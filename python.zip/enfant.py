"""Côté navigateur de la console et de la correction des questions ``code`` : le Python d'un Web Worker.

Le pendant de console_enfant.py (l'interpréteur qui reste vivant entre deux commandes) et de verifier.py (les tests
du professeur), sous Pyodide, dans un fil séparé de la page : ``worker.terminate()`` y tient lieu de bouton Arrêter.
Le worker de qtpy6web l'importe (un worker par console, et un pour la correction) ; l'import prépare le worker (le bac à
sable, irréversible, sur le dossier de l'élève). La sortie du programme va à la sortie standard, que le worker relaie.

    executer(source, reglages)     le programme de l'éditeur, dans un espace neuf ; reglages (JSON) : langage, classe,
                                   autorises, base
    ligne(texte, reglages)         une ligne de l'invite « >>> » / « sql> » (reglages : si la console n'a pas encore de session)
    saisie(texte)                  la réponse à un ``input()`` en attente
    commande(ligne)                les trois précédentes sous la forme des lignes JSON de console_code (le protocole de
                                   console_enfant.py, lignes de contrôle ``\x1e{json}`` comprises) : ce que
                                   qtpy6web.travailleur.ProcessusWeb appelle pour chaque ligne écrite
    verifier(demande)              les tests d'une question (verifier.py) ; demande en JSON, réponse {fraction, message}

executer, ligne et saisie rendent {attend, suite} : un ``input()`` attend une saisie ; l'invite attend la suite d'un bloc.
Tout passe en JSON, dans les deux sens : rien du navigateur n'entre dans Python autrement qu'en texte.

Ce qu'un fil sans mémoire partagée impose pour ``input()`` : le programme ne peut pas se suspendre en attendant la
page. Il est donc ABANDONNÉ (``Attente``) au premier ``input()`` sans réponse, et REJOUÉ depuis le début, sortie
coupée, quand la réponse arrive - la graine du hasard est fixée par exécution, si bien qu'un tirage se rejoue à
l'identique ; le temps qui passe, lui, ne se rejoue pas.
"""

import builtins
import io
import json
import os
import random
import sys
import time
from pathlib import Path

import bac_a_sable
import console_enfant
from console_enfant import FICHIER, jouer
from verifier import ICI, _decrire, _FauxPyxel, _ligne_eleve, base_sql, executer as executer_tests, executer_sql

DOSSIER = "/home/eleve"  # les fichiers de l'élève : le programme à corriger y est écrit avant les tests
SESSION = None  # l'état de la console de ce worker, depuis son premier « Exécuter » ou sa première ligne
REGLAGES = None  # commande() : la première ligne de console_code, les réglages de la console (JSON)


class Attente(BaseException):
    """Un ``input()`` sans réponse : le programme s'arrête là, il sera rejoué avec la réponse."""


class Sortie(io.TextIOBase):
    """``sys.stdout`` du worker : par paquets (une ligne ou 50 ms), muette pendant un rejeu, vers la sortie standard
    d'origine (``brut`` : le worker de qtpy6web la relaie)."""

    def __init__(self):
        self.brut, self.muet = None, False
        self.tampon, self.depuis = [], 0.0

    def writable(self):
        return True

    def write(self, texte):
        if not self.muet and texte:
            self.tampon.append(texte)
            if "\n" in texte and time.time() - self.depuis > 0.05:
                self.flush()
        return len(texte)

    def flush(self):
        if self.tampon:
            texte, self.tampon, self.depuis = "".join(self.tampon), [], time.time()
            self.brut.write(texte)
            self.brut.flush()


SORTIE = Sortie()


class Invite(console_enfant.Invite):
    """L'invite de console_enfant, mais une ``Attente`` n'est pas une erreur de l'élève : elle remonte."""

    def showtraceback(self):
        exc = sys.exc_info()[1]
        if isinstance(exc, Attente):
            raise exc
        super().showtraceback()


class Session:
    """L'état d'une question : son espace de noms, et de quoi le rejouer."""

    def __init__(self, reglages):
        self.langage = reglages.get("langage", "python")
        self.base, self.connexion = reglages.get("base", ""), None
        self.permis = bac_a_sable.programme(reglages.get("classe", ""), reglages.get("autorises"))
        self.historique, self.reponses, self.servies, self.graine = [], [], 0, 0
        self.invite = Invite(self._espace(), self.permis)

    def _espace(self):
        def saisie(invite=""):
            n, self.servies = self.servies, self.servies + 1
            if n < len(self.reponses):
                if self.servies == len(self.reponses):
                    SORTIE.muet = False  # tout ce qui était déjà à l'écran est rejoué : la suite est neuve
                return self.reponses[n]
            sys.stdout.write(str(invite))
            sys.stdout.flush()
            raise Attente
        espace = bac_a_sable.espace(self.permis, __name__="__eleve__", __file__=FICHIER)
        espace["__builtins__"]["input"] = saisie
        return espace

    def _programme(self, source):
        """console_enfant.executer, mais une ``Attente`` remonte au lieu d'être imprimée."""
        espace = self._espace()
        try:
            objet = compile(source, FICHIER, "exec")
            bac_a_sable.analyser(source, self.permis, FICHIER)
            exec(objet, espace)  # noqa: S102 - c'est le principe
        except SyntaxError as exc:
            print(f"ligne {exc.lineno} : erreur de syntaxe ({exc.msg})")
        except Attente:
            raise
        except BaseException as exc:  # noqa: BLE001 - toute erreur de l'élève, SystemExit compris
            print(f"{_ligne_eleve(exc, FICHIER)}{_decrire(exc)}")
        return espace

    def rejouer(self):
        """Tout l'historique depuis le début, muet tant que les réponses déjà données n'ont pas toutes resservi."""
        self.servies, SORTIE.muet = 0, bool(self.reponses)
        random.seed(self.graine)
        suite = False
        for genre, texte in self.historique:
            if genre == "executer":
                self.invite.locals, suite = self._programme(texte), False
                self.invite.resetbuffer()
            else:
                suite = self.invite.push(texte)
        return suite


def _preparer():
    """À l'import, avant tout programme : le dossier de l'élève, le faux pyxel, et le bac à sable (irréversible)."""
    os.makedirs(DOSSIER, exist_ok=True)
    os.chdir(DOSSIER)
    sys.path.insert(0, DOSSIER)
    sys.meta_path.insert(0, _FauxPyxel())
    builtins.input = _sans_clavier  # la correction (verifier.executer) n'a pas de clavier : EOFError, comme le lecteur Qt
    SORTIE.brut, sys.stdout = sys.stdout, SORTIE
    bac_a_sable.poser(DOSSIER, (str(ICI / "pyxel_factice.py"),))


def _sans_clavier(*_):
    raise EOFError


def _finir(session, action):
    """Une commande de la page, jusqu'à sa fin ou à un ``input()`` sans réponse ; ce que la page doit en savoir."""
    SORTIE.muet = False
    try:
        suite = action()
    except Attente:
        session.invite.resetbuffer()
        SORTIE.muet = False
        SORTIE.flush()
        return json.dumps({"attend": True, "suite": False})
    SORTIE.muet = False
    SORTIE.flush()
    return json.dumps({"attend": False, "suite": bool(suite)})


def executer(source, reglages):
    global SESSION
    session = SESSION = Session(json.loads(reglages))
    if session.langage == "sql":
        return _finir(session, lambda: _sql(session, source))
    session.historique, session.reponses, session.graine = [("executer", source)], [], random.randrange(1 << 32)
    return _finir(session, session.rejouer)


def ligne(texte, reglages):
    global SESSION
    session = SESSION = SESSION or Session(json.loads(reglages))
    if session.langage == "sql":
        return _finir(session, lambda: _sql(session, texte, neuve=False))
    session.historique.append(("ligne", texte))
    return _finir(session, lambda: session.invite.push(texte))


def saisie(texte):
    session = SESSION
    if session.langage == "sql":
        return json.dumps({"attend": False, "suite": False})  # il n'y a pas d'input() en SQL
    session.reponses.append(texte)
    return _finir(session, session.rejouer)


def _sql(session, texte, neuve=True):
    """console_enfant.main_sql : la base est rejouée à chaque « Exécuter », une ligne de l'invite garde la sienne."""
    if neuve and session.connexion is not None:
        session.connexion.close()
        session.connexion = None
    if session.connexion is None:
        try:
            session.connexion = base_sql(session.base)
        except Exception as exc:  # noqa: BLE001 - le jeu de données du sujet est fautif, le dire sans tomber
            print(f"le jeu de données de la question est refusé par SQLite : {_decrire(exc)}")
            return False
    jouer(session.connexion, texte)
    return False


def commande(texte):
    """Une ligne JSON de console_code (ce qu'elle écrit à console_enfant.py) : la première règle la console (``dossier``
    en moins : le worker a le sien), les suivantes sont ses ordres, ``{"executer": source}``, ``{"ligne": texte}``,
    ``{"saisie": texte}``. La sortie du programme s'imprime, puis la ligne de contrôle de console_enfant, ``\x1e{json}``."""
    global REGLAGES
    ordre = json.loads(texte)
    if REGLAGES is None:
        ordre.pop("dossier", None)
        REGLAGES = json.dumps(ordre)
        return
    if "executer" in ordre:
        r = executer(ordre["executer"], REGLAGES)
    elif "ligne" in ordre:
        r = ligne(ordre["ligne"], REGLAGES)
    else:
        r = saisie(ordre["saisie"])
    r = json.loads(r)
    print("\x1e" + json.dumps({"attend": True} if r["attend"] else {"fin": True, "suite": r["suite"]}))
    SORTIE.flush()


def verifier(demande):
    """verifier.verifier_question, sans sous-processus. {fraction, message} : ce que noyau.Code._verifier rend."""
    d = json.loads(demande)
    if d["langage"] == "sql":
        r = executer_sql(d["source"], d["base"], d["tests"], d["ordonne"])
    else:
        import pyodide_js  # noqa: PLC0415 - le système de fichiers d'Emscripten, que le bac à sable (posé sur open) ne voit pas

        fichier = Path(DOSSIER) / d["fichier"]
        pyodide_js.FS.writeFile(str(fichier), d["source"])
        r = executer_tests(str(fichier), d["tests"], d["tests_code"], d["classe"], d["autorises"])
    if r["erreur"]:
        return json.dumps({"fraction": 0, "message": r["erreur"]})
    return json.dumps({"fraction": r["reussis"] / r["total"] if r["total"] else None,
                       "message": "\n\n".join(r["messages"]) or None})


_preparer()
