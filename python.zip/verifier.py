"""Vérifie le travail d'un élève : exécute les tests des questions « code » sur ses fichiers.

    python verifier.py SUJET DOSSIER          tableau ✔ / ✘ par exercice, pour un élève
    python verifier.py SUJET --lot RENDUS     un sous-dossier par élève -> CSV eleve;exercice;points
    python verifier.py --solutions BANQUE     chaque solution de la banque contre ses propres tests

SUJET est un paquet élève (exporter_eleve.py) ou, chez le professeur, un sujet de sujets/. Chaque question
s'exécute dans son propre processus, sous délai de garde : une boucle infinie ou un input() de l'élève ne
bloque rien, et son code ne tourne jamais dans le programme appelant (éditeur, application). Le fichier
testé est le ``fichier`` de la question (``exercice_03.py``), à défaut celui du sujet (``tp.py``).

Le côté enfant n'utilise que la bibliothèque standard ; le côté parent lit le paquet avec modele.py (serializejson).
"""

import argparse
import ast
import builtins
import contextlib
import importlib.util
import io
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

import bac_a_sable

ICI = Path(__file__).resolve().parent
DELAI = 10  # secondes par question
MARQUE = "\x1eRESULTAT "  # préfixe de la ligne de résultat de l'enfant, que l'élève n'imprimera pas par hasard
SYMBOLES = {"reussi": "✔", "echec": "✘", "erreur": "✘", "absent": "·"}


# CÔTÉ ENFANT : un processus par question -------------------------------------------------------------------

def _ligne_eleve(exc, fichier):
    """« ligne 12 : » de la dernière trame qui est dans le fichier de l'élève, ou rien."""
    trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == fichier]
    return f"ligne {trames[-1].lineno} : " if trames else ""


def _decrire(exc):
    return f"{type(exc).__name__} : {exc}" if str(exc) else type(exc).__name__


class _FauxPyxel:
    """« import pyxel » charge pyxel_factice.py, même si le vrai est installé : pas de fenêtre, run() rend la main."""

    def find_spec(self, nom, chemin=None, cible=None):
        return importlib.util.spec_from_file_location("pyxel", ICI / "pyxel_factice.py") if nom == "pyxel" else None


def _absent(exc, fichier, resultat):
    """Un nom cité par le test que l'élève n'a pas encore écrit : « pas commencé », pas une erreur.
    Un NameError levé dans SON code (variable mal orthographiée) reste une erreur."""
    if isinstance(exc, NameError) and not _ligne_eleve(exc, fichier):
        resultat["absents"] += 1
        resultat["messages"].append(f"{exc.name} n'est pas encore défini")
        return True
    return False


def executer(fichier, tests, tests_code, classe="", autorises=None):
    """Charge le fichier de l'élève et passe les tests ; renvoie {reussis, total, absents, messages, erreur}.
    Le programme de l'élève est borné par bac_a_sable ; ``tests`` et ``tests_code`` (le code du professeur) ne le sont pas."""
    sys.meta_path.insert(0, _FauxPyxel())
    fichier = str(Path(fichier).resolve())
    os.chdir(Path(fichier).parent)
    sys.path.insert(0, str(Path(fichier).parent))
    total = len(tests) + bool(tests_code)
    resultat = {"reussis": 0, "total": total, "absents": 0, "messages": [], "erreur": None}
    sortie = io.StringIO()
    permis = bac_a_sable.programme(classe, autorises)
    espace = bac_a_sable.espace(permis, __name__="__eleve__", __file__=fichier)
    try:
        source = Path(fichier).read_text(encoding="utf-8")
        code = compile(source, fichier, "exec")
        bac_a_sable.analyser(source, permis, fichier)
        bac_a_sable.poser(Path(fichier).parent, (str(ICI / "pyxel_factice.py"),))  # le faux pyxel, seul fichier du projet lisible
        with contextlib.redirect_stdout(sortie):
            exec(code, espace)  # noqa: S102 - c'est le principe : exécuter le programme de l'élève
    except SyntaxError as exc:
        resultat["erreur"] = f"ligne {exc.lineno} : erreur de syntaxe ({exc.msg})"
        return resultat
    except EOFError:
        resultat["erreur"] = "le programme attend une saisie au clavier (input) : impossible à vérifier automatiquement"
        return resultat
    except BaseException as exc:  # noqa: BLE001 - toute erreur de l'élève, SystemExit compris
        resultat["erreur"] = f"{_ligne_eleve(exc, fichier)}{_decrire(exc)}"
        return resultat
    espace["__builtins__"] = builtins  # les tests du professeur ne sont pas bornés ; les fonctions de l'élève gardent les leurs
    espace["sortie"] = sortie.getvalue()
    if "pyxel" in sys.modules:
        espace.update(sys.modules["pyxel"].AIDES)
    for test in tests:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                obtenu = repr(eval(test["appel"], espace))  # noqa: S307
        except BaseException as exc:  # noqa: BLE001
            if not _absent(exc, fichier, resultat):
                resultat["messages"].append(test.get("message") or f"{test['appel']} provoque une erreur : "
                                            f"{_ligne_eleve(exc, fichier)}{_decrire(exc)}")
            continue
        if obtenu == test["attendu"]:
            resultat["reussis"] += 1
        else:
            resultat["messages"].append(test.get("message") or f"{test['appel']} devrait valoir {test['attendu']}, ton code donne {obtenu}")
    if tests_code:
        lignes = tests_code.splitlines()
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                exec(compile(tests_code, "<tests>", "exec"), espace)  # noqa: S102
            resultat["reussis"] += 1
        except BaseException as exc:  # noqa: BLE001
            if _absent(exc, fichier, resultat):
                return resultat
            trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == "<tests>"]
            ligne = lignes[trames[-1].lineno - 1].strip() if trames else ""
            if isinstance(exc, AssertionError):
                resultat["messages"].append(str(exc) or f"test non passé : {ligne}")
            else:
                resultat["messages"].append(f"{_ligne_eleve(exc, fichier)}{_decrire(exc)}" + (f" (pendant le test : {ligne})" if ligne else ""))
    return resultat


INTERDITS_SQL = (sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH, sqlite3.SQLITE_PRAGMA)


def _autoriseur(action, *_):
    """Le pendant SQL de bac_a_sable : le crochet d'audit de Python ne voit pas sqlite3, qui ouvrirait un fichier
    par son propre code C. Refuser ATTACH, DETACH et PRAGMA enferme la requête dans la base en mémoire."""
    return sqlite3.SQLITE_DENY if action in INTERDITS_SQL else sqlite3.SQLITE_OK


def base_sql(base):
    """Une base ``:memory:`` neuve où le script ``base`` (CREATE/INSERT) a été rejoué, l'autoriseur posé APRÈS lui :
    c'est la requête de l'élève qu'on borne, pas le jeu de données du sujet. Partagée avec la console du lecteur."""
    connexion = sqlite3.connect(":memory:")
    connexion.executescript(base)
    connexion.set_authorizer(_autoriseur)
    return connexion


def executer_sql(requete, base, tests, ordonne=False):
    """Exécute la requête de l'élève sur ``base`` et compare les LIGNES du résultat, jamais le texte de la requête.

    ``base`` est un script ``CREATE TABLE … ; INSERT …`` rejoué dans une base ``:memory:`` NEUVE à chaque test, si
    bien qu'un test ne subit pas l'état laissé par le précédent. Un test dont l'``appel`` est vide juge le résultat
    de la requête de l'élève ; sinon ``appel`` est une requête de contrôle jouée APRÈS elle, ce qui couvre les
    INSERT, UPDATE et DELETE, qui ne rendent rien mais laissent une trace. ``attendu`` est le ``repr()`` de la liste
    de tuples attendue ; l'ordre des lignes est indifférent sauf si ``ordonne``."""
    resultat = {"reussis": 0, "total": len(tests), "absents": 0, "messages": [], "erreur": None}
    if not requete.strip():
        resultat["erreur"] = "aucune requête écrite"
        return resultat
    try:
        base_sql(base).close()  # d'abord le jeu de données : sinon son erreur serait imputée à l'élève
    except sqlite3.Error as exc:
        resultat["erreur"] = f"le jeu de données du sujet est refusé par SQLite : {_decrire(exc)}"
        return resultat
    for test in tests:
        connexion = base_sql(base)
        try:
            obtenu = connexion.execute(requete).fetchall()
            if test["appel"].strip():
                obtenu = connexion.execute(test["appel"]).fetchall()
        except sqlite3.Error as exc:
            resultat["messages"].append(test.get("message") or f"ta requête provoque une erreur SQL : {_decrire(exc)}")
            continue
        finally:
            connexion.close()
        try:
            attendu = ast.literal_eval(test["attendu"])
        except (ValueError, SyntaxError):
            resultat["messages"].append(f"attendu illisible dans le sujet : {test['attendu']}")
            continue
        attendu = [tuple(ligne) for ligne in attendu]
        if (obtenu == attendu) if ordonne else (sorted(obtenu, key=repr) == sorted(attendu, key=repr)):
            resultat["reussis"] += 1
        else:
            quoi = f"la requête de contrôle « {test['appel']} » donne" if test["appel"].strip() else "ta requête donne"
            resultat["messages"].append(test.get("message") or f"{quoi} {obtenu}, on attendait {attendu}")
    return resultat


def enfant():
    demande = json.loads(sys.stdin.read())
    sys.stdin = io.StringIO()  # un input() de l'élève lève EOFError au lieu d'attendre
    if demande.get("langage") == "sql":
        resultat = executer_sql(Path(demande["fichier"]).read_text(encoding="utf-8"), demande.get("base", ""),
                                demande.get("tests", []), demande.get("ordonne", False))
    else:
        resultat = executer(demande["fichier"], demande.get("tests", []), demande.get("tests_code", ""),
                            demande.get("classe", ""), demande.get("autorises"))
    sys.__stdout__.write("\n" + MARQUE + json.dumps(resultat) + "\n")


# CÔTÉ PARENT -----------------------------------------------------------------------------------------------

def a_verifier(questions):
    """Les questions « code » et « sql » qui ont des tests, sous-questions de groupe comprises (``questions`` :
    celles d'un paquet élève ou d'une banque)."""
    return [f for q in questions for f in q.feuilles() if f.type in ("code", "sql") and (f.tests or f.tests_code)]


def verifier_question(q, dossier, fichier_defaut, python=sys.executable, classe=""):
    """{id, fichier, etat, points, obtenus, messages} ; etat : reussi, echec, erreur ou absent. ``classe`` fixe ce
    que le programme a le droit d'employer (bac_a_sable.programme), sauf si la question a sa propre liste."""
    nom = q.fichier or fichier_defaut
    fichier = Path(dossier) / nom
    base = {"id": q.id, "fichier": nom, "points": q.points, "obtenus": 0}
    if not fichier.is_file():
        return {**base, "etat": "absent", "messages": [f"{nom} n'existe pas encore"]}
    demande = json.dumps({"fichier": str(fichier), "tests": [vars(t) for t in q.tests], "tests_code": q.tests_code,
                          "classe": classe, "autorises": q.autorises, "langage": q.langage,
                          "base": getattr(q, "base", ""), "ordonne": getattr(q, "ordonne", False)})
    try:
        fini = subprocess.run([python, str(ICI / "verifier.py"), "--enfant"], input=demande, capture_output=True,
                              text=True, encoding="utf-8", timeout=DELAI)
    except subprocess.TimeoutExpired:
        return {**base, "etat": "erreur", "messages": [f"le programme ne s'est pas terminé en {DELAI} s : boucle infinie ?"]}
    lignes = [ligne for ligne in fini.stdout.split("\n") if ligne.startswith(MARQUE)]
    if not lignes:  # l'enfant est mort sans répondre : sortie brutale (os._exit), plantage de Python…
        return {**base, "etat": "erreur", "messages": [f"le programme s'est arrêté brutalement (code {fini.returncode})"
                                                       + (f" : {fini.stderr.strip().splitlines()[-1]}" if fini.stderr.strip() else "")]}
    r = json.loads(lignes[-1][len(MARQUE):])
    if r["erreur"]:
        return {**base, "etat": "erreur", "messages": [r["erreur"]]}
    etat = ("reussi" if r["reussis"] == r["total"] else "absent" if r["absents"] == r["total"] else "echec")
    return {**base, "etat": etat, "obtenus": round(base["points"] * r["reussis"] / r["total"], 2), "messages": r["messages"]}


def verifier(paquet, dossier, python=sys.executable):
    return [verifier_question(q, dossier, paquet.fichier, python, paquet.classe) for q in a_verifier(paquet.questions())]


def charger(chemin, mot_de_passe=None):
    """Un paquet élève (chiffré : ``mot_de_passe``), ou un sujet de sujets/ (chez le professeur, qui a les banques) converti en paquet."""
    from modele import MOT_DE_PASSE, Paquet  # noqa: PLC0415 - seulement côté parent : l'enfant n'importe pas Qt
    from modele import charger as charger_objet  # noqa: PLC0415
    objet = charger_objet(chemin, (mot_de_passe or MOT_DE_PASSE) if str(chemin).endswith(".qcm") else None)
    if isinstance(objet, Paquet):
        return objet
    from exporter_eleve import paquet  # noqa: PLC0415 - seulement chez le professeur
    from sujet import Sujet  # noqa: PLC0415
    return paquet(Sujet(chemin))


def afficher(resultats):
    for r in resultats:
        print(f"{SYMBOLES[r['etat']]} {r['id']:<40} {r['obtenus']:>5g} / {r['points']:<3g} {r['fichier']}")
        for message in r["messages"]:
            print(f"      {message}")
    print(f"total : {sum(r['obtenus'] for r in resultats):g} / {sum(r['points'] for r in resultats):g}")


def solutions(banque, python=sys.executable):
    """Chaque solution de la banque (objet ``Banque``, déjà chargée) contre ses propres tests ; renvoie
    [(id, messages)] de celles qui échouent."""
    echecs = []
    for q in a_verifier(banque.questions):
        with tempfile.TemporaryDirectory() as dossier:
            (Path(dossier) / (q.fichier or "tp.py")).write_text(q.solution, encoding="utf-8")
            r = verifier_question(q, dossier, "tp.py", python, banque.niveau)
        if r["etat"] != "reussi":
            echecs.append((q.id, r["messages"]))
    return echecs


def main():
    if sys.argv[1:] == ["--enfant"]:
        return enfant()
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujet", nargs="?", type=Path, help="paquet élève ou sujet")
    analyseur.add_argument("dossier", nargs="?", type=Path, help="dossier des fichiers de l'élève")
    analyseur.add_argument("--lot", type=Path, help="dossier des rendus : un sous-dossier par élève")
    analyseur.add_argument("--solutions", type=Path, nargs="+", help="banques dont vérifier les solutions")
    analyseur.add_argument("--mot-de-passe", help="mot de passe du paquet .qcm (défaut : celui des sujets d'entraînement)")
    analyseur.add_argument("--python", default=sys.executable, help="interpréteur de l'élève (défaut : celui-ci)")
    a = analyseur.parse_args()
    if a.solutions:
        from modele import charger as charger_objet  # noqa: PLC0415 - import tardif : modele importe verifier
        echecs = [(b, *e) for b in a.solutions for e in solutions(charger_objet(b), a.python)]
        for banque, qid, messages in echecs:
            print(f"✘ {banque.name} {qid} : " + " ; ".join(messages))
        return 1 if echecs else 0
    if not a.sujet or not (a.dossier or a.lot):
        analyseur.error("il faut un sujet, et un dossier ou --lot")
    paquet = charger(a.sujet, a.mot_de_passe)
    if a.lot:
        print("eleve;exercice;points;sur")
        for eleve in sorted(p for p in a.lot.iterdir() if p.is_dir()):
            resultats = verifier(paquet, eleve, a.python)
            for r in resultats:
                print(f"{eleve.name};{r['id']};{r['obtenus']:g};{r['points']:g}")
            print(f"{eleve.name};total;{sum(r['obtenus'] for r in resultats):g};{sum(r['points'] for r in resultats):g}")
    else:
        afficher(verifier(paquet, a.dossier, a.python))
    return 0


if __name__ == "__main__":
    sys.exit(main())
