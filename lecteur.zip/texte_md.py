"""Le Markdown des questions -> le HTML que comprend QTextDocument, et le style des cours (voir README.md).

Partagé par exporter_pdf.py (papier) et par les questions de modele.py (écran) : un seul rendu, deux supports.
"""

import ast
import html
import io
import json
import re
import textwrap
import tokenize
from pathlib import Path

import markdown
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import get_lexer_by_name
from pygments.style import Style
from pygments.token import Comment, Token

RACINE = Path(__file__).resolve().parent
PUCE_MARQUEE = re.compile(r"^([ \t]*)-([->]) ", re.M)  # « -- » une description, « -> » un clic ; « - » reste une action
SYMBOLES_PUCE = {"-": "–", ">": "→"}

STYLES = json.loads((RACINE / "referentiels/styles_texte.json").read_text(encoding="utf-8"))["styles"]

# Le style des cours (« CLAUDE - Style de cours.md ») : Carlito, code bleu à chasse fixe, commentaires gris,
# réponses attendues vert foncé, cadres (fond, bordure) définition / attention / code, tableaux à en-tête gris très clair.
POLICE, MONO = "Carlito", "DejaVu Sans Mono"
BLEU_CODE, VERT_REPONSE, GRIS = "#00b0f0", "#00b050", "#a6a6a6"
CADRE_DEFINITION, CADRE_CODE, CADRE_CORRECTION = ("#eefae6", "#6b934e"), ("#f7f7f7", "#bfbfbf"), ("#f7f7f7", VERT_REPONSE)
ENTETE_TABLEAU, BORDURE_TABLEAU = "#f2f2f2", "#000000"  # le vert 6b934e ne cadre QUE les définitions, qui sont des tableaux d'une seule case
STYLE_MONO = f"font-family:'{MONO}'; font-size:9pt; color:{BLEU_CODE}"  # 0,9 fois le corps du texte
POLICE_MAIN = "Kalam"  # POLICE_MAIN de noyau.py, dupliquée ici comme VERT/VERT_REPONSE (texte_md ne dépend pas de noyau)
STYLE_MONO_MANUSCRIT = f"font-family:'{POLICE_MAIN}'"  # le code cité dans une correction manuscrite (rond, croix,
# flèche, feedback) : ni couleur ni taille propres, pour hériter du trait rouge/vert et du corps du texte qui
# l'entoure au lieu de rester bleu à chasse fixe et plus petit (l'utilisateur, 27/09/2026)


LARGE = "\ue002"  # entoure un bloc de code élargi : exporter_pdf le sort des colonnes de la question (voir numeroter)

BLOC_CODE = re.compile(r"^([ \t]*)```([\w+-]*)[ \t]*\n(.*?)^\1```[ \t]*$\n?", re.S | re.M)  # indenté : dans une puce
STYLE_MOT = re.compile(r"\[([^\[\]]+)\]\{\.([a-z][a-z0-9_-]*)\}")  # [texte]{.rouge}
STYLE_BLOC = re.compile(r"^:::+\s*\{\.([a-z][a-z0-9_-]*)\}\s*\n(.*?)^:::+\s*$\n?", re.S | re.M)  # ::: {.encadre}
MARQUEUR_TROU = re.compile(r"\[\[(\d+)\]\]")
CODE_EN_LIGNE = re.compile(r"`([^`\n]+)`")
IMAGE_HTML = re.compile(r'<img alt="([^"]*)" src="([^"]+)" />')  # ce que produit markdown pour ![légende](nom)
IMAGE_EN_TETE = re.compile(r"\s*(!\[[^\]]*\]\([^)\s]+\))[ \t]*\n\s*\n")  # un bloc qui s'ouvre sur une image seule : un pictogramme
PLACE_BLOC = re.compile(r"<p>BLOCQCM(\d+)</p>")


TABLE_NUE = re.compile(r'<table((?: (?:width|style)="[^"]*")*)>')  # un tableau sans bordure déclarée : à habiller
LIGNE_ENTETE = re.compile(r"<tr>(\s*<th)")


class StyleCode(Style):
    """La coloration du cours : tout le code en bleu, les commentaires en gris."""
    styles = {Token: BLEU_CODE, Comment: GRIS}



def bordure(couleur, cellpadding=4):
    return f'border="1" bordercolor="{couleur}" cellpadding="{cellpadding}" cellspacing="0" style="border-collapse:collapse; border-style:solid"'



INDENTATION = re.compile(r"^((?:<span[^>]*>)*)( +)", re.M)  # après l'ouverture éventuelle du surlignage d'une ligne


def indentation_visible(corps):
    """L'indentation s'écrit en « $ » transparents : un lecteur de PDF jette les espaces de début de ligne au copier, les « $ »
    passent, et l'élève les remplace par des espaces après avoir collé. Hors d'un ``<pre>``, c'est aussi ce qui la rend
    visible : le HTML y réduit les espaces du début à un seul."""
    return INDENTATION.sub(lambda m: f'{m.group(1)}<span style="color:transparent">{"$" * len(m.group(2))}</span>', corps)


CODE_EN_LIGNE = re.compile(r"<code>(.*?)</code>", re.S)
INSECABLE_MAXI = 20  # caractères : un code en ligne plus court ne se coupe pas en fin de ligne (« a ??? b », 28/09/2026)


def insecable(code):
    """Un code en ligne court garde ses espaces insécables : coupé, « a <= b » ne se lit plus comme une expression."""
    return code.replace(" ", "&nbsp;") if len(html.unescape(code)) <= INSECABLE_MAXI else code


def bloc_code(corps, cadre=CADRE_CODE, largeur=None, taille=9):
    """``largeur`` (en px du HTML, voir encadre) : un bloc trop large pour sa colonne s'encadre à cette largeur et
    se marque, pour qu'exporter_pdf le sorte des colonnes de la question et le laisse mordre sur la marge.
    ``taille`` : le corps de la police, que couper_code réduit pour une ligne qu'il n'a pas pu couper."""
    style = STYLE_MONO.replace("9pt", f"{taille:g}pt")
    pre = f'<pre style="{style}; white-space:pre-wrap">{indentation_visible(corps)}</pre>'  # sous une puce, la place manque
    return encadre(pre, cadre) if largeur is None else f"{LARGE}{encadre(pre, cadre, largeur=largeur)}{LARGE}"


TAILLE_MINI = 7  # en dessous, un code imprimé ne se lit plus


MOTS_DE_TETE = {"for", "if", "else", "and", "or"}  # une coupure devant eux se lit comme une phrase qui continue


def points_de_coupure(code):
    """Pour chaque ligne (numérotée depuis 1), les blancs entre deux mots où Python la laisse couper :
    (colonne, retrait de la suite, profondeur de parenthèses, devant un mot de MOTS_DE_TETE). Hors parenthèses
    (profondeur 0), la coupure demande une barre oblique inverse ; dedans, la suite s'aligne sous la parenthèse.
    Et la colonne du commentaire de chaque ligne qui en porte un."""
    coupures, commentaires, ouvrantes, precedent = {}, {}, [], None
    for t in tokenize.generate_tokens(io.StringIO(code).readline):
        ligne, colonne = t.start
        if t.type == tokenize.COMMENT:
            commentaires[ligne] = colonne
        elif t.type not in (tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER):
            if ouvrantes and ouvrantes[-1] is None:  # la suite s'alignera sur ce premier mot après la parenthèse
                ouvrantes[-1] = colonne if precedent.end[0] == ligne else precedent.end[1]
            if precedent and precedent.end[0] == ligne and precedent.end[1] < colonne:
                coupures.setdefault(ligne, []).append((colonne, ouvrantes[-1] if ouvrantes else None, len(ouvrantes),
                                                       t.string in MOTS_DE_TETE))
            if t.type == tokenize.OP and t.string in "([{":
                ouvrantes.append(None)
            elif t.type == tokenize.OP and t.string in ")]}" and ouvrantes:
                ouvrantes.pop()
            precedent = t
    return coupures, commentaires


def couper_ligne(ligne, coupures, commentaire, colonnes):
    """Une ligne trop longue -> les lignes qui la remplacent, ou None si elle ne se laisse pas couper. Le code se
    coupe au niveau de parenthèses le moins profond, de préférence devant un mot de tête, le plus à droite
    possible — sans laisser en tête moins de la moitié de la place, qui ne ferait que reporter le problème."""
    retrait = len(ligne) - len(ligne.lstrip())
    if commentaire is not None and len(ligne[:commentaire].rstrip()) <= colonnes:  # le code tient : on replie le commentaire
        texte, code = ligne[commentaire + 1:].strip(), ligne[:commentaire].rstrip()
        if code and colonnes - commentaire >= 25:  # la suite du commentaire s'aligne sous son « # »
            debut, largeur = commentaire, colonnes - commentaire - 2
        else:  # pas la place à droite : le commentaire passe au-dessus du code, à son retrait
            debut, largeur = retrait, colonnes - retrait - 2
        morceaux = [" " * debut + "# " + m for m in equilibrer(texte, largeur)]
        if code and debut == commentaire:
            return [ligne[:commentaire] + morceaux[0].lstrip()] + morceaux[1:]
        return morceaux + ([code] if code else [])
    possibles = [c for c in coupures if c[0] + (2 if c[2] == 0 else 0) <= colonnes]  # 2 : la place de « \\ »
    bons = [c for c in possibles if c[0] >= colonnes // 2] or possibles
    if not bons:
        return None
    colonne, retrait_suite, profondeur, _ = min(bons, key=lambda c: (c[2], not c[3], -c[0]))
    if retrait_suite is None or retrait_suite > colonnes - 20:  # rien à quoi s'aligner, ou trop à droite
        retrait_suite = retrait + 8
    tete = ligne[:colonne].rstrip() + ("" if profondeur else " \\")
    return [tete, " " * retrait_suite + ligne[colonne:].lstrip()]


def replier(lignes, i):
    """Un commentaire en pleine ligne vient d'être coupé en ``lignes[i]`` et ``lignes[i + 1]`` : si le commentaire
    suivant continue la même phrase (même retrait, minuscule en tête), la fin coupée le rejoint au lieu de rester
    seule sur sa ligne — un paragraphe se reforme au lieu de descendre en escalier."""
    fin, suite = lignes[i + 1], lignes[i + 2] if i + 2 < len(lignes) else ""
    retrait = len(fin) - len(fin.lstrip())
    texte = suite[retrait:]
    if fin.lstrip().startswith("#") and suite[:retrait].strip() == "" and texte.startswith("# ") and texte[2:3].islower() \
            and not est_du_code(texte[2:]):  # « # print(x) » : du code commenté, pas la suite de la phrase
        lignes[i + 1:i + 3] = [fin + " " + texte[2:]]


def est_du_code(texte):
    try:
        ast.parse(texte)
        return True
    except SyntaxError:
        return False


def equilibrer(texte, largeur):
    """Le texte replié en lignes de ``largeur`` au plus, aussi égales que possible : sans cela la dernière ne
    porterait souvent qu'un mot, seul sous un commentaire qui en compte quinze."""
    def plier(largeur):
        return textwrap.wrap(texte, largeur, break_long_words=False, break_on_hyphens=False)
    lignes = plier(largeur)
    while largeur > 10 and len(plier(largeur - 1)) == len(lignes):
        largeur -= 1
    return plier(largeur)


def couper_code(code, colonnes):
    """Le code, ses lignes de plus de ``colonnes`` caractères coupées là où Python l'accepte : après une virgule
    entre parenthèses, la suite alignée sous la parenthèse ; sinon entre deux mots, avec une barre oblique inverse ;
    un commentaire replié en plusieurs. Le code imprimé reste ainsi exécutable tel quel, ce que ne serait pas un
    retour à la ligne de Qt, qui repart à la colonne 0. Rend (code, taille de police) : une ligne qui ne se coupe
    pas (une longue chaîne, un bloc qui n'est pas du Python) fait réduire la police du bloc, jusqu'à TAILLE_MINI."""
    try:
        attendu = ast.dump(ast.parse(code))
    except (SyntaxError, ValueError):
        attendu = None  # pas du Python (une sortie, du texte) : on ne sait pas où couper sans changer le sens
    lignes = code.split("\n")
    while attendu is not None:
        coupures, commentaires = points_de_coupure("\n".join(lignes))
        for i, ligne in enumerate(lignes):
            if len(ligne) > colonnes:
                nouvelles = couper_ligne(ligne, coupures.get(i + 1, []), commentaires.get(i + 1), colonnes)
                if nouvelles and len(nouvelles) > 1:  # un mot plus long que la place ne se coupe pas
                    lignes[i:i + 1] = nouvelles
                    if len(nouvelles) == 2 and ligne.lstrip().startswith("#"):
                        replier(lignes, i)
                    break
        else:
            break
    coupe = "\n".join(lignes)
    if attendu is not None and ast.dump(ast.parse(coupe)) != attendu:  # filet : la coupure ne doit rien changer
        coupe = code
    longueur = max(map(len, coupe.split("\n")))
    taille = 9 if longueur <= colonnes else max(TAILLE_MINI, int(9 * colonnes / longueur * 2) / 2)
    return coupe, taille


POLICE_MATHS = "DejaVu Math TeX Gyre"
# $…$ : pas d'espace juste après le $ ouvrant ni juste avant le $ fermant, ni de chiffre après lui (« 5 $ et 10 $ »
# reste du texte). Un code entre accents graves est pris en entier, pour que ses $ ne soient pas lus comme une formule.
FORMULE = re.compile(r"(`[^`\n]+`)|\$(?=\S)([^$\n]*?\S)\$(?!\d)")
COMMANDES_MATHS = {"cdots": "⋯", "ldots": "…", "times": "×", "le": "≤", "ge": "≥", "ne": "≠", "infty": "∞"}
ARGUMENT = r"(\{(?:[^{}]|\{[^{}]*\})*\}|\\[a-zA-Z]+|.)"  # {groupe}, \commande ou un seul caractère


def formule(source):
    """Une formule écrite entre $ -> HTML : lettres seules en italique, ^ en exposant, _ en indice,
    \\frac{a}{b} en fraction en ligne, - en signe moins, * en croix, les COMMANDES_MATHS, et toute autre
    commande en mot droit (\\log, \\sin, \\max). Rendu identique à l'écran et au PDF, sans dépendance :
    QTextDocument ne connaît ni MathML ni LaTeX."""
    return mettre_en_forme(html.escape(source, quote=False))


def mettre_en_forme(texte):
    def groupe(texte):
        return mettre_en_forme(texte[1:-1] if texte.startswith("{") else texte)

    def fraction(m):  # ½ en petit ; n(n + 1)/2 en pleine taille, un exposant de cette longueur est illisible
        haut, bas = m.group(1).strip("{}"), m.group(2).strip("{}")
        if re.fullmatch(r"\w", haut) and re.fullmatch(r"\w", bas):
            return f"<sup>{groupe(haut)}</sup>⁄<sub>{groupe(bas)}</sub>"
        somme = lambda t: re.search(r"[+−]", re.sub(r"\(.*?\)", "", t))  # a + b s'entoure, n(n + 1) non
        return "/".join(f"({groupe(t)})" if somme(t) else groupe(t) for t in (haut, bas))

    texte = texte.replace("-", "−").replace("*", "×")
    texte = re.sub(r"\\frac\s*" + ARGUMENT + r"\s*" + ARGUMENT, fraction, texte)
    texte = re.sub(r"\^" + ARGUMENT, lambda m: f"<sup>{groupe(m.group(1))}</sup>", texte)
    texte = re.sub(r"_" + ARGUMENT, lambda m: f"<sub>{groupe(m.group(1))}</sub>", texte)
    texte = re.sub(r"\\([a-zA-Z]+)", lambda m: COMMANDES_MATHS.get(m.group(1), m.group(1)), texte)
    texte = re.sub(r"(<i>.*?</i>|<[^>]*>|&\w+;)|(?<![a-zA-Z])([a-zA-Z])(?![a-zA-Z])",  # hors des balises déjà posées
                   lambda m: m.group(1) or f"<i>{m.group(2)}</i>", texte)
    return texte


def formules(texte):
    return FORMULE.sub(lambda m: m.group(1) or f"<span style=\"font-family:'{POLICE_MATHS}'\">{formule(m.group(2))}</span>",
                       texte)


def ligne_code(corps):
    """Une ligne de code seule dans le texte courant (un élément à ranger) : la chasse, la couleur et l'indentation
    d'un bloc de code, sans son cadre."""
    return f'<span style="{STYLE_MONO}">{indentation_visible(corps)}</span>'



def encadre(contenu, cadre, style="", largeur="100%"):
    """Un bloc dans un cadre (fond, bordure) du style de cours. ``largeur`` en px du HTML : Qt les convertit en
    points du PDF à 0,75 (96 ppp supposés contre les 72 du document), et un cadre plus large que la colonne
    déborde à droite — mais seulement au premier niveau, une cellule le rogne."""
    return (f'<table width="{largeur}" bgcolor="{cadre[0]}" {bordure(cadre[1], 6)}>'
            f'<tr><td style="{style}">{contenu}</td></tr></table>')


def tableau(rendu):
    """Les tableaux nus d'un rendu prennent les bordures et l'en-tête des tableaux du cours."""
    rendu = TABLE_NUE.sub(rf'<table\1 {bordure(BORDURE_TABLEAU)}>', rendu)
    return LIGNE_ENTETE.sub(rf'<tr bgcolor="{ENTETE_TABLEAU}">\1', rendu)



PUCES = {"<ul>": '<table width="100%" cellpadding="0" cellspacing="0" style="margin-top:4px; margin-bottom:4px">', "</ul>": "</table>",
         "<li>": '<tr>{}<td style="vertical-align:top{}">', "</li>": "</td></tr>"}
GRIS_FAIT = "#9a9a9a"  # une action cochée : son texte, et le rond de sa case (Case, modele.py)
FAITE = f"; color:{GRIS_FAIT}"
JETON_PUCE = "\ue000"  # suivi du symbole de la puce : posé avant le Markdown, lu par puces()
JETON_INDENT = "\ue001"  # une espace d'indentation d'un code en ligne, relue après le Markdown (voir html())


def cellule(contenu, largeur=16):
    """La cellule de la puce, à gauche de son texte."""
    return f'<td width="{largeur}" style="vertical-align:top">{contenu}</td>'


def puces(rendu, coche=None):
    """Puces alignées sur le texte et détachées de lui ; une sous-liste, dans le texte de sa puce, s'aligne donc sur ce texte.
    Symbole • (action), – (description) ou → (clic). Les listes numérotées restent des listes : leurs ``<li>`` ne
    deviennent pas des lignes de tableau. ``coche`` : () -> (la cellule qui remplace le • d'une action, à l'écran d'un
    projet : une case à cocher, l'appelant les compte : un bloc ::: passe ici avant le texte qui le contient ; l'action
    est-elle faite : son texte est alors grisé)."""
    listes = []  # les listes ouvertes, "ul" ou "ol" (une liste coupée par un bloc de code reprend en <ol start="2">)

    def remplacer(m):
        balise, paragraphe, marque = m.group(0), m.group(1) or "", m.group(2)
        fermeture = balise[1] == "/"
        nom = balise[2:4] if fermeture else balise[1:3]  # ul, ol ou li
        if nom != "li":
            listes.pop() if fermeture else listes.append(nom)
        if nom == "ul" or fermeture and nom == "li" and listes[-1:] == ["ul"]:
            return PUCES[f"</{nom}>" if fermeture else f"<{nom}>"]
        if nom == "li" and not fermeture and listes[-1:] == ["ul"]:
            case, faite = coche() if coche and not marque else (cellule(marque or "•"), False)
            return PUCES["<li>"].format(case, FAITE if faite else "") + paragraphe
        return "<li>" + paragraphe if balise.startswith("<li>") else balise
    return re.sub(rf"</?(?:ul|ol)\b[^>]*>|</li>|<li>(\s*<p>)?(?:{JETON_PUCE}(.))?", remplacer, rendu)


def css(nom_style):
    """Un style de la palette -> déclaration CSS. La couleur s'accompagne de gras (l'impression est souvent en noir et
    blanc), sauf `"gras": false` : un style en italique s'en distingue déjà."""
    style, regles = STYLES[nom_style], []
    if "couleur" in style:
        regles += [f"color:{style['couleur']}"] + (["font-weight:bold"] if style.get("gras", True) else [])
    if style.get("italique"):
        regles.append("font-style:italic")
    if "fond" in style:
        regles.append(f"background-color:{style['fond']}")
    if "police" in style:
        police = {"serif": "Liberation Serif", "sans-serif": POLICE, "monospace": MONO}.get(style["police"], style["police"])
        regles.append(f"font-family:'{police}'")
    return "; ".join(regles)


def colorer(code, langage):
    try:
        lexer = get_lexer_by_name(langage or "python")
    except Exception:
        lexer = get_lexer_by_name("text")
    return highlight(code, lexer, HtmlFormatter(style=StyleCode, noclasses=True, nowrap=True))



class Markdown:
    """Le Markdown des questions -> le HTML que comprend QTextDocument."""

    def __init__(self, images, largeur_utile, code_large=None):
        """``code_large`` : (colonnes, largeur px, colonnes maxi) du papier — au-delà de ``colonnes`` caractères, une
        ligne de code fait élargir son cadre à ``largeur px``, qui mord sur la marge d'impression et tient ``colonnes
        maxi`` caractères. None à l'écran, qui défile."""
        self.images, self.largeur_utile = images, largeur_utile  # images : nom -> QImage
        self.code_large = code_large

    def html(self, texte, trou=None, _blocs=None, colonnes=None, coche=None, manuscrit=False):
        """trou : fonction (numéro) -> HTML, pour remplacer les marqueurs [[n]] d'un texte à trous.
        colonnes : la place dont le code dispose ICI, si elle diffère de celle d'une question (un contexte, sans
        colonne de numéro ni de points, en a davantage).
        coche : () -> la cellule de la puce d'une action (voir puces), une case à cocher de l'écran, comptée par l'appelant.
        manuscrit : le texte est une correction écrite à la main (feedback, appréciation) -> un code entre
        accents graves y prend l'écriture manuscrite, sans couleur ni taille propres, pour hériter du trait
        rouge/vert et du corps du texte qui l'entoure."""
        blocs = [] if _blocs is None else _blocs

        def garder(m):
            retrait, langage = m.group(1), m.group(2)
            code = re.sub(rf"^{retrait}", "", m.group(3), flags=re.M)
            blocs.append(self.code(code, langage, colonnes=colonnes, trou=trou))
            return f"\n\n{retrait}BLOCQCM{len(blocs) - 1}\n\n"

        texte = BLOC_CODE.sub(garder, texte)
        texte = formules(texte)
        texte = PUCE_MARQUEE.sub(lambda m: f"{m.group(1)}- {JETON_PUCE}{SYMBOLES_PUCE[m.group(2)]}", texte)
        # `    ligne` : markdown rend un code en ligne .strip(), qui mange l'indentation — et jusqu'aux espaces
        # insécables, que str.strip() compte aussi pour des blancs. Elle passe donc en jeton, rendu après coup.
        texte = CODE_EN_LIGNE.sub(lambda m: "`" + JETON_INDENT * (len(m.group(1)) - len(m.group(1).lstrip())) + m.group(1).lstrip() + "`",
                                  texte)
        texte = STYLE_BLOC.sub(lambda m: "\n\n" + self.bloc(m.group(1), m.group(2), trou, blocs, colonnes, coche, manuscrit) + "\n\n", texte)
        texte = STYLE_MOT.sub(lambda m: f'<span style="{css(m.group(2))}">{m.group(1)}</span>', texte)
        if trou:
            texte = MARQUEUR_TROU.sub(lambda t: trou(t.group(1)), texte)
        rendu = markdown.markdown(texte, extensions=["tables", "sane_lists"]).replace(JETON_INDENT, "&nbsp;")
        if _blocs is None:  # appel de tête : les blocs de code reprennent leur place
            rendu = PLACE_BLOC.sub(lambda m: blocs[int(m.group(1))], rendu)
        style_code = STYLE_MONO_MANUSCRIT if manuscrit else STYLE_MONO
        rendu = CODE_EN_LIGNE.sub(lambda m: f'<span style="{style_code}">{insecable(m.group(1))}</span>', rendu)
        return IMAGE_HTML.sub(self.media, tableau(puces(rendu, coche)))

    def code(self, code, langage, cadre=CADRE_CODE, colonnes=None, trou=None):
        """Un bloc de code dans son cadre. Sur papier, au-delà des colonnes de la question, le cadre s'élargit en
        mordant sur la marge ; au-delà de ce cadre élargi, les lignes se coupent (voir couper_code)."""
        largeur, taille = None, 9
        if self.code_large:
            colonnes_question, largeur, colonnes_maxi = self.code_large
            code, taille = couper_code(code, colonnes_maxi)
            if langage == "sql":  # jamais réduit : une ligne trop longue revient à la ligne (l'utilisateur, 28/09/2026)
                taille = 9
            if max(map(len, code.splitlines() or [""])) <= (colonnes or colonnes_question):
                largeur = None
        if trou and MARQUEUR_TROU.search(code):  # pas de coloration : les marqueurs deviennent des champs
            corps = MARQUEUR_TROU.sub(lambda t: trou(t.group(1)), html.escape(code))
        else:
            corps = colorer(code, langage)
        return bloc_code(corps, cadre, largeur, taille)

    def bloc(self, nom, texte, trou, blocs, colonnes=None, coche=None, manuscrit=False):
        """Un bloc ::: {.nom} dans son cadre. S'il s'ouvre sur une image seule, elle se met à gauche et le texte à sa droite."""
        style, image = STYLES[nom], IMAGE_EN_TETE.match(texte)
        contenu = self.html(texte[image.end():] if image else texte, trou, blocs, colonnes, coche, manuscrit)
        if image:
            contenu = (f'<table cellpadding="0" cellspacing="0"><tr><td style="vertical-align:middle">{self.html(image.group(1))}</td>'
                       f'<td width="12"></td><td style="vertical-align:middle">{contenu}</td></tr></table>')
        return encadre(contenu, (style.get("fond", "#ffffff"), style.get("bordure", CADRE_CODE[1])), style=css(nom))

    def inline(self, texte, manuscrit=False):
        """Un texte court (proposition, élément) : sans le paragraphe qui l'entoure."""
        rendu = self.html(texte, manuscrit=manuscrit)
        m = re.fullmatch(r"<p>(.*)</p>\n?", rendu, re.S)
        return m.group(1) if m and "<p>" not in m.group(1) else rendu

    def media(self, m):
        legende, nom = m.group(1), m.group(2)
        if nom in self.images:
            image = self.images[nom]  # taille d'affichage donnée par la résolution de l'image, comme dans Word
            largeur = min(image.width() * 72 / (image.dotsPerMeterX() * 0.0254), self.largeur_utile)
            return f'<img src="{nom}" width="{largeur:.0f}">'
        extension = nom.rsplit(".", 1)[-1].lower()
        if extension == "svg":  # dessiné en vecteurs par ObjetSvg, à la taille que le SVG déclare
            return f'<img src="{nom}">'
        # son ou vidéo : injouable sur papier, on le nomme
        return f"<i>[{extension} : {html.escape(nom)}{', ' + legende if legende else ''}]</i>"
