"""Le tableau de bord d'une classe : ses TP, révisions et mini-interrogations, chacun avec son état et un bouton pour le
commencer ou le continuer, et en bas les bilans de l'élève (copies, thèmes, année), sans passer par Teams pour chercher un lien (demande de l'utilisateur, 25/10/2026 : « un tableau
de bord SmartTeacher en qtpy6 avec des boutons pour démarrer ou reprendre un TP ou autre »).

Deux fichiers du dossier Dropbox de l'application, à sa racine, le font :
    echeances.csv     écrit à la main par le professeur (format du Worker 59, LibreOffice, « ; », heure de Paris en
                      « JJ/MM/AAAA HH:MM ») : sujet;classe;debut;fin_creneau;echeance, le sujet relatif à sujets/ sans .json ;
    tableau.json      écrit ici (``catalogue``, à chaque déploiement) : pour chaque sujet déposé, son nom et le
                      chemin de son .qcm dans Dropbox, celui que le lien ``?sujet=`` des élèves ouvre ; pour chaque
                      classe de ``listes/``, ses inscrits chiffrés (``classes_chiffrees``).
Le premier est relu à chaque ouverture de la page : une échéance changée se voit sans redéployer.

En ligne, la page ``?classe=SECONDE 5&cle=…`` (``web/pyqt6/pont_tableau.py``) montre ``Portail`` plein canevas : l'élève
y entre par son nom, son prénom et son mot de passe, vérifiés sur la liste de sa classe et le
fichier d'empreintes (``codes.IDENTITES``) comme à l'accueil d'un sujet
(l'utilisateur, 26/10/2026 : « Il faut rentrer le nom, prénom, et mot de passe pour arriver sur l'accueil, par contre le
navigateur peut retenir cela […] Les navigateurs ne seront pas partagés »), puis voit ``Tableau`` ; un bouton ouvre le
sujet à la place du tableau. En natif, ``tableau_eleves.py --classe "SECONDE 5"`` montre le même portail sur le dossier
Dropbox synchronisé, et un bouton lance ``lecteur.py`` sur le .qcm. ``tableau_eleves.py catalogue`` écrit tableau.json,
``tableau_eleves.py liens HOTE`` les adresses des classes, clé comprise, que le professeur leur donne.

Rien de nominatif ni de secret en clair : la page et son dossier Dropbox sont lisibles de tous (le jeton est dans la
page). La liste d'une classe y est chiffrée par une clé que seule son adresse porte, comme le code de classe porte celle
d'un sujet ; un sujet à venir n'a pas de bouton."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
import time
import sys
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from html import escape, unescape
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, MutableSet
from urllib.parse import urlencode

import bilans_widget
import codes
import echeances
import modele
from noyau import ECRAN, REPONDUES, sans_mention_ide
from panneau_echeances import COLONNES, MAISONS, SANS_ECHEANCE, Panneau, cours_de_la_classe, cours_du_jour
from qtpy6.QtCore import QPointF, QSize, Qt, QTimer
from qtpy6.QtGui import QColor, QFontMetrics, QIcon, QKeySequence, QPainter, QPainterPath, QPen, QPixmap, QShortcut
from qtpy6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDateTimeEdit, QFormLayout, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QScrollArea, QSizePolicy, QStackedWidget, QToolButton, QVBoxLayout, QWidget, QMenu)
from serializejson._encryption import decrypt

DROPBOX = Path("/DATA/Dropbox/Applications/SmartTeacherQcm")  # le dossier de l'application, synchronisé sur ce disque
ECHEANCES, CATALOGUE = echeances.NOM, "tableau.json"
# Les états, dans l'ordre où le tableau les montre : ce qui se fait maintenant d'abord, ce qui est fini en dernier.
EN_COURS, A_FINIR, A_VENIR, FERME = "En cours", "À finir", "À venir", "Fermé"
ETATS = (EN_COURS, A_FINIR, A_VENIR, FERME)
# ce que ``commencee(nom)`` rend pour une copie déjà rendue dans cet appareil (``pont_qt.cle_rendue``) : sous son titre, et
# hors de « À faire » (le professeur, 16/11/2026 : « la section "A Faire" ne semble pas se mettre à jour quand les élèves ont
# fini leur TP », W695)
RENDU = "Rendu"
# ce qu'il rend pour un TP aux questions obligatoires toutes closes, des bonus encore ouverts (``pont_qt.cle_bonus``) : son
# cadre « Bonus à finir », d'une autre couleur que « À finir » (le professeur, 17/11/2026 11:54 : « on pourrait avoir deux
# cadre de couleur différente si c'est à finir obligatoirement , ou si c'est jute les question bonus à finri », W749)
BONUS_A_FINIR = "Bonus à finir"


@dataclass
class Ligne:
    sujet: str  # relatif à sujets/, sans .json
    classe: str
    debut: datetime | None  # UTC
    fin_creneau: datetime | None
    echeance: datetime | None
    echeance_tardive: datetime | None = None  # le rattrapage, dit au professeur dans la partie grise (``en_bref``)
    maison: bool | None = None  # case « maison » (W732) : à finir à la maison (True), en pause entre les séances (False)
    sans_echeance: bool = False  # « sans » écrit dans la case : aucune échéance, même dérivée (``entrees``, W764)
    eleves: frozenset[str] = frozenset()  # case ``eleves`` : les seuls élèves qui voient le sujet (``echeances.vise``)

    def etat(self, maintenant: datetime) -> str:
        """« En cours » pendant le créneau en classe (sans fin de créneau : jusqu'à l'échéance), « À finir » ensuite jusqu'à
        l'échéance, « À venir » avant, « Fermé » après."""
        if self.debut and maintenant < self.debut:
            return A_VENIR
        if self.echeance and maintenant >= self.echeance:
            return FERME
        if self.fin_creneau and maintenant >= self.fin_creneau:
            return A_FINIR
        return EN_COURS


def date_de_paris(texte: str) -> datetime | None:
    """« JJ/MM/AAAA HH:MM » à l'heure de Paris, en UTC (``echeances.instant``, celle du lecteur) ; None si vide."""
    texte = texte.strip()
    if not texte:
        return None
    try:
        return echeances.instant(texte)
    except ValueError:
        raise ValueError(f"« {texte} » n'est pas une date « JJ/MM/AAAA HH:MM »") from None


def cle_de(nom: str) -> str:
    """Un sujet ou une classe, quelle que soit sa graphie : seul le dernier nom d'un chemin compte (``echeances``), et
    « 2nd 5 » tapé dans l'adresse comme « 2nd_5 » ou « 2ND5 », « Les réseaux sociaux - TP2 » comme le nom de son .qcm
    (« Les_reseaux_sociaux_-_TP2 ») : la même chose ; et un sujet « Listes : méthodes » comme son .qcm, que
    ``codes.nom_de_fichier`` écrit « Listes_-_methodes » (06/11/2026 : la ligne du TP03 de Terminale sans bouton)."""
    return codes.cle_de(nom)


def nom_de_revision(chemin: tuple[str, ...], sorte: str) -> str:
    """Le nom du sujet ``sorte`` (« réviser ») du thème ``chemin``, celui que compose ``entrainement.py`` et sous lequel le
    catalogue le range (``cle_de``)."""
    return " - ".join(p.replace("/", "-") for p in chemin) + f" - {sorte}"


def cle_de_reviser(niveau: str, nom: str) -> str:
    """La clé d'un sujet « Réviser » dans le catalogue : son niveau de Dropbox (« Seconde », « Première », « Terminale »)
    puis son nom. ``cle_de`` ne garde que le dernier nom, et les trois « Python - réviser » (SNT, NSI Première,
    NSI Terminale) s'y écrasaient : le dernier lu gagnait, et le bouton de Première et de Terminale ouvrait celui de
    Seconde (17/11/2026, W759)."""
    return cle_de(f"{niveau} - {nom}")


def cle_de_chemin(chemin: str) -> str:
    """La clé d'un sujet dans le catalogue : ``cle_de`` de CHAQUE nom de son chemin relatif à sujets/ (« SNT/Python - TP01 … »
    → « snt/python-tp01-… »). ``cle_de`` seule ne garde que le dernier nom, et le TP01 de Seconde écrasait celui de Première,
    même nom à un autre niveau : son bouton manquait (20/11/2026, W825)."""
    return "/".join(cle_de(p) for p in chemin.strip().replace("\\", "/").removesuffix(".qcm").split("/") if p.strip())


def du_catalogue(sujets: dict[str, Any], sujet: str) -> tuple[str, dict[str, Any]]:
    """La clé et l'entrée du catalogue (``{}`` : aucune) du ``sujet`` d'une ligne d'echeances.csv, sous l'une de ses trois
    formes : son chemin relatif à sujets/ (la clé), son lien dans Dropbox (« Seconde/Python/TP/… », lignes d'avant), ou son
    seul nom (le catalogue d'avant ``cle_de_chemin``, ou une ligne écrite à la main), qui ne vaut que s'il n'est qu'à un niveau."""
    cle = cle_de_chemin(sujet)
    if isinstance(entree := sujets.get(cle), dict):
        return cle, entree
    nom = cle.rpartition("/")[2]
    # Le nom seul ne départage qu'une ligne sans chemin, ou une entrée d'un ancien catalogue à clé nue : un chemin d'un
    # niveau ne prend jamais l'entrée d'un autre (le TP01 de Première, non déposé, aurait pris celui de Seconde).
    memes = [(c, e) for c, e in sujets.items() if isinstance(e, dict) and c.rpartition("/")[2] == nom]
    # le lien parmi TOUTES les entrées : une clé de Réviser (cle_de_reviser) n'a pas le nom de son chemin (W846)
    lien = [(c, e) for c, e in sujets.items() if isinstance(e, dict) and cle_de_chemin(str(e.get("lien", ""))) == cle]
    nus = [(c, e) for c, e in memes if "/" not in cle or "/" not in c]
    for trouves in (lien, nus):
        if len(trouves) == 1:
            return trouves[0]
    return cle, {}


def reviser(revisions: dict[str, Any], chemin: tuple[str, ...], niveau: str = "") -> dict[str, Any] | None:
    """L'entrée du catalogue que le bouton « Réviser » de la section ``chemin`` ouvre : le sujet « Réviser » de son THÈME
    (``entrainement.py``, une banque par thème, décision du 06/11/2026 22:14) et du ``niveau`` de la classe
    (``cle_de_reviser``) ; ``None`` s'il n'est pas déposé. Une entrée d'avant cette clé (sans niveau) ne vaut que si
    son lien est bien dans ce niveau. Les sujets par section de la rév. 2228 (« entraînement », « validation ») sont à
    la corbeille depuis le 15/11/2026."""
    nom = nom_de_revision(chemin[:1], "réviser")
    trouve = revisions.get(cle_de_reviser(niveau, nom)) if niveau else None
    if not (isinstance(trouve, dict) and trouve.get("lien")):
        trouve = revisions.get(cle_de(nom))
        if niveau and isinstance(trouve, dict) and str(trouve.get("lien", "")).split("/")[0] != niveau:
            return None
    return trouve if isinstance(trouve, dict) and trouve.get("lien") else None


def meme_classe(a: str, b: str) -> bool:
    return cle_de(a) == cle_de(b)


class Erreur(str):
    """Une erreur du fichier d'échéances, avec la classe de sa ligne (``classe`` vide : inconnue). L'élève ne voit que
    celles de sa classe, le professeur toutes (l'utilisateur, 26/10/2026)."""

    def __new__(cls, texte: str, classe: str = "") -> Erreur:
        erreur = super().__new__(cls, texte)
        erreur.classe = classe
        return erreur


def oui_non(texte: str | None) -> bool | None:
    """Une case oui/non d'echeances.csv (``echeances.OUI``, ``echeances.NON``) ; vide ou autre : ``None``, le défaut."""
    mot = (texte or "").strip().casefold()
    return True if mot in echeances.OUI else False if mot in echeances.NON else None


def lire_echeances(texte: str) -> tuple[list[Ligne], list[Erreur]]:
    """Les lignes du fichier d'échéances, et les erreurs d'une ligne illisible (sautée, pas fatale : le professeur l'écrit à
    la main). Pour un même sujet et une même classe, la dernière ligne l'emporte, comme dans ``echeances.trouver``."""
    lignes, erreurs, numero = {}, [], 1
    texte = echeances.sans_signature(texte)  # sa ligne de signature n'est pas une ligne illisible
    try:
        for numero, champs in enumerate(csv.DictReader(io.StringIO(texte.lstrip("﻿")), delimiter=";"), start=2):
            try:
                sujet, classe = champs["sujet"].strip(), champs["classe"].strip()
                if sujet and classe:
                    sans = (champs.get("echeance") or "").strip().lower() == echeances.SANS  # « sans » : aucune échéance (W764)
                    if sans:
                        champs["echeance"] = ""
                    lignes[cle_de(sujet), cle_de(classe)] = Ligne(sujet, classe, *(date_de_paris(champs.get(c) or "")
                                                                                 for c in ("debut", "fin_creneau", "echeance",
                                                                                           "echeance_tardive")),
                                                                     maison=oui_non(champs.get("maison")), sans_echeance=sans,
                                                                     eleves=(lue := echeances.lire(champs)).eleves)
                    erreurs += [Erreur(f"ligne {numero} : {e}", classe) for e in lue.erreurs if e.startswith("eleves")]
            except (KeyError, ValueError, AttributeError) as erreur:
                erreurs.append(Erreur(f"ligne {numero} : {erreur}", str(champs.get("classe") or "").strip()))
    except csv.Error as erreur:  # une case démesurée : la suite du fichier est perdue, pas ce qui est déjà lu
        erreurs.append(Erreur(f"ligne {numero + 1} et suivantes illisibles : {erreur}"))
    return list(lignes.values()), erreurs


LISTES = Path(__file__).parent / "listes"  # les listes des classes, celles que l'export inscrit dans les sujets


sel_de_classe = codes.sel_de_classe  # le sel et la clé de la liste d'une classe : dans ``codes``, sans Qt, qui en
cle_de_classe = codes.cle_de_classe  # chiffre aussi la copie jointe au PDF corrigé (``correction/copie_eleve.py``)


def arguments_du_lecteur(programme: str, chemin: Path, jeton: str, section: tuple[str, ...] = (), essai: int = 0) -> list[str]:
    """Le lecteur natif ouvert sur un sujet du tableau, avec le code de la classe : l'élève n'en tape aucun ; un « Réviser »,
    avec la section dont le bouton a été pressé (``section_en_texte``) ; ``essai`` (son historique) : la copie de cette
    série (``lecteur.chemin_essai``), ouverte telle quelle (``--essai``)."""
    if essai:  # le sujet déposé est la copie de base, la première série
        chemin = Path(chemin).with_name(Path(chemin).stem + codes.essai(essai) + Path(chemin).suffix)
    return [programme, str(chemin), *(["--mot-de-passe", codes.phrase_du_jeton(jeton)] if jeton else []),
            *(["--section", section_en_texte(section)] if section else []), *(["--essai", str(essai)] if essai else [])]


def section_en_texte(section: tuple[str, ...]) -> str:
    """La section d'un « Réviser » comme la lit le lecteur (``lecteur.section_de`` : ``--section``, ``?section=``) : la liste
    JSON de son chemin, dont les noms peuvent porter « / » (« Opérateurs d'affectation / Unpacking ») ; vide : tout le thème."""
    return json.dumps(list(section), ensure_ascii=False) if section else ""


def jetons_du_sujet(definition: Any, secret: str) -> dict[str, str]:
    """Pour chaque classe inscrite dans le ``.qcm`` du sujet ``definition``, le code qui l'ouvre pour elle (``codes.jeton`` : ce
    que porte ``?code=``), sans date : c'est ``echeances.csv`` qui les donne (``echeances.appliquer``). Le rang de la classe
    est celui que lit ``Accueil.deverrouiller``, ``sorted(paquet.inscrits)``."""
    import exporter_eleve  # noqa: PLC0415 - côté professeur seulement
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas sujet.py
    classes = sorted({Path(liste).stem for liste in exporter_eleve.listes_du_sujet(definition)})  # deux niveaux peuvent partager une liste
    if len(classes) > codes.CLASSES:  # l'export le refuse : ce sujet n'a pas de .qcm à ces classes
        return {}
    cle = exporter_eleve.cle_neuve(module_sujet.graine_de(definition), secret)[1]
    return {classe: codes.jeton(codes.code_classe(cle, rang)) for rang, classe in enumerate(classes)}


def jetons_du_paquet(chemin: Path, secret: str) -> dict[str, str]:
    """Comme ``jetons_du_sujet``, mais lus dans le ``.qcm`` déposé ``chemin`` : ses classes inscrites et sa clé (celle de son
    en-tête), pour un .qcm que son sujet n'exporte plus là (Pyxel de Terminale, déposé le 11/10/2026 par l'ancien champ
    « niveaux », retiré à la rév. 951) : les classes d'aujourd'hui n'y ont plus le même rang. Rien s'il ne s'ouvre pas."""
    try:
        cle = codes.cle_du_mot(secret, chemin.read_bytes())
        classes = sorted(modele.charger(chemin, cle).inscrits)
    except Exception:  # noqa: BLE001 - un .qcm illisible garde son bouton, sans code de classe
        return {}
    return {classe: codes.jeton(codes.code_classe(cle, rang)) for rang, classe in enumerate(classes)}


def nom_du_paquet(chemin: Path, secret: str | None) -> str:
    """``Paquet.nom`` du ``.qcm`` déposé ``chemin`` (la place de la copie, ``pont_qt.cle``), que son nom de fichier
    (``codes.nom_de_fichier``) peut altérer ; "" s'il ne s'ouvre pas (absent du disque, pas de ``secret``)."""
    try:
        return str(modele.charger(chemin, codes.cle_du_mot(secret, chemin.read_bytes())).nom) if secret else ""
    except Exception:  # noqa: BLE001 - un .qcm illisible garde son bouton, sous le nom de son fichier
        return ""


def qcm_des_echeances(dropbox: Path) -> dict[str, list[str]]:
    """Sous ``cle_de`` de leur sujet, les chemins de ``.qcm`` (relatifs à ``dropbox``) que nomment les lignes de son
    echeances.csv : la place d'un sujet déposé ailleurs que là où il s'exporte aujourd'hui."""
    fichier = dropbox / ECHEANCES
    if not fichier.exists():
        return {}
    resultat: dict[str, list[str]] = {}
    for ligne in lire_echeances(fichier.read_text(encoding="utf-8"))[0]:
        sujet = ligne.sujet.strip().replace("\\", "/").lstrip("/").removesuffix(".qcm")
        resultat.setdefault(cle_de(sujet), []).append(f"{sujet}.qcm")
    return resultat


def classes_chiffrees(secret: str, listes: Path = LISTES, jetons: dict[str, dict[str, str]] | None = None) -> dict[str, str]:
    """Pour chaque liste de ``listes`` (« SECONDE 5.csv »), sous ``cle_de`` de la classe, ses inscrits tels qu'un sujet les
    porte (``codes.inscrire`` : nom, prénom) et les ``jetons`` de ses sujets (sous ``cle_de`` du sujet : jamais en clair dans
    tableau.json, public), dans un fichier age en armure, par la clé de la classe ; le mot de passe professeur l'ouvre aussi
    (``codes.cle_du_mot`` sur son sel)."""
    from serializejson._encryption import encrypt, prime  # noqa: PLC0415 - côté professeur seulement

    resultat = {}
    for chemin in sorted(listes.glob("*.csv")):
        classe = chemin.stem
        cle = cle_de_classe(secret, classe)
        prime(cle, sel_de_classe(classe))
        contenu = {"classe": classe, "inscrits": codes.inscrire(codes.lire_liste(chemin)), "codes": (jetons or {}).get(classe, {})}
        resultat[cle_de(classe)] = encrypt(json.dumps(contenu, ensure_ascii=False).encode(), cle, armor=True)
    return resultat


@dataclass
class Identite:
    """Qui est entré : l'élève tel que la liste le nomme, ou le professeur (``nom`` et ``prenom`` vides). Entré par son mot
    de passe : son ``secret``, qui ouvre aussi son bilan, et l'empreinte à déposer d'une première visite (``depot``). Lus dans
    la liste de sa classe, les ``jetons`` qui ouvrent ses sujets, sans rien lui demander (``jetons_du_sujet``)."""
    nom: str
    prenom: str
    professeur: bool = False
    secret: bytes | None = None
    depot: dict[str, str] | None = None
    jetons: dict[str, str] | None = None
    # le professeur entré par son mot de passe : la graine qui signe echeances.csv (``codes.graine_echeances``,
    # ``regler_par``), jamais affichée ni comparée
    graine: bytes | None = field(default=None, repr=False, compare=False)
    # l'élève vu par le professeur (``Portail.voir_comme``, W814) : sans secret, son bilan ouvert par l'empreinte déposée,
    # ses copies en lecture seule
    lecture_seule: bool = False

    @property
    def eleve(self) -> str:
        return f"{self.nom} {self.prenom}".strip()


def ouvrir_liste(chiffree: str, cle: str) -> dict[str, Any] | None:
    """La liste d'une classe (``classes_chiffrees``) ouverte par ``cle``, ou None si elle ne l'ouvre pas."""
    try:
        contenu = json.loads(bytes(decrypt(chiffree, cle)).decode())
    except Exception:  # noqa: BLE001 - mauvaise clé, liste abîmée : elle ne s'ouvre pas, l'élève le lit
        return None
    return contenu if isinstance(contenu, dict) and isinstance(contenu.get("inscrits"), list) else None


def sans_liste(cat: dict[str, Any], classe: str) -> str:
    """Pourquoi l'adresse de ``classe`` n'ouvre aucune liste. tableau.json sans aucune classe : il n'a pas été lu (la page
    rend un fichier illisible vide, ``lire_catalogue``), une connexion à Dropbox qui a échoué au chargement ; sinon la
    classe de l'adresse n'y est pas. Les deux disaient « pas encore en ligne », et le professeur cherchait une liste
    déposée depuis la veille (19/11/2026, W806, élève de Seconde 4)."""
    if not cat.get("classes"):
        return "La liste des classes n'a pas pu être lue : vérifiez la connexion à Internet, puis rechargez la page."
    return f"La classe « {classe} » de cette adresse n'a pas de liste en ligne : demandez au professeur le lien de votre classe."


def identifier(chiffree: str, cle: str, nom: str, prenom: str, code: str, identites: dict[str, Any] | None = None,
               garde: tuple[str, str, bytes] | None = None) -> Identite | str:
    """L'entrée du tableau : l'élève de la liste (ouverte par la ``cle`` de l'adresse), reconnu malgré ses fautes
    (``codes.reconnaitre``), entré par son mot de passe, celui
    tapé ou celui que l'appareil ``garde``, comme à l'accueil d'un sujet (``codes.reconnaitre_mot_de_passe`` sur le
    fichier d'empreintes ``identites``) ; ou le professeur,
    son mot de passe tapé comme code (``codes.cle_du_mot`` ouvre la liste). Rend l'``Identite``, ou ce qui ne va pas. Le
    professeur n'est essayé qu'à défaut d'élève reconnu : chaque essai coûte une seconde (scrypt)."""
    code, nom, prenom = code.strip(), nom.strip(), prenom.strip()
    if not code and garde is None:
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    liste = ouvrir_liste(chiffree, cle) if cle else None
    inscrit = liste and nom and prenom and codes.reconnaitre(nom, prenom, liste["inscrits"])
    if inscrit:
        cle_eleve = codes.nom_identite(inscrit[0], inscrit[1])
        secret = garde[2] if garde and codes.nom_identite(*garde[:2]) == cle_eleve else None
        reconnu = codes.reconnaitre_mot_de_passe(identites or {}, inscrit[0], inscrit[1], code, secret)
        if isinstance(reconnu, str):
            return reconnu
        return Identite(inscrit[0], inscrit[1], secret=reconnu.secret, depot=reconnu.depot, jetons=liste.get("codes"))
    if not code:
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    mot = codes.cle_du_mot(code, chiffree.encode())
    if mot and ouvrir_liste(chiffree, mot) is not None:
        return Identite("", "", professeur=True, graine=codes.graine_echeances(code))
    if liste is None and not cle:  # « ?classe=SECONDE+5 » seul, lien coupé ou retapé (22/11/2026, W929 : quatre élèves)
        return ("Il manque la fin de cette adresse (« &cle=… ») : ouvrez le lien complet de votre classe, donné par le "
                "professeur, et gardez-le dans vos favoris.")
    if liste is None:
        return "Cette adresse ne permet pas d'entrer : demandez au professeur le lien de votre classe."
    if not (nom and prenom):
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    return f"« {nom} {prenom} » n'est pas sur la liste de la classe {liste.get('classe', '')} : vérifiez l'orthographe."


# Les sections de la page d'une classe, dans cet ordre sous chaque thème (l'utilisateur, 06/11/2026 : « organiser la page
# par thème, puis TP, Révisions, Mini-interrogation, DS ») : le nom du dossier du cours, puis le titre montré.
# le dossier d'un sujet → la sous-section de son thème, dans cet ordre (l'utilisateur, 06/11/2026 : « il faut des nom de sous
# section plus clair dans les thèmes : "Cours", "Travaux pratiques", "Interrogations" (DS et mini-interrogations), "Projet",
# "Bilan" ») ; « Cours » ne vient pas d'un dossier (``Tableau._cours_du_theme``), le bilan du thème va sous « Réviser »
# (``bilans_dans_les_themes``)
# « Réviser » entre « Cours » et « Travaux pratiques » (l'utilisateur, 06/11/2026 : « dans chaque thème il faut une
# sous-section "Réviser" », « entre "cours" et "travaux pratiques" »)
TYPES = {"Révisions": "Réviser", "TP": "Travaux pratiques", "Mini-Interrogations": "Interrogations", "DS": "Interrogations",
         "Projet": "Projet", "Projets": "Projet"}
AUTRES = "Autres"  # un sujet que rien ne range


def theme_et_type(dossier: str) -> tuple[str, str]:
    """Le thème et le type d'un sujet, tirés de son ``dossier`` de cours : « NSI/NSI Première/Python/TP » → (« Python »,
    « TP »), « SNT/Python/TP/SANS IDE » → (« Python », « TP »), « SNT/DS » → (« SNT », « DS ») ; sans type connu, le dernier
    dossier (« Pyxel/Projet Monkey ») ; (« », « ») sans dossier."""
    parties = [p for p in dossier.replace("\\", "/").split("/") if p]
    rangs = [i for i, p in enumerate(parties) if p in TYPES]
    i = rangs[-1] if rangs else len(parties) - 1
    if i < 1:
        return "", ""
    return parties[i - 1], parties[i]


def theme_du_nom(nom: str) -> tuple[str, str]:
    """Le repli de ``theme_et_type`` pour un sujet que le catalogue ne range pas (absent, ou tableau.json d'avant le
    06/11/2026) : « Python - TP08 - Titre » → (« Python », « TP ») ; une ligne d'echeances.csv nomme le sujet par son nom
    de fichier (``codes.nom_de_fichier`` : « Python_-_Revision_08_-_… », sans accents), lu de même."""
    morceaux = [m.strip() for m in nom.replace("_-_", " - ").split(" - ")]
    sorte = morceaux[1] if len(morceaux) > 1 else ""
    for prefixe, dossier in (("TP", "TP"), ("Révision", "Révisions"), ("Revision", "Révisions"),
                             ("Mini-", "Mini-Interrogations"), ("DS", "DS"), ("Projet", "Projet")):
        if sorte.startswith(prefixe):
            return morceaux[0], dossier
    if len(morceaux) > 1 and morceaux[-1] == "réviser":  # le Réviser d'une évaluation (``entrainement``, W828)
        return morceaux[0], "Révisions"
    return (morceaux[0], AUTRES) if len(morceaux) > 1 else ("", AUTRES)


def sorte_du_sujet(chemin: str | Path) -> str:
    """« TP », « Révisions », « Mini-Interrogations », « DS »… (``theme_du_nom``) d'après le nom du sujet, sinon celui de son
    dossier ; ``AUTRES`` sinon. Elle choisit les échéances par défaut du panneau des réglages (``panneau_echeances``)."""
    chemin = Path(str(chemin).replace("\\", "/"))
    for nom in (chemin.stem, f"_ - {chemin.stem}", f"_ - {chemin.parent.name}"):
        if (sorte := theme_du_nom(nom)[1]) != AUTRES:
            return sorte
    return AUTRES


def catalogue(dropbox: Path = DROPBOX, deposes: Iterable[str] = (), secret: str | None = None,
              listes: Path = LISTES) -> dict[str, Any]:
    """tableau.json : pour chaque sujet de sujets/ dont le .qcm est déposé dans ``dropbox`` ou dans ``deposes`` (ses chemins
    dans Dropbox : ceux que deployer.sh vient d'envoyer, que le client Dropbox n'a peut-être pas encore rapatriés), le chemin du .qcm dans Dropbox (sans « / » de tête, celui de ``?sujet=``) et son nom (``Paquet.nom`` : la place de la
    copie dans le navigateur, ``pont_qt.cle``, et le titre que le tableau montre, « Thème - TP2 - Titre » comme les
    fichiers), sous ``cle_de`` de son nom ; et sous « classes », les listes chiffrées (``classes_chiffrees``) par le mot
    de passe professeur ``secret`` (``codes.professeur()`` par défaut ; sans lui, aucune classe : personne n'entre)."""
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas sujet.py
    sys.path.insert(0, str(Path(__file__).parent / "web"))
    from dropbox_professeur import place  # noqa: PLC0415
    secret = secret or codes.professeur()
    sujets, deposes, jetons = {}, {d.lstrip("/") for d in deposes}, {}
    ailleurs = qcm_des_echeances(dropbox)
    for chemin in sorted(module_sujet.SUJETS.rglob("*.json")):
        try:
            definition = module_sujet.lire(chemin)
        except Exception:  # noqa: BLE001, S112 - un sujet en chantier ne doit pas priver la classe de son tableau
            continue
        relatif = chemin.relative_to(module_sujet.SUJETS).with_suffix("").as_posix()
        lien = place(module_sujet.sortie(definition, "qcm") / f"{codes.nom_de_fichier(chemin.stem)}.qcm")
        depose = lien.lstrip("/") in deposes or (dropbox / lien.lstrip("/")).exists()
        if not depose:  # déposé ailleurs, à la place que nomme echeances.csv : le .qcm d'avant (Pyxel de Terminale), à son
            # niveau (le TP01 de Première, pas encore déposé, prenait celui de Seconde, même nom)
            dossiers = lien.lstrip("/").split("/")[:-1]  # sans dossier (exporté à la racine), aucun niveau à respecter
            lien = next((q for q in ailleurs.get(cle_de(relatif), ())
                         if (not dossiers or cle_de(q.split("/")[0]) == cle_de(dossiers[0]))
                         and (q in deposes or (dropbox / q).exists())), "")
            if not lien:
                continue
        # un « Réviser » par niveau, sous le même nom : sa clé porte le niveau, celui de Dropbox en tête de son lien
        cle = cle_de_reviser(lien.lstrip("/").split("/")[0], chemin.stem) if getattr(definition, "reviser", None) else cle_de_chemin(relatif)
        sujets[cle] = {"lien": lien.lstrip("/"), "nom": chemin.stem}
        theme, sorte = theme_et_type(definition.dossier or "")
        if theme:  # la section de la page où il se range (``Tableau``)
            sujets[cle].update(theme=theme, type=sorte)
        if cours := cours_du_sujet(definition):
            sujets[cle]["cours"] = cours
            if any(pages := pages_du_sujet(definition)):  # jusqu'où la section « Cours » le montre (``pages_vues``)
                sujets[cle]["cours_pages"] = pages
                if any(tables := diaporamas_du_sujet(definition)):  # le diaporama coupé au même niveau
                    sujets[cle]["diaporama_pages"] = tables
        if duree := getattr(definition, "duree_minutes", None):  # ce que montrent les réglages en ligne d'une ligne sans durée
            sujets[cle]["duree"] = duree
        sien = (jetons_du_sujet(definition, secret) if depose else jetons_du_paquet(dropbox / lien, secret)) if secret else {}
        for classe, jeton in sien.items():
            jetons.setdefault(classe, {})[cle] = jeton
    # un .qcm déposé que nomme une ligne d'echeances.csv mais qu'aucun sujet du dépôt n'exporte plus (sujet renommé ou
    # retiré depuis) garde son bouton, sous la clé de son lien : le TP01 V2 de Seconde, renommé « TP01 » le 16/11/2026
    # (rév. 3023), programmé pour la SECONDE 5 sous son ancien nom le 20/11, restait « À finir » sans bouton [PAC-8]
    liens = {entree["lien"] for entree in sujets.values()}
    for lien in sorted({q for qcm in ailleurs.values() for q in qcm} - liens):
        if lien in deposes or (dropbox / lien).exists():
            cle = cle_de_chemin(lien)
            sujets[cle] = {"lien": lien, "nom": nom_du_paquet(dropbox / lien, secret) or Path(lien).stem}
            for classe, jeton in (jetons_du_paquet(dropbox / lien, secret) if secret else {}).items():
                jetons.setdefault(classe, {})[cle] = jeton
    # les DS papier publiés depuis le menu PDF (``publier_ds``) : aucun déploiement ne les refait, ils restent
    return {"version": 1, "sujets": sujets, "classes": classes_chiffrees(secret, listes, jetons) if secret else {},
            PAPIER: catalogue_du_disque(dropbox)[PAPIER]}


PAPIER = "papier"  # la clé de tableau.json des DS papier publiés (W647) : à part de « sujets », aucun n'a de lien


def du_theme(cours: str, theme: str, autres: Iterable[str] = ()) -> bool:
    """Le PDF de cours ``cours`` (sa place dans Dropbox, « Première/Python/L’ESSENTIEL….pdf ») n'est pas rangé dans le
    dossier d'un des ``autres`` thèmes de la page (« Python » pour le thème « Pyxel ») : un cours à la racine d'un
    niveau, ou dans un dossier qui ne porte le nom d'aucun thème de la page (thème « Autres », thème tiré du nom d'un
    sujet hors catalogue, plus court que son dossier), reste dans le thème qui le cite. Le
    professeur, 21/11/2026, à la place d'un élève de Terminale : « peut-on enlever les boutons  L'ESSENTIEL DU LANGUAGE
    PYTHON du thème Pyxel sur l'accueil? pourquoi est-il là alors qu'il est absent de
    /DATA/Dropbox/Applications/SmartTeacherQcm/Terminale/Pyxel/ ? » [APE-6]."""
    dossiers = cours.split("/")[1:-1]
    return not dossiers or cle_de(dossiers[0]) == cle_de(theme) or cle_de(dossiers[0]) not in map(cle_de, autres)


def cours_du_sujet(definition: Any) -> list[list[str]]:
    """Les PDF de cours d'un sujet, que la page range dans son thème (l'utilisateur, 06/11/2026 : « il faut ajouter un
    section cours avec les pdf de cours dans chaque thème ») : leur place dans Dropbox, celle où deployer.sh les dépose, leur
    titre et le PDF de leur diaporama, s'il existe (« pour les cours il faut proposer la version pdf et la version slides »)."""
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas sujet.py
    sys.path.insert(0, str(Path(__file__).parent / "web"))
    from dropbox_professeur import place  # noqa: PLC0415
    return [[place(module_sujet.PROF / c).lstrip("/"), Path(c).stem,
             place(d).lstrip("/") if (d := module_sujet.diaporama(module_sujet.PROF / c)).exists() else ""]
            for c in getattr(definition, "cours", None) or ()]


def pages_du_sujet(definition: Any) -> list[int | None]:
    """La limite de pages de chaque cours du sujet (``DefinitionSujet.cours_pages`` : un nombre pour tous, ou un par cours ;
    None : le cours entier), dans l'ordre de ``cours_du_sujet``."""
    cours, pages = getattr(definition, "cours", None) or (), getattr(definition, "cours_pages", None)
    return list(pages) if isinstance(pages, list) else [pages] * len(cours)


def diaporamas_du_sujet(definition: Any) -> list[list[int]]:
    """Pour chaque cours du sujet, dans l'ordre de ``cours_du_sujet``, les diapositives de son diaporama à montrer selon la
    page du cours déjà vue (``diaporama_par_page``) ; [] : pas de diaporama, ou pas de coupe sûre."""
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement
    tables = []
    for c in getattr(definition, "cours", None) or ():
        cours = module_sujet.PROF / c
        diapo = module_sujet.diaporama(cours)
        tables.append(list(diaporama_par_page(cours, diapo)) if cours.exists() and diapo.exists() else [])
    return tables


def _debut_de_titre(texte: str) -> str:
    """Les trois premiers mots d'un titre, sans casse ni ponctuation : « Convention des couleurs de ce cours » (diapositive)
    et « Convention des couleurs de ce document » (cours) se reconnaissent, « Nombres » et « Nombres ( int , float ) »
    aussi (``startswith``)."""
    return "".join(re.findall(r"\w+", texte.casefold())[:3])


_DIAPORAMAS: dict[tuple[str, str], tuple[int, ...]] = {}  # une lecture des deux PDF par déploiement


def diaporama_par_page(cours: Path, diapo: Path) -> tuple[int, ...]:
    """Le diaporama coupé au même niveau que le PDF du cours (le professeur, 17/11/2026, guichet W721 : ni entier ni caché,
    seulement les diapositives des chapitres déjà vus) : pour un cours vu jusqu'à sa page k, l'élément k-1 est le nombre de
    diapositives à montrer, jusqu'à la fin du dernier chapitre commencé à la page k ou avant. Le chapitre d'une diapositive
    est son titre (première ligne) avant « : » ; « TP n » et « (suite) » prolongent le précédent ; sa page est la première
    du cours, sommaire exclu et jamais avant celle du chapitre précédent, dont une ligne commence comme lui
    (``_debut_de_titre``) ; introuvable, il suit le précédent. Vide si aucun chapitre ne se retrouve : pas de coupe sûre."""
    if (cle := (str(cours), str(diapo))) in _DIAPORAMAS:
        return _DIAPORAMAS[cle]
    from qtpy6.QtPdf import QPdfDocument  # noqa: PLC0415 - côté professeur, au déploiement

    def lignes(chemin: Path) -> list[list[str]]:
        document = QPdfDocument(None)
        document.load(str(chemin))
        pages = [[x.strip() for x in document.getAllText(i).text().splitlines() if x.strip()] for i in range(document.pageCount())]
        document.close()
        return pages

    pages, diapositives = lignes(cours), lignes(diapo)
    chapitres: list[tuple[int, int]] = []  # (rang de sa première diapositive, page du cours où il commence)
    page, precedent, trouves = 0, None, 0
    for rang, contenu in enumerate(diapositives):
        titre = re.sub(r"\s*\(suite\)\s*$", "", (contenu or [""])[0].split(" : ")[0], flags=re.IGNORECASE)
        debut = _debut_de_titre(titre)
        if rang == 0 or not debut or debut == precedent or re.fullmatch(r"tp\d+\w*", debut) or debut == "sommaire":
            continue
        precedent = debut
        for numero in range(max(page, 1), len(pages) + 1):
            if any(x.casefold() == "sommaire" for x in pages[numero - 1]):
                continue
            if any(_debut_de_titre(x).startswith(debut) for x in pages[numero - 1]):
                page, trouves = numero, trouves + 1
                break
        chapitres.append((rang, page))
    table = () if not trouves else tuple(
        next((rang for rang, debut in chapitres if debut > k), len(diapositives)) for k in range(1, len(pages) + 1))
    _DIAPORAMAS[cle] = table
    return table


def limite_du_diaporama(pages: int | None, table: tuple[int, ...]) -> int | None:
    """Les diapositives à montrer quand le cours se voit jusqu'à ``pages`` (None : en entier, le diaporama aussi) ; 0 : pas
    de bouton, faute de coupe sûre (``diaporama_par_page`` vide, ou catalogue d'avant)."""
    if pages is None:
        return None
    return table[min(pages, len(table)) - 1] if table else 0


def diaporamas_lus(valeur: Any, nombre: int) -> tuple[tuple[int, ...], ...]:
    """« diaporama_pages » d'une entrée de tableau.json, une table par cours ; absente ou mal formée : aucune."""
    if not (isinstance(valeur, list) and len(valeur) == nombre and all(
            isinstance(t, list) and all(type(n) is int and n > 0 for n in t) for t in valeur)):
        return ()
    return tuple(tuple(t) for t in valeur)


def pages_lues(valeur: Any, nombre: int) -> tuple[int | None, ...]:
    """« cours_pages » d'une entrée de tableau.json, une par cours ; absente ou mal formée : aucune limite."""
    if not (isinstance(valeur, list) and len(valeur) == nombre
            and all(p is None or type(p) is int and p > 0 for p in valeur)):
        return ()
    return tuple(valeur)


def pages_vues(liste: list[Entree]) -> dict[str, int | None]:
    """Pour chaque PDF de cours qu'un sujet déjà ouvert ou fermé de la classe cite, les pages déjà vues : la plus grande
    limite de ces sujets, None (tout) si l'un n'en a pas (le professeur, 16/11/2026 : « limite le cours aux pages déjà
    vues ») ; un cours que seuls des sujets à venir citent n'y est pas."""
    vues: dict[str, int | None] = {}
    for e in liste:
        if e.etat == A_VENIR:
            continue
        for i, (chemin, _, _) in enumerate(e.cours):
            limite = e.cours_pages[i] if i < len(e.cours_pages) else None
            if chemin in vues and vues[chemin] is None:
                continue
            vues[chemin] = None if limite is None else max(limite, vues.get(chemin) or 0)
    return vues


def catalogue_du_disque(dropbox: Path = DROPBOX) -> dict[str, Any]:
    """tableau.json tel qu'il est dans ``dropbox`` (``lire_catalogue`` : vide s'il manque ou ne se lit pas)."""
    try:
        return lire_catalogue((dropbox / CATALOGUE).read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError):
        return lire_catalogue(None)


def publier_ds(definition: Any, nom: str, classes: Iterable[str], publication: str | None = None,
               dropbox: Path = DROPBOX, parties: list[list] | None = None) -> dict[str, Any]:
    """Publie le DS papier ``nom`` (celui de son PDF et du dossier de ses copies corrigées, ``trier_scans.nom_du_sujet``)
    sur l'accueil de ses ``classes`` : son entrée sous « papier » de tableau.json, son nom seul, jamais son .qcm ni son
    sujet (SPEC W647, point 5) ; ``publication`` (« JJ/MM/AAAA HH:MM », heure de Paris, vide : pas de date) : quand ses
    copies corrigées deviennent visibles, None : celle déjà publiée. Les échéances ne la portent pas (consigne du
    Superviseur W647 : echeances.csv inchangé). ``parties`` (``pdf_qcm.parties_du_ds``) : les thèmes qu'il couvre et leur
    première page, [[thème, page], …], None : celles déjà publiées. Rend l'entrée écrite."""
    if publication is not None and publication.strip():
        date_de_paris(publication)  # ValueError si elle ne se lit pas : rien n'est écrit
    with verrou_catalogue(dropbox):  # lu, modifié, réécrit d'un bloc : un déploiement ne l'écrit pas entre-temps
        if (dropbox / CATALOGUE).exists() and not catalogue_du_disque(dropbox)["sujets"]:
            raise ValueError(f"{dropbox / CATALOGUE} illisible ou sans sujet : rien n'est écrit (il serait remplacé par un vide)")
        cat = catalogue_du_disque(dropbox)
        ancienne = cat[PAPIER].get(cle_de(nom), {})
        theme, sorte = theme_et_type(definition.dossier or "")
        entree = {"nom": nom, "dossier": codes.en_ligne(definition.dossier or ""), "theme": theme, "type": sorte or "DS",
                  "classes": sorted(classes), "cours": cours_du_sujet(definition),
                  "publication": (ancienne.get("publication", "") if publication is None else publication.strip())}
        if publication is None and ancienne.get(APRES_RATTRAPAGES) is True:  # une date posée l'efface (``regler_publication``)
            entree[APRES_RATTRAPAGES] = True
        if ancienne.get(NUMERIQUE):  # republié : il double toujours le même TP électronique, scannés relus
            entree[NUMERIQUE] = ancienne[NUMERIQUE]
            entree[SCANNES] = scannes_du_tp(dropbox / entree["dossier"] / nom)
        if any(pages := pages_du_sujet(definition)):
            entree["cours_pages"] = pages
        if entree["type"] == "DS" and (parties := ancienne.get(PARTIES) if parties is None else parties):  # pas un TP
            entree[PARTIES] = parties
        cat[PAPIER][cle_de(nom)] = entree
        _remplacer(dropbox / CATALOGUE, cat)
        return entree


APRES_RATTRAPAGES = "apres_rattrapages"  # dans une entrée « papier » : les corrigés attendent le scan des rattrapages
NUMERIQUE = "numerique"  # dans une entrée « papier » : le nom du TP électronique qu'elle double (``lier_numerique``, W906)
SCANNES = "scannes"  # dans une entrée « papier » : les ``empreinte_eleve`` des copies scannées (``scannes_du_tp``)
PARTIES = "parties"  # dans une entrée « papier » : [[thème, première page], …] des thèmes du DS (``pdf_qcm.parties_du_ds``)
DEVOIRS = "Devoirs surveillés"  # le bloc du bas : les DS papier entiers, après les thèmes qu'ils couvrent (``entrees``)


def empreinte_eleve(classe: str, eleve: str) -> str:
    """Ce que tableau.json publie d'un élève dont la copie papier est scannée : un condensé de sa classe et de son nom,
    que son lecteur recalcule ; ni nom, ni code de liste."""
    return hashlib.sha256(f"{cle_de(classe)}|{cle_de(eleve)}".encode()).hexdigest()[:12]


def scannes_du_tp(dossier: Path, listes: Path | None = None) -> list[str]:
    """Les ``empreinte_eleve`` des élèves dont une copie du TP papier rangé dans ``dossier`` (son dossier Dropbox local)
    est scannée : identifiée dans ``Scans/copie_<code anonyme>`` (``codes.code_eleve``), ou déjà corrigée
    (« <TP> [Nom Prénom].pdf » sous le dossier de sa classe). Une copie « inconnu » n'en donne aucun."""
    connus = {codes.code_eleve(l.stem, e[2]): (l.stem, f"{e[0]} {e[1]}")
              for l in sorted((listes or LISTES).glob("*.csv")) for e in codes.lire_liste(l) if len(e) > 2}
    eleves = {connus[d.name.removeprefix("copie_")] for d in (dossier / "Scans").glob("copie_*")
              if d.name.removeprefix("copie_") in connus}
    eleves |= {(pdf.parent.name, m.group(1)) for pdf in dossier.glob("*/*.pdf")
               if (m := re.search(r"\[([^\]]+)\]\.pdf$", pdf.name))}
    return sorted({empreinte_eleve(classe, nom) for classe, nom in eleves})
APRES_SCAN = "publiés après le scan des rattrapages"


def regler_publication(nom: str, publication: str, apres_rattrapages: bool = False,
                       dropbox: Path = DROPBOX) -> dict[str, Any]:
    """Le réglage de publication des corrigés du DS papier ``nom`` déjà sur l'accueil (son entrée « papier », posée par
    « Générer les sujets », ``publier_ds``), fait depuis la page de la classe, à côté des échéances (le professeur,
    19/11/2026, W792 : « là où je règle les échéances, je puisse aussi régler les publications ») : ``publication``
    (« JJ/MM/AAAA HH:MM », heure de Paris ; vide : pas de date), ou, sans date, ``apres_rattrapages`` : la date sera celle
    du scan des rattrapages (champ ``APRES_RATTRAPAGES``, que le scanner lira). Rien d'autre de l'entrée ne bouge ; un nom
    inconnu ou une date illisible : ValueError, rien d'écrit. Rend l'entrée écrite."""
    publication = publication.strip()
    if publication:
        date_de_paris(publication)
    with verrou_catalogue(dropbox):
        cat = catalogue_du_disque(dropbox)
        if not (ancienne := cat[PAPIER].get(cle_de(nom))):
            raise ValueError(f"« {nom} » n'est pas sur l'accueil : « Générer les sujets » du menu PDF l'y pose")
        entree = {k: v for k, v in ancienne.items() if k != APRES_RATTRAPAGES}
        entree["publication"] = publication
        if apres_rattrapages and not publication:
            entree[APRES_RATTRAPAGES] = True
        cat[PAPIER][cle_de(nom)] = entree
        _remplacer(dropbox / CATALOGUE, cat)
        return entree


def lier_numerique(nom: str, numerique: str, dropbox: Path = DROPBOX) -> dict[str, Any]:
    """Le TP papier ``nom`` déjà sur l'accueil (``publier_ds``) déclaré doublé par le TP électronique ``numerique`` (son
    nom ou son chemin ; vide : plus aucun) : là où la classe a une ligne d'échéance de ``numerique``, l'élève qui a une
    copie corrigée de ``nom`` la voit à la place du TP, les autres le TP (``Entree.corrige``). Le professeur, 22/11/2026
    (W906) : « pour tous les TP [...] papier, il faut aussi la version numérique mais qui ne s'affiche que si il n'y a
    pas de TP papier ». Un nom inconnu : ValueError, rien d'écrit. Rend l'entrée écrite."""
    with verrou_catalogue(dropbox):
        cat = catalogue_du_disque(dropbox)
        if not (ancienne := cat[PAPIER].get(cle_de(nom))):
            raise ValueError(f"« {nom} » n'est pas sur l'accueil : « Générer les sujets » du menu PDF l'y pose")
        entree = {k: v for k, v in ancienne.items() if k not in (NUMERIQUE, SCANNES)}
        if numerique.strip():
            entree[NUMERIQUE] = numerique.strip().replace("\\", "/").rpartition("/")[2]
            entree[SCANNES] = scannes_du_tp(dropbox / ancienne.get("dossier", "") / ancienne["nom"])
        cat[PAPIER][cle_de(nom)] = entree
        _remplacer(dropbox / CATALOGUE, cat)
        return entree


Publier = Callable[[str, str, bool, Callable[[dict[str, Any] | None, str], None]], None]
# ``publier(nom, publication, apres_rattrapages, rappel)`` : ``regler_publication``, puis ``rappel(catalogue, message)`` :
# tableau.json après coup (None : rien d'écrit) et ce qu'il en est dit en haut de la page


def publier_sur_disque(dropbox: Path = DROPBOX) -> Publier:
    """``Publier`` en natif : ``regler_publication`` dans le tableau.json de ``dropbox``."""
    def publier(nom: str, publication: str, apres_rattrapages: bool,
                rappel: Callable[[dict[str, Any] | None, str], None]) -> None:
        try:
            entree = regler_publication(nom, publication, apres_rattrapages, dropbox)
        except (OSError, ValueError) as erreur:
            rappel(None, f"Corrigés de « {nom} » : rien d'enregistré ({erreur})")
            return
        quand = (f"visibles à partir du {entree['publication']}" if entree["publication"] else
                 APRES_SCAN if entree.get(APRES_RATTRAPAGES) else "pas encore publiés")
        rappel(catalogue_du_disque(dropbox), f"Corrigés de « {nom} » : {quand}")
    return publier


@contextmanager
def verrou_catalogue(dropbox: Path) -> Iterator[None]:
    """Un seul écrivain de tableau.json à la fois sur cette machine (``publier_ds``, ``ecrire_catalogue``) : un verrou
    hors de Dropbox (qui le synchroniserait), propre au dossier ``dropbox``."""
    import fcntl  # noqa: PLC0415 - machine du professeur seulement
    marque = hashlib.sha1(str(Path(dropbox).resolve()).encode()).hexdigest()[:12]
    with open(Path(tempfile.gettempdir()) / f"smartteacher-tableau-{marque}.verrou", "w") as verrou:
        fcntl.flock(verrou, fcntl.LOCK_EX)
        yield


def _remplacer(chemin: Path, cat: dict[str, Any]) -> None:
    """``cat`` écrit à côté de ``chemin`` puis renommé sur lui : jamais un tableau.json à moitié écrit."""
    temporaire = chemin.with_name(f".{chemin.name}.tmp")
    temporaire.write_text(json.dumps(cat, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    temporaire.replace(chemin)


def ecrire_catalogue(cat: dict[str, Any], sortie: Path, dropbox: Path) -> None:
    """Le catalogue d'un déploiement (``catalogue``) écrit dans ``sortie`` : sous le verrou de ``publier_ds``, avec les DS
    papier tels qu'ils sont sur le disque à cet instant, et non lus au début du calcul (un « Publier » pendant le
    déploiement n'est pas perdu : W647, reste du TODO Lecteur, W715) ; renommé d'un bloc."""
    with verrou_catalogue(dropbox):
        cat = {**cat, PAPIER: catalogue_du_disque(dropbox)[PAPIER]}
        _remplacer(Path(sortie), cat)


def nom_de_fichier_court(nom: str) -> str:
    """Un nom de fichier temporaire tiré de ``nom`` : ses lettres seules, 40 au plus."""
    return cle_de(nom)[:40] or "ds"


def pdfs_de_l_eleve(dossier: str, sujet: str, classe: str, eleve: str, extension: str = ".pdf") -> list[str]:
    """Les places possibles dans Dropbox du PDF corrigé de ``eleve`` (« Nom Prénom », celui de la page) pour le sujet
    ``sujet`` rangé dans ``dossier`` : ``<dossier>/<sujet>/<classe>/<sujet> [<élève>].pdf``, puis sans dossier de classe
    (DS de Première et de Terminale), comme ``codes.chemin_copie`` les nomme (``copie_papier.chemin_du_pdf``). Rien que
    l'identité de l'élève entré : aucun autre nom, aucun code de sujet. ``extension`` « .qcm » : sa copie électronique, que
    le lecteur web dépose au même nom (``pont_qt.chemin_distant``), pour la vue élève du professeur (``Portail.voir_comme``)."""
    if not (dossier.strip("/") and sujet and eleve.strip()):
        return []
    # ``chemin_copie`` ne regarde des inscrits que leur nombre : deux, le dossier de la classe ; un, sans
    plusieurs, une = (classe, ""), (classe,)
    racine = dossier.strip("/")
    try:  # le niveau en tête est celui de la classe, comme ``codes.chemin_copie`` range les copies (sujet de Première
        racine = "/".join([codes.niveau(classe), *racine.split("/")[1:]]) if classe.strip() else racine  # donné en Terminale)
    except ValueError:
        pass  # nom de classe illisible : le dossier du sujet
    return [f"{racine}/{codes.chemin_copie(inscrits, classe, sujet, eleve.strip()).removesuffix('.qcm')}{extension}"
            for inscrits in ((plusieurs, une) if classe.strip() else (une,))]


@dataclass
class Entree:
    """Une ligne du tableau : ce que le bouton ouvre (``lien`` vide : rien, pas encore déposé ou à venir), et le code que le
    bouton lui passe pour l'élève de cette classe (``jeton``), qui n'a ainsi aucun code à taper."""
    ligne: Ligne
    etat: str
    lien: str
    nom: str
    jeton: str = ""
    theme: str = ""  # sa section sur la page (``theme_et_type``)
    type: str = AUTRES
    cours: tuple[tuple[str, str, str], ...] = ()  # ses cours : (PDF dans Dropbox, titre, PDF du diaporama ou ""), section « Cours »
    # un DS papier (« papier » de tableau.json, ``publier_ds``) : sans lien, le dossier Dropbox de ses copies corrigées, la
    # date à partir de laquelle elles se montrent (None : pas de date), et si elle est atteinte
    papier: bool = False
    dossier: str = ""
    publication: datetime | None = None
    publiee: bool = False
    apres_rattrapages: bool = False  # sans date : ses corrigés se publient au scan des rattrapages (``regler_publication``)
    cours_pages: tuple[int | None, ...] = ()  # une limite par cours (``pages_lues``), vide : aucune
    diaporama_pages: tuple[tuple[int, ...], ...] = ()  # par cours, ``diaporama_par_page`` (``diaporamas_lus``)
    lien_au_debut: str = ""  # à venir : ce que le bouton ouvrira à son début (``Tableau._battre``), ``lien`` restant vide
    section: tuple[str, ...] = ()  # un « Réviser » : la section pressée, seule à composer le questionnaire (``lecteur.Accueil.section``, W754)
    essai: int = 0  # un « Réviser » rouvert par son historique : cette série-là, telle quelle (``Tableau.historique``, W811) ; 0 : la courante
    # un TP électronique que la classe a aussi fait sur papier (``NUMERIQUE``) : l'entrée papier, qui le remplace pour
    # l'élève dont la copie est scannée (``scanne``) ; le professeur voit les deux sur une ligne coupée en deux (W906)
    corrige: Entree | None = None
    scannes: frozenset[str] = frozenset()  # une entrée papier : les ``empreinte_eleve`` de ceux dont la copie est scannée
    page: int = 1  # un DS papier redit dans un thème qu'il couvre (``PARTIES``) : la page de sa copie où ce thème commence

    def scanne(self, eleve: str) -> bool:
        """Vrai si l'élève ``eleve`` (« Nom Prénom ») de la classe de ce TP électronique a rendu sa copie papier : elle est
        scannée, corrigée ou pas encore (le professeur, 22/11/2026 02:04, W906 : « c'est l'absence de TP scanné qui doit
        déclencher la présence du TP numérique pour un élève »)."""
        return bool(self.corrige and eleve.strip()
                    and empreinte_eleve(self.ligne.classe, eleve) in self.corrige.scannes)

    def dossier_des_copies(self) -> str:
        """Le dossier Dropbox où sont rangées les copies corrigées : celui du DS papier, celui du .qcm d'un TP."""
        return self.dossier if self.papier else self.lien.rpartition("/")[0]


def finie(copie: dict[str, Any] | None) -> bool:
    """Une copie du bilan finie : rendue (``fin``) ou toutes ses questions closes (``terminee``)."""
    return bool(copie) and (copie.get("fin") is not None or bool(copie.get("terminee")))


def instant_de(e: Entree) -> float:
    """L'instant qui range un sujet (``entrees``, cadres de « À faire ») : son échéance, sinon son début ; aucun : à la fin."""
    date = e.ligne.echeance or e.ligne.debut
    return date.timestamp() if date else float("inf")


def entrees(lignes: list[Ligne], cat: dict[str, Any], classe: str, maintenant: datetime,
            jetons: dict[str, str] | None = None) -> list[Entree]:
    """Les lignes de ``classe``, dans l'ordre des ``ETATS``, puis par échéance la plus proche (la plus récente d'abord pour
    les fermés) ; puis, fermés, les DS papier publiés pour elle (« papier » de tableau.json) qu'aucune ligne ne nomme."""
    resultat, corriges = [], {}
    nommes = {cle_de(ligne.sujet) for ligne in lignes if meme_classe(ligne.classe, classe)}
    for cle, ds in (cat.get(PAPIER) if isinstance(cat.get(PAPIER), dict) else {}).items():
        siennes = [c for c in ds.get("classes", ()) if isinstance(c, str) and meme_classe(c, classe)] if isinstance(ds, dict) else []
        if not siennes:
            continue
        # le TP électronique de la classe qu'il double : le même nom, sinon celui que nomme ``NUMERIQUE`` (W906)
        cible = cle if cle in nommes else cle_de(str(ds.get(NUMERIQUE) or ""))
        try:
            date = date_de_paris(str(ds.get("publication") or ""))
        except ValueError:
            date = None  # une date illisible : pas encore publiée
        nom = str(ds.get("nom") or cle)
        theme, sorte = (ds["theme"], ds.get("type") or "DS") if ds.get("theme") else theme_du_nom(nom)
        cours = tuple((str(c[0]), str(c[1]), str(c[2]) if len(c) == 3 else "")
                      for c in ds.get("cours", ()) if len(c) in (2, 3))
        papier = (Entree(Ligne(nom, siennes[0], None, None, None), FERME, "", nom, "", theme, sorte, cours,
                               papier=True, dossier=str(ds.get("dossier") or ""), publication=date,
                               publiee=date is not None and date <= maintenant,
                               apres_rattrapages=date is None and ds.get(APRES_RATTRAPAGES) is True,
                               cours_pages=pages_lues(ds.get("cours_pages"), len(cours)),
                               scannes=frozenset(str(x) for x in ds.get(SCANNES) or () if isinstance(x, str))))
        if cible in nommes:
            corriges[cible] = papier
        elif sorte == "DS" and (parties := [(str(p[0]), int(p[1])) for p in ds.get(PARTIES) or () if len(p) == 2 and p[0]]):
            # un DS dans chaque thème qu'il couvre, ouvert à la page du thème, et entier en bas, sous « Devoirs surveillés »
            # (le professeur, 22/11/2026, W916, [APE-20] : « on ne peux pas spliter le DS dans ces thème , en plus d'une
            # section DS en bas ? », « afficher tout le sujet, mais juste de sauter sur la page du thème , si ce n'est pas
            # le premier »)
            resultat += [replace(papier, theme=theme_du_ds, page=page) for theme_du_ds, page in parties]
            resultat.append(replace(papier, theme=DEVOIRS))
        else:
            resultat.append(papier)
    for ligne in lignes:
        if not meme_classe(ligne.classe, classe):
            continue
        cle, connu = du_catalogue(cat["sujets"], ligne.sujet)
        nom = connu.get("nom", ligne.sujet.rpartition("/")[2])
        theme, sorte = (connu["theme"], connu.get("type", AUTRES)) if connu.get("theme") else theme_du_nom(nom)
        if ligne.echeance is None and not ligne.sans_echeance and TYPES.get(sorte, sorte) == REVISER:  # révision d'un DS : close à la publication de ses
            # copies corrigées (``echeances.publication_du_ds``, le professeur 17/11/2026) ; sans publication, sans échéance
            if publiee := echeances.publication_du_ds(nom, ligne.classe, cat.get(PAPIER) or {}, meme_classe):
                ligne = replace(ligne, echeance=publiee)
        etat = ligne.etat(maintenant)
        cours = tuple((str(c[0]), str(c[1]), str(c[2]) if len(c) == 3 else "")
                      for c in connu.get("cours", ()) if len(c) in (2, 3))  # 2 : avant les diaporamas
        resultat.append(Entree(ligne, etat, "" if etat == A_VENIR else connu.get("lien", ""), nom,
                               (jetons or {}).get(cle, ""), theme, sorte, cours,
                               cours_pages=pages_lues(connu.get("cours_pages"), len(cours)),
                               diaporama_pages=diaporamas_lus(connu.get("diaporama_pages"), len(cours)),
                               lien_au_debut=connu.get("lien", "") if etat == A_VENIR else "",
                               corrige=corriges.get(cle_de(ligne.sujet))))
    def rang(e: Entree) -> tuple[int, float]:
        return ETATS.index(e.etat), -instant_de(e) if e.etat == FERME else instant_de(e)

    return sorted(resultat, key=rang)


def sans_bouton(cat: dict[str, Any], texte: str, maintenant: datetime, listes: Path = LISTES) -> list[str]:
    """Les lignes d'echeances.csv (``texte``) pas encore fermées qu'une classe voit sans bouton : aucun .qcm déposé du
    catalogue ``cat`` ne répond à leur sujet (.qcm retiré, pas encore déposé). Le déploiement les DIT (``catalogue``), sans
    rien décider : le TP12 de Première et le TP01 V2 de la SECONDE 5 étaient « À finir » sans bouton, et personne ne le
    savait avant les élèves [PAC-8]."""
    lignes = lire_echeances(texte)[0]
    return [f"{classe} | {e.etat} | {e.ligne.sujet} | échéance {e.ligne.echeance}" for classe in classes_connues(listes, texte)
            for e in entrees(lignes, cat, classe, maintenant) if e.etat != FERME and not (e.papier or e.lien or e.lien_au_debut)]


def ranger(liste: list[Entree]) -> list[tuple[str, list[tuple[str, list[Entree]]]]]:
    """Les entrées par thème (ordre alphabétique), puis par type dans l'ordre des ``TYPES`` (les autres après, par nom),
    puis par numéro (« TP08 » avant « TP10 », celui du deuxième morceau du nom), à égalité par nom."""
    def numero(e: Entree) -> tuple[int, str]:
        morceaux = e.nom.split(" - ")
        chiffres = re.search(r"\d+", morceaux[1]) if len(morceaux) > 1 else None
        return int(chiffres.group()) if chiffres else 10**6, e.nom.casefold()

    ordre = list(dict.fromkeys(TYPES.values()))
    themes: dict[str, dict[str, list[Entree]]] = {}
    for e in liste:  # par sous-section : DS et mini-interrogations ensemble, « Interrogations » ; sous « Devoirs
        # surveillés », aucune : son titre le dit
        themes.setdefault(e.theme, {}).setdefault("" if e.theme == DEVOIRS else TYPES.get(e.type, e.type), []).append(e)
    return [(theme, [(sorte, sorted(groupe, key=numero)) for sorte, groupe in
                     sorted(sections.items(), key=lambda s: (ordre.index(s[0]) if s[0] in ordre else len(ordre), s[0]))])
            for theme, sections in sorted(themes.items(), key=lambda t: (t[0] == DEVOIRS, not t[0], t[0].casefold()))]


def a_paris(date: datetime | None) -> str:
    """Une date UTC dite à l'heure de Paris, « mar. 10/11 à 10 h 00 »."""
    if date is None:
        return ""
    locale = date + timedelta(minutes=codes._decalage_paris(codes._minutes(date)))
    jours = ("lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim.")
    return f"{jours[locale.weekday()]} {locale:%d/%m} à {locale:%H} h {locale:%M}"


def quand(e: Entree) -> str:
    """Ce que l'élève doit savoir de la date : quand ça commence, ou jusqu'à quand il a."""
    if e.etat == A_VENIR:
        return f"commence le {a_paris(e.ligne.debut)}" if e.ligne.debut else ""
    if e.etat == FERME:
        return f"fermé depuis le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else ""
    return f"à rendre avant le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else ""


def en_bref(e: Entree) -> str:
    """La partie grise d'un sujet, au professeur seul : ce que ses réglages disent, sans ouvrir la molette (le professeur,
    17/11/2026 00:22, guichet W721 : « la partie grise du bouton du sujet s'enrichit pour le professeur seul (fin de
    séance, à rendre, rattrapage…) »)."""
    parties = [f"commence le {a_paris(e.ligne.debut)}" if e.etat == A_VENIR and e.ligne.debut else "",
               f"fin de séance {a_paris(e.ligne.fin_creneau)}" if e.ligne.fin_creneau else "",
               quand(e) if e.etat != A_VENIR else f"à rendre avant le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else "",
               "" if e.ligne.echeance else SANS_ECHEANCE,
               f"rattrapage jusqu'au {a_paris(e.ligne.echeance_tardive)}" if e.ligne.echeance_tardive else "",
               {True: MAISONS["oui"], False: MAISONS["non"], None: ""}[e.ligne.maison]]
    return " · ".join(filter(None, parties))


# un sujet à venir : caché jusqu'à 30 min avant son début, en gris avec un décompte pendant ces 30 min, cliquable au début
# (le professeur, 17/11/2026 00:32 : « pour qu'en début de cours on ne le croie pas absent, sans polluer l'interface trop tôt »)
APPARITION = timedelta(minutes=30)


def apparition(e: Entree) -> datetime | None:
    """L'instant où un sujet à venir paraît sur la page de l'élève ; ``None`` s'il n'est pas à venir."""
    return e.ligne.debut - APPARITION if e.etat == A_VENIR and e.ligne.debut else None


def decompte(reste: timedelta) -> str:
    """La partie grise d'un sujet sur le point de commencer : « commence dans 12 min 05 s »."""
    minutes, secondes = divmod(max(0, math.ceil(reste.total_seconds())), 60)
    return f"commence dans {minutes} min {secondes:02d} s"


# Le cadre bleu « Réviser » (le professeur, 17/11/2026 00:26 et 00:29, guichet W721) : les révisions du thème Python, l'essentiel
# du langage, y restent toute l'année ; celles d'un autre thème en sortent, et perdent leur bord bleu dans le thème, une fois
# qu'un DS ou une vraie interrogation (pas une mini-interrogation) du thème a eu lieu, et y reviennent quand un nouveau est prévu
THEME_DE_TOUTE_L_ANNEE = "Python"
EVALUATIONS = ("DS", "Interrogations")


def themes_evalues(liste: list[Entree]) -> set[str]:
    """Les thèmes dont les révisions sortent du cadre bleu : un DS ou une interrogation y a eu lieu (commencé, fermé, ou DS
    papier), aucun n'y est à venir ; jamais ``THEME_DE_TOUTE_L_ANNEE``."""
    passes, prevus = set(), set()
    for e in liste:
        if e.type in EVALUATIONS:
            (prevus if e.etat == A_VENIR else passes).add(e.theme)
    return {t for t in passes - prevus if t.casefold() != THEME_DE_TOUTE_L_ANNEE.casefold()}


# Une épreuve électronique pendant sa séance : l'accueil ne s'affiche plus, elle s'ouvre d'emblée, sans cours ni retour en
# arrière (le professeur, 17/11/2026 00:34 et 00:39, guichet W721) ; ``Portail.montrer_tableau``
EPREUVES = (*EVALUATIONS, "Mini-Interrogations")
# l'épreuve en séance dont le .qcm n'est pas dans le dossier Dropbox (``Portail.sujet_depose``, IP-1)
SUJET_ABSENT = "« {} » n'est pas encore disponible : préviens ton professeur."


def en_seance(e: Entree, instant: datetime) -> bool:
    """``e`` est une épreuve électronique dont la séance est en cours à ``instant`` : de son début à sa fin de créneau (sans
    elle, à son échéance) ; sans début ni l'une de ces fins, ce n'est pas une séance."""
    fin = e.ligne.fin_creneau or e.ligne.echeance if e.ligne else None
    return (e.type in EPREUVES and not e.papier and bool(e.lien) and bool(e.ligne.debut) and fin is not None
            and e.ligne.debut <= instant < fin)


def avant_seance(e: Entree, instant: datetime) -> bool:
    """``e`` est une épreuve qui sera ``en_seance`` à son début, dans moins d'``APPARITION`` : l'élève attend devant
    ``AttenteEpreuve`` plutôt que devant la page, d'où il irait chercher le cours (le professeur, 17/11/2026 00:34)."""
    debut = e.ligne.debut if e.ligne else None
    fin = e.ligne.fin_creneau or e.ligne.echeance if e.ligne else None
    return (e.type in EPREUVES and not e.papier and bool(e.lien or e.lien_au_debut) and debut is not None
            and fin is not None and debut - APPARITION <= instant < debut < fin)


# ce que dit l'écran d'attente, par type d'épreuve (``AttenteEpreuve``)
QUI_COMMENCE = {"DS": "Le DS", "Mini-Interrogations": "La mini-interrogation", "Interrogations": "L'interrogation"}
# les règles que l'écran rappelle avant « Commencer » (le professeur, 20/11/2026 12:57-13:05, W826 : « ces detecteur font
# un rapport au professeur uniquemnt » ; le détecteur n'existe pas encore, « on va bluffer », TODO Lecteur)
REGLES_EPREUVE = (
    "<b>Avant de commencer</b><ul>"
    "<li>« Commencer » passe l'épreuve en plein écran et lance le chronomètre, qui ne s'arrête plus, même si vous "
    "fermez la page. Ne cliquez que si vous êtes prêt.</li>"
    "<li>Anti-triche : quitter le plein écran, changer d'onglet ou d'application noircit l'écran, et chaque sortie est "
    "inscrite dans votre copie.</li>"
    "<li>Interdits : le cours, vos notes, Internet et toute intelligence artificielle.</li>"
    "<li>Un détecteur de comportement suspect repère l'usage de l'IA et du cours ; il fait un rapport au professeur "
    "uniquement.</li></ul>")


PAS_PUBLIEE = "copie corrigée pas encore publiée"  # la ligne grise d'un DS papier grisé (SPEC W647, point 4)


def etat_de_copie(e: Entree, professeur: bool = False) -> str:
    """La ligne grise d'un DS papier : à l'élève, ``PAS_PUBLIEE`` (la date, si elle est à venir) tant que sa copie
    corrigée n'est pas trouvée ; au professeur, la date de publication des corrigés."""
    if professeur:
        return (f"corrigés visibles depuis le {a_paris(e.publication)}" if e.publiee else
                f"corrigés visibles à partir du {a_paris(e.publication)}" if e.publication else
                f"corrigés {APRES_SCAN}" if e.apres_rattrapages else "corrigés pas encore publiés")
    return f"{PAS_PUBLIEE} (le {a_paris(e.publication)})" if e.publication and not e.publiee else PAS_PUBLIEE


NIVEAUX = {"2": "Seconde", "1": "Première", "t": "Terminale"}  # le dossier du niveau d'une classe, faute de sujet déposé
LOGO_APPLI = Path(__file__).parent / "associations" / "teacher.svg"  # l'icône des fenêtres du lecteur, embarquée en ligne


def niveau_de(classe: str, liste: list[Entree]) -> str:
    """Le dossier du niveau de la classe dans Dropbox, où sont ses « Bilans » : celui de ses sujets déposés, sinon tiré du
    nom de la classe, celui de sa liste (« SECONDE 5 », « B3_P_NSINF_GR1 » : ``codes.niveau``), sinon de sa première
    lettre (« 2nd 5 » → Seconde, « 1G2 » → Première, « TG1 » → Terminale) ; vide s'il ne se devine pas."""
    dossiers = [e.lien.split("/", 1)[0] for e in liste if "/" in e.lien]
    if dossiers:
        return max(set(dossiers), key=dossiers.count)
    try:
        return codes.niveau(classe)
    except ValueError:
        return NIVEAUX.get(classe.strip().lower()[:1], "")


def matiere_de(niveau: str) -> str:
    """La matière d'un niveau de Dropbox (« Seconde » → SNT, « Première », « Terminale » → NSI), lue dans ``codes.EN_LIGNE`` ;
    vide pour un niveau inconnu. Elle se montre entre SmartTeacher et la classe (le professeur, notes du 16/11/2026 :
    « entre SmartTeacher et la classe, il faut mettre la matière : "SNT" »)."""
    return next((matiere.split("/")[0] for matiere, n in codes.EN_LIGNE.items() if n == niveau), "")


def titre_de_page(classe: str, niveau: str) -> str:
    """« SNT · SECONDE 4 » : la matière du niveau, s'il en a une, puis la classe, échappées pour un QLabel."""
    return " &nbsp;·&nbsp; ".join(escape(m) for m in (matiere_de(niveau), classe) if m)


MARGES_TITRE = (10, 6, 10, 6)  # autour du texte d'un titre, qu'on puisse le presser ou non
# le titre d'un sujet ou d'un cours : le texte d'un sujet (``modele.TAILLE_POLICE``), sur toute la largeur de la page (le
# professeur, 21/11/2026, [COS-1] : « les bouton de sujets ne doivent pas arreter de s'agrandir quand on elargit la page »,
# qui renverse les 900 px au plus de W529)


def police_de_titre(widget: QWidget) -> None:
    """La police d'un titre de sujet ou de cours sur ``widget`` : celle du texte d'un sujet."""
    police = widget.font()
    police.setPointSize(modele.TAILLE_POLICE)
    widget.setFont(police)


class Cours(QWidget):
    """Un PDF de cours ouvert depuis la page (``Tableau._cours_du_theme``), page entière à la largeur de la fenêtre, en
    plein écran, la maison de la copie posée dessus en haut à gauche (``accueil``) ; ``octets`` None : « introuvable », à la place du document. ``copie`` (titre,
    octets) : la copie corrigée de l'élève, à droite du cours (SPEC W647, point 3), dans ``vue`` et ``document`` ; le
    cours, à gauche, dans ``vue_cours`` et ``document_cours`` (le cours introuvable : la copie seule). ``pages`` : le cours
    jusqu'à cette page seulement (``Tableau.pages_vues``), None : entier ; jamais la copie."""

    def __init__(self, titre: str, octets: bytes | None, copie: tuple[str, bytes] | None = None,
                 pages: int | None = None, page_copie: int = 1) -> None:
        super().__init__()
        self.setWindowTitle(titre)
        couche = QVBoxLayout(self)
        couche.setContentsMargins(0, 0, 0, 0)
        couche.setSpacing(0)
        # montrée en plein écran (``Tableau.ouvrir_cours``) : sans cadre, la maison de la copie (``modele.bouton_accueil``),
        # posée sur le PDF en haut à gauche, et Échap la referment (L-34, le professeur, 19/11/2026, W811 : « juste un bouton
        # Home plutôt que fermé qui soit aussi en haut à gauche », « éviter de faire une nouvelle ligne », « en
        # surimpression sur le PDF toujours ») ; placée et remontée au-dessus du PDF à chaque taille (``resizeEvent``)
        feuille_de_page(self)
        self.accueil = modele.bouton_accueil(self)
        self.accueil.setStyleSheet("QPushButton { background: rgba(255, 255, 255, 210); border: 1px solid #b0b0b0; "
                                   "border-radius: 6px; padding: 4px; }")
        self.accueil.clicked.connect(self.close)
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self, self.close)
        # les flèches tournent les pages une à une, sans boucler (L-35, le professeur, 19/11/2026, W811 : « pouvoir avoir
        # les flèches gauche droite ou haut bas pour passer à la slide précédente et suivante »)
        for touches, pas in (((Qt.Key.Key_Left, Qt.Key.Key_Up), -1), ((Qt.Key.Key_Right, Qt.Key.Key_Down), 1)):
            for touche in touches:
                QShortcut(QKeySequence(touche), self, lambda pas=pas: self.tourner(pas))
        if copie is not None:
            self.setWindowTitle(copie[0])
            from qtpy6.QtWidgets import QSplitter  # noqa: PLC0415
            cote = QSplitter(Qt.Orientation.Horizontal)  # cours à gauche, copie à droite, la séparation se déplace
            couche.addWidget(cote)
            if octets is not None:
                self.vue_cours, self.document_cours = self._pdf(cote, octets)
                self.vue_cours.setPageLimit(pages)  # pas au-delà des pages déjà vues (qtpy6, comme le lecteur)
            self.vue, self.document = self._pdf(cote, copie[1])
            # un DS ouvert depuis un thème : à la page du thème (``Entree.page``), une fois la fenêtre à sa taille (avant,
            # la mise en page refaite à l'affichage déplace la vue : page 3 au lieu de 4, sonde W916)
            self.page_copie = page_copie - 1 if 1 < page_copie <= self.document.pageCount() else None
            return
        if octets is None:
            couche.addWidget(QLabel(f"Le cours « {escape(titre)} » est introuvable pour l'instant.",
                                    alignment=Qt.AlignmentFlag.AlignCenter, wordWrap=True))
            return
        self.vue, self.document = self._pdf(couche, octets)
        self.vue.setPageLimit(pages)

    def resizeEvent(self, evenement) -> None:
        super().resizeEvent(evenement)
        self.accueil.adjustSize()
        self.accueil.move(8, 8)
        self.accueil.raise_()

    def showEvent(self, evenement) -> None:
        """Montrée, la copie va à sa ``page_copie`` (une seule fois, après la mise en page de l'affichage)."""
        super().showEvent(evenement)
        if getattr(self, "page_copie", None) is not None:
            QTimer.singleShot(0, self._sauter)

    def _sauter(self) -> None:
        if (page := getattr(self, "page_copie", None)) is not None:
            self.page_copie = None
            navigateur = self.vue.pageNavigator()
            navigateur.jump(page, QPointF(), navigateur.currentZoom())

    def tourner(self, pas: int) -> None:
        """La page ``pas`` plus loin (-1 : la précédente) en haut de la vue qui a le clavier, le cours sinon ; rien avant
        la première page ni après la dernière montrée (``setPageLimit``)."""
        vues = [v for v in (getattr(self, "vue_cours", None), getattr(self, "vue", None)) if v is not None]
        if not vues:
            return
        vue = next((v for v in vues if v.hasFocus()), vues[0])
        fin, limite = vue.document().pageCount(), vue.pageLimit()
        if limite is not None:
            fin = min(fin, limite)
        navigateur = vue.pageNavigator()
        page = navigateur.currentPage() + pas
        if 0 <= page < fin:
            navigateur.jump(page, QPointF(), navigateur.currentZoom())

    def _pdf(self, dans: QVBoxLayout | QWidget, octets: bytes) -> tuple[QWidget, Any]:
        """Une vue du PDF ``octets`` ajoutée à ``dans`` (une couche ou un QSplitter), page entière à la largeur, et son
        document."""
        from qtpy6.QtCore import QBuffer, QByteArray, QMargins  # noqa: PLC0415
        from qtpy6.QtPdf import QPdfDocument  # noqa: PLC0415 - chargé seulement quand un cours s'ouvre
        from qtpy6.QtPdfWidgets import QPdfView  # noqa: PLC0415
        vue = QPdfView()
        vue.setPageMode(QPdfView.PageMode.MultiPage)
        vue.setZoomMode(QPdfView.ZoomMode.FitToWidth)
        vue.setDocumentMargins(QMargins())
        dans.addWidget(vue)  # enfant avant le document : détruite avant lui (voir la vue du cours de modele.py)
        document = QPdfDocument(self)
        tampon = QBuffer(document)  # lu au fil des pages : il vit aussi longtemps que le document, son parent
        tampon.setData(QByteArray(octets))
        tampon.open(QBuffer.OpenModeFlag.ReadOnly)
        document.load(tampon)
        vue.setDocument(document)
        return vue, document


# Où va la contestation d'une note papier (``lier_notes``) : ``(chemin, texte, envoyee)``, ``envoyee()`` appelée au
# seul succès, le chemin Dropbox
# « <sujet> [<élève>].contestations.json » (``codes.CONTESTATIONS``), à ne jamais écraser ; posé par la page
# (``web/pyqt6/pont_tableau.py``, route ``contestation`` de dropbox.js) ou par le portail du bureau (``deposer_sur_disque``).
DEPOSER_CONTESTATION: Callable[[str, str, Callable[[], None]], None] | None = None


def deposer_sur_disque(dossier: Path) -> Callable[[str, str, Callable[[], None]], None]:
    """Le ``DEPOSER_CONTESTATION`` du portail du bureau : le fichier écrit sous ``dossier`` (le Dropbox du professeur),
    « ….contestations (2).json » plutôt qu'écraser, comme la route ``contestation`` de dropbox.js (``autorename``) dans la page."""
    def deposer(chemin: str, texte: str, envoyee: Callable[[], None]) -> None:
        cible, n = dossier / chemin, 1
        while cible.exists():
            n += 1
            cible = dossier / f"{chemin.removesuffix('.json')} ({n}).json"
        try:
            cible.write_text(texte, encoding="utf-8")
        except OSError as erreur:  # le disque refuse : la contestation repartira avec la suivante
            print(f"contestation non déposée ({erreur})", file=sys.stderr)
            return
        envoyee()
    return deposer


def lier_notes(cours: "Cours", octets: bytes, cle: str | None, chemin: str | None, contester: bool = True) -> "Cours":
    """La vue de la copie corrigée de ``cours`` (``Cours.vue``), ses notes manuscrites rendues cliquables comme dans le
    lecteur (``modele.lier_notes_du_pdf`` : barème expliqué, « Contester cette note ») depuis la copie que le PDF ``octets``
    joint pour l'élève (``codes.PIECE_ELEVE``, chiffrée par ``cle``, la clé de sa classe que porte l'adresse du tableau :
    ``correction/copie_eleve.py``, W806). Rien sans elle, sans clé ou si elle ne s'ouvre pas : le PDF reste lisible tel quel. Une
    contestation part à ``DEPOSER_CONTESTATION``, à côté du PDF ``chemin`` (W763, le professeur, 17/11/2026 : « je ne vois
    pas ce qui empêcherait d'y rajouter les contestations »). ``contester`` faux (la vue élève du professeur, W814) : rien
    ne part."""
    piece = codes.piece_eleve(octets)
    if not (piece and cle and getattr(cours, "vue", None)):
        return cours
    with tempfile.TemporaryDirectory() as dossier:
        (copie := Path(dossier) / codes.PIECE_ELEVE).write_bytes(piece)
        try:
            paquet = modele.charger(copie, cle)
        except Exception:  # noqa: BLE001 - une autre clé (pièce d'avant le 19/11, autre classe) ou abîmée : le PDF seul
            return cours
    modele.lier_notes_du_pdf(cours.vue, paquet)
    cours.paquet = paquet  # gardé en vie avec la fenêtre : les liens de ses notes le visent
    if contester and chemin and chemin.endswith(".pdf"):
        cible = chemin[:-4] + codes.CONTESTATIONS
        def tous() -> list[dict[str, Any]]:
            return [{"question": q.id, **s} for q in paquet.feuilles for s in q.signalements]
        envoyes = {json.dumps(n, sort_keys=True, default=str) for n in tous()}  # ceux d'avant : déjà chez le professeur

        def envoyer() -> None:
            neufs = [n for n in tous() if json.dumps(n, sort_keys=True, default=str) not in envoyes]
            if neufs and DEPOSER_CONTESTATION:  # marquées envoyées au seul succès : un échec repart avec la suivante
                DEPOSER_CONTESTATION(cible, json.dumps(neufs, ensure_ascii=False, indent=1, default=str),
                                     lambda: envoyes.update(json.dumps(n, sort_keys=True, default=str) for n in neufs))
        for q in paquet.feuilles:
            q.changee.connect(envoyer)
    return cours


HAUTEUR_JAUGE = 5  # px : les jauges d'avancement sous le titre d'un TP (``TitreBouton.poser_jauges``)
ECART_BONUS = 6  # px : entre la jauge de l'obligatoire et celle des bonus ([APE-17])
TAILLE_BONUS = 10  # px : le mot « bonus » au-dessus de sa jauge ([APE-17])


class TitreBouton(QPushButton):
    """Le titre d'un sujet, qu'on presse pour l'ouvrir (l'utilisateur, 03/11/2026 : « que les titres de la liste soient
    directement des boutons »). Un QPushButton ne sait ni le texte riche ni le retour à la ligne : un QLabel dedans les porte,
    et laisse passer la souris ; c'est sa couche qui donne la hauteur, selon la largeur."""

    def __init__(self, texte: QLabel, nom: str) -> None:
        super().__init__()
        self.titre = texte
        police_de_titre(texte)
        texte.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        couche = QVBoxLayout(self)
        couche.setContentsMargins(*MARGES_TITRE)
        couche.addWidget(texte)
        self.setAccessibleName(nom)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)

    def loger(self, coin: QToolButton) -> None:
        """``coin`` (la molette des réglages) dans le bouton, tout à droite de sa première ligne, à la hauteur d'une ligne
        de texte ([COS-2]) : posée par-dessus, hors de la couche, elle ne réserve sa place que sur la première ligne
        (``TitreDeSujet.reserve``) ; la ligne grise passée dessous garde toute la largeur."""
        cote = QFontMetrics(self.titre.font()).height()
        coin.setParent(self)
        coin.setFixedSize(cote, cote)
        coin.setIconSize(QSize(cote - 2, cote - 2))
        self.coin = coin
        if isinstance(self.titre, TitreDeSujet):
            self.titre.reserve = cote + ECART_GRIS
            self.titre._choisir(self.titre.width())
        else:
            self.titre.setContentsMargins(0, 0, cote + ECART_GRIS, 0)
        self._placer_coin()

    def _placer_coin(self) -> None:
        if coin := getattr(self, "coin", None):
            gauche, haut, droite, _ = MARGES_TITRE
            coin.move(self.width() - droite - coin.width(), haut)

    def resizeEvent(self, evenement) -> None:
        super().resizeEvent(evenement)
        self._placer_coin()

    def poser_jauges(self, avancements: dict[str, list[int]]) -> None:
        """Sous le titre, les jauges du lecteur aplaties, sans texte : vert l'obligatoire, or les bonus, chacune large comme
        sa part des questions (``noyau.Paquet.avancements``, lu par le bilan ; le professeur, 20/11/2026, W826 : « la meme
        jauge que que dans le player , mais beaucoup plus plat ») ; posées une fois, mises à jour au bilan suivant, refaites
        si leurs jauges changent (la jauge vide d'un TP pas commencé, [APE-15], puis celles de sa copie). La jauge bonus,
        écartée de l'autre, porte « bonus » juste au-dessus (le professeur, 22/11/2026, [APE-17] : « quand il y a une jauge
        "bonus" ilfaut ecarter un peu les deux jauge et ecrire "bonus" juste au dessus de la jauge »)."""
        jauges = getattr(self, "jauges", None)
        if jauges is None or jauges.keys() != {c for c in ("obligatoire", "bonus") if c in avancements}:
            self.retirer_jauges()
            self.jauges = jauges = {}
            self._widgets_de_jauges: list[QWidget] = []
            self.rangee = rangee = QHBoxLayout()
            rangee.setSpacing(ECART_BONUS)
            for cle, couleur in (("obligatoire", "vert"), ("bonus", "or")):
                if cle in avancements:
                    jauges[cle] = b = modele.barre("", couleur)
                    b.setTextVisible(False)
                    b.setFixedHeight(HAUTEUR_JAUGE)
                    b.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
                    colonne = QVBoxLayout()
                    colonne.setSpacing(0)
                    colonne.addStretch(1)  # les deux jauges sur la même ligne, en bas
                    if cle == "bonus":
                        mot = QLabel("bonus")
                        mot.setStyleSheet(f"color:#606060; font-size:{TAILLE_BONUS}px")
                        mot.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
                        colonne.addWidget(mot, 0, Qt.AlignmentFlag.AlignLeft)
                        self._widgets_de_jauges.append(mot)
                    colonne.addWidget(b)
                    self._widgets_de_jauges.append(b)
                    rangee.addLayout(colonne, avancements[cle][1])
            self.layout().addLayout(rangee)
        for cle, b in jauges.items():
            if cle in avancements:
                b.setValue(avancements[cle][0])

    def retirer_jauges(self) -> None:
        """Les jauges sous le titre retirées : refaites (``poser_jauges``), ou la copie rendue ([APE-15])."""
        if getattr(self, "jauges", None) is None:
            return
        self.layout().removeItem(self.rangee)
        for widget in self._widgets_de_jauges:
            widget.deleteLater()
        self.jauges = None

    def sizeHint(self) -> QSize:
        return self.layout().sizeHint()

    def minimumSizeHint(self) -> QSize:
        return self.layout().minimumSize()


ESPACE_ENTETE = 6  # entre la ligne de titre de la page et ce qui suit
AU_DESSUS = {"h1": 18, "h2": 12, "h3": 8}  # l'espace au-dessus d'un titre de section, selon son niveau (px)
# Les trois tailles de titre de la page (le professeur, 21/11/2026, [COS-26] : « il faut que tu échange les tailles de
# police entre les titres des thématiques et "Thématiques" », [COS-27] : « il faut que "À faire", "Thématiques" et "Bilan
# de l'année", prennet la nouvelle taile de police de "Thématiques" après l'échange », [COS-28] : « le titre
# "Cours","Réviser", etc soient un peu plus grand ») : les grandes sections, puis le nom d'un thème, puis ses rubriques,
# en multiples de la police de l'application. Les balises <h1>…<h3> n'y suffisent pas : <h1> et « xx-large » donnent
# tous deux deux fois la police (le nom d'un thème et « Thématiques » étaient de la même taille), et Qt ignore une taille
# en points posée dans un titre.
SECTION, THEME, RUBRIQUE = 2.5, 2.0, 1.4


def en_titre(texte: str, rang: float) -> str:
    """Le texte d'un titre de la page, en gras, à ``rang`` fois la taille de la police de l'application."""
    police = QApplication.font()
    taille = f"{police.pointSizeF() * rang:g}pt" if police.pointSizeF() > 0 else f"{round(police.pixelSize() * rang)}px"
    return f"<p style='font-size:{taille}'><b>{texte}</b></p>"


def titre_de_section(texte: str, haut: int | None = None) -> QLabel:
    """Un titre de la page (« <h2>…</h2> »), avec de l'espace au-dessus (l'utilisateur, 06/11/2026 : « il faut ajouter un peu
    d'espace au dessus de tout les titre de section et sous-section »)."""
    etiquette = QLabel(texte)
    etiquette.setContentsMargins(0, AU_DESSUS.get(texte[1:3], 0) if haut is None else haut, 0, 0)
    return etiquette


ECART_GRIS = 12  # entre le nom et sa partie grise, quand elles tiennent sur une ligne


def texte_du_titre(nom: str, gris: str, une_ligne: bool, interligne: int) -> str:
    """Le texte du bouton d'un sujet : son nom en entier, en gras, et sa date ou sa note en gris sur la même ligne, à droite
    (l'utilisateur, 06/11/2026 : « la partie grise à la ligne, plutot la mettre sur la meme ligne à droite ») ; sous le
    nom quand la ligne ne les tient pas (« sur téléphone il faudra certainement plutot metre à la ligne »). La partie grise
    garde l'``interligne`` du titre (px) : la note manuscrite, plus grande (``bilans_widget.manuscrit``), haussait sa ligne
    de 22 à 31 px, un vide sous le nom pris pour une jauge cachée (le professeur, 22/11/2026, [APE-10])."""
    ligne = f"line-height:{interligne}px; -qt-line-height-type:fixed; "
    if not une_ligne:
        return f"<b>{nom}</b><div style='{ligne}color:#606060'>{gris}</div>"
    return (f"<table width='100%' cellspacing=0 cellpadding=0><tr><td><b>{nom}</b></td>"
            f"<td align=right style='{ligne}color:#606060; padding-left:{ECART_GRIS}px'>{gris}</td></tr></table>")


def nom_dans_le_theme(nom: str, theme: str) -> str:
    """Le nom d'un sujet dans la section de son thème, sans le thème en tête que le titre de la section dit déjà
    (« Localisation… - Révision 1 - Latitude… » → « Révision 1 - Latitude… » ; le professeur, 10/11/2026, W529) ; le nom
    entier s'il ne commence pas par le thème, ou s'il ne resterait que la sorte (« Les réseaux sociaux - TP », le TP unique du
    thème, ne devient pas « TP » : le professeur, 22/11/2026, W916, « s'il n'ya rien d'autre que le thème et TP dans le titre il
    faut laisse le thème ») ; sans la mention « (avec IDE) » ou « (sans IDE) » (``noyau.sans_mention_ide``)."""
    nom = sans_mention_ide(nom)
    tete = f"{theme} - "
    reste = nom[len(tete):]
    seule_sorte = reste.casefold().rstrip("s") in {sorte.casefold().rstrip("s") for sorte in TYPES}
    return reste if theme and nom.casefold().startswith(tete.casefold()) and reste and not seule_sorte else nom


class TitreDeSujet(QLabel):
    """Le texte d'un sujet (``texte_du_titre``), qui passe la partie grise à la ligne quand sa largeur ne tient plus le nom
    et elle côte à côte : un tableau du texte riche de Qt ne se replie pas de lui-même."""

    def __init__(self, nom: str, gris: str) -> None:
        super().__init__()
        self.setWordWrap(True)
        self.setTextFormat(Qt.TextFormat.RichText)
        police_de_titre(self)
        self.poser(nom, gris)

    reserve = 0  # la place d'un coin posé par-dessus la première ligne (``TitreBouton.loger``)

    def poser(self, nom: str, gris: str) -> None:
        self.nom, self.gris, self.une_ligne = nom, gris, None
        self._choisir(self.width())

    def _choisir(self, largeur: int) -> None:
        gras = self.font()
        gras.setBold(True)
        besoin = QFontMetrics(gras).horizontalAdvance(self.nom) + QFontMetrics(self.font()).horizontalAdvance(unescape(re.sub('<[^>]+>', '', self.gris))) + ECART_GRIS
        une_ligne = not self.gris or besoin <= largeur - 2 * self.margin() - self.reserve
        if self.reserve:  # le coin n'écarte que la première ligne : seule ou le nom, s'il l'atteint
            atteint = une_ligne or QFontMetrics(gras).horizontalAdvance(self.nom) > largeur - 2 * self.margin() - self.reserve
            self.setContentsMargins(0, 0, self.reserve if atteint else 0, 0)
        if une_ligne != self.une_ligne:
            self.une_ligne = une_ligne
            self.setText(texte_du_titre(self.nom, self.gris, une_ligne, QFontMetrics(gras).height()))

    def resizeEvent(self, evenement) -> None:
        self._choisir(evenement.size().width())
        super().resizeEvent(evenement)


FORMAT_QT = "dd/MM/yyyy HH:mm"  # ``echeances.FORMAT`` dit par Qt
Regler = Callable[[str, str, dict[str, str], Callable[[str | None, str], None]], None]
# ``regler(sujet, classe, changements, rappel)`` : ``changements`` (colonne → case, ``echeances.recopier``) écrits dans
# echeances.csv, puis ``rappel(texte, message)`` : le texte du fichier après coup (None : illisible), et ce qu'il en est dit


def message_reglage(sujet: str, classe: str, ecrite: bool | None, erreur: Exception | None = None) -> str:
    """Ce que la page dit d'un « Enregistrer » : la ligne ajoutée, rien à changer, ou pourquoi le fichier n'est pas touché."""
    quoi = f"{sujet.rpartition('/')[2]}, {classe} : {echeances.NOM}"
    if erreur is not None:
        return f"{quoi} NON modifié ({erreur})."
    return f"{quoi} complété d'une ligne, qui vaut pour les élèves sans redéployer." if ecrite else f"{quoi} disait déjà cela."


def regler_sur_disque(sujet: str, classe: str, changements: dict[str, str], rappel: Callable[[str | None, str], None]) -> None:
    """``Regler`` en natif : la ligne ajoutée au fichier synchronisé par le client Dropbox (``echeances.regler``)."""
    try:
        message = message_reglage(sujet, classe, echeances.regler(sujet, classe, changements))
    except (OSError, ValueError) as erreur:
        message = message_reglage(sujet, classe, None, erreur)
    rappel(echeances.du_disque(), message)


async def regler_par(lire: Callable[[], Any], ecrire: Callable[[str, str | None], Any], sujet: str, classe: str,
                     changements: dict[str, str], rappel: Callable[[str | None, str], None], essais: int = 3,
                     graine: bytes | None = None) -> None:
    """``Regler`` en ligne : ``lire()`` rend {texte, rev} du fichier (ou rien), ``ecrire(texte, rev)`` l'écrit sur cette
    version et rend {rev}, ou rien si quelqu'un l'a changé depuis (``dropbox.js``, ``echeances_lire`` et ``echeances_ecrire``) :
    on relit alors et on recommence, comme ``pont_qt.deposer_identite``. Le texte complété vient d'``echeances.recopier``,
    signé par ``graine`` (celle du professeur entré, ``Identite.graine``) si le fichier l'était bien, refusé sans elle s'il
    est signé ; ``rappel`` reçoit le texte sans sa ligne de signature."""
    texte = None
    for _ in range(essais):
        try:
            lu = await lire()
            texte, rev = (str(lu.texte), str(lu.rev)) if getattr(lu, "texte", None) is not None else (None, None)
            nouveau = echeances.recopier(texte, sujet, classe, changements, graine)
            if nouveau is None:
                rappel(texte and echeances.sans_signature(texte), message_reglage(sujet, classe, False))
                return
            if getattr(await ecrire(nouveau, rev), "rev", None) is not None:
                rappel(echeances.sans_signature(nouveau), message_reglage(sujet, classe, True))
                return
        except Exception as erreur:  # noqa: BLE001 - réseau, quota, jeton, ou ValueError d'une valeur refusée : dit, rien d'écrit
            rappel(texte and echeances.sans_signature(texte), message_reglage(sujet, classe, None, erreur))
            return
    rappel(None, message_reglage(sujet, classe, None, ValueError("le fichier change sans cesse, réessayez")))


def maintenant_a_paris() -> datetime:
    """L'heure de Paris, sans fuseau, à la minute : celle des cases d'echeances.csv (le navigateur, lui, compte en UTC)."""
    return datetime.strptime(echeances.en_texte(datetime.now(timezone.utc)), echeances.FORMAT)


Effectives = Callable[[str, str], dict[str, str]]
# ``effectives(sujet, classe)`` : les réglages qui valent vraiment pour la classe, comme echeances.csv les écrit (colonne →
# case, ``echeances.REGLAGES``), là où sa ligne n'en dit rien : ``valeurs_du_qcm`` en natif, ``valeurs_par_defaut`` sinon


def valeurs_par_defaut(duree: int | None = None) -> dict[str, str]:
    """Les réglages d'un code de classe donné sans réglage (``codes.code_classe`` : celui que la page d'une classe passe au
    lecteur, ``jetons_du_sujet``), en cases d'echeances.csv : sans échéance, soumission 0, sans anti-triche, temps écran, et
    la durée du sujet (``duree``, vide s'il n'en a pas)."""
    return {"echeance": "", "duree": str(duree or ""), "soumission": "0", "anti_triche": "non", "temps": ECRAN}


def chemin_du_qcm(dropbox: Path, cat: dict[str, Any], sujet: str) -> Path | None:
    """Le .qcm du ``sujet`` d'une ligne d'echeances.csv sur ce disque : celui du catalogue, sinon le chemin que la ligne
    porte (sa place dans Dropbox, sans « .qcm », comme l'écrit « Générer ») ; ``None`` s'il n'y est pas."""
    connu = du_catalogue(lire_catalogue(cat)["sujets"], sujet)[1]
    for relatif in (connu.get("lien"), sujet.strip().lstrip("/") + ".qcm"):
        if relatif and (chemin := dropbox / relatif).is_file():
            return chemin
    return None


def valeurs_du_qcm(chemin: Path | None, classe: str) -> dict[str, str]:
    """``Effectives`` en natif : le dernier code donné à ``classe`` pour le .qcm ``chemin`` au journal des déploiements
    (``code_eleve.du_sujet``), qui dit sa durée (celle du sujet s'il n'en porte pas), son échéance, sa soumission, son
    anti-triche et son temps ; sans code au journal, ``valeurs_par_defaut`` à la durée du sujet ; sans .qcm lisible, celles
    sans durée. Ouvrir un .qcm coûte une seconde (scrypt) : ``main`` ne le fait que pour une ligne incomplète, une fois."""
    if chemin is None:
        return valeurs_par_defaut()
    import code_eleve  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas code_eleve.py
    try:
        cle, paquet = code_eleve.ouvrir(chemin)
        donnes = [e for e in code_eleve.du_sujet(cle, paquet) if e["classe"] and meme_classe(e["classe"], classe)]
    except (OSError, ValueError, KeyError):
        return valeurs_par_defaut()
    duree = paquet.get("duree_minutes")
    if not donnes:
        return valeurs_par_defaut(duree)
    e = donnes[-1]
    return {"echeance": echeances.en_texte(e["echeance"]), "duree": str(e["duree"] or duree or ""),
            "soumission": str(e["soumission"] or 0), "anti_triche": "oui" if e["anti_triche"] else "non",
            "temps": e["temps"] or ECRAN}


class Reglages(QFrame):
    """Sous le titre d'un sujet, pour le professeur seulement : le panneau des réglages de cette classe, le même que la fenêtre
    « Déployer » (``panneau_echeances.Panneau``, mêmes libellés, même ordre), et « Enregistrer », qui recopie la ligne
    d'echeances.csv en bas avec ce qui a changé (``echeances.recopier``) ; seules les cases changées ici sont envoyées, une
    case écrite à la main que ce panneau ne sait pas montrer reste telle quelle. Chaque réglage du code montre une vraie
    valeur : celle du fichier, sinon celle qui vaut vraiment pour la classe (``effectives()``, appelée seulement s'il en
    manque) ; une ligne incomplète s'enregistre alors entière (l'utilisateur, 06/11/2026 : « je veux dans mon interface pour
    gerer les sujet qu'il n'y ai aucun champs laissé à "celle du code" »). « sans échéance » et « sans durée » ne disent que
    ce vrai état. Les cours de la classe viennent de l'emploi du temps du professeur en natif, d'aucun dans le lecteur web
    (``panneau_echeances.cours_du_jour``). ``regler(sujet, classe, changements)`` : ``Portail.regler``. ``echeance`` : celle
    de l'``Entree`` ; une révision de DS à case vide la tient de la publication des copies corrigées du DS
    (``echeances.publication_du_ds``), que l'élève voit « fermé depuis » : elle est dite sous le panneau, jamais écrite
    dans la case, qui suit une publication déplacée ([L-31], relecteur W764)."""

    def __init__(self, sujet: str, classe: str, brute: dict[str, str] | None, regler: Callable[[str, str, dict[str, str]], None],
                 effectives: Callable[[], dict[str, str]] = valeurs_par_defaut, parent: QWidget | None = None,
                 echeance: datetime | None = None) -> None:
        super().__init__(parent)
        self.sujet, self.classe, self.regler = sujet, classe, regler
        self.setFrameShape(QFrame.Shape.StyledPanel)
        ligne = echeances.lire(brute)
        self.ecrites = {c: ((brute or {}).get(c) or "").strip() for c in COLONNES}  # la ligne en vigueur, telle qu'écrite
        manque = echeances.manquantes(brute)
        valeurs = {**self.ecrites, **{c: v for c, v in effectives().items() if c in manque}} if manque else self.ecrites
        maintenant = maintenant_a_paris()
        cours = cours_de_la_classe(cours_du_jour(), classe, maintenant)
        self.panneau = Panneau(sorte_du_sujet(sujet), cours, maintenant, valeurs)
        formulaire = QFormLayout(self)
        formulaire.addRow(self.panneau)
        self.derivee = None
        if echeance is not None and not valeurs["echeance"]:  # la case dit « sans échéance », la ligne en a une
            self.derivee = QLabel(f"<span style='color:#606060'>Case vide : échéance à la publication des copies corrigées "
                                  f"du DS, le {echeances.en_texte(echeance)}.</span>")
            self.derivee.setWordWrap(True)
            formulaire.addRow(self.derivee)
        self.enregistrer = QPushButton("Enregistrer")
        self.enregistrer.clicked.connect(self.envoyer)
        self.enregistrer.setEnabled(self.changements() != {})
        self.panneau.change.connect(lambda: self.enregistrer.setEnabled(self.changements() != {}))
        formulaire.addRow(self.enregistrer)
        self.incomplete = QLabel(f"<span style='color:#606060'>{echeances.NOM} ne dit pas tout pour cette classe : ce qui "
                                 "vaut est montré, « Enregistrer » l'y écrit.</span>")
        self.incomplete.setWordWrap(True)
        self.incomplete.setVisible(self.changements() != {})
        formulaire.addRow(self.incomplete)
        for erreur in ligne.erreurs:  # une case mal écrite à la main : ignorée par le lecteur, montrée ici à sa vraie valeur
            formulaire.addRow(QLabel(f"<span style='color:#c0392b'>{escape(erreur)}</span>"))

    def cases(self) -> dict[str, str]:
        """Ce que montre le panneau, case par case, comme echeances.csv l'écrit (``Panneau.cases``)."""
        return self.panneau.cases()

    def changements(self) -> dict[str, str]:
        """Les cases qui diffèrent de la ligne en vigueur : celles changées ici, et celles qu'elle ne disait pas."""
        return {colonne: case for colonne, case in self.cases().items() if case != self.ecrites[colonne]}

    def envoyer(self) -> None:
        self.enregistrer.setEnabled(False)
        self.enregistrer.setText("Enregistrement…")
        self.regler(self.sujet, self.classe, self.changements())


class Publication(QFrame):
    """Sous le titre d'un DS papier, pour le professeur seulement, comme ``Reglages`` sous un sujet déployé : la date à
    partir de laquelle les élèves voient leurs copies corrigées, ou « après le scan des rattrapages », et « Enregistrer »
    (``publier(nom, publication, apres_rattrapages)`` : ``Portail.publier_corriges``). Remplace « PDF › Publier les
    corrigés du DS… » du clic droit (le professeur, 19/11/2026, W792)."""

    def __init__(self, e: Entree, publier: Callable[[str, str, bool], None], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.nom, self.publier = e.nom, publier
        self.setFrameShape(QFrame.Shape.StyledPanel)
        formulaire = QFormLayout(self)
        actuelle = (datetime.strptime(echeances.en_texte(e.publication), echeances.FORMAT) if e.publication else None)
        # la plus petite valeur dit « pas encore publiés » : la veille à 0 h, pour qu'aujourd'hui choisi au calendrier (à 0 h,
        # déjà passée : visibles aussitôt) ne retombe pas sur elle (le professeur, 19/11/2026, W807)
        jour = maintenant_a_paris().replace(hour=0, minute=0)
        plus_tot = min(jour, actuelle or jour) - timedelta(days=1)
        self.date = QDateTimeEdit()
        self.date.setCalendarPopup(True)
        self.date.setDisplayFormat("ddd " + FORMAT_QT)
        self.date.setMinimumDateTime(plus_tot)
        self.date.setSpecialValueText(PAS_DE_DATE)
        self.date.setDateTime(actuelle or plus_tot)
        formulaire.addRow("Corrigés visibles à partir du", self.date)
        self.rattrapages = QCheckBox("après le scan des rattrapages")
        self.rattrapages.setChecked(e.apres_rattrapages and actuelle is None)
        self.date.setEnabled(not self.rattrapages.isChecked())
        self.rattrapages.toggled.connect(lambda coche: self.date.setEnabled(not coche))
        formulaire.addRow("", self.rattrapages)
        self.ecrites = self.cases()
        self.enregistrer = QPushButton("Enregistrer")
        self.enregistrer.clicked.connect(self.envoyer)
        self.enregistrer.setEnabled(False)
        for signal in (self.date.dateTimeChanged, self.rattrapages.toggled):
            signal.connect(lambda *_: self.enregistrer.setEnabled(self.cases() != self.ecrites))
        formulaire.addRow(self.enregistrer)

    def cases(self) -> tuple[str, bool]:
        """(date « JJ/MM/AAAA HH:MM » ou vide, après les rattrapages) : ce que montre le panneau ; la case cochée l'emporte."""
        if self.rattrapages.isChecked():
            return "", True
        date = self.date.dateTime()
        return ("" if date == self.date.minimumDateTime() else date.toString(FORMAT_QT)), False

    def envoyer(self) -> None:
        self.enregistrer.setEnabled(False)
        self.enregistrer.setText("Enregistrement…")
        self.publier(self.nom, *self.cases())


PAS_DE_DATE = "pas encore publiés"  # la plus petite date du panneau ``Publication`` : aucune



# « tout en haut le En cours doit avoir un cadre vert, le finir à la maison un cadre rouge » (l'utilisateur, 06/11/2026) ;
# le bouton du même sujet, dans son thème, a le bord de la même couleur
# un troisième cadre, bleu, pour les révisions ouvertes (l'utilisateur, 06/11/2026 : « un troisièe cadre bleu "Réviser" avec
# les qcm de révision ») : un sujet de révision ouvert y va, et non dans « En cours » ni « À finir »
REVISER = "Réviser"
COULEURS_DES_ZONES = {EN_COURS: "#27ae60", A_FINIR: "#c0392b", BONUS_A_FINIR: "#e67e22", REVISER: "#2980b9"}


def ancienne_revision(e: Entree) -> bool:
    """Une révision d'avant le « Réviser » par thème (« … - Révision 1 - … », « Révisions DS n°1 - … ») : un sujet de type
    « Révisions » qui n'est pas un « … - réviser » d'``entrainement.py`` (W754, W759). Ses copies restent ; la page ne la
    montre plus comme un sujet, ses séries sont dans l'historique du « Réviser » de son thème (``Tableau.historique`` ; le
    professeur, 21/11/2026, [COS-3] : « il faut converir les anciens sujet de révisions pourqu'il se fondent dans le nouveau
    systeme de révision comme des essais déjà fait et dans l'historique et qu'il n'apparaissent plus comme sujet à part
    entière »)."""
    return TYPES.get(e.type, e.type) == REVISER and not e.papier and not cle_de(e.nom).endswith("-reviser")


def zone_de(e: Entree, deja: bool | str = False) -> str:
    """Le cadre du haut d'un sujet ouvert : « Réviser » pour une révision, « Bonus à finir » si la copie de l'élève n'a plus
    que des bonus ouverts (``deja``, ce que rend ``commencee``), son état (« En cours », « À finir ») sinon ; un sujet sur
    le point de commencer (``apparition``) va dans « En cours »."""
    if TYPES.get(e.type, e.type) == REVISER:
        return REVISER
    return BONUS_A_FINIR if deja == BONUS_A_FINIR else EN_COURS if e.etat == A_VENIR else e.etat


class Branches(QWidget):
    """Les traits discrets de l'arbre devant un libellé du bilan d'un thème, comme un arbre de fichiers : une verticale
    par ancêtre qui a encore un frère plus bas, puis ├ ou └ vers le libellé (l'utilisateur, 06/11/2026 : « pour
    l'arborescence des sections, il faut mettre des traits discrets », sur le modèle de Notes/example.png)."""

    COULEUR = "#b8bcc2"

    def __init__(self, suites: list[bool], dernier: bool) -> None:
        super().__init__()
        self.suites, self.dernier = suites, dernier  # ``suites[k]`` : l'ancêtre de niveau k a un frère plus bas
        self.setFixedWidth((len(suites) + 1) * bilans_widget.PALIER)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)

    def paintEvent(self, _evenement) -> None:  # noqa: ANN001
        peintre = QPainter(self)
        peintre.setPen(QPen(QColor(self.COULEUR), 1))
        demi, milieu, bas = bilans_widget.PALIER // 2, self.height() // 2, self.height()
        for k, suite in enumerate(self.suites):
            if suite:
                peintre.drawLine(k * bilans_widget.PALIER + demi, 0, k * bilans_widget.PALIER + demi, bas)
        x = len(self.suites) * bilans_widget.PALIER + demi
        peintre.drawLine(x, 0, x, milieu if self.dernier else bas)
        peintre.drawLine(x, milieu, x + demi, milieu)
        peintre.end()


def branches(niveaux: list[int]) -> list[tuple[list[bool], bool]]:
    """Pour chaque rang de l'arbre aplati (``niveaux``), de quoi tracer ses ``Branches`` : la suite de chaque ancêtre,
    et s'il est le dernier de ses frères."""
    def frere_apres(i: int) -> bool:
        for n in niveaux[i + 1:]:
            if n <= niveaux[i]:
                return n == niveaux[i]
        return False
    rendus, ancetres = [], []  # ancetres[k] : le rang de l'ancêtre de niveau k du rang courant
    for i, n in enumerate(niveaux):
        ancetres = ancetres[:n] + [i]
        rendus.append(([frere_apres(a) for a in ancetres[:n]], not frere_apres(i)))
    return rendus


def jauge(taux: float | None) -> QLabel:
    """La jauge d'une ligne de bilan, ``bilans_widget._jauge`` en widget : la part remplie à la couleur du taux ; sans
    taux, « en attente »."""
    if taux is None:
        return QLabel("en attente")
    etiquette = QLabel()
    etiquette.setFixedSize(bilans_widget.JAUGE, 10)
    part = max(0.0, min(1.0, taux))
    plein, vide = bilans_widget.teinte(taux), bilans_widget.GRIS_JAUGE
    if part in (0.0, 1.0):  # pleine ou vide : une seule couleur (deux arrêts au même bord font un dégradé)
        etiquette.setStyleSheet(f"background: {plein if part else vide};")
    else:
        etiquette.setStyleSheet(f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {plein}, stop:{part:.4f} "
                                f"{plein}, stop:{part + 0.0001:.4f} {vide}, stop:1 {vide});")
    return etiquette


REVOIR = "Revoir les questions déjà répondues"  # la première ligne de l'historique d'un « Réviser » ([APE-7], ``noyau.REPONDUES``)


class JaugeDeRevision(QPushButton):
    """La jauge d'une section dans la grille du bilan d'un thème, pressable : elle déroule l'historique de la section
    (``Tableau._jauge_de``) ; la jauge (``jauge``) sans changement, sans flèche de menu, la main au survol."""

    def __init__(self, taux: float | None) -> None:
        super().__init__()
        self.jauge = jauge(taux)
        self.jauge.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        disposition = QHBoxLayout(self)
        disposition.setContentsMargins(0, 0, 0, 0)
        disposition.addWidget(self.jauge)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Historique : les séries lancées depuis cette section")
        self.setStyleSheet("QPushButton { border: none; background: transparent; padding: 0; }"
                           " QPushButton::menu-indicator { image: none; width: 0; }")
        self.setFixedSize(self.jauge.size())


class TitreDeRevision(QPushButton):
    """Le titre d'une section dans la grille du bilan d'un thème, qui est le bouton de sa révision : transparent, gris au
    survol, son libellé revenant à la ligne sur un téléphone (``texte``, comme ``TitreBouton``) ; marges : un peu après la
    branche de l'arbre, un peu avant la jauge (le professeur, 21/11/2026, [COS-8])."""

    def __init__(self, libelle: str) -> None:
        super().__init__()
        self.texte = QLabel(libelle)
        self.texte.setWordWrap(True)
        self.texte.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        disposition = QVBoxLayout(self)
        disposition.setContentsMargins(4, 2, 4, 2)
        disposition.addWidget(self.texte)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("QPushButton { border: none; background: transparent; border-radius: 4px; }"
                           " QPushButton:hover { background: #e6e6e6; } QPushButton:pressed { background: #d6d6d6; }")
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)

    def text(self) -> str:  # noqa: D102 - le libellé, comme un bouton à texte
        return self.texte.text()

    def sizeHint(self) -> QSize:  # noqa: D102
        return self.layout().sizeHint()

    def minimumSizeHint(self) -> QSize:  # noqa: D102
        return self.layout().minimumSize()

    def hasHeightForWidth(self) -> bool:  # noqa: D102
        return True

    def heightForWidth(self, largeur: int) -> int:  # noqa: D102
        return self.texte.heightForWidth(max(1, largeur - 8)) + 4


def bouton_ouvert(couleur: str) -> str:
    """La feuille de style d'un sujet ouvert, dans son thème : le bord du bouton lui-même, de la couleur de sa zone."""
    return modele.style_bouton(f"3px solid {couleur}")


COTE_MOLETTE = 30  # px : le bouton des réglages d'un sujet, au professeur


def icone_molette(cote: int = 64, couleur: str = "#404040") -> QIcon:
    """Une molette dessinée (huit dents, un trou) : ni fichier à embarquer dans le lecteur web, ni police qui manquerait
    du caractère ⚙."""
    image = QPixmap(cote, cote)
    image.fill(Qt.GlobalColor.transparent)
    peintre = QPainter(image)
    peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
    centre, dehors, dedans, trou = QPointF(cote / 2, cote / 2), cote * 0.48, cote * 0.34, cote * 0.14
    contour = QPainterPath()
    for k in range(32):  # dent, dent, creux, creux, par huitième de tour
        rayon = dehors if k % 4 in (1, 2) else dedans
        angle = (k - 0.5) * math.pi / 16
        point = centre + QPointF(rayon * math.cos(angle), rayon * math.sin(angle))
        contour.moveTo(point) if k == 0 else contour.lineTo(point)
    contour.closeSubpath()
    contour.addEllipse(centre, trou, trou)
    peintre.fillPath(contour, QColor(couleur))
    peintre.end()
    return QIcon(image)


def molette() -> QToolButton:
    """Le bouton des réglages d'un sujet : une molette, petit bouton bien visible, qui se coche ; sans contour (le
    professeur, 21/11/2026, [COS-2] : « le boutons de reglage ne doivent pas avoir de contour »), un fond léger quand le
    panneau est ouvert."""
    bouton = QToolButton()
    bouton.setAutoRaise(True)
    bouton.setStyleSheet("QToolButton { border: none; background: transparent; }"
                         " QToolButton:checked, QToolButton:hover { background: rgba(0, 0, 0, 30); border-radius: 4px; }")
    bouton.setIcon(icone_molette())
    bouton.setIconSize(QSize(COTE_MOLETTE - 8, COTE_MOLETTE - 8))
    bouton.setFixedSize(COTE_MOLETTE, COTE_MOLETTE)
    bouton.setCheckable(True)
    bouton.setToolTip("Réglages")
    bouton.setAccessibleName("Réglages")
    bouton.setCursor(Qt.CursorShape.PointingHandCursor)
    return bouton


def feuille_de_page(page: QWidget) -> None:
    """Le fond et les boutons du lecteur sur ``page`` (l'utilisateur : « mettre la meme couleur de fond que sur les QCM et
    le meme style de boutons que "corriger" ») : ``modele.fond_sujet`` et ``modele.style_bouton``, la source unique ; la
    feuille descend aux boutons du dedans, un bouton qui a la sienne (``bouton_ouvert``) la garde."""
    page.setObjectName("page")
    page.setStyleSheet(f"QWidget#page {{ background: {modele.fond_sujet().name()}; }} {modele.style_bouton()}")


# « À finir à la maison : les TP et autre à finir à la maison » (l'utilisateur, 06/11/2026)
TITRES_DES_ZONES = {EN_COURS: EN_COURS, A_FINIR: "À finir à la maison", BONUS_A_FINIR: "Questions bonus à finir",
                    REVISER: REVISER}
ECART_PLI = 4  # entre le triangle d'un thème et son nom
MARGE, MARGE_CADRE, TRAIT_CADRE, RETRAIT, RETRAIT_BOUTONS = 24, 8, 4, 24, 16  # bord de la page, bord du cadre « En cours », son trait, retrait


class Tableau(QScrollArea):
    """Le tableau d'une classe. ``ouvrir(entree)`` : un titre pressé ; ``commencee(nom)`` : vrai si une copie de ce sujet
    de l'élève entré est déjà dans cet appareil, ``RENDU`` si elle y est rendue (hors de
    « À faire », comme une copie rendue que le bilan lu montre : ``notes_dans_les_boutons``) ; ``eleve`` : « Nom Prénom » de
    l'élève entré, montré sous la classe ; ``professeur`` : c'est le professeur ;
    ``lire_bilan(chemin, rappel)`` : rend à ``rappel`` les octets du fichier ``chemin`` du dossier Dropbox (None s'il
    n'existe pas), le bilan de l'année, ouvert d'emblée s'il est en clair ou que le ``secret`` de l'élève entré l'ouvre
    (``identites`` : le fichier d'empreintes) ; le mot de passe n'est demandé que sinon. Au professeur, si ``regler`` est
    donné, un bouton « Réglages » par sujet, qui montre ses ``Reglages`` lus dans ``texte_echeances`` (le fichier), les
    cases qu'il ne dit pas remplies par ``effectives`` (``valeurs_par_defaut`` sans lui) ;
    ``message`` : ce qu'a fait le dernier « Enregistrer », en haut."""

    def __init__(self, classe: str, liste: list[Entree], ouvrir: Callable[[Entree], None],
                 commencee: Callable[[str], bool] = lambda nom: False, erreurs: list[str] = (), eleve: str = "",
                 lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None,
                 professeur: bool = False, secret: bytes | None = None, identites: dict[str, Any] | None = None,
                 texte_echeances: str | None = None, regler: Callable[[str, str, dict[str, str]], None] | None = None,
                 message: str = "", parent: QWidget | None = None, effectives: Effectives | None = None,
                 revisions: dict[str, Any] | None = None, maintenant: datetime | None = None,
                 rebatir: Callable[[], None] | None = None,
                 publier: Callable[[str, str, bool], None] | None = None, eleves: list[str] | None = None,
                 series: Callable[[Entree], list[tuple[int, str]]] | None = None, lecture_seule: bool = False) -> None:
        super().__init__(parent)
        # l'élève vu par le professeur (``Portail.voir_comme``, W814) : son bilan ouvert par l'empreinte qu'il a déposée
        # (``bilans_widget.cle_deposee``), le professeur n'ayant pas son secret ; aucune contestation ne part
        self.lecture_seule = lecture_seule
        self.setWindowTitle(f"SmartTeacher - {classe}")
        self.publier = publier if professeur else None  # au professeur : le panneau ``Publication`` d'un DS papier
        # l'heure de la page, qui avance depuis ``maintenant`` (celui des états de ``liste``) ; ``rebatir`` refait la page quand
        # un sujet caché doit paraître (``apparition``) ; ``decomptes`` : par sujet sur le point de commencer, son bouton grisé
        depart, origine = maintenant or datetime.now(timezone.utc), time.monotonic()
        self.horloge: Callable[[], datetime] = lambda: depart + timedelta(seconds=time.monotonic() - origine)
        self.rebatir, self.decomptes = rebatir, []
        self.prochaine: datetime | None = None  # la prochaine apparition d'un sujet caché
        self.construit = False  # pas de ``rebatir`` depuis le constructeur : le Portail n'a pas encore ce tableau
        evalues = themes_evalues(liste)  # avant de cacher : une évaluation prévue, même cachée, y ramène les révisions
        # une ancienne révision n'est plus un sujet de la page, au professeur non plus : ses séries vont dans l'historique du
        # « Réviser » de son thème (``ancienne_revision``, ``historique`` ; [COS-3])
        self.anciennes_revisions = [e for e in liste if ancienne_revision(e)]
        liste = [e for e in liste if not ancienne_revision(e)]
        if not professeur:  # un TP fait aussi sur papier : l'élève qui a rendu sa copie voit son entrée papier (W906)
            liste = [e.corrige if e.corrige and e.scanne(eleve) else replace(e, corrige=None) for e in liste]
        if not professeur:  # le professeur voit tout, ses réglages compris
            instant = self.horloge()
            caches = {id(e) for e in liste if (a := apparition(e)) and a > instant}
            self.prochaine = min((apparition(e) for e in liste if id(e) in caches), default=None)
            liste = [e for e in liste if id(e) not in caches]
        instant = self.horloge()  # l'épreuve à ouvrir d'emblée (``en_seance``), si l'élève ne l'a pas rendue
        self.epreuve = None if professeur else next(
            (e for e in liste if en_seance(e, instant) and commencee(e.nom) != RENDU), None)
        # l'épreuve qui commence dans moins de 30 min : l'écran d'attente vert du Portail, jusqu'à son début (``_battre``)
        self.attente = None if professeur or self.epreuve else next(
            (e for e in liste if avant_seance(e, instant) and commencee(e.nom) != RENDU), None)
        # les sujets du catalogue, où « Réviser » et « Validation » trouvent ceux d'``entrainement.py`` (``revision``)
        self.revisions, self.ouvrir_revision, self.classe_revision = revisions or {}, ouvrir, classe
        # l'historique d'un « Réviser » : ``series(entree)``, les séries lancées depuis son bouton, (essai, libellé) ; celles de
        # cet appareil (``lecteur.series_sur_disque``, ``pont_tableau.series``), aucune sans lui (W811)
        self.series = series or (lambda entree: [])
        self.commencee = commencee  # ce que l'appareil sait des copies de l'élève entré (plus montré : [COS-4])
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.boutons: dict[str, TitreBouton] = {}  # par sujet : ce que les tests pressent
        self.textes: list[tuple[Entree, TitreDeSujet, str]] = []  # par sujet : son texte et sa ligne grise, où va la note de la copie
        self.themes: list[tuple[str, QVBoxLayout]] = []  # par section de thème : son nom et sa pile
        # par thème, où va son bilan : sous ses boutons « Réviser » ; un thème sans révision, une sous-section « Réviser »
        # cachée, montrée avec son bilan (l'utilisateur, 06/11/2026 : « ce qui se trouve dans Bilan, doit plutôt se trouver
        # dans réviser, en dessous du bouton de révision globale du thème »)
        self.reviser: dict[str, tuple[QWidget | None, QVBoxLayout]] = {}
        self.boutons_reviser: list[tuple[str, str, QPushButton]] = []  # (thème, notion, bouton) du bilan de chaque thème
        self.historiques: list[tuple[str, str, QPushButton]] = []  # (thème, notion, jauge) : l'historique de chaque « Réviser »
        self._molettes: dict[str, list[QToolButton]] = {}  # par sujet : ses molettes, une par endroit où il est redit
        self._place_des_reglages: dict[str, QVBoxLayout] = {}  # par sujet : la pile où est son panneau
        self.reglages: dict[str, Reglages] = {}  # par sujet, au professeur seulement (``regler``) : ses réglages, sous son titre
        self.lire_bilan, self.niveau, self.bilan = lire_bilan, niveau_de(classe, liste), None
        self.plis: dict[str, QToolButton] = {}  # le triangle de chaque thème, coché : plié
        self.cours: dict[str, TitreBouton] = {}  # les boutons des PDF de cours, par chemin dans Dropbox
        self.fenetre_cours: Cours | None = None
        self.secret, self.identites = secret, identites or {}
        self.cle_classe = ""  # la clé de la liste de la classe (``Portail``) : celle de la copie jointe aux PDF corrigés
        # l'élève entré, dont la page cherche les copies corrigées (SPEC W647) ; elles, trouvées, par sujet ; par thème, le
        # cours montré à côté d'une copie dont le sujet n'en nomme aucun
        self.eleve = "" if professeur else eleve.strip()
        self.copies: dict[str, bytes] = {}
        self.copies_attendues: dict[str, list[Callable[[bytes | None], None]]] = {}  # sujet → boutons qui attendent sa copie
        self.chemins_copies: dict[str, str] = {}  # sujet → chemin Dropbox du PDF corrigé trouvé (contestations à côté)
        self.cours_par_theme: dict[str, tuple[str, str, str]] = {}
        self.pages_vues = pages_vues(liste)  # jusqu'où chaque cours se montre ; absent : pas encore vu, pas de bouton
        self.diaporamas = {c[0]: t for e in liste for c, t in zip(e.cours, e.diaporama_pages) if t}  # par PDF de cours
        for e in liste:
            for c in e.cours:  # le premier cours déjà vu du thème, jamais celui d'un sujet à venir
                if c[0] in self.pages_vues:
                    self.cours_par_theme.setdefault(e.theme, c)
                    break
        contenu = QWidget()
        feuille_de_page(contenu)
        # le cadre « En cours » déborde dans la marge, son titre aligné sur ceux des thèmes (l'utilisateur, 06/11/2026 :
        # « c'est le cadre autour qui doit aller dans les marges ») : la page a 8 px de bord, tout le reste 16 de plus
        exterieur = QVBoxLayout(contenu)
        exterieur.setContentsMargins(MARGE_CADRE, 16, MARGE_CADRE, 16)
        self.pile = pile = QVBoxLayout()
        pile.setContentsMargins(MARGE - MARGE_CADRE, 0, MARGE - MARGE_CADRE, 0)
        exterieur.addLayout(pile)
        # icône, application, classe et élève sur une ligne, en haut (l'utilisateur, 06/11/2026 : « il faut mettre l'icone
        # SmartTeacher, classe et nom de l'élève en ligne pour laisser de la place au reste de la page »)
        logo = QLabel()
        logo.setPixmap(QIcon(str(LOGO_APPLI)).pixmap(56, 56))
        qui = "Professeur" if professeur else eleve
        self.entete = QLabel(f"<span style='font-size:xx-large'><b>SmartTeacher</b> &nbsp;·&nbsp; {titre_de_page(classe, self.niveau)}"
                             + (f" &nbsp;·&nbsp; {escape(qui)}" if qui else "") + "</span>")
        ligne = QHBoxLayout()
        ligne.addWidget(logo)
        ligne.addWidget(self.entete, 1)
        pile.addLayout(ligne)
        pile.addSpacing(ESPACE_ENTETE)  # « la ligne de titre plus grande et un peu d'espace avant le TODO » (06/11/2026)
        self.message = QLabel(message)  # ce qu'a fait le dernier « Enregistrer » des réglages, en texte brut
        self.message.setTextFormat(Qt.TextFormat.PlainText)
        self.message.setWordWrap(True)
        self.message.setVisible(bool(message))
        pile.addWidget(self.message)
        if not liste:
            pile.addWidget(QLabel("Rien n'est prévu pour cette classe pour l'instant."))
        # un TP rendu sort de « À faire », une révision jamais : elle se refait
        rendu = lambda e: not professeur and bool(e.lien) and zone_de(e) != REVISER and commencee(e.nom) == RENDU  # noqa: E731
        # une révision d'un thème déjà évalué n'est plus « à faire » (``themes_evalues``) ; un sujet sur le point de commencer
        # l'est déjà, pour l'élève
        hors_cadre = lambda e: rendu(e) or zone_de(e) == REVISER and e.theme in evalues  # noqa: E731
        ouverts = [e for e in liste if (e.etat in (EN_COURS, A_FINIR) or e.etat == A_VENIR and not professeur)
                   and not hors_cadre(e)]
        self.a_faire: list[tuple[Entree, QWidget, QFrame]] = []  # par sujet de « À faire » : son bouton et son cadre
        self.titre_a_faire: QWidget | None = None
        sujet = lambda dans, e, theme="", en_haut=False: self._sujet(dans, e, professeur, regler, commencee, ouvrir,  # noqa: E731
                                                                     texte_echeances, effectives, theme, en_haut)
        # deux zones en haut (l'utilisateur, 06/11/2026 : « il faut deux zones en haut : En cours : c'est le TP ou la mini
        # interrogation du cours actuel »), « En cours » pendant le créneau, « À finir » ensuite jusqu'à l'échéance ; chaque
        # sujet est redit dans son thème
        if ouverts:  # un grand titre au-dessus des cadres, comme « Thématiques » au-dessus des thèmes (l'utilisateur,
            self.titre_a_faire = titre_de_section(en_titre("À faire", SECTION), AU_DESSUS["h1"])  # « TODO » (06/11/2026), « À faire » depuis le 10/11/2026 (W529)
            pile.addWidget(self.titre_a_faire)
        # les cadres en retrait sous « TODO », leurs boutons alignés sur ceux des thèmes (l'utilisateur, 06/11/2026 : « il faut
        # une indentation du coup pour les cadre de TODO », puis « décale encore pour pluot aligner à gauche les boutons de TP »)
        self.cadres = cadres = QVBoxLayout()
        cadres.setContentsMargins(self._largeur_pli() + ECART_PLI + RETRAIT_BOUTONS, 0, 0, 0)
        exterieur.addLayout(cadres)
        # l'ordre des thèmes et des sections de la page (``ranger``) est aussi celui du cadre « Réviser » (l'utilisateur,
        # 08/11/2026 : « les boutons de révisions dans l'encadré bleu en haut doivent être dans l'ordre des thématiques et des
        # sections de chaque thématique ») ; « En cours » et « À finir » restent par échéance (``entrees``)
        # le thème d'une ancienne révision reste, même sans autre sujet : le « Réviser » de son bilan porte ses séries ([COS-3])
        rangees = [(theme, [(sorte, groupe) for sorte, tous in sections if (groupe := [e for e in tous if not ancienne_revision(e)])])
                   for theme, sections in ranger(liste + self.anciennes_revisions)]
        place = {id(e): i for i, e in enumerate(e for _, sections in rangees for _, groupe in sections for e in groupe)}
        # aussi pour ``_battre`` (le bouton d'un sujet qui s'ouvre prend la couleur de sa zone, relecteur W749)
        self.zone_eleve = zone_eleve = lambda e: zone_de(e, not professeur and bool(e.lien) and commencee(e.nom))  # noqa: E731
        for zone in (EN_COURS, A_FINIR, BONUS_A_FINIR, REVISER):
            dans_zone = [e for e in ouverts if zone_eleve(e) == zone]
            if not dans_zone:
                continue
            if zone == REVISER:
                dans_zone.sort(key=lambda e: place[id(e)])
            else:  # par échéance (``entrees``), et à échéance égale dans l'ordre des thèmes et de leurs sections (le
                # professeur, 22/11/2026, [APE-16] : « si des échéances sont identique, il faut trier dans l'ordre des
                # thèmatique et de leur sections »)
                dans_zone.sort(key=lambda e: (instant_de(e), place.get(id(e), len(place))))
            # « un cadre rouge avec des coins arrondis et un trait épais » (l'utilisateur, 06/11/2026), vert pour « En cours »
            cadre = QFrame()
            cadre.setObjectName("en_cours")  # le style ne passe pas aux boutons du dedans
            cadre.setStyleSheet(f"QFrame#en_cours {{ border: {TRAIT_CADRE}px solid {COULEURS_DES_ZONES[zone]}; border-radius: 12px; }}")
            dedans = QVBoxLayout(cadre)
            interieur = MARGE - MARGE_CADRE - TRAIT_CADRE
            dedans.setContentsMargins(interieur, 4, interieur, 12)
            dedans.addWidget(QLabel(f"<h2>{TITRES_DES_ZONES[zone]}</h2>"))
            boutons = QVBoxLayout()  # en retrait, comme dans un thème
            boutons.setContentsMargins(RETRAIT, 0, 0, 0)
            dedans.addLayout(boutons)
            for e in dans_zone:
                sujet(boutons, e, en_haut=True)
                if (bouton := boutons.itemAt(boutons.count() - 1).widget()) is not None:
                    self.a_faire.append((e, bouton, cadre))
            cadres.addWidget(cadre)
        if ouverts:
            self.pile = pile = QVBoxLayout()  # la suite de la page, sous les cadres
            pile.setContentsMargins(MARGE - MARGE_CADRE, 0, MARGE - MARGE_CADRE, 0)
            exterieur.addLayout(pile)
        # un sujet ouvert est aussi dans son thème, bord de la couleur de sa zone (l'utilisateur, 06/11/2026 : « il faut doubler les
        # travaux en cours : un dans le résumé "En cours" en haut, et un avec un cadre rouge dans la thématique »)
        # un grand titre au-dessus des thèmes (l'utilisateur, 06/11/2026 : « il faut un grand titre "Thématiques" »)
        if rangees:
            pile.addWidget(titre_de_section(en_titre("Thématiques", SECTION), AU_DESSUS["h1"]))
        for theme, sections in rangees:
            # un triangle à gauche du titre plie ou déplie le thème (l'utilisateur, 06/11/2026 : « il faut pouvoir reduire(plier) /
            # deployer(deplier) une thematique avec un petit bouton avec des triangle à gauche du titre , sans contour ni fond »)
            entete, pli = QHBoxLayout(), self._pli()
            entete.setContentsMargins(0, AU_DESSUS["h2"], 0, 0)  # le titre du thème, triangle compris
            entete.setSpacing(ECART_PLI)
            entete.addWidget(pli)
            # le nom du thème à la taille des grands titres, au-dessus de Réviser, Travaux pratiques… (le professeur, 10/11/2026,
            # W529 : « aggrandi les noms des themes »)
            entete.addWidget(QLabel(en_titre(escape(theme or AUTRES), THEME)), 1)
            pile.addLayout(entete)
            corps = QWidget()  # pas « contenu » : celui de la page entière
            dans_theme = QVBoxLayout(corps)  # en retrait sous son thème (l'utilisateur, 06/11/2026 : « il faut une indentation
            # dans chaque thème ») ; le retrait part du nom du thème, pas du triangle (« réindenter pour compenser la présence
            # du bouton de deployement d'une thematique »)
            dans_theme.setContentsMargins(pli.sizeHint().width() + ECART_PLI + RETRAIT, 0, 0, 0)
            pile.addWidget(corps)
            pli.toggled.connect(lambda plie, c=corps, b=pli: (c.setVisible(not plie), b.setArrowType(
                Qt.ArrowType.RightArrow if plie else Qt.ArrowType.DownArrow)))
            self.plis[theme or AUTRES] = pli
            self.themes.append((theme or AUTRES, dans_theme))
            self._cours_du_theme(dans_theme, theme, [*sections, ("", [e for e in self.anciennes_revisions if e.theme == theme])],
                                 [t for t, _ in rangees if t])  # les cours d'une ancienne révision restent ([COS-3])
            if not sections or sections[0][0] != REVISER:  # « Réviser » vient en premier (``ranger``)
                boite = QWidget()
                boite.hide()
                dans_boite = QVBoxLayout(boite)
                dans_boite.setContentsMargins(0, 0, 0, 0)
                dans_theme.addWidget(boite)
                self.reviser[theme or AUTRES] = (boite, self._sous_section(dans_boite, REVISER))
            for sorte, groupe in sections:
                dans_sorte = self._sous_section(dans_theme, sorte) if sorte else dans_theme  # sans titre : « Devoirs surveillés »
                if sorte == REVISER:
                    self.reviser[theme or AUTRES] = (None, dans_sorte)
                for e in groupe:
                    sujet(dans_sorte, e, theme)  # sans le thème en tête : le titre de la section le dit (W529)
                    if e.etat not in (EN_COURS, A_FINIR) or hors_cadre(e):
                        continue
                    if e.ligne.sujet in self.boutons:  # le bord du bouton lui-même, pas un cadre de plus (06/11/2026)
                        self.boutons[e.ligne.sujet].setStyleSheet(bouton_ouvert(COULEURS_DES_ZONES[zone_eleve(e)]))
        for erreur in erreurs:  # ce que le professeur a mal écrit (``construire`` ne laisse à l'élève que sa classe)
            pile.addWidget(QLabel(f"<span style='color:#c0392b'>{ECHEANCES}, {erreur}</span>"))
        if lire_bilan and self.niveau and not professeur:
            self._formulaire_bilan(eleve)
            if eleve:  # le mot de passe n'est demandé que si le bilan ne s'ouvre pas sans lui
                self.voir_bilan()
        elif lire_bilan and self.niveau and eleves:  # au professeur : le bilan de l'élève choisi
            self._bilans_des_eleves(eleves)
        exterieur.addStretch(1)
        self.setWidget(contenu)
        self.minuterie = QTimer(self)
        self.minuterie.timeout.connect(self._battre)
        self._battre()
        self.construit = True
        if self.decomptes or self.prochaine and rebatir:
            self.minuterie.start(1000)
        modele.tactile.defiler_au_doigt(self)  # au doigt, la page défile, comme celle d'un sujet (le professeur, 10/11/2026, W529)

    def _sujet(self, pile: QVBoxLayout, e: Entree, professeur: bool, regler: Callable[[str, str, dict[str, str]], None] | None,
               commencee: Callable[[str], bool], ouvrir: Callable[[Entree], None], texte_echeances: str | None,
               effectives: Effectives | None, theme: str = "", en_haut: bool = False) -> None:
        """Un sujet dans ``pile`` : le nom du fichier, « Thème - TP2 - Titre », puis la date en gris (au professeur, ses
        réglages en bref : ``en_bref``) ; dans la section de son ``theme``, sans lui en tête (``nom_dans_le_theme``) ;
        ``en_haut`` : dans un cadre du haut ; à l'élève, un sujet à venir grisé, avec son décompte (``_battre``) ; au
        professeur, sa molette des réglages et leur panneau."""
        # « Rendu » seul, plus de « Déjà commencé » : la jauge sous le titre le dit (le professeur, 21/11/2026, [COS-4])
        if professeur and e.corrige:  # papier à gauche (sa publication), électronique à droite (ses réglages)
            rangee = QHBoxLayout()
            for moitie in (e.corrige, replace(e, corrige=None)):
                colonne = QVBoxLayout()
                self._sujet(colonne, moitie, professeur, regler, commencee, ouvrir, texte_echeances, effectives, theme, en_haut)
                rangee.addLayout(colonne, 1)
            pile.addLayout(rangee)
            return
        deja = e.lien and not professeur and e.etat != FERME and commencee(e.nom)
        gris = (etat_de_copie(e, professeur) if e.papier else en_bref(e) if professeur
                else " · ".join(filter(None, (quand(e), RENDU if deja == RENDU else ""))))  # une date peut manquer
        texte = TitreDeSujet(nom_dans_le_theme(e.nom, theme), gris)
        self.textes.append((e, texte, gris))
        if e.papier:  # un DS papier : grisé tant que sa copie corrigée n'est ni publiée ni trouvée (SPEC W647, point 4)
            bouton = TitreBouton(texte, e.nom)
            bouton.clicked.connect(lambda _=False, e=e: self.ouvrir_copie(e, self.copies.get(e.ligne.sujet)))
            bouton.setEnabled(False)
            self.boutons.setdefault(e.ligne.sujet, bouton)
            if professeur and self.publier:  # sa molette, comme un sujet déployé
                self._poser_molette(pile, e, bouton, lambda e=e: Publication(e, self.publier))
                return
            pile.addWidget(bouton)
            if not professeur and e.publiee and self.eleve and self.lire_bilan:
                self._activer_si_copie(e, bouton, texte)
            return
        if e.lien:
            titre = bouton = TitreBouton(texte, e.nom)
            # l'élève entré : sa copie corrigée d'abord, sinon le TP électronique, comme avant (SPEC W647, points 2 et 3)
            bouton.clicked.connect(lambda _=False, e=e: self.ouvrir_tp(e, ouvrir) if self.eleve and self.lire_bilan
                                   and not professeur else ouvrir(e))
            self.boutons[e.ligne.sujet] = bouton
            # une jauge vide, remplie au bilan de sa copie (le professeur, 22/11/2026, [APE-15] : « les bouton de TP non
            # commencés , doivent afficher un jauge vide »)
            if not professeur and e.type == "TP" and not deja:
                bouton.poser_jauges({"obligatoire": [0, 1]})
        elif e.etat == A_VENIR and not professeur:  # bientôt : grisé, cliquable à son début (``_battre``)
            titre = bouton = TitreBouton(texte, e.nom)
            bouton.setEnabled(False)
            bouton.clicked.connect(lambda _=False, e=e: self.ouvrir_tp(e, ouvrir) if self.eleve and self.lire_bilan else ouvrir(e))
            self.decomptes.append((e, bouton, texte, en_haut))
        else:  # à venir : le titre seul, aligné sur ceux qu'on presse
            titre = texte
            texte.setContentsMargins(*MARGES_TITRE)
        if not (professeur and regler):
            pile.addWidget(titre)
            return
        self._poser_molette(pile, e, titre, lambda e=e: Reglages(
            e.ligne.sujet, e.ligne.classe,
            echeances.trouver(texte_echeances, {e.ligne.sujet.strip().replace("\\", "/").rpartition("/")[2]}, e.ligne.classe),
            regler, (lambda: effectives(e.ligne.sujet, e.ligne.classe)) if effectives else valeurs_par_defaut,
            echeance=e.ligne.echeance))

    def _poser_molette(self, pile: QVBoxLayout, e: Entree, titre: QWidget, faire: Callable[[], QWidget]) -> None:
        """Le professeur : la molette du sujet, qui montre ou cache ``panneau`` (ses réglages) sous ``titre`` ; elle seule se
        presse, petit bouton bien visible (le professeur, 17/11/2026 00:22, guichet W721). Dans le bouton du sujet, tout à
        droite de sa première ligne, et pour chaque sujet, même redit dans son thème (le professeur, 21/11/2026, [COS-2] :
        « etre présent pour chaque sujet (pour l'instnat ) et inséré dans le bouton du sujet tout à droite sur la première
        ligne ») ; un titre qui n'est pas un bouton la garde à sa droite. Un sujet redit n'a qu'un panneau (``reglages``,
        fait par ``faire`` une fois, ses valeurs lues une fois et jamais deux versions d'une même ligne), qui passe sous la
        molette pressée, les autres molettes du sujet relâchées."""
        montrer = molette()
        if isinstance(titre, TitreBouton):
            titre.loger(montrer)
            pile.addWidget(titre)
            ancre: QWidget | QHBoxLayout = titre
        else:
            ancre = QHBoxLayout()
            ancre.addWidget(titre, 1)
            ancre.addWidget(montrer, 0, Qt.AlignmentFlag.AlignTop)
            pile.addLayout(ancre)
        sujet = e.ligne.sujet
        if sujet not in self.reglages:
            self.reglages[sujet] = panneau = faire()
            panneau.hide()
            pile.addWidget(panneau)
            self._place_des_reglages[sujet] = pile
        self._molettes.setdefault(sujet, []).append(montrer)

        def basculer(oui: bool) -> None:
            panneau = self.reglages[sujet]
            if oui:
                for autre in self._molettes[sujet]:
                    if autre is not montrer:
                        autre.setChecked(False)
                self._place_des_reglages[sujet].removeWidget(panneau)
                pile.insertWidget(pile.indexOf(ancre) + 1, panneau)
                self._place_des_reglages[sujet] = pile
            panneau.setVisible(oui)
        montrer.toggled.connect(basculer)

    def _battre(self) -> None:
        """Chaque seconde : la page refaite quand un sujet caché doit paraître (``rebatir``) ; le décompte des sujets sur le
        point de commencer, et, à leur début, leur bouton qui devient cliquable (bord de sa zone dans le thème)."""
        instant = self.horloge()
        if self.prochaine and instant >= self.prochaine and self.rebatir and self.construit:
            self.minuterie.stop()
            self.rebatir()
            return
        for quatre in list(self.decomptes):
            e, bouton, texte, en_haut = quatre
            reste = e.ligne.debut - instant if e.ligne.debut else timedelta(0)
            if reste > timedelta(0) or not self.construit:  # commencé pendant la construction : à la seconde suivante
                texte.poser(texte.nom, decompte(reste))
                continue
            self.decomptes.remove(quatre)
            e.etat, e.lien = e.ligne.etat(instant), e.lien or e.lien_au_debut
            if self.rebatir and en_seance(e, instant):  # une épreuve qui commence : la page s'efface devant elle
                self.minuterie.stop()
                self.rebatir()
                return
            texte.poser(texte.nom, quand(e))
            bouton.setEnabled(bool(e.lien))
            if e.lien:
                self.boutons.setdefault(e.ligne.sujet, bouton)
                if not en_haut and self.zone_eleve(e) in COULEURS_DES_ZONES:
                    bouton.setStyleSheet(bouton_ouvert(COULEURS_DES_ZONES[self.zone_eleve(e)]))
        if not self.decomptes and not (self.prochaine and self.rebatir):
            self.minuterie.stop()

    @staticmethod
    def _sous_section(dans_theme: QVBoxLayout, sorte: str) -> QVBoxLayout:
        """Le titre de la sous-section ``sorte`` dans ``dans_theme`` et la pile de ses boutons, un peu en retrait
        (l'utilisateur, 06/11/2026)."""
        dans_theme.addWidget(titre_de_section(en_titre(escape(sorte), RUBRIQUE), AU_DESSUS["h3"]))
        dans_sorte = QVBoxLayout()
        dans_sorte.setContentsMargins(RETRAIT_BOUTONS, 0, 0, 0)
        dans_theme.addLayout(dans_sorte)
        return dans_sorte

    @staticmethod
    def _pli() -> QToolButton:
        """Le triangle d'un thème, sans contour ni fond, pointé vers le bas : déplié."""
        pli = QToolButton()
        pli.setArrowType(Qt.ArrowType.DownArrow)
        pli.setCheckable(True)
        pli.setStyleSheet("QToolButton { border: none; background: transparent; }")
        pli.setCursor(Qt.CursorShape.PointingHandCursor)
        return pli

    @classmethod
    def _largeur_pli(cls) -> int:
        """La largeur du triangle d'un thème, dont les cadres du haut se décalent pour s'aligner sur le nom des thèmes."""
        pli = cls._pli()
        largeur = pli.sizeHint().width()
        pli.deleteLater()
        return largeur

    def _cours_du_theme(self, dans_theme: QVBoxLayout, theme: str, sections: list[tuple[str, list[Entree]]],
                        themes: list[str]) -> None:
        """En tête du thème, « Cours » et un bouton par PDF de cours de ses sujets (l'utilisateur, 06/11/2026 : « il faut
        ajouter un section cours avec les pdf de cours dans chaque thème »), qui l'ouvre dans ``Cours``, lu dans Dropbox
        par ``lire_bilan`` ; sans lui, rien à ouvrir, pas de section. Seuls les cours rangés dans le dossier du thème
        (``du_theme``) : l'essentiel de Python que cite le projet Pyxel reste sous Python [APE-6]."""
        cours = dict.fromkeys(c for _, groupe in sections for e in groupe for c in e.cours  # une fois, dans l'ordre
                              if c[0] in self.pages_vues and du_theme(c[0], theme, themes))
        if not (cours and self.lire_bilan):
            return
        dans_theme.addWidget(titre_de_section(en_titre("Cours", RUBRIQUE), AU_DESSUS["h3"]))
        dans_cours = QVBoxLayout()
        dans_cours.setContentsMargins(RETRAIT_BOUTONS, 0, 0, 0)
        dans_theme.addLayout(dans_cours)
        # le PDF du cours, puis celui de son diaporama juste dessous, au même nom suivi de « (pdf) » et « (diaporama) »
        # (l'utilisateur, 06/11/2026 : « pour le cours il faut les deux bouton l'un au dessus de l'autre avec le même nom
        # qui finit par (pdf) et (diaporama) ») ; les deux s'ouvrent dans la même fenêtre de PDF
        for chemin, titre, diapo in cours:
            for fichier, sorte in ((chemin, "pdf"), (diapo, "diaporama")):
                if not fichier:
                    continue
                # le PDF du cours jusqu'aux pages déjà vues, son diaporama jusqu'à la fin des chapitres qu'elles commencent
                # (``diaporama_par_page`` ; le professeur, 17/11/2026 : ni entier ni caché) ; sans coupe sûre, pas de bouton
                pages = self.pages_vues[chemin] if sorte == "pdf" else limite_du_diaporama(
                    self.pages_vues[chemin], self.diaporamas.get(chemin, ()))
                if pages == 0:
                    continue
                nom = f"{titre} ({sorte})"
                bouton = TitreBouton(QLabel(f"<b>{escape(nom)}</b>"), nom)
                bouton.clicked.connect(lambda _=False, fichier=fichier, nom=nom, pages=pages:
                                       self.ouvrir_cours(fichier, nom, pages))
                dans_cours.addWidget(bouton)
                self.cours[fichier] = bouton

    def ouvrir_cours(self, chemin: str, titre: str, pages: int | None = None) -> None:
        """Lit le PDF dans Dropbox, puis le montre dans sa fenêtre, ses ``pages`` premières pages seules (None : toutes) ;
        un cours introuvable le dit dans la même fenêtre."""
        self.lire_bilan(chemin, lambda octets: self._montrer(Cours(titre, octets, pages=pages)))

    def _montrer(self, fenetre: Cours) -> None:
        """La fenêtre de PDF ``fenetre`` montrée, à la place de la précédente."""
        self.fenetre_cours = fenetre
        # l'écran d'abord : dans le navigateur, une fenêtre neuve agrandie sans taille restait à 0 x 0, PDF lu mais
        # invisible (sonde, W472, 08/11/2026 ; le professeur : les boutons « Cours » ne fonctionnent toujours pas)
        if ecran := QApplication.primaryScreen():
            fenetre.setGeometry(ecran.availableGeometry())
        # plein écran : dans le navigateur, seul cet état dispense une fenêtre Qt de son cadre (icône Qt, titre, boutons ;
        # le professeur, 08/11/2026 21:28) ; « Fermer » et Échap la referment (W496)
        fenetre.showFullScreen()

    def chercher_copie(self, e: Entree, rappel: Callable[[bytes | None], None]) -> None:
        """Rend à ``rappel`` les octets du PDF corrigé de l'élève entré pour ``e`` (``pdfs_de_l_eleve`` : le dossier de sa
        classe, puis celui du sujet), lus dans Dropbox par ``lire_bilan`` ; None s'il n'y en a pas."""
        chemins = pdfs_de_l_eleve(e.dossier_des_copies(), e.nom, e.ligne.classe, self.eleve) if self.lire_bilan else []

        def essai(i: int) -> None:
            if i >= len(chemins):
                rappel(None)
            else:
                def lu(octets: bytes | None, chemin: str = chemins[i]) -> None:
                    if not octets:
                        return essai(i + 1)
                    self.chemins_copies[e.ligne.sujet] = chemin
                    rappel(octets)
                self.lire_bilan(chemins[i], lu)
        essai(0)

    def _activer_si_copie(self, e: Entree, bouton: TitreBouton, texte: TitreDeSujet) -> None:
        """Le bouton d'un DS papier publié rendu pressable dès que la copie corrigée de l'élève est trouvée ; un DS redit
        dans plusieurs thèmes (``PARTIES``) : sa copie lue une seule fois pour tous ses boutons."""
        def recu(octets: bytes | None) -> None:
            if not octets:
                return
            self.copies[e.ligne.sujet] = octets
            try:
                bouton.setEnabled(True)
                if texte.gris == etat_de_copie(e):  # la note du bilan, arrivée avant la copie, reste (W935)
                    texte.poser(texte.nom, "copie corrigée")
            except RuntimeError:  # la page refaite pendant la lecture (en ligne, elle est asynchrone) : rien à montrer
                pass
        if e.ligne.sujet in self.copies:  # déjà lue pour un autre de ses boutons
            return recu(self.copies[e.ligne.sujet])
        attente = self.copies_attendues.setdefault(e.ligne.sujet, [])
        attente.append(recu)
        if len(attente) == 1:
            self.chercher_copie(e, lambda octets: [f(octets) for f in self.copies_attendues.pop(e.ligne.sujet, [])])

    def ouvrir_tp(self, e: Entree, ouvrir: Callable[[Entree], None]) -> None:
        """Un TP pressé par l'élève : sa copie corrigée, si elle est rendue, sinon le TP électronique (``ouvrir``)."""
        self.chercher_copie(e, lambda octets: self.ouvrir_copie(e, octets) if octets else ouvrir(e))

    def ouvrir_copie(self, e: Entree, octets: bytes | None) -> None:
        """La copie corrigée ``octets`` de ``e`` dans la fenêtre de PDF, le cours de son thème à gauche (le sien, sinon le
        premier du thème), lu dans Dropbox ; sans cours, la copie seule."""
        if not octets:
            return
        cours = e.cours[0] if e.cours else self.cours_par_theme.get(e.theme)
        titre = f"{e.nom} - copie corrigée"
        chemin = self.chemins_copies.get(e.ligne.sujet)
        if cours is None or not self.lire_bilan:
            self._montrer(lier_notes(Cours("", None, (titre, octets), page_copie=e.page), octets, self.cle_classe, chemin,
                                     not self.lecture_seule))
        else:
            self.lire_bilan(cours[0], lambda lu: self._montrer(lier_notes(Cours(cours[1], lu, (titre, octets),
                                                                                 pages=self.pages_vues.get(cours[0]),
                                                                                 page_copie=e.page),
                                                                           octets, self.cle_classe, chemin,
                                                                           not self.lecture_seule)))

    def _formulaire_bilan(self, eleve: str) -> None:
        """En bas, les bilans de l'élève, de ses copies, par thème et de l'année (``bilans_widget.Bilan`` ; l'utilisateur,
        06/11/2026 : « les bilans (copie, thème, année) doivent être sur la page d'accueil ») : le mot de passe, s'il faut le
        taper, et le nom et le prénom si cet appareil n'en a retenu aucun."""
        # le titre du formulaire ; le bilan ouvert porte le sien (l'utilisateur, 06/11/2026 : « "Mes bilans", "Bilan de Essai
        # Élève", "établi le ..." ne servent à rien, il faut juste le titre de section "Bilan de l'année" »)
        self.titre_bilan = titre_de_section(en_titre("Bilan de l'année", SECTION), AU_DESSUS["h1"])  # au rang de « Thématiques »
        self.pile.addWidget(self.titre_bilan)
        self.cadre_bilan = QWidget()
        formulaire = QFormLayout(self.cadre_bilan)
        formulaire.setContentsMargins(0, 0, 0, 0)
        nom, prenom = (eleve.split(" ", 1) + [""])[:2] if eleve else ("", "")
        self.nom, self.prenom, self.mot_de_passe = QLineEdit(nom), QLineEdit(prenom), QLineEdit()
        if not eleve:
            formulaire.addRow("Nom", self.nom)
            formulaire.addRow("Prénom", self.prenom)
        self.mot_de_passe.setEchoMode(QLineEdit.EchoMode.Password)
        self.mot_de_passe.returnPressed.connect(self.voir_bilan)
        voir = QPushButton("Voir mon bilan")
        voir.clicked.connect(self.voir_bilan)
        ligne = QHBoxLayout()
        ligne.addWidget(self.mot_de_passe, 1)
        ligne.addWidget(voir)
        formulaire.addRow("Mot de passe", ligne)
        self.message_bilan = QLabel("")
        self.message_bilan.setWordWrap(True)
        formulaire.addRow(self.message_bilan)
        self.pile.addWidget(self.cadre_bilan)

    def _bilans_des_eleves(self, eleves: list[str]) -> None:
        """Au professeur, en bas de la page de la classe, à la place du « Bilan de l'année » de l'élève : le bilan de
        l'élève choisi parmi ``eleves``, tel que l'élève le voit (``bilans_widget.Bilan``) (le professeur, 19/11/2026,
        W792 : « centrée sur le déploiement et la gestion des deadlines et les bilans, vraiment comme les élèves »)."""
        self.pile.addWidget(titre_de_section("<h2>Bilans des élèves</h2>", AU_DESSUS["h1"]))
        self.choix_eleve = QComboBox()
        self.choix_eleve.addItem("Choisir un élève…", "")
        for nom in eleves:
            self.choix_eleve.addItem(nom, nom)
        self.choix_eleve.currentIndexChanged.connect(lambda _: self.voir_bilan_de(self.choix_eleve.currentData()))
        self.pile.addWidget(self.choix_eleve)
        self.message_bilan = QLabel("")
        self.message_bilan.setWordWrap(True)
        self.pile.addWidget(self.message_bilan)

    def voir_bilan_de(self, eleve: str) -> None:
        """Le bilan de ``eleve`` sous le choix, à la place du précédent ; lu comme celui de l'élève (``lire_bilan``)."""
        if self.bilan is not None:
            self.pile.removeWidget(self.bilan)
            self.bilan.hide()
            self.bilan.deleteLater()
            self.bilan = None
        self.message_bilan.setText("Lecture du bilan…" if eleve else "")
        if eleve:
            self.lire_bilan(f"{self.niveau}/Bilans/{bilans_widget.nom_du_fichier(eleve)}",
                            lambda octets: self.bilan_de_recu(eleve, octets))

    def bilan_de_recu(self, eleve: str, octets: bytes | None) -> None:
        """Le bilan lu de ``eleve``, ouvert en clair ou par l'empreinte qu'il a déposée (``bilans_widget.cle_deposee``),
        celle dont le professeur le chiffre ; ou ce qui l'empêche, dit sous le choix."""
        if eleve != self.choix_eleve.currentData():  # un autre élève choisi entre-temps
            return
        if not octets:
            self.message_bilan.setText(f"Pas encore de bilan pour {eleve}.")
            return
        chemin = Path(tempfile.gettempdir()) / f"bilan{bilans_widget.EXTENSION}"
        chemin.write_bytes(octets)
        try:
            bilan = bilans_widget.ouvrir_bilan(str(chemin), bilans_widget.cle_deposee(eleve, self.identites))
        except ValueError:
            self.message_bilan.setText(f"Le bilan de {eleve} est illisible.")
            return
        finally:
            chemin.unlink(missing_ok=True)
        if bilan is None:
            self.message_bilan.setText(f"Le bilan de {eleve} ne s'ouvre pas par l'empreinte qu'il a déposée (mot de passe "
                                       "réinitialisé depuis ?) : il sera refait au prochain calcul des bilans.")
            return
        self.message_bilan.setText("")
        self.bilan = bilan
        self.pile.addWidget(bilan)

    def notes_dans_les_boutons(self, bilan: bilans_widget.Bilan) -> None:
        """La note de chaque copie rendue dans la ligne grise du bouton de son sujet (l'utilisateur, 06/11/2026 : « le bilan
        doit être sur la page d'accueil, avec les notes dans le bouton de chaque copie rendue »). Le sujet d'une copie est celui
        dont le nom, graphie normalisée par ``cle_de``, est le sien : ``epreuve`` est le nom du paquet, dont le .qcm porte le nom
        (``Entree.nom``) ; plusieurs copies du même sujet (un second essai) : la dernière rendue. Pas de « Bilan des copies »
        sur la page d'accueil, même pour une copie sans bouton (l'utilisateur, 06/11/2026 : « suprime la section "Bilan des
        copies" »)."""
        derniere: dict[str, dict[str, Any]] = {}
        for p in bilan.parcours:  # dans l'ordre de leur rendu : la dernière écrase, sauf une copie pas finie qui suit une
            # copie finie (l'ancienne copie d'un TP migré, « TP01 OLD », du même nom : le professeur, 22/11/2026, [APE-19] :
            # « le TP01 python est  fini . pourquoi est-il ecrit "à finir" et sa jauge n'est pas complète »)
            cle = cle_de(sans_essai(p["epreuve"]))
            if not (finie(derniere.get(cle)) and not finie(p)):
                derniere[cle] = p
        for e, texte, gris in self.textes:
            cle = next((c for c in (cle_de(e.nom), cle_de(e.ligne.sujet)) if c in derniere), None)
            if cle is None:
                continue
            # une copie finie : sa note sans son échéance (le professeur, 22/11/2026, [APE-14] : « le TP trois montre sa
            # note, mais il est inutile d'afficher les échances pour des copies finies ! »)
            # un DS papier publié : sa note seule, rendu ou pas au sens du bilan (W935) ; pas publié : sa raison reste ; « si
            # c'est fermé, il faut juste mettre la note » (l'utilisateur, 06/11/2026)
            if e.publiee if e.papier else e.etat == FERME or finie(derniere[cle]):
                gris = ""
            note = bilan.note_de_copie(derniere[cle])
            if e.papier and not note:  # au bilan sans date ni note : « copie corrigée », si elle est trouvée, reste ; datée
                # et pas notée, « en attente de correction » le dit, sans être masqué
                continue
            if e.papier and e.theme != DEVOIRS and (du_theme := bilan.note_du_theme(derniere[cle], e.theme)):
                note += f", {du_theme}"  # le DS dans un de ses thèmes ([APE-20]) ; entier sous DEVOIRS : sa note seule
            texte.poser(texte.nom, " · ".join(filter(None, (gris, note))))
            # une copie pas rendue (un TP ne se rend pas) : son avancement sous le titre (W826), lu à chaque bilan ; rendue :
            # plus de jauge, même la jauge vide d'avant sa copie ([APE-15])
            if isinstance(bouton := texte.parentWidget(), TitreBouton):
                if derniere[cle].get("fin") is None and derniere[cle].get("avancements"):
                    bouton.poser_jauges(derniere[cle]["avancements"])
                elif derniere[cle].get("fin") is not None:
                    bouton.retirer_jauges()
        # une copie rendue, même depuis un autre appareil, sort de « À faire » (W695, 16/11/2026), une révision jamais ; une
        # copie en cours (``fin`` vide : le bilan lit aussi les TP pas encore rendus) y reste, sinon le cadre « À finir à la
        # maison » paraissait puis disparaissait à l'arrivée du bilan (le professeur, 18/11/2026, W782) ; une copie dont toutes
        # les questions obligatoires sont closes est finie, rendue ou pas (le professeur, 21/11/2026, [APE-8] : « pourquoi
        # est-il dans "à finir à la maison" alors qu'il est terminé ? »)
        rendues = {c for c, p in derniere.items() if p.get("fin") is not None or p.get("terminee")}
        rendus = [(e, bouton, cadre) for e, bouton, cadre in self.a_faire
                  if zone_de(e) != REVISER and (cle_de(e.nom) in rendues or cle_de(e.ligne.sujet) in rendues)]
        for e, bouton, _ in rendus:
            bouton.hide()
            if (dans_theme := self.boutons.get(e.ligne.sujet)) not in (None, bouton):  # son bord de couleur aussi
                dans_theme.setStyleSheet("")
        for cadre in {id(c): c for _, _, c in rendus}.values():
            cadre.setVisible(any(not b.isHidden() for _, b, c in self.a_faire if c is cadre))
        if rendus and self.titre_a_faire is not None:
            self.titre_a_faire.setVisible(any(not c.isHidden() for _, _, c in self.a_faire))
        bilan.garder_copies([])

    def bilans_dans_les_themes(self, bilan: bilans_widget.Bilan) -> None:
        """Le bilan de chaque thème sous le titre de sa section (l'utilisateur, 06/11/2026 : « il faut un bilan dans chaque
        section thématique »), sous les boutons de « Réviser » (« ce qui se trouve dans Bilan, doit plutôt se trouver dans réviser ») : le thème de l'arbre est celui de la section au nom près (``cle_de``). Le
        « Bilan par thème » du bilan ne garde que les thèmes sans section."""
        noeuds = {cle_de(n[0]): n for n in bilan.arbre}
        utilises: set[str] = set()
        for nom, _ in self.themes:
            cle = cle_de(nom)
            if cle not in noeuds:
                continue
            utilises.add(cle)
            boite, dans_reviser = self.reviser[nom]  # sous les boutons de révision, sans titre à lui
            if boite is not None:
                boite.show()
            dans_reviser.addWidget(self._grille_du_bilan(nom, bilan.rangs(noeuds[cle]), noeuds[cle][0], bool(noeuds[cle][4]),
                                                         noeuds[cle][3]))
            if bilan.provisoire:  # des révisions faites depuis le passage du professeur y sont comptées (W457)
                mention = QLabel(f"<i>{bilans_widget.PROVISOIRE}</i>")
                mention.setWordWrap(True)
                dans_reviser.addWidget(mention)
        bilan.garder_themes([n for n in bilan.arbre if cle_de(n[0]) not in utilises])

    @staticmethod
    def _taille_de_profondeur(widgets: Iterable[QWidget], profondeur: int) -> None:
        """Police décroissante avec la profondeur dans l'arbre du bilan, le bouton « Réviser » à la taille de son libellé
        (le professeur, 19/11/2026, W807 : « dasn l'arboresscenc peut ton avoir une teille de police decroissante en
        fonction de la profondeur ? (évec le bouton reviser qui soit la taille de la police) ») : 115 % pour le thème, 12
        points de moins par niveau, jamais sous 80 %."""
        facteur, base = max(0.8, 1.15 - 0.12 * profondeur), QApplication.font()
        for widget in widgets:
            police = widget.font()
            if base.pointSizeF() > 0:
                police.setPointSizeF(base.pointSizeF() * facteur)
            else:  # une police en pixels (pointSizeF vaut -1)
                police.setPixelSize(max(1, round(base.pixelSize() * facteur)))
            widget.setFont(police)

    def _grille_du_bilan(self, theme: str, rangs: list[tuple[int, str, float | None]], racine: str = "",
                         detail: bool = True, taux_du_theme: float | None = None) -> QWidget:
        """Le bilan d'un thème en grille : le libellé en retrait selon son niveau, sa jauge, et un bouton « Réviser » par
        section et sous-section (l'utilisateur, 06/11/2026 : « ajoute le bouton de révision par section et sous-section »).
        Largeur bornée : les colonnes des jauges et des boutons tombent au même bord d'un thème à l'autre, et la grille se
        resserre sur un téléphone, le libellé revenant à la ligne. Chaque rang a son chemin dans l'arbre (``racine``, le thème
        de l'arbre, puis ses parents ; sans ``detail``, le thème seul) : « Réviser » ouvre son entraînement, et « Validation »,
        à côté, son questionnaire de Validation s'il est déposé (l'utilisateur, 06/11/2026 17:41)."""
        grille = QWidget()
        disposition = QGridLayout(grille)
        disposition.setContentsMargins(0, 0, 0, 0)
        disposition.setColumnStretch(0, 1)
        disposition.setVerticalSpacing(0)  # les traits de l'arbre d'un rang à l'autre, sans coupure
        message = QLabel("")
        message.setWordWrap(True)
        message.hide()
        parents = [racine or theme]
        # « Réviser » du thème entier, en tête de la grille (le professeur, 19/11/2026, W807 : « il faut un bouton de
        # revistion par thématique. pas juste sur les sections ») : le chemin du thème seul compose sur tout le thème
        # (sans ``detail``, le seul rang est déjà le thème)
        # chaque titre est le bouton de sa révision : transparent, gris au survol, d'un peu après la branche à un peu avant
        # la jauge ; plus de bouton « Réviser » à droite ; « Tout le thème » a sa jauge et n'est plus en gras (le
        # professeur, 21/11/2026, [COS-6] à [COS-8]) ; la racine : le titre du thème seul ([COS-29])
        if detail:
            tout = TitreDeRevision(theme)  # le thème seul, sans « Tout le thème » ([COS-29])
            tout.clicked.connect(lambda _=False: self.reviser_notion(theme, racine or theme, message, (racine or theme,)))
            self._taille_de_profondeur((tout, tout.texte), 0)
            disposition.addWidget(tout, 0, 0)
            disposition.addWidget(self._jauge_de(taux_du_theme, theme, racine or theme, message, (racine or theme,)), 0, 1,
                                  Qt.AlignmentFlag.AlignVCenter)
            self.boutons_reviser.append((theme, racine or theme, tout))
        for rang, ((niveau, libelle, taux), (suites, dernier)) in enumerate(zip(rangs, branches([r[0] for r in rangs])), int(detail)):
            parents[1 + niveau:] = [libelle] if detail else []
            chemin = tuple(parents)
            bouton = TitreDeRevision(libelle)
            ligne = QHBoxLayout()
            ligne.setContentsMargins(0, 0, 0, 0)
            ligne.setSpacing(4)
            ligne.addWidget(Branches(suites, dernier))
            ligne.addWidget(bouton, 1)
            disposition.addLayout(ligne, rang, 0)
            disposition.addWidget(self._jauge_de(taux, theme, libelle, message, chemin), rang, 1, Qt.AlignmentFlag.AlignVCenter)
            bouton.clicked.connect(lambda _=False, libelle=libelle, chemin=chemin:
                                   self.reviser_notion(theme, libelle, message, chemin))
            self._taille_de_profondeur((bouton, bouton.texte), niveau + int(detail))
            self.boutons_reviser.append((theme, libelle, bouton))
        disposition.addWidget(message, len(rangs) + int(detail), 0, 1, 2)
        grille.setMaximumWidth(bilans_widget.PALIER + bilans_widget.LIBELLES + bilans_widget.JAUGE
                               + disposition.horizontalSpacing())
        return grille

    def _jauge_de(self, taux: float | None, theme: str, libelle: str, message: QLabel, chemin: tuple[str, ...]) -> QWidget:
        """La jauge de la section ``chemin``, pressée, déroule son historique (``historique``) : les séries lancées depuis son
        titre, sous ses questions déjà répondues ([APE-7]) ; elle remplace le petit triangle à sa droite (le professeur,
        22/11/2026, [APE-12] : « elle doivent ouvrir l'historique et il faut suprimer le bouton actuel pour l'historique »).
        Le menu se remplit à chaque déroulé ; « en attente » (aucun bilan) se presse aussi."""
        bouton = JaugeDeRevision(taux)
        menu = QMenu(bouton)
        menu.aboutToShow.connect(lambda: self.historique(menu, theme, libelle, chemin, message))
        bouton.setMenu(menu)
        self.historiques.append((theme, libelle, bouton))
        return bouton

    def historique(self, menu: QMenu, theme: str, libelle: str, chemin: tuple[str, ...], message: QLabel) -> None:
        """Le menu de la jauge de « Réviser » ``chemin`` : une ligne par série lancée depuis son titre (``series``, même section ;
        le thème entier, ou une copie sans section), qui ROUVRE cette série telle quelle (``Entree.essai``), sans passer à la
        suivante ni la recomposer ; « Aucune série » sinon. Le thème entier montre d'abord les séries de ses anciennes
        révisions (``ancienne_revision``), essais faits avant le « Réviser », chacune rouverte telle quelle ([COS-3]). Tout
        en haut, avant un trait, ``REVOIR`` : les questions de la section déjà répondues ([APE-7]), que la jauge ouvrait
        (le professeur, 22/11/2026, [APE-12] : « la copie qui regroupe devrait être tout en hau »)."""
        menu.clear()
        menu.addAction(REVOIR).triggered.connect(
            lambda: self.reviser_notion(theme, libelle, message, (*chemin, REPONDUES)))
        menu.addSeparator()
        for ancienne in self.anciennes_revisions if len(chemin) == 1 else []:
            if (ancienne.theme or AUTRES) == (theme or AUTRES):
                for essai, texte in self.series(ancienne):
                    nom = nom_dans_le_theme(ancienne.nom.replace("_", " "), ancienne.theme)  # « Python_-_Revision_08… » : le nom de fichier
                    menu.addAction(f"{nom} — {texte}").triggered.connect(
                        lambda _=False, choisie=replace(ancienne, essai=essai): self.ouvrir_revision(choisie))
        connu = reviser(self.revisions, chemin or (theme, libelle), self.niveau)
        entree = connu and self._entree_de_revision(connu, chemin or (theme, libelle))
        for essai, texte in self.series(entree) if entree else []:
            menu.addAction(texte).triggered.connect(lambda _=False, essai=essai: self.ouvrir_revision(replace(entree, essai=essai)))
        if len(menu.actions()) == 2:
            menu.addAction("Aucune série").setEnabled(False)

    def reviser_notion(self, theme: str, libelle: str, message: QLabel, chemin: tuple[str, ...] = ()) -> None:
        """Le sujet « Réviser » de la section ``chemin`` (``reviser`` : celui de son thème), ouvert comme un sujet du
        tableau ; aucun de déposé : le message le dit."""
        if entree := reviser(self.revisions, chemin or (theme, libelle), self.niveau):
            self.ouvrir_revision(self._entree_de_revision(entree, chemin or (theme, libelle)))
            return
        message.setText(f"Réviser « {libelle} » ({theme}) : pas encore de révision en ligne pour cette section.")
        message.show()

    def _entree_de_revision(self, connu: dict[str, Any], section: tuple[str, ...] = ()) -> Entree:
        """Un sujet de « Réviser » comme une ligne du tableau, ouverte à tout moment et sans code de classe : ``ouvrir`` ne
        lit que son lien, son jeton (le code de la classe, que le catalogue donne s'il l'inscrit) et ``section``, la section
        pressée, seule à composer le questionnaire (W754)."""
        return Entree(Ligne(connu.get("nom", ""), self.classe_revision, None, None, None), EN_COURS, connu["lien"], connu.get("nom", ""),
                      connu.get("jeton", ""), section=tuple(section))

    def eleve_du_formulaire(self) -> str:
        return f"{self.nom.text().strip()} {self.prenom.text().strip()}".strip()

    def voir_bilan(self) -> None:
        eleve = self.eleve_du_formulaire()
        if not eleve:
            self.message_bilan.setText("Votre nom et votre prénom, puis Entrée.")
            return
        self.message_bilan.setText("Lecture du bilan…")
        self.lire_bilan(f"{self.niveau}/Bilans/{bilans_widget.nom_du_fichier(eleve)}", self.bilan_recu)

    def bilan_recu(self, octets: bytes | None) -> None:
        if not octets:
            self.message_bilan.setText("Pas encore de bilan pour vous : le professeur le dépose après les premières notes.")
            return
        chemin = Path(tempfile.gettempdir()) / f"bilan{bilans_widget.EXTENSION}"
        chemin.write_bytes(octets)
        tape = self.mot_de_passe.text()
        try:
            cle = bilans_widget.cle_deposee(self.eleve, self.identites) if self.lecture_seule else \
                bilans_widget.cle_du_secret(self.secret, self.identites)
            bilan = bilans_widget.ouvrir_bilan(str(chemin), cle)
            if bilan is None and tape:
                bilan = bilans_widget.ouvrir_par_mot_de_passe(str(chemin), self.eleve_du_formulaire(), tape, self.identites)
        except ValueError:
            self.message_bilan.setText("Ce bilan est illisible : signalez-le au professeur.")
            return
        finally:
            chemin.unlink(missing_ok=True)
        if bilan is None:
            self.message_bilan.setText(bilans_widget.REFUS if tape else "Tapez votre mot de passe.")
            return
        self.mot_de_passe.clear()
        self.bilan = bilan  # à la place du formulaire : le mot de passe ne sert plus
        self.pile.replaceWidget(self.cadre_bilan, bilan)
        self.notes_dans_les_boutons(bilan)
        self.bilans_dans_les_themes(bilan)
        self.titre_bilan.hide()
        bilan.sans_entete()
        self.cadre_bilan.hide()  # hors de la pile, il resterait peint en haut jusqu'à sa destruction
        self.cadre_bilan.deleteLater()


def sans_essai(epreuve: str) -> str:
    """Le nom d'une épreuve sans son « (2e essai) » (``bilans.copie_du_paquet``) : celui de son sujet."""
    return re.sub(r" \(\d+e essai\)$", "", epreuve)


def lire_catalogue(cat: dict[str, Any] | str | None) -> dict[str, Any]:
    """tableau.json lu ; illisible ou absent : comme vide, sans bouton ni classe."""
    if isinstance(cat, str):
        try:
            cat = json.loads(cat)
        except ValueError:
            cat = None
    if not isinstance(cat, dict) or not isinstance(cat.get("sujets"), dict):
        cat = {"sujets": {}}
    if not isinstance(cat.get("classes"), dict):
        cat["classes"] = {}
    if not isinstance(cat.get(PAPIER), dict):
        cat[PAPIER] = {}
    return cat


def construire(classe: str, texte: str | None, cat: dict[str, Any] | str | None, ouvrir: Callable[[Entree], None],
               commencee: Callable[[str], bool] = lambda nom: False, maintenant: datetime | None = None, eleve: str = "",
               lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None, professeur: bool = False,
               secret: bytes | None = None, identites: dict[str, Any] | None = None,
               jetons: dict[str, str] | None = None, regler: Callable[[str, str, dict[str, str]], None] | None = None,
               message: str = "", effectives: Effectives | None = None, rebatir: Callable[[], None] | None = None,
               publier: Callable[[str, str, bool], None] | None = None, eleves: list[str] | None = None,
               series: Callable[[Entree], list[tuple[int, str]]] | None = None, lecture_seule: bool = False) -> Tableau:
    """Le tableau à partir des textes des deux fichiers (None : absent, le tableau est vide). Les erreurs du fichier
    d'échéances : toutes au professeur, à l'élève celles des lignes de sa classe seulement. Sans ``effectives``, une case
    vide des réglages montre ``valeurs_par_defaut`` à la durée du sujet que porte le catalogue. ``series`` : l'historique
    d'un « Réviser » (``Tableau``), à l'élève seulement."""
    cat = lire_catalogue(cat)
    if effectives is None:
        def effectives(sujet: str, _classe: str) -> dict[str, str]:
            return valeurs_par_defaut(du_catalogue(cat["sujets"], sujet)[1].get("duree"))
    lignes, erreurs = lire_echeances(texte or "")
    if not professeur:  # une ligne réservée (case ``eleves``, un rattrapage) : son bouton chez les seuls élèves visés
        lignes = [l for l in lignes if not l.eleves or eleve and echeances.empreinte_eleve(eleve) in l.eleves]
    # le nom de la classe tel que le professeur l'écrit, pas tel que l'adresse le porte (« 2nd_5 »)
    classe = next((ligne.classe for ligne in lignes if meme_classe(ligne.classe, classe)), classe)
    if not professeur:
        erreurs = [e for e in erreurs if e.classe and meme_classe(e.classe, classe)]
    maintenant = maintenant or datetime.now(timezone.utc)
    return Tableau(classe, entrees(lignes, cat, classe, maintenant, jetons), ouvrir, commencee, erreurs,
                   eleve, lire_bilan, professeur, secret, identites, texte, regler if professeur else None, message,
                   effectives=effectives,  # « Réviser » : les sujets du catalogue, avec le code de la classe s'il en a un
                   revisions={k: {**v, "jeton": (jetons or {}).get(k, "")} for k, v in cat["sujets"].items() if isinstance(v, dict)},
                   maintenant=maintenant, rebatir=rebatir, publier=publier if professeur else None,
                   eleves=eleves if professeur else None, series=None if professeur else series,
                   lecture_seule=lecture_seule and not professeur)


class AttenteEpreuve(QWidget):
    """L'écran VERT qui précède une épreuve (``EPREUVES``) : pendant les 30 min (``APPARITION``) avant une épreuve
    ``en_seance``, « L'interrogation commence dans 12 min 05 s », à la seconde, sans la page ni le cours (le professeur,
    17/11/2026 00:34 : « au lieu d'un écran noir », où les élèves se croient bannis ou figés ; confirmé 00:39) ; puis, avec
    ``commencer``, les règles (``REGLES_EPREUVE``) et le bouton « Commencer », actif au début, dont le clic seul ouvre
    l'épreuve, en plein écran, et lance son chronomètre (le professeur, 20/11/2026 12:57, W826 : « ils risquent de cliquer
    dessus juste pour voir si ça lance bien » ; 13:04 : « fusionner avec l'écran d'attente »). ``retour`` : le bouton
    « Retour à la page », pour l'épreuve ouverte depuis la page (``Portail.confirmer``)."""

    def __init__(self, e: Entree, horloge: Callable[[], datetime], commencer: Callable[[], None] | None = None,
                 retour: Callable[[], None] | None = None) -> None:
        super().__init__()
        self.e, self.horloge = e, horloge
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.setStyleSheet("AttenteEpreuve { background: #2e7d32; } QLabel { color: white; }"
                           " QPushButton { background: white; color: black; padding: 10px 30px; font-size: x-large; }")
        disposition = QVBoxLayout(self)
        disposition.addStretch()
        self.titre = QLabel(f"<span style='font-size:xx-large'><b>{escape(e.nom)}</b></span>")
        self.texte = QLabel()
        for etiquette in (self.titre, self.texte):
            etiquette.setAlignment(Qt.AlignmentFlag.AlignCenter)
            etiquette.setWordWrap(True)
            disposition.addWidget(etiquette)
        self.commencer = None
        if commencer is not None:
            regles = QLabel(f"<span style='font-size:large'>{REGLES_EPREUVE}</span>")
            regles.setWordWrap(True)
            regles.setMaximumWidth(900)
            disposition.addWidget(regles, alignment=Qt.AlignmentFlag.AlignHCenter)
            self.commencer = QPushButton("Commencer")
            self.commencer.clicked.connect(commencer)
            disposition.addWidget(self.commencer, alignment=Qt.AlignmentFlag.AlignHCenter)
        if retour is not None:
            self.retour = QPushButton("Retour à la page")
            self.retour.clicked.connect(retour)
            disposition.addWidget(self.retour, alignment=Qt.AlignmentFlag.AlignHCenter)
        disposition.addStretch()
        self.minuterie = QTimer(self)
        self.minuterie.timeout.connect(self.battre)
        self.minuterie.start(1000)
        self.battre()

    def battre(self) -> None:
        reste = self.e.ligne.debut - self.horloge() if self.e.ligne.debut else timedelta(0)
        qui = QUI_COMMENCE.get(self.e.type, "L'épreuve")
        commencee = reste <= timedelta(0)
        self.texte.setText(f"<span style='font-size:xx-large'>{qui} {'peut commencer' if commencee else decompte(reste)}</span>")
        if self.commencer is not None:
            self.commencer.setEnabled(commencee)
        if commencee:
            self.minuterie.stop()


class Portail(QStackedWidget):
    """La page d'une classe : l'entrée (prénom, nom, mot de passe, vérifiés par ``identifier`` sur la
    liste chiffrée de la classe et le fichier d'empreintes ``identites``), puis son ``Tableau``. ``retenu()`` rend
    ``(nom, prénom, code)`` retenus par cet appareil, le code étant le secret (``bytes``) de l'élève entré par son mot de
    passe, ``retenir(…)`` les retient (``None`` : les oublie) : le navigateur d'un élève n'est pas partagé (l'utilisateur,
    26/10/2026), l'élève revient sans retaper. ``deposer(entree)`` : l'empreinte d'une
    première visite, à ajouter au fichier d'empreintes. ``commencee(nom, identite)`` : une copie de ce sujet par cet
    élève est dans cet appareil. ``regler`` (``Regler`` : ``regler_sur_disque``, ou ``regler_par`` en ligne) : ce qui
    écrit dans echeances.csv les réglages du professeur ; sans lui, ni bouton « Réglages » ni panneau. ``series(entree,
    identite)`` : les séries d'un « Réviser » de cet élève dans cet appareil (``Tableau.historique``). Les autres paramètres
    sont ceux de ``construire`` (``effectives`` compris)."""

    def __init__(self, classe: str, texte: str | None, cat: dict[str, Any] | str | None, cle: str,
                 ouvrir: Callable[[Entree], None], commencee: Callable[[str, Identite], bool] = lambda nom, qui: False,
                 retenu: Callable[[], tuple[str, str, str | bytes] | None] = lambda: None,
                 retenir: Callable[[tuple[str, str, str | bytes] | None], None] = lambda valeur: None,
                 maintenant: datetime | None = None,
                 lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None,
                 identites: dict[str, Any] | None = None, deposer: Callable[[dict[str, str]], None] = lambda entree: None,
                 regler: Regler | None = None, parent: QWidget | None = None, effectives: Effectives | None = None,
                 publier: Publier | None = None,
                 series: Callable[[Entree, Identite], list[tuple[int, str]]] = lambda entree, qui: [],
                 copie_deposee: Callable[[str], bool] = lambda chemin: False,
                 ouvrir_copie: Callable[[Entree, str | None], None] | None = None,
                 sujet_depose: Callable[[str], bool] = lambda lien: True,
                 ouvertes_d_emblee: MutableSet[str] | None = None) -> None:
        super().__init__(parent)
        self.series = series
        # ``sujet_depose(lien)`` : le .qcm de ce lien est dans le dossier Dropbox ; l'épreuve en séance ne s'ouvre
        # d'emblée que s'il y est (IP-1, W848). Au bureau, le disque ; sur le web, inconnu ici : vrai, et la page du
        # sujet dit « introuvable » (page.html)
        self.sujet_depose = sujet_depose
        # la vue élève du professeur (``voir_comme``, W814) : ``copie_deposee(chemin)``, la copie de ce chemin du dossier
        # Dropbox existe ; ``ouvrir_copie(entree, chemin)`` l'ouvre EN LECTURE SEULE (``None`` : le sujet vierge)
        self.copie_deposee, self.ouvrir_copie = copie_deposee, ouvrir_copie
        self.classe, self.texte, self.cat, self.cle, self.regler_fichier = classe, texte, lire_catalogue(cat), cle, regler
        self.publier_fichier = publier  # ``publier_sur_disque`` : le réglage de publication des corrigés d'un DS papier
        self.effectives = effectives
        self.ouvrir, self.commencee, self.retenu, self.retenir = ouvrir, commencee, retenu, retenir
        self.maintenant, self.lire_bilan, self.identites, self.deposer = maintenant, lire_bilan, identites or {}, deposer
        self.identite: Identite | None = None
        self.garde: tuple[str, str, bytes] | None = None  # l'élève que l'appareil a retenu par son mot de passe
        self.premiere = False  # l'élève nommé en est à sa première visite : son mot de passe s'affiche (``voir_premiere_visite``)
        self.inscrits: list[list[str]] | None = None  # la liste de la classe, déchiffrée une fois (``voir_premiere_visite``)
        self.tableau: Tableau | None = None
        # les épreuves déjà ouvertes sans passer par la page (``en_seance``), le temps du programme ; la page web, refaite à
        # chaque retour de l'épreuve, passe celles de l'onglet (``pont_tableau.Emblee``, IP-1, W870)
        self.ouvertes_d_emblee: MutableSet[str] = set() if ouvertes_d_emblee is None else ouvertes_d_emblee
        self.setWindowTitle(f"SmartTeacher - {classe}")
        self.connexion = QWidget()
        feuille_de_page(self.connexion)
        pile = QVBoxLayout(self.connexion)
        pile.setContentsMargins(24, 16, 24, 16)
        pile.addStretch(1)
        logo = QLabel()
        logo.setPixmap(QIcon(str(LOGO_APPLI)).pixmap(96, 96))
        pile.addWidget(logo, 0, Qt.AlignmentFlag.AlignHCenter)
        entete = QLabel(f"<h1>SmartTeacher</h1><h2>{titre_de_page(classe, niveau_de(classe, []))}</h2>")
        entete.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(entete)
        formulaire = QFormLayout()
        self.prenom, self.nom, self.personnel = QLineEdit(), QLineEdit(), QLineEdit()
        self.personnel.setEchoMode(QLineEdit.EchoMode.Password)
        self.prenom.editingFinished.connect(self.voir_premiere_visite)
        self.nom.editingFinished.connect(self.voir_premiere_visite)
        formulaire.addRow("Prénom", self.prenom)
        formulaire.addRow("Nom", self.nom)
        formulaire.addRow("Mot de passe", self.personnel)
        pile.addLayout(formulaire)
        self.bouton_entrer = QPushButton("Entrer")
        self.bouton_entrer.clicked.connect(self.entrer)
        self.personnel.returnPressed.connect(self.entrer)
        pile.addWidget(self.bouton_entrer, 0, Qt.AlignmentFlag.AlignHCenter)
        self.message = QLabel("")
        self.message.setWordWrap(True)
        self.message.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(self.message)
        pile.addStretch(2)
        self.addWidget(self.connexion)
        if valeur := retenu():  # ce que l'appareil a retenu, pré-rempli et essayé d'emblée
            self.nom.setText(valeur[0])
            self.prenom.setText(valeur[1])
            if isinstance(valeur[2], bytes):
                self.garde = valeur
            else:
                self.personnel.setText(valeur[2])
            if valeur[2]:
                self.entrer()
            else:  # un nom seul (retenu d'avant les mots de passe) : l'élève tape le sien
                self.voir_premiere_visite()

    def voir_premiere_visite(self) -> None:
        """À sa première visite, l'élève ne tape son mot de passe qu'une fois : le champ l'affiche et le message le dit ;
        sinon il est masqué. La liste se déchiffre une seule fois, quand le nom est complet : ce déchiffrement est lent."""
        nom, prenom = self.nom.text().strip(), self.prenom.text().strip()
        if nom and prenom and self.inscrits is None and self.cle:
            chiffree = self.cat["classes"].get(cle_de(self.classe))
            liste = chiffree and ouvrir_liste(chiffree, self.cle)
            self.inscrits = liste["inscrits"] if liste else None
        premiere = bool(self.inscrits) and codes.premiere_visite(self.identites, self.inscrits, nom, prenom, self.garde)
        if premiere != self.premiere:
            self.premiere = premiere
            self.personnel.setEchoMode(QLineEdit.EchoMode.Normal if premiere else QLineEdit.EchoMode.Password)
            self.message.setText(codes.PREMIERE_VISITE if premiere else "")

    def entrer(self) -> None:
        nom, prenom, code = self.nom.text(), self.prenom.text(), self.personnel.text()
        chiffree = self.cat["classes"].get(cle_de(self.classe))
        identite = identifier(chiffree, self.cle, nom, prenom, code, self.identites, self.garde) if chiffree \
            else sans_liste(self.cat, self.classe)
        if isinstance(identite, str):
            if identite == codes.GARDE_PERIMEE:  # retenue d'avant une réinscription : le mot de passe d'aujourd'hui
                self.garde = None
                self.retenir(None)
                self.voir_premiere_visite()
                if self.premiere:  # réinitialisé : il en choisit un autre, le message est déjà là
                    return
            self.message.setText(f"<span style='color:#c0392b'>{escape(identite)}</span>")
            return
        self.identite = identite
        if identite.depot:
            self.deposer(identite.depot)
            codes.ajouter_depot(self.identites, identite.depot)  # plus une première visite
        # le mot de passe professeur ne s'écrit nulle part, même dans le navigateur : il le retape ; celui d'un élève non
        # plus, c'est son secret qui est retenu
        self.retenir(None if identite.professeur else (identite.nom, identite.prenom, identite.secret))
        self.personnel.clear()
        self.message.clear()
        self.montrer_tableau()

    def montrer_tableau(self, message: str = "") -> None:
        """Le tableau de l'élève ou du professeur entré, fait (ou refait, après un réglage) sur ``texte``."""
        identite = self.identite
        if self.tableau is not None:
            if self.maintenant is not None:  # une heure figée (essai) avance avec la page refaite
                self.maintenant = self.tableau.horloge()
            self.removeWidget(self.tableau)
            self.tableau.deleteLater()
        if not identite.lecture_seule:
            commencee, series = lambda nom_sujet: self.commencee(nom_sujet, identite), lambda entree: self.series(entree, identite)

            def ouvrir(e: Entree) -> None:  # une épreuve pas encore commencée : d'abord son écran, « Commencer » (``confirmer``)
                self.confirmer(e, retour=True) if self.a_confirmer(e, commencee) else self.ouvrir(e)
        else:  # ses copies déposées dans Dropbox, celles que la page de l'élève lit, sans rien écrire
            def ouvrir(e: Entree) -> None:
                if self.ouvrir_copie is not None:
                    self.ouvrir_copie(e, self.copie_de(e.lien, e.nom))

            def commencee(nom_sujet: str) -> bool:
                # ``nom_sujet`` (``Entree.nom``) peut être à deux niveaux : la copie n'est déposée que sous le lien du sien
                return any(self.copie_de(str(e.get("lien", "")), nom_sujet) is not None for c, e in self.cat["sujets"].items()
                           if isinstance(e, dict) and c.rpartition("/")[2] == cle_de(nom_sujet))

            def series(entree: Entree) -> list[tuple[int, str]]:
                copie = self.copie_de(entree.lien, entree.nom)
                return self.series(replace(entree, lien=copie), identite) if copie else []
        self.tableau = construire(self.classe, self.texte, self.cat, ouvrir, commencee, self.maintenant, identite.eleve,
                                  self.lire_bilan, identite.professeur, identite.secret, self.identites, identite.jetons,
                                  self.regler if self.regler_fichier else None, message, self.effectives,
                                  rebatir=self.montrer_tableau,
                                  publier=self.publier_corriges if self.publier_fichier else None,
                                  eleves=self.eleves_de_la_classe() if identite.professeur else None,
                                  series=series, lecture_seule=identite.lecture_seule)
        self.tableau.cle_classe = self.cle
        self.addWidget(self.tableau)
        self.setCurrentWidget(self.tableau)
        epreuve, attente = self.tableau.epreuve, self.tableau.attente
        for e in (epreuve, attente):
            if e is not None and e.ligne.sujet not in self.ouvertes_d_emblee and not self.sujet_depose(e.lien or e.lien_au_debut):
                # un lecteur lancé sur un fichier absent, une page web « introuvable » : la page et pourquoi, rien d'autre ;
                # pas marquée ouverte, elle s'ouvre à la page refaite (``_battre``) qui la trouve déposée
                self.tableau.message.setText(SUJET_ABSENT.format(e.nom))
                self.tableau.message.setVisible(True)
                epreuve, attente = (None, attente) if e is epreuve else (epreuve, None)
        if epreuve is not None and epreuve.ligne.sujet not in self.ouvertes_d_emblee:  # une fois : l'élève qui en revient voit la page
            self.ouvertes_d_emblee.add(epreuve.ligne.sujet)
            self.confirmer(epreuve) if not identite.lecture_seule and self.a_confirmer(epreuve, commencee) else ouvrir(epreuve)
        elif attente is not None and attente.ligne.sujet not in self.ouvertes_d_emblee:
            # la page derrière l'écran d'attente : son minuteur la refait au début (``Tableau._battre``), et l'écran de
            # l'épreuve en séance prend sa place, « Commencer » actif
            self.confirmer(attente, commencer=not identite.lecture_seule and self.a_confirmer(attente, commencee))

    def a_confirmer(self, e: Entree, commencee: Callable[[str], Any]) -> bool:
        """``e`` est une épreuve électronique (``EPREUVES`` : DS, interrogation, mini-interrogation) que l'élève n'a pas
        commencée dans cet appareil : elle s'ouvre par « Commencer » (``confirmer``), jamais par le seul bouton de la page
        (le professeur, 20/11/2026 13:05, W826 : « tous »)."""
        return not self.identite.professeur and e.type in EPREUVES and not e.papier and bool(e.lien or e.lien_au_debut) \
            and not commencee(e.nom)

    def confirmer(self, e: Entree, retour: bool = False, commencer: bool = True) -> None:
        """L'écran vert de ``e`` (``AttenteEpreuve``) devant la page : « Commencer » (``commencer``) ouvre l'épreuve dans
        son clic, le seul geste qui accorde le plein écran au navigateur ; « Retour à la page » (``retour``, l'épreuve
        ouverte depuis la page) le retire ; la page refaite (``montrer_tableau``) l'emporte."""
        def fermer() -> None:
            self.setCurrentWidget(self.tableau)
            self.removeWidget(ecran)
            ecran.deleteLater()

        def lancer() -> None:  # au début, le lien de l'épreuve à venir, même si la page ne l'a pas encore pris (``_battre``)
            self.ouvrir(replace(e, lien=e.lien or e.lien_au_debut))
            fermer()
        ecran = AttenteEpreuve(e, self.tableau.horloge, lancer if commencer else None, fermer if retour else None)
        self.addWidget(ecran)
        self.setCurrentWidget(ecran)
        self.tableau.destroyed.connect(ecran.deleteLater)

    def entrer_professeur(self) -> None:
        """Le tableau du professeur d'emblée, sans entrée : la fenêtre « Gérer les sujets » (``Gestion``), sur la machine où
        se lit le mot de passe professeur (``codes.professeur``), qui ne s'écrit ni ne se tape ici."""
        self.identite = Identite("", "", professeur=True)
        self.montrer_tableau()

    def voir_comme(self, inscrit: tuple[str, str] | None) -> None:
        """Le professeur voit la page comme l'élève ``inscrit`` (nom, prénom de la liste) la voit : ses sujets, ses
        boutons, son « Réviser », son bilan (ouvert par l'empreinte déposée), ses copies déposées dans Dropbox, ouvertes
        EN LECTURE SEULE (``ouvrir_copie``) ; ``None`` : sa propre page (le professeur, 19/11/2026, W811 : « il faudrait
        que je puisse basculer pour voir comme si j'étais un élève », « il faut surtout que ce soit en lecture seul les
        copies »). Rien ne s'écrit : ni secret retenu, ni empreinte déposée."""
        if inscrit is None:
            self.entrer_professeur()
            return
        chiffree = self.cat["classes"].get(cle_de(self.classe))
        liste = ouvrir_liste(chiffree, self.cle) if chiffree and self.cle else None
        self.identite = Identite(*inscrit, jetons=liste.get("codes") if liste else None, lecture_seule=True)
        self.montrer_tableau()

    def copie_de(self, lien: str, sujet: str) -> str | None:
        """Le chemin dans Dropbox de la copie électronique de l'élève vu pour le sujet ``sujet`` déposé à ``lien`` (le dossier
        de sa classe, puis celui du sujet : ``pdfs_de_l_eleve``), s'il l'a déposée (``copie_deposee``) ; sinon None."""
        lignes = lire_echeances(self.texte or "")[0]
        classe = next((ligne.classe for ligne in lignes if meme_classe(ligne.classe, self.classe)), self.classe)
        chemins = pdfs_de_l_eleve(lien.rpartition("/")[0], sujet, classe, self.identite.eleve, ".qcm") if lien else []
        return next((c for c in chemins if self.copie_deposee(c)), None)

    def regler(self, sujet: str, classe: str, changements: dict[str, str]) -> None:
        """Un « Enregistrer » du professeur : ``changements`` écrits par ``regler_fichier``, puis le tableau refait sur le
        fichier relu, l'état et les dates des sujets compris, et ce qu'il en est dit en haut."""
        def recu(texte: str | None, message: str) -> None:
            if texte is not None:
                self.texte = texte
            if self.identite is not None and self.identite.professeur:  # pas s'il est sorti entre-temps
                self.montrer_tableau(message)
        self.regler_fichier(sujet, classe, changements, recu)

    def eleves_de_la_classe(self) -> list[str]:
        """Au professeur : « Nom Prénom » de chaque élève de la classe (``inscrits_de_la_classe``)."""
        return [f"{nom} {prenom}" for nom, prenom in self.inscrits_de_la_classe()]

    def inscrits_de_la_classe(self) -> list[tuple[str, str]]:
        """Au professeur : (nom, prénom) de chaque élève de la classe, de sa liste chiffrée dans tableau.json ouverte par
        la clé de l'adresse (``ouvrir_liste``) ; vide si elle ne s'ouvre pas."""
        chiffree = self.cat["classes"].get(cle_de(self.classe))
        liste = ouvrir_liste(chiffree, self.cle) if chiffree and self.cle else None
        return [(nom, prenom) for nom, prenom, *_ in liste["inscrits"]] if liste else []

    def publier_corriges(self, nom: str, publication: str, apres_rattrapages: bool) -> None:
        """Un « Enregistrer » du panneau ``Publication`` : écrit par ``publier_fichier``, puis la page refaite sur le
        catalogue relu, et ce qu'il en est dit en haut."""
        def recu(cat: dict[str, Any] | None, message: str) -> None:
            if cat is not None:
                self.cat = lire_catalogue(cat)
            if self.identite is not None and self.identite.professeur:
                self.montrer_tableau(message)
        self.publier_fichier(nom, publication, apres_rattrapages, recu)


def memoire_des_effectives(dropbox: Path) -> Effectives:
    """``Effectives`` en natif sur le dossier ``dropbox`` : ``valeurs_du_qcm`` du .qcm de chaque sujet (``chemin_du_qcm``,
    catalogue relu de ``dropbox``), une fois par sujet et par classe : le .qcm s'ouvre en une seconde."""
    memoire: dict[tuple[str, str], dict[str, str]] = {}

    def effectives(sujet: str, classe: str) -> dict[str, str]:
        if (sujet, classe) not in memoire:
            cat = (dropbox / CATALOGUE).read_text(encoding="utf-8") if (dropbox / CATALOGUE).is_file() else None
            memoire[sujet, classe] = valeurs_du_qcm(chemin_du_qcm(dropbox, cat, sujet), classe)
        return memoire[sujet, classe]
    return effectives


def classes_connues(listes: Path = LISTES, texte: str | None = None) -> list[str]:
    """Les classes à choisir dans « Gérer les sujets » : celles de ``listes/``, puis celles qu'echeances.csv (``texte``) est
    seul à nommer, chacune une fois (``meme_classe``)."""
    classes = [chemin.stem for chemin in sorted(listes.glob("*.csv"))]
    for ligne in lire_echeances(texte or "")[0]:
        if not any(meme_classe(ligne.classe, c) for c in classes):
            classes.append(ligne.classe)
    return classes


class Gestion(QWidget):
    """« SmartTeacher - Gérer les sujets » : la page d'une classe vue par le professeur (``Portail.entrer_professeur``), ses
    réglages par sujet, et en haut la classe à choisir, qui refait la page (l'utilisateur, 06/11/2026 : « je veux egalement
    pouvoir choisir la classe dans l'interface » et « avoir cette interface en natif avec un lien dans mon menu KDE »).
    ``portail(classe)`` : la page de cette classe, faite sur le fichier relu (``main``)."""

    TITRE = "SmartTeacher - Gérer les sujets"

    def __init__(self, classes: list[str], portail: Callable[[str], Portail], classe: str | None = None,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.fabriquer = portail
        self.portail: Portail | None = None
        self.setWindowTitle(self.TITRE)
        self.setWindowIcon(QIcon(str(LOGO_APPLI)))
        pile = QVBoxLayout(self)
        rangee = QHBoxLayout()
        rangee.addWidget(QLabel("Classe"))
        self.classe = QComboBox()
        for nom in classes:
            self.classe.addItem(nom, nom)
        rangee.addWidget(self.classe, 1)
        # à droite de la classe, la page vue par « Professeur » ou par l'un de ses élèves, copies en lecture seule
        # (``Portail.voir_comme`` ; le professeur, 19/11/2026, W811 : « à droite du menu de la classe avoir un menu
        # élèves », « le premier élément c'est professeur et les éléments suivants … chaque élève de la classe »)
        rangee.addWidget(QLabel("Élèves"))
        self.eleves = QComboBox()
        self.eleves.currentIndexChanged.connect(lambda *_: self.portail and self.portail.voir_comme(self.eleves.currentData()))
        rangee.addWidget(self.eleves, 1)
        # le tableau des notes de la classe (``notes_classe.py``, W785), écrit à part : il ouvre toutes les copies
        self.notes = QPushButton("Tableau des notes (CSV)")
        self.notes.setToolTip("Écrit « Notes/notes <classe>.csv » dans le dossier Dropbox : une ligne par élève, une "
                              "colonne par épreuve, et pourquoi quand la note manque")
        self.notes.clicked.connect(lambda: self.ecrire_notes(self.classe.currentData()))
        rangee.addWidget(self.notes)
        self.etat_notes = QLabel()
        self.etat_notes.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        pile.addLayout(rangee)
        pile.addWidget(self.etat_notes)
        self.etat_notes.hide()
        self.pile = pile
        trouvee = next((i for i, nom in enumerate(classes) if classe and meme_classe(nom, classe)), 0)
        self.classe.setCurrentIndex(trouvee)
        self.classe.currentIndexChanged.connect(lambda *_: self.montrer(self.classe.currentData()))
        if classes:
            self.montrer(self.classe.currentData())

    def montrer(self, classe: str) -> None:
        """La page de ``classe`` à la place de celle d'avant."""
        if self.portail is not None:
            self.pile.removeWidget(self.portail)
            self.portail.deleteLater()
        self.portail = self.fabriquer(classe)
        self.portail.entrer_professeur()
        self.pile.addWidget(self.portail, 1)
        self.eleves.blockSignals(True)  # la classe changée : « Professeur » d'abord, puis ses élèves
        self.eleves.clear()
        self.eleves.addItem("Professeur", None)
        for nom, prenom in self.portail.inscrits_de_la_classe():
            self.eleves.addItem(f"{nom} {prenom}", (nom, prenom))
        self.eleves.blockSignals(False)

    def ecrire_notes(self, classe: str) -> None:
        """Lance ``notes_classe.py <classe>`` à part (toutes les copies à ouvrir : la page ne gèle pas), puis dit le
        chemin du CSV écrit, ou l'erreur."""
        from qtpy6.QtCore import QProcess  # noqa: PLC0415

        processus = QProcess(self)
        self.notes.setEnabled(False)
        self.etat_notes.setText(f"Tableau des notes de {classe} : relevé des copies en cours…")
        self.etat_notes.show()

        def fini(code: int, _statut: Any) -> None:
            sortie = bytes(processus.readAllStandardOutput()).decode(errors="replace").strip()
            erreur = bytes(processus.readAllStandardError()).decode(errors="replace").strip()
            self.etat_notes.setText(f"Écrit : {sortie}" if code == 0 and sortie else
                                    f"Tableau des notes : échec ({erreur.splitlines()[-1] if erreur else code})")
            self.notes.setEnabled(True)

        processus.finished.connect(fini)
        processus.start(sys.executable, [str(Path(__file__).with_name("notes_classe.py")), classe])


def main() -> int:
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("action", nargs="?", choices=["catalogue", "liens", "completer"],
                           help="catalogue : écrit tableau.json dans le dossier Dropbox ; liens HOTE : les adresses des classes ; "
                                "completer : les lignes en vigueur d'echeances.csv auxquelles manque un réglage, recopiées "
                                "complètes (montrées seulement, sans --ecrire)")
    analyseur.add_argument("hote", nargs="?", help="liens : l'adresse de la page, celle de HOTE dans web/deployer.conf")
    analyseur.add_argument("--classe", help="montre le tableau de cette classe")
    analyseur.add_argument("--professeur", action="store_true",
                           help="« Gérer les sujets » : la page des classes vue par le professeur, la classe à choisir")
    analyseur.add_argument("--ecrire", action="store_true", help="completer : écrit le fichier, au lieu de montrer l'ajout")
    analyseur.add_argument("--dropbox", type=Path, default=DROPBOX)
    analyseur.add_argument("-o", "--sortie", type=Path, help="tableau.json ailleurs que dans le dossier Dropbox")
    analyseur.add_argument("--depose", nargs="*", default=[], help="catalogue : les .qcm que deployer.sh vient de déposer")
    a = analyseur.parse_args()
    if a.action == "catalogue":
        sortie = a.sortie or a.dropbox / CATALOGUE
        cat = catalogue(a.dropbox, a.depose)
        ecrire_catalogue(cat, sortie, a.dropbox)
        print(f"{sortie} : {len(cat['sujets'])} sujets déposés")
        if (a.dropbox / ECHEANCES).exists():
            for ligne in sans_bouton(cat, (a.dropbox / ECHEANCES).read_text(encoding="utf-8"), datetime.now(timezone.utc)):
                print(f"ligne d'échéance sans bouton (aucun .qcm déposé au catalogue) : {ligne}")
        return 0
    if a.action == "liens":  # à taper par le professeur : chaque adresse porte la clé de la liste de sa classe
        secret = codes.professeur()
        if not (secret and a.hote):
            analyseur.error("liens HOTE, sur la machine du professeur")
        for chemin in sorted(LISTES.glob("*.csv")):
            print(f"{chemin.stem} : {a.hote.rstrip('/')}/?{urlencode({'classe': chemin.stem, 'cle': cle_de_classe(secret, chemin.stem)})}")
        return 0
    effectives = memoire_des_effectives(a.dropbox)
    if a.action == "completer":  # à taper par le professeur : il lit, puis relance avec --ecrire
        chemin = a.dropbox / ECHEANCES
        with open(chemin, encoding="utf-8", newline="") as fichier:
            ancien = fichier.read()
        nouveau = echeances.completer(ancien, lambda ligne: effectives(ligne["sujet"], ligne["classe"]))
        if nouveau is None:
            print(f"{chemin} : rien à compléter, chaque ligne en vigueur dit ses réglages (ou rien d'autre ne les dit)")
            return 0
        entete = echeances.completer_entete(ancien)
        print(f"{chemin} :" + (f"\nen-tête complété : {entete.splitlines()[0].lstrip(chr(0xFEFF))}" if entete != ancien else ""))
        print(nouveau[len(entete):], end="")
        if a.ecrire:
            echeances.ecrire(ancien, nouveau, chemin)
            print("écrit.")
        else:
            print("rien d'écrit : relancer avec --ecrire")
        return 0
    if not (a.classe or a.professeur):
        analyseur.error("--classe, --professeur, catalogue, liens ou completer")
    import lecteur  # noqa: PLC0415
    from modele import application  # noqa: PLC0415
    from qtpy6.QtCore import QProcess  # noqa: PLC0415
    app = application()
    echeances.DOSSIER = a.dropbox  # les réglages du professeur s'écrivent dans le fichier que ce tableau lit
    lire = lambda nom: (a.dropbox / nom).read_text(encoding="utf-8") if (a.dropbox / nom).exists() else None  # noqa: E731
    programme = str(Path(__file__).with_name("lecteur.py"))
    secret = codes.professeur()  # la clé de la classe, en mémoire seulement : c'est l'adresse des élèves qui la porte
    identites, fichier = lecteur.identites_du_disque(a.dropbox / CATALOGUE)  # celui du dossier partagé, hors ligne compris

    def retenir(valeur: tuple[str, str, str | bytes] | None) -> None:  # le secret seul, comme l'accueil ; jamais un code
        if valeur is None:
            lecteur.oublier_identite()
        elif isinstance(valeur[2], bytes):
            lecteur.garder_identite(*valeur)

    def portail(classe: str) -> Portail:
        global DEPOSER_CONTESTATION
        DEPOSER_CONTESTATION = deposer_sur_disque(a.dropbox)
        return Portail(classe, lire(ECHEANCES), lire(CATALOGUE), cle_de_classe(secret, classe) if secret else "",
                       lambda e: QProcess.startDetached(sys.executable, arguments_du_lecteur(programme, a.dropbox / e.lien, e.jeton, e.section, e.essai)),
                       retenu=lecteur.identite_gardee, retenir=retenir,
                       lire_bilan=lambda chemin, rappel: rappel(b.read_bytes() if (b := a.dropbox / chemin).is_file() else None),
                       identites=identites, deposer=lambda entree: lecteur.deposer_sur_disque(fichier, entree),
                       regler=regler_sur_disque, effectives=effectives, publier=publier_sur_disque(a.dropbox),
                       series=lambda e, qui: lecteur.series_sur_disque(a.dropbox / e.lien, e.section),
                       copie_deposee=lambda chemin: (a.dropbox / chemin).is_file(),
                       sujet_depose=lambda lien: (a.dropbox / lien).is_file(),
                       ouvrir_copie=lambda e, copie: QProcess.startDetached(sys.executable, [
                           *arguments_du_lecteur(programme, a.dropbox / (copie or e.lien), "", essai=e.essai if copie else 0),
                           "--lecture-seule"]))

    if a.professeur:
        if not secret:
            analyseur.error(f"--professeur : le mot de passe professeur ne se lit pas ({codes.FICHIER})")
        tableau = Gestion(classes_connues(LISTES, lire(ECHEANCES)), portail, a.classe)
        tableau.resize(760, 760)
    else:
        tableau = portail(a.classe)
        tableau.resize(760, 600)
    tableau.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
