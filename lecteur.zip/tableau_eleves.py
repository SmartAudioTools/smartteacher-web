"""Le tableau de bord d'une classe : ses TP, révisions et mini-interrogations, chacun avec son état et un bouton pour le
commencer ou le continuer, et en bas le bilan de l'année de l'élève, sans passer par Teams pour chercher un lien (demande de l'utilisateur, 25/10/2026 : « un tableau
de bord SmartTeacher en qtpy6 avec des boutons pour démarrer ou reprendre un TP ou autre »).

Deux fichiers du dossier Dropbox de l'application, à sa racine, le font :
    echeances.csv     écrit à la main par le professeur (format du Worker 59, LibreOffice, « ; », heure de Paris en
                      « JJ/MM/AAAA HH:MM ») : sujet;classe;debut;fin_creneau;echeance, le sujet relatif à sujets/ sans .json ;
    tableau.json      écrit ici (``catalogue``, à chaque déploiement) : pour chaque sujet déposé, son nom et le
                      chemin de son .qcm dans Dropbox, celui que le lien ``?sujet=`` des élèves ouvre ; pour chaque
                      classe de ``listes/``, ses inscrits chiffrés (``classes_chiffrees``).
Le premier est relu à chaque ouverture de la page : une échéance changée se voit sans redéployer.

En ligne, la page ``?classe=SECONDE 5&cle=…`` (``web/pyqt6/pont_tableau.py``) montre ``Portail`` plein canevas : l'élève
y entre par son nom, son prénom et son mot de passe, vérifiés sur la liste de sa classe et le
fichier d'empreintes (``codes.IDENTITES``) comme à l'accueil d'un sujet
(l'utilisateur, 26/10/2026 : « Il faut rentrer le nom, prénom, et mot de passe pour arriver sur l'accueil, par contre le
navigateur peut retenir cela […] Les navigateurs ne seront pas partagés »), puis voit ``Tableau`` ; un bouton ouvre le
sujet à la place du tableau. En natif, ``tableau_eleves.py --classe "SECONDE 5"`` montre le même portail sur le dossier
Dropbox synchronisé, et un bouton lance ``lecteur.py`` sur le .qcm. ``tableau_eleves.py catalogue`` écrit tableau.json,
``tableau_eleves.py liens HOTE`` les adresses des classes, clé comprise, que le professeur leur donne.

Rien de nominatif ni de secret en clair : la page et son dossier Dropbox sont lisibles de tous (le jeton est dans la
page). La liste d'une classe y est chiffrée par une clé que seule son adresse porte, comme le code de classe porte celle
d'un sujet ; un sujet à venir n'a pas de bouton."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import sys
import tempfile
from dataclasses import dataclass
from html import escape
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable
from urllib.parse import urlencode

import bilans_widget
import codes
import echeances
from noyau import ECRAN, SOUMISSIONS, TEMPS
from qtpy6.QtCore import QSize, Qt
from qtpy6.QtGui import QIcon
from qtpy6.QtWidgets import (QComboBox, QDateTimeEdit, QFormLayout, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QScrollArea, QSizePolicy, QSpinBox, QStackedWidget, QVBoxLayout, QWidget)
from serializejson._encryption import decrypt

DROPBOX = Path("/DATA/Dropbox/Applications/SmartTeacherQcm")  # le dossier de l'application, synchronisé sur ce disque
ECHEANCES, CATALOGUE = echeances.NOM, "tableau.json"
# Les états, dans l'ordre où le tableau les montre : ce qui se fait maintenant d'abord, ce qui est fini en dernier.
EN_COURS, A_FINIR, A_VENIR, FERME = "En cours", "À finir", "À venir", "Fermé"
ETATS = (EN_COURS, A_FINIR, A_VENIR, FERME)


@dataclass
class Ligne:
    sujet: str  # relatif à sujets/, sans .json
    classe: str
    debut: datetime | None  # UTC
    fin_creneau: datetime | None
    echeance: datetime | None

    def etat(self, maintenant: datetime) -> str:
        """« En cours » pendant le créneau en classe (sans fin de créneau : jusqu'à l'échéance), « À finir » ensuite jusqu'à
        l'échéance, « À venir » avant, « Fermé » après."""
        if self.debut and maintenant < self.debut:
            return A_VENIR
        if self.echeance and maintenant >= self.echeance:
            return FERME
        if self.fin_creneau and maintenant >= self.fin_creneau:
            return A_FINIR
        return EN_COURS


def date_de_paris(texte: str) -> datetime | None:
    """« JJ/MM/AAAA HH:MM » à l'heure de Paris, en UTC (``echeances.instant``, celle du lecteur) ; None si vide."""
    texte = texte.strip()
    if not texte:
        return None
    try:
        return echeances.instant(texte)
    except ValueError:
        raise ValueError(f"« {texte} » n'est pas une date « JJ/MM/AAAA HH:MM »") from None


def cle_de(nom: str) -> str:
    """Un sujet ou une classe, quelle que soit sa graphie : seul le dernier nom d'un chemin compte (``echeances``), et
    « 2nd 5 » tapé dans l'adresse comme « 2nd_5 » ou « 2ND5 », « Les réseaux sociaux - TP2 » comme le nom de son .qcm
    (« Les_reseaux_sociaux_-_TP2 ») : la même chose ; et un sujet « Listes : méthodes » comme son .qcm, que
    ``codes.nom_de_fichier`` écrit « Listes_-_methodes » (06/11/2026 : la ligne du TP03 de Terminale sans bouton)."""
    return codes.en_ascii(codes.nom_de_fichier(nom.strip().replace("\\", "/").rpartition("/")[2])).replace("_", "").lower()


def meme_classe(a: str, b: str) -> bool:
    return cle_de(a) == cle_de(b)


class Erreur(str):
    """Une erreur du fichier d'échéances, avec la classe de sa ligne (``classe`` vide : inconnue). L'élève ne voit que
    celles de sa classe, le professeur toutes (l'utilisateur, 26/10/2026)."""

    def __new__(cls, texte: str, classe: str = "") -> Erreur:
        erreur = super().__new__(cls, texte)
        erreur.classe = classe
        return erreur


def lire_echeances(texte: str) -> tuple[list[Ligne], list[Erreur]]:
    """Les lignes du fichier d'échéances, et les erreurs d'une ligne illisible (sautée, pas fatale : le professeur l'écrit à
    la main). Pour un même sujet et une même classe, la dernière ligne l'emporte, comme dans ``echeances.trouver``."""
    lignes, erreurs, numero = {}, [], 1
    try:
        for numero, champs in enumerate(csv.DictReader(io.StringIO(texte.lstrip("﻿")), delimiter=";"), start=2):
            try:
                sujet, classe = champs["sujet"].strip(), champs["classe"].strip()
                if sujet and classe:
                    lignes[cle_de(sujet), cle_de(classe)] = Ligne(sujet, classe, *(date_de_paris(champs.get(c) or "")
                                                                                 for c in ("debut", "fin_creneau", "echeance")))
            except (KeyError, ValueError, AttributeError) as erreur:
                erreurs.append(Erreur(f"ligne {numero} : {erreur}", str(champs.get("classe") or "").strip()))
    except csv.Error as erreur:  # une case démesurée : la suite du fichier est perdue, pas ce qui est déjà lu
        erreurs.append(Erreur(f"ligne {numero + 1} et suivantes illisibles : {erreur}"))
    return list(lignes.values()), erreurs


LISTES = Path(__file__).parent / "listes"  # les listes des classes, celles que l'export inscrit dans les sujets


def sel_de_classe(classe: str) -> bytes:
    """Le sel de la liste chiffrée d'une classe, tiré de son nom : la clé (``cle_de_classe``), donc l'adresse donnée à la
    classe, reste la même d'un déploiement à l'autre."""
    return hashlib.sha256(f"smartteacher|tableau|{cle_de(classe)}".encode()).digest()[:16]


def cle_de_classe(secret: str, classe: str) -> str:
    """La clé de la liste de ``classe`` (``codes.cle_sujet`` : six caractères), que porte l'adresse de son tableau."""
    return codes.cle_sujet(secret, sel_de_classe(classe))


def arguments_du_lecteur(programme: str, chemin: Path, jeton: str) -> list[str]:
    """Le lecteur natif ouvert sur un sujet du tableau, avec le code de la classe : l'élève n'en tape aucun."""
    return [programme, str(chemin), *(["--mot-de-passe", codes.phrase_du_jeton(jeton)] if jeton else [])]


def jetons_du_sujet(definition: Any, secret: str) -> dict[str, str]:
    """Pour chaque classe inscrite dans le ``.qcm`` du sujet ``definition``, le code qui l'ouvre pour elle (``codes.jeton`` : ce
    que porte ``?code=``), sans date : c'est ``echeances.csv`` qui les donne (``echeances.appliquer``). Le rang de la classe
    est celui que lit ``Accueil.deverrouiller``, ``sorted(paquet.inscrits)``."""
    import exporter_eleve  # noqa: PLC0415 - côté professeur seulement
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas sujet.py
    classes = sorted({Path(liste).stem for liste in exporter_eleve.listes_du_sujet(definition)})  # deux niveaux peuvent partager une liste
    if len(classes) > codes.CLASSES:  # l'export le refuse : ce sujet n'a pas de .qcm à ces classes
        return {}
    cle = exporter_eleve.cle_neuve(module_sujet.graine_de(definition), secret)[1]
    return {classe: codes.jeton(codes.code_classe(cle, rang)) for rang, classe in enumerate(classes)}


def classes_chiffrees(secret: str, listes: Path = LISTES, jetons: dict[str, dict[str, str]] | None = None) -> dict[str, str]:
    """Pour chaque liste de ``listes`` (« SECONDE 5.csv »), sous ``cle_de`` de la classe, ses inscrits tels qu'un sujet les
    porte (``codes.inscrire`` : nom, prénom) et les ``jetons`` de ses sujets (sous ``cle_de`` du sujet : jamais en clair dans
    tableau.json, public), dans un fichier age en armure, par la clé de la classe ; le mot de passe professeur l'ouvre aussi
    (``codes.cle_du_mot`` sur son sel)."""
    from serializejson._encryption import encrypt, prime  # noqa: PLC0415 - côté professeur seulement

    resultat = {}
    for chemin in sorted(listes.glob("*.csv")):
        classe = chemin.stem
        cle = cle_de_classe(secret, classe)
        prime(cle, sel_de_classe(classe))
        contenu = {"classe": classe, "inscrits": codes.inscrire(codes.lire_liste(chemin)), "codes": (jetons or {}).get(classe, {})}
        resultat[cle_de(classe)] = encrypt(json.dumps(contenu, ensure_ascii=False).encode(), cle, armor=True)
    return resultat


@dataclass
class Identite:
    """Qui est entré : l'élève tel que la liste le nomme, ou le professeur (``nom`` et ``prenom`` vides). Entré par son mot
    de passe : son ``secret``, qui ouvre aussi son bilan, et l'empreinte à déposer d'une première visite (``depot``). Lus dans
    la liste de sa classe, les ``jetons`` qui ouvrent ses sujets, sans rien lui demander (``jetons_du_sujet``)."""
    nom: str
    prenom: str
    professeur: bool = False
    secret: bytes | None = None
    depot: dict[str, str] | None = None
    jetons: dict[str, str] | None = None

    @property
    def eleve(self) -> str:
        return f"{self.nom} {self.prenom}".strip()


def ouvrir_liste(chiffree: str, cle: str) -> dict[str, Any] | None:
    """La liste d'une classe (``classes_chiffrees``) ouverte par ``cle``, ou None si elle ne l'ouvre pas."""
    try:
        contenu = json.loads(bytes(decrypt(chiffree, cle)).decode())
    except Exception:  # noqa: BLE001 - mauvaise clé, liste abîmée : elle ne s'ouvre pas, l'élève le lit
        return None
    return contenu if isinstance(contenu, dict) and isinstance(contenu.get("inscrits"), list) else None


def identifier(chiffree: str | None, cle: str, nom: str, prenom: str, code: str, identites: dict[str, Any] | None = None,
               garde: tuple[str, str, bytes] | None = None) -> Identite | str:
    """L'entrée du tableau : l'élève de la liste (ouverte par la ``cle`` de l'adresse), reconnu malgré ses fautes
    (``codes.reconnaitre``), entré par son mot de passe, celui
    tapé ou celui que l'appareil ``garde``, comme à l'accueil d'un sujet (``codes.reconnaitre_mot_de_passe`` sur le
    fichier d'empreintes ``identites``) ; ou le professeur,
    son mot de passe tapé comme code (``codes.cle_du_mot`` ouvre la liste). Rend l'``Identite``, ou ce qui ne va pas. Le
    professeur n'est essayé qu'à défaut d'élève reconnu : chaque essai coûte une seconde (scrypt)."""
    code, nom, prenom = code.strip(), nom.strip(), prenom.strip()
    if not chiffree:
        return "La liste de cette classe n'est pas encore en ligne : le professeur doit la déposer."
    if not code and garde is None:
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    liste = ouvrir_liste(chiffree, cle) if cle else None
    inscrit = liste and nom and prenom and codes.reconnaitre(nom, prenom, liste["inscrits"])
    if inscrit:
        cle_eleve = codes.nom_identite(inscrit[0], inscrit[1])
        secret = garde[2] if garde and codes.nom_identite(*garde[:2]) == cle_eleve else None
        reconnu = codes.reconnaitre_mot_de_passe(identites or {}, inscrit[0], inscrit[1], code, secret)
        if isinstance(reconnu, str):
            return reconnu
        return Identite(inscrit[0], inscrit[1], secret=reconnu.secret, depot=reconnu.depot, jetons=liste.get("codes"))
    if not code:
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    mot = codes.cle_du_mot(code, chiffree.encode())
    if mot and ouvrir_liste(chiffree, mot) is not None:
        return Identite("", "", professeur=True)
    if liste is None:
        return "Cette adresse ne permet pas d'entrer : demandez au professeur le lien de votre classe."
    if not (nom and prenom):
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    return f"« {nom} {prenom} » n'est pas sur la liste de la classe {liste.get('classe', '')} : vérifiez l'orthographe."


def catalogue(dropbox: Path = DROPBOX, deposes: Iterable[str] = (), secret: str | None = None,
              listes: Path = LISTES) -> dict[str, Any]:
    """tableau.json : pour chaque sujet de sujets/ dont le .qcm est déposé dans ``dropbox`` ou dans ``deposes`` (ses chemins
    dans Dropbox : ceux que deployer.sh vient d'envoyer, que le client Dropbox n'a peut-être pas encore rapatriés), le chemin du .qcm dans Dropbox (sans « / » de tête, celui de ``?sujet=``) et son nom (``Paquet.nom`` : la place de la
    copie dans le navigateur, ``pont_qt.cle``, et le titre que le tableau montre, « Thème - TP2 - Titre » comme les
    fichiers), sous ``cle_de`` de son nom ; et sous « classes », les listes chiffrées (``classes_chiffrees``) par le mot
    de passe professeur ``secret`` (``codes.professeur()`` par défaut ; sans lui, aucune classe : personne n'entre)."""
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas sujet.py
    sys.path.insert(0, str(Path(__file__).parent / "web"))
    from dropbox_professeur import place  # noqa: PLC0415
    secret = secret or codes.professeur()
    sujets, deposes, jetons = {}, {d.lstrip("/") for d in deposes}, {}
    for chemin in sorted(module_sujet.SUJETS.rglob("*.json")):
        try:
            definition = module_sujet.lire(chemin)
        except Exception:  # noqa: BLE001, S112 - un sujet en chantier ne doit pas priver la classe de son tableau
            continue
        lien = place(module_sujet.sortie(definition, "qcm") / f"{codes.nom_de_fichier(chemin.stem)}.qcm")
        if lien.lstrip("/") not in deposes and not (dropbox / lien.lstrip("/")).exists():
            continue
        relatif = chemin.relative_to(module_sujet.SUJETS).with_suffix("").as_posix()
        sujets[cle_de(relatif)] = {"lien": lien.lstrip("/"), "nom": chemin.stem}
        if duree := getattr(definition, "duree_minutes", None):  # ce que montrent les réglages en ligne d'une ligne sans durée
            sujets[cle_de(relatif)]["duree"] = duree
        for classe, jeton in (jetons_du_sujet(definition, secret) if secret else {}).items():
            jetons.setdefault(classe, {})[cle_de(relatif)] = jeton
    return {"version": 1, "sujets": sujets, "classes": classes_chiffrees(secret, listes, jetons) if secret else {}}


@dataclass
class Entree:
    """Une ligne du tableau : ce que le bouton ouvre (``lien`` vide : rien, pas encore déposé ou à venir), et le code que le
    bouton lui passe pour l'élève de cette classe (``jeton``), qui n'a ainsi aucun code à taper."""
    ligne: Ligne
    etat: str
    lien: str
    nom: str
    jeton: str = ""


def entrees(lignes: list[Ligne], cat: dict[str, Any], classe: str, maintenant: datetime,
            jetons: dict[str, str] | None = None) -> list[Entree]:
    """Les lignes de ``classe``, dans l'ordre des ``ETATS``, puis par échéance la plus proche (la plus récente d'abord pour
    les fermés)."""
    resultat = []
    for ligne in lignes:
        if not meme_classe(ligne.classe, classe):
            continue
        connu = cat["sujets"].get(cle_de(ligne.sujet))
        connu = connu if isinstance(connu, dict) else {}
        etat = ligne.etat(maintenant)
        resultat.append(Entree(ligne, etat, "" if etat == A_VENIR else connu.get("lien", ""), connu.get("nom", ligne.sujet.rpartition("/")[2]),
                                (jetons or {}).get(cle_de(ligne.sujet), "")))
    def rang(e: Entree) -> tuple[int, float]:
        date = e.ligne.echeance or e.ligne.debut
        instant = date.timestamp() if date else float("inf")
        return ETATS.index(e.etat), -instant if e.etat == FERME else instant

    return sorted(resultat, key=rang)


def a_paris(date: datetime | None) -> str:
    """Une date UTC dite à l'heure de Paris, « mar. 10/11 à 10 h 00 »."""
    if date is None:
        return ""
    locale = date + timedelta(minutes=codes._decalage_paris(codes._minutes(date)))
    jours = ("lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim.")
    return f"{jours[locale.weekday()]} {locale:%d/%m} à {locale:%H} h {locale:%M}"


def quand(e: Entree) -> str:
    """Ce que l'élève doit savoir de la date : quand ça commence, ou jusqu'à quand il a."""
    if e.etat == A_VENIR:
        return f"commence le {a_paris(e.ligne.debut)}" if e.ligne.debut else ""
    if e.etat == FERME:
        return f"fermé depuis le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else ""
    return f"à rendre avant le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else ""


NIVEAUX = {"2": "Seconde", "1": "Premiere", "t": "Terminale"}  # le dossier du niveau d'une classe, faute de sujet déposé
LOGO_APPLI = Path(__file__).parent / "associations" / "teacher.svg"  # l'icône des fenêtres du lecteur, embarquée en ligne


def niveau_de(classe: str, liste: list[Entree]) -> str:
    """Le dossier du niveau de la classe dans Dropbox, où sont ses « Bilans » : celui de ses sujets déposés, sinon tiré du
    nom de la classe, celui de sa liste (« SECONDE 5 », « B3_P_NSINF_GR1 » : ``codes.niveau``), sinon de sa première
    lettre (« 2nd 5 » → Seconde, « 1G2 » → Premiere, « TG1 » → Terminale) ; vide s'il ne se devine pas."""
    dossiers = [e.lien.split("/", 1)[0] for e in liste if "/" in e.lien]
    if dossiers:
        return max(set(dossiers), key=dossiers.count)
    try:
        return codes.en_ascii(codes.niveau(classe))
    except ValueError:
        return NIVEAUX.get(classe.strip().lower()[:1], "")


MARGES_TITRE = (10, 6, 10, 6)  # autour du texte d'un titre, qu'on puisse le presser ou non


class TitreBouton(QPushButton):
    """Le titre d'un sujet, qu'on presse pour l'ouvrir (l'utilisateur, 03/11/2026 : « que les titres de la liste soient
    directement des boutons »). Un QPushButton ne sait ni le texte riche ni le retour à la ligne : un QLabel dedans les porte,
    et laisse passer la souris ; c'est sa couche qui donne la hauteur, selon la largeur."""

    def __init__(self, texte: QLabel, nom: str) -> None:
        super().__init__()
        self.titre = texte
        texte.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        couche = QVBoxLayout(self)
        couche.setContentsMargins(*MARGES_TITRE)
        couche.addWidget(texte)
        self.setAccessibleName(nom)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)

    def sizeHint(self) -> QSize:
        return self.layout().sizeHint()

    def minimumSizeHint(self) -> QSize:
        return self.layout().minimumSize()


SANS_ECHEANCE, SANS_DUREE = "sans échéance", "sans durée"  # le vrai état : le code n'en porte pas, le sujet non plus
FORMAT_QT = "dd/MM/yyyy HH:mm"  # ``echeances.FORMAT`` dit par Qt
Regler = Callable[[str, str, dict[str, str], Callable[[str | None, str], None]], None]
# ``regler(sujet, classe, changements, rappel)`` : ``changements`` (colonne → case, ``echeances.recopier``) écrits dans
# echeances.csv, puis ``rappel(texte, message)`` : le texte du fichier après coup (None : illisible), et ce qu'il en est dit


def message_reglage(sujet: str, classe: str, ecrite: bool | None, erreur: Exception | None = None) -> str:
    """Ce que la page dit d'un « Enregistrer » : la ligne ajoutée, rien à changer, ou pourquoi le fichier n'est pas touché."""
    quoi = f"{sujet.rpartition('/')[2]}, {classe} : {echeances.NOM}"
    if erreur is not None:
        return f"{quoi} NON modifié ({erreur})."
    return f"{quoi} complété d'une ligne, qui vaut pour les élèves sans redéployer." if ecrite else f"{quoi} disait déjà cela."


def regler_sur_disque(sujet: str, classe: str, changements: dict[str, str], rappel: Callable[[str | None, str], None]) -> None:
    """``Regler`` en natif : la ligne ajoutée au fichier synchronisé par le client Dropbox (``echeances.regler``)."""
    try:
        message = message_reglage(sujet, classe, echeances.regler(sujet, classe, changements))
    except (OSError, ValueError) as erreur:
        message = message_reglage(sujet, classe, None, erreur)
    rappel(echeances.du_disque(), message)


async def regler_par(lire: Callable[[], Any], ecrire: Callable[[str, str | None], Any], sujet: str, classe: str,
                     changements: dict[str, str], rappel: Callable[[str | None, str], None], essais: int = 3) -> None:
    """``Regler`` en ligne : ``lire()`` rend {texte, rev} du fichier (ou rien), ``ecrire(texte, rev)`` l'écrit sur cette
    version et rend {rev}, ou rien si quelqu'un l'a changé depuis (``dropbox.js``, ``echeances_lire`` et ``echeances_ecrire``) :
    on relit alors et on recommence, comme ``pont_qt.deposer_identite``. Le texte complété vient d'``echeances.recopier``."""
    texte = None
    for _ in range(essais):
        try:
            lu = await lire()
            texte, rev = (str(lu.texte), str(lu.rev)) if getattr(lu, "texte", None) is not None else (None, None)
            nouveau = echeances.recopier(texte, sujet, classe, changements)
            if nouveau is None:
                rappel(texte, message_reglage(sujet, classe, False))
                return
            if getattr(await ecrire(nouveau, rev), "rev", None) is not None:
                rappel(nouveau, message_reglage(sujet, classe, True))
                return
        except Exception as erreur:  # noqa: BLE001 - réseau, quota, jeton, ou ValueError d'une valeur refusée : dit, rien d'écrit
            rappel(texte, message_reglage(sujet, classe, None, erreur))
            return
    rappel(None, message_reglage(sujet, classe, None, ValueError("le fichier change sans cesse, réessayez")))


def maintenant_a_paris() -> datetime:
    """L'heure de Paris, sans fuseau, à la minute : celle des cases d'echeances.csv (le navigateur, lui, compte en UTC)."""
    return datetime.strptime(echeances.en_texte(datetime.now(timezone.utc)), echeances.FORMAT)


Effectives = Callable[[str, str], dict[str, str]]
# ``effectives(sujet, classe)`` : les réglages qui valent vraiment pour la classe, comme echeances.csv les écrit (colonne →
# case, ``echeances.REGLAGES``), là où sa ligne n'en dit rien : ``valeurs_du_qcm`` en natif, ``valeurs_par_defaut`` sinon


def valeurs_par_defaut(duree: int | None = None) -> dict[str, str]:
    """Les réglages d'un code de classe donné sans réglage (``codes.code_classe`` : celui que la page d'une classe passe au
    lecteur, ``jetons_du_sujet``), en cases d'echeances.csv : sans échéance, soumission 0, sans anti-triche, temps écran, et
    la durée du sujet (``duree``, vide s'il n'en a pas)."""
    return {"echeance": "", "duree": str(duree or ""), "soumission": "0", "anti_triche": "non", "temps": ECRAN}


def chemin_du_qcm(dropbox: Path, cat: dict[str, Any], sujet: str) -> Path | None:
    """Le .qcm du ``sujet`` d'une ligne d'echeances.csv sur ce disque : celui du catalogue, sinon le chemin que la ligne
    porte (sa place dans Dropbox, sans « .qcm », comme l'écrit « Générer ») ; ``None`` s'il n'y est pas."""
    connu = lire_catalogue(cat)["sujets"].get(cle_de(sujet))
    for relatif in ((connu or {}).get("lien") if isinstance(connu, dict) else None, sujet.strip().lstrip("/") + ".qcm"):
        if relatif and (chemin := dropbox / relatif).is_file():
            return chemin
    return None


def valeurs_du_qcm(chemin: Path | None, classe: str) -> dict[str, str]:
    """``Effectives`` en natif : le dernier code donné à ``classe`` pour le .qcm ``chemin`` au journal des déploiements
    (``code_eleve.du_sujet``), qui dit sa durée (celle du sujet s'il n'en porte pas), son échéance, sa soumission, son
    anti-triche et son temps ; sans code au journal, ``valeurs_par_defaut`` à la durée du sujet ; sans .qcm lisible, celles
    sans durée. Ouvrir un .qcm coûte une seconde (scrypt) : ``main`` ne le fait que pour une ligne incomplète, une fois."""
    if chemin is None:
        return valeurs_par_defaut()
    import code_eleve  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas code_eleve.py
    try:
        cle, paquet = code_eleve.ouvrir(chemin)
        donnes = [e for e in code_eleve.du_sujet(cle, paquet) if e["classe"] and meme_classe(e["classe"], classe)]
    except (OSError, ValueError, KeyError):
        return valeurs_par_defaut()
    duree = paquet.get("duree_minutes")
    if not donnes:
        return valeurs_par_defaut(duree)
    e = donnes[-1]
    return {"echeance": echeances.en_texte(e["echeance"]), "duree": str(e["duree"] or duree or ""),
            "soumission": str(e["soumission"] or 0), "anti_triche": "oui" if e["anti_triche"] else "non",
            "temps": e["temps"] or ECRAN}


def _ecrite(ligne: echeances.Ligne, colonne: str) -> str:
    """La case ``colonne`` de ``ligne`` (lue) telle que ce panneau l'écrirait ; vide si le fichier n'en dit rien de lisible."""
    valeur = getattr(ligne, colonne)
    if valeur is None:
        return ""
    if colonne == "echeance":
        return echeances.en_texte(valeur)
    if colonne == "anti_triche":
        return "oui" if valeur else "non"
    return str(valeur)


class Reglages(QFrame):
    """Sous le titre d'un sujet, pour le professeur seulement : l'échéance, la durée, le mode de soumission, l'anti-triche et le
    temps de cette classe, et « Enregistrer », qui recopie la ligne d'echeances.csv en bas avec ce qui a changé
    (``echeances.recopier``) ; seules les cases changées ici sont envoyées, une case écrite à la main que ce panneau ne sait
    pas montrer reste telle quelle. Chaque case montre une vraie valeur : celle du fichier, sinon celle qui vaut vraiment
    pour la classe (``effectives()``, appelée seulement s'il en manque) ; une ligne incomplète s'enregistre alors entière
    (l'utilisateur, 06/11/2026 : « je veux dans mon interface pour gerer les sujet qu'il n'y ai aucun champs laissé à
    "celle du code" »). « sans échéance » et « sans durée » ne disent que ce vrai état. ``regler(sujet, classe,
    changements)`` : ``Portail.regler``."""

    def __init__(self, sujet: str, classe: str, brute: dict[str, str] | None, regler: Callable[[str, str, dict[str, str]], None],
                 effectives: Callable[[], dict[str, str]] = valeurs_par_defaut, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.sujet, self.classe, self.regler = sujet, classe, regler
        self.setFrameShape(QFrame.Shape.StyledPanel)
        ligne = echeances.lire(brute)
        self.ecrites = {c: _ecrite(ligne, c) for c in echeances.REGLAGES}  # ce que dit la ligne en vigueur
        manque = echeances.manquantes(brute)
        valeurs = {**effectives(), **{c: v for c, v in self.ecrites.items() if c not in manque}} if manque else self.ecrites
        debut = datetime.strptime(echeances.en_texte(ligne.depart), echeances.FORMAT) if ligne.depart else None
        actuelle = datetime.strptime(valeurs["echeance"], echeances.FORMAT) if valeurs.get("echeance") else None
        formulaire = QFormLayout(self)
        self.echeance = QDateTimeEdit()
        self.echeance.setCalendarPopup(True)
        self.echeance.setDisplayFormat("ddd " + FORMAT_QT)
        # la plus petite valeur dit « sans échéance » : le début (une échéance doit venir après), sinon juste avant l'heure
        # ou l'échéance actuelle, qui reste lisible même passée
        plus_tot = debut or min(maintenant_a_paris(), actuelle or maintenant_a_paris()) - timedelta(minutes=1)
        self.echeance.setMinimumDateTime(plus_tot)
        self.echeance.setSpecialValueText(SANS_ECHEANCE)
        self.echeance.setDateTime(actuelle or plus_tot)
        formulaire.addRow("Échéance", self.echeance)
        self.duree = QSpinBox()
        self.duree.setRange(0, echeances.DUREE_MAX)
        self.duree.setSuffix(" min")
        self.duree.setSpecialValueText(SANS_DUREE)
        self.duree.setValue(int(valeurs["duree"]) if (valeurs.get("duree") or "").isdigit() else 0)
        formulaire.addRow("Durée", self.duree)
        self.soumission = QComboBox()
        for numero, texte in SOUMISSIONS.items():
            self.soumission.addItem(texte, str(numero))
        self.soumission.setCurrentIndex(max(0, self.soumission.findData(valeurs.get("soumission") or "0")))
        formulaire.addRow("Soumission", self.soumission)
        self.anti_triche = QComboBox()
        for texte in ("oui", "non"):
            self.anti_triche.addItem(texte, texte)
        self.anti_triche.setCurrentIndex(max(0, self.anti_triche.findData(valeurs.get("anti_triche") or "non")))
        formulaire.addRow("Anti-triche", self.anti_triche)
        self.temps = QComboBox()
        for case, texte in TEMPS.items():
            self.temps.addItem(texte, case)
        self.temps.setCurrentIndex(max(0, self.temps.findData(valeurs.get("temps") or ECRAN)))
        formulaire.addRow("Temps", self.temps)
        self.enregistrer = QPushButton("Enregistrer")
        self.enregistrer.clicked.connect(self.envoyer)
        self.enregistrer.setEnabled(self.changements() != {})
        for signal in (self.echeance.dateTimeChanged, self.duree.valueChanged, self.soumission.currentIndexChanged,
                       self.anti_triche.currentIndexChanged, self.temps.currentIndexChanged):
            signal.connect(lambda *_: self.enregistrer.setEnabled(self.changements() != {}))
        formulaire.addRow(self.enregistrer)
        self.incomplete = QLabel(f"<span style='color:#606060'>{echeances.NOM} ne dit pas tout pour cette classe : ce qui "
                                 "vaut est montré, « Enregistrer » l'y écrit.</span>")
        self.incomplete.setWordWrap(True)
        self.incomplete.setVisible(self.changements() != {})
        formulaire.addRow(self.incomplete)
        for erreur in ligne.erreurs:  # une case mal écrite à la main : ignorée par le lecteur, montrée ici à sa vraie valeur
            formulaire.addRow(QLabel(f"<span style='color:#c0392b'>{escape(erreur)}</span>"))

    def cases(self) -> dict[str, str]:
        """Ce que montre le panneau, case par case, comme echeances.csv l'écrit (vide : sans échéance, sans durée)."""
        echeance = self.echeance.dateTime()
        return {"echeance": "" if echeance == self.echeance.minimumDateTime() else echeance.toString(FORMAT_QT),
                "duree": str(self.duree.value() or ""), "soumission": self.soumission.currentData(),
                "anti_triche": self.anti_triche.currentData(), "temps": self.temps.currentData()}

    def changements(self) -> dict[str, str]:
        """Les cases qui diffèrent de la ligne en vigueur : celles changées ici, et celles qu'elle ne disait pas."""
        return {colonne: case for colonne, case in self.cases().items() if case != self.ecrites[colonne]}

    def envoyer(self) -> None:
        self.enregistrer.setEnabled(False)
        self.enregistrer.setText("Enregistrement…")
        self.regler(self.sujet, self.classe, self.changements())


class Tableau(QScrollArea):
    """Le tableau d'une classe. ``ouvrir(entree)`` : un titre pressé ; ``commencee(nom)`` : vrai si une copie de ce sujet
    de l'élève entré est déjà dans cet appareil (« Déjà commencé » sous son titre) ; ``eleve`` : « Nom Prénom » de
    l'élève entré, montré sous la classe ; ``professeur`` : c'est le professeur ;
    ``lire_bilan(chemin, rappel)`` : rend à ``rappel`` les octets du fichier ``chemin`` du dossier Dropbox (None s'il
    n'existe pas), le bilan de l'année, ouvert d'emblée s'il est en clair ou que le ``secret`` de l'élève entré l'ouvre
    (``identites`` : le fichier d'empreintes) ; le mot de passe n'est demandé que sinon. Au professeur, si ``regler`` est
    donné, un bouton « Réglages » par sujet, qui montre ses ``Reglages`` lus dans ``texte_echeances`` (le fichier), les
    cases qu'il ne dit pas remplies par ``effectives`` (``valeurs_par_defaut`` sans lui) ;
    ``message`` : ce qu'a fait le dernier « Enregistrer », en haut."""

    def __init__(self, classe: str, liste: list[Entree], ouvrir: Callable[[Entree], None],
                 commencee: Callable[[str], bool] = lambda nom: False, erreurs: list[str] = (), eleve: str = "",
                 lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None,
                 professeur: bool = False, secret: bytes | None = None, identites: dict[str, Any] | None = None,
                 texte_echeances: str | None = None, regler: Callable[[str, str, dict[str, str]], None] | None = None,
                 message: str = "", parent: QWidget | None = None, effectives: Effectives | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"SmartTeacher - {classe}")
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.boutons: dict[str, TitreBouton] = {}  # par sujet : ce que les tests pressent
        self.reglages: dict[str, Reglages] = {}  # par sujet, au professeur seulement (``regler``) : ses réglages, sous son titre
        self.lire_bilan, self.niveau, self.bilan = lire_bilan, niveau_de(classe, liste), None
        self.secret, self.identites = secret, identites or {}
        contenu = QWidget()
        self.pile = pile = QVBoxLayout(contenu)
        pile.setContentsMargins(24, 16, 24, 16)
        logo = QLabel()
        logo.setPixmap(QIcon(str(LOGO_APPLI)).pixmap(96, 96))
        pile.addWidget(logo, 0, Qt.AlignmentFlag.AlignHCenter)
        qui = "Professeur" if professeur else eleve
        self.entete = QLabel(f"<h1>SmartTeacher</h1><h2>{escape(classe)}</h2>" + (f"<p>{escape(qui)}</p>" if qui else ""))
        self.entete.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(self.entete)
        self.message = QLabel(message)  # ce qu'a fait le dernier « Enregistrer » des réglages, en texte brut
        self.message.setTextFormat(Qt.TextFormat.PlainText)
        self.message.setWordWrap(True)
        self.message.setVisible(bool(message))
        pile.addWidget(self.message)
        if not liste:
            pile.addWidget(QLabel("Rien n'est prévu pour cette classe pour l'instant."))
        for etat in ETATS:
            groupe = [e for e in liste if e.etat == etat]
            if not groupe:
                continue
            pile.addWidget(QLabel(f"<h2>{etat}</h2>"))
            for e in groupe:  # le nom du fichier, « Thème - TP2 - Titre », puis la date en gris
                deja = e.lien and not professeur and e.etat != FERME and commencee(e.nom)
                gris = " · ".join(filter(None, (quand(e), "Déjà commencé" if deja else "")))  # une date peut manquer
                texte = QLabel(f"<b>{e.nom}</b><br><span style='color:#606060'>{gris}</span>")
                texte.setWordWrap(True)
                texte.setTextFormat(Qt.TextFormat.RichText)
                if e.lien:
                    titre = bouton = TitreBouton(texte, e.nom)
                    bouton.clicked.connect(lambda _=False, e=e: ouvrir(e))
                    self.boutons[e.ligne.sujet] = bouton
                else:  # à venir : le titre seul, aligné sur ceux qu'on presse
                    titre = texte
                    texte.setContentsMargins(*MARGES_TITRE)
                if not (professeur and regler):
                    pile.addWidget(titre)
                    continue
                # le professeur : « Réglages » à droite du titre, qui montre ou cache le panneau du sujet en dessous
                rangee = QHBoxLayout()
                rangee.addWidget(titre, 1)
                montrer = QPushButton("Réglages")
                montrer.setCheckable(True)
                rangee.addWidget(montrer, 0, Qt.AlignmentFlag.AlignTop)
                pile.addLayout(rangee)
                panneau = Reglages(e.ligne.sujet, e.ligne.classe,
                                   echeances.trouver(texte_echeances, {e.ligne.sujet.strip().replace("\\", "/").rpartition("/")[2]},
                                                     e.ligne.classe), regler,
                                   (lambda e=e: effectives(e.ligne.sujet, e.ligne.classe)) if effectives else valeurs_par_defaut)
                panneau.hide()
                montrer.toggled.connect(panneau.setVisible)
                pile.addWidget(panneau)
                self.reglages[e.ligne.sujet] = panneau
        for erreur in erreurs:  # ce que le professeur a mal écrit (``construire`` ne laisse à l'élève que sa classe)
            pile.addWidget(QLabel(f"<span style='color:#c0392b'>{ECHEANCES}, {erreur}</span>"))
        if lire_bilan and self.niveau and not professeur:
            self._formulaire_bilan(eleve)
            if eleve:  # le mot de passe n'est demandé que si le bilan ne s'ouvre pas sans lui
                self.voir_bilan()
        pile.addStretch(1)
        self.setWidget(contenu)

    def _formulaire_bilan(self, eleve: str) -> None:
        """En bas, le bilan de l'année : le mot de passe, s'il faut le taper, et le nom et le prénom si cet appareil n'en a
        retenu aucun."""
        self.pile.addWidget(QLabel("<h2>Bilan de l'année</h2>"))
        self.cadre_bilan = QWidget()
        formulaire = QFormLayout(self.cadre_bilan)
        formulaire.setContentsMargins(0, 0, 0, 0)
        nom, prenom = (eleve.split(" ", 1) + [""])[:2] if eleve else ("", "")
        self.nom, self.prenom, self.mot_de_passe = QLineEdit(nom), QLineEdit(prenom), QLineEdit()
        if not eleve:
            formulaire.addRow("Nom", self.nom)
            formulaire.addRow("Prénom", self.prenom)
        self.mot_de_passe.setEchoMode(QLineEdit.EchoMode.Password)
        self.mot_de_passe.returnPressed.connect(self.voir_bilan)
        voir = QPushButton("Voir mon bilan")
        voir.clicked.connect(self.voir_bilan)
        ligne = QHBoxLayout()
        ligne.addWidget(self.mot_de_passe, 1)
        ligne.addWidget(voir)
        formulaire.addRow("Mot de passe", ligne)
        self.message_bilan = QLabel("")
        self.message_bilan.setWordWrap(True)
        formulaire.addRow(self.message_bilan)
        self.pile.addWidget(self.cadre_bilan)

    def eleve_du_formulaire(self) -> str:
        return f"{self.nom.text().strip()} {self.prenom.text().strip()}".strip()

    def voir_bilan(self) -> None:
        eleve = self.eleve_du_formulaire()
        if not eleve:
            self.message_bilan.setText("Votre nom et votre prénom, puis Entrée.")
            return
        self.message_bilan.setText("Lecture du bilan…")
        self.lire_bilan(f"{self.niveau}/Bilans/{bilans_widget.nom_du_fichier(eleve)}", self.bilan_recu)

    def bilan_recu(self, octets: bytes | None) -> None:
        if not octets:
            self.message_bilan.setText("Pas encore de bilan pour vous : le professeur le dépose après les premières notes.")
            return
        chemin = Path(tempfile.gettempdir()) / f"bilan{bilans_widget.EXTENSION}"
        chemin.write_bytes(octets)
        tape = self.mot_de_passe.text()
        try:
            bilan = bilans_widget.ouvrir_bilan(str(chemin), bilans_widget.cle_du_secret(self.secret))
            if bilan is None and tape:
                bilan = bilans_widget.ouvrir_par_mot_de_passe(str(chemin), self.eleve_du_formulaire(), tape, self.identites)
        except ValueError:
            self.message_bilan.setText("Ce bilan est illisible : signalez-le au professeur.")
            return
        finally:
            chemin.unlink(missing_ok=True)
        if bilan is None:
            self.message_bilan.setText(bilans_widget.REFUS if tape else "Tapez votre mot de passe.")
            return
        self.mot_de_passe.clear()
        self.bilan = bilan  # à la place du formulaire : le mot de passe ne sert plus
        self.pile.replaceWidget(self.cadre_bilan, bilan)
        self.cadre_bilan.deleteLater()


def lire_catalogue(cat: dict[str, Any] | str | None) -> dict[str, Any]:
    """tableau.json lu ; illisible ou absent : comme vide, sans bouton ni classe."""
    if isinstance(cat, str):
        try:
            cat = json.loads(cat)
        except ValueError:
            cat = None
    if not isinstance(cat, dict) or not isinstance(cat.get("sujets"), dict):
        cat = {"sujets": {}}
    if not isinstance(cat.get("classes"), dict):
        cat["classes"] = {}
    return cat


def construire(classe: str, texte: str | None, cat: dict[str, Any] | str | None, ouvrir: Callable[[Entree], None],
               commencee: Callable[[str], bool] = lambda nom: False, maintenant: datetime | None = None, eleve: str = "",
               lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None, professeur: bool = False,
               secret: bytes | None = None, identites: dict[str, Any] | None = None,
               jetons: dict[str, str] | None = None, regler: Callable[[str, str, dict[str, str]], None] | None = None,
               message: str = "", effectives: Effectives | None = None) -> Tableau:
    """Le tableau à partir des textes des deux fichiers (None : absent, le tableau est vide). Les erreurs du fichier
    d'échéances : toutes au professeur, à l'élève celles des lignes de sa classe seulement. Sans ``effectives``, une case
    vide des réglages montre ``valeurs_par_defaut`` à la durée du sujet que porte le catalogue."""
    cat = lire_catalogue(cat)
    if effectives is None:
        def effectives(sujet: str, _classe: str) -> dict[str, str]:
            connu = cat["sujets"].get(cle_de(sujet))
            return valeurs_par_defaut(connu.get("duree") if isinstance(connu, dict) else None)
    lignes, erreurs = lire_echeances(texte or "")
    # le nom de la classe tel que le professeur l'écrit, pas tel que l'adresse le porte (« 2nd_5 »)
    classe = next((ligne.classe for ligne in lignes if meme_classe(ligne.classe, classe)), classe)
    if not professeur:
        erreurs = [e for e in erreurs if e.classe and meme_classe(e.classe, classe)]
    return Tableau(classe, entrees(lignes, cat, classe, maintenant or datetime.now(timezone.utc), jetons), ouvrir, commencee, erreurs,
                   eleve, lire_bilan, professeur, secret, identites, texte, regler if professeur else None, message,
                   effectives=effectives)


class Portail(QStackedWidget):
    """La page d'une classe : l'entrée (prénom, nom, mot de passe, vérifiés par ``identifier`` sur la
    liste chiffrée de la classe et le fichier d'empreintes ``identites``), puis son ``Tableau``. ``retenu()`` rend
    ``(nom, prénom, code)`` retenus par cet appareil, le code étant le secret (``bytes``) de l'élève entré par son mot de
    passe, ``retenir(…)`` les retient (``None`` : les oublie) : le navigateur d'un élève n'est pas partagé (l'utilisateur,
    26/10/2026), l'élève revient sans retaper, et « Changer d'élève » oublie. ``deposer(entree)`` : l'empreinte d'une
    première visite, à ajouter au fichier d'empreintes. ``commencee(nom, identite)`` : une copie de ce sujet par cet
    élève est dans cet appareil. ``regler`` (``Regler`` : ``regler_sur_disque``, ou ``regler_par`` en ligne) : ce qui
    écrit dans echeances.csv les réglages du professeur ; sans lui, ni bouton « Réglages » ni panneau. Les autres paramètres
    sont ceux de ``construire`` (``effectives`` compris)."""

    def __init__(self, classe: str, texte: str | None, cat: dict[str, Any] | str | None, cle: str,
                 ouvrir: Callable[[Entree], None], commencee: Callable[[str, Identite], bool] = lambda nom, qui: False,
                 retenu: Callable[[], tuple[str, str, str | bytes] | None] = lambda: None,
                 retenir: Callable[[tuple[str, str, str | bytes] | None], None] = lambda valeur: None,
                 maintenant: datetime | None = None,
                 lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None,
                 identites: dict[str, Any] | None = None, deposer: Callable[[dict[str, str]], None] = lambda entree: None,
                 regler: Regler | None = None, parent: QWidget | None = None, effectives: Effectives | None = None) -> None:
        super().__init__(parent)
        self.classe, self.texte, self.cat, self.cle, self.regler_fichier = classe, texte, lire_catalogue(cat), cle, regler
        self.effectives = effectives
        self.gestion = False  # entré par ``entrer_professeur`` : pas de « Changer d'élève »
        self.ouvrir, self.commencee, self.retenu, self.retenir = ouvrir, commencee, retenu, retenir
        self.maintenant, self.lire_bilan, self.identites, self.deposer = maintenant, lire_bilan, identites or {}, deposer
        self.identite: Identite | None = None
        self.garde: tuple[str, str, bytes] | None = None  # l'élève que l'appareil a retenu par son mot de passe
        self.premiere = False  # l'élève nommé en est à sa première visite : son mot de passe s'affiche (``voir_premiere_visite``)
        self.inscrits: list[list[str]] | None = None  # la liste de la classe, déchiffrée une fois (``voir_premiere_visite``)
        self.tableau: Tableau | None = None
        self.setWindowTitle(f"SmartTeacher - {classe}")
        self.connexion = QWidget()
        pile = QVBoxLayout(self.connexion)
        pile.setContentsMargins(24, 16, 24, 16)
        pile.addStretch(1)
        logo = QLabel()
        logo.setPixmap(QIcon(str(LOGO_APPLI)).pixmap(96, 96))
        pile.addWidget(logo, 0, Qt.AlignmentFlag.AlignHCenter)
        entete = QLabel(f"<h1>SmartTeacher</h1><h2>{escape(classe)}</h2>")
        entete.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(entete)
        formulaire = QFormLayout()
        self.prenom, self.nom, self.personnel = QLineEdit(), QLineEdit(), QLineEdit()
        self.personnel.setEchoMode(QLineEdit.EchoMode.Password)
        self.prenom.editingFinished.connect(self.voir_premiere_visite)
        self.nom.editingFinished.connect(self.voir_premiere_visite)
        formulaire.addRow("Prénom", self.prenom)
        formulaire.addRow("Nom", self.nom)
        formulaire.addRow("Mot de passe", self.personnel)
        pile.addLayout(formulaire)
        self.bouton_entrer = QPushButton("Entrer")
        self.bouton_entrer.clicked.connect(self.entrer)
        self.personnel.returnPressed.connect(self.entrer)
        pile.addWidget(self.bouton_entrer, 0, Qt.AlignmentFlag.AlignHCenter)
        self.message = QLabel("")
        self.message.setWordWrap(True)
        self.message.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(self.message)
        pile.addStretch(2)
        self.addWidget(self.connexion)
        if valeur := retenu():  # ce que l'appareil a retenu, pré-rempli et essayé d'emblée
            self.nom.setText(valeur[0])
            self.prenom.setText(valeur[1])
            if isinstance(valeur[2], bytes):
                self.garde = valeur
            else:
                self.personnel.setText(valeur[2])
            if valeur[2]:
                self.entrer()
            else:  # un nom seul (retenu d'avant les mots de passe) : l'élève tape le sien
                self.voir_premiere_visite()

    def voir_premiere_visite(self) -> None:
        """À sa première visite, l'élève ne tape son mot de passe qu'une fois : le champ l'affiche et le message le dit ;
        sinon il est masqué. La liste se déchiffre une seule fois, quand le nom est complet : ce déchiffrement est lent."""
        nom, prenom = self.nom.text().strip(), self.prenom.text().strip()
        if nom and prenom and self.inscrits is None and self.cle:
            chiffree = self.cat["classes"].get(cle_de(self.classe))
            liste = chiffree and ouvrir_liste(chiffree, self.cle)
            self.inscrits = liste["inscrits"] if liste else None
        premiere = bool(self.inscrits) and codes.premiere_visite(self.identites, self.inscrits, nom, prenom, self.garde)
        if premiere != self.premiere:
            self.premiere = premiere
            self.personnel.setEchoMode(QLineEdit.EchoMode.Normal if premiere else QLineEdit.EchoMode.Password)
            self.message.setText(codes.PREMIERE_VISITE if premiere else "")

    def entrer(self) -> None:
        nom, prenom, code = self.nom.text(), self.prenom.text(), self.personnel.text()
        chiffree = self.cat["classes"].get(cle_de(self.classe))
        identite = identifier(chiffree, self.cle, nom, prenom, code, self.identites, self.garde)
        if isinstance(identite, str):
            if identite == codes.GARDE_PERIMEE:  # retenue d'avant une réinscription : le mot de passe d'aujourd'hui
                self.garde = None
                self.retenir(None)
                self.voir_premiere_visite()
                if self.premiere:  # réinitialisé : il en choisit un autre, le message est déjà là
                    return
            self.message.setText(f"<span style='color:#c0392b'>{escape(identite)}</span>")
            return
        self.identite = identite
        if identite.depot:
            self.deposer(identite.depot)
            codes.ajouter_depot(self.identites, identite.depot)  # plus une première visite
        # le mot de passe professeur ne s'écrit nulle part, même dans le navigateur : il le retape ; celui d'un élève non
        # plus, c'est son secret qui est retenu
        self.retenir(None if identite.professeur else (identite.nom, identite.prenom, identite.secret))
        self.personnel.clear()
        self.message.clear()
        self.montrer_tableau()

    def montrer_tableau(self, message: str = "") -> None:
        """Le tableau de l'élève ou du professeur entré, fait (ou refait, après un réglage) sur ``texte``."""
        identite = self.identite
        if self.tableau is not None:
            self.removeWidget(self.tableau)
            self.tableau.deleteLater()
        self.tableau = construire(self.classe, self.texte, self.cat, self.ouvrir,
                                  lambda nom_sujet: self.commencee(nom_sujet, identite), self.maintenant, identite.eleve,
                                  self.lire_bilan, identite.professeur, identite.secret, self.identites, identite.jetons,
                                  self.regler if self.regler_fichier else None, message, self.effectives)
        if not self.gestion:
            changer = QPushButton("Changer d'élève")
            changer.clicked.connect(self.changer)
            self.tableau.pile.insertWidget(0, changer, 0, Qt.AlignmentFlag.AlignRight)
        self.addWidget(self.tableau)
        self.setCurrentWidget(self.tableau)

    def entrer_professeur(self) -> None:
        """Le tableau du professeur d'emblée, sans entrée : la fenêtre « Gérer les sujets » (``Gestion``), sur la machine où
        se lit le mot de passe professeur (``codes.professeur``), qui ne s'écrit ni ne se tape ici."""
        self.gestion = True
        self.identite = Identite("", "", professeur=True)
        self.montrer_tableau()

    def regler(self, sujet: str, classe: str, changements: dict[str, str]) -> None:
        """Un « Enregistrer » du professeur : ``changements`` écrits par ``regler_fichier``, puis le tableau refait sur le
        fichier relu, l'état et les dates des sujets compris, et ce qu'il en est dit en haut."""
        def recu(texte: str | None, message: str) -> None:
            if texte is not None:
                self.texte = texte
            if self.identite is not None and self.identite.professeur:  # pas s'il est sorti entre-temps
                self.montrer_tableau(message)
        self.regler_fichier(sujet, classe, changements, recu)

    def changer(self) -> None:
        """Retour à l'entrée, l'appareil oublie l'élève (son nom reste pré-rempli, pas son code)."""
        self.retenir(None)
        self.identite = self.garde = None
        if self.tableau is not None:
            self.removeWidget(self.tableau)
            self.tableau.deleteLater()
            self.tableau = None
        self.voir_premiere_visite()
        self.setCurrentWidget(self.connexion)


def memoire_des_effectives(dropbox: Path) -> Effectives:
    """``Effectives`` en natif sur le dossier ``dropbox`` : ``valeurs_du_qcm`` du .qcm de chaque sujet (``chemin_du_qcm``,
    catalogue relu de ``dropbox``), une fois par sujet et par classe : le .qcm s'ouvre en une seconde."""
    memoire: dict[tuple[str, str], dict[str, str]] = {}

    def effectives(sujet: str, classe: str) -> dict[str, str]:
        if (sujet, classe) not in memoire:
            cat = (dropbox / CATALOGUE).read_text(encoding="utf-8") if (dropbox / CATALOGUE).is_file() else None
            memoire[sujet, classe] = valeurs_du_qcm(chemin_du_qcm(dropbox, cat, sujet), classe)
        return memoire[sujet, classe]
    return effectives


def classes_connues(listes: Path = LISTES, texte: str | None = None) -> list[str]:
    """Les classes à choisir dans « Gérer les sujets » : celles de ``listes/``, puis celles qu'echeances.csv (``texte``) est
    seul à nommer, chacune une fois (``meme_classe``)."""
    classes = [chemin.stem for chemin in sorted(listes.glob("*.csv"))]
    for ligne in lire_echeances(texte or "")[0]:
        if not any(meme_classe(ligne.classe, c) for c in classes):
            classes.append(ligne.classe)
    return classes


class Gestion(QWidget):
    """« SmartTeacher - Gérer les sujets » : la page d'une classe vue par le professeur (``Portail.entrer_professeur``), ses
    réglages par sujet, et en haut la classe à choisir, qui refait la page (l'utilisateur, 06/11/2026 : « je veux egalement
    pouvoir choisir la classe dans l'interface » et « avoir cette interface en natif avec un lien dans mon menu KDE »).
    ``portail(classe)`` : la page de cette classe, faite sur le fichier relu (``main``)."""

    TITRE = "SmartTeacher - Gérer les sujets"

    def __init__(self, classes: list[str], portail: Callable[[str], Portail], classe: str | None = None,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.fabriquer = portail
        self.portail: Portail | None = None
        self.setWindowTitle(self.TITRE)
        self.setWindowIcon(QIcon(str(LOGO_APPLI)))
        pile = QVBoxLayout(self)
        rangee = QHBoxLayout()
        rangee.addWidget(QLabel("Classe"))
        self.classe = QComboBox()
        for nom in classes:
            self.classe.addItem(nom, nom)
        rangee.addWidget(self.classe, 1)
        pile.addLayout(rangee)
        self.pile = pile
        trouvee = next((i for i, nom in enumerate(classes) if classe and meme_classe(nom, classe)), 0)
        self.classe.setCurrentIndex(trouvee)
        self.classe.currentIndexChanged.connect(lambda *_: self.montrer(self.classe.currentData()))
        if classes:
            self.montrer(self.classe.currentData())

    def montrer(self, classe: str) -> None:
        """La page de ``classe`` à la place de celle d'avant."""
        if self.portail is not None:
            self.pile.removeWidget(self.portail)
            self.portail.deleteLater()
        self.portail = self.fabriquer(classe)
        self.portail.entrer_professeur()
        self.pile.addWidget(self.portail, 1)


def main() -> int:
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("action", nargs="?", choices=["catalogue", "liens", "completer"],
                           help="catalogue : écrit tableau.json dans le dossier Dropbox ; liens HOTE : les adresses des classes ; "
                                "completer : les lignes en vigueur d'echeances.csv auxquelles manque un réglage, recopiées "
                                "complètes (montrées seulement, sans --ecrire)")
    analyseur.add_argument("hote", nargs="?", help="liens : l'adresse de la page, celle de HOTE dans web/deployer.conf")
    analyseur.add_argument("--classe", help="montre le tableau de cette classe")
    analyseur.add_argument("--professeur", action="store_true",
                           help="« Gérer les sujets » : la page des classes vue par le professeur, la classe à choisir")
    analyseur.add_argument("--ecrire", action="store_true", help="completer : écrit le fichier, au lieu de montrer l'ajout")
    analyseur.add_argument("--dropbox", type=Path, default=DROPBOX)
    analyseur.add_argument("-o", "--sortie", type=Path, help="tableau.json ailleurs que dans le dossier Dropbox")
    analyseur.add_argument("--depose", nargs="*", default=[], help="catalogue : les .qcm que deployer.sh vient de déposer")
    a = analyseur.parse_args()
    if a.action == "catalogue":
        sortie = a.sortie or a.dropbox / CATALOGUE
        cat = catalogue(a.dropbox, a.depose)
        sortie.write_text(json.dumps(cat, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        print(f"{sortie} : {len(cat['sujets'])} sujets déposés")
        return 0
    if a.action == "liens":  # à taper par le professeur : chaque adresse porte la clé de la liste de sa classe
        secret = codes.professeur()
        if not (secret and a.hote):
            analyseur.error("liens HOTE, sur la machine du professeur")
        for chemin in sorted(LISTES.glob("*.csv")):
            print(f"{chemin.stem} : {a.hote.rstrip('/')}/?{urlencode({'classe': chemin.stem, 'cle': cle_de_classe(secret, chemin.stem)})}")
        return 0
    effectives = memoire_des_effectives(a.dropbox)
    if a.action == "completer":  # à taper par le professeur : il lit, puis relance avec --ecrire
        chemin = a.dropbox / ECHEANCES
        with open(chemin, encoding="utf-8", newline="") as fichier:
            ancien = fichier.read()
        nouveau = echeances.completer(ancien, lambda ligne: effectives(ligne["sujet"], ligne["classe"]))
        if nouveau is None:
            print(f"{chemin} : rien à compléter, chaque ligne en vigueur dit ses réglages (ou rien d'autre ne les dit)")
            return 0
        entete = echeances.completer_entete(ancien)
        print(f"{chemin} :" + (f"\nen-tête complété : {entete.splitlines()[0].lstrip(chr(0xFEFF))}" if entete != ancien else ""))
        print(nouveau[len(entete):], end="")
        if a.ecrire:
            echeances.ecrire(ancien, nouveau, chemin)
            print("écrit.")
        else:
            print("rien d'écrit : relancer avec --ecrire")
        return 0
    if not (a.classe or a.professeur):
        analyseur.error("--classe, --professeur, catalogue, liens ou completer")
    import lecteur  # noqa: PLC0415
    from modele import application  # noqa: PLC0415
    from qtpy6.QtCore import QProcess  # noqa: PLC0415
    app = application()
    echeances.DOSSIER = a.dropbox  # les réglages du professeur s'écrivent dans le fichier que ce tableau lit
    lire = lambda nom: (a.dropbox / nom).read_text(encoding="utf-8") if (a.dropbox / nom).exists() else None  # noqa: E731
    programme = str(Path(__file__).with_name("lecteur.py"))
    secret = codes.professeur()  # la clé de la classe, en mémoire seulement : c'est l'adresse des élèves qui la porte
    identites, fichier = lecteur.identites_du_disque(a.dropbox / CATALOGUE)  # celui du dossier partagé, hors ligne compris

    def retenir(valeur: tuple[str, str, str | bytes] | None) -> None:  # le secret seul, comme l'accueil ; jamais un code
        if valeur is None:
            lecteur.oublier_identite()
        elif isinstance(valeur[2], bytes):
            lecteur.garder_identite(*valeur)

    def portail(classe: str) -> Portail:
        return Portail(classe, lire(ECHEANCES), lire(CATALOGUE), cle_de_classe(secret, classe) if secret else "",
                       lambda e: QProcess.startDetached(sys.executable, arguments_du_lecteur(programme, a.dropbox / e.lien, e.jeton)),
                       retenu=lecteur.identite_gardee, retenir=retenir,
                       lire_bilan=lambda chemin, rappel: rappel(b.read_bytes() if (b := a.dropbox / chemin).is_file() else None),
                       identites=identites, deposer=lambda entree: lecteur.deposer_sur_disque(fichier, entree),
                       regler=regler_sur_disque, effectives=effectives)

    if a.professeur:
        if not secret:
            analyseur.error(f"--professeur : le mot de passe professeur ne se lit pas ({codes.FICHIER})")
        tableau = Gestion(classes_connues(LISTES, lire(ECHEANCES)), portail, a.classe)
        tableau.resize(760, 760)
    else:
        tableau = portail(a.classe)
        tableau.resize(760, 600)
    tableau.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
