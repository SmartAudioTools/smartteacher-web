"""Le tableau de bord d'une classe : ses TP, révisions et mini-interrogations, chacun avec son état et un bouton pour le
commencer ou le continuer, et en bas le bilan de l'année de l'élève, sans passer par Teams pour chercher un lien (demande de l'utilisateur, 25/10/2026 : « un tableau
de bord SmartTeacher en qtpy6 avec des boutons pour démarrer ou reprendre un TP ou autre »).

Deux fichiers du dossier Dropbox de l'application, à sa racine, le font :
    echeances.csv     écrit à la main par le professeur (format du Worker 59, LibreOffice, « ; », heure de Paris en
                      « JJ/MM/AAAA HH:MM ») : sujet;classe;debut;fin_creneau;echeance, le sujet relatif à sujets/ sans .json ;
    tableau.json      écrit ici (``catalogue``, à chaque déploiement) : pour chaque sujet déposé, son nom et le
                      chemin de son .qcm dans Dropbox, celui que le lien ``?sujet=`` des élèves ouvre ; pour chaque
                      classe de ``listes/``, ses inscrits chiffrés (``classes_chiffrees``).
Le premier est relu à chaque ouverture de la page : une échéance changée se voit sans redéployer.

En ligne, la page ``?classe=SECONDE 5&cle=…`` (``web/pyqt6/pont_tableau.py``) montre ``Portail`` plein canevas : l'élève
y entre par son nom, son prénom et son code personnel, vérifiés sur la liste de sa classe comme à l'accueil d'un sujet
(l'utilisateur, 26/10/2026 : « Il faut rentrer le nom, prénom, et mot de passe pour arriver sur l'accueil, par contre le
navigateur peut retenir cela […] Les navigateurs ne seront pas partagés »), puis voit ``Tableau`` ; un bouton ouvre le
sujet à la place du tableau. En natif, ``tableau_eleves.py --classe "SECONDE 5"`` montre le même portail sur le dossier
Dropbox synchronisé, et un bouton lance ``lecteur.py`` sur le .qcm. ``tableau_eleves.py catalogue`` écrit tableau.json,
``tableau_eleves.py liens HOTE`` les adresses des classes, clé comprise, que le professeur leur donne.

Rien de nominatif ni de secret en clair : la page et son dossier Dropbox sont lisibles de tous (le jeton est dans la
page). La liste d'une classe y est chiffrée par une clé que seule son adresse porte, comme le code de classe porte celle
d'un sujet ; un sujet à venir n'a pas de bouton."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import sys
import tempfile
from dataclasses import dataclass
from html import escape
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable
from urllib.parse import urlencode

import bilans_widget
import codes
import echeances
from qtpy6.QtCore import Qt
from qtpy6.QtGui import QIcon
from qtpy6.QtWidgets import (QFormLayout, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea,
                             QStackedWidget, QVBoxLayout, QWidget)
from serializejson._encryption import decrypt

DROPBOX = Path("/DATA/Dropbox/Applications/SmartTeacherQcm")  # le dossier de l'application, synchronisé sur ce disque
ECHEANCES, CATALOGUE = echeances.NOM, "tableau.json"
# Les états, dans l'ordre où le tableau les montre : ce qui se fait maintenant d'abord, ce qui est fini en dernier.
EN_COURS, A_FINIR, A_VENIR, FERME = "En cours", "À finir", "À venir", "Fermé"
ETATS = (EN_COURS, A_FINIR, A_VENIR, FERME)


@dataclass
class Ligne:
    sujet: str  # relatif à sujets/, sans .json
    classe: str
    debut: datetime | None  # UTC
    fin_creneau: datetime | None
    echeance: datetime | None

    def etat(self, maintenant: datetime) -> str:
        """« En cours » pendant le créneau en classe (sans fin de créneau : jusqu'à l'échéance), « À finir » ensuite jusqu'à
        l'échéance, « À venir » avant, « Fermé » après."""
        if self.debut and maintenant < self.debut:
            return A_VENIR
        if self.echeance and maintenant >= self.echeance:
            return FERME
        if self.fin_creneau and maintenant >= self.fin_creneau:
            return A_FINIR
        return EN_COURS


def date_de_paris(texte: str) -> datetime | None:
    """« JJ/MM/AAAA HH:MM » à l'heure de Paris, en UTC (``echeances.instant``, celle du lecteur) ; None si vide."""
    texte = texte.strip()
    if not texte:
        return None
    try:
        return echeances.instant(texte)
    except ValueError:
        raise ValueError(f"« {texte} » n'est pas une date « JJ/MM/AAAA HH:MM »") from None


def cle_de(nom: str) -> str:
    """Un sujet ou une classe, quelle que soit sa graphie : seul le dernier nom d'un chemin compte (``echeances``), et
    « 2nd 5 » tapé dans l'adresse comme « 2nd_5 » ou « 2ND5 », « Les réseaux sociaux - TP2 » comme le nom de son .qcm
    (« Les_reseaux_sociaux_-_TP2 ») : la même chose."""
    return codes.en_ascii(nom.strip().replace("\\", "/").rpartition("/")[2]).replace("_", "").lower()


def meme_classe(a: str, b: str) -> bool:
    return cle_de(a) == cle_de(b)


class Erreur(str):
    """Une erreur du fichier d'échéances, avec la classe de sa ligne (``classe`` vide : inconnue). L'élève ne voit que
    celles de sa classe, le professeur toutes (l'utilisateur, 26/10/2026)."""

    def __new__(cls, texte: str, classe: str = "") -> Erreur:
        erreur = super().__new__(cls, texte)
        erreur.classe = classe
        return erreur


def lire_echeances(texte: str) -> tuple[list[Ligne], list[Erreur]]:
    """Les lignes du fichier d'échéances, et les erreurs d'une ligne illisible (sautée, pas fatale : le professeur l'écrit à
    la main). Pour un même sujet et une même classe, la dernière ligne l'emporte, comme dans ``echeances.trouver``."""
    lignes, erreurs, numero = {}, [], 1
    try:
        for numero, champs in enumerate(csv.DictReader(io.StringIO(texte.lstrip("﻿")), delimiter=";"), start=2):
            try:
                sujet, classe = champs["sujet"].strip(), champs["classe"].strip()
                if sujet and classe:
                    lignes[cle_de(sujet), cle_de(classe)] = Ligne(sujet, classe, *(date_de_paris(champs.get(c) or "")
                                                                                 for c in ("debut", "fin_creneau", "echeance")))
            except (KeyError, ValueError, AttributeError) as erreur:
                erreurs.append(Erreur(f"ligne {numero} : {erreur}", str(champs.get("classe") or "").strip()))
    except csv.Error as erreur:  # une case démesurée : la suite du fichier est perdue, pas ce qui est déjà lu
        erreurs.append(Erreur(f"ligne {numero + 1} et suivantes illisibles : {erreur}"))
    return list(lignes.values()), erreurs


LISTES = Path(__file__).parent / "listes"  # les listes des classes, celles que l'export inscrit dans les sujets


def sel_de_classe(classe: str) -> bytes:
    """Le sel de la liste chiffrée d'une classe, tiré de son nom : la clé (``cle_de_classe``), donc l'adresse donnée à la
    classe, reste la même d'un déploiement à l'autre."""
    return hashlib.sha256(f"smartteacher|tableau|{cle_de(classe)}".encode()).digest()[:16]


def cle_de_classe(secret: str, classe: str) -> str:
    """La clé de la liste de ``classe`` (``codes.cle_sujet`` : six caractères), que porte l'adresse de son tableau."""
    return codes.cle_sujet(secret, sel_de_classe(classe))


def classes_chiffrees(secret: str, listes: Path = LISTES) -> dict[str, str]:
    """Pour chaque liste de ``listes`` (« SECONDE 5.csv »), sous ``cle_de`` de la classe, ses inscrits tels qu'un sujet les
    porte (``codes.inscrire`` : nom, prénom, contrôle du code personnel) dans un fichier age en armure, par la clé de la
    classe ; le mot de passe professeur l'ouvre aussi (``codes.cle_du_mot`` sur son sel)."""
    from serializejson._encryption import encrypt, prime  # noqa: PLC0415 - côté professeur seulement

    resultat = {}
    for chemin in sorted(listes.glob("*.csv")):
        classe = chemin.stem
        cle = cle_de_classe(secret, classe)
        prime(cle, sel_de_classe(classe))
        contenu = {"classe": classe, "inscrits": codes.inscrire(secret, cle, codes.lire_liste(chemin))}
        resultat[cle_de(classe)] = encrypt(json.dumps(contenu, ensure_ascii=False).encode(), cle, armor=True)
    return resultat


@dataclass
class Identite:
    """Qui est entré : l'élève tel que la liste le nomme, ou le professeur (``nom`` et ``prenom`` vides)."""
    nom: str
    prenom: str
    professeur: bool = False

    @property
    def eleve(self) -> str:
        return f"{self.nom} {self.prenom}".strip()


def ouvrir_liste(chiffree: str, cle: str) -> dict[str, Any] | None:
    """La liste d'une classe (``classes_chiffrees``) ouverte par ``cle``, ou None si elle ne l'ouvre pas."""
    try:
        contenu = json.loads(bytes(decrypt(chiffree, cle)).decode())
    except Exception:  # noqa: BLE001 - mauvaise clé, liste abîmée : elle ne s'ouvre pas, l'élève le lit
        return None
    return contenu if isinstance(contenu, dict) and isinstance(contenu.get("inscrits"), list) else None


def identifier(chiffree: str | None, cle: str, nom: str, prenom: str, code: str) -> Identite | str:
    """L'entrée du tableau : l'élève de la liste (ouverte par la ``cle`` de l'adresse), reconnu malgré ses fautes
    (``codes.reconnaitre``) et dont c'est le code personnel (``codes.verifier_personnel``), comme à l'accueil d'un sujet ;
    ou le professeur, son mot de passe tapé comme code (``codes.cle_du_mot`` ouvre la liste). Rend l'``Identite``, ou ce
    qui ne va pas. Le professeur n'est essayé qu'à défaut d'élève reconnu : chaque essai coûte une seconde (scrypt)."""
    code, nom, prenom = code.strip(), nom.strip(), prenom.strip()
    if not chiffree:
        return "La liste de cette classe n'est pas encore en ligne : le professeur doit la déposer."
    if not code:
        return "Écrivez votre prénom, votre nom et votre code personnel."
    liste = ouvrir_liste(chiffree, cle) if cle else None
    inscrit = liste and nom and prenom and codes.reconnaitre(nom, prenom, liste["inscrits"])
    if inscrit:
        if not codes.verifier_personnel(cle, inscrit, code):
            return f"Ce code personnel n'est pas celui de {inscrit[0]} {inscrit[1]}."
        return Identite(inscrit[0], inscrit[1])
    mot = codes.cle_du_mot(code, chiffree.encode())
    if mot and ouvrir_liste(chiffree, mot) is not None:
        return Identite("", "", professeur=True)
    if liste is None:
        return "Cette adresse ne permet pas d'entrer : demandez au professeur le lien de votre classe."
    if not (nom and prenom):
        return "Écrivez votre prénom, votre nom et votre code personnel."
    return f"« {nom} {prenom} » n'est pas sur la liste de la classe {liste.get('classe', '')} : vérifiez l'orthographe."


def catalogue(dropbox: Path = DROPBOX, deposes: Iterable[str] = (), secret: str | None = None,
              listes: Path = LISTES) -> dict[str, Any]:
    """tableau.json : pour chaque sujet de sujets/ dont le .qcm est déposé dans ``dropbox`` ou dans ``deposes`` (ses chemins
    dans Dropbox : ceux que deployer.sh vient d'envoyer, que le client Dropbox n'a peut-être pas encore rapatriés), le chemin du .qcm dans Dropbox (sans « / » de tête, celui de ``?sujet=``) et son nom (``Paquet.nom`` : la place de la
    copie dans le navigateur, ``pont_qt.cle``, et le titre que le tableau montre, « Thème - TP2 - Titre » comme les
    fichiers), sous ``cle_de`` de son nom ; et sous « classes », les listes chiffrées (``classes_chiffrees``) par le mot
    de passe professeur ``secret`` (``codes.professeur()`` par défaut ; sans lui, aucune classe : personne n'entre)."""
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas sujet.py
    sys.path.insert(0, str(Path(__file__).parent / "web"))
    from dropbox_professeur import place  # noqa: PLC0415
    sujets, deposes = {}, {d.lstrip("/") for d in deposes}
    for chemin in sorted(module_sujet.SUJETS.rglob("*.json")):
        try:
            definition = module_sujet.lire(chemin)
        except Exception:  # noqa: BLE001, S112 - un sujet en chantier ne doit pas priver la classe de son tableau
            continue
        lien = place(module_sujet.sortie(definition, "qcm") / f"{codes.nom_de_fichier(chemin.stem)}.qcm")
        if lien.lstrip("/") not in deposes and not (dropbox / lien.lstrip("/")).exists():
            continue
        relatif = chemin.relative_to(module_sujet.SUJETS).with_suffix("").as_posix()
        sujets[cle_de(relatif)] = {"lien": lien.lstrip("/"), "nom": chemin.stem}
    secret = secret or codes.professeur()
    return {"version": 1, "sujets": sujets, "classes": classes_chiffrees(secret, listes) if secret else {}}


@dataclass
class Entree:
    """Une ligne du tableau : ce que le bouton ouvre (``lien`` vide : rien, pas encore déposé ou à venir)."""
    ligne: Ligne
    etat: str
    lien: str
    nom: str


def entrees(lignes: list[Ligne], cat: dict[str, Any], classe: str, maintenant: datetime) -> list[Entree]:
    """Les lignes de ``classe``, dans l'ordre des ``ETATS``, puis par échéance la plus proche (la plus récente d'abord pour
    les fermés)."""
    resultat = []
    for ligne in lignes:
        if not meme_classe(ligne.classe, classe):
            continue
        connu = cat["sujets"].get(cle_de(ligne.sujet))
        connu = connu if isinstance(connu, dict) else {}
        etat = ligne.etat(maintenant)
        resultat.append(Entree(ligne, etat, "" if etat == A_VENIR else connu.get("lien", ""), connu.get("nom", ligne.sujet.rpartition("/")[2])))
    def rang(e: Entree) -> tuple[int, float]:
        date = e.ligne.echeance or e.ligne.debut
        instant = date.timestamp() if date else float("inf")
        return ETATS.index(e.etat), -instant if e.etat == FERME else instant

    return sorted(resultat, key=rang)


def a_paris(date: datetime | None) -> str:
    """Une date UTC dite à l'heure de Paris, « mar. 10/11 à 10 h 00 »."""
    if date is None:
        return ""
    locale = date + timedelta(minutes=codes._decalage_paris(codes._minutes(date)))
    jours = ("lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim.")
    return f"{jours[locale.weekday()]} {locale:%d/%m} à {locale:%H} h {locale:%M}"


def quand(e: Entree) -> str:
    """Ce que l'élève doit savoir de la date : quand ça commence, ou jusqu'à quand il a."""
    if e.etat == A_VENIR:
        return f"commence le {a_paris(e.ligne.debut)}" if e.ligne.debut else ""
    if e.etat == FERME:
        return f"fermé depuis le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else ""
    return f"à rendre avant le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else ""


NIVEAUX = {"2": "Seconde", "1": "Premiere", "t": "Terminale"}  # le dossier du niveau d'une classe, faute de sujet déposé
LOGO_APPLI = Path(__file__).parent / "associations" / "teacher.svg"  # l'icône des fenêtres du lecteur, embarquée en ligne


def niveau_de(classe: str, liste: list[Entree]) -> str:
    """Le dossier du niveau de la classe dans Dropbox, où sont ses « Bilans » : celui de ses sujets déposés, sinon tiré du
    nom de la classe, celui de sa liste (« SECONDE 5 », « B3_P_NSINF_GR1 » : ``codes.niveau``), sinon de sa première
    lettre (« 2nd 5 » → Seconde, « 1G2 » → Premiere, « TG1 » → Terminale) ; vide s'il ne se devine pas."""
    dossiers = [e.lien.split("/", 1)[0] for e in liste if "/" in e.lien]
    if dossiers:
        return max(set(dossiers), key=dossiers.count)
    try:
        return codes.en_ascii(codes.niveau(classe))
    except ValueError:
        return NIVEAUX.get(classe.strip().lower()[:1], "")


class Tableau(QScrollArea):
    """Le tableau d'une classe. ``ouvrir(entree)`` : un bouton pressé ; ``commencee(nom)`` : vrai si une copie de ce sujet
    de l'élève entré est déjà dans cet appareil (« Continuer » au lieu de « Commencer ») ; ``eleve`` : « Nom Prénom » de
    l'élève entré, montré sous la classe ; ``professeur`` : c'est le professeur, chaque bouton dit « Ouvrir » ;
    ``lire_bilan(chemin, rappel)`` : rend à ``rappel`` les octets du fichier ``chemin`` du dossier Dropbox (None s'il
    n'existe pas), le bilan de l'année, ouvert d'emblée par ``personnel``, le code avec lequel l'élève est entré."""

    def __init__(self, classe: str, liste: list[Entree], ouvrir: Callable[[Entree], None],
                 commencee: Callable[[str], bool] = lambda nom: False, erreurs: list[str] = (), eleve: str = "",
                 lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None,
                 professeur: bool = False, personnel: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"SmartTeacher - {classe}")
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.boutons: dict[str, QPushButton] = {}  # par sujet : ce que les tests pressent
        self.lire_bilan, self.niveau, self.bilan = lire_bilan, niveau_de(classe, liste), None
        contenu = QWidget()
        self.pile = pile = QVBoxLayout(contenu)
        pile.setContentsMargins(24, 16, 24, 16)
        logo = QLabel()
        logo.setPixmap(QIcon(str(LOGO_APPLI)).pixmap(96, 96))
        pile.addWidget(logo, 0, Qt.AlignmentFlag.AlignHCenter)
        qui = "Professeur" if professeur else eleve
        self.entete = QLabel(f"<h1>SmartTeacher</h1><h2>{escape(classe)}</h2>" + (f"<p>{escape(qui)}</p>" if qui else ""))
        self.entete.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(self.entete)
        if not liste:
            pile.addWidget(QLabel("Rien n'est prévu pour cette classe pour l'instant."))
        for etat in ETATS:
            groupe = [e for e in liste if e.etat == etat]
            if not groupe:
                continue
            pile.addWidget(QLabel(f"<h2>{etat}</h2>"))
            grille = QGridLayout()
            grille.setColumnStretch(0, 1)
            for rang, e in enumerate(groupe):  # le nom du fichier, « Thème - TP2 - Titre », puis la date en gris
                texte = QLabel(f"<b>{e.nom}</b><br><span style='color:#606060'>{quand(e)}</span>")
                texte.setWordWrap(True)
                texte.setTextFormat(Qt.TextFormat.RichText)
                grille.addWidget(texte, rang, 0)
                if e.lien:
                    bouton = QPushButton("Ouvrir" if professeur else "Revoir" if e.etat == FERME
                                         else "Continuer" if commencee(e.nom) else "Commencer")
                    bouton.clicked.connect(lambda _=False, e=e: ouvrir(e))
                    grille.addWidget(bouton, rang, 1, Qt.AlignmentFlag.AlignTop)
                    self.boutons[e.ligne.sujet] = bouton
            pile.addLayout(grille)
        for erreur in erreurs:  # ce que le professeur a mal écrit (``construire`` ne laisse à l'élève que sa classe)
            pile.addWidget(QLabel(f"<span style='color:#c0392b'>{ECHEANCES}, {erreur}</span>"))
        if lire_bilan and self.niveau and not professeur:
            self._formulaire_bilan(eleve)
            if eleve and personnel:  # entré par son code : le bilan s'ouvre sans le redemander
                self.personnel.setText(personnel)
                self.voir_bilan()
        pile.addStretch(1)
        self.setWidget(contenu)

    def _formulaire_bilan(self, eleve: str) -> None:
        """En bas, le bilan de l'année : le code personnel (jamais retenu, comme à l'accueil d'un sujet), et le nom et le
        prénom si cet appareil n'en a retenu aucun."""
        self.pile.addWidget(QLabel("<h2>Bilan de l'année</h2>"))
        self.cadre_bilan = QWidget()
        formulaire = QFormLayout(self.cadre_bilan)
        formulaire.setContentsMargins(0, 0, 0, 0)
        nom, prenom = (eleve.split(" ", 1) + [""])[:2] if eleve else ("", "")
        self.nom, self.prenom, self.personnel = QLineEdit(nom), QLineEdit(prenom), QLineEdit()
        if not eleve:
            formulaire.addRow("Nom", self.nom)
            formulaire.addRow("Prénom", self.prenom)
        self.personnel.setEchoMode(QLineEdit.EchoMode.Password)
        self.personnel.returnPressed.connect(self.voir_bilan)
        voir = QPushButton("Voir mon bilan")
        voir.clicked.connect(self.voir_bilan)
        ligne = QHBoxLayout()
        ligne.addWidget(self.personnel, 1)
        ligne.addWidget(voir)
        formulaire.addRow("Code personnel", ligne)
        self.message_bilan = QLabel("")
        self.message_bilan.setWordWrap(True)
        formulaire.addRow(self.message_bilan)
        self.pile.addWidget(self.cadre_bilan)

    def voir_bilan(self) -> None:
        eleve = f"{self.nom.text().strip()} {self.prenom.text().strip()}".strip()
        if not eleve or not self.personnel.text().strip():
            self.message_bilan.setText("Votre nom, votre prénom et votre code personnel, puis Entrée.")
            return
        self.message_bilan.setText("Lecture du bilan…")
        self.lire_bilan(f"{self.niveau}/Bilans/{bilans_widget.nom_du_fichier(eleve)}", self.bilan_recu)

    def bilan_recu(self, octets: bytes | None) -> None:
        if not octets:
            self.message_bilan.setText("Pas encore de bilan pour vous : le professeur le dépose après les premières notes.")
            return
        chemin = Path(tempfile.gettempdir()) / f"bilan{bilans_widget.EXTENSION}"
        chemin.write_bytes(octets)
        try:
            bilan = bilans_widget.ouvrir_bilan(str(chemin), self.personnel.text())
        except ValueError:
            bilan = None
            self.message_bilan.setText("Ce bilan est illisible : signalez-le au professeur.")
            return
        finally:
            chemin.unlink(missing_ok=True)
        if bilan is None:
            self.message_bilan.setText("Code incorrect.")
            return
        self.personnel.clear()
        self.bilan = bilan  # à la place du formulaire : le code ne sert plus
        self.pile.replaceWidget(self.cadre_bilan, bilan)
        self.cadre_bilan.deleteLater()


def lire_catalogue(cat: dict[str, Any] | str | None) -> dict[str, Any]:
    """tableau.json lu ; illisible ou absent : comme vide, sans bouton ni classe."""
    if isinstance(cat, str):
        try:
            cat = json.loads(cat)
        except ValueError:
            cat = None
    if not isinstance(cat, dict) or not isinstance(cat.get("sujets"), dict):
        cat = {"sujets": {}}
    if not isinstance(cat.get("classes"), dict):
        cat["classes"] = {}
    return cat


def construire(classe: str, texte: str | None, cat: dict[str, Any] | str | None, ouvrir: Callable[[Entree], None],
               commencee: Callable[[str], bool] = lambda nom: False, maintenant: datetime | None = None, eleve: str = "",
               lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None, professeur: bool = False,
               personnel: str = "") -> Tableau:
    """Le tableau à partir des textes des deux fichiers (None : absent, le tableau est vide). Les erreurs du fichier
    d'échéances : toutes au professeur, à l'élève celles des lignes de sa classe seulement."""
    cat = lire_catalogue(cat)
    lignes, erreurs = lire_echeances(texte or "")
    # le nom de la classe tel que le professeur l'écrit, pas tel que l'adresse le porte (« 2nd_5 »)
    classe = next((ligne.classe for ligne in lignes if meme_classe(ligne.classe, classe)), classe)
    if not professeur:
        erreurs = [e for e in erreurs if e.classe and meme_classe(e.classe, classe)]
    return Tableau(classe, entrees(lignes, cat, classe, maintenant or datetime.now(timezone.utc)), ouvrir, commencee, erreurs,
                   eleve, lire_bilan, professeur, personnel)


class Portail(QStackedWidget):
    """La page d'une classe : l'entrée (prénom, nom, code personnel, vérifiés par ``identifier`` sur la liste chiffrée de
    la classe), puis son ``Tableau``. ``retenu()`` rend ``(nom, prénom, code)`` retenus par cet appareil, ``retenir(…)``
    les retient (``None`` : les oublie) : le navigateur d'un élève n'est pas partagé (l'utilisateur, 26/10/2026), l'élève
    revient sans retaper, et « Changer d'élève » oublie. ``commencee(nom, identite)`` : une copie de ce sujet par cet
    élève est dans cet appareil. Les autres paramètres sont ceux de ``construire``."""

    def __init__(self, classe: str, texte: str | None, cat: dict[str, Any] | str | None, cle: str,
                 ouvrir: Callable[[Entree], None], commencee: Callable[[str, Identite], bool] = lambda nom, qui: False,
                 retenu: Callable[[], tuple[str, str, str] | None] = lambda: None,
                 retenir: Callable[[tuple[str, str, str] | None], None] = lambda valeur: None,
                 maintenant: datetime | None = None,
                 lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.classe, self.texte, self.cat, self.cle = classe, texte, lire_catalogue(cat), cle
        self.ouvrir, self.commencee, self.retenu, self.retenir = ouvrir, commencee, retenu, retenir
        self.maintenant, self.lire_bilan = maintenant, lire_bilan
        self.identite: Identite | None = None
        self.tableau: Tableau | None = None
        self.setWindowTitle(f"SmartTeacher - {classe}")
        self.connexion = QWidget()
        pile = QVBoxLayout(self.connexion)
        pile.setContentsMargins(24, 16, 24, 16)
        pile.addStretch(1)
        logo = QLabel()
        logo.setPixmap(QIcon(str(LOGO_APPLI)).pixmap(96, 96))
        pile.addWidget(logo, 0, Qt.AlignmentFlag.AlignHCenter)
        entete = QLabel(f"<h1>SmartTeacher</h1><h2>{escape(classe)}</h2>")
        entete.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(entete)
        formulaire = QFormLayout()
        self.prenom, self.nom, self.personnel = QLineEdit(), QLineEdit(), QLineEdit()
        self.personnel.setEchoMode(QLineEdit.EchoMode.Password)
        formulaire.addRow("Prénom", self.prenom)
        formulaire.addRow("Nom", self.nom)
        formulaire.addRow("Code personnel", self.personnel)
        pile.addLayout(formulaire)
        self.bouton_entrer = QPushButton("Entrer")
        self.bouton_entrer.clicked.connect(self.entrer)
        self.personnel.returnPressed.connect(self.entrer)
        pile.addWidget(self.bouton_entrer, 0, Qt.AlignmentFlag.AlignHCenter)
        self.message = QLabel("")
        self.message.setWordWrap(True)
        self.message.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(self.message)
        pile.addStretch(2)
        self.addWidget(self.connexion)
        if valeur := retenu():  # ce que l'appareil a retenu, pré-rempli et essayé d'emblée
            self.nom.setText(valeur[0])
            self.prenom.setText(valeur[1])
            self.personnel.setText(valeur[2])
            self.entrer()

    def entrer(self) -> None:
        nom, prenom, code = self.nom.text(), self.prenom.text(), self.personnel.text()
        chiffree = self.cat["classes"].get(cle_de(self.classe))
        identite = identifier(chiffree, self.cle, nom, prenom, code)
        if isinstance(identite, str):
            self.message.setText(f"<span style='color:#c0392b'>{escape(identite)}</span>")
            return
        self.identite = identite
        # le mot de passe professeur ne s'écrit nulle part, même dans le navigateur : il le retape
        self.retenir(None if identite.professeur else (identite.nom, identite.prenom, code.strip()))
        self.personnel.clear()
        self.message.clear()
        self.tableau = construire(self.classe, self.texte, self.cat, self.ouvrir,
                                  lambda nom_sujet: self.commencee(nom_sujet, identite), self.maintenant, identite.eleve,
                                  self.lire_bilan, identite.professeur, "" if identite.professeur else code.strip())
        changer = QPushButton("Changer d'élève")
        changer.clicked.connect(self.changer)
        self.tableau.pile.insertWidget(0, changer, 0, Qt.AlignmentFlag.AlignRight)
        self.addWidget(self.tableau)
        self.setCurrentWidget(self.tableau)

    def changer(self) -> None:
        """Retour à l'entrée, l'appareil oublie l'élève (son nom reste pré-rempli, pas son code)."""
        self.retenir(None)
        self.identite = None
        if self.tableau is not None:
            self.removeWidget(self.tableau)
            self.tableau.deleteLater()
            self.tableau = None
        self.setCurrentWidget(self.connexion)


def main() -> int:
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("action", nargs="?", choices=["catalogue", "liens"],
                           help="catalogue : écrit tableau.json dans le dossier Dropbox ; liens HOTE : les adresses des classes")
    analyseur.add_argument("hote", nargs="?", help="liens : l'adresse de la page, celle de HOTE dans web/deployer.conf")
    analyseur.add_argument("--classe", help="montre le tableau de cette classe")
    analyseur.add_argument("--dropbox", type=Path, default=DROPBOX)
    analyseur.add_argument("-o", "--sortie", type=Path, help="tableau.json ailleurs que dans le dossier Dropbox")
    analyseur.add_argument("--depose", nargs="*", default=[], help="catalogue : les .qcm que deployer.sh vient de déposer")
    a = analyseur.parse_args()
    if a.action == "catalogue":
        sortie = a.sortie or a.dropbox / CATALOGUE
        cat = catalogue(a.dropbox, a.depose)
        sortie.write_text(json.dumps(cat, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        print(f"{sortie} : {len(cat['sujets'])} sujets déposés")
        return 0
    if a.action == "liens":  # à taper par le professeur : chaque adresse porte la clé de la liste de sa classe
        secret = codes.professeur()
        if not (secret and a.hote):
            analyseur.error("liens HOTE, sur la machine du professeur")
        for chemin in sorted(LISTES.glob("*.csv")):
            print(f"{chemin.stem} : {a.hote.rstrip('/')}/?{urlencode({'classe': chemin.stem, 'cle': cle_de_classe(secret, chemin.stem)})}")
        return 0
    if not a.classe:
        analyseur.error("--classe, catalogue ou liens")
    from modele import application  # noqa: PLC0415
    from qtpy6.QtCore import QProcess  # noqa: PLC0415
    app = application()
    lire = lambda nom: (a.dropbox / nom).read_text(encoding="utf-8") if (a.dropbox / nom).exists() else None  # noqa: E731
    lecteur = str(Path(__file__).with_name("lecteur.py"))
    secret = codes.professeur()  # la clé de la classe, en mémoire seulement : c'est l'adresse des élèves qui la porte
    tableau = Portail(a.classe, lire(ECHEANCES), lire(CATALOGUE), cle_de_classe(secret, a.classe) if secret else "",
                      lambda e: QProcess.startDetached(sys.executable, [lecteur, str(a.dropbox / e.lien)]),
                      lire_bilan=lambda chemin, rappel: rappel(b.read_bytes() if (b := a.dropbox / chemin).is_file() else None))
    tableau.resize(760, 600)
    tableau.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
