"""Le tableau de bord d'une classe : ses TP, révisions et mini-interrogations, chacun avec son état et un bouton pour le
commencer ou le continuer, et en bas les bilans de l'élève (copies, thèmes, année), sans passer par Teams pour chercher un lien (demande de l'utilisateur, 25/10/2026 : « un tableau
de bord SmartTeacher en qtpy6 avec des boutons pour démarrer ou reprendre un TP ou autre »).

Deux fichiers du dossier Dropbox de l'application, à sa racine, le font :
    echeances.csv     écrit à la main par le professeur (format du Worker 59, LibreOffice, « ; », heure de Paris en
                      « JJ/MM/AAAA HH:MM ») : sujet;classe;debut;fin_creneau;echeance, le sujet relatif à sujets/ sans .json ;
    tableau.json      écrit ici (``catalogue``, à chaque déploiement) : pour chaque sujet déposé, son nom et le
                      chemin de son .qcm dans Dropbox, celui que le lien ``?sujet=`` des élèves ouvre ; pour chaque
                      classe de ``listes/``, ses inscrits chiffrés (``classes_chiffrees``).
Le premier est relu à chaque ouverture de la page : une échéance changée se voit sans redéployer.

En ligne, la page ``?classe=SECONDE 5&cle=…`` (``web/pyqt6/pont_tableau.py``) montre ``Portail`` plein canevas : l'élève
y entre par son nom, son prénom et son mot de passe, vérifiés sur la liste de sa classe et le
fichier d'empreintes (``codes.IDENTITES``) comme à l'accueil d'un sujet
(l'utilisateur, 26/10/2026 : « Il faut rentrer le nom, prénom, et mot de passe pour arriver sur l'accueil, par contre le
navigateur peut retenir cela […] Les navigateurs ne seront pas partagés »), puis voit ``Tableau`` ; un bouton ouvre le
sujet à la place du tableau. En natif, ``tableau_eleves.py --classe "SECONDE 5"`` montre le même portail sur le dossier
Dropbox synchronisé, et un bouton lance ``lecteur.py`` sur le .qcm. ``tableau_eleves.py catalogue`` écrit tableau.json,
``tableau_eleves.py liens HOTE`` les adresses des classes, clé comprise, que le professeur leur donne.

Rien de nominatif ni de secret en clair : la page et son dossier Dropbox sont lisibles de tous (le jeton est dans la
page). La liste d'une classe y est chiffrée par une clé que seule son adresse porte, comme le code de classe porte celle
d'un sujet ; un sujet à venir n'a pas de bouton."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import sys
import tempfile
from dataclasses import dataclass, field
from html import escape, unescape
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable
from urllib.parse import urlencode

import bilans_widget
import codes
import echeances
from noyau import ECRAN, SOUMISSIONS, TEMPS
from qtpy6.QtCore import QSize, Qt
from qtpy6.QtGui import QColor, QFontMetrics, QIcon, QPainter, QPen
from qtpy6.QtWidgets import (QComboBox, QDateTimeEdit, QFormLayout, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QScrollArea, QSizePolicy, QSpinBox, QStackedWidget, QToolButton, QVBoxLayout, QWidget)
from serializejson._encryption import decrypt

DROPBOX = Path("/DATA/Dropbox/Applications/SmartTeacherQcm")  # le dossier de l'application, synchronisé sur ce disque
ECHEANCES, CATALOGUE = echeances.NOM, "tableau.json"
# Les états, dans l'ordre où le tableau les montre : ce qui se fait maintenant d'abord, ce qui est fini en dernier.
EN_COURS, A_FINIR, A_VENIR, FERME = "En cours", "À finir", "À venir", "Fermé"
ETATS = (EN_COURS, A_FINIR, A_VENIR, FERME)


@dataclass
class Ligne:
    sujet: str  # relatif à sujets/, sans .json
    classe: str
    debut: datetime | None  # UTC
    fin_creneau: datetime | None
    echeance: datetime | None

    def etat(self, maintenant: datetime) -> str:
        """« En cours » pendant le créneau en classe (sans fin de créneau : jusqu'à l'échéance), « À finir » ensuite jusqu'à
        l'échéance, « À venir » avant, « Fermé » après."""
        if self.debut and maintenant < self.debut:
            return A_VENIR
        if self.echeance and maintenant >= self.echeance:
            return FERME
        if self.fin_creneau and maintenant >= self.fin_creneau:
            return A_FINIR
        return EN_COURS


def date_de_paris(texte: str) -> datetime | None:
    """« JJ/MM/AAAA HH:MM » à l'heure de Paris, en UTC (``echeances.instant``, celle du lecteur) ; None si vide."""
    texte = texte.strip()
    if not texte:
        return None
    try:
        return echeances.instant(texte)
    except ValueError:
        raise ValueError(f"« {texte} » n'est pas une date « JJ/MM/AAAA HH:MM »") from None


def cle_de(nom: str) -> str:
    """Un sujet ou une classe, quelle que soit sa graphie : seul le dernier nom d'un chemin compte (``echeances``), et
    « 2nd 5 » tapé dans l'adresse comme « 2nd_5 » ou « 2ND5 », « Les réseaux sociaux - TP2 » comme le nom de son .qcm
    (« Les_reseaux_sociaux_-_TP2 ») : la même chose ; et un sujet « Listes : méthodes » comme son .qcm, que
    ``codes.nom_de_fichier`` écrit « Listes_-_methodes » (06/11/2026 : la ligne du TP03 de Terminale sans bouton)."""
    return codes.en_ascii(codes.nom_de_fichier(nom.strip().replace("\\", "/").rpartition("/")[2])).replace("_", "").lower()


def nom_de_revision(chemin: tuple[str, ...], sorte: str) -> str:
    """Le nom du sujet ``sorte`` (« entraînement », « validation ») de la section ``chemin`` de « Réviser » (thème, section,
    sous-section…), celui que compose ``entrainement.py`` et sous lequel le catalogue le range (``cle_de``)."""
    return " - ".join(p.replace("/", "-") for p in chemin) + f" - {sorte}"


def revision(revisions: dict[str, Any], chemin: tuple[str, ...], sorte: str) -> dict[str, Any] | None:
    """L'entrée du catalogue (``lien``, ``nom``) du sujet ``sorte`` de la section ``chemin`` : celui de la section la plus
    proche qui a son entraînement, elle-même ou un parent (``entrainement.py`` ne double pas les sujets d'une section qui
    n'a qu'une sous-section) ; ``None`` s'il n'y en a aucun de déposé. Une section qui a son entraînement mais pas de
    Validation (réservoir trop maigre) n'en propose AUCUNE : celle du parent porterait sur d'autres questions (relecture
    de W173, 06/11/2026)."""
    def deposee(n: int, sorte: str) -> dict[str, Any] | None:
        trouve = revisions.get(cle_de(nom_de_revision(chemin[:n], sorte)))
        return trouve if isinstance(trouve, dict) and trouve.get("lien") else None
    n = next((n for n in range(len(chemin), 0, -1) if deposee(n, "entraînement")), 0)
    return deposee(n, sorte) if n else None


def reviser(revisions: dict[str, Any], chemin: tuple[str, ...]) -> dict[str, Any] | None:
    """L'entrée du catalogue que le bouton « Réviser » de la section ``chemin`` ouvre : le sujet « Réviser » de son THÈME
    (``entrainement.py``, une banque par thème, décision du 06/11/2026 22:14), à défaut l'entraînement de la section
    (``revision``, sujets de la rév. 2228, jusqu'à leur mise à la corbeille)."""
    trouve = revisions.get(cle_de(nom_de_revision(chemin[:1], "réviser")))
    return trouve if isinstance(trouve, dict) and trouve.get("lien") else revision(revisions, chemin, "entraînement")


def meme_classe(a: str, b: str) -> bool:
    return cle_de(a) == cle_de(b)


class Erreur(str):
    """Une erreur du fichier d'échéances, avec la classe de sa ligne (``classe`` vide : inconnue). L'élève ne voit que
    celles de sa classe, le professeur toutes (l'utilisateur, 26/10/2026)."""

    def __new__(cls, texte: str, classe: str = "") -> Erreur:
        erreur = super().__new__(cls, texte)
        erreur.classe = classe
        return erreur


def lire_echeances(texte: str) -> tuple[list[Ligne], list[Erreur]]:
    """Les lignes du fichier d'échéances, et les erreurs d'une ligne illisible (sautée, pas fatale : le professeur l'écrit à
    la main). Pour un même sujet et une même classe, la dernière ligne l'emporte, comme dans ``echeances.trouver``."""
    lignes, erreurs, numero = {}, [], 1
    texte = echeances.sans_signature(texte)  # sa ligne de signature n'est pas une ligne illisible
    try:
        for numero, champs in enumerate(csv.DictReader(io.StringIO(texte.lstrip("﻿")), delimiter=";"), start=2):
            try:
                sujet, classe = champs["sujet"].strip(), champs["classe"].strip()
                if sujet and classe:
                    lignes[cle_de(sujet), cle_de(classe)] = Ligne(sujet, classe, *(date_de_paris(champs.get(c) or "")
                                                                                 for c in ("debut", "fin_creneau", "echeance")))
            except (KeyError, ValueError, AttributeError) as erreur:
                erreurs.append(Erreur(f"ligne {numero} : {erreur}", str(champs.get("classe") or "").strip()))
    except csv.Error as erreur:  # une case démesurée : la suite du fichier est perdue, pas ce qui est déjà lu
        erreurs.append(Erreur(f"ligne {numero + 1} et suivantes illisibles : {erreur}"))
    return list(lignes.values()), erreurs


LISTES = Path(__file__).parent / "listes"  # les listes des classes, celles que l'export inscrit dans les sujets


def sel_de_classe(classe: str) -> bytes:
    """Le sel de la liste chiffrée d'une classe, tiré de son nom : la clé (``cle_de_classe``), donc l'adresse donnée à la
    classe, reste la même d'un déploiement à l'autre."""
    return hashlib.sha256(f"smartteacher|tableau|{cle_de(classe)}".encode()).digest()[:16]


def cle_de_classe(secret: str, classe: str) -> str:
    """La clé de la liste de ``classe`` (``codes.cle_sujet`` : six caractères), que porte l'adresse de son tableau."""
    return codes.cle_sujet(secret, sel_de_classe(classe))


def arguments_du_lecteur(programme: str, chemin: Path, jeton: str) -> list[str]:
    """Le lecteur natif ouvert sur un sujet du tableau, avec le code de la classe : l'élève n'en tape aucun."""
    return [programme, str(chemin), *(["--mot-de-passe", codes.phrase_du_jeton(jeton)] if jeton else [])]


def jetons_du_sujet(definition: Any, secret: str) -> dict[str, str]:
    """Pour chaque classe inscrite dans le ``.qcm`` du sujet ``definition``, le code qui l'ouvre pour elle (``codes.jeton`` : ce
    que porte ``?code=``), sans date : c'est ``echeances.csv`` qui les donne (``echeances.appliquer``). Le rang de la classe
    est celui que lit ``Accueil.deverrouiller``, ``sorted(paquet.inscrits)``."""
    import exporter_eleve  # noqa: PLC0415 - côté professeur seulement
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas sujet.py
    classes = sorted({Path(liste).stem for liste in exporter_eleve.listes_du_sujet(definition)})  # deux niveaux peuvent partager une liste
    if len(classes) > codes.CLASSES:  # l'export le refuse : ce sujet n'a pas de .qcm à ces classes
        return {}
    cle = exporter_eleve.cle_neuve(module_sujet.graine_de(definition), secret)[1]
    return {classe: codes.jeton(codes.code_classe(cle, rang)) for rang, classe in enumerate(classes)}


def jetons_du_paquet(chemin: Path, secret: str) -> dict[str, str]:
    """Comme ``jetons_du_sujet``, mais lus dans le ``.qcm`` déposé ``chemin`` : ses classes inscrites et sa clé (celle de son
    en-tête), pour un .qcm que son sujet n'exporte plus là (Pyxel de Terminale, déposé le 11/10/2026 par l'ancien champ
    « niveaux », retiré à la rév. 951) : les classes d'aujourd'hui n'y ont plus le même rang. Rien s'il ne s'ouvre pas."""
    import modele  # noqa: PLC0415 - côté professeur seulement
    try:
        cle = codes.cle_du_mot(secret, chemin.read_bytes())
        classes = sorted(modele.charger(chemin, cle).inscrits)
    except Exception:  # noqa: BLE001 - un .qcm illisible garde son bouton, sans code de classe
        return {}
    return {classe: codes.jeton(codes.code_classe(cle, rang)) for rang, classe in enumerate(classes)}


def qcm_des_echeances(dropbox: Path) -> dict[str, list[str]]:
    """Sous ``cle_de`` de leur sujet, les chemins de ``.qcm`` (relatifs à ``dropbox``) que nomment les lignes de son
    echeances.csv : la place d'un sujet déposé ailleurs que là où il s'exporte aujourd'hui."""
    fichier = dropbox / ECHEANCES
    if not fichier.exists():
        return {}
    resultat: dict[str, list[str]] = {}
    for ligne in lire_echeances(fichier.read_text(encoding="utf-8"))[0]:
        sujet = ligne.sujet.strip().replace("\\", "/").lstrip("/").removesuffix(".qcm")
        resultat.setdefault(cle_de(sujet), []).append(f"{sujet}.qcm")
    return resultat


def classes_chiffrees(secret: str, listes: Path = LISTES, jetons: dict[str, dict[str, str]] | None = None) -> dict[str, str]:
    """Pour chaque liste de ``listes`` (« SECONDE 5.csv »), sous ``cle_de`` de la classe, ses inscrits tels qu'un sujet les
    porte (``codes.inscrire`` : nom, prénom) et les ``jetons`` de ses sujets (sous ``cle_de`` du sujet : jamais en clair dans
    tableau.json, public), dans un fichier age en armure, par la clé de la classe ; le mot de passe professeur l'ouvre aussi
    (``codes.cle_du_mot`` sur son sel)."""
    from serializejson._encryption import encrypt, prime  # noqa: PLC0415 - côté professeur seulement

    resultat = {}
    for chemin in sorted(listes.glob("*.csv")):
        classe = chemin.stem
        cle = cle_de_classe(secret, classe)
        prime(cle, sel_de_classe(classe))
        contenu = {"classe": classe, "inscrits": codes.inscrire(codes.lire_liste(chemin)), "codes": (jetons or {}).get(classe, {})}
        resultat[cle_de(classe)] = encrypt(json.dumps(contenu, ensure_ascii=False).encode(), cle, armor=True)
    return resultat


@dataclass
class Identite:
    """Qui est entré : l'élève tel que la liste le nomme, ou le professeur (``nom`` et ``prenom`` vides). Entré par son mot
    de passe : son ``secret``, qui ouvre aussi son bilan, et l'empreinte à déposer d'une première visite (``depot``). Lus dans
    la liste de sa classe, les ``jetons`` qui ouvrent ses sujets, sans rien lui demander (``jetons_du_sujet``)."""
    nom: str
    prenom: str
    professeur: bool = False
    secret: bytes | None = None
    depot: dict[str, str] | None = None
    jetons: dict[str, str] | None = None
    # le professeur entré par son mot de passe : la graine qui signe echeances.csv (``codes.graine_echeances``,
    # ``regler_par``), jamais affichée ni comparée
    graine: bytes | None = field(default=None, repr=False, compare=False)

    @property
    def eleve(self) -> str:
        return f"{self.nom} {self.prenom}".strip()


def ouvrir_liste(chiffree: str, cle: str) -> dict[str, Any] | None:
    """La liste d'une classe (``classes_chiffrees``) ouverte par ``cle``, ou None si elle ne l'ouvre pas."""
    try:
        contenu = json.loads(bytes(decrypt(chiffree, cle)).decode())
    except Exception:  # noqa: BLE001 - mauvaise clé, liste abîmée : elle ne s'ouvre pas, l'élève le lit
        return None
    return contenu if isinstance(contenu, dict) and isinstance(contenu.get("inscrits"), list) else None


def identifier(chiffree: str | None, cle: str, nom: str, prenom: str, code: str, identites: dict[str, Any] | None = None,
               garde: tuple[str, str, bytes] | None = None) -> Identite | str:
    """L'entrée du tableau : l'élève de la liste (ouverte par la ``cle`` de l'adresse), reconnu malgré ses fautes
    (``codes.reconnaitre``), entré par son mot de passe, celui
    tapé ou celui que l'appareil ``garde``, comme à l'accueil d'un sujet (``codes.reconnaitre_mot_de_passe`` sur le
    fichier d'empreintes ``identites``) ; ou le professeur,
    son mot de passe tapé comme code (``codes.cle_du_mot`` ouvre la liste). Rend l'``Identite``, ou ce qui ne va pas. Le
    professeur n'est essayé qu'à défaut d'élève reconnu : chaque essai coûte une seconde (scrypt)."""
    code, nom, prenom = code.strip(), nom.strip(), prenom.strip()
    if not chiffree:
        return "La liste de cette classe n'est pas encore en ligne : le professeur doit la déposer."
    if not code and garde is None:
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    liste = ouvrir_liste(chiffree, cle) if cle else None
    inscrit = liste and nom and prenom and codes.reconnaitre(nom, prenom, liste["inscrits"])
    if inscrit:
        cle_eleve = codes.nom_identite(inscrit[0], inscrit[1])
        secret = garde[2] if garde and codes.nom_identite(*garde[:2]) == cle_eleve else None
        reconnu = codes.reconnaitre_mot_de_passe(identites or {}, inscrit[0], inscrit[1], code, secret)
        if isinstance(reconnu, str):
            return reconnu
        return Identite(inscrit[0], inscrit[1], secret=reconnu.secret, depot=reconnu.depot, jetons=liste.get("codes"))
    if not code:
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    mot = codes.cle_du_mot(code, chiffree.encode())
    if mot and ouvrir_liste(chiffree, mot) is not None:
        return Identite("", "", professeur=True, graine=codes.graine_echeances(code))
    if liste is None:
        return "Cette adresse ne permet pas d'entrer : demandez au professeur le lien de votre classe."
    if not (nom and prenom):
        return "Écrivez votre prénom, votre nom et votre mot de passe."
    return f"« {nom} {prenom} » n'est pas sur la liste de la classe {liste.get('classe', '')} : vérifiez l'orthographe."


# Les sections de la page d'une classe, dans cet ordre sous chaque thème (l'utilisateur, 06/11/2026 : « organiser la page
# par thème, puis TP, Révisions, Mini-interrogation, DS ») : le nom du dossier du cours, puis le titre montré.
# le dossier d'un sujet → la sous-section de son thème, dans cet ordre (l'utilisateur, 06/11/2026 : « il faut des nom de sous
# section plus clair dans les thèmes : "Cours", "Travaux pratiques", "Interrogations" (DS et mini-interrogations), "Projet",
# "Bilan" ») ; « Cours » ne vient pas d'un dossier (``Tableau._cours_du_theme``), le bilan du thème va sous « Réviser »
# (``bilans_dans_les_themes``)
# « Réviser » entre « Cours » et « Travaux pratiques » (l'utilisateur, 06/11/2026 : « dans chaque thème il faut une
# sous-section "Réviser" », « entre "cours" et "travaux pratiques" »)
TYPES = {"Révisions": "Réviser", "TP": "Travaux pratiques", "Mini-Interrogations": "Interrogations", "DS": "Interrogations",
         "Projet": "Projet", "Projets": "Projet"}
AUTRES = "Autres"  # un sujet que rien ne range


def theme_et_type(dossier: str) -> tuple[str, str]:
    """Le thème et le type d'un sujet, tirés de son ``dossier`` de cours : « NSI/NSI Première/Python/TP » → (« Python »,
    « TP »), « SNT/Python/TP/SANS IDE » → (« Python », « TP »), « SNT/DS » → (« SNT », « DS ») ; sans type connu, le dernier
    dossier (« Pyxel/Projet Monkey ») ; (« », « ») sans dossier."""
    parties = [p for p in dossier.replace("\\", "/").split("/") if p]
    rangs = [i for i, p in enumerate(parties) if p in TYPES]
    i = rangs[-1] if rangs else len(parties) - 1
    if i < 1:
        return "", ""
    return parties[i - 1], parties[i]


def theme_du_nom(nom: str) -> tuple[str, str]:
    """Le repli de ``theme_et_type`` pour un sujet que le catalogue ne range pas (absent, ou tableau.json d'avant le
    06/11/2026) : « Python - TP08 - Titre » → (« Python », « TP »)."""
    morceaux = [m.strip() for m in nom.split(" - ")]
    sorte = morceaux[1] if len(morceaux) > 1 else ""
    for prefixe, dossier in (("TP", "TP"), ("Révision", "Révisions"), ("Mini-", "Mini-Interrogations"), ("DS", "DS"),
                             ("Projet", "Projet")):
        if sorte.startswith(prefixe):
            return morceaux[0], dossier
    return (morceaux[0], AUTRES) if len(morceaux) > 1 else ("", AUTRES)


def catalogue(dropbox: Path = DROPBOX, deposes: Iterable[str] = (), secret: str | None = None,
              listes: Path = LISTES) -> dict[str, Any]:
    """tableau.json : pour chaque sujet de sujets/ dont le .qcm est déposé dans ``dropbox`` ou dans ``deposes`` (ses chemins
    dans Dropbox : ceux que deployer.sh vient d'envoyer, que le client Dropbox n'a peut-être pas encore rapatriés), le chemin du .qcm dans Dropbox (sans « / » de tête, celui de ``?sujet=``) et son nom (``Paquet.nom`` : la place de la
    copie dans le navigateur, ``pont_qt.cle``, et le titre que le tableau montre, « Thème - TP2 - Titre » comme les
    fichiers), sous ``cle_de`` de son nom ; et sous « classes », les listes chiffrées (``classes_chiffrees``) par le mot
    de passe professeur ``secret`` (``codes.professeur()`` par défaut ; sans lui, aucune classe : personne n'entre)."""
    import sujet as module_sujet  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas sujet.py
    sys.path.insert(0, str(Path(__file__).parent / "web"))
    from dropbox_professeur import place  # noqa: PLC0415
    secret = secret or codes.professeur()
    sujets, deposes, jetons = {}, {d.lstrip("/") for d in deposes}, {}
    ailleurs = qcm_des_echeances(dropbox)
    for chemin in sorted(module_sujet.SUJETS.rglob("*.json")):
        try:
            definition = module_sujet.lire(chemin)
        except Exception:  # noqa: BLE001, S112 - un sujet en chantier ne doit pas priver la classe de son tableau
            continue
        relatif = chemin.relative_to(module_sujet.SUJETS).with_suffix("").as_posix()
        lien = place(module_sujet.sortie(definition, "qcm") / f"{codes.nom_de_fichier(chemin.stem)}.qcm")
        depose = lien.lstrip("/") in deposes or (dropbox / lien.lstrip("/")).exists()
        if not depose:  # déposé ailleurs, à la place que nomme echeances.csv : le .qcm d'avant (Pyxel de Terminale)
            lien = next((q for q in ailleurs.get(cle_de(relatif), ()) if q in deposes or (dropbox / q).exists()), "")
            if not lien:
                continue
        sujets[cle_de(relatif)] = {"lien": lien.lstrip("/"), "nom": chemin.stem}
        theme, sorte = theme_et_type(definition.dossier or "")
        if theme:  # la section de la page où il se range (``Tableau``)
            sujets[cle_de(relatif)].update(theme=theme, type=sorte)
        # ses PDF de cours, que la page range dans son thème (l'utilisateur, 06/11/2026 : « il faut ajouter un section cours
        # avec les pdf de cours dans chaque thème ») : leur place dans Dropbox, celle où deployer.sh les dépose, et leur titre
        # et le PDF de son diaporama, s'il existe (« pour les cours il faut proposer la version pdf et la version slides »)
        if cours := [[place(module_sujet.PROF / c).lstrip("/"), Path(c).stem,
                      place(d).lstrip("/") if (d := module_sujet.diaporama(module_sujet.PROF / c)).exists() else ""]
                     for c in getattr(definition, "cours", None) or ()]:
            sujets[cle_de(relatif)]["cours"] = cours
        if duree := getattr(definition, "duree_minutes", None):  # ce que montrent les réglages en ligne d'une ligne sans durée
            sujets[cle_de(relatif)]["duree"] = duree
        sien = (jetons_du_sujet(definition, secret) if depose else jetons_du_paquet(dropbox / lien, secret)) if secret else {}
        for classe, jeton in sien.items():
            jetons.setdefault(classe, {})[cle_de(relatif)] = jeton
    return {"version": 1, "sujets": sujets, "classes": classes_chiffrees(secret, listes, jetons) if secret else {}}


@dataclass
class Entree:
    """Une ligne du tableau : ce que le bouton ouvre (``lien`` vide : rien, pas encore déposé ou à venir), et le code que le
    bouton lui passe pour l'élève de cette classe (``jeton``), qui n'a ainsi aucun code à taper."""
    ligne: Ligne
    etat: str
    lien: str
    nom: str
    jeton: str = ""
    theme: str = ""  # sa section sur la page (``theme_et_type``)
    type: str = AUTRES
    cours: tuple[tuple[str, str, str], ...] = ()  # ses cours : (PDF dans Dropbox, titre, PDF du diaporama ou ""), section « Cours »


def entrees(lignes: list[Ligne], cat: dict[str, Any], classe: str, maintenant: datetime,
            jetons: dict[str, str] | None = None) -> list[Entree]:
    """Les lignes de ``classe``, dans l'ordre des ``ETATS``, puis par échéance la plus proche (la plus récente d'abord pour
    les fermés)."""
    resultat = []
    for ligne in lignes:
        if not meme_classe(ligne.classe, classe):
            continue
        connu = cat["sujets"].get(cle_de(ligne.sujet))
        connu = connu if isinstance(connu, dict) else {}
        etat = ligne.etat(maintenant)
        nom = connu.get("nom", ligne.sujet.rpartition("/")[2])
        theme, sorte = (connu["theme"], connu.get("type", AUTRES)) if connu.get("theme") else theme_du_nom(nom)
        resultat.append(Entree(ligne, etat, "" if etat == A_VENIR else connu.get("lien", ""), nom,
                               (jetons or {}).get(cle_de(ligne.sujet), ""), theme, sorte,
                               tuple((str(c[0]), str(c[1]), str(c[2]) if len(c) == 3 else "")
                                     for c in connu.get("cours", ()) if len(c) in (2, 3))))  # 2 : avant les diaporamas
    def rang(e: Entree) -> tuple[int, float]:
        date = e.ligne.echeance or e.ligne.debut
        instant = date.timestamp() if date else float("inf")
        return ETATS.index(e.etat), -instant if e.etat == FERME else instant

    return sorted(resultat, key=rang)


def ranger(liste: list[Entree]) -> list[tuple[str, list[tuple[str, list[Entree]]]]]:
    """Les entrées par thème (ordre alphabétique), puis par type dans l'ordre des ``TYPES`` (les autres après, par nom),
    puis par numéro (« TP08 » avant « TP10 », celui du deuxième morceau du nom), à égalité par nom."""
    def numero(e: Entree) -> tuple[int, str]:
        morceaux = e.nom.split(" - ")
        chiffres = re.search(r"\d+", morceaux[1]) if len(morceaux) > 1 else None
        return int(chiffres.group()) if chiffres else 10**6, e.nom.casefold()

    ordre = list(dict.fromkeys(TYPES.values()))
    themes: dict[str, dict[str, list[Entree]]] = {}
    for e in liste:  # par sous-section : DS et mini-interrogations ensemble, « Interrogations »
        themes.setdefault(e.theme, {}).setdefault(TYPES.get(e.type, e.type), []).append(e)
    return [(theme, [(sorte, sorted(groupe, key=numero)) for sorte, groupe in
                     sorted(sections.items(), key=lambda s: (ordre.index(s[0]) if s[0] in ordre else len(ordre), s[0]))])
            for theme, sections in sorted(themes.items(), key=lambda t: (not t[0], t[0].casefold()))]


def a_paris(date: datetime | None) -> str:
    """Une date UTC dite à l'heure de Paris, « mar. 10/11 à 10 h 00 »."""
    if date is None:
        return ""
    locale = date + timedelta(minutes=codes._decalage_paris(codes._minutes(date)))
    jours = ("lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim.")
    return f"{jours[locale.weekday()]} {locale:%d/%m} à {locale:%H} h {locale:%M}"


def quand(e: Entree) -> str:
    """Ce que l'élève doit savoir de la date : quand ça commence, ou jusqu'à quand il a."""
    if e.etat == A_VENIR:
        return f"commence le {a_paris(e.ligne.debut)}" if e.ligne.debut else ""
    if e.etat == FERME:
        return f"fermé depuis le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else ""
    return f"à rendre avant le {a_paris(e.ligne.echeance)}" if e.ligne.echeance else ""


NIVEAUX = {"2": "Seconde", "1": "Premiere", "t": "Terminale"}  # le dossier du niveau d'une classe, faute de sujet déposé
LOGO_APPLI = Path(__file__).parent / "associations" / "teacher.svg"  # l'icône des fenêtres du lecteur, embarquée en ligne


def niveau_de(classe: str, liste: list[Entree]) -> str:
    """Le dossier du niveau de la classe dans Dropbox, où sont ses « Bilans » : celui de ses sujets déposés, sinon tiré du
    nom de la classe, celui de sa liste (« SECONDE 5 », « B3_P_NSINF_GR1 » : ``codes.niveau``), sinon de sa première
    lettre (« 2nd 5 » → Seconde, « 1G2 » → Premiere, « TG1 » → Terminale) ; vide s'il ne se devine pas."""
    dossiers = [e.lien.split("/", 1)[0] for e in liste if "/" in e.lien]
    if dossiers:
        return max(set(dossiers), key=dossiers.count)
    try:
        return codes.en_ascii(codes.niveau(classe))
    except ValueError:
        return NIVEAUX.get(classe.strip().lower()[:1], "")


MARGES_TITRE = (10, 6, 10, 6)  # autour du texte d'un titre, qu'on puisse le presser ou non


class Cours(QWidget):
    """Un PDF de cours ouvert depuis la page (``Tableau._cours_du_theme``), page entière à la largeur de la fenêtre ;
    ``octets`` None : « introuvable », à la place du document."""

    def __init__(self, titre: str, octets: bytes | None) -> None:
        super().__init__()
        self.setWindowTitle(titre)
        couche = QVBoxLayout(self)
        couche.setContentsMargins(0, 0, 0, 0)
        if octets is None:
            couche.addWidget(QLabel(f"Le cours « {escape(titre)} » est introuvable pour l'instant.",
                                    alignment=Qt.AlignmentFlag.AlignCenter, wordWrap=True))
            return
        from qtpy6.QtCore import QBuffer, QByteArray, QMargins  # noqa: PLC0415
        from qtpy6.QtPdf import QPdfDocument  # noqa: PLC0415 - chargé seulement quand un cours s'ouvre
        from qtpy6.QtPdfWidgets import QPdfView  # noqa: PLC0415
        self.vue = QPdfView()
        self.vue.setPageMode(QPdfView.PageMode.MultiPage)
        self.vue.setZoomMode(QPdfView.ZoomMode.FitToWidth)
        self.vue.setDocumentMargins(QMargins())
        couche.addWidget(self.vue)  # enfant avant le document : détruite avant lui (voir la vue du cours de modele.py)
        self.document = QPdfDocument(self)
        self.tampon = QBuffer(self.document)  # lu au fil des pages : il vit aussi longtemps que le document
        self.tampon.setData(QByteArray(octets))
        self.tampon.open(QBuffer.OpenModeFlag.ReadOnly)
        self.document.load(self.tampon)
        self.vue.setDocument(self.document)


class TitreBouton(QPushButton):
    """Le titre d'un sujet, qu'on presse pour l'ouvrir (l'utilisateur, 03/11/2026 : « que les titres de la liste soient
    directement des boutons »). Un QPushButton ne sait ni le texte riche ni le retour à la ligne : un QLabel dedans les porte,
    et laisse passer la souris ; c'est sa couche qui donne la hauteur, selon la largeur."""

    def __init__(self, texte: QLabel, nom: str) -> None:
        super().__init__()
        self.titre = texte
        texte.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        couche = QVBoxLayout(self)
        couche.setContentsMargins(*MARGES_TITRE)
        couche.addWidget(texte)
        self.setAccessibleName(nom)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)

    def sizeHint(self) -> QSize:
        return self.layout().sizeHint()

    def minimumSizeHint(self) -> QSize:
        return self.layout().minimumSize()


ESPACE_ENTETE = 6  # entre la ligne de titre de la page et ce qui suit
AU_DESSUS = {"h1": 18, "h2": 12, "h3": 8}  # l'espace au-dessus d'un titre de section, selon son niveau (px)


def titre_de_section(texte: str, haut: int | None = None) -> QLabel:
    """Un titre de la page (« <h2>…</h2> »), avec de l'espace au-dessus (l'utilisateur, 06/11/2026 : « il faut ajouter un peu
    d'espace au dessus de tout les titre de section et sous-section »)."""
    etiquette = QLabel(texte)
    etiquette.setContentsMargins(0, AU_DESSUS.get(texte[1:3], 0) if haut is None else haut, 0, 0)
    return etiquette


ECART_GRIS = 12  # entre le nom et sa partie grise, quand elles tiennent sur une ligne


def texte_du_titre(nom: str, gris: str, une_ligne: bool = True) -> str:
    """Le texte du bouton d'un sujet : son nom en entier, en gras, et sa date ou sa note en gris sur la même ligne, à droite
    (l'utilisateur, 06/11/2026 : « la partie grise à la ligne, plutot la mettre sur la meme ligne à droite ») ; sous le
    nom quand la ligne ne les tient pas (« sur téléphone il faudra certainement plutot metre à la ligne »)."""
    if not une_ligne:
        return f"<b>{nom}</b><br><span style='color:#606060'>{gris}</span>"
    return (f"<table width='100%' cellspacing=0 cellpadding=0><tr><td><b>{nom}</b></td>"
            f"<td align=right style='color:#606060; padding-left:{ECART_GRIS}px'>{gris}</td></tr></table>")


class TitreDeSujet(QLabel):
    """Le texte d'un sujet (``texte_du_titre``), qui passe la partie grise à la ligne quand sa largeur ne tient plus le nom
    et elle côte à côte : un tableau du texte riche de Qt ne se replie pas de lui-même."""

    def __init__(self, nom: str, gris: str) -> None:
        super().__init__()
        self.setWordWrap(True)
        self.setTextFormat(Qt.TextFormat.RichText)
        self.poser(nom, gris)

    def poser(self, nom: str, gris: str) -> None:
        self.nom, self.gris, self.une_ligne = nom, gris, None
        self._choisir(self.width())

    def _choisir(self, largeur: int) -> None:
        gras = self.font()
        gras.setBold(True)
        besoin = QFontMetrics(gras).horizontalAdvance(self.nom) + QFontMetrics(self.font()).horizontalAdvance(unescape(re.sub('<[^>]+>', '', self.gris))) + ECART_GRIS
        une_ligne = not self.gris or besoin <= largeur - 2 * self.margin()
        if une_ligne != self.une_ligne:
            self.une_ligne = une_ligne
            self.setText(texte_du_titre(self.nom, self.gris, une_ligne))

    def resizeEvent(self, evenement) -> None:
        self._choisir(evenement.size().width())
        super().resizeEvent(evenement)


SANS_ECHEANCE, SANS_DUREE = "sans échéance", "sans durée"  # le vrai état : le code n'en porte pas, le sujet non plus
FORMAT_QT = "dd/MM/yyyy HH:mm"  # ``echeances.FORMAT`` dit par Qt
Regler = Callable[[str, str, dict[str, str], Callable[[str | None, str], None]], None]
# ``regler(sujet, classe, changements, rappel)`` : ``changements`` (colonne → case, ``echeances.recopier``) écrits dans
# echeances.csv, puis ``rappel(texte, message)`` : le texte du fichier après coup (None : illisible), et ce qu'il en est dit


def message_reglage(sujet: str, classe: str, ecrite: bool | None, erreur: Exception | None = None) -> str:
    """Ce que la page dit d'un « Enregistrer » : la ligne ajoutée, rien à changer, ou pourquoi le fichier n'est pas touché."""
    quoi = f"{sujet.rpartition('/')[2]}, {classe} : {echeances.NOM}"
    if erreur is not None:
        return f"{quoi} NON modifié ({erreur})."
    return f"{quoi} complété d'une ligne, qui vaut pour les élèves sans redéployer." if ecrite else f"{quoi} disait déjà cela."


def regler_sur_disque(sujet: str, classe: str, changements: dict[str, str], rappel: Callable[[str | None, str], None]) -> None:
    """``Regler`` en natif : la ligne ajoutée au fichier synchronisé par le client Dropbox (``echeances.regler``)."""
    try:
        message = message_reglage(sujet, classe, echeances.regler(sujet, classe, changements))
    except (OSError, ValueError) as erreur:
        message = message_reglage(sujet, classe, None, erreur)
    rappel(echeances.du_disque(), message)


async def regler_par(lire: Callable[[], Any], ecrire: Callable[[str, str | None], Any], sujet: str, classe: str,
                     changements: dict[str, str], rappel: Callable[[str | None, str], None], essais: int = 3,
                     graine: bytes | None = None) -> None:
    """``Regler`` en ligne : ``lire()`` rend {texte, rev} du fichier (ou rien), ``ecrire(texte, rev)`` l'écrit sur cette
    version et rend {rev}, ou rien si quelqu'un l'a changé depuis (``dropbox.js``, ``echeances_lire`` et ``echeances_ecrire``) :
    on relit alors et on recommence, comme ``pont_qt.deposer_identite``. Le texte complété vient d'``echeances.recopier``,
    signé par ``graine`` (celle du professeur entré, ``Identite.graine``) si le fichier l'était bien (``echeances.resigner``) ;
    ``rappel`` reçoit le texte sans sa ligne de signature."""
    texte = None
    for _ in range(essais):
        try:
            lu = await lire()
            texte, rev = (str(lu.texte), str(lu.rev)) if getattr(lu, "texte", None) is not None else (None, None)
            nouveau = echeances.recopier(texte, sujet, classe, changements)
            if nouveau is None:
                rappel(texte and echeances.sans_signature(texte), message_reglage(sujet, classe, False))
                return
            nouveau = echeances.resigner(texte or "", nouveau, graine)
            if getattr(await ecrire(nouveau, rev), "rev", None) is not None:
                rappel(echeances.sans_signature(nouveau), message_reglage(sujet, classe, True))
                return
        except Exception as erreur:  # noqa: BLE001 - réseau, quota, jeton, ou ValueError d'une valeur refusée : dit, rien d'écrit
            rappel(texte and echeances.sans_signature(texte), message_reglage(sujet, classe, None, erreur))
            return
    rappel(None, message_reglage(sujet, classe, None, ValueError("le fichier change sans cesse, réessayez")))


def maintenant_a_paris() -> datetime:
    """L'heure de Paris, sans fuseau, à la minute : celle des cases d'echeances.csv (le navigateur, lui, compte en UTC)."""
    return datetime.strptime(echeances.en_texte(datetime.now(timezone.utc)), echeances.FORMAT)


Effectives = Callable[[str, str], dict[str, str]]
# ``effectives(sujet, classe)`` : les réglages qui valent vraiment pour la classe, comme echeances.csv les écrit (colonne →
# case, ``echeances.REGLAGES``), là où sa ligne n'en dit rien : ``valeurs_du_qcm`` en natif, ``valeurs_par_defaut`` sinon


def valeurs_par_defaut(duree: int | None = None) -> dict[str, str]:
    """Les réglages d'un code de classe donné sans réglage (``codes.code_classe`` : celui que la page d'une classe passe au
    lecteur, ``jetons_du_sujet``), en cases d'echeances.csv : sans échéance, soumission 0, sans anti-triche, temps écran, et
    la durée du sujet (``duree``, vide s'il n'en a pas)."""
    return {"echeance": "", "duree": str(duree or ""), "soumission": "0", "anti_triche": "non", "temps": ECRAN}


def chemin_du_qcm(dropbox: Path, cat: dict[str, Any], sujet: str) -> Path | None:
    """Le .qcm du ``sujet`` d'une ligne d'echeances.csv sur ce disque : celui du catalogue, sinon le chemin que la ligne
    porte (sa place dans Dropbox, sans « .qcm », comme l'écrit « Générer ») ; ``None`` s'il n'y est pas."""
    connu = lire_catalogue(cat)["sujets"].get(cle_de(sujet))
    for relatif in ((connu or {}).get("lien") if isinstance(connu, dict) else None, sujet.strip().lstrip("/") + ".qcm"):
        if relatif and (chemin := dropbox / relatif).is_file():
            return chemin
    return None


def valeurs_du_qcm(chemin: Path | None, classe: str) -> dict[str, str]:
    """``Effectives`` en natif : le dernier code donné à ``classe`` pour le .qcm ``chemin`` au journal des déploiements
    (``code_eleve.du_sujet``), qui dit sa durée (celle du sujet s'il n'en porte pas), son échéance, sa soumission, son
    anti-triche et son temps ; sans code au journal, ``valeurs_par_defaut`` à la durée du sujet ; sans .qcm lisible, celles
    sans durée. Ouvrir un .qcm coûte une seconde (scrypt) : ``main`` ne le fait que pour une ligne incomplète, une fois."""
    if chemin is None:
        return valeurs_par_defaut()
    import code_eleve  # noqa: PLC0415 - côté professeur seulement : le lecteur web n'embarque pas code_eleve.py
    try:
        cle, paquet = code_eleve.ouvrir(chemin)
        donnes = [e for e in code_eleve.du_sujet(cle, paquet) if e["classe"] and meme_classe(e["classe"], classe)]
    except (OSError, ValueError, KeyError):
        return valeurs_par_defaut()
    duree = paquet.get("duree_minutes")
    if not donnes:
        return valeurs_par_defaut(duree)
    e = donnes[-1]
    return {"echeance": echeances.en_texte(e["echeance"]), "duree": str(e["duree"] or duree or ""),
            "soumission": str(e["soumission"] or 0), "anti_triche": "oui" if e["anti_triche"] else "non",
            "temps": e["temps"] or ECRAN}


def _ecrite(ligne: echeances.Ligne, colonne: str) -> str:
    """La case ``colonne`` de ``ligne`` (lue) telle que ce panneau l'écrirait ; vide si le fichier n'en dit rien de lisible."""
    valeur = getattr(ligne, colonne)
    if valeur is None:
        return ""
    if colonne == "echeance":
        return echeances.en_texte(valeur)
    if colonne == "anti_triche":
        return "oui" if valeur else "non"
    return str(valeur)


class Reglages(QFrame):
    """Sous le titre d'un sujet, pour le professeur seulement : l'échéance, la durée, le mode de soumission, l'anti-triche et le
    temps de cette classe, et « Enregistrer », qui recopie la ligne d'echeances.csv en bas avec ce qui a changé
    (``echeances.recopier``) ; seules les cases changées ici sont envoyées, une case écrite à la main que ce panneau ne sait
    pas montrer reste telle quelle. Chaque case montre une vraie valeur : celle du fichier, sinon celle qui vaut vraiment
    pour la classe (``effectives()``, appelée seulement s'il en manque) ; une ligne incomplète s'enregistre alors entière
    (l'utilisateur, 06/11/2026 : « je veux dans mon interface pour gerer les sujet qu'il n'y ai aucun champs laissé à
    "celle du code" »). « sans échéance » et « sans durée » ne disent que ce vrai état. ``regler(sujet, classe,
    changements)`` : ``Portail.regler``."""

    def __init__(self, sujet: str, classe: str, brute: dict[str, str] | None, regler: Callable[[str, str, dict[str, str]], None],
                 effectives: Callable[[], dict[str, str]] = valeurs_par_defaut, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.sujet, self.classe, self.regler = sujet, classe, regler
        self.setFrameShape(QFrame.Shape.StyledPanel)
        ligne = echeances.lire(brute)
        self.ecrites = {c: _ecrite(ligne, c) for c in echeances.REGLAGES}  # ce que dit la ligne en vigueur
        manque = echeances.manquantes(brute)
        valeurs = {**effectives(), **{c: v for c, v in self.ecrites.items() if c not in manque}} if manque else self.ecrites
        debut = datetime.strptime(echeances.en_texte(ligne.depart), echeances.FORMAT) if ligne.depart else None
        actuelle = datetime.strptime(valeurs["echeance"], echeances.FORMAT) if valeurs.get("echeance") else None
        formulaire = QFormLayout(self)
        self.echeance = QDateTimeEdit()
        self.echeance.setCalendarPopup(True)
        self.echeance.setDisplayFormat("ddd " + FORMAT_QT)
        # la plus petite valeur dit « sans échéance » : le début (une échéance doit venir après), sinon juste avant l'heure
        # ou l'échéance actuelle, qui reste lisible même passée
        plus_tot = debut or min(maintenant_a_paris(), actuelle or maintenant_a_paris()) - timedelta(minutes=1)
        self.echeance.setMinimumDateTime(plus_tot)
        self.echeance.setSpecialValueText(SANS_ECHEANCE)
        self.echeance.setDateTime(actuelle or plus_tot)
        formulaire.addRow("Échéance", self.echeance)
        self.duree = QSpinBox()
        self.duree.setRange(0, echeances.DUREE_MAX)
        self.duree.setSuffix(" min")
        self.duree.setSpecialValueText(SANS_DUREE)
        self.duree.setValue(int(valeurs["duree"]) if (valeurs.get("duree") or "").isdigit() else 0)
        formulaire.addRow("Durée", self.duree)
        self.soumission = QComboBox()
        for numero, texte in SOUMISSIONS.items():
            self.soumission.addItem(texte, str(numero))
        self.soumission.setCurrentIndex(max(0, self.soumission.findData(valeurs.get("soumission") or "0")))
        formulaire.addRow("Soumission", self.soumission)
        self.anti_triche = QComboBox()
        for texte in ("oui", "non"):
            self.anti_triche.addItem(texte, texte)
        self.anti_triche.setCurrentIndex(max(0, self.anti_triche.findData(valeurs.get("anti_triche") or "non")))
        formulaire.addRow("Anti-triche", self.anti_triche)
        self.temps = QComboBox()
        for case, texte in TEMPS.items():
            self.temps.addItem(texte, case)
        self.temps.setCurrentIndex(max(0, self.temps.findData(valeurs.get("temps") or ECRAN)))
        formulaire.addRow("Temps", self.temps)
        self.enregistrer = QPushButton("Enregistrer")
        self.enregistrer.clicked.connect(self.envoyer)
        self.enregistrer.setEnabled(self.changements() != {})
        for signal in (self.echeance.dateTimeChanged, self.duree.valueChanged, self.soumission.currentIndexChanged,
                       self.anti_triche.currentIndexChanged, self.temps.currentIndexChanged):
            signal.connect(lambda *_: self.enregistrer.setEnabled(self.changements() != {}))
        formulaire.addRow(self.enregistrer)
        self.incomplete = QLabel(f"<span style='color:#606060'>{echeances.NOM} ne dit pas tout pour cette classe : ce qui "
                                 "vaut est montré, « Enregistrer » l'y écrit.</span>")
        self.incomplete.setWordWrap(True)
        self.incomplete.setVisible(self.changements() != {})
        formulaire.addRow(self.incomplete)
        for erreur in ligne.erreurs:  # une case mal écrite à la main : ignorée par le lecteur, montrée ici à sa vraie valeur
            formulaire.addRow(QLabel(f"<span style='color:#c0392b'>{escape(erreur)}</span>"))

    def cases(self) -> dict[str, str]:
        """Ce que montre le panneau, case par case, comme echeances.csv l'écrit (vide : sans échéance, sans durée)."""
        echeance = self.echeance.dateTime()
        return {"echeance": "" if echeance == self.echeance.minimumDateTime() else echeance.toString(FORMAT_QT),
                "duree": str(self.duree.value() or ""), "soumission": self.soumission.currentData(),
                "anti_triche": self.anti_triche.currentData(), "temps": self.temps.currentData()}

    def changements(self) -> dict[str, str]:
        """Les cases qui diffèrent de la ligne en vigueur : celles changées ici, et celles qu'elle ne disait pas."""
        return {colonne: case for colonne, case in self.cases().items() if case != self.ecrites[colonne]}

    def envoyer(self) -> None:
        self.enregistrer.setEnabled(False)
        self.enregistrer.setText("Enregistrement…")
        self.regler(self.sujet, self.classe, self.changements())


# « tout en haut le En cours doit avoir un cadre vert, le finir à la maison un cadre rouge » (l'utilisateur, 06/11/2026) ;
# le bouton du même sujet, dans son thème, a le bord de la même couleur
# un troisième cadre, bleu, pour les révisions ouvertes (l'utilisateur, 06/11/2026 : « un troisièe cadre bleu "Réviser" avec
# les qcm de révision ») : un sujet de révision ouvert y va, et non dans « En cours » ni « À finir »
REVISER = "Réviser"
COULEURS_DES_ZONES = {EN_COURS: "#27ae60", A_FINIR: "#c0392b", REVISER: "#2980b9"}


def zone_de(e: Entree) -> str:
    """Le cadre du haut d'un sujet ouvert : « Réviser » pour une révision, son état (« En cours », « À finir ») sinon."""
    return REVISER if TYPES.get(e.type, e.type) == REVISER else e.etat


class Branches(QWidget):
    """Les traits discrets de l'arbre devant un libellé du bilan d'un thème, comme un arbre de fichiers : une verticale
    par ancêtre qui a encore un frère plus bas, puis ├ ou └ vers le libellé (l'utilisateur, 06/11/2026 : « pour
    l'arborescence des sections, il faut mettre des traits discrets », sur le modèle de Notes/example.png)."""

    COULEUR = "#b8bcc2"

    def __init__(self, suites: list[bool], dernier: bool) -> None:
        super().__init__()
        self.suites, self.dernier = suites, dernier  # ``suites[k]`` : l'ancêtre de niveau k a un frère plus bas
        self.setFixedWidth((len(suites) + 1) * bilans_widget.PALIER)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)

    def paintEvent(self, _evenement) -> None:  # noqa: ANN001
        peintre = QPainter(self)
        peintre.setPen(QPen(QColor(self.COULEUR), 1))
        demi, milieu, bas = bilans_widget.PALIER // 2, self.height() // 2, self.height()
        for k, suite in enumerate(self.suites):
            if suite:
                peintre.drawLine(k * bilans_widget.PALIER + demi, 0, k * bilans_widget.PALIER + demi, bas)
        x = len(self.suites) * bilans_widget.PALIER + demi
        peintre.drawLine(x, 0, x, milieu if self.dernier else bas)
        peintre.drawLine(x, milieu, x + demi, milieu)
        peintre.end()


def branches(niveaux: list[int]) -> list[tuple[list[bool], bool]]:
    """Pour chaque rang de l'arbre aplati (``niveaux``), de quoi tracer ses ``Branches`` : la suite de chaque ancêtre,
    et s'il est le dernier de ses frères."""
    def frere_apres(i: int) -> bool:
        for n in niveaux[i + 1:]:
            if n <= niveaux[i]:
                return n == niveaux[i]
        return False
    rendus, ancetres = [], []  # ancetres[k] : le rang de l'ancêtre de niveau k du rang courant
    for i, n in enumerate(niveaux):
        ancetres = ancetres[:n] + [i]
        rendus.append(([frere_apres(a) for a in ancetres[:n]], not frere_apres(i)))
    return rendus


def jauge(taux: float | None) -> QLabel:
    """La jauge d'une ligne de bilan, ``bilans_widget._jauge`` en widget : la part remplie à la couleur du taux ; sans
    taux, « en attente »."""
    if taux is None:
        return QLabel("en attente")
    etiquette = QLabel()
    etiquette.setFixedSize(bilans_widget.JAUGE, 10)
    part = max(0.0, min(1.0, taux))
    plein, vide = bilans_widget.teinte(taux), bilans_widget.GRIS_JAUGE
    if part in (0.0, 1.0):  # pleine ou vide : une seule couleur (deux arrêts au même bord font un dégradé)
        etiquette.setStyleSheet(f"background: {plein if part else vide};")
    else:
        etiquette.setStyleSheet(f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {plein}, stop:{part:.4f} "
                                f"{plein}, stop:{part + 0.0001:.4f} {vide}, stop:1 {vide});")
    return etiquette


def bouton_ouvert(couleur: str) -> str:
    """La feuille de style d'un sujet ouvert, dans son thème : le bord du bouton lui-même, de la couleur de sa zone."""
    return (f"QPushButton {{ border: 3px solid {couleur}; border-radius: 6px; background: qlineargradient(x1:0, y1:0, "
            "x2:0, y2:1, stop:0 #ffffff, stop:1 #ececec); } QPushButton:hover { background: #f4f4f4; } "
            "QPushButton:pressed { background: #e0e0e0; }")


# « À finir à la maison : les TP et autre à finir à la maison » (l'utilisateur, 06/11/2026)
TITRES_DES_ZONES = {EN_COURS: EN_COURS, A_FINIR: "À finir à la maison", REVISER: REVISER}
ECART_PLI = 4  # entre le triangle d'un thème et son nom
MARGE, MARGE_CADRE, TRAIT_CADRE, RETRAIT, RETRAIT_BOUTONS = 24, 8, 4, 24, 16  # bord de la page, bord du cadre « En cours », son trait, retrait


class Tableau(QScrollArea):
    """Le tableau d'une classe. ``ouvrir(entree)`` : un titre pressé ; ``commencee(nom)`` : vrai si une copie de ce sujet
    de l'élève entré est déjà dans cet appareil (« Déjà commencé » sous son titre) ; ``eleve`` : « Nom Prénom » de
    l'élève entré, montré sous la classe ; ``professeur`` : c'est le professeur ;
    ``lire_bilan(chemin, rappel)`` : rend à ``rappel`` les octets du fichier ``chemin`` du dossier Dropbox (None s'il
    n'existe pas), le bilan de l'année, ouvert d'emblée s'il est en clair ou que le ``secret`` de l'élève entré l'ouvre
    (``identites`` : le fichier d'empreintes) ; le mot de passe n'est demandé que sinon. Au professeur, si ``regler`` est
    donné, un bouton « Réglages » par sujet, qui montre ses ``Reglages`` lus dans ``texte_echeances`` (le fichier), les
    cases qu'il ne dit pas remplies par ``effectives`` (``valeurs_par_defaut`` sans lui) ;
    ``message`` : ce qu'a fait le dernier « Enregistrer », en haut."""

    def __init__(self, classe: str, liste: list[Entree], ouvrir: Callable[[Entree], None],
                 commencee: Callable[[str], bool] = lambda nom: False, erreurs: list[str] = (), eleve: str = "",
                 lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None,
                 professeur: bool = False, secret: bytes | None = None, identites: dict[str, Any] | None = None,
                 texte_echeances: str | None = None, regler: Callable[[str, str, dict[str, str]], None] | None = None,
                 message: str = "", parent: QWidget | None = None, effectives: Effectives | None = None,
                 revisions: dict[str, Any] | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(f"SmartTeacher - {classe}")
        # les sujets du catalogue, où « Réviser » et « Validation » trouvent ceux d'``entrainement.py`` (``revision``)
        self.revisions, self.ouvrir_revision, self.classe_revision = revisions or {}, ouvrir, classe
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.boutons: dict[str, TitreBouton] = {}  # par sujet : ce que les tests pressent
        self.textes: list[tuple[Entree, TitreDeSujet, str]] = []  # par sujet : son texte et sa ligne grise, où va la note de la copie
        self.themes: list[tuple[str, QVBoxLayout]] = []  # par section de thème : son nom et sa pile
        # par thème, où va son bilan : sous ses boutons « Réviser » ; un thème sans révision, une sous-section « Réviser »
        # cachée, montrée avec son bilan (l'utilisateur, 06/11/2026 : « ce qui se trouve dans Bilan, doit plutôt se trouver
        # dans réviser, en dessous du bouton de révision globale du thème »)
        self.reviser: dict[str, tuple[QWidget | None, QVBoxLayout]] = {}
        self.boutons_reviser: list[tuple[str, str, QPushButton]] = []  # (thème, notion, bouton) du bilan de chaque thème
        self.boutons_validation: list[tuple[str, tuple[str, ...], QPushButton]] = []  # (thème, chemin de la section, bouton)
        self.reglages: dict[str, Reglages] = {}  # par sujet, au professeur seulement (``regler``) : ses réglages, sous son titre
        self.lire_bilan, self.niveau, self.bilan = lire_bilan, niveau_de(classe, liste), None
        self.plis: dict[str, QToolButton] = {}  # le triangle de chaque thème, coché : plié
        self.cours: dict[str, TitreBouton] = {}  # les boutons des PDF de cours, par chemin dans Dropbox
        self.fenetre_cours: Cours | None = None
        self.secret, self.identites = secret, identites or {}
        contenu = QWidget()
        # le cadre « En cours » déborde dans la marge, son titre aligné sur ceux des thèmes (l'utilisateur, 06/11/2026 :
        # « c'est le cadre autour qui doit aller dans les marges ») : la page a 8 px de bord, tout le reste 16 de plus
        exterieur = QVBoxLayout(contenu)
        exterieur.setContentsMargins(MARGE_CADRE, 16, MARGE_CADRE, 16)
        self.pile = pile = QVBoxLayout()
        pile.setContentsMargins(MARGE - MARGE_CADRE, 0, MARGE - MARGE_CADRE, 0)
        exterieur.addLayout(pile)
        # icône, application, classe et élève sur une ligne, en haut (l'utilisateur, 06/11/2026 : « il faut mettre l'icone
        # SmartTeacher, classe et nom de l'élève en ligne pour laisser de la place au reste de la page »)
        logo = QLabel()
        logo.setPixmap(QIcon(str(LOGO_APPLI)).pixmap(56, 56))
        qui = "Professeur" if professeur else eleve
        self.entete = QLabel(f"<span style='font-size:xx-large'><b>SmartTeacher</b> &nbsp;·&nbsp; {escape(classe)}"
                             + (f" &nbsp;·&nbsp; {escape(qui)}" if qui else "") + "</span>")
        ligne = QHBoxLayout()
        ligne.addWidget(logo)
        ligne.addWidget(self.entete, 1)
        pile.addLayout(ligne)
        pile.addSpacing(ESPACE_ENTETE)  # « la ligne de titre plus grande et un peu d'espace avant le TODO » (06/11/2026)
        self.message = QLabel(message)  # ce qu'a fait le dernier « Enregistrer » des réglages, en texte brut
        self.message.setTextFormat(Qt.TextFormat.PlainText)
        self.message.setWordWrap(True)
        self.message.setVisible(bool(message))
        pile.addWidget(self.message)
        if not liste:
            pile.addWidget(QLabel("Rien n'est prévu pour cette classe pour l'instant."))
        ouverts = [e for e in liste if e.etat in (EN_COURS, A_FINIR)]
        sujet = lambda dans, e: self._sujet(dans, e, professeur, regler, commencee, ouvrir, texte_echeances, effectives)
        # deux zones en haut (l'utilisateur, 06/11/2026 : « il faut deux zones en haut : En cours : c'est le TP ou la mini
        # interrogation du cours actuel »), « En cours » pendant le créneau, « À finir » ensuite jusqu'à l'échéance ; chaque
        # sujet est redit dans son thème
        if ouverts:  # un grand titre au-dessus des cadres, comme « Thématiques » au-dessus des thèmes (l'utilisateur,
            pile.addWidget(titre_de_section("<h1>TODO</h1>"))  # 06/11/2026 : « il faut un titre "TODO" »)
        # les cadres en retrait sous « TODO », leurs boutons alignés sur ceux des thèmes (l'utilisateur, 06/11/2026 : « il faut
        # une indentation du coup pour les cadre de TODO », puis « décale encore pour pluot aligner à gauche les boutons de TP »)
        self.cadres = cadres = QVBoxLayout()
        cadres.setContentsMargins(self._largeur_pli() + ECART_PLI + RETRAIT_BOUTONS, 0, 0, 0)
        exterieur.addLayout(cadres)
        for zone in (EN_COURS, A_FINIR, REVISER):
            dans_zone = [e for e in ouverts if zone_de(e) == zone]
            if not dans_zone:
                continue
            # « un cadre rouge avec des coins arrondis et un trait épais » (l'utilisateur, 06/11/2026), vert pour « En cours »
            cadre = QFrame()
            cadre.setObjectName("en_cours")  # le style ne passe pas aux boutons du dedans
            cadre.setStyleSheet(f"QFrame#en_cours {{ border: {TRAIT_CADRE}px solid {COULEURS_DES_ZONES[zone]}; border-radius: 12px; }}")
            dedans = QVBoxLayout(cadre)
            interieur = MARGE - MARGE_CADRE - TRAIT_CADRE
            dedans.setContentsMargins(interieur, 4, interieur, 12)
            dedans.addWidget(QLabel(f"<h2>{TITRES_DES_ZONES[zone]}</h2>"))
            boutons = QVBoxLayout()  # en retrait, comme dans un thème
            boutons.setContentsMargins(RETRAIT, 0, 0, 0)
            dedans.addLayout(boutons)
            for e in dans_zone:
                sujet(boutons, e)
            cadres.addWidget(cadre)
        if ouverts:
            self.pile = pile = QVBoxLayout()  # la suite de la page, sous les cadres
            pile.setContentsMargins(MARGE - MARGE_CADRE, 0, MARGE - MARGE_CADRE, 0)
            exterieur.addLayout(pile)
        # un sujet ouvert est aussi dans son thème, bord de la couleur de sa zone (l'utilisateur, 06/11/2026 : « il faut doubler les
        # travaux en cours : un dans le résumé "En cours" en haut, et un avec un cadre rouge dans la thématique »)
        # un grand titre au-dessus des thèmes (l'utilisateur, 06/11/2026 : « il faut un grand titre "Thématiques" »)
        rangees = ranger(liste)
        if rangees:
            pile.addWidget(titre_de_section("<h1>Thématiques</h1>"))
        for theme, sections in rangees:
            # un triangle à gauche du titre plie ou déplie le thème (l'utilisateur, 06/11/2026 : « il faut pouvoir reduire(plier) /
            # deployer(deplier) une thematique avec un petit bouton avec des triangle à gauche du titre , sans contour ni fond »)
            entete, pli = QHBoxLayout(), self._pli()
            entete.setContentsMargins(0, AU_DESSUS["h2"], 0, 0)  # le titre du thème, triangle compris
            entete.setSpacing(ECART_PLI)
            entete.addWidget(pli)
            entete.addWidget(QLabel(f"<h2>{escape(theme or AUTRES)}</h2>"), 1)
            pile.addLayout(entete)
            corps = QWidget()  # pas « contenu » : celui de la page entière
            dans_theme = QVBoxLayout(corps)  # en retrait sous son thème (l'utilisateur, 06/11/2026 : « il faut une indentation
            # dans chaque thème ») ; le retrait part du nom du thème, pas du triangle (« réindenter pour compenser la présence
            # du bouton de deployement d'une thematique »)
            dans_theme.setContentsMargins(pli.sizeHint().width() + ECART_PLI + RETRAIT, 0, 0, 0)
            pile.addWidget(corps)
            pli.toggled.connect(lambda plie, c=corps, b=pli: (c.setVisible(not plie), b.setArrowType(
                Qt.ArrowType.RightArrow if plie else Qt.ArrowType.DownArrow)))
            self.plis[theme or AUTRES] = pli
            self.themes.append((theme or AUTRES, dans_theme))
            self._cours_du_theme(dans_theme, sections)
            if not sections or sections[0][0] != REVISER:  # « Réviser » vient en premier (``ranger``)
                boite = QWidget()
                boite.hide()
                dans_boite = QVBoxLayout(boite)
                dans_boite.setContentsMargins(0, 0, 0, 0)
                dans_theme.addWidget(boite)
                self.reviser[theme or AUTRES] = (boite, self._sous_section(dans_boite, REVISER))
            for sorte, groupe in sections:
                dans_sorte = self._sous_section(dans_theme, sorte)
                if sorte == REVISER:
                    self.reviser[theme or AUTRES] = (None, dans_sorte)
                for e in groupe:
                    sujet(dans_sorte, e)
                    if e.etat not in (EN_COURS, A_FINIR):
                        continue
                    if e.ligne.sujet in self.boutons:  # le bord du bouton lui-même, pas un cadre de plus (06/11/2026)
                        self.boutons[e.ligne.sujet].setStyleSheet(bouton_ouvert(COULEURS_DES_ZONES[zone_de(e)]))
        for erreur in erreurs:  # ce que le professeur a mal écrit (``construire`` ne laisse à l'élève que sa classe)
            pile.addWidget(QLabel(f"<span style='color:#c0392b'>{ECHEANCES}, {erreur}</span>"))
        if lire_bilan and self.niveau and not professeur:
            self._formulaire_bilan(eleve)
            if eleve:  # le mot de passe n'est demandé que si le bilan ne s'ouvre pas sans lui
                self.voir_bilan()
        exterieur.addStretch(1)
        self.setWidget(contenu)

    def _sujet(self, pile: QVBoxLayout, e: Entree, professeur: bool, regler: Callable[[str, str, dict[str, str]], None] | None,
               commencee: Callable[[str], bool], ouvrir: Callable[[Entree], None], texte_echeances: str | None,
               effectives: Effectives | None) -> None:
        """Un sujet dans ``pile`` : le nom du fichier, « Thème - TP2 - Titre », puis la date en gris ; au professeur, son
        bouton « Réglages » et leur panneau."""
        deja = e.lien and not professeur and e.etat != FERME and commencee(e.nom)
        gris = " · ".join(filter(None, (quand(e), "Déjà commencé" if deja else "")))  # une date peut manquer
        texte = TitreDeSujet(e.nom, gris)
        self.textes.append((e, texte, gris))
        if e.lien:
            titre = bouton = TitreBouton(texte, e.nom)
            bouton.clicked.connect(lambda _=False, e=e: ouvrir(e))
            self.boutons[e.ligne.sujet] = bouton
        else:  # à venir : le titre seul, aligné sur ceux qu'on presse
            titre = texte
            texte.setContentsMargins(*MARGES_TITRE)
        if not (professeur and regler) or e.ligne.sujet in self.reglages:  # un sujet doublé : ses réglages une fois, en haut
            pile.addWidget(titre)
            return
        # le professeur : « Réglages » à droite du titre, qui montre ou cache le panneau du sujet en dessous
        rangee = QHBoxLayout()
        rangee.addWidget(titre, 1)
        montrer = QPushButton("Réglages")
        montrer.setCheckable(True)
        rangee.addWidget(montrer, 0, Qt.AlignmentFlag.AlignTop)
        pile.addLayout(rangee)
        panneau = Reglages(e.ligne.sujet, e.ligne.classe,
                           echeances.trouver(texte_echeances, {e.ligne.sujet.strip().replace("\\", "/").rpartition("/")[2]},
                                             e.ligne.classe), regler,
                           (lambda e=e: effectives(e.ligne.sujet, e.ligne.classe)) if effectives else valeurs_par_defaut)
        panneau.hide()
        montrer.toggled.connect(panneau.setVisible)
        pile.addWidget(panneau)
        self.reglages[e.ligne.sujet] = panneau

    @staticmethod
    def _sous_section(dans_theme: QVBoxLayout, sorte: str) -> QVBoxLayout:
        """Le titre de la sous-section ``sorte`` dans ``dans_theme`` et la pile de ses boutons, un peu en retrait
        (l'utilisateur, 06/11/2026)."""
        dans_theme.addWidget(titre_de_section(f"<h3>{escape(sorte)}</h3>"))
        dans_sorte = QVBoxLayout()
        dans_sorte.setContentsMargins(RETRAIT_BOUTONS, 0, 0, 0)
        dans_theme.addLayout(dans_sorte)
        return dans_sorte

    @staticmethod
    def _pli() -> QToolButton:
        """Le triangle d'un thème, sans contour ni fond, pointé vers le bas : déplié."""
        pli = QToolButton()
        pli.setArrowType(Qt.ArrowType.DownArrow)
        pli.setCheckable(True)
        pli.setStyleSheet("QToolButton { border: none; background: transparent; }")
        pli.setCursor(Qt.CursorShape.PointingHandCursor)
        return pli

    @classmethod
    def _largeur_pli(cls) -> int:
        """La largeur du triangle d'un thème, dont les cadres du haut se décalent pour s'aligner sur le nom des thèmes."""
        pli = cls._pli()
        largeur = pli.sizeHint().width()
        pli.deleteLater()
        return largeur

    def _cours_du_theme(self, dans_theme: QVBoxLayout, sections: list[tuple[str, list[Entree]]]) -> None:
        """En tête du thème, « Cours » et un bouton par PDF de cours de ses sujets (l'utilisateur, 06/11/2026 : « il faut
        ajouter un section cours avec les pdf de cours dans chaque thème »), qui l'ouvre dans ``Cours``, lu dans Dropbox
        par ``lire_bilan`` ; sans lui, rien à ouvrir, pas de section."""
        cours = dict.fromkeys(c for _, groupe in sections for e in groupe for c in e.cours)  # une fois, dans l'ordre
        if not (cours and self.lire_bilan):
            return
        dans_theme.addWidget(titre_de_section("<h3>Cours</h3>"))
        dans_cours = QVBoxLayout()
        dans_cours.setContentsMargins(RETRAIT_BOUTONS, 0, 0, 0)
        dans_theme.addLayout(dans_cours)
        # le PDF du cours, puis celui de son diaporama juste dessous, au même nom suivi de « (pdf) » et « (diaporama) »
        # (l'utilisateur, 06/11/2026 : « pour le cours il faut les deux bouton l'un au dessus de l'autre avec le même nom
        # qui finit par (pdf) et (diaporama) ») ; les deux s'ouvrent dans la même fenêtre de PDF
        for chemin, titre, diapo in cours:
            for fichier, sorte in ((chemin, "pdf"), (diapo, "diaporama")):
                if not fichier:
                    continue
                nom = f"{titre} ({sorte})"
                bouton = TitreBouton(QLabel(f"<b>{escape(nom)}</b>"), nom)
                bouton.clicked.connect(lambda _=False, fichier=fichier, nom=nom: self.ouvrir_cours(fichier, nom))
                dans_cours.addWidget(bouton)
                self.cours[fichier] = bouton

    def ouvrir_cours(self, chemin: str, titre: str) -> None:
        """Lit le PDF dans Dropbox, puis le montre dans sa fenêtre ; un cours introuvable le dit dans la même fenêtre."""
        def recu(octets: bytes | None) -> None:
            self.fenetre_cours = Cours(titre, octets)
            self.fenetre_cours.showMaximized()
        self.lire_bilan(chemin, recu)

    def _formulaire_bilan(self, eleve: str) -> None:
        """En bas, les bilans de l'élève, de ses copies, par thème et de l'année (``bilans_widget.Bilan`` ; l'utilisateur,
        06/11/2026 : « les bilans (copie, thème, année) doivent être sur la page d'accueil ») : le mot de passe, s'il faut le
        taper, et le nom et le prénom si cet appareil n'en a retenu aucun."""
        # le titre du formulaire ; le bilan ouvert porte le sien (l'utilisateur, 06/11/2026 : « "Mes bilans", "Bilan de Essai
        # Élève", "établi le ..." ne servent à rien, il faut juste le titre de section "Bilan de l'année" »)
        self.titre_bilan = titre_de_section("<h2>Bilan de l'année</h2>", AU_DESSUS["h1"])  # au rang de « Thématiques »
        self.pile.addWidget(self.titre_bilan)
        self.cadre_bilan = QWidget()
        formulaire = QFormLayout(self.cadre_bilan)
        formulaire.setContentsMargins(0, 0, 0, 0)
        nom, prenom = (eleve.split(" ", 1) + [""])[:2] if eleve else ("", "")
        self.nom, self.prenom, self.mot_de_passe = QLineEdit(nom), QLineEdit(prenom), QLineEdit()
        if not eleve:
            formulaire.addRow("Nom", self.nom)
            formulaire.addRow("Prénom", self.prenom)
        self.mot_de_passe.setEchoMode(QLineEdit.EchoMode.Password)
        self.mot_de_passe.returnPressed.connect(self.voir_bilan)
        voir = QPushButton("Voir mon bilan")
        voir.clicked.connect(self.voir_bilan)
        ligne = QHBoxLayout()
        ligne.addWidget(self.mot_de_passe, 1)
        ligne.addWidget(voir)
        formulaire.addRow("Mot de passe", ligne)
        self.message_bilan = QLabel("")
        self.message_bilan.setWordWrap(True)
        formulaire.addRow(self.message_bilan)
        self.pile.addWidget(self.cadre_bilan)

    def notes_dans_les_boutons(self, bilan: bilans_widget.Bilan) -> None:
        """La note de chaque copie rendue dans la ligne grise du bouton de son sujet (l'utilisateur, 06/11/2026 : « le bilan
        doit être sur la page d'accueil, avec les notes dans le bouton de chaque copie rendue »). Le sujet d'une copie est celui
        dont le nom, graphie normalisée par ``cle_de``, est le sien : ``epreuve`` est le nom du paquet, dont le .qcm porte le nom
        (``Entree.nom``) ; plusieurs copies du même sujet (un second essai) : la dernière rendue. Pas de « Bilan des copies »
        sur la page d'accueil, même pour une copie sans bouton (l'utilisateur, 06/11/2026 : « suprime la section "Bilan des
        copies" »)."""
        derniere: dict[str, dict[str, Any]] = {}
        for p in bilan.parcours:  # dans l'ordre de leur rendu : la dernière écrase
            derniere[cle_de(sans_essai(p["epreuve"]))] = p
        for e, texte, gris in self.textes:
            cle = next((c for c in (cle_de(e.nom), cle_de(e.ligne.sujet)) if c in derniere), None)
            if cle is None:
                continue
            if e.etat == FERME:  # « si c'est fermé, il faut juste mettre la note » (l'utilisateur, 06/11/2026)
                gris = ""
            texte.poser(e.nom, " · ".join(filter(None, (gris, bilan.note_de_copie(derniere[cle])))))
        bilan.garder_copies([])

    def bilans_dans_les_themes(self, bilan: bilans_widget.Bilan) -> None:
        """Le bilan de chaque thème sous le titre de sa section (l'utilisateur, 06/11/2026 : « il faut un bilan dans chaque
        section thématique »), sous les boutons de « Réviser » (« ce qui se trouve dans Bilan, doit plutôt se trouver dans réviser ») : le thème de l'arbre est celui de la section au nom près (``cle_de``). Le
        « Bilan par thème » du bilan ne garde que les thèmes sans section."""
        noeuds = {cle_de(n[0]): n for n in bilan.arbre}
        utilises: set[str] = set()
        for nom, _ in self.themes:
            cle = cle_de(nom)
            if cle not in noeuds:
                continue
            utilises.add(cle)
            boite, dans_reviser = self.reviser[nom]  # sous les boutons de révision, sans titre à lui
            if boite is not None:
                boite.show()
            dans_reviser.addWidget(self._grille_du_bilan(nom, bilan.rangs(noeuds[cle]), noeuds[cle][0], bool(noeuds[cle][4])))
        bilan.garder_themes([n for n in bilan.arbre if cle_de(n[0]) not in utilises])

    def _grille_du_bilan(self, theme: str, rangs: list[tuple[int, str, float | None]], racine: str = "",
                         detail: bool = True) -> QWidget:
        """Le bilan d'un thème en grille : le libellé en retrait selon son niveau, sa jauge, et un bouton « Réviser » par
        section et sous-section (l'utilisateur, 06/11/2026 : « ajoute le bouton de révision par section et sous-section »).
        Largeur bornée : les colonnes des jauges et des boutons tombent au même bord d'un thème à l'autre, et la grille se
        resserre sur un téléphone, le libellé revenant à la ligne. Chaque rang a son chemin dans l'arbre (``racine``, le thème
        de l'arbre, puis ses parents ; sans ``detail``, le thème seul) : « Réviser » ouvre son entraînement, et « Validation »,
        à côté, son questionnaire de Validation s'il est déposé (l'utilisateur, 06/11/2026 17:41)."""
        grille = QWidget()
        disposition = QGridLayout(grille)
        disposition.setContentsMargins(0, 0, 0, 0)
        disposition.setColumnStretch(0, 1)
        disposition.setVerticalSpacing(0)  # les traits de l'arbre d'un rang à l'autre, sans coupure
        message = QLabel("")
        message.setWordWrap(True)
        message.hide()
        largeur, parents = 0, [racine or theme]
        for rang, ((niveau, libelle, taux), (suites, dernier)) in enumerate(zip(rangs, branches([r[0] for r in rangs]))):
            parents[1 + niveau:] = [libelle] if detail else []
            chemin = tuple(parents)
            texte = QLabel(libelle)
            texte.setWordWrap(True)
            ligne = QHBoxLayout()
            ligne.setContentsMargins(0, 0, 0, 0)
            ligne.setSpacing(4)
            ligne.addWidget(Branches(suites, dernier))
            ligne.addWidget(texte, 1)
            disposition.addLayout(ligne, rang, 0)
            disposition.addWidget(jauge(taux), rang, 1, Qt.AlignmentFlag.AlignVCenter)
            bouton = QPushButton("Réviser")
            bouton.clicked.connect(lambda _=False, libelle=libelle, chemin=chemin:
                                   self.reviser_notion(theme, libelle, message, chemin))
            disposition.addWidget(bouton, rang, 2)
            largeur = bouton.sizeHint().width()
            self.boutons_reviser.append((theme, libelle, bouton))
            if validation := revision(self.revisions, chemin, "validation"):
                valider = QPushButton("Validation")
                valider.setToolTip("Sans cours ni aide, rendu à la fin : c'est lui qui montre ce qui est acquis.")
                valider.clicked.connect(lambda _=False, v=validation: self.ouvrir_revision(self._entree_de_revision(v)))
                disposition.addWidget(valider, rang, 3)
                largeur += valider.sizeHint().width() + disposition.horizontalSpacing()
                self.boutons_validation.append((theme, chemin, valider))
        disposition.addWidget(message, len(rangs), 0, 1, 4)
        grille.setMaximumWidth(bilans_widget.PALIER + bilans_widget.LIBELLES + bilans_widget.JAUGE + largeur
                               + 2 * disposition.horizontalSpacing())
        return grille

    def reviser_notion(self, theme: str, libelle: str, message: QLabel, chemin: tuple[str, ...] = ()) -> None:
        """Le sujet « Réviser » de la section ``chemin`` (``reviser`` : celui de son thème, à défaut l'ancien entraînement
        de la section), ouvert comme un sujet du tableau ; aucun de déposé : le message le dit."""
        if entree := reviser(self.revisions, chemin or (theme, libelle)):
            self.ouvrir_revision(self._entree_de_revision(entree))
            return
        message.setText(f"Réviser « {libelle} » ({theme}) : pas encore d'entraînement en ligne pour cette section.")
        message.show()

    def _entree_de_revision(self, connu: dict[str, Any]) -> Entree:
        """Un sujet de « Réviser » comme une ligne du tableau, ouverte à tout moment et sans code de classe : ``ouvrir`` ne
        lit que son lien et son jeton (le code de la classe, que le catalogue donne s'il l'inscrit)."""
        return Entree(Ligne(connu.get("nom", ""), self.classe_revision, None, None, None), EN_COURS, connu["lien"], connu.get("nom", ""),
                      connu.get("jeton", ""))

    def eleve_du_formulaire(self) -> str:
        return f"{self.nom.text().strip()} {self.prenom.text().strip()}".strip()

    def voir_bilan(self) -> None:
        eleve = self.eleve_du_formulaire()
        if not eleve:
            self.message_bilan.setText("Votre nom et votre prénom, puis Entrée.")
            return
        self.message_bilan.setText("Lecture du bilan…")
        self.lire_bilan(f"{self.niveau}/Bilans/{bilans_widget.nom_du_fichier(eleve)}", self.bilan_recu)

    def bilan_recu(self, octets: bytes | None) -> None:
        if not octets:
            self.message_bilan.setText("Pas encore de bilan pour vous : le professeur le dépose après les premières notes.")
            return
        chemin = Path(tempfile.gettempdir()) / f"bilan{bilans_widget.EXTENSION}"
        chemin.write_bytes(octets)
        tape = self.mot_de_passe.text()
        try:
            bilan = bilans_widget.ouvrir_bilan(str(chemin), bilans_widget.cle_du_secret(self.secret))
            if bilan is None and tape:
                bilan = bilans_widget.ouvrir_par_mot_de_passe(str(chemin), self.eleve_du_formulaire(), tape, self.identites)
        except ValueError:
            self.message_bilan.setText("Ce bilan est illisible : signalez-le au professeur.")
            return
        finally:
            chemin.unlink(missing_ok=True)
        if bilan is None:
            self.message_bilan.setText(bilans_widget.REFUS if tape else "Tapez votre mot de passe.")
            return
        self.mot_de_passe.clear()
        self.bilan = bilan  # à la place du formulaire : le mot de passe ne sert plus
        self.pile.replaceWidget(self.cadre_bilan, bilan)
        self.notes_dans_les_boutons(bilan)
        self.bilans_dans_les_themes(bilan)
        self.titre_bilan.hide()
        bilan.sans_entete()
        self.cadre_bilan.hide()  # hors de la pile, il resterait peint en haut jusqu'à sa destruction
        self.cadre_bilan.deleteLater()


def sans_essai(epreuve: str) -> str:
    """Le nom d'une épreuve sans son « (2e essai) » (``bilans.copie_du_paquet``) : celui de son sujet."""
    return re.sub(r" \(\d+e essai\)$", "", epreuve)


def lire_catalogue(cat: dict[str, Any] | str | None) -> dict[str, Any]:
    """tableau.json lu ; illisible ou absent : comme vide, sans bouton ni classe."""
    if isinstance(cat, str):
        try:
            cat = json.loads(cat)
        except ValueError:
            cat = None
    if not isinstance(cat, dict) or not isinstance(cat.get("sujets"), dict):
        cat = {"sujets": {}}
    if not isinstance(cat.get("classes"), dict):
        cat["classes"] = {}
    return cat


def construire(classe: str, texte: str | None, cat: dict[str, Any] | str | None, ouvrir: Callable[[Entree], None],
               commencee: Callable[[str], bool] = lambda nom: False, maintenant: datetime | None = None, eleve: str = "",
               lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None, professeur: bool = False,
               secret: bytes | None = None, identites: dict[str, Any] | None = None,
               jetons: dict[str, str] | None = None, regler: Callable[[str, str, dict[str, str]], None] | None = None,
               message: str = "", effectives: Effectives | None = None) -> Tableau:
    """Le tableau à partir des textes des deux fichiers (None : absent, le tableau est vide). Les erreurs du fichier
    d'échéances : toutes au professeur, à l'élève celles des lignes de sa classe seulement. Sans ``effectives``, une case
    vide des réglages montre ``valeurs_par_defaut`` à la durée du sujet que porte le catalogue."""
    cat = lire_catalogue(cat)
    if effectives is None:
        def effectives(sujet: str, _classe: str) -> dict[str, str]:
            connu = cat["sujets"].get(cle_de(sujet))
            return valeurs_par_defaut(connu.get("duree") if isinstance(connu, dict) else None)
    lignes, erreurs = lire_echeances(texte or "")
    # le nom de la classe tel que le professeur l'écrit, pas tel que l'adresse le porte (« 2nd_5 »)
    classe = next((ligne.classe for ligne in lignes if meme_classe(ligne.classe, classe)), classe)
    if not professeur:
        erreurs = [e for e in erreurs if e.classe and meme_classe(e.classe, classe)]
    return Tableau(classe, entrees(lignes, cat, classe, maintenant or datetime.now(timezone.utc), jetons), ouvrir, commencee, erreurs,
                   eleve, lire_bilan, professeur, secret, identites, texte, regler if professeur else None, message,
                   effectives=effectives,  # « Réviser » : les sujets du catalogue, avec le code de la classe s'il en a un
                   revisions={k: {**v, "jeton": (jetons or {}).get(k, "")} for k, v in cat["sujets"].items() if isinstance(v, dict)})


class Portail(QStackedWidget):
    """La page d'une classe : l'entrée (prénom, nom, mot de passe, vérifiés par ``identifier`` sur la
    liste chiffrée de la classe et le fichier d'empreintes ``identites``), puis son ``Tableau``. ``retenu()`` rend
    ``(nom, prénom, code)`` retenus par cet appareil, le code étant le secret (``bytes``) de l'élève entré par son mot de
    passe, ``retenir(…)`` les retient (``None`` : les oublie) : le navigateur d'un élève n'est pas partagé (l'utilisateur,
    26/10/2026), l'élève revient sans retaper. ``deposer(entree)`` : l'empreinte d'une
    première visite, à ajouter au fichier d'empreintes. ``commencee(nom, identite)`` : une copie de ce sujet par cet
    élève est dans cet appareil. ``regler`` (``Regler`` : ``regler_sur_disque``, ou ``regler_par`` en ligne) : ce qui
    écrit dans echeances.csv les réglages du professeur ; sans lui, ni bouton « Réglages » ni panneau. Les autres paramètres
    sont ceux de ``construire`` (``effectives`` compris)."""

    def __init__(self, classe: str, texte: str | None, cat: dict[str, Any] | str | None, cle: str,
                 ouvrir: Callable[[Entree], None], commencee: Callable[[str, Identite], bool] = lambda nom, qui: False,
                 retenu: Callable[[], tuple[str, str, str | bytes] | None] = lambda: None,
                 retenir: Callable[[tuple[str, str, str | bytes] | None], None] = lambda valeur: None,
                 maintenant: datetime | None = None,
                 lire_bilan: Callable[[str, Callable[[bytes | None], None]], None] | None = None,
                 identites: dict[str, Any] | None = None, deposer: Callable[[dict[str, str]], None] = lambda entree: None,
                 regler: Regler | None = None, parent: QWidget | None = None, effectives: Effectives | None = None) -> None:
        super().__init__(parent)
        self.classe, self.texte, self.cat, self.cle, self.regler_fichier = classe, texte, lire_catalogue(cat), cle, regler
        self.effectives = effectives
        self.ouvrir, self.commencee, self.retenu, self.retenir = ouvrir, commencee, retenu, retenir
        self.maintenant, self.lire_bilan, self.identites, self.deposer = maintenant, lire_bilan, identites or {}, deposer
        self.identite: Identite | None = None
        self.garde: tuple[str, str, bytes] | None = None  # l'élève que l'appareil a retenu par son mot de passe
        self.premiere = False  # l'élève nommé en est à sa première visite : son mot de passe s'affiche (``voir_premiere_visite``)
        self.inscrits: list[list[str]] | None = None  # la liste de la classe, déchiffrée une fois (``voir_premiere_visite``)
        self.tableau: Tableau | None = None
        self.setWindowTitle(f"SmartTeacher - {classe}")
        self.connexion = QWidget()
        pile = QVBoxLayout(self.connexion)
        pile.setContentsMargins(24, 16, 24, 16)
        pile.addStretch(1)
        logo = QLabel()
        logo.setPixmap(QIcon(str(LOGO_APPLI)).pixmap(96, 96))
        pile.addWidget(logo, 0, Qt.AlignmentFlag.AlignHCenter)
        entete = QLabel(f"<h1>SmartTeacher</h1><h2>{escape(classe)}</h2>")
        entete.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(entete)
        formulaire = QFormLayout()
        self.prenom, self.nom, self.personnel = QLineEdit(), QLineEdit(), QLineEdit()
        self.personnel.setEchoMode(QLineEdit.EchoMode.Password)
        self.prenom.editingFinished.connect(self.voir_premiere_visite)
        self.nom.editingFinished.connect(self.voir_premiere_visite)
        formulaire.addRow("Prénom", self.prenom)
        formulaire.addRow("Nom", self.nom)
        formulaire.addRow("Mot de passe", self.personnel)
        pile.addLayout(formulaire)
        self.bouton_entrer = QPushButton("Entrer")
        self.bouton_entrer.clicked.connect(self.entrer)
        self.personnel.returnPressed.connect(self.entrer)
        pile.addWidget(self.bouton_entrer, 0, Qt.AlignmentFlag.AlignHCenter)
        self.message = QLabel("")
        self.message.setWordWrap(True)
        self.message.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        pile.addWidget(self.message)
        pile.addStretch(2)
        self.addWidget(self.connexion)
        if valeur := retenu():  # ce que l'appareil a retenu, pré-rempli et essayé d'emblée
            self.nom.setText(valeur[0])
            self.prenom.setText(valeur[1])
            if isinstance(valeur[2], bytes):
                self.garde = valeur
            else:
                self.personnel.setText(valeur[2])
            if valeur[2]:
                self.entrer()
            else:  # un nom seul (retenu d'avant les mots de passe) : l'élève tape le sien
                self.voir_premiere_visite()

    def voir_premiere_visite(self) -> None:
        """À sa première visite, l'élève ne tape son mot de passe qu'une fois : le champ l'affiche et le message le dit ;
        sinon il est masqué. La liste se déchiffre une seule fois, quand le nom est complet : ce déchiffrement est lent."""
        nom, prenom = self.nom.text().strip(), self.prenom.text().strip()
        if nom and prenom and self.inscrits is None and self.cle:
            chiffree = self.cat["classes"].get(cle_de(self.classe))
            liste = chiffree and ouvrir_liste(chiffree, self.cle)
            self.inscrits = liste["inscrits"] if liste else None
        premiere = bool(self.inscrits) and codes.premiere_visite(self.identites, self.inscrits, nom, prenom, self.garde)
        if premiere != self.premiere:
            self.premiere = premiere
            self.personnel.setEchoMode(QLineEdit.EchoMode.Normal if premiere else QLineEdit.EchoMode.Password)
            self.message.setText(codes.PREMIERE_VISITE if premiere else "")

    def entrer(self) -> None:
        nom, prenom, code = self.nom.text(), self.prenom.text(), self.personnel.text()
        chiffree = self.cat["classes"].get(cle_de(self.classe))
        identite = identifier(chiffree, self.cle, nom, prenom, code, self.identites, self.garde)
        if isinstance(identite, str):
            if identite == codes.GARDE_PERIMEE:  # retenue d'avant une réinscription : le mot de passe d'aujourd'hui
                self.garde = None
                self.retenir(None)
                self.voir_premiere_visite()
                if self.premiere:  # réinitialisé : il en choisit un autre, le message est déjà là
                    return
            self.message.setText(f"<span style='color:#c0392b'>{escape(identite)}</span>")
            return
        self.identite = identite
        if identite.depot:
            self.deposer(identite.depot)
            codes.ajouter_depot(self.identites, identite.depot)  # plus une première visite
        # le mot de passe professeur ne s'écrit nulle part, même dans le navigateur : il le retape ; celui d'un élève non
        # plus, c'est son secret qui est retenu
        self.retenir(None if identite.professeur else (identite.nom, identite.prenom, identite.secret))
        self.personnel.clear()
        self.message.clear()
        self.montrer_tableau()

    def montrer_tableau(self, message: str = "") -> None:
        """Le tableau de l'élève ou du professeur entré, fait (ou refait, après un réglage) sur ``texte``."""
        identite = self.identite
        if self.tableau is not None:
            self.removeWidget(self.tableau)
            self.tableau.deleteLater()
        self.tableau = construire(self.classe, self.texte, self.cat, self.ouvrir,
                                  lambda nom_sujet: self.commencee(nom_sujet, identite), self.maintenant, identite.eleve,
                                  self.lire_bilan, identite.professeur, identite.secret, self.identites, identite.jetons,
                                  self.regler if self.regler_fichier else None, message, self.effectives)
        self.addWidget(self.tableau)
        self.setCurrentWidget(self.tableau)

    def entrer_professeur(self) -> None:
        """Le tableau du professeur d'emblée, sans entrée : la fenêtre « Gérer les sujets » (``Gestion``), sur la machine où
        se lit le mot de passe professeur (``codes.professeur``), qui ne s'écrit ni ne se tape ici."""
        self.identite = Identite("", "", professeur=True)
        self.montrer_tableau()

    def regler(self, sujet: str, classe: str, changements: dict[str, str]) -> None:
        """Un « Enregistrer » du professeur : ``changements`` écrits par ``regler_fichier``, puis le tableau refait sur le
        fichier relu, l'état et les dates des sujets compris, et ce qu'il en est dit en haut."""
        def recu(texte: str | None, message: str) -> None:
            if texte is not None:
                self.texte = texte
            if self.identite is not None and self.identite.professeur:  # pas s'il est sorti entre-temps
                self.montrer_tableau(message)
        self.regler_fichier(sujet, classe, changements, recu)


def memoire_des_effectives(dropbox: Path) -> Effectives:
    """``Effectives`` en natif sur le dossier ``dropbox`` : ``valeurs_du_qcm`` du .qcm de chaque sujet (``chemin_du_qcm``,
    catalogue relu de ``dropbox``), une fois par sujet et par classe : le .qcm s'ouvre en une seconde."""
    memoire: dict[tuple[str, str], dict[str, str]] = {}

    def effectives(sujet: str, classe: str) -> dict[str, str]:
        if (sujet, classe) not in memoire:
            cat = (dropbox / CATALOGUE).read_text(encoding="utf-8") if (dropbox / CATALOGUE).is_file() else None
            memoire[sujet, classe] = valeurs_du_qcm(chemin_du_qcm(dropbox, cat, sujet), classe)
        return memoire[sujet, classe]
    return effectives


def classes_connues(listes: Path = LISTES, texte: str | None = None) -> list[str]:
    """Les classes à choisir dans « Gérer les sujets » : celles de ``listes/``, puis celles qu'echeances.csv (``texte``) est
    seul à nommer, chacune une fois (``meme_classe``)."""
    classes = [chemin.stem for chemin in sorted(listes.glob("*.csv"))]
    for ligne in lire_echeances(texte or "")[0]:
        if not any(meme_classe(ligne.classe, c) for c in classes):
            classes.append(ligne.classe)
    return classes


class Gestion(QWidget):
    """« SmartTeacher - Gérer les sujets » : la page d'une classe vue par le professeur (``Portail.entrer_professeur``), ses
    réglages par sujet, et en haut la classe à choisir, qui refait la page (l'utilisateur, 06/11/2026 : « je veux egalement
    pouvoir choisir la classe dans l'interface » et « avoir cette interface en natif avec un lien dans mon menu KDE »).
    ``portail(classe)`` : la page de cette classe, faite sur le fichier relu (``main``)."""

    TITRE = "SmartTeacher - Gérer les sujets"

    def __init__(self, classes: list[str], portail: Callable[[str], Portail], classe: str | None = None,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.fabriquer = portail
        self.portail: Portail | None = None
        self.setWindowTitle(self.TITRE)
        self.setWindowIcon(QIcon(str(LOGO_APPLI)))
        pile = QVBoxLayout(self)
        rangee = QHBoxLayout()
        rangee.addWidget(QLabel("Classe"))
        self.classe = QComboBox()
        for nom in classes:
            self.classe.addItem(nom, nom)
        rangee.addWidget(self.classe, 1)
        pile.addLayout(rangee)
        self.pile = pile
        trouvee = next((i for i, nom in enumerate(classes) if classe and meme_classe(nom, classe)), 0)
        self.classe.setCurrentIndex(trouvee)
        self.classe.currentIndexChanged.connect(lambda *_: self.montrer(self.classe.currentData()))
        if classes:
            self.montrer(self.classe.currentData())

    def montrer(self, classe: str) -> None:
        """La page de ``classe`` à la place de celle d'avant."""
        if self.portail is not None:
            self.pile.removeWidget(self.portail)
            self.portail.deleteLater()
        self.portail = self.fabriquer(classe)
        self.portail.entrer_professeur()
        self.pile.addWidget(self.portail, 1)


def main() -> int:
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("action", nargs="?", choices=["catalogue", "liens", "completer"],
                           help="catalogue : écrit tableau.json dans le dossier Dropbox ; liens HOTE : les adresses des classes ; "
                                "completer : les lignes en vigueur d'echeances.csv auxquelles manque un réglage, recopiées "
                                "complètes (montrées seulement, sans --ecrire)")
    analyseur.add_argument("hote", nargs="?", help="liens : l'adresse de la page, celle de HOTE dans web/deployer.conf")
    analyseur.add_argument("--classe", help="montre le tableau de cette classe")
    analyseur.add_argument("--professeur", action="store_true",
                           help="« Gérer les sujets » : la page des classes vue par le professeur, la classe à choisir")
    analyseur.add_argument("--ecrire", action="store_true", help="completer : écrit le fichier, au lieu de montrer l'ajout")
    analyseur.add_argument("--dropbox", type=Path, default=DROPBOX)
    analyseur.add_argument("-o", "--sortie", type=Path, help="tableau.json ailleurs que dans le dossier Dropbox")
    analyseur.add_argument("--depose", nargs="*", default=[], help="catalogue : les .qcm que deployer.sh vient de déposer")
    a = analyseur.parse_args()
    if a.action == "catalogue":
        sortie = a.sortie or a.dropbox / CATALOGUE
        cat = catalogue(a.dropbox, a.depose)
        sortie.write_text(json.dumps(cat, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        print(f"{sortie} : {len(cat['sujets'])} sujets déposés")
        return 0
    if a.action == "liens":  # à taper par le professeur : chaque adresse porte la clé de la liste de sa classe
        secret = codes.professeur()
        if not (secret and a.hote):
            analyseur.error("liens HOTE, sur la machine du professeur")
        for chemin in sorted(LISTES.glob("*.csv")):
            print(f"{chemin.stem} : {a.hote.rstrip('/')}/?{urlencode({'classe': chemin.stem, 'cle': cle_de_classe(secret, chemin.stem)})}")
        return 0
    effectives = memoire_des_effectives(a.dropbox)
    if a.action == "completer":  # à taper par le professeur : il lit, puis relance avec --ecrire
        chemin = a.dropbox / ECHEANCES
        with open(chemin, encoding="utf-8", newline="") as fichier:
            ancien = fichier.read()
        nouveau = echeances.completer(ancien, lambda ligne: effectives(ligne["sujet"], ligne["classe"]))
        if nouveau is None:
            print(f"{chemin} : rien à compléter, chaque ligne en vigueur dit ses réglages (ou rien d'autre ne les dit)")
            return 0
        entete = echeances.completer_entete(ancien)
        print(f"{chemin} :" + (f"\nen-tête complété : {entete.splitlines()[0].lstrip(chr(0xFEFF))}" if entete != ancien else ""))
        print(nouveau[len(entete):], end="")
        if a.ecrire:
            echeances.ecrire(ancien, nouveau, chemin)
            print("écrit.")
        else:
            print("rien d'écrit : relancer avec --ecrire")
        return 0
    if not (a.classe or a.professeur):
        analyseur.error("--classe, --professeur, catalogue, liens ou completer")
    import lecteur  # noqa: PLC0415
    from modele import application  # noqa: PLC0415
    from qtpy6.QtCore import QProcess  # noqa: PLC0415
    app = application()
    echeances.DOSSIER = a.dropbox  # les réglages du professeur s'écrivent dans le fichier que ce tableau lit
    lire = lambda nom: (a.dropbox / nom).read_text(encoding="utf-8") if (a.dropbox / nom).exists() else None  # noqa: E731
    programme = str(Path(__file__).with_name("lecteur.py"))
    secret = codes.professeur()  # la clé de la classe, en mémoire seulement : c'est l'adresse des élèves qui la porte
    identites, fichier = lecteur.identites_du_disque(a.dropbox / CATALOGUE)  # celui du dossier partagé, hors ligne compris

    def retenir(valeur: tuple[str, str, str | bytes] | None) -> None:  # le secret seul, comme l'accueil ; jamais un code
        if valeur is None:
            lecteur.oublier_identite()
        elif isinstance(valeur[2], bytes):
            lecteur.garder_identite(*valeur)

    def portail(classe: str) -> Portail:
        return Portail(classe, lire(ECHEANCES), lire(CATALOGUE), cle_de_classe(secret, classe) if secret else "",
                       lambda e: QProcess.startDetached(sys.executable, arguments_du_lecteur(programme, a.dropbox / e.lien, e.jeton)),
                       retenu=lecteur.identite_gardee, retenir=retenir,
                       lire_bilan=lambda chemin, rappel: rappel(b.read_bytes() if (b := a.dropbox / chemin).is_file() else None),
                       identites=identites, deposer=lambda entree: lecteur.deposer_sur_disque(fichier, entree),
                       regler=regler_sur_disque, effectives=effectives)

    if a.professeur:
        if not secret:
            analyseur.error(f"--professeur : le mot de passe professeur ne se lit pas ({codes.FICHIER})")
        tableau = Gestion(classes_connues(LISTES, lire(ECHEANCES)), portail, a.classe)
        tableau.resize(760, 760)
    else:
        tableau = portail(a.classe)
        tableau.resize(760, 600)
    tableau.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
