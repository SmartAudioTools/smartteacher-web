"""Le pont de la page ``?classe=…&cle=…`` (page.html) : le tableau de bord d'une classe (``tableau_eleves.Portail`` : l'entrée
de l'élève, puis son tableau) plein canevas, au lieu d'un sujet. La page lui donne le texte des deux fichiers de la racine du
dossier du professeur (``echeances.csv``, ``tableau.json`` : en-tête de ``tableau_eleves.py``) et ``ouvrir(lien)``, qui
recharge la page sur ``?sujet=<lien>`` : le sujet s'ouvre alors par le chemin ordinaire, accueil compris. La clé de la liste
de la classe est lue ici dans l'adresse. Importé après ``pont_qt`` (``lecteur_qt.preparer``), dont il reprend l'application
et le stockage."""

import asyncio
import base64
import json
from urllib.parse import parse_qs

import codes
import tableau_eleves
from js import document
from pont_qt import IDENTITE, PROFESSEUR, deposer_identite, stockage  # celui de pont_qt : la même place que ses copies

FENETRE = None
TABLEAU = "smartteacher-qt|tableau"  # nom, prénom et code personnel de l'élève entré au tableau : le navigateur n'est pas partagé
# entré par son mot de passe, l'élève est retenu sous IDENTITE, [nom, prénom, secret], comme à l'accueil d'un sujet


def commencee(nom: str, identite: tableau_eleves.Identite) -> bool:
    """Une copie de ce sujet par l'élève entré est déjà dans ce navigateur : la place de ``pont_qt.cle`` (premier essai),
    sous son nom tel que la liste l'écrit, celui que l'accueil du sujet donne aussi à sa copie."""
    return bool(identite.eleve) and stockage.lire(f"smartteacher-qt|{nom}|{identite.eleve.lower()}") is not None


def retenu() -> tuple[str, str, str | bytes] | None:
    """L'élève retenu par ce navigateur : par son code personnel, ou par son secret (entré par son mot de passe, ici ou à
    l'accueil d'un sujet) ; à défaut, le mot de passe professeur que l'accueil d'un sujet y a retenu
    (``pont_qt.retenir_identite``), lu sans être récrit."""
    try:
        nom, prenom, code = json.loads(stockage.lire(TABLEAU) or "null")
        return nom, prenom, code
    except (ValueError, TypeError):
        pass
    try:
        nom, prenom, secret = json.loads(stockage.lire(IDENTITE) or "null")
        return nom, prenom, base64.b64decode(secret)
    except (ValueError, TypeError):
        mot = stockage.lire(PROFESSEUR)
        return ("", "", mot) if mot else None


def retenir(valeur: tuple[str, str, str] | None) -> None:
    """Retient l'élève entré, et son nom pour l'accueil des sujets (``pont_qt.preremplir``) ; None : l'oublie."""
    if valeur is None:
        stockage.effacer(TABLEAU)
        stockage.effacer(IDENTITE)
        return
    if isinstance(valeur[2], bytes):  # le secret, pas le mot de passe : l'accueil des sujets le reprend
        stockage.effacer(TABLEAU)
        stockage.ecrire(IDENTITE, json.dumps([valeur[0], valeur[1], base64.b64encode(valeur[2]).decode()]))
        return
    stockage.ecrire(TABLEAU, json.dumps(list(valeur)))
    stockage.ecrire(IDENTITE, json.dumps(list(valeur[:2])))


def montrer(classe: str, echeances: str, catalogue: str, ouvrir, identites: str = "", lire=None, ecrire=None) -> str:
    """Le portail de ``classe`` ; un fichier absent arrive vide. ``identites`` : le fichier d'empreintes, ``lire`` et
    ``ecrire`` ceux de dropbox.js (``identites_lire``, ``identites_ecrire``), où une première visite dépose. Rend
    ``"tableau"``."""
    global FENETRE
    cle = (parse_qs(str(document.location.search).lstrip("?")).get("cle") or [""])[0].strip()
    deposer = (lambda entree: asyncio.ensure_future(deposer_identite(entree, lire, ecrire))) if ecrire else (lambda entree: None)
    FENETRE = tableau_eleves.Portail(classe, echeances or None, catalogue or None, cle, lambda e: ouvrir(e.lien), commencee,
                                     retenu, retenir, identites=codes.identites_lire(identites or None), deposer=deposer)
    document.title = FENETRE.windowTitle()
    FENETRE.showFullScreen()
    return "tableau"
