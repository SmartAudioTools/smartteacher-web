"""Le pont de la page ``?classe=…&cle=…`` (page.html) : le tableau de bord d'une classe (``tableau_eleves.Portail`` : l'entrée
de l'élève, puis son tableau) plein canevas, au lieu d'un sujet. La page lui donne le texte des deux fichiers de la racine du
dossier du professeur (``echeances.csv``, ``tableau.json`` : en-tête de ``tableau_eleves.py``) et ``ouvrir(lien)``, qui
recharge la page sur ``?sujet=<lien>`` : le sujet s'ouvre alors par le chemin ordinaire, accueil compris. La clé de la liste
de la classe est lue ici dans l'adresse. Importé après ``pont_qt`` (``lecteur_qt.preparer``), dont il reprend l'application
et le stockage."""

import asyncio
import base64
import json
from urllib.parse import parse_qs

import codes
import tableau_eleves
from js import document
from pont_qt import IDENTITE, PROFESSEUR, deposer_identite, echeances_signe, stockage  # celui de pont_qt : la même place que ses copies

FENETRE = None
TABLEAU = "smartteacher-qt|tableau"  # ancienne place : nom, prénom et code personnel retirés le 03/11/2026, relus une fois (``retenu``)
# l'élève entré est retenu sous IDENTITE, [nom, prénom, secret], comme à l'accueil d'un sujet


def commencee(nom: str, identite: tableau_eleves.Identite) -> bool:
    """Une copie de ce sujet par l'élève entré est déjà dans ce navigateur : la place de ``pont_qt.cle`` (premier essai),
    sous son nom tel que la liste l'écrit, celui que l'accueil du sujet donne aussi à sa copie."""
    return bool(identite.eleve) and stockage.lire(f"smartteacher-qt|{nom}|{identite.eleve.lower()}") is not None


def retenu() -> tuple[str, str, str | bytes] | None:
    """L'élève retenu par ce navigateur, par son secret (entré par son mot de passe, ici ou à l'accueil d'un sujet) ; son nom
    seul s'il avait été retenu avec un code personnel, oublié ici : il deviendrait son mot de passe sans qu'il le sache ; à
    défaut, le mot de passe professeur que l'accueil d'un sujet y a retenu (``pont_qt.retenir_identite``), lu sans être récrit."""
    try:
        nom, prenom, _ = json.loads(stockage.lire(TABLEAU) or "null")
        stockage.effacer(TABLEAU)
        return nom, prenom, ""
    except (ValueError, TypeError):
        pass
    try:
        nom, prenom, secret = json.loads(stockage.lire(IDENTITE) or "null")
        return nom, prenom, base64.b64decode(secret)
    except (ValueError, TypeError):
        mot = stockage.lire(PROFESSEUR)
        return ("", "", mot) if mot else None


def retenir(valeur: tuple[str, str, bytes] | None) -> None:
    """Retient l'élève entré, pour le tableau et l'accueil des sujets (``pont_qt.preremplir``) ; None : l'oublie."""
    stockage.effacer(TABLEAU)
    if valeur is None:
        stockage.effacer(IDENTITE)
    else:
        stockage.ecrire(IDENTITE, json.dumps([valeur[0], valeur[1], base64.b64encode(valeur[2]).decode()]))


def lire_par(fichier):
    """Le ``lire_bilan`` de ``tableau_eleves.Tableau`` sur ``fichier`` de dropbox.js : les octets lus, rendus au rappel en
    arrière-plan ; None si le bilan manque (dropbox.js lève) ou si le dossier est injoignable."""
    def lire_bilan(chemin: str, rappel) -> None:
        async def lire() -> None:
            try:
                octets = (await fichier(chemin)).to_bytes()
            except Exception as erreur:  # noqa: BLE001 - pas de bilan pour cet élève, ou le professeur injoignable
                print(f"bilan {chemin} : {erreur}")
                octets = None
            rappel(octets)
        asyncio.ensure_future(lire())
    return lire_bilan


def montrer(classe: str, echeances: str, catalogue: str, ouvrir, identites: str = "", lire=None, ecrire=None,
            echeances_lire=None, echeances_ecrire=None, fichier=None) -> str:
    """Le portail de ``classe`` ; un fichier absent arrive vide. ``identites`` : le fichier d'empreintes, ``lire`` et
    ``ecrire`` ceux de dropbox.js (``identites_lire``, ``identites_ecrire``), où une première visite dépose ;
    ``echeances_lire`` et ``echeances_ecrire`` : là où le professeur écrit les réglages d'un sujet (``tableau_eleves.regler_par``),
    sans eux pas de réglages sur la page. Rend ``"tableau"``.
    ``fichier`` : celui de dropbox.js (un .report du dossier du professeur), d'où le bilan de l'année en bas du tableau
    de l'élève (``tableau_eleves.Tableau``, ``lire_bilan``), comme au bureau ; sans lui, pas de bilan."""
    global FENETRE
    cle = (parse_qs(str(document.location.search).lstrip("?")).get("cle") or [""])[0].strip()
    deposer = (lambda entree: asyncio.ensure_future(deposer_identite(entree, lire, ecrire))) if ecrire else (lambda entree: None)
    regler = None
    if echeances_lire and echeances_ecrire:
        def regler(sujet, classe_ligne, changements, rappel):
            graine = FENETRE.identite and FENETRE.identite.graine  # le professeur entré par son mot de passe signe
            asyncio.ensure_future(tableau_eleves.regler_par(echeances_lire, echeances_ecrire, sujet, classe_ligne, changements, rappel,
                                                            graine=graine))
    echeances = echeances_signe(echeances)
    FENETRE = tableau_eleves.Portail(classe, echeances, catalogue or None, cle, lambda e: ouvrir(e.lien, e.jeton), commencee,
                                     retenu, retenir, identites=codes.identites_lire(identites or None), deposer=deposer,
                                     regler=regler, lire_bilan=lire_par(fichier) if fichier else None)
    document.title = FENETRE.windowTitle()
    FENETRE.showFullScreen()
    return "tableau"
