"""« Réviser » selon la composition E du professeur, telle que ses décisions du 06/11/2026 au soir l'ont arrêtée
(``SmartTeacher_essais/entrainement/w187/REVUE_E.md`` § 7) : l'état de chaque notion d'un élève, tiré de ses copies
(``bilans.releve_paquet``), sans Qt.

Une notion est une section du cours (``bilans.chemins_question``, le chemin complet, celui des jauges). Seule la première
réponse à une question compte (``premier``), et une question réussie plusieurs fois ne compte qu'une fois. Une question à
choix, ou toute réponse donnée « cours autorisé », fait monter la jauge sans jamais valider (21:32) : leur part plafonne
à ``PLAFOND``, sous ``ACQUIS``. Seule une question VALIDANTE (``VALIDANTES`` : ouverte ou code) réussie « sans le cours »
fait l'acquis (22:37 ; le champ ``validante`` d'une question remplace cette règle par classe, 07/11/2026) : sans le cours = aucun cours de sa notion dévoilé plus tôt dans la même copie (``Paquet.cours_devoile``).
Vrai/Faux et choix à deux options (``devinable``) ne comptent pas. Une erreur ne retire rien : elle appelle un rattrapage
(``rattrapage``) ; c'est le second échec de suite dans la notion qui retire l'acquis et vide la jauge (22:42). Entretien :
une notion acquise se contrôle à ``INTERVALLES`` croissants ; seule une validante réussie sans le cours réussit un
contrôle (décision du 07/11/2026, 09:55), une autre réussite le laisse dû. L'état porte ce que le bilan doit tenir (22:49) : niveau
(``score``), date de la dernière validation (``valide_le``), intervalle en cours (``intervalle``). Toutes les constantes
sont ici, et seulement ici.
"""
from __future__ import annotations

import math
import random
import re
from typing import Any

import noyau
from bilans import chemins_question

JOUR = 86400.0
ACQUIS = 2.0  # jauge qui fait l'acquis : deux questions différentes réussies, dont une validante sans le cours
PLAFOND = 0.7 * ACQUIS  # part de la jauge que les questions à choix et les réponses « cours autorisé » peuvent
#                         apporter : « jamais jusqu'à 100 % » (21:32) ; 70 % de la jauge (décision du 07/11/2026, 10:08)
VALIDANTES = frozenset({"ReponseOuverte", "Code"})  # classes (ou leurs parents) qui peuvent valider : pas d'options
#                                                    affichées ; ReponseCourte n'y est pas : la règle par défaut, qu'un
#                                                    champ ``validante`` de la question remplace (décision du 07/11/2026)
INTERVALLES = (1 * JOUR, 3 * JOUR, 7 * JOUR, 14 * JOUR, 30 * JOUR)  # contrôles d'une notion acquise ; le dernier se
#                                                                    répète (un mois : décision du 07/11/2026, 10:14)
TAILLE = 10  # questions d'un questionnaire « Réviser » (un bloc lié n'est jamais coupé : il peut la dépasser)
CONTROLES = 3  # contrôles de notions acquises au plus par questionnaire, les plus anciens dus d'abord (point 8)
SANS_COURS, COURS_AUTORISE = "sans le cours", "cours autorisé"  # le mode d'une question (22:37), ``modes``


def validante(classes: set[str]) -> bool:
    """Une question dont les feuilles sont de ces ``classes`` (noms de la classe et de ses parents) peut valider."""
    return bool(classes & VALIDANTES)


def validante_question(q: dict[str, Any], herite: bool | None = None) -> bool:
    """La question de banque ``q`` (JSON) peut valider : toutes ses feuilles (sous-questions, à toute profondeur) le
    peuvent, comme ``bilans._premier_essai`` le relève dans une copie. Une feuille le peut si son champ ``validante``
    le dit (``True`` / ``False``), sinon celui de son groupe le plus proche (``herite``), sinon la règle par classe
    (``validante`` : classe validante, parents compris, ``noyau``)."""
    propre = q.get("validante")
    herite = herite if propre is None else bool(propre)
    sous = [s for s in q.get("sous_questions") or [] if isinstance(s, dict)]
    if sous:
        return all(validante_question(s, herite) for s in sous)
    if herite is not None:
        return herite
    classe = getattr(noyau, q.get("__class__") or "", None)
    return validante({c.__name__ for c in classe.__mro__} if isinstance(classe, type) else {q.get("__class__") or ""})


def sans_le_cours(i: str, instant: float, vues: list[tuple[str, float]]) -> bool:
    """La question ``i`` est « sans le cours » à ``instant`` (sa première soumission, ou maintenant tant qu'elle n'est
    pas soumise) : aucun cours de sa notion n'a été dévoilé avant dans la même copie (``vues`` : [(id de la question qui
    masquait la zone, instant du dévoilement)], ``Paquet.cours_devoile``). Sa propre zone ne compte pas : elle ne se
    dévoile qu'à sa fermeture, au même dixième de seconde que sa réponse (``Paquet._noter_cours_devoile``), et lui
    retirerait sinon sa validation."""
    return not any(j != i and v <= instant for j, v in vues)


def modes(paquet: Any, maintenant: float | None = None) -> dict[str, str]:
    """{id : mode} des questions d'un sujet « Réviser » (``Paquet.reviser`` ; vide pour un autre sujet), ce que l'icône
    sous leur numéro affiche (22:37) : ``SANS_COURS`` si elle peut valider (``validante``, relevée comme par
    ``bilans.releve_paquet``) et ``sans_le_cours`` à sa première soumission, ou à ``maintenant`` tant qu'elle n'est pas
    soumise (dévoiler le cours de sa notion pendant qu'elle est ouverte la repasse en ``COURS_AUTORISE``). Tiré de la
    copie seule (``cours_devoile``, ``horodatage``) : rien à stocker, ``etat_notions`` refait le même calcul.
    Sans ``maintenant``, tout dévoilement déjà enregistré compte pour une question non soumise : ``cours_devoile`` est
    arrondi au dixième, jusqu'à 0,05 s après ``time.time()``, et le dévoilement qui vient d'avoir lieu serait ignoré."""
    if not paquet.reviser:
        return {}
    notions = paquet.reviser.get("notions") or {}

    def de(i: str) -> tuple[str, ...]:  # comme ``etat_notions`` et ``Paquet._composer`` : « Autres » à défaut
        return tuple(notions.get(i) or ("Autres",))
    vues: dict[tuple[str, ...], list[tuple[str, float]]] = {}
    for i, instant in (paquet.cours_devoile or {}).items():
        vues.setdefault(de(i), []).append((i, instant))
    maintenant = math.inf if maintenant is None else maintenant
    resultat = {}
    for q in paquet.questions():
        instant = premiere_soumission(q)
        instant = maintenant if instant is None else instant
        resultat[q.id] = SANS_COURS if validante_feuilles(q) and sans_le_cours(q.id, instant, vues.get(de(q.id), [])) \
            else COURS_AUTORISE
    return resultat


def validante_feuilles(q: Any) -> bool:
    """La question ``q`` d'une copie (``noyau.Question``) peut valider : toutes ses feuilles le peuvent, chacune par
    son champ ``validante``, sinon celui de ``q`` (son groupe), sinon la règle par classe, parents compris
    (``validante``) ; même règle que ``validante_question`` pour la banque ; lu par ``bilans.releve_paquet`` et ``modes``."""
    feuilles = q.feuilles()
    groupe = getattr(q, "validante", None)

    def peut(f: Any) -> bool:
        propre = getattr(f, "validante", None)
        propre = groupe if propre is None else propre
        return bool(propre) if propre is not None else validante({c.__name__ for c in type(f).__mro__})
    return bool(feuilles) and all(peut(f) for f in feuilles)


def premiere_soumission(q: Any) -> float | None:
    """L'instant de la première soumission de la question ``q`` d'une copie (``horodatage`` de ses feuilles), None tant
    qu'aucune ne l'est ; lu par ``bilans.releve_paquet`` et ``modes``."""
    instants = [f.horodatage[0] for f in q.feuilles() if f.horodatage]
    return min(instants) if instants else None


def famille(i: str) -> str:
    """La famille d'une question (décision 22:31 : exercices distincts mais interchangeables, un seul par questionnaire) :
    son id sans le suffixe ``_v<n>`` des variantes de banque (``<origine>_v<n>``, W194, W210)."""
    return re.sub(r"_v\d+$", "", i)


def niveau_vise(etat: dict[str, Any]) -> int:
    """La ``difficulte`` (1 à 3) à poser dans une notion dans cet ``etat`` : 1 tant que rien n'a monté la jauge d'au
    moins une question, 2 en cours d'acquisition, 3 pour le contrôle d'une notion acquise."""
    return 3 if etat["acquis"] else 2 if etat["score"] >= 1 else 1


def notion(champs: dict[str, Any]) -> tuple[str, ...]:
    """La notion d'une question : le premier chemin complet de ``bilans.chemins_question``."""
    return chemins_question(champs)[0]


def etat_notions(releves: list[dict[str, Any]], banque: dict[str, dict[str, Any]], maintenant: float,
                 depart: dict[tuple[str, ...], dict[str, Any]] | None = None, depuis: float | None = None,
                 notions: dict[str, list[str]] | None = None) -> dict[tuple[str, ...], dict[str, Any]]:
    """{notion : état} d'UN élève, d'après les relevés de ses copies (``bilans.releve_paquet``) et ``banque``
    (``bilans.index_banques``). État : ``lecture`` (dernier dévoilement du cours, None), ``score`` (la jauge : une
    validation sans le cours vaut 1, le reste 1 aussi mais plafonné à ``PLAFOND``, depuis le dernier double échec),
    ``acquis``, ``valide_le`` (dernière validation sans le cours réussie, None), ``rattrapage`` (la dernière réponse
    comptée est un échec), ``controles`` (contrôles réussis depuis l'acquis), ``intervalle`` et ``du`` (intervalle en
    cours et instant du prochain contrôle, None si non acquise), ``a_controler`` (``du`` passé à ``maintenant``),
    ``reussies`` / ``ratees`` (ids, premier essai), ``reponses`` [(instant, id, réussie, validante sans le cours)].
    Une absence ne rate rien : un contrôle dû reste dû (``a_controler``) tant que l'élève n'a pas répondu.
    ``depart`` : l'état d'où partir (celui du bilan, ``depuis_bilan``), calculé à ``depuis`` : seules les lectures et
    réponses d'après ``depuis`` s'y ajoutent (les révisions faites depuis le calcul du bilan, étape 5 du plan W189).
    ``notions`` : {id : chemin de sa notion} (``Paquet.reviser``), à la place de ``banque`` que le lecteur n'a pas ;
    une question qui n'y est pas compte dans « Autres », comme dans ``Paquet._composer``."""
    depart = depart or {}

    def de(i: str) -> tuple[str, ...] | None:
        if notions is not None:
            return tuple(notions.get(i) or ("Autres",))
        return notion(banque[i]) if i in banque else None

    def apres(instant: float) -> bool:
        return depuis is None or instant > depuis
    lectures: dict[tuple[str, ...], list[float]] = {}
    reponses: dict[tuple[str, ...], list[tuple[float, str, bool, bool, bool]]] = {}
    for r in releves:
        vues_copie: dict[tuple[str, ...], list[tuple[str, float]]] = {}
        for i, instant in (r.get("cours_devoile") or {}).items():
            if (n := de(i)) is not None:
                if apres(instant):
                    lectures.setdefault(n, []).append(instant)
                vues_copie.setdefault(n, []).append((i, instant))
        for q in r["questions"]:
            if (n := de(q["id"])) is not None and q.get("premier") is not None and q.get("instant") is not None \
                    and apres(q["instant"]):
                sans_cours = sans_le_cours(q["id"], q["instant"], vues_copie.get(n, []))
                reponses.setdefault(n, []).append((q["instant"], q["id"], q["premier"], bool(q.get("devinable")),
                                                   bool(q.get("validante")) and sans_cours))
    etats = {}
    for n in dict.fromkeys([*depart, *reponses, *lectures]):
        vues = sorted(lectures.get(n, []))
        avant = depart.get(n, {})
        etat: dict[str, Any] = {"lecture": None, "score": 0.0, "acquis": False, "valide_le": None,
                                "rattrapage": False, "controles": 0, "intervalle": None, "du": None,
                                **{k: avant[k] for k in GARDES if k in avant}, "reponses": []}
        etat["lecture"] = vues[-1] if vues else etat["lecture"]
        etat["reussies"], etat["ratees"] = list(avant.get("reussies", [])), list(avant.get("ratees", []))
        # ids réussis en validation sans le cours ; une question revue ne compte qu'une fois
        validees: set[str] = set(avant.get("validees", []))
        indications: set[str] = set(avant.get("indications", []))  # ids réussis autrement (question à choix, cours autorisé)
        for instant, i, reussie, devinable, valide in sorted(reponses.get(n, [])):
            etat["reponses"].append((instant, i, reussie, valide))
            (etat["reussies"] if reussie else etat["ratees"]).append(i)
            if devinable:
                continue
            if not reussie:
                if etat["rattrapage"]:  # second échec de suite : l'acquis est perdu, on repart de zéro
                    etat.update(score=0.0, acquis=False, valide_le=None, controles=0, intervalle=None, du=None)
                    validees, indications = set(), set()
                etat["rattrapage"] = not etat["rattrapage"]  # après la perte, le compte des échecs repart
                continue
            etat["rattrapage"] = False
            if valide:
                etat["valide_le"] = instant
            if etat["acquis"]:
                if valide and instant >= etat["du"]:  # contrôle dû et réussi par une validante sans le cours (07/11)
                    etat["controles"] += 1
                    etat["intervalle"] = INTERVALLES[min(etat["controles"], len(INTERVALLES) - 1)]
                    etat["du"] = instant + etat["intervalle"]
                continue
            (validees if valide else indications).add(i)
            indications -= validees
            etat["score"] = len(validees) + min(PLAFOND, len(indications))
            if validees and etat["score"] >= ACQUIS:
                etat.update(acquis=True, intervalle=INTERVALLES[0], du=instant + INTERVALLES[0])
        etat["a_controler"] = etat["acquis"] and maintenant >= etat["du"]
        etat["validees"], etat["indications"] = sorted(validees), sorted(indications)
        etats[n] = etat
    return etats


GARDES = ("lecture", "score", "acquis", "valide_le", "rattrapage", "controles", "intervalle", "du", "reussies", "validees",
          "indications")  # ce que le bilan garde d'un état : ``composer`` le lit, et de quoi y ajouter des réponses


def en_bilan(etats: dict[tuple[str, ...], dict[str, Any]]) -> list[list[Any]]:
    """``etats`` (``etat_notions``) tel que le bilan de l'élève le porte : ``[[chemin de la notion, {GARDES}], …]``, sans
    ``reponses`` (le détail, que seul le calcul lit) ni ``a_controler`` (qui dépend de l'instant où on le lit)."""
    return [[list(n), {k: e[k] for k in GARDES if k in e}] for n, e in etats.items()]


def depuis_bilan(lignes: list[list[Any]], maintenant: float) -> dict[tuple[str, ...], dict[str, Any]]:
    """L'inverse d'``en_bilan`` : {notion : état}, ``a_controler`` recalculé à ``maintenant``."""
    etats = {}
    for chemin, garde in lignes:
        etat = {"reponses": [], "ratees": [], **garde}
        etat["a_controler"] = bool(etat.get("acquis")) and etat.get("du") is not None and maintenant >= etat["du"]
        etats[tuple(chemin)] = etat
    return etats


def composer(blocs: list[tuple[tuple[str, ...], list[str]]], etats: dict[tuple[str, ...], dict[str, Any]], graine: str,
             taille: int = TAILLE, questions: dict[str, dict[str, Any]] | None = None) -> list[str]:
    """Les ids d'un questionnaire « Réviser » (points 1 à 3 et 8 d'E) parmi ``blocs`` [(notion, ids liés dans l'ordre de
    la banque)], d'après ``etats`` (``etat_notions``, l'élève à cet instant) et ``questions`` ({id : question de banque},
    pour ``difficulte`` et ``validante_question``). Un bloc au plus par ``famille`` (celle de sa première question) : le
    membre retenu est, dans l'ordre, jamais réussi, validant si la notion n'attend plus qu'une validation (une question au
    moins comptée, aucune validée sans le cours : une question à choix de plus n'y ferait rien) ou un contrôle dû, de ``difficulte`` la plus
    proche de ``niveau_vise``, au hasard sous ``graine`` ; les familles d'une notion se rangent de même. D'abord les
    contrôles dus (``CONTROLES`` au plus, le plus ancien ``du`` d'abord, un bloc par notion) ; puis les notions non
    acquises, de la plus proche de l'acquis à la plus faible (``score``), un bloc par notion à chaque tour, jusqu'à
    ``taille`` questions. Les notions acquises non dues ne servent que s'il ne reste rien d'autre. Ordre final mélangé,
    chaque bloc gardé dans l'ordre de la banque."""
    alea = random.Random(graine)
    questions = questions or {}
    familles: dict[tuple[str, ...], dict[str, list[list[str]]]] = {}
    for n, ids in blocs:
        familles.setdefault(n, {}).setdefault(famille(ids[0]), []).append(ids)
    vide: dict[str, Any] = {"acquis": False, "score": 0.0, "reussies": [], "a_controler": False, "du": None,
                            "valide_le": None}
    par_notion: dict[tuple[str, ...], list[tuple[str, list[str]]]] = {}
    for n, par_famille in familles.items():
        etat = etats.get(n, vide)
        reussies, vise = set(etat["reussies"]), niveau_vise(etat)
        attend_validation = (not etat["acquis"] and etat["score"] >= 1 and etat.get("valide_le") is None) \
            or etat["a_controler"]  # un contrôle ne se réussit que par une validante (07/11)

        def cle(b: list[str]) -> tuple[bool, bool, int]:
            valide = any(i in questions and validante_question(questions[i]) for i in b)
            return (any(i in reussies for i in b), attend_validation and not valide,
                    abs((questions.get(b[0], {}).get("difficulte") or 2) - vise))

        retenus = []
        for f, membres in par_famille.items():
            alea.shuffle(membres)
            retenus.append((f, min(membres, key=cle)))  # min : le premier des ex aequo, mélangés
        alea.shuffle(retenus)
        retenus.sort(key=lambda fb: cle(fb[1]))  # stable : au hasard entre ex aequo
        par_notion[n] = retenus
    pris: set[str] = set()  # familles posées : une famille qui déborde sur deux notions n'est tirée qu'une fois

    def tirer(n: tuple[str, ...]) -> list[str] | None:
        while par_notion[n]:
            f, b = par_notion[n].pop(0)
            if f not in pris:
                pris.add(f)
                return b
        return None

    dus = sorted((n for n in par_notion if etats.get(n, vide)["a_controler"]), key=lambda n: etats[n]["du"])[:CONTROLES]
    choisis = [b for b in map(tirer, dus) if b]
    ouvertes = sorted((n for n in par_notion if not etats.get(n, vide)["acquis"]), key=lambda n: -etats.get(n, vide)["score"])
    reste = [n for n in par_notion if n not in ouvertes]
    for groupe in (ouvertes, reste):
        while groupe and sum(map(len, choisis)) < taille:
            groupe = [n for n in groupe if par_notion[n]]
            for n in groupe:
                if sum(map(len, choisis)) >= taille:
                    break
                if b := tirer(n):
                    choisis.append(b)
    alea.shuffle(choisis)
    return [i for b in choisis for i in b]
