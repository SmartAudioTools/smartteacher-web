"""La clé du modèle qui note (``jugement`` : ``cle``, ``modele``, ``escalade``) dans un fichier à part, à la racine du dossier
des sujets en ligne, que le lecteur relit à chaque ouverture et qui prime sur celle du sujet ou de la copie.

Le professeur, 18/11/2026 (W782) : « si un jour on rechange la clé, il y a un redéploiement de tous les sujets … est-ce que
la clé de l'IA doit être dans le sujet ou est-ce qu'il faudrait pas que ça soit dans un JSON à côté ? ». Avant : la clé
n'était que dans le ``.qcm`` (``exporter_eleve.chiffre``) et chaque copie gardait celle de son départ (``Paquet.etat``) ;
après la rotation du 07/11, 245 copies portaient encore la clé révoquée et leurs réponses restaient sans note. Changer de
clé : ``web/dropbox_professeur.py cle`` (ou tout « Déployer »), sans réexporter un sujet.

Le fichier est brouillé, pas chiffré : le lecteur de l'élève doit le lire sans mot de passe, comme il lit la clé du
``.qcm`` ; le brouillage évite seulement qu'une clé en clair se lise ou se repère (``sk-ant-``) dans un dossier partagé.
Les cours (``cours``) restent dans le sujet : ce fichier ne porte que ce que ``exporter_eleve.jugement_configure`` lit
dans ``web/deployer.conf``."""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path
from typing import Any

FICHIER = "jugement.txt"
CHAMPS = ("cle", "modele", "escalade")
_MASQUE = hashlib.sha256(b"smartteacher|jugement|brouillage").digest()


def _xor(octets: bytes) -> bytes:
    return bytes(o ^ _MASQUE[i % len(_MASQUE)] for i, o in enumerate(octets))


def octets(jugement: dict[str, Any]) -> bytes:
    """Le contenu du fichier pour ``jugement`` (ses seuls ``CHAMPS``)."""
    propre = {c: jugement[c] for c in CHAMPS if jugement.get(c)}
    return base64.b64encode(_xor(json.dumps(propre, ensure_ascii=False).encode())) + b"\n"


def lire(texte: str | bytes | None) -> dict[str, str] | None:
    """Le ``jugement`` du fichier, ou None : absent, illisible, ou sans clé (le lecteur garde alors celui du sujet)."""
    if not texte:
        return None
    try:
        brut = texte.encode() if isinstance(texte, str) else texte
        jugement = json.loads(_xor(base64.b64decode(brut.strip(), validate=True)))
    except (ValueError, UnicodeDecodeError):
        return None
    if not isinstance(jugement, dict) or not jugement.get("cle"):
        return None
    return {c: str(jugement[c]) for c in CHAMPS if jugement.get(c)}


def du_disque(chemin: str | Path) -> dict[str, str] | None:
    """Le lecteur natif : le fichier du dossier de ``chemin`` ou d'un de ses parents (le miroir Dropbox du professeur)."""
    for dossier in Path(chemin).resolve().parents:
        try:
            return lire((dossier / FICHIER).read_bytes())
        except OSError:
            continue
    return None


def applique(jugement: dict[str, Any] | None, commun: dict[str, str] | None) -> dict[str, Any] | None:
    """Le ``jugement`` d'une question : celui du sujet (ses cours), sa clé et ses modèles remplacés par ceux du fichier
    commun. Un sujet sans ``jugement`` (exporté sans clé exprès : papier, essai) le reste."""
    return {**jugement, **commun} if jugement and commun else jugement
