"""Les aménagements que le lecteur ``.qcm`` applique à l'élève qui compose (natif et web), sans changer le sujet : le
professeur, 10/11/2026 : « c'est juste le lecteur web qui doit s'adapter en fonction de l'élève, le fichier est a priori le
même » ; « seulement le profil, jamais le classeur ».

La table ``amenagements.json``, à la racine du dossier Dropbox du professeur (à côté de ``identites.json``), est tirée du
classeur (``amenagements_eleves``) par « Déployer sur le web » (``web/dropbox_professeur.py deposer``) :
``{"version": 1, "eleves": {clé: ["simplifie", "tiers_temps"]}}``. La clé hache les mots du nom (``cle_publiee``) : ni nom
en clair, ni libellé du classeur, seulement les aménagements que le lecteur sait appliquer (``LECTEUR``). La page la lit
comme ``echeances.csv`` (``dropbox.js racine``), le natif comme le fichier d'empreintes (``du_disque``).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import math
from pathlib import Path
from typing import Any

from amenagements_eleves import cle, profil

FICHIER = "amenagements.json"
LECTEUR = frozenset({"tiers_temps", "simplifie", "agrandi", "oralise", "orthographe"})  # ce que le lecteur applique
# les libellés du classeur (avant toute parenthèse, comme ``amenagements_eleves.profil``) que seul le lecteur applique : hors
# de ``amenagements_eleves.CORRESPONDANCE``, qui en ferait une copie papier aménagée sans rien y changer
# « orthographe » : une faute de plus par mot de sept lettres dans une réponse courte (``noyau.FAUTES_EN_PLUS``)
SEULEMENT_LECTEUR = {"consignes oralisées": "oralise",  # le bouton « Écouter » (``modele.Paquet.ecouter``)
                     "orthographe non pénalisée": "orthographe"}
# le zoom de départ de l'élève « agrandi » (``lecteur.Lecteur``) : la valeur d'``exporter_pdf.ECHELLE_AGRANDI``, que le
# lecteur web n'embarque pas (reportlab)
ZOOM_AGRANDI = 1.3
TIERS_TEMPS = 4 / 3  # la durée d'un élève tiers-temps


def cle_publiee(*morceaux: str) -> str:
    """La clé d'un élève dans la table : les mots de son nom (``amenagements_eleves.cle``, « DUPONT Élise » comme « Elise
    Dupont »), hachés. Qui a la liste des noms la recalcule (comme ``codes.cle_bilan`` de l'empreinte) : elle ne cache le
    nom qu'à qui ne l'a pas."""
    return hmac.new(b"SmartTeacher amenagements v1", " ".join(cle(*morceaux)).encode(), "sha256").hexdigest()[:24]


def table(donnees: dict[str, Any]) -> dict[str, Any]:
    """La table publiée du classeur ``donnees`` (``amenagements_eleves.classeur``) : chaque élève qui a au moins un aménagement
    du lecteur, qu'il compose sur papier ou sur ordinateur."""
    eleves: dict[str, set[str]] = {}
    for classe in donnees.values():
        for eleve, fiche in classe.items():
            if amenagements := profil_lecteur(fiche.get("amenagements") or []):
                eleves.setdefault(cle_publiee(eleve), set()).update(amenagements)
    return {"version": 1, "eleves": {c: sorted(a) for c, a in sorted(eleves.items())}}


def profil_lecteur(libelles: list[str]) -> frozenset[str]:
    """Les aménagements du lecteur que portent ces libellés du classeur : ceux du générateur qu'il applique, et les siens."""
    siens = {SEULEMENT_LECTEUR[c] for libelle in libelles if (c := libelle.split("(")[0].strip().lower()) in SEULEMENT_LECTEUR}
    return (profil(libelles) | siens) & LECTEUR


def octets(donnees: dict[str, Any]) -> bytes:
    """La table de ``donnees`` telle qu'elle se dépose : le même classeur donne les mêmes octets (déposée une fois)."""
    return json.dumps(table(donnees), ensure_ascii=False, indent=1).encode()


def lire(texte: str | None) -> dict[str, list[str]]:
    """``{clé: aménagements}`` de la table ``texte`` ; vide si elle est absente ou illisible (aucun élève n'est aménagé)."""
    try:
        eleves = json.loads(texte).get("eleves") if texte else None
    except (ValueError, AttributeError):
        return {}
    return eleves if isinstance(eleves, dict) else {}


def de(table_lue: dict[str, list[str]], eleve: str) -> frozenset[str]:
    """Les aménagements de ``eleve`` (« Nom Prénom ») que le lecteur applique ; aucun s'il n'est pas dans la table."""
    return frozenset(table_lue.get(cle_publiee(eleve)) or ()) & LECTEUR if eleve else frozenset()


def du_disque(chemin: str | Path) -> dict[str, list[str]]:
    """La table du natif : la première trouvée dans le dossier du sujet ou au-dessus (la racine du dossier Dropbox partagé),
    comme ``lecteur.identites_du_disque`` ; vide sinon."""
    dossier = Path(chemin).resolve().parent
    for d in (dossier, *dossier.parents):
        try:
            return lire((d / FICHIER).read_text(encoding="utf-8"))
        except OSError:
            continue
    return {}


def bonus(amenagements: frozenset[str], duree_minutes: int | None) -> int:
    """Les minutes ajoutées à la durée ``duree_minutes`` (et à l'échéance) pour ces aménagements : un tiers, arrondi à la
    minute au-dessus, pour le tiers-temps ; rien sans durée."""
    return math.ceil(duree_minutes * (TIERS_TEMPS - 1) - 1e-9) if "tiers_temps" in amenagements and duree_minutes else 0


def simplifier(paquet: Any) -> int:
    """L'énoncé simplifié d'office (``reformulee``, enregistré dans la copie) partout où la question en a un, sous-questions
    comprises ; l'élève garde le lien « énoncé d'origine ». Rend le nombre de questions changées."""
    changees = 0
    for q in paquet.questions():
        for f in (q, *q.sous_questions):
            if getattr(f, "enonce_simplifie", "") and not f.reformulee:
                f.reformulee, changees = True, changees + 1
    return changees
