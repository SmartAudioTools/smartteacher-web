"""Le modèle objet de QCM/ : banques, questions, sujets et paquets élèves, en classes Python (voir README.md).

Chaque classe se lit et s'écrit en JSON par serializejson : le fichier est un JSON plat où ``"__class__"`` nomme la
classe, les valeurs par défaut du ``__init__`` étant omises. Un parseur tiers qui ignore ``__class__`` retrouve
l'arbre de dictionnaires. Au chargement, ``__init__`` est rappelé avec les champs du fichier : un champ inconnu ou
manquant est une ``TypeError``, jamais un champ ignoré.

Le type d'une question est sa classe (``ChoixUnique``…), et ``type`` en donne le nom historique (``"choix_unique"``).
Ne restent des dictionnaires que les clés qui sont des DONNÉES : ``contextes``, ``medias``, ``variables``,
``competences_livret``, ``trous``.

Tout ce qui contient des questions est un widget Qt (qtpy6, PySide6) : les seize types, ``Section``, ``Paquet`` et
``Banque``. Une même classe sert donc à la banque du professeur, au paquet livré et au rendu de l'élève, à des états
différents : ``charger(fichier).show()`` affiche n'importe lequel. Seul ``DefinitionSujet`` reste une donnée pure.
La réponse de l'élève est le champ ``saisie`` (``reponse`` est, pour une alternative, la bonne réponse) : une property
branchée sur les widgets de saisie, que ``Objet.__serializejson__`` écrit avec les autres champs, si bien que
l'enregistrement du fichier suffit à conserver la session (réponses, indices débloqués, seconde chance, fin).
Le paquet livré à l'élève contient les questions COMPLÈTES : c'est son chiffrement (``mot_de_passe``) qui les protège.
"""

import configparser
import functools
import math
import os
import re
from pathlib import Path

import noyau
import qtpy6web.tactile
from noyau import *  # noqa: F403 - modele.py EST le noyau, avec des widgets : ses importeurs y trouvent tout (serializejson compris)
from qtpy6.QtCore import (QByteArray, QEasingCurve, QEvent, QObject, QPoint, QPointF, QPropertyAnimation, QRect, QSize,
                          QSizeF, Qt, QTimer, Signal)
from qtpy6.QtGui import (QColor, QFontMetrics, QImage, QKeySequence, QPainter, QPalette, QPen, QPixmap, QPolygonF,
                         QPyTextObject, QTextCharFormat, QTextCursor, QTextDocument, QTextFormat, QTextOption)
from qtpy6.QtSvg import QSvgRenderer
from qtpy6.QtWidgets import (QAbstractItemView, QApplication, QButtonGroup, QCheckBox, QComboBox, QFrame,
                             QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                             QListWidget, QListWidgetItem, QMenu, QMessageBox, QPlainTextEdit, QProgressBar,
                             QPushButton, QRadioButton, QScrollArea, QSizePolicy, QStackedWidget, QStyledItemDelegate,
                             QTableWidget, QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget)

from console_code import ConsoleCode
from qtpy6web.dispositions import Disposition, Rangee
from editeur_code import EditeurCode, EditeurLignes
from texte_md import BORDURE_TABLEAU, CADRE_CODE, ENTETE_TABLEAU, GRIS_FAIT, Markdown, cellule

if qtpy6web.navigateur():
    import processus_web  # le Web Worker qui corrige les questions code (Code.soumettre), à la place du sous-processus

IMAGES = {"png", "jpg", "jpeg", "gif", "webp", "svg"}
LARGEUR_MAX = 900  # largeur d'affichage maximale d'une image, en pixels
HAUTEUR_VISUEL = 90  # le visuel du thème dans l'entête du sujet, en pixels
TAILLE_POLICE = 12  # le texte du sujet, en points : les 16 px d'un navigateur, là où la police du système en donne 13
PAUSE_MS, DESCENTE_MS = 700, 450  # la question traitée reste grisée sous les yeux, puis la vue glisse à la suivante


def charger(chemin, mot_de_passe=None):
    """L'objet (Banque, DefinitionSujet, Paquet…) écrit dans le fichier, chiffré ou non."""
    application()
    return serializejson.load(str(chemin), authorized_classes=list(serializejson.constructors), encryption_key=mot_de_passe)


def sauver(objet, chemin, mot_de_passe=None):
    """Écrit l'objet ; chiffré (age, scrypt) si ``mot_de_passe`` : le coût de scrypt n'est payé qu'une fois par processus."""
    # dans le navigateur, la copie se range (localStorage) et s'envoie (Apps Script) en texte : l'armure ASCII d'age (base64) ;
    # ailleurs le binaire, d'un tiers plus court
    serializejson.dump(objet, str(chemin), bytes_compression=None, index=None, sort_keys=False, single_line_list_numbers=False,
                       encryption_key=mot_de_passe, encryption_in_base64=qtpy6web.navigateur())
    serializejson.wait_writes()



# --- l'écran : une application, du texte Markdown, des lignes cochables ------------------------------------------


def application():
    """La QApplication du processus, créée au besoin (``qtpy6web.application`` : hors session graphique, sans fenêtre ;
    dans le navigateur, où Qt n'a AUCUNE police système, celles du sujet et celle de l'interface du natif, Noto Sans, ce
    que « Sans Serif 9 » donne sur la machine, sont livrées dans ``polices/`` à côté de ce fichier et chargées là)."""
    return qtpy6web.application(polices=Path(__file__).parent / "polices", defaut=("Noto Sans", 9))


def fond_sujet():
    """Le fond du sujet : entre le gris de la fenêtre (trop terne) et le blanc des champs (qui s'y perdraient), aux trois
    quarts vers le blanc."""
    fenetre, champ = QApplication.palette().window().color(), QApplication.palette().base().color()
    return QColor(*((a + 3 * b) // 4 for a, b in zip(fenetre.getRgb()[:3], champ.getRgb()[:3])))


def fond_entete(palette):
    """Donne à ``palette`` le fond de l'entête du sujet : celui de la barre de titre, lu dans le thème KDE (« Header »),
    plus foncé quand la fenêtre a le focus, comme elle ; ailleurs, le gris de la fenêtre, assombri d'autant qu'en Breeze
    clair (239 → 222) quand elle a le focus. ``configparser`` et pas QSettings : celui-ci lit « [Colors:Header][Inactive] »
    comme une seconde « [Colors:Header] », qui écrase la première."""
    theme = configparser.ConfigParser(interpolation=None, strict=False)
    theme.read(os.path.expanduser("~/.config/kdeglobals"), encoding="utf-8")
    fenetre = QApplication.palette().window().color()
    for groupe, section, defaut in ((QPalette.ColorGroup.Active, "Colors:Header", fenetre.darker(108)),
                                    (QPalette.ColorGroup.Inactive, "Colors:Header][Inactive", fenetre)):
        try:
            couleur = QColor(*map(int, theme.get(section, "BackgroundNormal").split(",")))
        except (configparser.Error, TypeError, ValueError):  # pas de KDE, ou une couleur écrite autrement que « r,g,b »
            couleur = defaut
        palette.setColor(groupe, QPalette.ColorRole.Window, couleur)


def question(widget):
    """La question qui contient ``widget`` (ou ``widget`` lui-même), None hors d'une question."""
    while widget is not None and not isinstance(widget, Question):
        widget = widget.parentWidget()
    return widget


def copiable(widget):
    """Vrai si une question qui contient ``widget`` (ou lui-même) porte ``copiable`` : sans elle, rien ne se copie.
    Toutes les questions qui le contiennent comptent : un Groupe copiable le transmet à ses sous-questions."""
    while widget is not None:
        if isinstance(widget, Question) and widget.copiable:
            return True
        widget = widget.parentWidget()
    return False


def cadre_code(document, position):
    """La table du cadre de code (texte_md.bloc_code) où se trouve ``position``, None hors d'un code."""
    curseur = QTextCursor(document)
    curseur.setPosition(position)
    table = curseur.currentTable()
    return table if table is not None and table.format().background().color() == QColor(CADRE_CODE[0]) else None


def code_selectionne(texte):
    """Le code sélectionné dans un Texte d'un projet, tel qu'écrit ; None si la sélection n'est pas dans un cadre de code."""
    curseur = texte.textCursor()
    if not texte.property("code_seul") or not curseur.hasSelection() or cadre_code(texte.document(), curseur.anchor()) is None:
        return None
    return curseur.selectedText().replace("\u2029", "\n")


class GardeCopie(QObject):
    """Installé par le lecteur seulement : rien de ce que l'élève voit ne peut être copié, sauf dans une question
    ``copiable``. Le texte n'est plus sélectionnable ; Ctrl+C, Ctrl+X, Ctrl+Inser, Maj+Suppr et le menu contextuel sont
    interceptés AVANT que le presse-papiers ne reçoive quoi que ce soit (un gestionnaire de presse-papiers le lirait aussitôt).
    Dans un projet, le code de l'énoncé est écrit pour être collé dans l'éditeur : un cadre de code s'y sélectionne et se
    copie (Ctrl+C), un cadre à la fois, et rien autour."""

    def __init__(self, app):
        super().__init__(app)
        app.installEventFilter(self)

    def eventFilter(self, objet, evenement):
        type_ = evenement.type()
        if not isinstance(objet, QWidget):
            return False
        if type_ == QEvent.Type.Show and isinstance(objet, Texte):  # dans les deux sens : un Texte affiché avant d'avoir son parent est venu sans question
            libre, q = copiable(objet), question(objet)
            objet.setProperty("code_seul", not libre and q is not None and q.projet)
            objet.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction if libre
                                          else Qt.TextInteractionFlag.TextSelectableByMouse if objet.property("code_seul")
                                          else Qt.TextInteractionFlag.NoTextInteraction)
            if objet.property("code_seul") and not objet.property("limite"):
                objet.setProperty("limite", True)
                objet.selectionChanged.connect(functools.partial(self.limiter, objet))
        elif type_ in (QEvent.Type.KeyPress, QEvent.Type.ShortcutOverride):
            if evenement.matches(QKeySequence.StandardKey.Copy) or evenement.matches(QKeySequence.StandardKey.Cut):
                if copiable(objet):
                    return False
                code = code_selectionne(objet) if type_ == QEvent.Type.KeyPress and isinstance(objet, Texte) else None
                if code is not None:
                    QApplication.clipboard().setText(code)
                return True
        elif type_ == QEvent.Type.ContextMenu and not copiable(objet):
            return True
        return False

    @staticmethod
    def limiter(texte):
        """Une sélection ne sort pas du cadre de code où elle a commencé ; commencée ailleurs, elle s'efface."""
        curseur = texte.textCursor()
        if not curseur.hasSelection():
            return
        cadre = cadre_code(texte.document(), curseur.anchor())
        if cadre is None:
            curseur.clearSelection()
        else:
            position = min(max(curseur.position(), cadre.firstCursorPosition().position()), cadre.lastCursorPosition().position())
            if position == curseur.position():
                return
            curseur.setPosition(position, QTextCursor.MoveMode.KeepAnchor)
        texte.setTextCursor(curseur)


def a_l_echelle(html):
    """Les tailles écrites en points dans le HTML (le code : 9 pt), comptées pour le corps de 10 pt du papier, à
    l'échelle du corps de l'écran."""
    return re.sub(r"font-size:(\d+(?:\.\d+)?)pt", lambda m: f"font-size:{float(m.group(1)) * TAILLE_POLICE / 10:g}pt", html)


INDENTATION_PAPIER = re.compile(r'<span style="color:transparent">(\$+)</span>')  # texte_md.indentation_visible


class MarkdownEcran(Markdown):
    """Une image se dit par son nom : ``Texte.loadResource`` la fournit, quand ses octets sont là (après la construction).
    L'indentation d'un bloc de code reste des espaces, que son ``<pre>`` préserve : les « $ » transparents du papier
    (pour le copier d'un lecteur de PDF) se verraient dans une sélection, et se copieraient."""

    def media(self, m):
        nom = m.group(2)
        return f'<img src="{nom}">' if nom.rsplit(".", 1)[-1].lower() in IMAGES else super().media(m)

    def code(self, *args, **kwargs):
        """Le fond du cadre sur sa case : Qt ne peint pas le ``bgcolor`` d'un tableau en ``border-collapse:collapse``,
        et le code prenait le fond du sujet. Blanc, un peu plus clair que la page (demande de l'utilisateur, 26/09/2026)."""
        html = INDENTATION_PAPIER.sub(lambda m: " " * len(m.group(1)), super().code(*args, **kwargs))
        return html.replace("<tr><td ", '<tr><td bgcolor="#ffffff" ', 1)


MD = MarkdownEcran({}, LARGEUR_MAX)


def fragments(document):
    """Les fragments de texte du document, dans l'ordre."""
    bloc = document.begin()
    while bloc.isValid():
        it = bloc.begin()
        while not it.atEnd():
            yield it.fragment()
            it += 1
        bloc = bloc.next()


OBJET_SVG, NOM_SVG = QTextFormat.UserObject + 1, QTextFormat.UserProperty + 1
POUCE = {"in": 1, "cm": 1 / 2.54, "mm": 1 / 25.4, "pt": 1 / 72, "pc": 1 / 6, "px": 1 / 96, "": 1 / 96}


def taille_svg(octets):
    """Largeur et hauteur, en pouces, que la racine d'un SVG déclare (``width="5.17in"``) : son pHYs à lui. Sans unité,
    des pixels d'écran. Absentes, on échoue : la taille d'affichage n'est écrite nulle part ailleurs."""
    racine = re.search(rb"<svg\b[^>]*>", octets).group(0)
    return [float(m.group(1)) * POUCE[m.group(2).decode()]
            for m in (re.search(rb'\s%s="([\d.]+)(\w*)"' % cote, racine) for cote in (b"width", b"height"))]


class ObjetSvg(QPyTextObject):  # QObject + QTextObjectInterface : la classe fournie par PySide, le double héritage n'y suffit pas
    """Les images des médias dessinées dans un QTextDocument par ce gestionnaire plutôt que par la ressource image de Qt :
    un SVG en vecteurs (net à toute échelle, à l'écran comme dans le PDF, là où une image serait rééchantillonnée), un PNG
    à pleine résolution réduit au dessin (net sur un écran HiDPI). Et la largeur d'affichage suit celle du texte : sur un
    téléphone, une figure large se réduit au lieu d'être coupée au bord (``intrinsicSize`` est redemandée à chaque
    changement de largeur du document). ``echelle`` : les unités du document par pouce de la taille déclarée dans le
    média (pixels à l'écran, points sur le papier), ``largeur_max`` la largeur d'affichage à ne pas dépasser."""

    def __init__(self, document, medias, echelle, largeur_max):
        super().__init__(document)  # vit tant que le document : la disposition ne retient pas son gestionnaire
        self.medias, self.echelle, self.largeur_max, self.rendus = medias, echelle, largeur_max, {}
        document.documentLayout().registerHandler(OBJET_SVG, self)

    def poser(self):
        """Après chaque ``setHtml`` : le HTML ne sait pas déclarer d'objet personnalisé, chaque ``<img>`` dont le nom est
        dans les médias est remplacé par l'objet que ce gestionnaire dessine."""
        document = self.parent()
        images = [(f.position(), f.charFormat().toImageFormat().name()) for f in fragments(document) if f.charFormat().isImageFormat()]
        for position, nom in reversed(images):  # de la fin : les positions restent justes
            if nom in self.medias:
                format_ = QTextCharFormat()
                format_.setObjectType(OBJET_SVG)
                format_.setProperty(NOM_SVG, nom)
                curseur = QTextCursor(document)
                curseur.setPosition(position)
                curseur.setPosition(position + 1, QTextCursor.MoveMode.KeepAnchor)
                curseur.insertText("\ufffc", format_)

    def rendu(self, nom):
        """Le SVG prêt à dessiner ou le PNG décodé, et sa taille en pouces : ce que déclare la racine du SVG, la résolution
        du PNG (``pHYs``, la taille dans le Word d'origine) ; sans elle, ses pixels comptent pour des unités du document."""
        if nom not in self.rendus:
            octets = self.medias[nom]
            if nom.lower().endswith(".svg"):
                # le texte d'un SVG prend la police du sujet (celle du document : le système à l'écran, Carlito sur le
                # papier), quelle que soit la famille écrite dans le fichier ; sa taille reste celle du fichier, en unités
                # de la figure, donc à l'échelle de la figure — demande de l'utilisateur, 24/09/2026
                famille = self.parent().defaultFont().family().encode()
                image = QSvgRenderer(QByteArray(re.sub(rb'font-family="[^"]*"', b'font-family="' + famille + b'"', octets)))
                largeur, hauteur = taille_svg(octets)
            else:
                image = QImage.fromData(octets)
                par_pouce = image.dotsPerMeterX() * 0.0254 if b"pHYs" in octets else self.echelle
                largeur, hauteur = image.width() / par_pouce, image.height() / par_pouce
            self.rendus[nom] = image, largeur, hauteur
        return self.rendus[nom]

    def intrinsicSize(self, document, position, format_):
        _, largeur, hauteur = self.rendu(format_.property(NOM_SVG))
        largeur_max = min(self.largeur_max, document.textWidth()) if document.textWidth() > 0 else self.largeur_max
        facteur = min(self.echelle, largeur_max / largeur)
        return QSizeF(largeur * facteur, hauteur * facteur)

    def drawObject(self, peintre, rect, document, position, format_):
        image = self.rendu(format_.property(NOM_SVG))[0]
        if isinstance(image, QSvgRenderer):
            image.render(peintre, rect)
        else:
            peintre.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            peintre.drawImage(rect, image)


class MenuCentre(QComboBox):
    """Un menu dont le mot choisi est centré : un champ en lecture seule dont le clic ouvre la liste."""

    def __init__(self):
        super().__init__()
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self.lineEdit().setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lineEdit().installEventFilter(self)
        self.view().window().installEventFilter(self)  # le cadre de la liste déroulée

    def eventFilter(self, objet, evenement):
        if objet is self.lineEdit() and evenement.type() == QEvent.Type.MouseButtonPress:
            self.showPopup()
            return True
        if (objet is self.view().window() and evenement.type() == QEvent.Type.MouseButtonRelease
                and not self.view().geometry().contains(evenement.position().toPoint())):
            # Le relâchement qui suit l'appui d'ouverture tombe sur le champ, hors de la liste : personne ne le prend, et
            # Qt-WASM (6.10, Firefox, souris comme doigt) referme alors la liste avant tout choix. Le consommer la garde
            # ouverte jusqu'au clic sur une ligne ou à côté ; sur le bureau, il était déjà sans effet.
            return True
        return super().eventFilter(objet, evenement)

    def addItems(self, textes):
        super().addItems(textes)
        for i in range(self.count()):
            self.setItemData(i, Qt.AlignmentFlag.AlignCenter, Qt.ItemDataRole.TextAlignmentRole)


class Texte(QTextBrowser):
    """Du Markdown, sans cadre ni ascenseur, à la hauteur de son contenu. ``cible`` : le bouton que son clic actionne."""

    clic = Signal(int, int)

    def __init__(self, markdown="", trou=None, inline=False, cible=None):
        super().__init__()
        self.cible = cible
        self.incrustes = {}  # nom d'ancre -> widget posé sur le texte, à la place de l'ancre
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setOpenLinks(False)
        self.setStyleSheet("QTextBrowser { background: transparent; }")
        self.document().setDocumentMargin(0)
        self.document().documentLayout().documentSizeChanged.connect(self._ajuster)  # QTextEdit garde la largeur du texte égale à la sienne
        self.svg = ObjetSvg(self.document(), MEDIAS, 96 * TAILLE_POLICE / 10, LARGEUR_MAX)  # même échelle que les PNG
        self.definir(markdown, trou, inline)

    def definir(self, markdown, trou=None, inline=False, coche=None):
        self.setHtml(a_l_echelle(MD.inline(markdown) if inline else MD.html(markdown, trou, coche=coche)))
        self.svg.poser()
        self.setHidden(not markdown)
        self._ajuster(self.document().size())

    def _ajuster(self, taille):
        self.setFixedHeight(int(taille.height()) + 2)
        self._placer()

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self._placer()

    def _placer(self):
        """Chaque widget incrusté se pose sur l'emplacement réservé par son ancre ``<a name=…>``."""
        for fragment in fragments(self.document()):
            for nom in fragment.charFormat().anchorNames():
                widget = self.incrustes.get(nom)
                if widget is not None:
                    curseur = QTextCursor(self.document())
                    curseur.setPosition(fragment.position())
                    rect = self.cursorRect(curseur)
                    widget.move(rect.left(), rect.top() + (rect.height() - widget.height()) // 2)
                    widget.show()

    def sizeHint(self):
        return QSize(400, int(self.document().size().height()) + 2)

    def loadResource(self, type_, url):
        if url.toString() in MEDIAS:
            return QImage()  # ``ObjetSvg.poser`` remplace l'image dès le HTML posé : rien à charger ici
        return super().loadResource(type_, url)

    def mousePressEvent(self, evenement):
        if self.cible is not None:
            self.cible.click()
        self.clic.emit(int(evenement.position().x()), int(evenement.position().y()))
        super().mousePressEvent(evenement)


def ligne(bouton, markdown):
    """Une case ou un bouton radio et son texte Markdown, dont le clic actionne le bouton."""
    widget = QWidget()
    disposition = QHBoxLayout(widget)
    disposition.setContentsMargins(0, 0, 0, 0)
    disposition.addWidget(bouton, 0, Qt.AlignmentFlag.AlignTop)
    texte = Texte(markdown, inline=True, cible=bouton)
    disposition.addWidget(texte, 1)

    def centrer():  # le bouton centre sa case : à la hauteur de la première ligne du texte, elle s'y aligne
        bouton.setFixedHeight(max(bouton.sizeHint().height(), texte.cursorRect(QTextCursor(texte.document())).height()))
    texte.document().documentLayout().documentSizeChanged.connect(centrer)
    centrer()
    return widget


def teinter(widgets, role, couleur):
    """``role`` de la palette à ``couleur`` pour tous les états : désactivé aussi, sinon Fusion grise la case sous le voile."""
    palette = QPalette()  # seul ``role`` est résolu : le reste s'hérite du parent. Pas ``w.palette()`` : une référence, où
    palette.setColor(role, couleur)  # shiboken retrouve parfois le wrapper d'une palette détruite (plantage des tests)
    for w in widgets:  # sans groupe : actif, inactif et désactivé
        w.setPalette(palette)


def decocher(boutons, groupe=None):
    if groupe:
        groupe.setExclusive(False)
    for b in boutons:
        b.setChecked(False)
    if groupe:
        groupe.setExclusive(True)


def hauteur(editeur, lignes):
    editeur.setMinimumHeight(lignes * editeur.fontMetrics().lineSpacing() + 16)
    return editeur


class Entete(Disposition):
    """L'entête du sujet : le titre, le visuel du thème s'il y en a un, et la colonne droite (barres, boutons) à côté
    du titre, ou DESSOUS quand les deux ne tiennent pas de front : à la largeur d'un téléphone, le titre coincé dans
    80 px se coupait en syllabes sur dix lignes et l'entête prenait le tiers de l'écran. De front tant que le titre garde
    la moitié de la largeur, ou toute sa largeur naturelle (``Titre.sizeHint``, sans retour à la ligne) : un critère qui
    ne dépend pas de la disposition en cours, donc pas d'oscillation, et qui laisse l'écran d'ordinateur comme avant (un
    long titre y passe sur deux lignes à côté de la colonne, plutôt que de la faire descendre)."""

    def __init__(self, titre, visuel, droite, espacement):
        super().__init__(espacement)
        self.addWidget(titre)
        if visuel is not None:
            self.addWidget(visuel)
            self.items[-1].setAlignment(Qt.AlignmentFlag.AlignCenter)  # au milieu du vide entre le titre et la colonne
        self.addChildLayout(droite)  # ``QLayout`` n'a pas d'``addLayout`` : c'est ce qu'il fait, en deux temps
        self.addItem(droite)
        self.titre, self.visuel, self.droite = self.items[0], self.items[1] if visuel is not None else None, droite

    def _disposer(self, rect, poser):
        e, x, y = self.spacing(), rect.x(), rect.y()
        l_titre, l_droite = self.titre.sizeHint().width(), self.droite.sizeHint().width()
        h_titre, h_droite = self.titre.sizeHint().height(), self.droite.sizeHint().height()
        l_visuel = self.visuel.sizeHint().width() + e if self.visuel is not None else 0
        reste = rect.width() - l_droite - e  # ce qui reviendrait au titre (visuel compris) de front
        de_front = reste >= min(l_titre + l_visuel, rect.width() // 2)
        if not de_front:
            reste = rect.width()
        ligne = max(h_titre, self.visuel.sizeHint().height() if self.visuel is not None else 0, h_droite if de_front else 0)
        if poser:
            self.titre.setGeometry(QRect(x, y, reste - l_visuel, ligne))
            if self.visuel is not None:  # entre la fin naturelle du titre et la colonne (ou le bord)
                debut = x + min(l_titre, reste - l_visuel) + e
                self.visuel.setGeometry(QRect(debut, y, x + reste - debut, ligne))
            if de_front:
                self.droite.setGeometry(QRect(x + rect.width() - l_droite, y, l_droite, ligne))
            else:
                self.droite.setGeometry(QRect(x, y + ligne + e, l_droite, h_droite))  # à sa largeur, au bord du titre
        return ligne if de_front else ligne + e + h_droite


# --- questions ------------------------------------------------------------------------------------------------

class Case(QCheckBox):
    """La case d'une action à faire, dessinée : un petit rond au contour épais, comme une puce, et un V vert qui le
    recouvre en le débordant une fois l'action faite (dessin choisi par l'utilisateur, 24/09/2026 : la case native,
    13 px bord gris pâle, se perdait sur le fond gris du lecteur)."""

    COTE = 20  # le widget ; le rond est plus petit, le V déborde du rond sans sortir du widget
    RAYON = 6

    def sizeHint(self):
        return QSize(self.COTE, self.COTE)

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        c, inactif = self.COTE, None if self.isEnabled() else "#9e9e9e"
        peintre.setPen(QPen(QColor(inactif or (GRIS_FAIT if self.isChecked() else "#37474f")), 2))  # gris comme son texte une fois faite
        peintre.setBrush(QColor("white"))
        peintre.drawEllipse(QPointF(c / 2, c / 2), self.RAYON, self.RAYON)
        if self.isChecked():
            peintre.setPen(QPen(QColor(inactif or "#43a047"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            # la pointe au centre du rond, pour qu'on lise un V et non un trait le long du bord (remarque du 24/09/2026)
            peintre.drawPolyline(QPolygonF([QPointF(c * 0.27, c * 0.4), QPointF(c * 0.5, c * 0.64), QPointF(c * 0.93, c * 0.08)]))


class Voile(QWidget):
    """Un gris un peu plus foncé que le fond, translucide, sur une question validée ou soumise : le fond fonce et le texte
    s'éclaircit d'un même geste. Il retient les clics (ignorés, ils remontent à la question, jamais aux champs dessous) ;
    la molette remonte de même jusqu'à la zone défilante."""

    def __init__(self, parent):
        super().__init__(parent)
        self.couleur = QColor()
        self.hide()

    def paintEvent(self, evenement):
        QPainter(self).fillRect(self.rect(), self.couleur)


class Question(noyau.Question, QWidget):
    """Le widget d'une question : l'énoncé, le corps propre à chaque type (``_corps``, ``_lire``/``_ecrire``), la
    justification, les indices et la barre de validation. La logique est celle de ``noyau.Question``."""

    changee = Signal()  # la question a changé d'état (soumise, validée, figée) : à enregistrer

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        self.entrees, self.voile = [], None
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)  # jamais plus haute que son contenu
        self.disposition = QVBoxLayout(self)
        self.disposition.setContentsMargins(0, 6, 0, 10)
        super().__init__(*args, **kw)

    def _montrer_enonce(self):
        texte = self.enonce_simplifie if self.reformulee and self.enonce_simplifie else self.enonce
        anciens = list(self.texte_enonce.incrustes.values())  # les cases de l'énoncé précédent
        for w in anciens:
            w.deleteLater()
        self.entrees = [w for w in self.entrees if w not in anciens]
        self.texte_enonce.incrustes.clear()
        self.cases = []
        self.texte_enonce.definir(f"**{self.marque}** {texte}" if self.marque else texte, coche=self._case if self.projet else None)
        if self.enonce_simplifie:
            self.bouton_reformuler.setText("Énoncé d'origine" if self.reformulee else "Reformuler")

    def _case(self):
        """La case à cocher d'une action (puce « - ») de l'énoncé d'un projet, à la place de sa puce : une liste de
        choses à faire, dont l'état, ``cochees``, s'enregistre avec la copie."""
        n = len(self.cases)
        case = Case(self.texte_enonce.viewport())
        case.setChecked(n in self.cochees)
        case.toggled.connect(self._cocher)
        case.hide()
        self.cases.append(case)
        self.texte_enonce.incrustes[f"coche{n}"] = case
        self.entrees.append(case)  # inactive comme la saisie : sous le voile, ou grisée avant que la question ne soit posée
        return cellule(f'<a name="coche{n}">&nbsp;</a>', Case.COTE + 6), n in self.cochees  # un blanc avant le texte

    def _cocher(self):
        self.cochees = [n for n, case in enumerate(self.cases) if case.isChecked()]
        self.changee.emit()
        self._montrer_enonce()  # le texte d'une action cochée se grise (demande de l'utilisateur, 24/09/2026)

    def avancement(self):
        """La part faite de la question, de 0 à 1 : tout dès qu'elle est validée ou soumise ; avant, dans un projet,
        la part de ses actions cochées (demande de l'utilisateur, 24/09/2026 : « prendre en compte ces cases cochées
        pour monitorer l'avancement »)."""
        if self.repondue or self.fermee:
            return 1
        return len(self.cochees) / len(self.cases) if self.cases else 0

    def numeroter(self, numero=None):
        """« Question n°x » à gauche, le barème à droite, au-dessus de l'énoncé."""
        super().numeroter(numero)
        self.rang.setText(f"<b>Question n°{numero}</b>" if numero else "")
        self.gris.setText(f"<small style='color:gray'>{points_txt(self.total())}</small>")

    def _construire(self):
        """L'énoncé, le corps, la barre de validation, puis la saisie et l'état de session relus (``noyau``)."""
        d = self.disposition
        self.rang, self.gris = QLabel(), QLabel()
        self.rang.setStyleSheet(f"font-size: {TAILLE_POLICE * 1.25:g}pt;")  # au-dessus du texte, en dessous du titre de section
        self.numeroter()
        tete = QHBoxLayout()
        tete.addWidget(self.rang)
        tete.addStretch()
        tete.addWidget(self.gris)
        d.addLayout(tete)
        self.texte_enonce = Texte()
        if self.enonce_simplifie:  # à droite de l'énoncé qu'il remplace, et non dans la barre du bas : un groupe n'en a pas
            self.bouton_reformuler = QPushButton()
            self.bouton_reformuler.clicked.connect(self.reformuler)
            ligne = QHBoxLayout()
            ligne.addWidget(self.texte_enonce, 1)
            ligne.addWidget(self.bouton_reformuler, 0, Qt.AlignmentFlag.AlignTop)
            d.addLayout(ligne)
        else:
            d.addWidget(self.texte_enonce)
        self._montrer_enonce()
        self._corps(d)
        if not self.sous_questions:
            if self.justification:
                d.addWidget(Texte(f"**Justification** ({points_txt(self.justification.points)}) : {self.justification.consigne}", inline=True))
                self.justif = hauteur(QPlainTextEdit(), 3)
                d.addWidget(self.justif)
                self.entrees.append(self.justif)
            self.zone_indices = QVBoxLayout()
            d.addLayout(self.zone_indices)
            barre = Rangee(d.spacing())
            self.bouton_aide, self.bouton_indice, self.bouton_soumettre, self.bouton_valider, self.bouton_modifier = (
                QPushButton("Aide (gratuite)"), QPushButton(), QPushButton("Soumettre"), QPushButton(), QPushButton("Modifier"))
            self.bouton_aide.setToolTip("Une piste pour démarrer, sans perdre de points.")
            for b in (self.bouton_valider, self.bouton_soumettre, self.bouton_modifier):
                barre.addWidget(b)
            barre.addStretch()  # l'aide et l'indice à l'écart des boutons qui rendent la copie
            barre.addWidget(self.bouton_aide)
            barre.addWidget(self.bouton_indice)
            d.addLayout(barre)
            self.barre = barre
            self.voile = Voile(self)  # tout ce qui est au-dessus de la barre : « Modifier » reste net et cliquable
            self.retour = Texte()
            d.addWidget(self.retour)
            self.bouton_soumettre.clicked.connect(self.soumettre)
            self.bouton_valider.clicked.connect(self.valider)
            self.bouton_modifier.clicked.connect(self.rouvrir)
            self.bouton_indice.clicked.connect(self.debloquer)
            self.bouton_aide.clicked.connect(self.aider)
            self.minuteur = QTimer(self)
            self.minuteur.timeout.connect(self.mettre_a_jour)
        boutons = [b for b in self.findChildren(QPushButton) if question(b) is self]  # pas ceux des sous-questions
        teinter(boutons, QPalette.ColorRole.Button, QApplication.palette().button().color().darker(104))  # à peine plus foncés
        super()._construire()

    def afficher_contexte(self, markdown):
        super().afficher_contexte(markdown)
        self.disposition.insertWidget(1, Texte(markdown))

    def _dire(self, markdown, couleur=""):
        super()._dire(markdown, couleur)
        self.retour.setStyleSheet("QTextBrowser { background: transparent; " + (f"color: {couleur};" if couleur else "") + " }")
        self.retour.definir(markdown, self._trou_corrige)

    def _montrer_indice(self, markdown, tete=False):
        self.zone_indices.insertWidget(0 if tete else -1, Texte(markdown))

    def _minuteur(self, marche):
        if marche:
            self.minuteur.start(1000)
        else:
            self.minuteur.stop()

    def montrer(self, visible):
        super().montrer(visible)
        self.setVisible(visible)

    @property
    def justifie(self):
        return self.justif.toPlainText() if self.justification else ""

    @justifie.setter
    def justifie(self, texte):
        if self.justification:
            self.justif.setPlainText(texte)

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        if self.voile:  # la disposition a déjà placé la barre : Qt la sert avant le widget
            self.voile.setGeometry(0, 0, self.width(), self.barre.geometry().top())
            self.voile.raise_()  # au-dessus des indices et contextes ajoutés depuis

    def mettre_a_jour(self):
        """Ce qui est actif, visible et écrit sur les boutons, selon l'état de la question."""
        ouvert = self.actif and not self.fermee
        libre = ouvert and not self.repondue
        niveau = 117 if self.fermee else 110 if self.repondue else 0  # voilée : un peu si validée, plus si soumise
        for w in self.entrees:
            w.setEnabled(libre)  # le voile retient la souris, pas le clavier
            estompe = not (libre or niveau)  # pas encore posée, ou figée : le voile ne la couvre pas
            if estompe != (w.graphicsEffect() is not None):  # grisé de façon visible, quel que soit le style Qt
                w.setGraphicsEffect(QGraphicsOpacityEffect(w, opacity=0.45) if estompe else None)
        if self.voile:
            self.voile.setVisible(bool(niveau))
            self.voile.couleur = fond_sujet().darker(niveau or 100)
            self.voile.couleur.setAlphaF(0.44)  # fond 251 → 241 (validée), 235 (soumise) ; texte noir → gris 100
            self.voile.update()
        self.bouton_soumettre.setVisible(ouvert)
        self.bouton_valider.setVisible(ouvert)
        self.bouton_valider.setText("Modifier" if self.repondue else "Marquer comme traitée")
        self.bouton_modifier.setVisible(self.actif and self.fermee and not self.seconde and self.modifiable)
        self.bouton_aide.setVisible(libre and bool(self.aide) and not self.aidee)
        attente = self.indice_delai()
        self.bouton_indice.setVisible(libre and attente is not None)
        if attente is not None:
            retire = round(self.indices[self.debloques].malus * self.points, 2)  # en points : un pourcentage se lit mal
            self.bouton_indice.setEnabled(not attente)
            self.bouton_indice.setText("Indice" + (f" : −{points_txt(retire)}" if retire else "") + (f" (dans {attente} s)" if attente else ""))
            self.bouton_indice.setToolTip(f"Voir cet indice retire {points_txt(retire)} sur {points_txt(self.points)}, même si la réponse est juste."
                                          if retire else "Cet indice ne retire aucun point.")


class Alternative(noyau.Alternative, Question):

    def _corps(self, d):
        self.boutons = [QRadioButton(libelle) for libelle in self.libelles]
        self.groupe = QButtonGroup(self)
        rangee = QHBoxLayout()
        for b in self.boutons:
            self.groupe.addButton(b)
            rangee.addWidget(b)
        rangee.addStretch()
        d.addLayout(rangee)
        teinter(self.boutons, QPalette.ColorRole.Base, QColor("white"))
        self.entrees += self.boutons

    def _lire(self):
        return None if not any(b.isChecked() for b in self.boutons) else self.boutons[0].isChecked()

    def _ecrire(self, valeur):
        decocher(self.boutons, self.groupe)
        if valeur is not None:
            self.boutons[0 if valeur else 1].setChecked(True)


class Choix(noyau.Choix, Question):

    def _corps(self, d):
        ordre = melange(range(len(self.propositions)), self.graine) if self.melanger else range(len(self.propositions))
        self.groupe = QButtonGroup(self) if self.EXCLUSIF else None
        boutons = {}
        for i in ordre:
            boutons[i] = QRadioButton() if self.EXCLUSIF else QCheckBox()
            if self.groupe:
                self.groupe.addButton(boutons[i])
            d.addWidget(ligne(boutons[i], self.propositions[i].texte))
        self.boutons = [boutons[i] for i in range(len(self.propositions))]
        teinter(self.boutons, QPalette.ColorRole.Base, QColor("white"))  # rond et carré blancs, même sous le voile
        self.entrees += self.boutons

    def _ecrire(self, valeur):
        decocher(self.boutons, self.groupe)
        for i in [] if valeur is None else [valeur] if isinstance(valeur, int) else valeur:
            self.boutons[i].setChecked(True)


class ChoixUnique(noyau.ChoixUnique, Choix):

    def _lire(self):
        return next(iter(self._cochees()), None)


class ChoixMultiples(noyau.ChoixMultiples, Choix):

    def _lire(self):
        return self._cochees() or None


class ReponseCourte(noyau.ReponseCourte, Question):

    def _corps(self, d):
        self.champ = QLineEdit()
        self.champ.returnPressed.connect(self.soumettre)
        d.addWidget(self.champ)
        self.entrees.append(self.champ)

    def _lire(self):
        return self.champ.text() or None

    def _ecrire(self, valeur):
        self.champ.setText(valeur or "")


class ReponseOuverte(noyau.ReponseOuverte, Question):

    def _corps(self, d):
        self.editeur = hauteur(QPlainTextEdit(), self.lignes)
        d.addWidget(self.editeur)
        self.entrees.append(self.editeur)

    def _lire(self):
        return self.editeur.toPlainText() or None

    def _ecrire(self, valeur):
        self.editeur.setPlainText(valeur or "")


def lire_champs(champs):
    """Ce qui est rempli dans un ensemble de champs, ``None`` si rien ne l'est."""
    saisie = {n: c.currentText() if isinstance(c, QComboBox) else c.text() for n, c in champs.items()}
    return {n: t for n, t in saisie.items() if t} or None


def ecrire_champs(champs, valeur):
    """Y reposer une saisie ; un champ absent de ``valeur`` est vidé."""
    for n, c in champs.items():
        texte = (valeur or {}).get(n, "")
        c.setCurrentText(texte) if isinstance(c, QComboBox) else c.setText(texte)


class TexteATrous(noyau.TexteATrous, Question):

    def _corps(self, d):
        self.champs = {}
        for n, trou in self.trous.items():
            liste = melange(trou.choix, f"{self.graine}|{n}") if trou.choix else melange(self.choix, self.graine) if self.choix else None
            if liste:
                self.champs[n] = MenuCentre()
                self.champs[n].addItems(["", *map(str, liste)])
            else:
                self.champs[n] = QLineEdit()
                self.champs[n].setFixedWidth(100)
        texte = Texte()
        # mesuré à la police du sujet, que la feuille de style du parent ne donnera au texte qu'à l'affichage : à la
        # police par défaut, l'ancre en espaces laissait un vide après le menu, et le menu coupait ses mots d'un « … »
        police = texte.font()
        police.setPointSizeF(TAILLE_POLICE)
        metrique = QFontMetrics(police)
        blanc = metrique.horizontalAdvance("\u00a0")
        for n, champ in self.champs.items():  # chaque champ prend la place d'une ancre, faite d'espaces insécables
            champ.setParent(texte.viewport())
            champ.setStyleSheet(f"QComboBox, QLineEdit {{ font-size: {TAILLE_POLICE}pt; padding: 0px 4px; margin: 0px; min-height: 0px;"
                                " border: 1px solid gray; border-radius: 3px; }"
                                "QComboBox::drop-down { width: 0px; border: none; } QComboBox::down-arrow { image: none; }")  # pas plus haut qu'une ligne
            largeur = (max(metrique.horizontalAdvance(champ.itemText(i)) for i in range(champ.count())) + 16
                       if isinstance(champ, QComboBox) else 100)
            champ.setFixedSize(largeur, metrique.height() - 2)
            champ.hide()
            texte.incrustes[f"trou{n}"] = champ
        texte.definir(self.texte, trou=lambda n: f'<a name="trou{n}">{"&nbsp;" * -(-self.champs[n].width() // blanc)}</a>')
        d.addWidget(texte)
        self.entrees += self.champs.values()

    def _lire(self):
        return lire_champs(self.champs)

    def _ecrire(self, valeur):
        ecrire_champs(self.champs, valeur)


MARGE_ENTETE = 4  # écrite une fois : la feuille de style l'applique, ``_ajuster`` la retranche pour mesurer le repli
STYLE_TABLEAU = (f"QTableWidget {{ gridline-color: {BORDURE_TABLEAU}; border: 1px solid {BORDURE_TABLEAU}; }}"
                 f"QHeaderView::section {{ background: {ENTETE_TABLEAU}; padding: {MARGE_ENTETE}px; border: 0;"
                 f" border-right: 1px solid {BORDURE_TABLEAU}; border-bottom: 1px solid {BORDURE_TABLEAU}; }}")
CASE_DONNEE = QColor("#f7f7f7")  # les cases fournies sont grisées : ce qui reste blanc dans la grille est ce qu'il y a à remplir


class CaseMarkdown(QStyledItemDelegate):
    """Peint le Markdown des cases DONNÉES, qu'un ``QTableWidgetItem`` ne sait afficher qu'en texte nu.

    Les cases à remplir sont laissées au rendu natif : c'est lui qui donne le champ blanc occupant toute la case."""

    def _document(self, index, largeur):
        document = QTextDocument()
        document.setDocumentMargin(4)
        document.setHtml(a_l_echelle(MD.inline(index.data() or "")))
        option = QTextOption(Qt.AlignmentFlag.AlignCenter)
        option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)  # une adresse « 192.168.1.0/24 » n'a pas d'espace où couper
        document.setDefaultTextOption(option)
        document.setTextWidth(largeur)  # sans largeur imposée, le texte long déborde sur la colonne voisine
        return document

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        if not index.flags() & Qt.ItemFlag.ItemIsEditable:
            option.text = ""  # le style ne dessine plus que le fond ; le texte, c'est ``paint`` qui s'en charge

    def paint(self, peintre, option, index):
        super().paint(peintre, option, index)
        if index.flags() & Qt.ItemFlag.ItemIsEditable:
            return
        document = self._document(index, option.rect.width())
        peintre.save()  # peindre le document à la main, c'est devoir recentrer soi-même ce que le style centrait
        peintre.translate(option.rect.topLeft()
                          + QPoint(0, max(0, int((option.rect.height() - document.size().height()) / 2))))
        document.drawContents(peintre)
        peintre.restore()

    def sizeHint(self, option, index):
        taille = self._document(index, self.parent().columnWidth(index.column())).size()
        return QSize(int(taille.width()), int(taille.height()))


class Tableau(noyau.Tableau, Question):

    def _corps(self, d):
        """La grille est un ``QTableWidget`` : c'est lui qui donne la case blanche entièrement éditable, la navigation
        au clavier et les colonnes étirées, sans rien en réécrire. ``champs`` retient ce qui porte la saisie — la case
        elle-même quand elle se tape, le menu quand elle se choisit — et ``lire_champs`` les lit indifféremment."""
        self.champs = {}
        self.table = QTableWidget(len(self.lignes), len(self.colonnes))
        self.table.setHorizontalHeaderLabels(self.colonnes)
        self.table.verticalHeader().hide()
        entete = self.table.horizontalHeader()
        entete.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        police = entete.font()
        police.setBold(True)  # le gras est posé ici, et non dans la feuille de style : ``_ajuster`` mesure ainsi la police réellement peinte
        entete.setFont(police)
        entete.setDefaultAlignment(Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap)  # sans ce drapeau, un en-tête trop long est coupé net
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.AllEditTriggers)  # un clic suffit : pas de double-clic à deviner
        self.table.setItemDelegate(CaseMarkdown(self.table))
        self.table.setStyleSheet(STYLE_TABLEAU)
        for r, ligne_ in enumerate(self.lignes):
            for c, cellule in enumerate(ligne_):
                reference = f"{r},{c}"
                trou = self.cellules.get(reference)
                case = QTableWidgetItem("" if trou else cellule)
                case.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if trou is None:
                    case.setFlags(case.flags() & ~Qt.ItemFlag.ItemIsEditable)
                    case.setBackground(CASE_DONNEE)
                self.table.setItem(r, c, case)
                if trou is None:
                    continue
                liste = (melange(trou.choix, f"{self.graine}|{reference}") if trou.choix
                         else melange(self.choix, self.graine) if self.choix else None)
                if liste:
                    self.champs[reference] = MenuCentre()
                    self.champs[reference].addItems(["", *map(str, liste)])
                    self.table.setCellWidget(r, c, self.champs[reference])
                else:
                    self.champs[reference] = case
        self.hauteurs = QTimer(self.table, singleShot=True)  # les colonnes ne sont à leur largeur définitive qu'une fois la mise en page retombée
        self.hauteurs.timeout.connect(self._ajuster)
        self.table.horizontalHeader().sectionResized.connect(lambda *_: self.hauteurs.start(0))
        d.addWidget(self.table)
        self.entrees.append(self.table)

    def _ajuster(self):
        """Les colonnes étant étirées, la hauteur qu'il faut à une case dépend de la largeur qu'on vient de lui donner :
        elle se recalcule à chaque redimensionnement, sinon un texte passé à la ligne est coupé. L'en-tête n'a pas de
        délégué qui le mesure pour lui : sa hauteur se calcule à la main, à la police même qu'il peint."""
        entete = self.table.horizontalHeader()
        metriques = entete.fontMetrics()
        replie = max(metriques.boundingRect(QRect(0, 0, self.table.columnWidth(c) - 2 * MARGE_ENTETE, 0),
                                            Qt.TextFlag.TextWordWrap, str(titre)).height()
                     for c, titre in enumerate(self.colonnes))
        entete.setFixedHeight(replie + entete.sizeHint().height() - metriques.height())  # + ce que le style ajoute autour d'une ligne
        self.table.resizeRowsToContents()
        self.table.setFixedHeight(entete.height() + 2
                                  + sum(self.table.rowHeight(r) for r in range(self.table.rowCount())))

    def _lire(self):
        return lire_champs(self.champs)

    def _ecrire(self, valeur):
        ecrire_champs(self.champs, valeur)


class Ordre(noyau.Ordre, Question):

    def _corps(self, d):
        if self.langage:
            d.addWidget(Texte("*Glissez les lignes dans le bon ordre, et indentez-les en les glissant vers la droite ou par Tab / "
                              "Maj+Tab (Ctrl+Z annule) ; le texte, lui, ne se modifie pas.*", inline=True))
            self.editeur = EditeurLignes([code_nu(e) for e in self.elements], self.depart, [0] * len(self.elements))
            if self.executable:
                self.console = ConsoleCode(self.editeur, self)  # la console porte l'éditeur, entre ses boutons et sa sortie
                d.addWidget(self.console)
                self.entrees.append(self.console)
            else:
                d.addWidget(self.editeur)
            self.entrees.append(self.editeur)
            return
        # les étiquettes d'un classement : même police que l'énoncé, un élément long va à la ligne, et la hauteur
        # se recalcule à la largeur réelle — mesurée avant l'affichage, elle coupait les derniers éléments
        self.liste = etiquettes(lambda: self.liste.setFixedHeight(hauteur_etiquettes(self.liste, map(code_nu, self.elements))))
        self.liste.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self._ecrire(None)
        d.addWidget(Texte("*Glissez les éléments dans le bon ordre.*", inline=True))
        d.addWidget(self.liste)
        self.entrees.append(self.liste)

    def _lire(self):
        if self.langage:
            ordre, niveaux = list(self.editeur.ordre), list(self.editeur.niveaux)
            return None if ordre == self.depart and not any(niveaux) else {"ordre": ordre, "niveaux": niveaux}
        ordre = [self.liste.item(k).data(Qt.ItemDataRole.UserRole) for k in range(self.liste.count())]
        return None if ordre == self.depart else ordre

    def _ecrire(self, valeur):
        if self.langage:  # une liste (le corrigé, une ancienne copie) se montre avec la bonne indentation
            if valeur is None:
                self.editeur.ranger(self.depart, [0] * len(self.elements))
            elif isinstance(valeur, dict):
                self.editeur.ranger(valeur["ordre"], valeur["niveaux"])
            else:
                self.editeur.ranger(valeur)
            return
        self.liste.clear()
        for i in self.depart if valeur is None else valeur:
            element = QListWidgetItem(code_nu(self.elements[i]))  # une liste n'affiche pas le Markdown : les accents graves s'y verraient
            element.setData(Qt.ItemDataRole.UserRole, i)
            self.liste.addItem(element)


GOUTTIERE = 140  # la colonne où se tracent les liens d'un appariement, entre les deux rangées de puces, en pixels
RAYON_PUCE = 6  # rayon d'une puce d'appariement, en pixels


class Liens(QWidget):
    """La gouttière d'un ``Appariement``, comme sur le papier : une puce au bout de chaque élément, de chaque côté, et
    les traits qui les relient. On tire un trait d'une puce vers une puce d'en face, dans un sens ou dans l'autre, ou
    l'on clique l'une puis l'autre (la puce ou son texte). Retirer un trait de sa puce de gauche et le lâcher dans le
    vide le défait. ``liens`` : pour chaque élément de gauche, la position de son élément à droite, ou ``None``."""

    def __init__(self, gauches, droites):
        super().__init__()
        self.gauches, self.droites = gauches, droites  # les textes, qui donnent la hauteur de chaque puce
        self.liens = [None] * len(gauches)
        self.origine = None  # (côté, rang) de la puce d'où part le trait en cours, ou celle cliquée en attente de l'autre
        self.souris = None  # où suit le trait en cours ; ``None`` une fois la puce seulement cliquée
        self.setFixedWidth(GOUTTIERE)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Ignored)  # la hauteur est celle des rangées de texte
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def _puce(self, cote, rang):
        texte = (self.gauches if cote == 0 else self.droites)[rang]
        y = texte.geometry().center().y() - self.geometry().top()
        return QPointF(RAYON_PUCE + 2 if cote == 0 else self.width() - RAYON_PUCE - 2, y)

    def _visee(self, position):
        """La puce la plus proche en hauteur, du côté de la gouttière où est la souris."""
        cote = 0 if position.x() < self.width() / 2 else 1
        textes = self.gauches if cote == 0 else self.droites
        return cote, min(range(len(textes)), key=lambda r: abs(self._puce(cote, r).y() - position.y()))

    def viser(self, cible):
        """Une puce cliquée (ou son texte) : la relie à celle qui attendait en face, ou attend à son tour."""
        if not self.isEnabled():
            return
        if self.origine is not None and self.origine[0] != cible[0]:
            self._relier(self.origine, cible)
            self.origine = None
        else:
            self.origine = None if self.origine == cible else cible
        self.update()

    def _relier(self, a, b):
        gauche, droite = (a, b) if a[0] == 0 else (b, a)
        self.liens[gauche[1]] = droite[1]

    def mousePressEvent(self, evenement):
        cible = self._visee(evenement.position())
        if self.origine is not None and self.origine[0] != cible[0]:
            self.viser(cible)
            return
        self.origine, self.souris = cible, evenement.position()
        self.update()

    def mouseMoveEvent(self, evenement):
        if self.origine is not None and self.souris is not None:
            self.souris = evenement.position()
            self.update()

    def mouseReleaseEvent(self, evenement):
        if self.origine is None or self.souris is None:
            return
        cible = self._visee(evenement.position())
        depart = self._puce(*self.origine)
        if cible[0] != self.origine[0]:
            self._relier(self.origine, cible)
            self.origine = None
        elif (evenement.position() - depart).manhattanLength() > 2 * RAYON_PUCE:  # lâché ailleurs que sur une puce d'en face
            if self.origine[0] == 0:
                self.liens[self.origine[1]] = None
            self.origine = None
        # sinon, un simple clic : la puce attend celle d'en face
        self.souris = None
        self.update()

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        trait = self.palette().highlight().color()
        tire = self.origine if self.souris is not None else None  # le lien d'une puce qu'on retire suit la souris
        peintre.setPen(QPen(trait, 2))
        for g, d in enumerate(self.liens):
            if d is not None and tire != (0, g):
                peintre.drawLine(self._puce(0, g), self._puce(1, d))
        if tire is not None:
            peintre.setPen(QPen(trait, 2, Qt.PenStyle.DashLine))
            peintre.drawLine(self._puce(*tire), self.souris)
        relies = {(0, g) for g, d in enumerate(self.liens) if d is not None} | {(1, d) for d in self.liens if d is not None}
        for cote, textes in enumerate((self.gauches, self.droites)):
            for rang in range(len(textes)):
                puce = (cote, rang)
                peintre.setPen(QPen(trait if puce == self.origine else self.palette().text().color(), 2 if puce == self.origine else 1))
                peintre.setBrush(trait if puce in relies or puce == self.origine else self.palette().base().color())
                peintre.drawEllipse(self._puce(cote, rang), RAYON_PUCE, RAYON_PUCE)


class Appariement(noyau.Appariement, Question):

    def _corps(self, d):
        """Deux colonnes de textes et, entre elles, la gouttière où l'élève relie les puces, comme sur la copie papier."""
        droites = [p.droite for p in self.paires] + self.distracteurs
        self.ordre = melange(range(len(droites)), self.graine)  # position affichée -> indice dans droites
        gauches = [Texte(p.gauche, inline=True) for p in self.paires]
        for texte in gauches:  # alignés sur leurs puces, comme sur papier
            texte.document().setDefaultTextOption(QTextOption(Qt.AlignmentFlag.AlignRight))
        droites = [Texte(droites[i], inline=True) for i in self.ordre]
        self.toile = Liens(gauches, droites)
        grille = QGridLayout()
        grille.setVerticalSpacing(10)
        for cote, textes in enumerate((gauches, droites)):
            for rang, texte in enumerate(textes):
                texte.clic.connect(functools.partial(lambda puce, *_: self.toile.viser(puce), (cote, rang)))
                grille.addWidget(texte, rang, 2 * cote)
        grille.addWidget(self.toile, 0, 1, max(len(gauches), len(droites)), 1)
        grille.setColumnStretch(0, 1)
        grille.setColumnStretch(2, 1)
        d.addWidget(Texte("*Reliez chaque élément de gauche à un élément de droite : tirez un trait d'une puce à l'autre, "
                          "ou cliquez l'une puis l'autre. Pour défaire un lien, tirez-le depuis sa puce de gauche et lâchez-le "
                          "dans le vide.*", inline=True))
        d.addLayout(grille)
        self.entrees.append(self.toile)

    def _lire(self):
        choix = [None if p is None else self.ordre[p] for p in self.toile.liens]
        return None if all(i is None for i in choix) else choix

    def _ecrire(self, valeur):
        self.toile.liens = [None if valeur is None or valeur[g] is None else self.ordre.index(valeur[g]) for g in range(len(self.paires))]
        self.toile.origine = self.toile.souris = None
        self.toile.update()


class PointSelection(noyau.PointSelection, Question):

    def _corps(self, d):
        self.point = None
        self.vue = Texte(f"![]({self.image})")
        self.vue.clic.connect(self._cliquer)
        self.croix = QLabel("✚", self.vue.viewport())
        self.croix.setStyleSheet("color: red; font-weight: bold; background: transparent;")
        self.croix.hide()
        d.addWidget(Texte("*Cliquez sur l'image.*", inline=True))
        d.addWidget(self.vue)
        self.entrees.append(self.vue)

    def _echelle(self):
        image = QImage.fromData(MEDIAS[self.image]) if self.image in MEDIAS else None
        return min(1, LARGEUR_MAX / image.width()) if image and image.width() else 1

    def _cliquer(self, x, y):
        if self.vue.isEnabled():
            self._ecrire([round(x / self._echelle()), round(y / self._echelle())])

    def _lire(self):
        return self.point

    def _ecrire(self, valeur):
        self.point = valeur
        self.croix.setVisible(valeur is not None)
        if valeur is not None:
            self.croix.move(int(valeur[0] * self._echelle()) - 6, int(valeur[1] * self._echelle()) - 9)


RAYON = 22  # rayon d'un sommet du type ``dessin``, en pixels
ECART = 7   # décalage d'une arête orientée sur sa droite, pour que A→B et B→A ne se superposent pas
VISEE = 10  # distance à une arête en deçà de laquelle un clic la vise, en pixels
TOILE_MINIMUM = 240  # en deçà, une toile ne se réduit plus : ses sommets ne seraient plus visables au doigt
TENU = 2 * (RAYON - 3)  # largeur de nom qu'un cercle peut contenir : au-delà, le nom s'écrit dessous


class ToileGraphe(QWidget):
    """La zone de dessin d'une question ``dessin`` : l'élève tire un trait d'un sommet à l'autre pour créer une
    arête, clique une arête puis Suppr pour l'effacer. Les sommets, eux, sont ceux du sujet et ne bougent pas."""

    def __init__(self, question):
        super().__init__()
        self.question, self.aretes = question, []
        self.depart, self.souris, self.choisie = None, None, None
        self._fond = ...  # chargé au premier dessin : MEDIAS n'est rempli qu'après la construction des questions
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        metriques = self.fontMetrics()
        deborde = [s for s in question.sommets if metriques.horizontalAdvance(str(s.nom)) > TENU]
        cote = max([metriques.horizontalAdvance(str(s.nom)) / 2 + 3 for s in deborde] + [RAYON])
        largeur = max([s.x for s in question.sommets] or [0]) + RAYON + cote
        hauteur = max([s.y for s in question.sommets] or [0]) + 2 * RAYON + (metriques.height() if deborde else 0)
        # La taille naturelle, celle des coordonnées du sujet ; plus étroite (un téléphone), la toile se dessine à
        # l'échelle et la souris est ramenée dans ces coordonnées (``_echelle``) : la figure du bac NSI 2026, 504 px,
        # imposait un ascenseur horizontal à tout le sujet sous 540 px.
        self.naturelle = QSize(int(largeur), int(hauteur))
        largeur_mini = min(self.naturelle.width(), TOILE_MINIMUM)
        self.setMinimumSize(largeur_mini, self.heightForWidth(largeur_mini))
        politique = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        politique.setHeightForWidth(True)
        self.setSizePolicy(politique)

    def sizeHint(self):
        return self.naturelle

    def heightForWidth(self, largeur):
        return math.ceil(self.naturelle.height() * min(1, largeur / self.naturelle.width()))

    def _echelle(self):
        return min(1, self.width() / self.naturelle.width())

    def fond(self):
        if self._fond is ...:
            self._fond = QImage.fromData(MEDIAS[self.question.image]) if self.question.image in MEDIAS else None
        return self._fond

    # -- géométrie

    def _sommet(self, nom):
        return next((s for s in self.question.sommets if s.nom == nom), None)

    def _sous(self, position):
        """Le nom du sommet sous ce point, s'il y en a un."""
        return next((s.nom for s in self.question.sommets
                     if (s.x - position.x()) ** 2 + (s.y - position.y()) ** 2 <= RAYON ** 2), None)

    def _trait(self, arete):
        """Les deux bouts du trait dessiné, de bord à bord, décalés sur la droite si le graphe est orienté."""
        depart, arrivee = self._sommet(arete[0]), self._sommet(arete[1])
        dx, dy = arrivee.x - depart.x, arrivee.y - depart.y
        longueur = math.hypot(dx, dy) or 1
        ux, uy = dx / longueur, dy / longueur
        ecart = ECART if self.question.oriente else 0
        return (QPointF(depart.x + ux * RAYON - uy * ecart, depart.y + uy * RAYON + ux * ecart),
                QPointF(arrivee.x - ux * RAYON - uy * ecart, arrivee.y - uy * RAYON + ux * ecart))

    def _milieu(self, arete):
        a, b = self._trait(arete)
        return QPointF((a.x() + b.x()) / 2, (a.y() + b.y()) / 2)

    def _distance(self, arete, position):
        """La distance de ce point au trait de l'arête, sur toute sa longueur."""
        a, b = self._trait(arete)
        dx, dy = b.x() - a.x(), b.y() - a.y()
        t = ((position.x() - a.x()) * dx + (position.y() - a.y()) * dy) / (dx * dx + dy * dy or 1)
        t = min(1, max(0, t))  # le point du trait le plus proche, sans dépasser ses bouts
        return math.hypot(a.x() + t * dx - position.x(), a.y() + t * dy - position.y())

    def _visee(self, position):
        """L'arête la plus proche de ce point, s'il en est à portée : n'importe où le long du trait, pas seulement
        en son milieu (viser le milieu à 14 px près était trop dur, demande de l'utilisateur, 24/09/2026)."""
        proches = [(self._distance(arete, position), i) for i, arete in enumerate(self.aretes)]
        distance, i = min(proches, default=(None, None))
        return i if distance is not None and distance <= VISEE else None

    # -- dessin

    def paintEvent(self, _):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.scale(self._echelle(), self._echelle())
        if self.fond() is not None:
            peintre.drawImage(0, 0, self.fond())
        for donnee in self.question.decor:  # sous le tracé de l'élève, qui surligne donc ce qu'il choisit
            self._peindre_arete(peintre, (donnee.source, donnee.cible, donnee.etiquette), QColor("#b0bec5"))
        for i, arete in enumerate(self.aretes):
            if i == self.choisie:  # l'arête choisie, que Suppr effacera : en bleu, et un halo pour qu'on la voie de loin
                peintre.setPen(QPen(QColor(30, 136, 229, 70), 10, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                peintre.drawLine(*self._trait(arete))
            self._peindre_arete(peintre, arete, QColor("#1e88e5") if i == self.choisie else QColor("#37474f"))
        if self.depart is not None and self.souris is not None:
            peintre.setPen(QPen(QColor("#9e9e9e"), 2, Qt.PenStyle.DashLine))
            sommet = self._sommet(self.depart)
            peintre.drawLine(QPointF(sommet.x, sommet.y), self.souris)
        for sommet in self.question.sommets:
            self._peindre_sommet(peintre, sommet)

    def _peindre_sommet(self, peintre, sommet):
        peintre.setPen(QPen(QColor("#37474f"), 2))
        peintre.setBrush(QColor("#ffffff"))
        centre = QPointF(sommet.x, sommet.y)
        peintre.drawEllipse(centre, RAYON, RAYON)
        if sommet.marque == "final":  # l'état acceptant d'un automate : le double cercle
            peintre.drawEllipse(centre, RAYON - 4, RAYON - 4)
        if sommet.marque == "initial":
            peintre.drawLine(QPointF(sommet.x - 2 * RAYON, sommet.y), QPointF(sommet.x - RAYON, sommet.y))
        nom = str(sommet.nom)
        largeur = peintre.fontMetrics().horizontalAdvance(nom)
        if largeur <= TENU:
            cadre = QRect(int(sommet.x - RAYON), int(sommet.y - RAYON), 2 * RAYON, 2 * RAYON)
        else:  # un nom trop long pour son cercle s'écrit dessous : « Internet » y serait coupé net
            cadre = QRect(int(sommet.x - largeur / 2 - 3), int(sommet.y + RAYON),
                          int(largeur) + 6, peintre.fontMetrics().height())
        peintre.drawText(cadre, int(Qt.AlignmentFlag.AlignCenter), nom)

    def _peindre_arete(self, peintre, arete, couleur):
        peintre.setPen(QPen(couleur, 2))
        peintre.setBrush(couleur)
        a, b = self._trait(arete)
        peintre.drawLine(a, b)
        if self.question.oriente:
            angle = math.atan2(b.y() - a.y(), b.x() - a.x())
            pointe = [b] + [QPointF(b.x() - 12 * math.cos(angle + c), b.y() - 12 * math.sin(angle + c))
                            for c in (0.4, -0.4)]
            peintre.drawPolygon(QPolygonF(pointe))
        if arete[2]:
            milieu = self._milieu(arete)
            peintre.setPen(QPen(couleur, 1))
            peintre.setBrush(QColor("#ffffff"))
            largeur = peintre.fontMetrics().horizontalAdvance(str(arete[2])) + 8
            peintre.drawRect(int(milieu.x() - largeur / 2), int(milieu.y() - 9), largeur, 18)
            peintre.drawText(int(milieu.x() - largeur / 2), int(milieu.y() - 9), largeur, 18,
                             int(Qt.AlignmentFlag.AlignCenter), str(arete[2]))

    # -- la souris

    def mousePressEvent(self, evenement):
        if not self.isEnabled():
            return
        position = evenement.position() / self._echelle()
        self.depart, self.souris = self._sous(position), position
        self.choisie = None if self.depart is not None else self._visee(position)
        self.update()

    def mouseMoveEvent(self, evenement):
        self.souris = evenement.position() / self._echelle()
        if self.depart is not None:
            self.update()

    def mouseReleaseEvent(self, evenement):
        if not self.isEnabled() or self.depart is None:
            return
        depart, self.depart = self.depart, None
        arrivee = self._sous(evenement.position() / self._echelle())
        if arrivee is not None and arrivee != depart:  # jamais de boucle : un clic sur un sommet, sans glisser, en
            # posait une, dessinée en rond au-dessus du sommet (vu par l'utilisateur, 24/09/2026)
            if self.question.etiquettes:
                self._etiqueter(depart, arrivee, evenement.position().toPoint())
            else:
                self.ajouter([depart, arrivee, ""])
        self.update()

    def _etiqueter(self, depart, arrivee, position):
        """L'étiquette de l'arête qu'on vient de tracer : un menu des étiquettes du sujet, qui ajoute l'arête au choix
        (``popup``, pas ``exec`` : le navigateur n'a pas de boucle imbriquée) ; refermé sans choix, rien n'est tracé."""
        menu = QMenu(self)
        menu.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        actions = {menu.addAction(str(e)): str(e) for e in self.question.etiquettes}
        menu.triggered.connect(lambda action: self.ajouter([depart, arrivee, actions[action]]))
        menu.popup(self.mapToGlobal(position))

    def ajouter(self, arete):
        if self.question.cle(*arete) not in [self.question.cle(*a) for a in self.aretes]:
            self.aretes.append(list(arete))
            self.update()

    def keyPressEvent(self, evenement):
        if self.choisie is not None and evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            del self.aretes[self.choisie]
            self.choisie = None
            self.update()
        else:
            super().keyPressEvent(evenement)


class Dessin(noyau.Dessin, Question):

    def _corps(self, d):
        self.toile = ToileGraphe(self)
        d.addWidget(Texte("*Tirez un trait d'un sommet à l'autre pour tracer une arête ; cliquez une arête, puis "
                          "Suppr pour l'effacer.*", inline=True))
        d.addWidget(self.toile)
        self.entrees.append(self.toile)

    def _lire(self):
        return [list(a) for a in self.toile.aretes] or None

    def _ecrire(self, valeur):
        self.toile.aretes = [list(a) for a in (valeur or [])]
        self.toile.choisie = None
        self.toile.update()


class Code(noyau.Code, Question):

    def _corps(self, d):
        self.editeur = hauteur(EditeurCode(self.code_initial), self.lignes)
        if self.langage in ("python", "sql"):
            self.console = ConsoleCode(self.editeur, self)  # la console porte l'éditeur, entre ses boutons et sa sortie
            d.addWidget(self.console)
            self.entrees.append(self.console)
        else:
            d.addWidget(self.editeur)
        self.entrees.append(self.editeur)

    def _lire(self):
        return self.editeur.toPlainText() if self.editeur.toPlainText() != self.code_initial else None

    def _ecrire(self, valeur):
        self.editeur.setPlainText(self.code_initial if valeur is None else valeur)

    if qtpy6web.navigateur():  # pas de sous-processus : la correction tourne dans un Web Worker, AVANT la soumission
        verdicts = {}  # id -> {saisie, fraction, message}, ce que _verifier rend

        def _verifier(self, saisie):
            v = self.verdicts.get(self.id)
            return (v["fraction"], v["message"]) if v is not None and v["saisie"] == saisie else (None, None)

        def soumettre(self):
            """Sans verdict pour cette saisie, la question attend, grisée, que le worker l'ait corrigée, puis se soumet
            comme en natif ; sans test, ou déjà corrigée, rien à attendre. Une question figée avant le verdict (temps
            écoulé) reste « en attente » : le professeur la corrige."""
            saisie, suite = self.saisie, super().soumettre
            if self.fermee or not self.actif or self.epreuve() is None or self._verifier(saisie) != (None, None):
                return suite()

            def verdict(fraction, message):
                self.verdicts[self.id] = {"saisie": saisie, "fraction": fraction, "message": message}
                self._corrections.pop((saisie, self.classe), None)
                self.setEnabled(True)
                suite()

            self.setEnabled(False)
            self._dire("*Vérification en cours…*")
            processus_web.verificateur().verifier({**self.epreuve(), "source": self.code_initial if saisie is None else saisie}, verdict)


class Sql(noyau.Sql, Code):
    pass


class Etiquette(QStyledItemDelegate):
    """Hauteur d'une étiquette de ``Classement`` calculée sur la largeur RÉELLE de sa colonne : celle que
    ``QListView`` estime avec ``setWordWrap`` ne suit pas le rétrécissement de la colonne, et l'étiquette longue
    finissait coupée d'un « … » au lieu d'aller à la ligne."""

    def sizeHint(self, option, index):
        return self.taille(option.fontMetrics, index.data())

    def taille(self, metrique, texte):
        largeur = self.parent().viewport().width() - 2 * self.parent().spacing() - 8
        return QSize(largeur, metrique.boundingRect(QRect(0, 0, largeur, 10000), Qt.TextFlag.TextWordWrap, texte).height() + 2 * qtpy6web.tactile.marge() + 4)


class Colonne(QListWidget):
    """Une liste d'étiquettes (colonne d'un ``Classement``, liste d'un ``Ordre``) : sa largeur change la hauteur de ses
    étiquettes, donc la sienne."""

    def __init__(self, ajuster):
        super().__init__()
        self.ajuster = ajuster

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.ajuster()


def etiquettes(ajuster):
    """Une ``Colonne`` d'étiquettes à glisser, qui vont à la ligne plutôt que d'être coupées."""
    liste = Colonne(ajuster)
    liste.setDefaultDropAction(Qt.DropAction.MoveAction)
    liste.setWordWrap(True)
    liste.setSpacing(2)  # des étiquettes séparées, pas des lignes ; la marge d'une feuille de style, elle, fausserait le retour à la ligne
    liste.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    liste.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # la hauteur tient tout ; une barre rétrécirait le texte, qui passerait à la ligne et déborderait
    liste.setResizeMode(QListWidget.ResizeMode.Adjust)  # recalcule les hauteurs quand la colonne change de largeur
    liste.setItemDelegate(Etiquette(liste))
    # ``::item`` retire le fond de sélection, mais pas le texte blanc qui va avec : une étiquette sélectionnée
    # (celle qu'on vient de glisser) devenait illisible. Elle garde son texte, liseré bleu.
    liste.setStyleSheet(f"QListWidget::item {{ border: 1px solid #b0b0b0; border-radius: 4px; padding: {qtpy6web.tactile.marge()}px 0; }}"
                        "QListWidget::item:selected { color: palette(text); border-color: palette(highlight); }")
    return liste


def hauteur_etiquettes(liste, textes):
    """La hauteur qui tient toutes ces étiquettes, sans vide dessous, à la largeur actuelle de ``liste``."""
    etiquette, metrique, marge = liste.itemDelegate(), liste.fontMetrics(), liste.spacing()
    return sum(etiquette.taille(metrique, t).height() + 2 * marge for t in textes) + 2 * liste.frameWidth()  # l'espacement, dessus et dessous


class Classement(noyau.Classement, Question):

    def _corps(self, d):
        """Un tableau comme sur papier : une colonne par catégorie, où glisser les étiquettes depuis la réserve
        « À classer », à gauche. Chaque colonne est une liste qui peut contenir tous les éléments : on dépose
        aussi dans une colonne vide, et un double-clic renvoie l'étiquette à la réserve."""
        grille = QGridLayout()
        self.colonnes = []  # la réserve, puis les catégories dans l'ordre de ``categories``
        for k, titre in enumerate(["À classer", *self.categories]):
            grille.addWidget(Texte(f"*{titre}*" if k == 0 else f"**{titre}**", inline=True), 0, k)
            liste = etiquettes(self._ajuster)
            liste.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
            if k:
                liste.itemDoubleClicked.connect(functools.partial(self._rendre, liste))
            grille.addWidget(liste, 1, k)
            grille.setColumnStretch(k, 1)
            self.colonnes.append(liste)
        d.addWidget(Texte("*Glissez chaque élément dans sa colonne (double-clic : il revient dans « À classer »).*", inline=True))
        d.addLayout(grille)
        self.entrees += self.colonnes
        self._ecrire(None)

    def _ajuster(self):
        """Toutes les colonnes à la hauteur de la réserve pleine : de quoi tenir tous les éléments, sans vide dessous.
        Les colonnes ont la même largeur, donc chaque étiquette la même hauteur dans n'importe laquelle."""
        reserve = self.colonnes[0] if len(self.colonnes) == len(self.categories) + 1 else None
        if reserve is None:
            return  # colonnes en cours de création
        hauteur = hauteur_etiquettes(reserve, (code_nu(e.texte) for e in self.elements))
        for liste in self.colonnes:
            liste.setFixedHeight(hauteur)

    def _rendre(self, liste, element):
        self.colonnes[0].addItem(liste.takeItem(liste.row(element)))

    def _lire(self):
        choix = [None] * len(self.elements)
        for k, liste in enumerate(self.colonnes[1:]):
            for rang in range(liste.count()):
                choix[liste.item(rang).data(Qt.ItemDataRole.UserRole)] = k
        return None if all(c is None for c in choix) else choix

    def _ecrire(self, valeur):
        for liste in self.colonnes:
            liste.clear()
        for i in self.depart:
            element = QListWidgetItem(code_nu(self.elements[i].texte))
            element.setData(Qt.ItemDataRole.UserRole, i)
            self.colonnes[0 if valeur is None or valeur[i] is None else valeur[i] + 1].addItem(element)


class Personnalise(noyau.Personnalise, Question):
    """Le widget écrit par le professeur (voir ``noyau.Personnalise``) : son code est exécuté ici, avec pour noms de
    départ ceux de ce module (les classes Qt, ``Texte``, ``hauteur``…)."""

    def _corps(self, d):
        self.message = Texte()
        self.message.setStyleSheet("QTextBrowser { background: transparent; color: #c0392b; }")
        d.addWidget(self.message)
        try:
            espace = dict(globals())
            exec(compile(self.widget, f"<widget {self.id}>", "exec"), espace)  # noqa: S102 - c'est le principe : le code du professeur
            absentes = [nom for nom in ("corps", "lire", "ecrire", "corriger") if not callable(espace.get(nom))]
            if absentes:
                raise NameError("fonctions absentes : " + ", ".join(absentes))
            self.fonctions = espace
        except Exception as exc:  # noqa: BLE001 - n'importe quelle erreur du code du professeur
            self._casser("widget", exc)
            return
        self._appeler("corps", None, d)

    def _casser(self, quoi, exc):
        super()._casser(quoi, exc)
        self.message.definir(f"**Question en panne** : {self.panne}\n\nSignalez-la : elle sera corrigée à la main.")

    def _lire(self):
        return self._appeler("lire", None)

    def _ecrire(self, valeur):
        self._appeler("ecrire", None, valeur)


class Groupe(noyau.Groupe, Question):

    def _corps(self, d):
        for sq in self.sous_questions:
            d.addWidget(sq)

    def numeroter(self, numero=None):
        """Le barème d'une sous-question entre parenthèses : le détail du total, pas des points en plus."""
        super().numeroter(numero)
        for sq in self.sous_questions:
            sq.gris.setText(f"<small style='color:gray'>({points_txt(sq.total())})</small>")


class Banque(noyau.Banque, QWidget):
    """Affichée, la banque montre ses questions corrigées."""

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)
        self.corrigee = False
        d = QVBoxLayout(self)
        d.addWidget(Texte(f"# {self.matiere}\n\n{self.niveau} {self.theme}".rstrip()))
        d.addWidget(defilant(self.questions))
        self.resize(900, 800)

    def showEvent(self, evenement):
        """Affichée, la banque montre ses questions corrigées (une seule fois : ce n'est pas son état enregistré)."""
        if not self.corrigee:
            self.corrigee = True
            for q in self.questions:
                q.presenter_corrige()
        super().showEvent(evenement)


def defilant(widgets):
    """Une zone défilante qui empile ``widgets``."""
    zone, contenu = QScrollArea(), QWidget()
    zone.setWidgetResizable(True)
    # par la feuille de style, pas par setFont : un widget qui a la sienne (Texte, listes, tableaux) n'hérite pas
    # de la police de son parent ; la taille seule, la famille et le gras de chacun restent les siens
    contenu.setStyleSheet(f"QWidget {{ font-size: {TAILLE_POLICE}pt; }}")
    empile = QVBoxLayout(contenu)
    for w in widgets:
        empile.addWidget(w)
    empile.addStretch()
    zone.setWidget(contenu)
    qtpy6web.tactile.defiler_au_doigt(zone)  # au doigt, la page défile comme partout ailleurs sur un téléphone
    contenu.setAutoFillBackground(False)  # setWidget l'active, et la feuille de style lui rend le gris de la fenêtre
    return zone


def encadre(markdown):
    """Les consignes du sujet dans le cadre vert des cours du professeur (fond et bordure relevés dans « Les réseaux
    sociaux.docx ») : en tête de la zone qui défile, elles s'effacent de la vue dès que l'élève descend aux questions."""
    cadre = QFrame(objectName="consignes")
    cadre.setStyleSheet("QFrame#consignes { background: #eefae6; border: 1px solid #6b934e; }")
    d = QVBoxLayout(cadre)
    d.setContentsMargins(10, 8, 10, 8)
    d.addWidget(Texte(markdown))
    return cadre


class Section(noyau.Section, QWidget):

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)
        d = QVBoxLayout(self)
        if self.titre:
            d.addWidget(Texte(f"## {self.titre}"))
        if self.consignes:
            d.addWidget(Texte(self.consignes))
        for q in self.questions:
            if isinstance(q, Question):
                d.addWidget(q)


COULEURS = {"vert": "#92d050", "bleu": "#00b0f0", "rouge": "#ff0000", "or": "#ffc000"}


class Titre(Texte):
    """L'entête du sujet, qui demande la largeur de son texte sans retour à la ligne : le vide à côté commence là où il
    finit. Mesurée à chaque mise en page, pas une fois : la police définitive n'arrive qu'à l'affichage de la fenêtre."""

    def sizeHint(self):
        naturel = self.document().clone()  # le document de ``self`` est coupé à la largeur courante du widget
        naturel.setTextWidth(-1)
        return QSize(math.ceil(naturel.idealWidth()) + 2, super().sizeHint().height())


def barre(intitule, couleur):
    """Une barre de progression de 0 à 100 %, son intitulé écrit dedans : ce qu'elle mesure se lit sans légende."""
    b = QProgressBar()
    b.setRange(0, 100)
    b.setFormat(intitule)
    b.setAlignment(Qt.AlignmentFlag.AlignCenter)
    b.setFixedHeight(22)
    colorer(b, couleur)
    return b


def colorer(barre, couleur):
    """Remplit ``barre`` de la couleur nommée ; sans effet si c'est déjà la sienne (le chronomètre appelle chaque seconde)."""
    if barre.property("couleur") != couleur:
        barre.setProperty("couleur", couleur)
        barre.setStyleSheet("QProgressBar { border: 1px solid #a0a0a0; border-radius: 4px; background: #f2f2f2; color: #707070; font-style: italic; }"
                            f"QProgressBar::chunk {{ background: {COULEURS[couleur]}; border-radius: 3px; }}")


class Paquet(noyau.Paquet, QWidget):
    """Le widget du paquet : une entête (titre, barres, TOUS les boutons globaux, bilan) et le sujet, défilant sur toute
    la largeur, ou une question par écran. La logique est celle de ``noyau.Paquet``."""

    finie = Signal()  # l'épreuve vient de se terminer (bouton, fin du temps) : la copie est à enregistrer

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)

    def _construire(self):
        palette = self.palette()
        palette.setColor(self.backgroundRole(), fond_sujet())
        self.setPalette(palette)
        self.setAutoFillBackground(True)
        # Deux parties : une entête (titre, barres, TOUS les boutons globaux, bilan) et le sujet, défilant sur toute la largeur.
        d = QVBoxLayout(self)
        d.setContentsMargins(0, 0, 0, 0)
        d.setSpacing(0)
        # Titre à gauche, barres à droite ; dessous, la navigation à gauche et ce qui termine à droite, sous les barres.
        bandeau = QWidget()  # l'entête a son propre fond, celui de la barre de titre
        palette = bandeau.palette()
        fond_entete(palette)
        bandeau.setPalette(palette)
        bandeau.setAutoFillBackground(True)
        entete = QVBoxLayout(bandeau)
        entete.setContentsMargins(9, 9, 9, 9)
        entete.setSpacing(6)  # sans quoi les dispositions imbriquées héritent du 0 de ``d`` : boutons collés
        titre = Titre(self.entete())
        bloc = titre.document().begin()
        while bloc.isValid():  # le sous-titre sous le titre, pas à la distance qui sépare deux paragraphes
            format_ = bloc.blockFormat()
            if format_.headingLevel() in (1, 2):
                format_.setBottomMargin(0) if format_.headingLevel() == 1 else format_.setTopMargin(4)
                QTextCursor(bloc).setBlockFormat(format_)
            bloc = bloc.next()
        visuel = None
        if LOGO in self.medias:  # le visuel du thème, centré dans le vide entre le titre et la colonne droite
            visuel = QLabel()
            visuel.setPixmap(QPixmap.fromImage(QImage.fromData(self.medias[LOGO])).scaledToHeight(
                HAUTEUR_VISUEL, Qt.TransformationMode.SmoothTransformation))
        # La colonne droite : l'état de l'épreuve, ce qui la termine, puis la navigation.
        self.barre_temps, self.barre_avancement = barre("temps écoulé", "bleu"), barre("avancement réponses", "vert")
        self.barre_bonus = barre("bonus", "or") if self.feuilles_bonus else None
        avancement = QHBoxLayout()
        avancement.setSpacing(4)
        for b in (self.barre_avancement, self.barre_bonus) if self.feuilles_bonus else (self.barre_avancement,):
            avancement.addWidget(b)
        droite = QVBoxLayout()
        droite.addWidget(self.barre_temps)
        droite.addLayout(avancement)
        fin = QHBoxLayout()
        fin.setSpacing(6)
        # Deux gestes nommés par leur conséquence, et seulement ceux qui ont un sens dans CE sujet (demande de
        # l'utilisateur, 25/09/2026 : « Soumettre toutes les questions » et « Terminer » ne se distinguaient pas, et le
        # premier ne servait à rien sans seconde chance, le cas d'une évaluation sommative).
        self.bouton_tout = QPushButton("Corriger mes réponses")
        self.bouton_tout.setToolTip("Corrige toutes les questions encore ouvertes sans terminer l'épreuve : une réponse fausse "
                                    "peut être reprise, à points réduits, tant qu'il reste du temps.")
        self.bouton_tout.clicked.connect(lambda: self.soumettre_tout())  # sans le lambda, le « checked » du clic vaudrait confirmer
        self.bouton_tout.setVisible(self.rejouable())
        fin.addWidget(self.bouton_tout)
        self.bouton_terminer = QPushButton("Rendre ma copie")
        self.bouton_terminer.setToolTip("Fin de l'épreuve : les questions encore ouvertes sont figées telles quelles, sans reprise possible"
                                        + (", puis la note et la correction s'affichent." if self.correction else "."))
        police = self.bouton_terminer.font()
        police.setBold(True)  # le seul bouton sans retour : il se distingue des autres
        self.bouton_terminer.setFont(police)
        self.bouton_terminer.clicked.connect(lambda: self.rendre())
        fin.addWidget(self.bouton_terminer)
        droite.addLayout(fin)
        navigation = QHBoxLayout()
        navigation.setSpacing(6)
        navigation.addStretch()
        self.precedent, self.suivant = QPushButton("Précédent"), QPushButton("Suivant")
        self.prec_libre, self.suiv_libre = QPushButton("◀ Non traitée"), QPushButton("Non traitée ▶")
        self.precedent.clicked.connect(lambda: self.aller(self.courante - 1))
        self.suivant.clicked.connect(lambda: self.aller(self.courante + 1))
        self.prec_libre.clicked.connect(lambda: self.sauter(-1))
        self.suiv_libre.clicked.connect(lambda: self.sauter(1))
        for b in (self.precedent, self.suivant) if self.affichage == "question" else ():
            navigation.addWidget(b)
        if self.affichage == "question":
            navigation.addSpacing(18)  # deux groupes : l'écran voisin, puis la question voisine encore à traiter
        navigation.addWidget(self.prec_libre)
        navigation.addWidget(self.suiv_libre)
        droite.addLayout(navigation)
        droite.addStretch()
        largeur = self.bouton_tout.sizeHint().width() + fin.spacing() + self.bouton_terminer.sizeHint().width()
        self.barre_temps.setFixedWidth(largeur)  # une colonne droite : l'état de l'épreuve au-dessus de ce qui la termine
        if self.feuilles_bonus:  # la même largeur en deux, au prorata des questions, sans que « bonus » cesse d'être lisible
            partie = max(round((largeur - 4) * len(self.feuilles_bonus) / len(self.feuilles)), 60)
            self.barre_avancement.setFixedWidth(largeur - 4 - partie)
            self.barre_bonus.setFixedWidth(partie)
        else:
            self.barre_avancement.setFixedWidth(largeur)
        entete.addLayout(Entete(titre, visuel, droite, entete.spacing()))
        self.bilan = Texte()
        entete.addWidget(self.bilan)
        d.addWidget(bandeau)
        trait = QFrame()
        trait.setFrameShape(QFrame.Shape.HLine)
        trait.setFrameShadow(QFrame.Shadow.Sunken)
        d.addWidget(trait)
        if self.affichage == "question":
            self.pile = QStackedWidget()
            for n, q in enumerate(self.pages):  # les consignes, sur le premier écran seulement
                page = defilant([encadre(self.consignes), q] if self.consignes and n == 0 else [q])
                page.setFrameShape(QFrame.Shape.NoFrame)
                self.pile.addWidget(page)
            self.pile.setCurrentIndex(min(self.courante, len(self.pages) - 1))
            d.addWidget(self.pile, 1)
        else:
            self.defilement = defilant([encadre(self.consignes), *self.sections] if self.consignes else self.sections)
            self.defilement.setFrameShape(QFrame.Shape.NoFrame)
            d.addWidget(self.defilement, 1)
            self.descente = QPropertyAnimation(self.defilement.verticalScrollBar(), b"value", self, duration=DESCENTE_MS,
                                               easingCurve=QEasingCurve.Type.OutCubic)
            self.attente = QTimer(self, singleShot=True, timeout=self._descendre)
        self.resize(900, 800)
        super()._construire()

    def _afficher_page(self, n):
        self.pile.setCurrentIndex(n)

    def _suite(self, feuille):
        """La question qui vient d'être traitée reste un instant sous les yeux, grisée, avant que la vue ne glisse vers
        la suivante : un saut immédiat la faisait disparaître sans que l'élève comprenne où elle était passée."""
        if self.affichage != "sujet":
            return super()._suite(feuille)
        self.attente.stop()  # tout changement annule la descente en attente : « Modifier » pendant la pause la retient
        self.descente.stop()
        super()._suite(feuille)
        if self.attente.isActive():  # une descente vient d'être demandée : elle attend la fin de la pause
            self.attente.start(PAUSE_MS)

    def _defiler(self, n):
        self.cible = n  # au prochain tour, la mise en page retombée ; _suite y ajoute la pause
        self.descente.stop()
        self.attente.start(0)

    def _descendre(self):
        zone = self.defilement
        self.descente.setStartValue(zone.verticalScrollBar().value())
        self.descente.setEndValue(self.unites[self.cible].mapTo(zone.widget(), QPoint(0, 0)).y())
        self.descente.start()

    def _rafraichir_vue(self):
        for b, feuilles in ((self.barre_avancement, [f for f in self.feuilles if f not in self.feuilles_bonus]), (self.barre_bonus, self.feuilles_bonus)):
            if feuilles:
                b.setValue(round(100 * sum(f.avancement() for f in feuilles) / len(feuilles)))
        self.bouton_tout.setEnabled(self.demarre and self.fin is None and not all(f.fermee for f in self.feuilles))
        if self.affichage == "question":
            self.precedent.setVisible(self.retour)
            self.precedent.setEnabled(self.courante > 0)
            self.suivant.setEnabled(self.courante < len(self.pages) - 1)
        self.prec_libre.setVisible(self.retour)
        self.prec_libre.setEnabled(self._voisine(-1) is not None)
        self.suiv_libre.setEnabled(self._voisine(1) is not None)

    def _confirmer(self):
        """L'élève confirme dans une boîte NON bloquante (le navigateur n'a pas de boucle imbriquée) : c'est elle qui
        soumet, sans redemander ; ici on répond toujours non, ``soumettre_tout`` s'arrête là en attendant son clic."""
        self._demander("Corriger mes réponses",
                       "Toutes les questions encore ouvertes vont être corrigées. L'épreuve continue : une réponse "
                       "fausse pourra être reprise, à points réduits, tant qu'il reste du temps.\n\nContinuer ?",
                       lambda: self.soumettre_tout(confirmer=False))
        return False

    def _demander(self, titre, texte, oui):
        boite = QMessageBox(QMessageBox.Icon.Question, titre, texte, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, self)
        boite.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        boite.accepted.connect(oui)
        boite.open()

    def bilan_rendu(self):
        """Ce que rendre la copie maintenant coûte, chiffré : les questions ni traitées ni soumises (corrigées telles
        quelles) et les secondes chances ouvertes mais non jouées (perdues) ; vide si tout est traité ou soumis."""
        ouvertes = [f for f in self.feuilles if not f.fermee]
        lignes = [(len([f for f in ouvertes if not (f.repondue or f.seconde)]), "Questions ni traitées ni soumises, corrigées telles quelles : "),
                  (len([f for f in ouvertes if f.seconde]), "Secondes chances non jouées, perdues : ")]
        return "\n".join(f"{texte}{n}" for n, texte in lignes if n)

    def rendre(self, confirmer=True):
        """Le bouton « Rendre ma copie » : ``terminer``, après avoir dit ce qui sera figé. La fin du temps, elle, ne demande rien."""
        if confirmer:
            self._demander("Rendre ma copie", (self.bilan_rendu() or "Toutes les questions sont traitées ou soumises.")
                           + "\n\nRendre la copie ? Plus rien ne pourra être modifié ensuite.", self.terminer)
            return
        self.terminer()

    def _montrer_fin(self):
        super()._montrer_fin()
        for b in (self.precedent, self.suivant, self.prec_libre, self.suiv_libre):
            b.hide()
        self.bouton_tout.setEnabled(False)
        self.bouton_terminer.hide()
        self.finie.emit()
        if self.correction:
            obtenus, corriges, attente = self.resultat()
            self.bilan.definir(f"**Note : {obtenus:g} / {corriges:g}**" + (f" — et {attente:g} points à faire corriger par le professeur."
                                                                             if attente else ""))
        else:
            self.bilan.definir("**Épreuve terminée.**")
