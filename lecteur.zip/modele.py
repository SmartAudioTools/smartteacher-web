"""Le modèle objet de QCM/ : banques, questions, sujets et paquets élèves, en classes Python (voir README.md).

Chaque classe se lit et s'écrit en JSON par serializejson : le fichier est un JSON plat où ``"__class__"`` nomme la
classe, les valeurs par défaut du ``__init__`` étant omises. Un parseur tiers qui ignore ``__class__`` retrouve
l'arbre de dictionnaires. Au chargement, ``__init__`` est rappelé avec les champs du fichier : un champ inconnu ou
manquant est une ``TypeError``, jamais un champ ignoré.

Le type d'une question est sa classe (``ChoixUnique``…), et ``type`` en donne le nom historique (``"choix_unique"``).
Ne restent des dictionnaires que les clés qui sont des DONNÉES : ``contextes``, ``medias``, ``variables``,
``competences_livret``, ``trous``.

Tout ce qui contient des questions est un widget Qt (qtpy6, PySide6) : les dix-huit types, ``Section``, ``Paquet`` et
``Banque``. Une même classe sert donc à la banque du professeur, au paquet livré et au rendu de l'élève, à des états
différents : ``charger(fichier).show()`` affiche n'importe lequel. Seul ``DefinitionSujet`` reste une donnée pure.
La réponse de l'élève est le champ ``saisie`` (``reponse`` est, pour une alternative, la bonne réponse) : une property
branchée sur les widgets de saisie, que ``Objet.__serializejson__`` écrit avec les autres champs, si bien que
l'enregistrement du fichier suffit à conserver la session (réponses, indices débloqués, seconde chance, fin).
Le paquet livré à l'élève contient les questions COMPLÈTES : c'est son chiffrement (``mot_de_passe``) qui les protège.
"""

import configparser
import contextlib
import functools
import html
import itertools
import math
import os
import re
import tempfile
import time
import weakref
from pathlib import Path

import adresse
import noyau
import pyxel_studio
from noyau import (ILLISIBLE, LOGO, MEDIAS, POLICE_MAIN, SCHEMA_DEMANDES, TROP, Sommet, code_nu, copier, dire, melange,
                   points_txt, serializejson)
# Ré-exportés : des importeurs les prennent dans modele (sujet.py, valider.py, tests_modele.py…), pas dans noyau.
from noyau import (Arete, Attribut, Cercle, DefinitionSujet, Element, Erreur, Indice, Justification,  # noqa: F401
                   Maillon, Objet, Paire, Pose, Proposition, Rapport, Rectangle, Reference, Relation, SecondeChance, Test,
                   Trou, au_choix, en_capitales, ordonner, parametres, quotient, revelees)
from qtpy6.QtCore import (QBuffer, QByteArray, QCoreApplication, QEasingCurve, QEvent, QMargins, QObject, QPoint, QPointF,
                          QPropertyAnimation, QRect, QRectF, QSize, QSizeF, Qt, QTimer, QUrl, Signal)
from qtpy6.QtGui import (QAbstractTextDocumentLayout, QColor, QCursor, QFont, QFontInfo, QFontMetrics, QFontMetricsF, QIcon, QImage, QKeySequence, QPainter, QPainterPath, QPalette,
                         QPen, QPixmap, QPolygonF, QPyTextObject, QRegion, QTextBlockFormat, QTextCharFormat, QTextCursor, QTextDocument, QTextFormat,
                         QTextOption)
from qtpy6 import paresse, peinture
from qtpy6.QtSvg import QSvgRenderer
from qtpy6.web import application as application_web, navigateur, tactile
from qtpy6.web.dispositions import Rangee
from qtpy6.web.defilement import ZoneDefilante
from qtpy6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog,
                             QDialogButtonBox, QFrame,
                             QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                             QListWidget, QListWidgetItem, QMenu, QMessageBox, QPlainTextEdit, QProgressBar,
                             QProxyStyle, QPushButton, QRadioButton, QScrollArea, QScrollBar, QSizePolicy, QSplitter, QStackedWidget, QStyle, QStyledItemDelegate, QStyleOptionButton, QStyleOptionComboBox,
                             QTableWidget, QTableWidgetItem, QTabWidget, QTextBrowser, QToolButton, QVBoxLayout, QWidget)

from console_code import ConsoleCode, intitule
from editeur_code import PAS, EditeurCode, EditeurLignes
from texte_md import BORDURE_TABLEAU, CADRE_CODE, ENTETE_TABLEAU, GRIS_FAIT, LARGEUR_COCHE, MONO, VERT_REPONSE, Markdown, cellule

IMAGES = {"png", "jpg", "jpeg", "gif", "webp", "svg"}
LARGEUR_MAX = 900  # largeur d'affichage maximale d'une image, en pixels
HAUTEUR_VISUEL = 90  # le visuel du thème dans l'entête du sujet, en pixels
TAILLE_POLICE = 12  # le texte du sujet, en points : les 16 px d'un navigateur, là où la police du système en donne 13
ECHELLE_MEDIAS = 96 * TAILLE_POLICE / 10  # pixels par pouce de la taille déclarée d'un média : 10 pt sur papier = le corps de l'écran
TAILLE_MAIN = TAILLE_POLICE + 2  # POLICE_MAIN (Kalam), pour la correction : ses lettres basses (x-height) sont plus
# petites qu'à corps égal (mesuré par QFontMetrics hors écran : Kalam à 12 pt vaut 8,4, la police du sujet 8,6). 13 pt
# (8,9) paraissait encore petit à côté du texte : 14 pt (10,0), partout à l'écran (demandes de l'utilisateur, 27 et 28/09/2026)
VIOLET_REFORMULER = "#8e44ad"  # le lien « (reformuler) »
PAUSE_MS, DESCENTE_MS = 700, 450  # la question soumise reste un instant sous les yeux, puis la vue se recale dessus


def charger(chemin, mot_de_passe=None):
    """L'objet (Banque, DefinitionSujet, Paquet…) écrit dans le fichier, chiffré ou non."""
    application()
    mode = adresse.MODE
    objet = serializejson.load(str(chemin), authorized_classes=list(serializejson.constructors), encryption_key=mot_de_passe)
    if isinstance(objet, Paquet) and objet.adresse != mode:  # ses widgets ont été bâtis à l'adresse d'avant : refaits à la sienne
        objet = serializejson.load(str(chemin), authorized_classes=list(serializejson.constructors), encryption_key=mot_de_passe)
    if isinstance(objet, DefinitionSujet) and objet.parties:  # un sujet composé : ses parties compilées en sections plates
        objet = composer(objet, Path(chemin))
    return objet


def sauver(objet, chemin, mot_de_passe=None):
    """Écrit l'objet ; chiffré (age, scrypt) si ``mot_de_passe`` : le coût de scrypt n'est payé qu'une fois par processus."""
    # dans le navigateur, la copie se range (localStorage) et s'envoie (Dropbox) en texte : l'armure ASCII d'age (base64) ;
    # ailleurs le binaire, d'un tiers plus court
    if isinstance(objet, DefinitionSujet) and getattr(objet, "composition", None):  # un sujet composé : réécrit tel qu'il a été lu
        reglages = {k: v for k, v in objet.__serializejson__()[2].items() if k not in ("banques", "sections")}
        objet = DefinitionSujet(**reglages, parties=objet.composition)
    serializejson.dump(objet, str(chemin), bytes_compression=None, index=None, sort_keys=False, single_line_list_numbers=False,
                       encryption_key=mot_de_passe, encryption_in_base64=navigateur())
    serializejson.wait_writes()


# --- les sujets composés d'autres sujets (``DefinitionSujet.parties``, 09/10/2026) ---------------------------------------

SUJETS = Path(__file__).parent / "sujets"  # là où ``depuis`` cherche les sujets dont une partie est faite (``sujet.SUJETS``)
_EN_COMPOSITION: list[Path] = []  # les sujets en cours de composition : un sujet qui se cite lui-même, même de loin, bouclerait


def _points_partie(p: float) -> str:
    return f"{p:g}".replace(".", ",") + (" points" if p >= 2 else " point")


def composer(definition: DefinitionSujet, chemin: Path) -> DefinitionSujet:
    """Le sujet composé ``definition`` (lu dans ``chemin``) compilé en sujet plat : les sections de chaque partie copiées de
    son sujet ``depuis`` (toutes, ou celles de ``sections``, par titre et dans cet ordre), ``partie`` posé sur la première
    (« Partie 1 : Conversions de nombres (20 points) ») et effacé des autres ; les banques des sujets cités, réunies et
    rendues relatives au sujet composé. ``points`` impose le total d'une partie : les points des questions de ses sections
    hors bonus sont alors mis à l'échelle, arrondis au quart de point (au moins un quart), le reste de l'arrondi sur la
    dernière ; un groupe garde les siens (ils sont ceux de ses sous-questions). Sans ``points``, ceux du sujet cité.
    Exports, lecteur et validation ne voient que la forme plate ; ``composition`` garde les parties pour ``sauver``, qui
    réécrit le fichier tel qu'il a été lu, et ``compilation`` dit où commence chacune (``valider``)."""
    chemin = chemin.resolve()
    if definition.banques or definition.sections:
        raise ValueError(f"{chemin.name} : « parties » remplace « banques » et « sections », pas les deux")
    if chemin in _EN_COMPOSITION:
        raise ValueError(f"{chemin.name} : se cite lui-même par ses parties ({' → '.join(c.name for c in _EN_COMPOSITION)})")
    _EN_COMPOSITION.append(chemin)
    try:
        banques, sections, compilation, vues, totaux_de = [], [], [], set(), {}
        for n, partie in enumerate(definition.parties, 1):
            if not isinstance(partie, dict) or "depuis" not in partie or set(partie) - {"depuis", "sections", "points", "titre"}:
                raise ValueError(f"{chemin.name} : partie {n} : clés depuis (obligatoire), sections, points, titre")
            origine = (SUJETS / partie["depuis"]).resolve()
            source = charger(origine)
            if not isinstance(source, DefinitionSujet):
                raise ValueError(f"{chemin.name} : partie {n} : {partie['depuis']} n'est pas un sujet")
            choisies = source.sections
            if "sections" in partie:
                par_titre = {s.titre: s for s in source.sections}
                if manquantes := [t for t in partie["sections"] if t not in par_titre]:
                    raise ValueError(f"{chemin.name} : partie {n} : section(s) absente(s) de {partie['depuis']} : {manquantes}")
                choisies = [par_titre[t] for t in partie["sections"]]
            if not choisies:
                raise ValueError(f"{chemin.name} : partie {n} : aucune section")
            totaux = {}  # id -> (points de la banque, groupe ?)
            for banque in source.banques:
                if isinstance(banque, str):
                    absolue = (origine.parent / banque).resolve()
                    if absolue not in totaux_de:
                        totaux_de[absolue] = {q.id: (q.total(), bool(q.sous_questions)) for q in charger(absolue).questions}
                    totaux.update(totaux_de[absolue])
                    if absolue not in vues:
                        vues.add(absolue)
                        banques.append(os.path.relpath(absolue, chemin.parent))
                else:  # un sujet figé cité : sa banque embarquée
                    totaux.update({q.id: (q.total(), bool(q.sous_questions)) for q in banque.questions})
                    banques.append(copier(banque))
            copies = [copier(s, sauf=("partie",)) for s in choisies]
            posees = [(s, j, ref.id if isinstance(ref, Reference) else ref, ref)
                      for s in copies if not s.bonus for j, ref in enumerate(s.questions)]
            if inconnues := [qid for _, _, qid, _ in posees if qid not in totaux]:
                raise ValueError(f"{chemin.name} : partie {n} : absentes des banques de {partie['depuis']} : {inconnues}")
            valeur = {qid: ref.points if isinstance(ref, Reference) else totaux[qid][0] for _, _, qid, ref in posees}
            total = sum(valeur.values())
            cible = partie.get("points", total)
            if cible != total:
                ajustables = [(s, j, qid) for s, j, qid, _ in posees if not totaux[qid][1]]
                fixe = sum(valeur[qid] for _, _, qid, _ in posees if totaux[qid][1])
                base = sum(valeur[qid] for _, _, qid in ajustables)
                if not base or cible - fixe < 0.25 * len(ajustables):
                    raise ValueError(f"{chemin.name} : partie {n} : {total:g} points dans {partie['depuis']}, "
                                     f"impossibles à ramener à {cible:g} (dont {fixe:g} de groupes, fixes)")
                nouveaux = [max(0.25, round(valeur[qid] * (cible - fixe) / base * 4) / 4) for _, _, qid in ajustables]
                nouveaux[-1] += cible - fixe - sum(nouveaux)
                if nouveaux[-1] <= 0:
                    raise ValueError(f"{chemin.name} : partie {n} : {cible:g} points trop peu pour ses {len(ajustables)} questions")
                for (s, j, qid), p in zip(ajustables, nouveaux):
                    s.questions[j] = qid if p == totaux[qid][0] else Reference(qid, p)
            intitule = (partie.get("titre") or source.sous_titre.split("\n")[0] or source.theme or source.titre).strip()
            copies[0].partie = f"Partie {n} : {intitule} ({_points_partie(cible)})"
            compilation.append({"depuis": partie["depuis"], "debut": len(sections), "nombre": len(copies),
                                "points": partie.get("points")})
            sections += copies
    finally:
        _EN_COMPOSITION.pop()
    definition.banques, definition.sections = banques, sections
    definition.composition, definition.parties, definition.compilation = definition.parties, None, compilation
    return definition


def figer(definition: DefinitionSujet) -> DefinitionSujet:
    """Le sujet composé (ou non) en sujet plat, qui ne cite plus ses parties : ``sauver(figer(charger(a)), b)`` écrit en
    ``b`` un sujet ordinaire, qui ne bougera plus quand les sujets cités changeront."""
    return copier(definition)



# --- l'écran : une application, du texte Markdown, des lignes cochables ------------------------------------------


def application():
    """La QApplication du processus, créée au besoin (``qtpy6.web.application`` : hors session graphique, sans fenêtre ;
    dans le navigateur, où Qt n'a AUCUNE police système, celles du sujet et celle de l'interface du natif, Noto Sans, ce
    que « Sans Serif 9 » donne sur la machine, sont livrées dans ``polices/`` à côté de ce fichier et chargées là)."""
    app = application_web(polices=Path(__file__).parent / "polices", defaut=("Noto Sans", 9))
    # toujours clair, même sur un téléphone en mode sombre (l'utilisateur, 02/10/2026) : les couleurs du sujet (fonds,
    # surlignages, code) sont choisies sur fond clair, et Qt-WASM suit sinon le « prefers-color-scheme » du navigateur
    app.styleHints().setColorScheme(Qt.ColorScheme.Light)
    if DEFILEMENT not in app.styleSheet():  # en tête : ce qu'ajoute ``tactile.activer`` (l'ascenseur élargi) l'emporte
        app.setStyleSheet(DEFILEMENT + app.styleSheet())
    return app


# Les barres de défilement à la manière d'un navigateur (l'utilisateur, 02/10/2026 : « se rapprocher de la barre de
# défilement de Firefox ») : ni flèches ni rail, une poignée grise arrondie, détachée du bord, qui fonce et s'élargit
# sous le pointeur. Le même dessin en natif et dans le navigateur, quel que soit le style de Qt (Breeze, Fusion).
DEFILEMENT = "".join(
    f"QScrollBar:{sens} {{ background: transparent; border: none; margin: 0px; {cote}: 12px; }}"
    f"QScrollBar::handle:{sens} {{ background: rgba(0, 0, 0, 0.3); border-radius: 3px; margin: {marges}; min-{long}: 32px; }}"
    f"QScrollBar::handle:{sens}:hover {{ background: rgba(0, 0, 0, 0.45); border-radius: 4px; margin: {marges_survol}; }}"
    f"QScrollBar::handle:{sens}:pressed {{ background: rgba(0, 0, 0, 0.55); }}"
    f"QScrollBar::add-line:{sens}, QScrollBar::sub-line:{sens} {{ border: none; background: none; {cote}: 0px; {long}: 0px; }}"
    f"QScrollBar::add-page:{sens}, QScrollBar::sub-page:{sens} {{ background: none; }}"
    for sens, cote, long, marges, marges_survol in (("vertical", "width", "height", "2px 3px", "2px 2px"),
                                                    ("horizontal", "height", "width", "3px 2px", "2px 2px")))


class BarreParDessus(QScrollBar):
    """La barre verticale d'une zone défilante posée PAR-DESSUS son contenu, sur son bord droit, au lieu d'une bande à
    côté (l'utilisateur, 02/10/2026, pour le cours : « la barre au-dessus du pdf », son fond transparent). Le style de Qt
    le fait (``SH_ScrollBar_Transient``), mais ``QStyleSheetStyle`` l'ignore dès que ``DEFILEMENT`` habille les barres :
    la barre de Qt est cachée, celle-ci la recopie dans les deux sens (la molette passe toujours par l'autre)."""

    def __init__(self, zone):
        super().__init__(Qt.Orientation.Vertical, zone)
        self.zone, self.interne = zone, zone.verticalScrollBar()
        zone.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.interne.rangeChanged.connect(self._etendue)
        self.interne.valueChanged.connect(self.setValue)
        self.valueChanged.connect(self.interne.setValue)
        zone.viewport().installEventFilter(self)  # pas la zone : son filtre passe avant que Qt recale le viewport
        self._etendue()

    def _etendue(self, *_):
        # l'étendue relue sur la barre de Qt, pas celle du signal : setPageLimit (qtpy6) la ramène à la dernière page
        # montrée pendant l'émission, et le signal porterait encore celle de tout le PDF (11 321 px au lieu de 1 420)
        minimum, maximum = self.interne.minimum(), self.interne.maximum()
        self.setRange(minimum, maximum)
        self.setPageStep(self.interne.pageStep())
        self.setSingleStep(self.interne.singleStep())
        self.setVisible(maximum > minimum)

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.Resize:
            vue = self.zone.viewport().geometry()
            largeur = self.sizeHint().width()
            self.setGeometry(vue.right() + 1 - largeur, vue.top(), largeur, vue.height())
        return False


def fond_sujet():
    """Le fond du sujet : entre le gris de la fenêtre (trop terne) et le blanc des champs (qui s'y perdraient), aux trois
    quarts vers le blanc."""
    fenetre, champ = QApplication.palette().window().color(), QApplication.palette().base().color()
    return QColor(*((a + 3 * b) // 4 for a, b in zip(fenetre.getRgb()[:3], champ.getRgb()[:3])))


def fond_entete(palette):
    """Donne à ``palette`` le fond de l'entête du sujet : celui de la barre de titre, lu dans le thème KDE (« Header »),
    plus foncé quand la fenêtre a le focus, comme elle ; ailleurs, le gris de la fenêtre, assombri d'autant qu'en Breeze
    clair (239 → 222) quand elle a le focus. ``configparser`` et pas QSettings : celui-ci lit « [Colors:Header][Inactive] »
    comme une seconde « [Colors:Header] », qui écrase la première."""
    theme = configparser.ConfigParser(interpolation=None, strict=False)
    theme.read(os.path.expanduser("~/.config/kdeglobals"), encoding="utf-8")
    fenetre = QApplication.palette().window().color()
    for groupe, section, defaut in ((QPalette.ColorGroup.Active, "Colors:Header", fenetre.darker(108)),
                                    (QPalette.ColorGroup.Inactive, "Colors:Header][Inactive", fenetre)):
        try:
            couleur = QColor(*map(int, theme.get(section, "BackgroundNormal").split(",")))
        except (configparser.Error, TypeError, ValueError):  # pas de KDE, ou une couleur écrite autrement que « r,g,b »
            couleur = defaut
        palette.setColor(groupe, QPalette.ColorRole.Window, couleur)


def question(widget):
    """La question qui contient ``widget`` (ou ``widget`` lui-même), None hors d'une question."""
    while widget is not None and not isinstance(widget, Question):
        widget = widget.parentWidget()
    return widget


def copiable(widget):
    """Vrai si une question qui contient ``widget`` (ou lui-même) porte ``copiable`` : sans elle, rien ne se copie.
    Toutes les questions qui le contiennent comptent : un Groupe copiable le transmet à ses sous-questions. Hors question,
    un widget à la propriété ``copiable`` (l'accueil du lecteur : le code s'y colle) le transmet de même à ses enfants."""
    while widget is not None:
        if isinstance(widget, Question) and widget.copiable or widget.property("copiable"):
            return True
        widget = widget.parentWidget()
    return False


def indentation_copiee(texte: str) -> str:
    """Le code copié d'un PDF, l'indentation écrite en « $ » (``texte_md.indentation_visible``) ou « ____ » rendue en
    espaces : un lecteur de PDF jette les espaces de début de ligne, et Pyxel Studio attend du Python."""
    return re.sub(r"(?m)^(?:\$+|_{4,})", lambda m: " " * len(m[0]), texte)


def cadre_code(document, position):
    """La table du cadre de code (texte_md.bloc_code) où se trouve ``position``, None hors d'un code."""
    curseur = QTextCursor(document)
    curseur.setPosition(position)
    table = curseur.currentTable()
    return table if table is not None and table.format().background().color() == QColor(CADRE_CODE[0]) else None


def code_selectionne(texte):
    """Le code sélectionné dans un Texte d'un projet, tel qu'écrit ; None si la sélection n'est pas dans un cadre de code."""
    curseur = texte.textCursor()
    if not texte.property("code_seul") or not curseur.hasSelection() or cadre_code(texte.document(), curseur.anchor()) is None:
        return None
    return curseur.selectedText().replace("\u2029", "\n")


def sorties_de_l_epreuve(sorties):
    """« Sorties de l'épreuve : 2 (3 min 10 s hors de l'épreuve) », suivi de l'heure de chacune ; une copie rouverte (page
    fermée ou rechargée) n'a pas d'heure de départ, ni de durée."""
    def heure(t):
        return time.strftime("%H:%M:%S", time.localtime(t)) if t else "?"
    duree = round(sum(retour - depart for depart, retour in sorties if depart and retour))
    return "\n".join([f"Sorties de l'épreuve : {len(sorties)} ({duree // 60} min {duree % 60} s hors de l'épreuve)"]
                     + [f"  {'copie rouverte' if depart is None else 'sortie à ' + heure(depart)}, retour à {heure(retour)}"
                        for depart, retour in sorties])


def migrations_de_la_copie(migrations):
    """Pour le professeur, un paragraphe par nouvelle version du sujet rencontrée par la copie (``noyau.Paquet.migrer``) :
    « Sujet modifié à 14:02 depuis le début de la copie : questions ajoutées : e ; reprises vierges (modifiées) : b ; … »."""
    rubriques = (("ajoutees", "questions ajoutées"), ("bareme", "barème changé, points mis à l'échelle"),
                 ("modifiees", "reprises vierges (modifiées)"), ("retirees", "retirées"))
    lignes = []
    for m in migrations:
        quand = time.strftime("%d/%m %H:%M", time.localtime(m["instant"]))
        detail = [f"{nom} : {', '.join(q if isinstance(q, str) else q['id'] for q in m[cle])}" for cle, nom in rubriques if m.get(cle)]
        rendue = " ; copie déjà rendue : laissée telle quelle" if "copie rendue" in m else ""
        lignes.append(f"Sujet modifié le {quand} depuis le début de la copie : {' ; '.join(detail)}{rendue}")
    return "\n".join(lignes)


class GardeCopie(QObject):
    """Installé par le lecteur seulement : rien de ce que l'élève voit ne peut être copié, sauf dans une question
    ``copiable``. Le texte n'est plus sélectionnable ; Ctrl+C, Ctrl+X, Ctrl+Inser, Maj+Suppr et le menu contextuel sont
    interceptés AVANT que le presse-papiers ne reçoive quoi que ce soit (un gestionnaire de presse-papiers le lirait aussitôt).
    Dans un projet, le code de l'énoncé est écrit pour être collé dans l'éditeur : un cadre de code s'y sélectionne et se
    copie (Ctrl+C), un cadre à la fois, et rien autour.

    Copier et coller restent possibles DANS l'épreuve, par un presse-papiers à elle (``memoire``) que le système ne voit
    pas : Ctrl+C et Ctrl+X d'un éditeur ou d'un cadre de code y écrivent, Ctrl+V (et Maj+Inser) colle ce qu'il contient,
    jamais le presse-papiers du système (l'utilisateur, 02/10/2026 : « empecher de coller depuis l'exterieur ou un copier
    vers l'exterieur »). Fermés de même hors d'une question ``copiable`` : le dépôt d'un texte glissé d'une autre
    application, et le clic du milieu (la sélection primaire de Linux). Dans le navigateur, le collage arrive par
    l'événement ``paste`` de la page, que ``qtpy6.web`` rend à Qt en Ctrl+V : il passe donc ici aussi."""

    def __init__(self, app):
        super().__init__(app)
        self.memoire = ""
        app.installEventFilter(self)

    @staticmethod
    @contextlib.contextmanager
    def suspendue():
        """Le temps du bloc, sans garde : un écran construit caché (``lecteur.Lecteur``) n'affiche rien et ne reçoit aucune
        touche, et chacun de ses événements (≈ 250 000 pour python_tp) traversait ce filtre Python : 2,5 → 1,6 s CPU en
        natif (minimums de six essais, 02/10/2026)."""
        app = QApplication.instance()
        gardes = app.findChildren(GardeCopie)
        for garde in gardes:
            app.removeEventFilter(garde)
        try:
            yield
        finally:
            for garde in gardes:
                app.installEventFilter(garde)

    GLISSER = frozenset((QEvent.Type.DragEnter, QEvent.Type.DragMove, QEvent.Type.Drop))
    CLIC = frozenset((QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease, QEvent.Type.MouseButtonDblClick))
    GARDES = frozenset((QEvent.Type.Show, QEvent.Type.KeyPress, QEvent.Type.ShortcutOverride, QEvent.Type.ContextMenu)) | GLISSER | CLIC

    def eventFilter(self, objet, evenement):
        """Appelé pour chaque événement de l'application : le type d'abord, le seul test qui écarte presque tout."""
        type_ = evenement.type()
        if type_ not in self.GARDES or not isinstance(objet, QWidget):
            return False
        if type_ == QEvent.Type.Show and isinstance(objet, Texte):  # dans les deux sens : un Texte affiché avant d'avoir son parent est venu sans question
            libre, q = copiable(objet), question(objet)
            objet.setProperty("code_seul", not libre and q is not None and q.projet)
            objet.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction if libre
                                          else Qt.TextInteractionFlag.TextSelectableByMouse if objet.property("code_seul")
                                          else Qt.TextInteractionFlag.NoTextInteraction)
            if objet.property("code_seul") and not objet.property("limite"):
                objet.setProperty("limite", True)
                objet.selectionChanged.connect(functools.partial(self.limiter, objet))
        elif type_ in (QEvent.Type.KeyPress, QEvent.Type.ShortcutOverride):
            copier, couper, coller = (evenement.matches(touche) for touche in (
                QKeySequence.StandardKey.Copy, QKeySequence.StandardKey.Cut, QKeySequence.StandardKey.Paste))
            if not (copier or couper or coller) or copiable(objet):
                return False
            if type_ == QEvent.Type.KeyPress:
                self.presse_papiers(objet, couper, coller)
            return True
        elif type_ in self.GLISSER:  # un texte glissé d'une autre application (un glisser interne a sa source)
            if evenement.source() is None and not copiable(objet):
                evenement.ignore()
                return True
        elif type_ in self.CLIC:
            return evenement.button() == Qt.MouseButton.MiddleButton and not copiable(objet)
        elif type_ == QEvent.Type.ContextMenu and not copiable(objet):
            return True
        return False

    def presse_papiers(self, objet, couper, coller):
        """Ctrl+C, Ctrl+X ou Ctrl+V sur ``objet``, par ``memoire`` : un champ (QLineEdit), un éditeur (QPlainTextEdit) ou un
        cadre de code d'un projet (``code_selectionne``) ; ailleurs, rien."""
        editable = hasattr(objet, "isReadOnly") and not objet.isReadOnly()
        en_ligne = isinstance(objet, QLineEdit)
        table = self.table_de(objet)
        if table is not None:  # un bloc de cases, sélectionné à la souris (l'utilisateur, 05/10/2026 : « permettre de faire du
            editeur = objet if en_ligne else None  # copier / coller en sélectionnant plusieurs cases »)
            if coller and ("\t" in self.memoire or "\n" in self.memoire):
                return self.coller_bloc(table, editeur, self.memoire)
            if not coller and (bloc := self.copier_bloc(table, editeur)) is not None:
                self.memoire = bloc
                if couper:
                    self.vider_bloc(table, editeur)
                return
        if coller:
            if editable and self.memoire:
                objet.insert(self.memoire) if en_ligne else objet.insertPlainText(self.memoire)
            return
        if isinstance(objet, Texte):
            texte = code_selectionne(objet)
        elif en_ligne:
            texte = objet.selectedText()
        elif hasattr(objet, "textCursor"):
            texte = objet.textCursor().selectedText().replace(" ", "\n")
        else:
            texte = None
        if not texte:
            return
        self.memoire = texte
        if isinstance(objet, Texte) and getattr(question(objet), "editeur_externe", False):  # le code se colle dans Pyxel Studio
            QApplication.clipboard().setText(texte)
        if couper and editable:
            objet.insert("") if en_ligne else objet.textCursor().removeSelectedText()

    @staticmethod
    def table_de(objet: QWidget) -> QTableWidget | None:
        """Le ``QTableWidget`` à sélection de cases dont ``objet`` est la vue ou l'éditeur d'une case, sinon None (une grille
        de conversion n'a pas de sélection : ses champs se collent un à un)."""
        for w in (objet, objet.parentWidget(), objet.parentWidget() and objet.parentWidget().parentWidget()):
            if isinstance(w, QTableWidget):
                return None if w.selectionMode() == QAbstractItemView.SelectionMode.NoSelection else w
        return None

    @staticmethod
    def copier_bloc(table: QTableWidget, editeur: QLineEdit | None) -> str | None:
        """Le texte des cases sélectionnées, s'il y en a au moins deux : une ligne par rangée, les colonnes séparées par des
        tabulations, comme un tableur ; une case du rectangle hors de la sélection compte vide. La case en cours de saisie
        se lit dans son éditeur, où est sa dernière frappe."""
        choisies = {(i.row(), i.column()) for i in table.selectedIndexes()}
        if len(choisies) < 2:
            return None
        courante = table.currentRow(), table.currentColumn()

        def texte(r: int, c: int) -> str:
            if (r, c) not in choisies:
                return ""
            if editeur is not None and (r, c) == courante:
                return editeur.text()
            return table.item(r, c).text() if table.item(r, c) else ""
        lignes, colonnes = [r for r, _ in choisies], [c for _, c in choisies]
        return "\n".join("\t".join(texte(r, c) for c in range(min(colonnes), max(colonnes) + 1))
                         for r in range(min(lignes), max(lignes) + 1))

    @staticmethod
    def coller_bloc(table: QTableWidget, editeur: QLineEdit | None, bloc: str) -> None:
        """Un bloc copié (``copier_bloc``) à partir de la case courante : chaque valeur va dans sa case si elle est à
        remplir ; une case donnée, un menu ou ce qui dépasse la table la laisse tomber. Rien sur une table figée."""
        r0, c0 = table.currentRow(), table.currentColumn()
        if r0 < 0 or c0 < 0:
            return
        for i, ligne in enumerate(bloc.rstrip("\n").split("\n")):
            for j, valeur in enumerate(ligne.split("\t")):
                GardeCopie.ecrire_case(table, editeur, r0 + i, c0 + j, valeur)

    @staticmethod
    def vider_bloc(table: QTableWidget, editeur: QLineEdit | None) -> None:
        """Ctrl+X sur un bloc : ses cases à remplir se vident, ses cases données restent."""
        for i in table.selectedIndexes():
            GardeCopie.ecrire_case(table, editeur, i.row(), i.column(), "")

    @staticmethod
    def ecrire_case(table: QTableWidget, editeur: QLineEdit | None, r: int, c: int, valeur: str) -> None:
        """``valeur`` dans la case (r, c) si elle est à remplir, dans son éditeur s'il est ouvert ; rien sur une table figée
        (inactive : une table soumise ou verrouillée l'est, le voile ne retenant que la souris)."""
        case = table.item(r, c)
        if not table.isEnabled() or case is None or not case.flags() & Qt.ItemFlag.ItemIsEditable \
                or table.cellWidget(r, c) not in (None, editeur):  # (``cellWidget`` rend aussi l'éditeur ouvert : pas un menu)
            return
        if editeur is not None and (r, c) == (table.currentRow(), table.currentColumn()):
            editeur.setText(valeur)
        else:
            case.setText(valeur)

    @staticmethod
    def limiter(texte):
        """Une sélection ne sort pas du cadre de code où elle a commencé ; commencée ailleurs, elle s'efface."""
        curseur = texte.textCursor()
        if not curseur.hasSelection():
            return
        cadre = cadre_code(texte.document(), curseur.anchor())
        if cadre is None:
            curseur.clearSelection()
        else:
            position = min(max(curseur.position(), cadre.firstCursorPosition().position()), cadre.lastCursorPosition().position())
            if position == curseur.position():
                return
            curseur.setPosition(position, QTextCursor.MoveMode.KeepAnchor)
        texte.setTextCursor(curseur)


def a_l_echelle(html):
    """Les tailles écrites en points dans le HTML, comptées pour le corps de 10 pt du papier, à l'échelle du corps de
    l'écran. Le code (``MONO``, 9 pt sur le papier) prend, lui, le corps entier de l'écran, celui de l'éditeur de
    code (demande de l'utilisateur, 28/09/2026) : 9 pt y deviennent TAILLE_POLICE, pas 10,8."""
    return re.sub(rf"(font-family:'{MONO}'; )?font-size:(\d+(?:\.\d+)?)pt",
                  lambda m: f"{m.group(1) or ''}font-size:{float(m.group(2)) * TAILLE_POLICE / (9 if m.group(1) else 10):g}pt", html)


A_NOTER = f'<u style="color:#bfbfbf">{"&nbsp;" * 5}</u>&nbsp;/&nbsp;'  # exporter_pdf.A_NOTER : la place de la note
INDENTATION_PAPIER = re.compile(r'<span style="color:transparent">(\$+)</span>')  # texte_md.indentation_visible


class MarkdownEcran(Markdown):
    """Une image se dit par son nom : ``Texte.loadResource`` la fournit, quand ses octets sont là (après la construction).
    L'indentation d'un bloc de code reste des espaces, que son ``<pre>`` préserve : les « $ » transparents du papier
    (pour le copier d'un lecteur de PDF) se verraient dans une sélection, et se copieraient."""

    sons = None  # liste (ancre, nom, légende) accumulée par ``media`` pendant un ``Texte.definir`` ; None ailleurs
    # (``html_case``, peint sans widgets) : un son y reste alors le texte injouable du papier, comme prévu.
    AUDIO = {"mp3", "ogg", "flac", "m4a"}  # un bouton les joue à l'écran (QMediaPlayer) ; vidéo : injouable, reste en texte

    def media(self, m):
        legende, nom = m.group(1), m.group(2)
        extension = nom.rsplit(".", 1)[-1].lower()
        if extension in IMAGES:
            return f'<img src="{nom}">'
        if extension in self.AUDIO and self.sons is not None and nom in MEDIAS:
            ancre = f"son{len(self.sons)}"
            self.sons.append((ancre, nom, legende))
            legende_html = f' <i>{html.escape(legende)}</i>' if legende else ""
            return f'<a name="{ancre}">{"&nbsp;" * 3}</a>{legende_html}'
        return super().media(m)

    def code(self, *args, **kwargs):
        """Le fond du cadre sur sa case : Qt ne peint pas le ``bgcolor`` d'un tableau en ``border-collapse:collapse``,
        et le code prenait le fond du sujet. Le gris du papier, légèrement plus foncé que la page, pour ne pas être pris
        pour le blanc d'un éditeur où l'on écrit (l'utilisateur, 30/09/2026, après le blanc pur du 26/09)."""
        html = INDENTATION_PAPIER.sub(lambda m: " " * len(m.group(1)), super().code(*args, **kwargs))
        return html.replace("<tr><td ", f'<tr><td bgcolor="{CADRE_CODE[0]}" ', 1)


MD = MarkdownEcran({}, LARGEUR_MAX)


def largeur_naturelle(document):
    """La largeur d'un texte sans retour à la ligne : celle de sa plus longue ligne."""
    copie = document.clone()
    copie.setTextWidth(-1)
    return copie.idealWidth()


def fragments(document):
    """Les fragments de texte du document, dans l'ordre."""
    bloc = document.begin()
    while bloc.isValid():
        it = bloc.begin()
        while not it.atEnd():
            yield it.fragment()
            it += 1
        bloc = bloc.next()


OBJET_SVG, NOM_SVG = QTextFormat.UserObject + 1, QTextFormat.UserProperty + 1
POUCE = {"in": 1, "cm": 1 / 2.54, "mm": 1 / 25.4, "pt": 1 / 72, "pc": 1 / 6, "px": 1 / 96, "": 1 / 96}


def taille_svg(octets):
    """Largeur et hauteur, en pouces, que la racine d'un SVG déclare (``width="5.17in"``) : son pHYs à lui. Sans unité,
    des pixels d'écran. Absentes, on échoue : la taille d'affichage n'est écrite nulle part ailleurs."""
    racine = re.search(rb"<svg\b[^>]*>", octets).group(0)
    return [float(m.group(1)) * POUCE[m.group(2).decode()]
            for m in (re.search(rb'\s%s="([\d.]+)(\w*)"' % cote, racine) for cote in (b"width", b"height"))]


class ObjetSvg(QPyTextObject):  # QObject + QTextObjectInterface : la classe fournie par PySide, le double héritage n'y suffit pas
    """Les images des médias dessinées dans un QTextDocument par ce gestionnaire plutôt que par la ressource image de Qt :
    un SVG en vecteurs (net à toute échelle, à l'écran comme dans le PDF, là où une image serait rééchantillonnée), un PNG
    à pleine résolution réduit au dessin (net sur un écran HiDPI). Et la largeur d'affichage suit celle du texte : sur un
    téléphone, une figure large se réduit au lieu d'être coupée au bord (``intrinsicSize`` est redemandée à chaque
    changement de largeur du document). ``echelle`` : les unités du document par pouce de la taille déclarée dans le
    média (pixels à l'écran, points sur le papier), ``largeur_max`` la largeur d'affichage à ne pas dépasser.

    À l'écran, la figure dessinée une fois à la taille des pixels est gardée en image (``qtpy6.peinture``), copiée telle
    quelle aux peintures suivantes : relancer ``QSvgRenderer.render`` (ou réduire le PNG) à chaque peinture coûtait à chaque
    défilement. Le PDF et le SVG gardent les vecteurs."""

    NUMEROS = itertools.count()  # pas id(self) : un gestionnaire détruit laisse son adresse à un autre

    def __init__(self, document, medias, echelle, largeur_max):
        super().__init__(document)  # vit tant que le document : la disposition ne retient pas son gestionnaire
        self.medias, self.echelle, self.largeur_max, self.rendus, self.numero = medias, echelle, largeur_max, {}, next(self.NUMEROS)
        document.documentLayout().registerHandler(OBJET_SVG, self)

    def poser(self):
        """Après chaque ``setHtml`` : le HTML ne sait pas déclarer d'objet personnalisé, chaque ``<img>`` dont le nom est
        dans les médias est remplacé par l'objet que ce gestionnaire dessine."""
        document = self.parent()
        images = [(f.position(), f.charFormat().toImageFormat().name()) for f in fragments(document) if f.charFormat().isImageFormat()]
        for position, nom in reversed(images):  # de la fin : les positions restent justes
            if nom in self.medias:
                format_ = QTextCharFormat()
                format_.setObjectType(OBJET_SVG)
                format_.setProperty(NOM_SVG, nom)
                curseur = QTextCursor(document)
                curseur.setPosition(position)
                curseur.setPosition(position + 1, QTextCursor.MoveMode.KeepAnchor)
                curseur.insertText("\ufffc", format_)

    def rendu(self, nom):
        """Le SVG prêt à dessiner ou le PNG décodé, et sa taille en pouces : ce que déclare la racine du SVG, la résolution
        du PNG (``pHYs``, la taille dans le Word d'origine) ; sans elle, ses pixels comptent pour des unités du document."""
        if nom not in self.rendus:
            octets = self.medias[nom]
            if nom.lower().endswith(".svg"):
                # le texte d'un SVG prend la police du sujet (celle du document : le système à l'écran, Carlito sur le
                # papier), quelle que soit la famille écrite dans le fichier ; sa taille reste celle du fichier, en unités
                # de la figure, donc à l'échelle de la figure — demande de l'utilisateur, 24/09/2026
                famille = self.parent().defaultFont().family().encode()
                # sauf la main du correcteur (Kalam), dans les figures que le corrigé remplit (``Conversion.svg``)
                image = QSvgRenderer(QByteArray(re.sub(rb'font-family="(?!Kalam")[^"]*"', b'font-family="' + famille + b'"', octets)))
                largeur, hauteur = taille_svg(octets)
            else:
                image = QImage.fromData(octets)
                par_pouce = image.dotsPerMeterX() * 0.0254 if b"pHYs" in octets else self.echelle
                largeur, hauteur = image.width() / par_pouce, image.height() / par_pouce
            self.rendus[nom] = image, largeur, hauteur
        return self.rendus[nom]

    def intrinsicSize(self, document, position, format_):
        _, largeur, hauteur = self.rendu(format_.property(NOM_SVG))
        largeur_max = min(self.largeur_max, document.textWidth()) if document.textWidth() > 0 else self.largeur_max
        facteur = min(self.echelle, largeur_max / largeur)
        return QSizeF(largeur * facteur, hauteur * facteur)

    @staticmethod
    def dessiner(peintre, image, rect):
        if isinstance(image, QSvgRenderer):
            image.render(peintre, rect)
        else:
            peintre.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            peintre.drawImage(rect, image)

    def drawObject(self, peintre, rect, document, position, format_):
        nom = format_.property(NOM_SVG)
        image = self.rendu(nom)[0]
        peinture.en_image(peintre, rect, (self.numero, nom), lambda p, r: self.dessiner(p, image, r))


class MenuCentre(QComboBox):
    """Un menu dont le mot choisi est centré : un champ en lecture seule dont l'appui ouvre la liste, et dont le
    relâchement sur une ligne la choisit — appuyer, glisser, relâcher : un seul geste, pas deux clics."""

    # Deux appuis rapprochés (souris, ou deux petits coups de doigt) font un double clic, pas un second appui : laissé au
    # champ, il y sélectionnait le mot au lieu d'ouvrir la liste (vu au doigt par l'utilisateur, 28/09/2026)
    APPUIS = (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonDblClick)

    def __init__(self):
        super().__init__()
        self.ouverture = None  # où l'appui a ouvert la liste ; None une fois l'appui fait dans la liste elle-même
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self.lineEdit().setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lineEdit().installEventFilter(self)
        self.view().window().installEventFilter(self)  # le cadre de la liste déroulée
        self.view().viewport().installEventFilter(self)

    def eventFilter(self, objet, evenement):
        if objet is self.lineEdit() and evenement.type() in self.APPUIS:
            self.ouverture = evenement.globalPosition().toPoint()
            self.showPopup()
            return True
        if objet is self.view().viewport() and evenement.type() == QEvent.Type.MouseButtonPress:
            self.ouverture = None
        if objet is self.view().viewport() and evenement.type() == QEvent.Type.MouseButtonRelease:
            # La vue ne choisit qu'au relâchement d'un appui reçu par elle. Celui de l'appui d'ouverture choisit s'il a
            # glissé : sans glisser, la liste ouverte par-dessus le champ prendrait la ligne sous le doigt.
            deplacement = None if self.ouverture is None else evenement.globalPosition().toPoint() - self.ouverture
            index = self.view().indexAt(evenement.position().toPoint())
            if index.isValid() and (deplacement is None or deplacement.manhattanLength() >= QApplication.startDragDistance()):
                self.setCurrentIndex(index.row())
                self.hidePopup()
            return True
        if (objet is self.view().window() and evenement.type() == QEvent.Type.MouseButtonRelease
                and not self.view().geometry().contains(evenement.position().toPoint())):
            # Le relâchement qui suit l'appui d'ouverture tombe sur le champ, hors de la liste : personne ne le prend, et
            # Qt-WASM (6.10, Firefox, souris comme doigt) referme alors la liste avant tout choix. Le consommer la garde
            # ouverte jusqu'au clic sur une ligne ou à côté ; sur le bureau, il était déjà sans effet.
            return True
        return super().eventFilter(objet, evenement)

    def wheelEvent(self, evenement):
        # La molette passe à la page : QComboBox la prenait pour changer de mot, ce qui arrêtait le défilement au-dessus
        # du menu et modifiait la réponse sans que l'élève le voie (signalé par l'utilisateur, 02/10/2026)
        evenement.ignore()

    def addItems(self, textes):
        super().addItems(textes)
        for i in range(self.count()):
            self.setItemData(i, Qt.AlignmentFlag.AlignCenter, Qt.ItemDataRole.TextAlignmentRole)
        self.setCurrentIndex(-1)  # rien de choisi, sans ligne vide dans la liste

    def largeur(self, police):
        return max(QFontMetrics(police).horizontalAdvance(self.itemText(i)) for i in range(self.count())) + 16


class MenuBinaire(MenuCentre):
    """Un menu à deux mots : tant que rien n'est choisi, il montre « mot **/** mot » ; le mot survolé se grise, le mot
    appuyé se grise davantage, et le relâcher dessus le choisit. Une fois choisi, chaque appui passe à l'autre mot : une
    liste de deux lignes n'apporterait rien (demande de l'utilisateur, 28/09/2026)."""

    def __init__(self, mots):
        super().__init__()
        self.addItems(mots)
        self.deux = DeuxMots(mots, self.lineEdit())
        self.lineEdit().setMouseTracking(True)  # le survol sans bouton
        self.lineEdit().textChanged.connect(self._texte_change)  # ``setCurrentText`` ne touche que lui

    def _texte_change(self, texte):
        self.deux.setVisible(not texte)

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.deux.setFont(self.lineEdit().font())  # celle de la feuille de style, qui ne descend pas jusqu'à l'incrustation
        self.deux.resize(self.lineEdit().size())

    def eventFilter(self, objet, evenement):
        type_ = evenement.type()
        if objet is self.lineEdit() and self.currentText() and type_ in (*self.APPUIS, QEvent.Type.MouseButtonRelease):
            if type_ in self.APPUIS:
                self.setCurrentIndex(1 - self.currentIndex())  # choisi : l'appui passe à l'autre mot, sans liste
            return True
        souris = (QEvent.Type.MouseMove, *self.APPUIS, QEvent.Type.MouseButtonRelease, QEvent.Type.Leave)
        if objet is self.lineEdit() and type_ in souris and not self.currentText():
            deux = self.deux
            deux.survol = None if type_ == QEvent.Type.Leave else deux.cote(evenement.position().x())
            if type_ in self.APPUIS:
                deux.appui = deux.survol
            if type_ == QEvent.Type.MouseButtonRelease:
                choisi, deux.appui = deux.appui == deux.survol, None
                if choisi:
                    self.setCurrentIndex(deux.survol)  # relâché sur le mot appuyé ; glissé vers l'autre, rien
            deux.update()
            if type_ not in (QEvent.Type.MouseMove, QEvent.Type.Leave):
                return True
        return super().eventFilter(objet, evenement)

    def largeur(self, police):
        return QFontMetrics(gras(police)).horizontalAdvance(f"{self.itemText(0)} / {self.itemText(1)}") + 16


class DeuxMots(QWidget):
    """« mot **/** mot » posé sur le champ d'un ``MenuBinaire`` : il dessine, le champ reçoit la souris."""

    def __init__(self, mots, champ):
        super().__init__(champ)
        self.mots, self.survol, self.appui = mots, None, None  # côtés (0 ou 1) survolé et appuyé
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    def zones(self):
        """Le rectangle de chaque mot et celui de la barre, centrés dans le champ."""
        normale, grasse = QFontMetrics(self.font()), QFontMetrics(gras(self.font()))
        a, b = (normale.horizontalAdvance(mot) for mot in self.mots)
        espace, barre = normale.horizontalAdvance(" "), grasse.horizontalAdvance("/")
        x = (self.width() - a - b - 2 * espace - barre) / 2
        h = self.height()
        return QRectF(x, 0, a, h), QRectF(x + a + espace, 0, barre, h), QRectF(x + a + 2 * espace + barre, 0, b, h)

    def cote(self, x):
        return 0 if x < self.zones()[1].center().x() else 1

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        premier, barre, second = self.zones()
        peintre.setPen(Qt.PenStyle.NoPen)
        for cote, zone in enumerate((premier, second)):
            opacite = 55 if self.appui == cote else 25 if self.survol == cote and self.appui is None else 0
            if opacite:
                peintre.setBrush(QColor(0, 0, 0, opacite))
                peintre.drawRoundedRect(zone.adjusted(-3, 1, 3, -1), 3, 3)
        peintre.setPen(self.palette().color(QPalette.ColorRole.Text))
        for zone, mot in ((premier, self.mots[0]), (second, self.mots[1])):
            peintre.drawText(zone, Qt.AlignmentFlag.AlignCenter, mot)
        peintre.setFont(gras(self.font()))
        peintre.drawText(barre, Qt.AlignmentFlag.AlignCenter, "/")


def gras(police):
    police = QFont(police)
    police.setBold(True)
    return police


def menu(mots, deux=True):
    """Le champ d'un trou à choisir : deux mots se choisissent d'un appui, davantage dans une liste. ``deux`` faux met
    aussi deux mots dans une liste : un texte dont un trou en a trois déroule tous les siens."""
    if deux and len(mots) == 2:
        return MenuBinaire(mots)
    champ = MenuCentre()
    champ.addItems(mots)
    return champ


TAILLE_TITRE = {1: 22, 2: 17}  # le titre et le sous-titre de l'entête du sujet, en points, avant harmonisation des largeurs
TITRE_MAX, VISUEL_MIN = 40, 60  # ce que l'harmonisation s'autorise : le titre jusqu'à 40 pt, le visuel pas sous 60 px de haut


def entete_harmonisee(document, image):
    """Le titre, le sous-titre et le visuel de l'entête à la même largeur autant que possible (l'utilisateur, 28/09/2026) :
    celle de la plus longue des deux lignes de texte. Le titre grossit jusqu'à ``TITRE_MAX``, le sous-titre sans dépasser
    80 % du titre, le visuel se met à la largeur atteinte (entre ``VISUEL_MIN`` et 4/3 de ``HAUTEUR_VISUEL`` de haut).
    Écrit les tailles dans ``document`` et rend le visuel (``image`` : QImage, ou None) à sa taille."""
    titres, bloc = {}, document.begin()
    while bloc.isValid():
        if bloc.blockFormat().headingLevel() in TAILLE_TITRE:
            titres[bloc.blockFormat().headingLevel()] = bloc
        bloc = bloc.next()

    def largeur(niveau, taille):
        police = QFont(document.defaultFont())
        police.setBold(True)
        police.setPointSizeF(taille)
        return max(QFontMetrics(police).horizontalAdvance(ligne) for ligne in titres[niveau].text().split("\u2028"))

    base = {n: largeur(n, TAILLE_TITRE[n]) or 1 for n in titres}
    cible = max(base.values(), default=0)
    tailles = {}
    if 1 in titres:
        tailles[1] = min(TAILLE_TITRE[1] * cible / base[1], TITRE_MAX)
    if 2 in titres:
        tailles[2] = min(TAILLE_TITRE[2] * cible / base[2], 0.8 * tailles.get(1, TITRE_MAX))
    for niveau, taille in tailles.items():
        morceau = titres[niveau].begin()
        while not morceau.atEnd():
            fragment, curseur = morceau.fragment(), QTextCursor(document)
            format_ = fragment.charFormat()
            format_.clearProperty(QTextFormat.Property.FontSizeAdjustment)  # celui du h1/h2, qui l'emporterait sur la taille
            format_.setFontPointSize(taille)
            curseur.setPosition(fragment.position())
            curseur.setPosition(fragment.position() + fragment.length(), QTextCursor.MoveMode.KeepAnchor)
            curseur.setCharFormat(format_)  # pas mergeCharFormat, qui ne retire aucune propriété
            morceau += 1
    if image is None or image.isNull():
        return None
    atteinte = max((largeur(n, t) for n, t in tailles.items()), default=0) or image.width()
    hauteur = min(max(round(atteinte * image.height() / image.width()), VISUEL_MIN), HAUTEUR_VISUEL * 4 // 3)
    return QPixmap.fromImage(image).scaledToHeight(hauteur, Qt.TransformationMode.SmoothTransformation)


class Texte(QTextBrowser):
    """Du Markdown, sans cadre ni ascenseur, à la hauteur de son contenu."""

    clic = Signal(int, int)

    def __init__(self, markdown="", trou=None, inline=False, manuscrit=False):
        super().__init__()
        self.incrustes = {}  # nom d'ancre -> widget posé sur le texte, à la place de l'ancre
        self.liens = {}  # href -> action, d'un clic sur le lien ou tout près (``lien_sous``)
        self.boutons_son = []  # un par son du texte, repris par definir() quand le même son revient
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setOpenLinks(False)
        self.setStyleSheet("QTextBrowser { background: transparent; }")
        self.document().setDocumentMargin(0)
        self.document().documentLayout().documentSizeChanged.connect(self._ajuster)  # QTextEdit garde la largeur du texte égale à la sienne
        self.svg = ObjetSvg(self.document(), MEDIAS, ECHELLE_MEDIAS, LARGEUR_MAX)  # même échelle que les PNG
        self.definir(markdown, trou, inline, manuscrit=manuscrit)

    def definir(self, markdown, trou=None, inline=False, coche=None, manuscrit=False):
        anciens = {bouton.son: bouton for bouton in self.boutons_son}  # repris tels quels : un son en cours garde son bouton
        MD.sons = []
        rendu = MD.inline(markdown, manuscrit=manuscrit) if inline else MD.html(markdown, trou, coche=coche, manuscrit=manuscrit)
        self.boutons_son = [anciens.pop(son, None) or self._bouton_son(*son) for son in MD.sons]
        MD.sons = None
        for bouton in anciens.values():
            if self.incrustes.get(bouton.objectName()) is bouton:  # son ancre peut être passée à un nouveau bouton
                del self.incrustes[bouton.objectName()]
            bouton.hide()  # caché, pas détruit : il part avec le texte. Détruit, il libérait la lambda qu'il avait alors,
            # dernière référence au texte : texte détruit pendant la destruction de son enfant, plantage de PySide (01/10/2026)
        self.setHtml(a_l_echelle(rendu))
        self.svg.poser()
        if self.parent() is not None or not markdown:  # sans parent, setHidden(False) l'ouvrirait en fenêtre, défaite
            self.setHidden(not markdown)  # dès qu'il est rangé : 543 fois à l'ouverture de python_tp (02/10/2026)
        self._ajuster(self.document().size())

    def _bouton_son(self, ancre, nom, legende):
        """Un bouton qui joue ``nom`` (``_jouer_son``), posé par ``_placer`` comme n'importe quel incrusté."""
        bouton = QToolButton(self.viewport())
        bouton.setObjectName(ancre)
        bouton.son = ancre, nom, legende
        bouton.setText("▶")
        bouton.setToolTip(legende or nom)
        cote = tactile.CIBLE if tactile.ACTIF else 22
        bouton.setFixedSize(cote, cote)
        bouton.hide()
        bouton.clicked.connect(self._jouer_son)
        self.incrustes[ancre] = bouton
        return bouton

    def _jouer_son(self):
        """Le son du bouton cliqué, par l'API Qt native : la même ligne sur le bureau et dans le navigateur, où le greffon
        wasm de Qt Multimedia le confie à un élément ``<audio>``. Un lecteur par bouton, créé au premier clic et gardé
        par lui ; le bouton se rend au bout du son (``_son_fini``) ou sur une erreur."""
        from qtpy6.QtMultimedia import QAudioOutput, QMediaPlayer  # noqa: PLC0415 - au premier son : dans le navigateur, le module se télécharge alors (≈ 600 Ko), pas au chargement de la page

        bouton = self.sender()
        lecteur = getattr(bouton, "lecteur", None)
        if lecteur is None:
            nom = bouton.son[1]
            chemin = Path(tempfile.gettempdir()) / f"qcm-{nom}"  # un fichier : le greffon wasm ne lit pas un QIODevice
            chemin.write_bytes(MEDIAS[nom])
            lecteur = bouton.lecteur = QMediaPlayer(bouton)
            lecteur.setAudioOutput(QAudioOutput(lecteur))
            lecteur.mediaStatusChanged.connect(self._son_fini)
            lecteur.errorOccurred.connect(self._son_en_erreur)
            lecteur.setSource(QUrl.fromLocalFile(str(chemin)))
        bouton.setEnabled(False)
        lecteur.play()

    def _son_fini(self, statut):
        """Rend le bouton au bout du son ou si le média est illisible — jamais sur ``playbackState`` : dans le navigateur,
        le greffon le repasse à ``Stopped`` dès ``canplay``, avant même que le son commence."""
        from qtpy6.QtMultimedia import QMediaPlayer  # noqa: PLC0415 - déjà chargé par _jouer_son

        if statut in (QMediaPlayer.MediaStatus.EndOfMedia, QMediaPlayer.MediaStatus.InvalidMedia):
            self.sender().parent().setEnabled(True)

    def _son_en_erreur(self):
        self.sender().parent().setEnabled(True)

    def _ajuster(self, taille):
        self.setFixedHeight(max(int(taille.height()) + 2, self._placer()))  # un champ centré sur la dernière ligne peut en déborder

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self._placer()

    def _placer(self):
        """Chaque widget incrusté se pose sur l'emplacement réservé par son ancre ``<a name=…>`` ; rend le bas du plus bas."""
        if not self.incrustes:
            return 0  # le cas courant : rien à poser, et le parcours des fragments revient à chaque redimensionnement
        bas = 0
        for fragment in fragments(self.document()):
            for nom in fragment.charFormat().anchorNames():
                widget = self.incrustes.get(nom)
                if widget is not None:
                    curseur = QTextCursor(self.document())
                    curseur.setPosition(fragment.position())
                    rect = self.cursorRect(curseur)
                    widget.move(rect.left(), rect.top() + (rect.height() - widget.height()) // 2)
                    widget.show()
                    bas = max(bas, widget.geometry().bottom() + 2)
        return bas

    def sizeHint(self):
        return QSize(400, int(self.document().size().height()) + 2)

    def loadResource(self, type_, url):
        if url.toString() in MEDIAS:
            return QImage()  # ``ObjetSvg.poser`` remplace l'image dès le HTML posé : rien à charger ici
        return super().loadResource(type_, url)

    def lien_sous(self, position):
        """Le lien d'action (``liens``) sous ``position`` ou à quelques pixels : un mot en italique est une cible trop
        petite, surtout au doigt (demande de l'utilisateur, 28/09/2026 : « la zone pour cliquer dessus doit être assez large »)."""
        if not self.liens:
            return None
        rayon = tactile.CIBLE // 2 if tactile.ACTIF else 10
        for dy in (0, -rayon // 2, rayon // 2, -rayon, rayon):
            for dx in (0, -rayon // 2, rayon // 2, -rayon, rayon):
                lien = self.anchorAt(position + QPoint(dx, dy))
                if lien in self.liens:
                    return lien
        return None

    def mousePressEvent(self, evenement):
        lien = self.lien_sous(evenement.position().toPoint())
        if lien:
            self.liens[lien]()
            return
        self.clic.emit(int(evenement.position().x()), int(evenement.position().y()))
        super().mousePressEvent(evenement)

    def mouseMoveEvent(self, evenement):
        super().mouseMoveEvent(evenement)
        if self.liens:
            proche = self.lien_sous(evenement.position().toPoint())
            self.viewport().setCursor(Qt.CursorShape.PointingHandCursor if proche else Qt.CursorShape.IBeamCursor)


class Ligne(QWidget):
    """Une case ou un bouton radio et son texte Markdown. Un appui de la case à la fin du texte, sur toute la hauteur
    de la rangée, actionne le bouton ; dans le vide à droite du texte, non : on y pose le doigt pour faire défiler la
    page (demande de l'utilisateur, 27/09/2026)."""

    def __init__(self, bouton, markdown):
        super().__init__()
        self.bouton, self.texte = bouton, Texte(markdown, inline=True)
        disposition = QHBoxLayout(self)
        disposition.setContentsMargins(0, 0, 0, 0)
        # case, texte et commentaire de correction centrés sur la hauteur de la rangée (demande de l'utilisateur, 27/09/2026)
        disposition.addWidget(bouton, 0, Qt.AlignmentFlag.AlignVCenter)
        disposition.addWidget(self.texte, 1, Qt.AlignmentFlag.AlignVCenter)
        self.texte.viewport().installEventFilter(self)  # le texte garde l'appui qui tombe sur ses lettres : on l'y guette

    def _appui(self, evenement, x):
        fin = self.texte.x() + math.ceil(self.texte.document().idealWidth()) + 8  # le doigt qui déborde du dernier mot
        if evenement.button() == Qt.MouseButton.LeftButton and x <= fin:
            self.bouton.click()

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.MouseButtonPress:
            self._appui(evenement, objet.mapTo(self, evenement.position().toPoint()).x())
        return False

    def mousePressEvent(self, evenement):
        if not self.texte.geometry().contains(evenement.position().toPoint()):  # un appui du texte qui remonte : déjà vu
            self._appui(evenement, evenement.position().x())
        super().mousePressEvent(evenement)


def decocher(boutons, groupe=None):
    if groupe:
        groupe.setExclusive(False)
    for b in boutons:
        b.setChecked(False)
    if groupe:
        groupe.setExclusive(True)


class Hauteur(QObject):
    """``lignes`` lignes de haut au moins, et toutes celles du texte, repliées comprises : rien ne se cache sous le
    bord. Recalculé quand la police change : la feuille de style du sujet (``defilant``) l'agrandit une fois le champ
    construit, et une hauteur figée sur l'ancienne coupait les dernières lignes (question 31 de la révision).
    Une hauteur FIXE, pas minimale : au-dessus, la disposition donnait au champ sa hauteur préférée, 192 px pour
    tout QPlainTextEdit, et trois lignes de code flottaient dans un cadre de sept (révision 01, 30/09/2026)."""

    def __init__(self, editeur, lignes):
        super().__init__(editeur)
        self.lignes = lignes
        editeur.installEventFilter(self)
        editeur.document().documentLayout().documentSizeChanged.connect(self._reposer)
        # l'ascenseur, lui, se règle APRÈS la mise en page : c'est là qu'on voit une ligne repliée à la nouvelle largeur
        editeur.verticalScrollBar().rangeChanged.connect(self._reposer)
        self.poser(editeur)

    def _reposer(self):
        self.poser(self.parent())

    def poser(self, editeur):
        """La hauteur réelle des blocs, pas un nombre de lignes : une ligne qui porte un « œ » prend la police de
        secours, plus haute que ``lineSpacing()``."""
        disposition, bloc, texte = editeur.document().documentLayout(), editeur.document().begin(), 0
        while bloc.isValid():
            texte += disposition.blockBoundingRect(bloc).height()
            bloc = bloc.next()
        ligne = editeur.fontMetrics().lineSpacing() + getattr(disposition, "ecart", lambda: 0)()  # l'éditeur de code aère
        editeur.setFixedHeight(max(self.lignes * ligne, math.ceil(texte)) + 16)

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.FontChange:
            self.poser(objet)
        return False


def hauteur(editeur, lignes):
    Hauteur(editeur, lignes)
    return editeur


# --- questions ------------------------------------------------------------------------------------------------

class Case(QCheckBox):
    """La case d'une action à faire, dessinée : un petit rond au contour épais, comme une puce, et un V vert qui le
    recouvre en le débordant une fois l'action faite (dessin choisi par l'utilisateur, 24/09/2026 : la case native,
    13 px bord gris pâle, se perdait sur le fond gris du lecteur)."""

    COTE = 20  # le widget ; le rond est plus petit, le V déborde du rond sans sortir du widget
    RAYON = 6

    def sizeHint(self):
        return QSize(self.COTE, self.COTE)

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        c, inactif = self.COTE, None if self.isEnabled() else "#9e9e9e"
        peintre.setPen(QPen(QColor(inactif or (GRIS_FAIT if self.isChecked() else "#37474f")), 2))  # gris comme son texte une fois faite
        peintre.setBrush(QColor("white"))
        peintre.drawEllipse(QPointF(c / 2, c / 2), self.RAYON, self.RAYON)
        if self.isChecked():
            peintre.setPen(QPen(QColor(inactif or "#43a047"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            # la pointe au centre du rond, pour qu'on lise un V et non un trait le long du bord (remarque du 24/09/2026)
            peintre.drawPolyline(QPolygonF([QPointF(c * 0.27, c * 0.4), QPointF(c * 0.5, c * 0.64), QPointF(c * 0.93, c * 0.08)]))


class CaseCarree(QCheckBox):
    """La case d'un choix multiple, dessinée à plat : Fusion fonce le haut de la sienne en dégradé (remarque de
    l'utilisateur, 27/09/2026 : « je veux quelque chose de plat »). Même taille que la case native, feuille de style
    tactile comprise (``PM_IndicatorWidth`` la suit)."""

    def sizeHint(self):
        cote = self.style().pixelMetric(QStyle.PixelMetric.PM_IndicatorWidth, None, self)
        return QSize(cote, cote)

    minimumSizeHint = sizeHint

    def hitButton(self, position):
        return self.rect().contains(position)

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        cote = min(self.width(), self.height())
        carre = QRectF((self.width() - cote) / 2 + 0.5, (self.height() - cote) / 2 + 0.5, cote - 1, cote - 1)
        actif = self.isEnabled()
        bord = self.palette().color(QPalette.ColorRole.Highlight) if self.hasFocus() else QColor("#8c8c8c" if actif else "#c4c4c4")
        peintre.setPen(QPen(bord, 1))
        peintre.setBrush(QColor("white" if actif else "#f4f4f4"))
        peintre.drawRect(carre)
        if self.isChecked():
            peintre.setPen(QPen(QColor("#202020" if actif else "#9e9e9e"), max(1.6, cote / 8), Qt.PenStyle.SolidLine,
                                Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            x, y, c = carre.x(), carre.y(), carre.width()
            peintre.drawPolyline(QPolygonF([QPointF(x + c * 0.22, y + c * 0.52), QPointF(x + c * 0.42, y + c * 0.74),
                                            QPointF(x + c * 0.8, y + c * 0.26)]))


def ligne_de_base(texte):
    """Où tombe la ligne de base de la première ligne du Texte ``texte``, dans ses coordonnées."""
    bloc = texte.document().firstBlock()
    ligne = bloc.layout().lineAt(0)
    return texte.document().documentLayout().blockBoundingRect(bloc).y() + ligne.y() + ligne.ascent()


def recrire(peintre, calque, texte, couleur, decalage=0):
    """Écrit sur ``calque`` (voile, surimpression), à sa place et en ``couleur``, le Texte ``texte`` que le contenu
    dessous garde transparent : la main du professeur passe ainsi au-dessus du voile, qui la ternirait."""
    peintre.save()
    peintre.translate(QPointF(texte.mapTo(calque.parentWidget(), QPoint(0, 0)) - calque.pos()) + QPointF(0, decalage))
    contexte = QAbstractTextDocumentLayout.PaintContext()
    contexte.palette.setColor(QPalette.ColorRole.Text, QColor(couleur))
    texte.document().documentLayout().draw(peintre, contexte)
    peintre.restore()


def indicateur(bouton):
    """Le rectangle de la case ou du rond que l'élève voit, dans les coordonnées du bouton."""
    if isinstance(bouton, CaseCarree):
        cote = min(bouton.width(), bouton.height())
        return QRect((bouton.width() - cote) // 2, (bouton.height() - cote) // 2, cote, cote)
    option = QStyleOptionButton()
    bouton.initStyleOption(option)
    return bouton.style().subElementRect(QStyle.SubElement.SE_RadioButtonIndicator, option, bouton)


class BoutonEgal(QPushButton):
    """Un bouton de la barre d'une question : texte centré, noir et gras, sans contour, sur un fond à peine plus foncé
    que le sujet (l'utilisateur, 02/10/2026 : tous pareils, Soumettre compris, après un premier jet en couleurs). Tous
    de la largeur de ``REFERENCE``, le plus long libellé courant, quels que soient la question et le texte de l'indice
    (l'utilisateur, 03/10/2026 : « une largeur plus petite et normalisée pour ne pas changer d'une question à l'autre » ;
    avant, le plus large du groupe, que « Indice : −0.5 point (dans 30 s) » portait à 245 px)."""

    REFERENCE = "Indice : −0.25 pt"

    def __init__(self, texte):
        super().__init__(texte)
        # par le bouton : la feuille de style de la zone qui défile ne descend pas jusqu'à lui (``Question._construire``)
        self.setStyleSheet(f"QPushButton {{ font-weight: bold; color: black; border: none;"
                           f" background: {fond_sujet().darker(106).name()}; border-radius: 6px; padding: 4px 8px; }}"
                           " QPushButton:pressed { background: rgba(0, 0, 0, 0.1); } QPushButton:disabled { color: #a0a0a0; }")

    def sizeHint(self):
        taille, mesure = super().sizeHint(), self.fontMetrics()
        return QSize(taille.width() - mesure.horizontalAdvance(self.text()) + mesure.horizontalAdvance(self.REFERENCE),
                     taille.height())


# les icônes des boutons de signalement, du cadenas et de l'épingle : symboliques, pleines et grises (demandes de
# l'utilisateur, 03/10/2026) ; un état actif (épinglée) se voit au fond du bouton, pas à l'icône
ICONES = {
    "bug": '<ellipse cx="12" cy="14.5" rx="4.5" ry="5.5"/><circle cx="12" cy="7" r="2.4"/>'
           '<path d="M7.8 11.5 4.5 8.5M7.5 15.5H3.5M8.5 19l-3 2M16.2 11.5l3.3-3M16.5 15.5h4M15.5 19l3 2M10.5 5 8.5 2.5M13.5 5l2-2.5"/>',
    "idee": '<path d="M9.5 17.5h5M10.5 20.5h3M12 2.5a6 6 0 0 0-3.6 10.8c.9.7 1.6 1.6 1.6 2.7v.5h4V16c0-1.1.7-2 1.6-2.7A6 6 0 0 0 12 2.5z"/>',
    # le doigt levé : des formes pleines sans contour, les quatre doigts séparés entre eux par des vides de 0,7 (« les
    # doigts séparés par des traits transparents ») mais soudés à la paume (« pas de séparation entre les doigts et la
    # paume, mais qu'entre les doigts »), le pouce un trait plein soudé à la paume, qui monte
    # à 45° vers la gauche puis repart à angle droit vers la droite (« il manque le petit
    # doigt […] et son pouce doit être replié », l'utilisateur, 03/10/2026) ; le bug a ses pattes avant tournées vers
    # l'avant (« elles ne doivent pas être complètement horizontales ») ; « le pouce ne doit pas avoir de contour blanc ou
    # transparent, il doit juste monter un tout petit peu à 45° vers la gauche, puis avoir un angle à 90° »
    "question": '<g stroke="none"><rect x="7.6" y="2" width="2.7" height="14" rx="1.35"/>'
                '<rect x="11" y="9" width="2.7" height="7" rx="1.35"/><rect x="14.4" y="9.5" width="2.7" height="6.5" rx="1.35"/>'
                '<rect x="17.8" y="11" width="2.7" height="5" rx="1.35"/>'
                '<path d="M7.6 15H20.5V18C20.5 20.8 18.3 22.6 15.5 22.6H10.6C8.9 22.6 7.6 21.3 7.6 19.6Z"/></g>'
                '<path d="M9 21 6.4 18.4 9 15.8" fill="none" stroke-width="2.7" stroke-linejoin="miter"/>',
    "ferme": '<rect x="5" y="10.5" width="14" height="10.5" rx="2"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5" fill="none"/>',
    "ouvert": '<rect x="5" y="10.5" width="14" height="10.5" rx="2"/><path d="M8 10.5V7a4 4 0 0 1 7.7-1.5" fill="none"/>',
    "epingle": '<path d="M9 2.5h6l-1 6.5 3.5 3.5v1.5h-11v-1.5L10 9z"/><path d="M12 14v7.5"/>',
    # mosaïque / onglets du cours : les glyphes ``mdi.view-grid`` et ``mdi.tab`` (retourné, ``hflip``) des panneaux de
    # SmartPythonEditor (l'utilisateur, 08/10/2026), relevés dans la fonte Material Design Icons 5.9.55 de qtawesome
    "mosaique": '<path stroke="none" d="M3 11H11V3H3ZM3 21H11V13H3ZM13 21H21V13H13ZM13 3V11H21V3Z"/>',
    "onglets": '<path stroke="none" transform="matrix(-1 0 0 1 24 0)" d="M21 3H3C1.9 3 1 3.9 1 5V19C1 20.1 1.9 21 3 21H21'
               'C22.1 21 23 20.1 23 19V5C23 3.9 22.1 3 21 3ZM21 19H3V5H13V9H21Z"/>',
}


def icone(nom, taille=20):
    """L'icône ``nom`` d'``ICONES``, dessinée en vecteurs à ``taille`` pixels (nette sur un écran HiDPI)."""
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#808080" stroke="#808080" stroke-width="1.6" '
           f'stroke-linecap="round" stroke-linejoin="round">{ICONES[nom]}</svg>')
    ratio = QApplication.instance().devicePixelRatio() if QApplication.instance() else 1
    image = QPixmap(round(taille * ratio), round(taille * ratio))
    image.fill(Qt.GlobalColor.transparent)
    peintre = QPainter(image)
    QSvgRenderer(QByteArray(svg.encode())).render(peintre)
    peintre.end()
    image.setDevicePixelRatio(ratio)
    return QIcon(image)


class BoutonIcone(QToolButton):
    """Un petit bouton de la barre d'une question, à droite : une icône seule, sans fond ni cadre, sa bulle pour libellé."""

    def __init__(self, nom, bulle):
        super().__init__()
        self.setIcon(icone(nom))
        self.setIconSize(QSize(20, 20))
        self.setToolTip(bulle)
        self.setAutoRaise(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("QToolButton { border: none; background: transparent; padding: 2px; }"
                           " QToolButton:hover { background: rgba(0, 0, 0, 0.08); border-radius: 4px; }"
                           " QToolButton:checked { background: rgba(0, 0, 0, 0.16); border-radius: 4px; }")
        self.voile = None  # le voile de sa question, percé à sa place : le bouton en peint la couleur sous son icône

    def paintEvent(self, evenement):
        # percé à travers le voile, le bouton montrerait le fond clair de la question en carré : il le refait au gris du
        # voile (l'utilisateur, 03/10/2026 : « le fond des petits boutons […] doit prendre la couleur du fond des questions
        # soumises ») ; un trou à la forme de l'icône seule aurait laissé au voile les clics entre ses traits
        if self.voile is not None and not self.voile.isHidden():  # caché (« Modifier ») : le fond clair revient
            peintre = QPainter(self)
            peintre.fillRect(self.rect(), self.voile.couleur)
            peintre.end()
        super().paintEvent(evenement)


class FenetreSignalement(QDialog):
    """La petite fenêtre où l'élève détaille un signalement : son texte va à ``envoye``, à la validation."""

    envoye = Signal(str)

    def __init__(self, parent, titre):
        super().__init__(parent)
        self.setWindowTitle(titre)
        d = QVBoxLayout(self)
        d.addWidget(QLabel(dire(f"<b>{titre}</b> : détaillez ici.")))
        self.texte = QPlainTextEdit()
        self.texte.setMinimumSize(380, 120)
        d.addWidget(self.texte)
        boutons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        boutons.button(QDialogButtonBox.StandardButton.Ok).setText("Envoyer")
        boutons.button(QDialogButtonBox.StandardButton.Cancel).setText("Annuler")
        boutons.accepted.connect(self.accept)
        boutons.rejected.connect(self.reject)
        d.addWidget(boutons)
        self.accepted.connect(lambda: self.envoye.emit(self.texte.toPlainText()))
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)


class Voile(QWidget):
    """Un gris un peu plus foncé que le fond, translucide, sur une question validée ou soumise : le fond fonce et le texte
    s'éclaircit d'un même geste. Posé sur le contenu de la zone défilante, pas sur la question : il en prend toute la
    largeur et descend jusqu'à la question suivante, voiles bout à bout ; ses boutons restent nets et cliquables, percés
    dans le voile (demande de l'utilisateur, 26/09/2026). Il retient les clics (ignorés, ils remontent au contenu, jamais
    aux champs dessous) ; la molette remonte de même jusqu'à la zone défilante. Il récrit par-dessus, net, ce qui est de
    la main du professeur (``manuscrits`` : texte et couleur), que le widget dessous garde transparent."""

    def __init__(self, parent):
        super().__init__(parent)
        self.couleur, self.manuscrits = QColor(), []
        self.hide()

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.fillRect(self.rect(), self.couleur)
        for texte, couleur in self.manuscrits:
            recrire(peintre, self, texte, couleur)

    @staticmethod
    def niveau(questions):
        """De combien le voile fonce le fond : 117 si ``questions`` sont toutes soumises, 110 si toutes soumises ou
        verrouillées au cadenas, 0 sinon (pas de voile). Le voile plus léger est celui de l'ancien bouton « traité », que
        le cadenas reprend (l'utilisateur, 04/10/2026) ; une question traitée sans cadenas n'en a pas (28/09/2026)."""
        return 117 if all(q.fermee for q in questions) else 110 if all(q.fermee or q.verrouillee for q in questions) else 0

    def teinter(self, niveau, visible=True):
        self.setVisible(bool(niveau) and visible)
        self.couleur = fond_sujet().darker(niveau or 100)
        self.couleur.setAlphaF(0.44)  # fond 251 → 241 (validée), 235 (soumise) ; texte noir → gris 100
        self.update()


def rond_a_la_main(peintre, zone, marge=(5, 3)):
    """Un rond autour de la zone, au stylo du peintre, penché de 2 px quelle que soit sa largeur : celui du correcteur
    (``Surimpression.entourer``) comme celui que l'élève pose sur une case (``TableEntourer``)."""
    peintre.save()
    peintre.translate(zone.center())
    peintre.rotate(-math.degrees(math.atan2(2, zone.width() / 2 + marge[0])))
    peintre.drawEllipse(QPointF(0, 0), zone.width() / 2 + marge[0], zone.height() / 2 + marge[1])
    peintre.restore()


class Surimpression(QWidget):
    """La correction d'une question à choix tracée à la main par-dessus, comme un professeur sur la copie (demande de
    l'utilisateur, 26/09/2026) : une rature oblique rouge sur une case fausse cochée (pas une croix, 28/09/2026), un rond
    vert autour d'une bonne, une flèche verte à gauche de chaque réponse exacte, et le commentaire (``feedback``) de chaque
    proposition à sa droite, de la couleur de son trait. Au-dessus du voile, qui la ternirait ; ``_poser_voile`` la pose
    avec lui. Transparente à la souris."""

    ROUGE, VERT = QColor("#d32f2f"), QColor(VERT_REPONSE)  # le vert vif des cours (demande de l'utilisateur, 26/09/2026)
    question = property(lambda self: self._question())  # référence faible : une forte ferait un cycle, que seul le ramasse-miettes
    # libère, n'importe quand, et Qt plante s'il détruit les widgets au milieu d'un de ses appels (tests_modele, 01/10/2026)

    def __init__(self, question):
        super().__init__(question)
        self._question, self.montree = weakref.ref(question), False
        self.fausses = None  # en seconde chance, les seules cases fausses cochées : ni flèche ni rond, la réponse reste à trouver
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.hide()

    # -- le geste du correcteur, commun aux surimpressions de tous les types

    def peintre(self):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.setBrush(Qt.BrushStyle.NoBrush)
        return peintre

    def stylo(self, peintre, couleur, epaisseur=2.5):
        peintre.setPen(QPen(couleur, epaisseur, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))

    def cadre(self, widget):
        """Le rectangle d'un widget de la question, dans les coordonnées de la surimpression."""
        return QRectF(QRect(widget.mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos(), widget.size()))

    def entourer(self, peintre, zone, couleur=None, marge=(5, 3)):
        """Un rond autour de la zone, vert par défaut, penché de 2 px quelle que soit sa largeur, comme tracé à la main."""
        self.stylo(peintre, couleur or self.VERT)
        rond_a_la_main(peintre, zone, marge)

    def raturer(self, peintre, gauche, droite, y):
        """Une rature rouge d'un bord à l'autre, à peine montante : pas une croix (28/09/2026)."""
        self.stylo(peintre, self.ROUGE)
        peintre.drawLine(QPointF(gauche - 3, y + 1), QPointF(droite + 3, y - 1))

    def barrer(self, peintre, depart, arrivee):
        """Un lien ou une arête faux, raturé d'un zigzag rouge en travers au quart de sa longueur (04/10/2026 : un seul trait
        se lisait mal sur une flèche) : pas au milieu, où deux traits croisés auraient leurs ratures en X. Six segments
        courts, pour que deux ratures voisines se mêlent moins ; plus serrés, le stylo de 2,5 px en fait une tache."""
        sens = arrivee - depart
        long = math.hypot(sens.x(), sens.y()) or 1
        milieu, le_long, travers = depart + sens * 0.25, sens * (3 / long), QPointF(-sens.y(), sens.x()) * (5 / long)
        self.stylo(peintre, self.ROUGE)
        peintre.drawPolyline(QPolygonF([milieu + le_long * (k - 3) + travers * (1 if k % 2 else -1) for k in range(7)]))

    def flecher(self, peintre, pointe):
        """Une flèche verte qui finit sur ``pointe`` : la bonne case oubliée, un trait de main à peine incliné."""
        self.stylo(peintre, self.VERT)
        peintre.drawLine(pointe + QPointF(-20, 1), pointe)
        peintre.drawPolyline(QPolygonF([pointe + QPointF(-7, -5), pointe, pointe + QPointF(-7, 5)]))

    def corriger_champ(self, peintre, champ, texte, juste, attendu, gauche=None):
        """Un champ d'une ligne corrigé comme un trou : ``texte``, ce que l'élève y lit, entouré de vert s'il est ``juste`` ;
        sinon barré en rouge et ``attendu`` écrit en rouge à sa suite (seul dans un champ vide). ``gauche`` : où le texte
        commence dans le champ, après le cadre et la marge d'un QLineEdit par défaut (2 px de plus, son ``horizontalMargin``)."""
        cadre, metrique = self.cadre(champ), QFontMetricsF(champ.font())
        if gauche is None:
            gauche = champ.style().pixelMetric(QStyle.PixelMetric.PM_DefaultFrameWidth, None, champ) + champ.textMargins().left() + 2
        gauche += cadre.left()
        ligne = cadre.top() + (cadre.height() - metrique.height()) / 2 + metrique.ascent()
        fin = gauche + metrique.horizontalAdvance(texte)
        if texte and juste:
            self.entourer(peintre, QRectF(gauche, ligne - metrique.ascent() * 0.8, fin - gauche, metrique.ascent()))
            return
        if texte:
            self.raturer(peintre, gauche, fin, ligne + metrique.tightBoundingRect(texte).center().y())
            fin += 10
        if attendu:
            self.ecrire(peintre, QPointF(fin, ligne), attendu, QFontInfo(champ.font()).pixelSize())

    @staticmethod
    def main(taille):
        """L'écriture du correcteur (Kalam) qui va avec un corps de ``taille`` pixels."""
        main = QFont(POLICE_MAIN)
        main.setPixelSize(round(taille * TAILLE_MAIN / TAILLE_POLICE))
        return main

    def ecrire(self, peintre, point, texte, taille, couleur=None, droite=False):
        """``texte`` écrit à la main, en rouge par défaut, à la taille d'écriture d'un corps de ``taille`` pixels, sur la
        ligne de base de ``point`` : à partir de lui, ou finissant sur lui si ``droite``."""
        main = self.main(taille)
        peintre.setFont(main)
        peintre.setPen(couleur or self.ROUGE)
        largeur = QFontMetricsF(main).horizontalAdvance(texte)
        peintre.drawText(point - QPointF(largeur if droite else 0, 0), texte)

    def paintEvent(self, evenement):
        q = self.question
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.setBrush(Qt.BrushStyle.NoBrush)
        coches = set(q._cochees())
        for i, b in enumerate(q.boutons):
            if self.fausses is not None and i not in self.fausses:
                continue
            case = indicateur(b)
            c = QPointF(b.mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos()) + QRectF(case).center()
            rayon = case.width() / 2 + 6.5  # le rond englobe la case, de 13 px à la souris comme au doigt (27/09/2026)
            juste = q.correcte(i)
            peintre.setPen(QPen(self.VERT if juste else self.ROUGE, 2.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                                Qt.PenJoinStyle.RoundJoin))
            if juste and i in coches:  # une bonne réponse cochée : le rond seul ; oubliée : la flèche seule (27/09/2026)
                peintre.save()
                peintre.translate(c)
                peintre.rotate(-8)
                peintre.drawEllipse(QPointF(0, 0), rayon, rayon * 0.85)
                peintre.restore()
            elif juste:
                self.flecher(peintre, c + QPointF(-case.width() / 2 - 4, 0))
            elif i in coches or self.fausses is not None:  # décochée depuis la seconde chance, la rature reste
                d = case.width() / 2 + 3.5
                peintre.drawLine(c + QPointF(-d, d), c + QPointF(d, -d))
            note = getattr(q, "notes", {}).get(i)
            if note:  # le Texte réserve la place, transparent : on l'écrit ici, au-dessus du voile
                texte = note.parentWidget().layout().itemAt(1).widget()
                # Kalam n'a pas les hauteurs de la police du corps : centrés, les deux textes n'ont pas la même ligne de
                # base ; le commentaire descend sur celle de la proposition (demande de l'utilisateur, 28/09/2026)
                decalage = texte.y() + ligne_de_base(texte) - note.y() - ligne_de_base(note)  # frères dans la rangée
                recrire(peintre, self, note, self.VERT if juste else self.ROUGE, decalage)


class SurimpressionTrous(Surimpression):
    """La même correction à la main sur les champs d'un texte à trous : la réponse juste entourée de vert, une fausse
    barrée en rouge (une rature, pas une croix, 28/09/2026) et le mot attendu écrit en rouge à sa suite s'il y a la place
    dans le champ, au-dessus sinon, comme dans une case de tableau ; un champ vide le reçoit seul. Plus rien n'est répété
    sous la question (règle commune du 04/10/2026 : la correction se fait en surimpression). Un trou sans réponse
    attendue (correction différée) reste nu."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        saisie = q._lire() or {}
        for n, champ in q.champs.items():
            trou, texte = q.trous[n], str(saisie.get(n, "")).strip()
            if trou.reponses is None:
                continue
            ligne_edit = champ.lineEdit() if isinstance(champ, QComboBox) else champ  # là où le mot est écrit
            cadre, metrique = self.cadre(ligne_edit), QFontMetricsF(ligne_edit.font())
            ligne = cadre.top() + (cadre.height() - metrique.height()) / 2 + metrique.ascent()
            largeur = metrique.horizontalAdvance(texte)
            if ligne_edit.alignment() & Qt.AlignmentFlag.AlignHCenter:
                debut = cadre.center().x() - largeur / 2
            else:  # où Qt écrit le texte d'un champ : après le cadre et la marge, à 2 px de plus (``horizontalMargin``)
                debut = cadre.left() + ligne_edit.style().pixelMetric(QStyle.PixelMetric.PM_DefaultFrameWidth, None, ligne_edit) + \
                    ligne_edit.textMargins().left() + 2
            debut = max(debut, cadre.left() + 3)  # un mot plus long que le champ y défile : le trait reste dans le champ
            largeur = min(largeur, cadre.right() - 3 - debut)
            if texte and q.trou_juste(n, texte):  # le rond autour du mot, comme une réponse courte
                self.entourer(peintre, QRectF(debut, ligne - metrique.ascent() * 0.8, largeur, metrique.ascent()))
                continue
            attendu, taille = str(trou.reponses[0]), QFontInfo(ligne_edit.font()).pixelSize()
            main = QFont(POLICE_MAIN)
            main.setPixelSize(round(taille * TAILLE_MAIN / TAILLE_POLICE))
            ecriture = QFontMetricsF(main)
            if not texte:
                self.ecrire(peintre, QPointF(cadre.center().x() - ecriture.horizontalAdvance(attendu) / 2, ligne), attendu, taille)
                continue
            milieu = ligne + metrique.tightBoundingRect(texte).center().y()
            self.raturer(peintre, debut, debut + largeur, milieu)
            if debut + largeur + 8 + ecriture.horizontalAdvance(attendu) <= cadre.right():
                self.ecrire(peintre, QPointF(debut + largeur + 8, ligne), attendu, taille)
            else:  # juste au-dessus de la rature, sans sortir du champ : le mot raturé se lit encore dessous
                self.ecrire(peintre, QPointF(cadre.center().x() - ecriture.horizontalAdvance(attendu) / 2,
                                             max(milieu - 5, cadre.top() + ecriture.capHeight() - 1)), attendu, taille)


class SurimpressionCourte(Surimpression):
    """La correction à la main d'une réponse courte, comme celle d'un trou (04/10/2026) : la réponse juste entourée de
    vert, une fausse barrée en rouge et la réponse attendue écrite en rouge à sa suite, dans le champ ; un champ vide
    la reçoit seule. Les autres formes acceptées ne s'écrivent pas : une seule réponse, comme le professeur sur la copie."""

    def paintEvent(self, evenement):
        q = self.question
        if q.etapes:  # un calcul justifié : chacun de ses trois champs corrigé à part (``noyau.ReponseCourte.notes_etapes``)
            peintre, notes, justes = self.peintre(), q.notes_etapes(q.saisie), q.juste()
            for etape, champ in q.champs_etapes.items():
                texte = champ.text().rstrip()
                self.corriger_champ(peintre, champ, texte, bool(texte) and notes[etape] == 1, justes[etape])
            return
        texte = q.champ.text().rstrip()
        self.corriger_champ(self.peintre(), q.champ, texte, bool(texte) and q.corriger(texte)[0] == 1, q.juste())

class SurimpressionConversion(Surimpression):
    """La correction à la main sur la grille d'une ``Conversion`` (demande de l'utilisateur, 03/10/2026) : ce qui est faux
    barré en rouge — seulement le chiffre, l'exposant ou la base fautifs quand le reste est juste —, ce qu'il fallait écrire
    en rouge à gauche de la rature s'il y a la place dans la case, au-dessus sinon, ce qui manque écrit en rouge dans sa
    case, et le bon résultat entouré de vert : celui de l'élève s'il est juste, sinon celui que le correcteur a réécrit.
    Le détail des cases vient de ``noyau.Conversion.annoter`` ; la grille corrigée ouvre les cases qu'il faut (``corrigee``)."""

    def paintEvent(self, evenement):
        q = self.question
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.setBrush(Qt.BrushStyle.NoBrush)
        for grille in filter(None, [q.grilles and q.grille, q.grille_bis]):
            if grille.isVisible() and grille.corrigee:  # au rattrapage, la première seule
                self._corriger(peintre, grille)

    def _corriger(self, peintre, grille):
        origine = QPointF(grille.mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos())
        for cle, (etat, ratures, ajout) in grille.question.annoter(Conversion._ecrites(grille)).items():
            champ = grille.champs.get(cle)
            if not isinstance(champ, ChampConversion) or not champ.isVisible():
                continue
            texte, metrique = champ.text(), QFontMetricsF(champ.font())
            main = QFont(POLICE_MAIN)
            main.setPixelSize(round(champ.font().pixelSize() * TAILLE_MAIN / TAILLE_POLICE))
            ecriture = QFontMetricsF(main)
            # où Qt écrit le texte du champ : entre ses marges, à 2 px de plus (``horizontalMargin`` de QLineEdit)
            cadre = QRectF(champ.geometry()).translated(origine)
            gauche = cadre.left() + champ.textMargins().left() + 2
            droite = cadre.right() + 1 - champ.textMargins().right() - 2
            alignement = champ.alignment()
            # la ligne de base : en haut, sous la marge que ``caler`` a posée (et la marge verticale de 1 px de Qt) ; le
            # centre supposé tombait trop bas quand les métriques diffèrent de celles du poste (TODO Conversion, Q2)
            ligne = cadre.top() + champ.textMargins().top() + 1 + QFontMetrics(champ.font()).ascent() \
                if alignement & Qt.AlignmentFlag.AlignTop else cadre.top() + (cadre.height() - metrique.height()) / 2 + metrique.ascent()
            placer = lambda largeur: droite - largeur if alignement & Qt.AlignmentFlag.AlignRight else \
                (gauche + droite - largeur) / 2 if alignement & Qt.AlignmentFlag.AlignHCenter else gauche  # noqa: E731
            debut = placer(metrique.horizontalAdvance(texte))
            x = lambda i: debut + metrique.horizontalAdvance(texte[:i])  # noqa: E731
            ecrites = []  # ce que le correcteur a écrit, en rectangles : le résultat réécrit s'y entoure

            def ecrire(chaine, gx, base):
                peintre.setFont(main)
                peintre.setPen(self.ROUGE)
                peintre.drawText(QPointF(gx, base), chaine)
                ecrites.append(QRectF(gx, base - ecriture.ascent() * 0.8, ecriture.horizontalAdvance(chaine), ecriture.ascent()))

            if etat == "manque":  # centrée dans la case : ``placer`` suit la marge d'une case VIDE (celle du curseur, alignée à
                # droite), et « + 32 » sortait de sa case par la gauche (l'utilisateur, 04/10/2026)
                largeur = ecriture.horizontalAdvance(ajout)
                ecrire(ajout, max(cadre.left() + 2, cadre.center().x() - largeur / 2), ligne)
            for i, j, correction in ratures:
                boite = metrique.tightBoundingRect(texte[i:j])
                milieu = ligne + boite.center().y()
                peintre.setPen(QPen(self.ROUGE, 2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                peintre.drawLine(QPointF(x(i) - 2, milieu + 1), QPointF(x(j) + 2, milieu - 1))
                if correction:
                    largeur = ecriture.horizontalAdvance(correction)
                    # à gauche, si rien ne précède (pas même un « + »), à un chiffre d'écart : collée, « 64 » devant un « 0 »
                    # barré se lisait « 640 », et « 1×2¹ » devant un « 1 », « 1×2¹1 » (vu dans le lecteur web, 04/10/2026)
                    ecart = metrique.horizontalAdvance("0")
                    if not texte[:i].strip() and x(i) - ecart - largeur >= cadre.left() + 2:
                        ecrire(correction, x(i) - ecart - largeur, ligne)
                    else:  # au-dessus de la rature
                        ecrire(correction, (x(i) + x(j) - largeur) / 2, ligne + boite.top() - 3)
            if ajout and etat == "faux":  # la base oubliée, derrière le nombre
                ecrire(ajout, x(len(texte.rstrip())) + 1, ligne)
            if cle == "resultat":  # le bon résultat, entouré : celui de l'élève, ou la réécriture qui le remplace
                tout = QRectF(x(0), ligne - metrique.ascent() * 0.75, x(len(texte.rstrip())) - x(0), metrique.ascent())
                zone = ecrites[0] if etat == "manque" or ratures and ratures[0][0] == 0 and ratures[0][2] else \
                    functools.reduce(QRectF.united, ecrites, tout)
                peintre.setPen(QPen(self.VERT, 2.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                peintre.save()
                peintre.translate(zone.center())
                peintre.rotate(-math.degrees(math.atan2(2, zone.width() / 2 + 6)))
                peintre.drawEllipse(QPointF(0, 0), zone.width() / 2 + 7, zone.height() / 2 + 5)
                peintre.restore()



class SurimpressionTableau(Surimpression):
    """La correction d'un tableau écrite à la main dans ses cases (demande de l'utilisateur, 04/10/2026 : « la correction
    du tableau 1 doit se faire en surimpression, pas en dessous ») : une case fausse barrée en rouge, la valeur attendue
    écrite en rouge à sa droite s'il y a la place dans la case, au-dessus sinon ; une case vide reçoit la valeur attendue ;
    une case juste reste nue, comme les cases intermédiaires d'une ``Conversion``. Seulement quand chaque case a une
    seule écriture attendue (``Tableau.surimposee``) : sinon la correction reste le tableau écrit dessous."""

    def paintEvent(self, evenement):
        q = self.question
        if q.simulation:
            return self.raturer_coup()
        if not q.surimposee():
            return
        if q.a_entourer:
            return self.corriger_entourees()
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        saisie, juste = q._lire() or {}, q.juste()
        vue = q.table.viewport()
        origine = QPointF(vue.mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos())
        main = QFont(POLICE_MAIN)
        main.setPixelSize(round(QFontInfo(q.table.font()).pixelSize() * TAILLE_MAIN / TAILLE_POLICE))  # même taille partout
        self.encadrer(peintre, origine, juste)  # d'abord : la correction rouge s'écrit par-dessus
        bits = QFont(main)
        bits.setLetterSpacing(QFont.SpacingType.PercentageSpacing, ESPACEMENT_BITS)  # écrits comme dans la case
        for n, case in q.champs.items():
            texte = str(saisie.get(n, "")).strip()
            if texte and q.trou_juste(n, texte):
                continue
            cadre = QRectF(q.table.visualItemRect(case)).translated(origine)
            police = case.font().resolve(q.table.font())  # la vue complète la police de la case avec la sienne
            metrique = QFontMetricsF(police)
            attendu = str(juste.get(n, ""))
            peintre.setFont(bits if q.cellules[n].base == 2 else main)
            ecriture = QFontMetricsF(peintre.font())
            ligne = cadre.top() + (cadre.height() - metrique.height()) / 2 + metrique.ascent()
            if not texte:
                peintre.setPen(self.ROUGE)
                if q.cellules[n].base == 2:
                    self.ecrire_bits(peintre, main, case, cadre, attendu, ligne)
                else:
                    peintre.drawText(QPointF(cadre.center().x() - ecriture.horizontalAdvance(attendu) / 2, ligne), attendu)
                continue
            largeur = metrique.horizontalAdvance(texte)
            debut, fin = cadre.center().x() - largeur / 2, cadre.center().x() + largeur / 2 + 3  # + l'indice, d'une autre police
            trou = q.cellules[n]
            if trou.base and noyau.base_manquante(trou.base, texte) and \
                    noyau.note_trou(trou, texte, noyau.connus_du_trou(q.cellules, n, q.choix)) == 0.5:
                peintre.setPen(self.ROUGE)  # le bon nombre sans sa base : la base seule, ajoutée derrière lui
                peintre.drawText(QPointF(fin, ligne), attendu[len(attendu.rstrip("₀₁₂₃₄₅₆₇₈₉")):])
                continue
            milieu = ligne + metrique.tightBoundingRect(texte).center().y()
            peintre.setPen(QPen(self.ROUGE, 2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            peintre.drawLine(QPointF(debut - 3, milieu + 1), QPointF(fin + 1, milieu - 1))
            peintre.setPen(self.ROUGE)
            dessus = max(milieu - 5, cadre.top() + ecriture.capHeight() - 1)
            if trou.base == 2:  # au-dessus de la rature, chaque bit dans le cadre de sa colonne
                self.ecrire_bits(peintre, main, case, cadre, attendu, dessus)
            elif fin + 6 + ecriture.horizontalAdvance(attendu) <= cadre.right() - 2:
                peintre.drawText(QPointF(fin + 6, ligne), attendu)
            else:  # juste au-dessus de la rature, sans sortir de la case : le texte pâli du dessous se lit encore
                peintre.drawText(QPointF(cadre.center().x() - ecriture.horizontalAdvance(attendu) / 2, dessus), attendu)

    def raturer_coup(self):
        """``simulation`` : la ligne du premier coup interdit raturée d'un bord à l'autre (l'utilisateur, 04/10/2026 : « rature
        la ligne du premier coup interdit ») ; les suivantes, jouées depuis un état qui n'a plus de sens, restent nues, et
        rien n'est raturé quand tous les coups sont permis, le but seul manquant (la correction le dit sous la grille)."""
        q = self.question
        r = q.coup_interdit(q._lire() or {})
        if r is None or r >= q.table.rowCount():
            return
        t, peintre = q.table, self.peintre()
        origine = QPointF(t.viewport().mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos())
        derniere = t.columnCount() - 1
        self.raturer(peintre, origine.x() + t.columnViewportPosition(0) + 4,
                     origine.x() + t.columnViewportPosition(derniere) + t.columnWidth(derniere) - 4,
                     origine.y() + t.rowViewportPosition(r) + t.rowHeight(r) / 2)

    def corriger_entourees(self):
        """``a_entourer`` : une case bien entourée l'est une seconde fois en vert, une case entourée à tort est raturée,
        une bonne case oubliée reçoit une flèche verte. En seconde chance, les ratures seules."""
        q, peintre = self.question, self.peintre()
        origine = QPointF(q.table.viewport().mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos())
        for reference in sorted(q.table.entourees | set(q.a_entourer)):
            zone = q.table.zone(reference).translated(origine)
            if reference not in q.a_entourer:
                self.raturer(peintre, zone.left() - 5, zone.right() + 5, zone.center().y())
            elif self.fausses is None:
                if reference in q.table.entourees:
                    self.entourer(peintre, zone, marge=(9, 6))
                else:
                    self.flecher(peintre, QPointF(zone.left() - 4, zone.center().y()))

    def abscisses(self, case, cadre, texte):
        """Où la case écrit chaque caractère de ``texte`` (centré, dans sa police espacée) : l'abscisse de son début et
        la largeur de son dessin, espacement retiré. Les cadres de ``encadrer`` et les bits rouges s'y posent tous : une
        seule colonne de chiffres par colonne du tableau, quoi que l'élève ait écrit (case vide, sans base, fausse)."""
        metrique = QFontMetricsF(case.font().resolve(self.question.table.font()))
        debut = cadre.center().x() - metrique.horizontalAdvance(texte) / 2
        return [(debut + metrique.horizontalAdvance(texte[:k]), metrique.horizontalAdvance(c) * 100 / ESPACEMENT_BITS)
                for k, c in enumerate(texte)]

    def ecrire_bits(self, peintre, main, case, cadre, attendu, ligne):
        """Un nombre binaire attendu écrit à la main, chaque caractère centré à la place que la case lui donnerait."""
        ecriture = QFontMetricsF(main)
        peintre.setFont(main)
        for c, (x, largeur) in zip(attendu, self.abscisses(case, cadre, attendu)):
            peintre.drawText(QPointF(x + (largeur - ecriture.horizontalAdvance(c)) / 2, ligne), c)

    COULEURS_BITS = ("#00b0f0", "#92d050", "#d349f5", "#f59949")  # celles du cours, du bit de poids faible au quatrième

    def encadrer(self, peintre, origine, juste):
        """Dans une colonne qui compte en binaire (des bits attendus, de même longueur, d'entiers consécutifs), encadre
        chaque suite verticale d'au moins deux bits identiques, d'une couleur par rang de bit : le bit de poids faible
        alterne, le suivant change tous les deux, puis tous les quatre… (l'utilisateur, 04/10/2026 : « encadrer les
        séries de bits identiques verticalement avec des cadres de couleur »). Comme dans le cours : le bit de poids
        faible encadré seul à chaque ligne, en bleu, puis vert, violet, orange. Les cadres se posent sur la colonne de
        chiffres de ``abscisses``, la même à chaque ligne."""
        q = self.question
        colonnes = {}
        for n, case in q.champs.items():
            r, c = map(int, n.split(","))
            colonnes.setdefault(c, []).append((r, n, case))
        for cases in colonnes.values():
            cases.sort()
            chiffres = [str(juste.get(n, "")).rstrip("₀₁₂₃₄₅₆₇₈₉") for _, n, _ in cases]
            if len(cases) < 2 or any(q.cellules.get(n) is None or q.cellules[n].base != 2 for _, n, _ in cases) or \
                    any(not re.fullmatch("[01]+", t) or len(t) != len(chiffres[0]) for t in chiffres) or \
                    any(int(b, 2) - int(a, 2) != 1 for a, b in zip(chiffres, chiffres[1:])):
                continue
            cadres = [QRectF(q.table.visualItemRect(case)).translated(origine) for _, _, case in cases]
            colonnes_bits = self.abscisses(cases[0][2], cadres[0], str(juste.get(cases[0][1], "")))
            peintre.setBrush(Qt.BrushStyle.NoBrush)
            for k, (x, chiffre) in enumerate(colonnes_bits[:len(chiffres[0])]):
                rang = len(chiffres[0]) - 1 - k
                peintre.setPen(QPen(QColor(self.COULEURS_BITS[rang % len(self.COULEURS_BITS)]), 1.6))
                marge = chiffre * (ESPACEMENT_BITS - 100) / 200 - 2.6  # deux cadres voisins : 5 px d écart
                i = 0
                while i < len(chiffres):
                    j = i
                    while j + 1 < len(chiffres) and chiffres[j + 1][k] == chiffres[i][k]:
                        j += 1
                    if j > i or rang == 0:
                        peintre.drawRoundedRect(QRectF(x - marge, cadres[i].top() + 2, chiffre + 2 * marge,
                                                       cadres[j].bottom() - cadres[i].top() - 4), 3, 3)
                    i = j + 1


DIFFEREE = False  # vrai dans ``differee`` : une question construite ne bâtit ses widgets qu'à la demande (``Question.batir``)


@contextlib.contextmanager
def differee():
    """Les questions construites dans ce bloc remettent leurs widgets à ``Question.batir`` : le paquet bâtit l'écran
    visible, puis le reste en tâche de fond (``Paquet.chantier``). Les 218 questions de python_tp coûtaient 2,2 s
    sur les 5,4 s de l'ouverture dans le navigateur (02/10/2026)."""
    global DIFFEREE
    DIFFEREE = True
    try:
        yield
    finally:
        DIFFEREE = False


class Question(noyau.Question, QWidget):
    """Le widget d'une question : l'énoncé, le corps propre à chaque type (``_corps``, ``_lire``/``_ecrire``), la
    justification, les indices et la barre de validation. La logique est celle de ``noyau.Question``."""

    changee = Signal()  # la question a changé d'état (soumise, validée, figée) : à enregistrer
    epinglage = Signal(bool)  # l'élève épingle la question à gauche, ou l'en décroche (``Paquet._epingler``)
    notee = parentheses = False  # voir afficher_bareme
    batie = True  # faux : construite sous ``differee``, ses widgets attendent ``batir``
    # Non bâtie, ces crochets ne font rien (la construction refait ce qu'ils font) ou sont notés pour être rejoués, dans
    # l'ordre, une fois bâtie ; le reste du paquet lit l'état en données (``saisie``, ``justifie``, ``fermee``…)
    PASSIFS, REJOUES = ("mettre_a_jour", "_montrer_enonce", "afficher_bareme"), ("_dire", "_annoter", "afficher_contexte")

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        self.entrees, self.cases, self.voile, self.surimpression = [], [], None, None
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)  # jamais plus haute que son contenu
        exterieur = QHBoxLayout(self)  # le numéro dans sa colonne, le reste en retrait : comme sur la copie
        exterieur.setContentsMargins(0, 12, 0, 24)  # des questions bien séparées : la correction reste près de la sienne (07/10/2026)
        self.rang = QLabel()
        exterieur.addWidget(self.rang, 0, Qt.AlignmentFlag.AlignTop)
        self.disposition = QVBoxLayout()
        exterieur.addLayout(self.disposition, 1)
        super().__init__(*args, **kw)

    def _montrer_enonce(self):
        texte = self.enonce_simplifie if self.reformulee and self.enonce_simplifie else self.enonce
        anciennes, self.cases = self.cases, []  # reprises par _case : cocher regrise le texte, pas de quoi refaire les cases
        self.texte_enonce.definir(f"**{self.marque}** {texte}" if self.marque else texte,
                                  coche=(lambda: self._case(anciennes)) if self.projet else None)
        for case in anciennes[len(self.cases):]:  # l'énoncé reformulé a moins d'actions
            del self.texte_enonce.incrustes[case.objectName()]
            self.entrees.remove(case)
            case.deleteLater()
        self.liens_poses = self.liens_enonce()
        self.texte_enonce.liens = {href: action for href, _, _, action in self.liens_poses}
        if self.liens_poses:  # au bout du dernier paragraphe, ou sous un bloc final (code, tableau), hors de lui
            curseur = QTextCursor(self.texte_enonce.document().rootFrame().lastCursorPosition())
            curseur.insertHtml("&nbsp;" + "&nbsp;".join(f'<a href="{href}" style="text-decoration:none"><i style="color:{couleur}">({mot})</i></a>'
                                                         for href, mot, couleur, _ in self.liens_poses))

    def liens_enonce(self):
        """Reformuler : un mot en italique entre parenthèses au bout de l'énoncé, en violet, au lieu d'un bouton (demande de
        l'utilisateur, 28/09/2026 : moins de boutons par question ; l'aide, d'abord un lien voisin, est redevenue un bouton
        le 30/09/2026). (href, mot, couleur, action)."""
        if self.enonce_simplifie:
            return [("reformuler", "énoncé d'origine" if self.reformulee else "reformuler", VIOLET_REFORMULER, self.reformuler)]
        return []

    def _case(self, anciennes):
        """La case à cocher d'une action (puce « - ») de l'énoncé d'un projet, à la place de sa puce : une liste de
        choses à faire, dont l'état, ``cochees``, s'enregistre avec la copie. Celle du même rang dans l'énoncé
        précédent (``anciennes``) est reprise."""
        n = len(self.cases)
        if n < len(anciennes):
            case = anciennes[n]
        else:
            case = Case(self.texte_enonce.viewport())
            case.setObjectName(f"coche{n}")
            case.setChecked(n in self.cochees)
            case.toggled.connect(self._cocher)
            case.hide()
            self.texte_enonce.incrustes[f"coche{n}"] = case
            self.entrees.append(case)  # inactive comme la saisie : sous le voile, ou grisée avant que la question ne soit posée
        self.cases.append(case)
        return cellule(f'<a name="coche{n}">&nbsp;</a>', LARGEUR_COCHE), n in self.cochees

    def _cocher(self):
        self.cochees = [n for n, case in enumerate(self.cases) if case.isChecked()]
        self.changee.emit()
        self._montrer_enonce()  # le texte d'une action cochée se grise (demande de l'utilisateur, 24/09/2026)

    def avancement(self):
        """La part faite de la question, de 0 à 1 : tout dès qu'elle est validée ou soumise ; avant, dans un projet,
        la part de ses actions cochées (demande de l'utilisateur, 24/09/2026 : « prendre en compte ces cases cochées
        pour monitorer l'avancement »)."""
        if self.repondue or self.fermee:
            return 1
        return len(self.cochees) / len(self.cases) if self.cases else 0

    def numeroter(self, numero=None):
        """« 1. » dans la colonne de gauche, comme sur la copie (demande de l'utilisateur, 26/09/2026)."""
        super().numeroter(numero)
        self.rang.setText(f"<b>{numero}.</b>" if numero else "")
        self.rang.setVisible(bool(numero))  # une sous-question n'a pas de colonne : sa lettre ouvre son énoncé

    def afficher_bareme(self):
        """À droite de l'énoncé, en italique comme sur la copie : « ____ / 1 point », la place de la note, que la
        note obtenue remplace une fois la question soumise, si le sujet montre la correction (``notee``). Entre
        parenthèses pour une sous-question : le détail du total, pas des points en plus. La note obtenue en vert si elle
        est entière, en rouge sinon, le barème qui suit toujours gris (demandes de l'utilisateur, 26/09/2026)."""
        if self.sous_questions:
            texte = points_txt(self.total()).replace(" ", "&nbsp;")
        elif self.notee and self.fermee and self.obtenu is not None:  # la justification a son propre barème
            couleur = (Surimpression.VERT if self.obtenu >= self.points else Surimpression.ROUGE).name()
            texte = (f"<span style='color:{couleur}; font-family:{POLICE_MAIN}; font-size:{TAILLE_MAIN}pt; "
                     f"font-style:normal'>{self.obtenu:g}</span>&nbsp;/&nbsp;{points_txt(self.points)}")  # le barème reste gris
        else:
            texte = A_NOTER + points_txt(self.total()).replace(" ", "&nbsp;")
        self.gris.setText(f"<i style='color:gray'>{f'({texte})' if self.parentheses else texte}</i>")

    def __getattr__(self, nom):
        if vars(self).get("batie") is False and not nom.startswith("__"):
            self.batir()  # un widget demandé avant d'être bâti : il l'est, tout de suite
            return getattr(self, nom)
        return super().__getattr__(nom)

    @property
    def saisie(self):  # non bâtie, celle qu'elle a reçue : ``_construire`` l'écrirait dans ses widgets, telle quelle
        return noyau.Question.saisie.fget(self) if self.batie else None if self.sous_questions else self._depart

    @saisie.setter
    def saisie(self, valeur):
        if self.batie:
            noyau.Question.saisie.fset(self, valeur)
        else:
            self._depart = valeur

    def _construire(self):
        if not DIFFEREE:
            return self._batir()
        self.batie, self.rejouer = False, []
        for nom in self.PASSIFS:
            setattr(self, nom, lambda *_: None)
        for nom in self.REJOUES:
            setattr(self, nom, lambda *args, nom=nom: self.rejouer.append((nom, args)))

    def batir(self):
        """Les widgets d'une question construite sous ``differee`` (ceux de ses sous-questions d'abord, qu'elle range),
        puis ce qui lui a été demandé d'ici là."""
        if self.batie:
            return
        for sq in self.sous_questions:
            sq.batir()
        for nom in (*self.PASSIFS, *self.REJOUES):
            del self.__dict__[nom]
        self.batie = True
        self._batir()
        for nom, args in self.rejouer:
            getattr(self, nom)(*args)

    def _batir(self):
        """L'énoncé, le corps, la barre de validation, puis la saisie et l'état de session relus (``noyau``)."""
        d = self.disposition
        self.numeroter(self.numero)  # déjà numérotée par le paquet si elle a attendu (``differee``)
        self.texte_enonce, self.gris = Texte(), QLabel()
        ligne = QHBoxLayout()
        ligne.addWidget(self.texte_enonce, 1)
        ligne.addWidget(self.gris, 0, Qt.AlignmentFlag.AlignTop)
        d.addLayout(ligne)
        self.afficher_bareme()
        self._montrer_enonce()
        self._corps(d)
        if not self.sous_questions:
            if self.justification:
                d.addWidget(Texte(f"**Justification** ({points_txt(self.justification.points)}) : {self.justification.consigne}", inline=True))
                self.justif = hauteur(QPlainTextEdit(), 3)
                d.addWidget(self.justif)
                self.entrees.append(self.justif)
            barre = Rangee(12)  # les boutons bien séparés (l'utilisateur, 02/10/2026)
            self.bouton_aide, self.bouton_indice, self.bouton_soumettre, self.bouton_modifier = (
                BoutonEgal("Aide"), BoutonEgal(""), BoutonEgal("Soumettre"), BoutonEgal("Modifier"))
            self.bouton_aide.setToolTip("Une piste pour démarrer, sans perdre de points.")
            for b in (self.bouton_soumettre, self.bouton_modifier, self.bouton_aide, self.bouton_indice):
                barre.addWidget(b)  # tous regroupés à gauche, sous la question (l'utilisateur, 30/09/2026)
            # tout à droite, de petites icônes : le cadenas, puis écrire au professeur (l'utilisateur, 03/10/2026)
            barre.addStretch()
            self.epingle = BoutonIcone("epingle", "")
            self.epingle.setCheckable(True)
            self.epingle.toggled.connect(self._epingle)
            self._bulle_epingle(False)  # sans ``epinglage`` : une question bâtie en tâche de fond n'a rien à décrocher
            self.epingle.setVisible(self.sert_aux_suivantes)  # ``epingler_possible``
            barre.addWidget(self.epingle)
            self.cadenas = BoutonIcone("ouvert", "")
            self.cadenas.clicked.connect(lambda: self.verrouiller())
            barre.addWidget(self.cadenas)
            self.icones = [self.epingle, self.cadenas]
            for sorte, titre in self.SIGNALEMENTS.items():
                b = BoutonIcone(sorte, titre)
                b.clicked.connect(lambda _=False, s=sorte, t=titre: self.ouvrir_signalement(s, t))
                barre.addWidget(b)
                self.icones.append(b)
            d.addLayout(barre)
            self.barre = barre
            # sous les boutons, l'aide et les indices puis la correction (30/09/2026), décollés des boutons d'un seul écart :
            # porté par aucun texte, il n'existe que s'il y a une écriture sous la question (l'utilisateur, 07/10/2026)
            self.zone_indices = QVBoxLayout()
            self.zone_indices.setContentsMargins(0, round(TAILLE_POLICE * 0.4), 0, 0)  # rien de paru : pas d'écart
            d.addLayout(self.zone_indices)
            self.voile, self.sous_voile = Voile(self), []  # ``_poser_voile`` le déplace sur le contenu qui défile
            self.nets = (self.bouton_soumettre, self.bouton_modifier, self.bouton_aide, self.bouton_indice, *self.icones)
            for b in self.nets:
                b.installEventFilter(self)  # un bouton qui apparaît ou se déplace : le trou du voile le suit
            self.retour = Texte()
            self.zone_indices.addWidget(self.retour)
            self.bouton_soumettre.clicked.connect(self.soumettre)
            self.bouton_modifier.clicked.connect(self.rouvrir)
            self.bouton_indice.clicked.connect(self.debloquer)
            self.bouton_aide.clicked.connect(self.aider)
        palette = QPalette()  # seul le fond des boutons est résolu, le reste s'hérite ; bouton par bouton : sous la feuille
        palette.setColor(QPalette.ColorRole.Button, palette.button().color().darker(104))  # de style de la zone qui défile,
        for b in self.findChildren(QPushButton):  # celle de la question ne se propage pas. À peine plus foncés que ceux
            if not isinstance(b, BoutonEgal):  # de l'en-tête (demande de l'utilisateur, 26/09/2026) ; ceux de la barre
                b.setPalette(palette)  # ont le leur (``BoutonEgal``)
        super()._construire()

    def afficher_contexte(self, markdown):
        super().afficher_contexte(markdown)
        self.disposition.insertWidget(0, Texte(markdown))

    def epingler_possible(self, oui):
        super().epingler_possible(oui)
        if "epingle" in vars(self):
            self.epingle.setVisible(oui)

    def _bulle_epingle(self, epinglee):
        self.epingle.setToolTip("Remettre la question à sa place" if epinglee else
                                "Épingler la question à gauche, pour l'avoir sous les yeux pendant les autres")

    def _epingle(self, epinglee):
        self._bulle_epingle(epinglee)
        self.epinglage.emit(epinglee)

    def ouvrir_signalement(self, sorte, titre):
        fenetre = FenetreSignalement(self, titre)
        fenetre.envoye.connect(lambda texte: self.signaler(sorte, texte))
        fenetre.open()  # sans boucle d'attente : le navigateur n'en a pas

    def _dire(self, markdown, couleur=""):
        super()._dire(markdown, couleur)
        self._styler_retour()
        self.retour.definir(markdown, self._trou_corrige, manuscrit=bool(couleur))
        # en Kalam, dont l'interligne est très haut, lignes et paragraphes resserrés comme sur le corrigé imprimé (demande de
        # l'utilisateur, 28/09/2026 : « Ce n'est pas la bonne réponse » trop loin de « Vous pouvez réessayer ») ; l'écart
        # avec les boutons est celui de ``zone_indices``
        document = self.retour.document()
        if couleur:
            curseur, bloc = QTextCursor(document), document.begin()
            while bloc.isValid():
                forme = bloc.blockFormat()
                forme.setLineHeight(85, QTextBlockFormat.LineHeightTypes.ProportionalHeight.value)
                forme.setTopMargin(0)
                forme.setBottomMargin(TAILLE_POLICE * 0.3)
                curseur.setPosition(bloc.position())
                curseur.setBlockFormat(forme)
                bloc = bloc.next()
        self._prevoir_voile()  # une correction écrite à la main passe au-dessus du voile

    def _styler_retour(self, couleur=None):
        """Le retour en ``couleur`` (``transparent`` : le voile l'écrit) ; en rouge ou en vert, la main du professeur."""
        couleur = couleur or self.dit[1]
        style = ("QTextBrowser { background: transparent; "
                 + (f"color: {couleur}; font-family: {POLICE_MAIN}; font-size: {TAILLE_MAIN}pt;" if couleur else "") + " }")
        if self.retour.styleSheet() != style:  # un voile reposé à chaque déplacement : pas de feuille réappliquée pour rien
            self.retour.setStyleSheet(style)

    ecrits = ()  # les autres textes de correction de la question, (Texte, couleur) : récrits au-dessus du voile comme le retour

    def _styler_ecrits(self, voilee):
        """Chaque texte de ``ecrits`` dans sa couleur, transparent sous un voile qui l'écrit lui-même (règle commune du
        04/10/2026 : une correction n'est jamais voilée, au premier essai comme au second)."""
        for texte, couleur in self.ecrits:
            style = (f"QTextBrowser {{ background: transparent; color: {'transparent' if voilee else couleur};"
                     f" font-family: {POLICE_MAIN}; font-size: {TAILLE_MAIN}pt; }}")
            if texte.styleSheet() != style:
                texte.setStyleSheet(style)

    def _montrer_indice(self, markdown, tete=False):
        texte = Texte(markdown, manuscrit=True)  # l'aide et les indices, écrits à la main comme une piste du professeur,
        # « Aide » ou « Indice » seul en gras (l'utilisateur, 30/09/2026)
        texte.setStyleSheet(f"QTextBrowser {{ background: transparent; font-family: {POLICE_MAIN}; font-size: {TAILLE_MAIN}pt; }}")
        self.zone_indices.insertWidget(0 if tete else self.zone_indices.count() - 1, texte)  # au-dessus de la correction

    def montrer(self, visible):
        super().montrer(visible)
        self.setVisible(visible)
        if self.voile and not visible:  # posé hors de la question, il ne se cache pas avec elle
            self.voile.hide()

    @property
    def justifie(self):
        if not self.justification:
            return ""
        return self.justif.toPlainText() if self.batie else self._justifie_depart

    @justifie.setter
    def justifie(self, texte):
        if not self.batie:
            self._justifie_depart = texte
        elif self.justification:
            self.justif.setPlainText(texte)

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.Move and self.sous_voile and objet is self.sous_voile[-1]:
            return False  # le contenu qui défile emporte le voile avec lui : rien à recalculer à chaque cran de molette
        if evenement.type() in (QEvent.Type.Move, QEvent.Type.Resize, QEvent.Type.Show, QEvent.Type.Hide):
            self._prevoir_voile()
        return False

    def _prevoir_voile(self):
        if not vars(self).get("voile_prevu"):
            self.voile_prevu = True  # un redimensionnement en envoie des centaines : un seul calcul, au tour de boucle suivant
            QTimer.singleShot(0, self, self._poser_voile)

    def _poser_voile(self):
        """Le voile sur le contenu de la zone défilante (la fenêtre, hors d'elle), de la question à la suivante : le haut
        du widget qui suit, ici ou chez le premier ancêtre qui en a un. Chaque ancêtre jusqu'au contenu est écouté : un
        déplacement de la section entière ne se voit pas depuis la question."""
        self.voile_prevu = False
        v = vars(self).get("voile")  # un événement tardif, l'objet Python déjà vidé : ``__getattr__`` du noyau lèverait
        if not v:
            return
        s = vars(self).get("surimpression")
        if v.isHidden() and not (s and s.montree):
            # rien à poser, ni voile ni correction tracée : la plupart des questions d'un sujet en cours. Chaque
            # redimensionnement les reposait toutes (python_tp : 654 poses, 20 redimensionnements 4,7 → 2,4 s hors
            # écran) ; ``teinter`` et ``_annoter``, qui font paraître l'un ou l'autre, redemandent la pose
            self._styler_retour()
            self._styler_ecrits(False)
            if s:
                s.hide()
            return
        chaine, hote = [self], self
        while hote.parentWidget() is not None and not isinstance(hote.parentWidget().parentWidget(), QScrollArea):
            hote = hote.parentWidget()
            chaine.append(hote)
        if v.parentWidget() is not hote:
            visible = not v.isHidden()
            v.setParent(hote)
            v.setVisible(visible)  # ``setParent`` le cache : une question voilée avant sa première pose perdait son voile
            for w in self.sous_voile:
                w.removeEventFilter(self)
            self.sous_voile = chaine
            for w in chaine:
                w.installEventFilter(self)
        haut = self.mapTo(hote, QPoint(0, 0)).y() if hote is not self else 0
        bas = haut + self.height()
        for w in chaine[:-1]:
            freres = [f for f in w.parentWidget().children() if isinstance(f, QWidget) and not isinstance(f, Voile) and not f.isHidden()
                      and f.y() >= w.y() + w.height()]
            if freres:
                bas = min(f.y() for f in freres) + (w.parentWidget().mapTo(hote, QPoint(0, 0)).y() if w.parentWidget() is not hote else 0)
                break
        v.setGeometry(0, haut, hote.width(), bas - haut)
        trous = QRegion(v.rect())
        for b in self.nets:
            if not b.isHidden():
                trous -= QRegion(QRect(b.mapTo(hote, QPoint(0, 0)) - v.pos(), b.size()))
            if isinstance(b, BoutonIcone):
                b.voile = v
                b.update()
        # la correction écrite à la main, que le voile récrit nette au-dessus de lui comme la surimpression (demande de
        # l'utilisateur, 28/09/2026 : « Bonne réponse ! » plus pâle que le rond vert)
        net = bool(self.dit[1]) and not self.retour.isHidden() and not v.isHidden()
        v.manuscrits = ([(self.retour, self.dit[1])] if net else []) + ([] if v.isHidden() else [*self.ecrits])
        self._styler_retour("transparent" if net else None)
        self._styler_ecrits(not v.isHidden())
        v.setMask(trous)
        v.update()
        v.raise_()
        if s:
            if s.parentWidget() is not hote:
                s.setParent(hote)
            s.setGeometry(v.geometry())
            s.setVisible(s.montree and not self.cachee)
            s.raise_()

    def mettre_a_jour(self):
        """Ce qui est actif, visible et écrit sur les boutons, selon l'état de la question."""
        self.afficher_bareme()
        ouvert = self.actif and not self.fermee
        niveau = Voile.niveau([self])  # voilée si soumise ou verrouillée
        voilee = bool(niveau and self.voile)
        for w in self.entrees:
            case = isinstance(w, QAbstractButton)
            # une case sous le voile reste active, sans focus : désactivée, Qt la grisait PUIS le voile la ternissait,
            # bien plus pâle que son libellé (remarque de l'utilisateur, 26/09/2026) ; le voile retient la souris
            w.setEnabled(ouvert and not self.verrouillee or (case and voilee))  # un champ, lui, reste inactif : le voile ne retient pas le clavier
            if isinstance(w, QAbstractItemView) and not w.isEnabled():  # une vue inactive peint sa sélection en gris : la
                w.clearSelection()  # case active d'un tableau soumis, grise d'un bord à l'autre (l'utilisateur, 04/10/2026)
            if case:
                w.setFocusPolicy(Qt.FocusPolicy.NoFocus if voilee else Qt.FocusPolicy.StrongFocus)
                if voilee:
                    w.clearFocus()
            estompe = not (ouvert or niveau)  # pas encore posée, ou figée : le voile ne la couvre pas
            if estompe != (w.graphicsEffect() is not None):  # grisé de façon visible, quel que soit le style Qt
                w.setGraphicsEffect(QGraphicsOpacityEffect(w, opacity=0.45) if estompe else None)
        if self.voile:
            self.voile.teinter(niveau, not self.cachee)
            self._prevoir_voile()  # la correction que le voile récrit suit sa visibilité
        self.bouton_soumettre.setVisible(ouvert and not self.retenue)
        self.bouton_modifier.setVisible(self.actif and self.fermee and not self.seconde and self.modifiable)
        self.bouton_aide.setVisible(ouvert and bool(self.aide) and not self.aidee)
        self.cadenas.setVisible(ouvert)
        self.cadenas.setIcon(icone("ferme" if self.verrouillee else "ouvert"))
        self.cadenas.setToolTip("Déverrouiller la question pour la modifier" if self.verrouillee
                                else "Verrouiller la question : elle est traitée, sa réponse ne se modifie plus par mégarde")
        attente = self.indice_delai()
        self.bouton_indice.setVisible(ouvert and attente is not None)
        if attente is not None:
            retire = round(self.indices[self.debloques].malus * self.points, 2)  # en points : un pourcentage se lit mal
            self.bouton_indice.setEnabled(not attente)
            # court, pour tenir dans la largeur commune (``BoutonEgal``) : le détail est dans la bulle et les consignes
            self.bouton_indice.setText(f"Indice dans {attente} s" if attente else f"Indice : −{retire:g} pt" if retire else "Indice")
            self.bouton_indice.setToolTip(f"Voir cet indice retire {points_txt(retire)} sur {points_txt(self.points)}, même si la réponse est juste."
                                          if retire else "Cet indice ne retire aucun point.")


class Annotee:
    """Une question corrigée aussi à la main (``self.surimpression``) : les traits paraissent avec la correction ou la
    confirmation, et s'effacent avec elle (« Modifier »)."""

    def montrer_correction(self, couleur=""):
        super().montrer_correction(couleur)
        self._annoter(True)

    def confirmer(self):
        super().confirmer()
        self._annoter(True)

    def _dire(self, markdown, couleur=""):
        super()._dire(markdown, couleur)
        # la correction effacée (« Modifier ») : ses traits aussi ; la seconde chance jouée, ceux qui l'indiquaient
        if not markdown or self.fermee and self.surimpression.fausses is not None:
            self._annoter(False)

    def _annoter(self, montree, fausses=None):
        self.surimpression.montree, self.surimpression.fausses = montree, fausses
        self._poser_voile()  # qui la montre ou la cache
        self.surimpression.update()


class Alternative(Annotee, noyau.Alternative, Question):
    """Corrigée comme une question à choix (``Surimpression``), sur la ligne de ses deux boutons : la bonne entourée si
    cochée, fléchée sinon, l'autre raturée si cochée (l'utilisateur, 07/10/2026)."""

    def _corps(self, d):
        self.boutons = [QRadioButton(libelle) for libelle in self.libelles]
        self.groupe = QButtonGroup(self)
        rangee = QHBoxLayout()
        for b in self.boutons:
            self.groupe.addButton(b)
            rangee.addWidget(b)
        rangee.addStretch()
        d.addLayout(rangee)
        self.entrees += self.boutons
        self.surimpression = Surimpression(self)

    def _attendu(self):
        return ""  # la bonne réponse est entourée ou fléchée en surimpression

    def correcte(self, i):
        return i == (0 if self.reponse else 1)

    def _cochees(self):
        return [i for i, b in enumerate(self.boutons) if b.isChecked()]

    def _lire(self):
        return None if not any(b.isChecked() for b in self.boutons) else self.boutons[0].isChecked()

    def _ecrire(self, valeur):
        decocher(self.boutons, self.groupe)
        if valeur is not None:
            self.boutons[0 if valeur else 1].setChecked(True)


class Choix(Annotee, noyau.Choix, Question):

    def _corps(self, d):
        ordre = melange(range(len(self.propositions)), self.graine) if self.melanger else range(len(self.propositions))
        self.groupe = QButtonGroup(self) if self.EXCLUSIF else None
        boutons, self.notes = {}, {}
        for i in ordre:
            boutons[i] = QRadioButton() if self.EXCLUSIF else CaseCarree()
            if self.groupe:
                self.groupe.addButton(boutons[i])
            rangee = Ligne(boutons[i], self.propositions[i].texte)
            if self.propositions[i].feedback:  # sa place à droite du choix, vide jusqu'à la correction
                note = self.notes[i] = Texte(self.propositions[i].feedback, inline=True, manuscrit=True)
                # l'écriture d'un professeur (demande de l'utilisateur, 26/09/2026), en Kalam (choisie le 27/09/2026) : pas d'italique, elle penche déjà
                note.setStyleSheet(f"QTextBrowser {{ background: transparent; color: transparent; font-family: {POLICE_MAIN};"
                                   f" font-size: {TAILLE_MAIN}pt; }}")
                note.hide()
                rangee.layout().addWidget(note, 1, Qt.AlignmentFlag.AlignVCenter)
            d.addWidget(rangee)
        self.boutons = [boutons[i] for i in range(len(self.propositions))]
        self.entrees += self.boutons
        self.surimpression = Surimpression(self)

    def _attendu(self):
        return ""  # les bonnes réponses sont fléchées ou entourées en surimpression, leurs justifications à leur droite (03/10/2026)

    def correcte(self, i):
        return self.propositions[i].correcte

    def _annoter(self, montree, fausses=None):
        for i, note in self.notes.items():
            montree_ici = montree and (fausses is None or i in fausses)
            texte = note.parentWidget().layout().itemAt(1).widget()  # le choix se resserre sur son texte, la note le suit
            texte.setMaximumWidth(math.ceil(texte.document().idealWidth()) + 2 if montree_ici else 16777215)  # QWIDGETSIZE_MAX
            note.setVisible(montree_ici)
        super()._annoter(montree, fausses)

    def _indiquer(self, indice):
        """La seconde chance : chaque case fausse cochée raturée, son commentaire à sa droite, en rouge, plutôt que
        dessous (demande de l'utilisateur, 03/10/2026 : « la correction partielle […] devrait aussi être à droite de la
        mauvaise proposition »). Lue dans ``saisie`` : la question peut ne pas être encore bâtie."""
        s = self.saisie
        fausses = [i for i in ([] if s is None else [s] if isinstance(s, int) else s) if not self.propositions[i].correcte]
        self._annoter(True, fausses)
        return None

    def _ecrire(self, valeur):
        decocher(self.boutons, self.groupe)
        for i in [] if valeur is None else [valeur] if isinstance(valeur, int) else valeur:
            self.boutons[i].setChecked(True)


class ChoixUnique(noyau.ChoixUnique, Choix):

    def _lire(self):
        return next(iter(self._cochees()), None)


class ChoixMultiples(noyau.ChoixMultiples, Choix):

    def _lire(self):
        return self._cochees() or None


class ReponseCourte(Annotee, noyau.ReponseCourte, Question):

    def _corps(self, d):
        self.champ = QLineEdit()
        self.champ.returnPressed.connect(self._entree)
        if self.etapes:
            self._corps_etapes(d)
        else:
            d.addWidget(self.champ)
            self.entrees.append(self.champ)
        self.surimpression = SurimpressionCourte(self)

    def _corps_etapes(self, d) -> None:
        """Le calcul justifié (``etapes``, demande de l'utilisateur, 07/10/2026) : « Formule », « Application numérique »
        et son bouton « Calculer », qui écrit le résultat du calcul dans « Résultat » (``self.champ``), l'unité restant à
        l'élève ; un calcul illisible le dit sous le champ, sans rien bloquer."""
        self.champs_etapes = {"formule": QLineEdit(), "application": QLineEdit(), "resultat": self.champ}
        self.bouton_calculer, self.erreur_calcul = QPushButton("Calculer"), QLabel()
        self.erreur_calcul.setStyleSheet("color: #c0392b")
        self.erreur_calcul.hide()
        self.champs_etapes["formule"].returnPressed.connect(self.champs_etapes["application"].setFocus)
        self.champs_etapes["application"].returnPressed.connect(self.calculer)
        self.bouton_calculer.clicked.connect(self.calculer)
        grille = QGridLayout()
        for ligne, (libelle, etape) in enumerate([("Formule", "formule"), ("Application numérique", "application"),
                                                  ("Résultat", "resultat")]):
            grille.addWidget(QLabel(libelle), 2 * ligne, 0)
            grille.addWidget(self.champs_etapes[etape], 2 * ligne, 1)
        grille.addWidget(self.bouton_calculer, 2, 2)
        grille.addWidget(self.erreur_calcul, 3, 1, 1, 2)
        grille.setColumnStretch(1, 1)
        d.addLayout(grille)
        self.entrees += [*self.champs_etapes.values(), self.bouton_calculer]

    def calculer(self) -> None:
        """Le bouton « Calculer » : l'application numérique calculée (``noyau.calculer``, sans ``eval``) dans « Résultat »."""
        try:
            self.champ.setText(noyau.ecrire_nombre(noyau.calculer(self.champs_etapes["application"].text())))
            self.erreur_calcul.hide()
        except ValueError as exc:
            self.erreur_calcul.setText(f"Calcul impossible : {exc}.")
            self.erreur_calcul.show()

    def _attendu(self):
        return ""  # écrite à la main dans le champ (``SurimpressionCourte``)

    def _entree(self):
        if not self.retenue:  # Entrée suit « Soumettre », caché si retenue
            self.soumettre()

    def _lire(self):
        if self.etapes:  # les trois champs, ``None`` si tous sont vides
            return lire_champs(self.champs_etapes)
        return self.champ.text() or None

    def _ecrire(self, valeur):
        if self.etapes:
            return ecrire_champs(self.champs_etapes, noyau.ReponseCourte.saisie_etapes(valeur) if valeur else None)
        self.champ.setText(valeur or "")


class ReponseOuverte(noyau.ReponseOuverte, Question):

    def _corps(self, d):
        if self.console:
            self.interpreteur = ConsoleCode(EditeurCode(""), self)
            self.interpreteur.masquer_programme(True)
            d.addWidget(self.interpreteur)
            self.entrees.append(self.interpreteur)
            d.addWidget(intitule("Votre réponse"))  # deux cadres l'un sous l'autre : dire lequel est noté
        self.editeur = hauteur(QPlainTextEdit(), self.lignes)
        d.addWidget(self.editeur)
        self.entrees.append(self.editeur)

    def mettre_a_jour(self):
        super().mettre_a_jour()
        if self.console:
            self.interpreteur.setVisible(not self.sans_execution)

    def _lire(self):
        return self.editeur.toPlainText() or None

    def _ecrire(self, valeur):
        self.editeur.setPlainText(valeur or "")


def lire_champs(champs):
    """Ce qui est rempli dans un ensemble de champs, ``None`` si rien ne l'est."""
    saisie = {n: c.currentText() if isinstance(c, QComboBox) else c.text() for n, c in champs.items()}
    return {n: t for n, t in saisie.items() if t} or None


def ecrire_champs(champs, valeur):
    """Y reposer une saisie ; un champ absent de ``valeur`` est vidé."""
    for n, c in champs.items():
        texte = (valeur or {}).get(n, "")
        c.setCurrentText(texte) if isinstance(c, QComboBox) else c.setText(texte)


class TexteATrous(Annotee, noyau.TexteATrous, Question):

    def _corps(self, d):
        texte = Texte()
        metrique = self._champs(texte)
        blanc = metrique.horizontalAdvance("\u00a0")
        texte.definir(self.texte, trou=lambda n: f'<a name="trou{n}">{"&nbsp;" * -(-self.champs[n].width() // blanc)}</a>')
        if tactile.ACTIF:
            curseur = QTextCursor(texte.document())
            curseur.select(QTextCursor.SelectionType.Document)
            interligne = QTextBlockFormat()
            interligne.setLineHeight(next(iter(self.champs.values())).height() + 8, QTextBlockFormat.LineHeightTypes.MinimumHeight.value)
            curseur.mergeBlockFormat(interligne)
        d.addWidget(texte)
        texte.show()  # né vide, donc caché, et ``definir`` sans parent ne le rouvre pas : le texte et ses champs restaient
        # invisibles (04/10/2026, depuis l'économie de ``definir`` du 02/10)
        self.entrees += self.champs.values()
        self.surimpression = SurimpressionTrous(self)

    def _champs(self, texte):
        """Un menu (ou un champ libre) par trou, posé sur ``texte`` comme incrusté ``trou<n>`` ; rend les métriques de la
        police du sujet, à laquelle ils sont mesurés."""
        self.champs = {}
        listes = {n: melange(trou.choix, f"{self.graine}|{n}") if trou.choix else melange(self.choix, self.graine) if self.choix else None
                  for n, trou in self.trous.items()}
        # tous les menus d'un texte sous la même forme : « A / B » seulement si aucun trou n'a plus de deux mots (demande
        # de l'utilisateur, 28/09/2026, « pour harmoniser »)
        deux = all(len(liste) == 2 for liste in listes.values() if liste)
        for n, liste in listes.items():
            if liste:
                self.champs[n] = menu([*map(str, liste)], deux)
            else:
                self.champs[n] = QLineEdit()
                self.champs[n].setFixedWidth(100)
        # mesuré à la police du sujet, que la feuille de style du parent ne donnera au texte qu'à l'affichage : à la
        # police par défaut, l'ancre en espaces laissait un vide après le menu, et le menu coupait ses mots d'un « … »
        police = texte.font()
        police.setPointSizeF(TAILLE_POLICE)
        metrique = QFontMetrics(police)
        # au doigt, des champs plus hauts qu'une ligne, et des lignes espacées d'autant (demande de l'utilisateur, 28/09/2026)
        hauteur = tactile.CIBLE - 8 if tactile.ACTIF else metrique.height() - 2
        for n, champ in self.champs.items():  # chaque champ prend la place d'une ancre, faite d'espaces insécables
            champ.setParent(texte.viewport())
            champ.setStyleSheet(f"QComboBox, QLineEdit {{ font-size: {TAILLE_POLICE}pt; padding: 0px 4px; margin: 0px; min-height: 0px;"
                                " border: 1px solid gray; border-radius: 3px; }"
                                "QComboBox::drop-down { width: 0px; border: none; } QComboBox::down-arrow { image: none; }")  # pas plus haut qu'une ligne
            largeur = champ.largeur(police) if isinstance(champ, MenuCentre) else 100
            champ.setFixedSize(largeur, hauteur)
            champ.hide()
            texte.incrustes[f"trou{n}"] = champ
        return metrique

    def _attendu(self):
        return ""  # chaque mot attendu est écrit à la main dans son champ (``SurimpressionTrous``, 04/10/2026)

    def _lire(self):
        return lire_champs(self.champs)

    def _ecrire(self, valeur):
        ecrire_champs(self.champs, valeur)


class Figure(Texte):
    """Une figure seule, et des widgets incrustés posés dessus : le centre de ``incrustes[nom]`` à ``places[nom]``, en
    fraction de la largeur et de la hauteur de la figure, qui suivent donc sa réduction sur un écran étroit."""

    places = {}

    def _placer(self):
        objet = next((f for f in fragments(self.document()) if f.charFormat().objectType() == OBJET_SVG), None)
        if objet is None:
            return 0
        taille = self.svg.intrinsicSize(self.document(), objet.position(), objet.charFormat())
        largeur = self.svg.rendu(objet.charFormat().property(NOM_SVG))[1]
        echelle = min(1, taille.width() / (largeur * min(self.svg.echelle, self.svg.largeur_max / largeur)))
        curseur = QTextCursor(self.document())
        curseur.setPosition(objet.position())
        coin = self.cursorRect(curseur).topLeft()
        bas = 0
        for nom, widget in self.incrustes.items():
            self._a_l_echelle(widget, echelle)
            x, y = self.places[nom]
            widget.move(round(coin.x() + x * taille.width() - widget.width() / 2), round(coin.y() + y * taille.height() - widget.height() / 2))
            widget.show()
            bas = max(bas, widget.geometry().bottom() + 2)
        return bas

    @staticmethod
    def _a_l_echelle(widget, echelle):
        """La largeur et la police d'un incrusté suivent la figure qui rétrécit, comme les étiquettes du SVG : à pleine
        largeur, au téléphone les menus se chevauchaient, débordaient et couvraient les numéros ① (R1, 09/10/2026). La
        hauteur reste, cible du doigt. Un menu se remesure à la police réduite : ses marges, elles, ne rétrécissent pas, et
        réduites avec le reste elles coupaient la première lettre du mot le plus long."""
        if getattr(widget, "echelle", 1) == echelle:
            return
        if not hasattr(widget, "pleine"):
            widget.pleine = widget.width(), widget.styleSheet()
        largeur, style = widget.pleine
        police = widget.parentWidget().font()
        police.setPointSizeF(TAILLE_POLICE * echelle)
        widget.setFixedWidth(widget.largeur(police) if isinstance(widget, MenuCentre) else round(largeur * echelle))
        widget.setStyleSheet(style + (f"QComboBox, QLineEdit {{ font-size: {police.pointSizeF():.2f}pt; }}" if echelle < 1 else ""))
        widget.echelle = echelle


class FigureATrous(TexteATrous, noyau.FigureATrous):

    def _corps(self, d):
        figure = Figure(f"![]({self.image})")
        self._champs(figure)
        figure.places = {f"trou{n}": place for n, place in self.places.items()}
        d.addWidget(figure)
        self.entrees += self.champs.values()
        self.surimpression = SurimpressionTrous(self)


MARGE_ENTETE = 4  # écrite une fois : la feuille de style l'applique, ``_ajuster`` la retranche pour mesurer le repli
# le cadre en haut et à gauche seulement : la grille trace déjà le trait à droite et en bas de chaque case, qui
# s'ajoutait au cadre en un bord de 2 px (l'utilisateur, 03/10/2026)
STYLE_TABLEAU = (f"QTableWidget {{ gridline-color: {BORDURE_TABLEAU}; border: 0; border-top: 1px solid {BORDURE_TABLEAU};"
                 f" border-left: 1px solid {BORDURE_TABLEAU};"
                 # pas le bleu de la sélection (« enlever le highlighting bleu des cases », l'utilisateur, 05/10/2026) :
                 # un gris léger, qui montre encore le bloc de cases sélectionné pour un copier-coller
                 f" selection-background-color: #e4e4e4; selection-color: #000000; }}"
                 f"QHeaderView::section {{ background: {ENTETE_TABLEAU}; padding: {MARGE_ENTETE}px; border: 0;"
                 f" border-right: 1px solid {BORDURE_TABLEAU}; border-bottom: 1px solid {BORDURE_TABLEAU}; }}")
CASE_DONNEE = QColor(noyau.GRIS_DONNEE)  # les cases fournies sont grisées : ce qui reste blanc dans la grille est ce qu'il y a à remplir


@functools.cache
def html_case(markdown):
    """Le HTML d'une case : ``sizeHint`` le redemande à chaque redimensionnement, et Markdown est lent."""
    return a_l_echelle(MD.inline(markdown))


def memoriser(delegue, cle, composer, plafond=256):
    """Le document d'une case, composé une fois par (texte, largeur…) : un délégué le recomposait à chaque peinture (setHtml
    et mise en page, 0,03 à 0,5 ms natif, dix fois plus dans le navigateur) et une vue repeint toutes ses cases à chaque
    survol, défilement ou glisser. Vidé d'un coup au-delà du plafond (largeurs successives d'un redimensionnement)."""
    cache = delegue.__dict__.setdefault("_documents", {})
    if cle not in cache:
        if len(cache) >= plafond:
            cache.clear()
        cache[cle] = composer()
    return cache[cle]


BASE = Qt.ItemDataRole.UserRole  # la base d'une case de tableau (``Trou.base``), que lit son éditeur
CARACTERE = Qt.ItemDataRole.UserRole + 1  # une case d'un seul caractère (``Tableau.caracteres``) : son éditeur avance seul
ESPACEMENT_BITS = 150  # en % de l'avance normale (160 réduit d'un rien, puis 140 trop serré : « les cadres se collent », l'utilisateur, 04/10/2026) : « 0 1 0 1 » sans espaces à taper


class CaseMarkdown(QStyledItemDelegate):
    """Peint le Markdown des cases DONNÉES, qu'un ``QTableWidgetItem`` ne sait afficher qu'en texte nu.

    Les cases à remplir sont laissées au rendu natif : c'est lui qui donne le champ blanc occupant toute la case."""

    def _document(self, index, largeur):
        police = self.parent().font()  # celle des cases à remplir : sinon les nombres donnés sortaient plus petits (03/10/2026)
        return memoriser(self, (index.data() or "", largeur, police.key()),
                         functools.partial(self._composer, index.data() or "", largeur, police))

    @staticmethod
    def _composer(texte, largeur, police):
        document = QTextDocument()
        document.setDefaultFont(police)
        document.setDocumentMargin(4)
        html = html_case(texte)
        document.setHtml(html)
        if "<img" in html:  # une image de la banque dans une case (1.57) : SVG ou PNG, dessinée comme dans un ``Texte``,
            document.svg = ObjetSvg(document, MEDIAS, ECHELLE_MEDIAS, largeur)  # réduite à la largeur de la case
            document.svg.poser()
        option = QTextOption(Qt.AlignmentFlag.AlignCenter)
        option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)  # une adresse « 192.168.1.0/24 » n'a pas d'espace où couper
        document.setDefaultTextOption(option)
        document.setTextWidth(largeur)  # sans largeur imposée, le texte long déborde sur la colonne voisine
        return document

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        if not index.flags() & Qt.ItemFlag.ItemIsEditable:
            option.text = ""  # le style ne dessine plus que le fond ; le texte, c'est ``paint`` qui s'en charge

    def paint(self, peintre, option, index):
        super().paint(peintre, option, index)
        if index.flags() & Qt.ItemFlag.ItemIsEditable:
            return
        document = self._document(index, option.rect.width())
        peintre.save()  # peindre le document à la main, c'est devoir recentrer soi-même ce que le style centrait
        peintre.translate(option.rect.topLeft()
                          + QPoint(0, max(0, int((option.rect.height() - document.size().height()) / 2))))
        document.drawContents(peintre)
        peintre.restore()

    def createEditor(self, parent, option, index):
        if index.data(BASE):  # un nombre suivi de sa base (``Trou.base``) : l'indice se tape comme dans une grille de conversion
            editeur = ChampConversion(parent)
            editeur.setFrame(False)
            editeur.setAlignment(Qt.AlignmentFlag.AlignCenter)
            editeur.setFont(index.data(Qt.ItemDataRole.FontRole) or parent.font())
        else:
            editeur = super().createEditor(parent, option, index)
            if index.data(CARACTERE):
                editeur.setAlignment(Qt.AlignmentFlag.AlignCenter)
                editeur.textEdited.connect(functools.partial(self._caractere, editeur, index.row(), index.column()))
        # la case et pas plus : la hauteur minimale d'un champ en tactile (``tactile.activer``) le ferait déborder sur la
        # ligne du dessous, que la saisie masquait
        editeur.setStyleSheet("QLineEdit { min-height: 0px; }")
        return editeur

    def _caractere(self, editeur, r, c, texte):
        """Une grille caractère par caractère : le caractère tapé REMPLACE celui de la case (pas de longueur maximale, qui
        refuserait la frappe dans une case déjà remplie dont rien n'est sélectionné), puis la saisie passe à la case
        suivante, dans l'ordre de lecture ; quitter la case courante y valide la saisie (``currentChanged`` de Qt)."""
        if not texte:
            return
        editeur.setText(texte[max(0, editeur.cursorPosition() - 1)])
        if not self._aller(r, c, 1):  # la dernière case : rien ne la quitte, on y valide la saisie
            self.commitData.emit(editeur)

    def _coller(self, editeur, index):
        """Ctrl+V d'un mot (une clé de Vigenère, un message chiffré) : une lettre par case, à partir de la case courante,
        dans l'ordre de lecture ; la saisie reprend après la dernière lettre posée."""
        texte = "".join(QApplication.clipboard().text().split())
        if not texte:
            return
        editeur.setText(texte[0])
        self.commitData.emit(editeur)
        r, c, table = index.row(), index.column(), self.parent()
        for lettre in texte[1:]:
            if not (suivante := self._suivante(r, c, 1)):
                return
            r, c = suivante
            table.item(r, c).setText(lettre)
        self._aller(r, c, 1)

    def _suivante(self, r, c, sens):
        """La case à remplir suivante (``sens`` 1) ou précédente (-1) dans l'ordre de lecture, ou None."""
        table = self.parent()
        n, largeur = r * table.columnCount() + c + sens, table.columnCount()
        while 0 <= n < table.rowCount() * largeur:
            case = table.item(n // largeur, n % largeur)
            if case and case.flags() & Qt.ItemFlag.ItemIsEditable and not table.cellWidget(n // largeur, n % largeur):
                return n // largeur, n % largeur
            n += sens
        return None

    def _aller(self, r, c, sens):
        """Passe à la case à remplir suivante ou précédente ; faux s'il n'y en a pas."""
        if suivante := self._suivante(r, c, sens):
            self.parent().setCurrentCell(*suivante)
        return bool(suivante)

    def eventFilter(self, editeur, evenement):
        if isinstance(editeur, ChampConversion) and ChampConversion.frappe(editeur, evenement):
            return True
        if (evenement.type() == QEvent.Type.KeyPress and isinstance(editeur, QLineEdit)
                and (index := self.parent().currentIndex()).data(CARACTERE)):
            if evenement.key() == Qt.Key.Key_Backspace and not editeur.text():  # case vide : on revient à la précédente
                self._aller(index.row(), index.column(), -1)
                return True
            if evenement.matches(QKeySequence.StandardKey.Paste):
                self._coller(editeur, index)
                return True
        return super().eventFilter(editeur, evenement)  # Entrée, Tab, Échap : la navigation de la table

    def sizeHint(self, option, index):
        taille = self._document(index, self.parent().columnWidth(index.column())).size()
        return QSize(int(taille.width()), int(taille.height()))


class Tableau(Annotee, noyau.Tableau, Question):

    def _corps(self, d):
        """La grille est un ``QTableWidget`` : c'est lui qui donne la case blanche entièrement éditable, la navigation
        au clavier et les colonnes étirées, sans rien en réécrire. ``champs`` retient ce qui porte la saisie — la case
        elle-même quand elle se tape, le menu quand elle se choisit — et ``lire_champs`` les lit indifféremment.
        Une ``frise`` valide est un chronogramme à colorer (``FriseGantt``), pas une grille."""
        if self.frise and not self._problemes_frise():
            self.champs, self.gantt, self.surimpression = {}, FriseGantt(self), SurimpressionFrise(self)
            d.addWidget(Texte("*Pour chaque instant, cliquez la case du processus exécuté ; un second clic l'efface.*", inline=True))
            d.addWidget(self.gantt)
            self.entrees.append(self.gantt)
            return
        if any(t.base for t in self.cellules.values()):
            d.addWidget(Texte(f"*{noyau.CONSIGNE_BASE_ECRAN.format(quoi='chaque nombre')}*", inline=True))
        self.champs, self.surimpression = {}, SurimpressionTableau(self)
        self.table = (TableEntourer if self.a_entourer else QTableWidget)(0, len(self.colonnes))
        self.table.setHorizontalHeaderLabels(self.colonnes)
        self.table.verticalHeader().hide()
        entete = self.table.horizontalHeader()
        entete.setHidden(not self.a_entete())
        entete.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        police = entete.font()
        police.setBold(True)  # le gras est posé ici, et non dans la feuille de style : ``_ajuster`` mesure ainsi la police réellement peinte
        entete.setFont(police)
        entete.setDefaultAlignment(Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap)  # sans ce drapeau, un en-tête trop long est coupé net
        if not self.a_entourer:  # une grille à entourer ne s'écrit pas : le clic y pose un rond (``TableEntourer``)
            self.table.setEditTriggers(QAbstractItemView.EditTrigger.AllEditTriggers)  # un clic suffit : pas de double-clic à deviner
        self.table.setItemDelegate(CaseMarkdown(self.table))
        self.table.setStyleSheet(STYLE_TABLEAU)
        self.hauteurs = QTimer(self.table, singleShot=True)  # les colonnes ne sont à leur largeur définitive qu'une fois la mise en page retombée
        self.hauteurs.timeout.connect(self._ajuster)
        self.table.horizontalHeader().sectionResized.connect(self._differer)
        self._nombre_de_lignes(self.montrees())
        d.addWidget(self.table)
        self.entrees.append(self.table)
        if self.lignes_libres:  # l'élève ouvre ses lignes une à une, jusqu'au double de la grille attendue plus deux ;
            # au-delà, ou sous ``montrees``, le bouton ne fait rien : le griser dirait où est la limite
            rangee = QHBoxLayout()
            self.plus, self.moins = QPushButton("+ ligne"), QPushButton("− ligne")
            self.plus.clicked.connect(lambda: self._nombre_de_lignes(self.table.rowCount() + 1))
            self.moins.clicked.connect(lambda: self._nombre_de_lignes(self.table.rowCount() - 1))
            rangee.addWidget(self.plus)
            rangee.addWidget(self.moins)
            rangee.addStretch()
            d.addLayout(rangee)
            self.entrees += [self.plus, self.moins]

    def surimposee(self):
        """Vrai quand la correction s'écrit dans les cases (``SurimpressionTableau``) : une réponse attendue par case,
        tapée, dans une grille fixe ; ou sur la frise, toujours."""
        return getattr(self, "gantt", None) is not None or not (self.lignes_libres or self.rapports or self.distinctes or self.combinaisons or self.choix or self.modifier
                    or any(t.reponses is None or t.choix for t in self.cellules.values()))

    def _attendu(self):
        return "" if self.surimposee() else super()._attendu()

    def _nombre_de_lignes(self, n):
        """Ouvre ou referme des lignes jusqu'à en avoir ``n`` (entre ``montrees`` et le plafond) ; ce qui était écrit
        dans une ligne refermée est perdu, comme une ligne barrée."""
        n = max(self.montrees(), min(n, 2 * len(self.lignes) + 2))
        while self.table.rowCount() > n:
            r = self.table.rowCount() - 1
            for c in range(len(self.colonnes)):
                self.champs.pop(f"{r},{c}", None)
            self.table.removeRow(r)
        while self.table.rowCount() < n:
            self._poser_ligne(self.table.rowCount())
        self._differer()

    def _poser_ligne(self, r):
        """Ajoute la ligne ``r`` : ses cases données, ses champs ; au-delà de la grille attendue, les champs de sa
        dernière ligne et la numérotation prolongée (``donnee``)."""
        self.table.insertRow(r)
        modele = min(r, len(self.lignes) - 1)
        for c in range(len(self.colonnes)):
            reference = f"{r},{c}"
            trou = self.cellules.get(f"{modele},{c}")
            case = QTableWidgetItem("" if trou and not self.modifier else self.donnee(r, c))
            case.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if trou is None:
                case.setFlags(case.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if not self.a_entourer:  # toute donnée, la grille à entourer reste blanche : grisée, elle aurait l'air figée
                    case.setBackground(CASE_DONNEE)
            self.table.setItem(r, c, case)
            if trou is None:
                continue
            liste = (melange(trou.choix, f"{self.graine}|{modele},{c}") if trou.choix
                     else melange(self.choix, self.graine) if self.choix else None)
            if self.en_pion(trou):
                self.champs[reference] = CasePion(trou.choix)
                self.table.setCellWidget(r, c, self.champs[reference])
            elif liste:
                self.champs[reference] = menu([*map(str, liste)])
                self.champs[reference].setCurrentText("")  # une ligne ouverte arrive vide : rien n'y est choisi
                self.table.setCellWidget(r, c, self.champs[reference])
            else:
                self.champs[reference] = case
                case.setData(CARACTERE, self.caracteres or None)
                if trou.base:
                    case.setData(BASE, trou.base)
                    if trou.base == 2:  # des bits espacés se lisent (l'utilisateur, 03/10/2026), comme dans la table du cours
                        police = QFont(self.table.font())
                        police.setLetterSpacing(QFont.SpacingType.PercentageSpacing, ESPACEMENT_BITS)
                        case.setFont(police)

    def _differer(self):
        self.hauteurs.start(0)

    def _ajuster(self):
        """Les colonnes étant étirées, la hauteur qu'il faut à une case dépend de la largeur qu'on vient de lui donner :
        elle se recalcule à chaque redimensionnement, sinon un texte passé à la ligne est coupé. L'en-tête n'a pas de
        délégué qui le mesure pour lui : sa hauteur se calcule à la main, à la police même qu'il peint."""
        entete = self.table.horizontalHeader()
        metriques = entete.fontMetrics()
        replie = max(metriques.boundingRect(QRect(0, 0, self.table.columnWidth(c) - 2 * MARGE_ENTETE, 0),
                                            Qt.TextFlag.TextWordWrap, str(titre)).height()
                     for c, titre in enumerate(self.colonnes))
        entete.setFixedHeight(replie + entete.sizeHint().height() - metriques.height())  # + ce que le style ajoute autour d'une ligne
        largeur = self._largeur_utile()
        if self.caracteres:  # sous le minimum du style (38 px), les colonnes débordaient : défilement, dernière ligne masquée ;
            entete.setMinimumSectionSize(largeur)  # et la hauteur étant celle du contenu, un ascenseur vertical, posé pendant
            self.table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # la mise en page, rognait la dernière colonne
        self.table.setMaximumWidth(len(self.colonnes) * largeur + 1)
        for r in range(self.table.rowCount()):  # pas ``resizeRowsToContents`` : il garde la hauteur de l'en-tête vertical,
            self.table.setRowHeight(r, self.table.sizeHintForRow(r))  # masqué mais 30 px, trop haut (l'utilisateur, 03/10/2026)
        self.table.setFixedHeight((0 if entete.isHidden() else entete.height()) + 1
                                  + sum(self.table.rowHeight(r) for r in range(self.table.rowCount())))

    def _largeur_utile(self):
        """La largeur d'une colonne qui suffit à tout ce qu'elle montre : titre, cases données, réponses attendues, menus. La
        table ne s'étire pas au-delà de ce qu'il lui faut en colonnes égales (une table de nombres courts sur toute la
        largeur de la page : l'utilisateur, 03/10/2026) ; une colonne de phrases, elle, prend toute la largeur comme avant.
        Une grille caractère par caractère a des cases carrées : la hauteur d'une ligne, ou ce que demande un en-tête."""
        if self.caracteres:
            gras = self.table.horizontalHeader().fontMetrics()
            return max(self.table.sizeHintForRow(0), *(gras.horizontalAdvance(str(titre)) + 2 * MARGE_ENTETE for titre in self.colonnes))
        police, gras = QFontMetrics(self.table.font()), self.table.horizontalHeader().fontMetrics()
        largeurs = [gras.horizontalAdvance(str(titre)) + 2 * MARGE_ENTETE for titre in self.colonnes]
        largeurs += [CaseMarkdown._composer(str(self.donnee(r, c)), 10000, self.table.font()).idealWidth()
                     for r in range(len(self.lignes)) for c in range(len(self.colonnes)) if f"{r},{c}" not in self.cellules]
        largeurs += [police.horizontalAdvance(f"{reponse}₁₆") * (ESPACEMENT_BITS / 100 if trou.base == 2 else 1)
                     for trou in self.cellules.values() for reponse in trou.reponses or []]  # relevée : rien d'attendu
        largeurs += [champ.sizeHint().width() for champ in self.champs.values() if isinstance(champ, QWidget)]
        return round(max([police.horizontalAdvance("0" * 8), *largeurs])) + 2 * police.horizontalAdvance("0")

    def _lire(self):
        if getattr(self, "gantt", None) is not None:
            return self.gantt.saisie()
        if self.a_entourer:
            return sorted(self.table.entourees) or None
        saisie = lire_champs(self.champs)
        return None if self.modifier and saisie == self._avant() else saisie  # rien de modifié : pas encore répondu

    def _ecrire(self, valeur):
        if getattr(self, "gantt", None) is not None:
            return self.gantt.poser(valeur)
        if self.a_entourer:
            self.table.entourees = set(valeur or [])
            return self.table.viewport().update()
        if self.lignes_libres:
            self._nombre_de_lignes(self.lignes_ecrites(valeur))
        ecrire_champs(self.champs, self._avant() if valeur is None and self.modifier else valeur)

    def _avant(self):
        """Avec ``modifier``, la table telle qu'elle arrive, avant toute modification."""
        return {n: str(self.donnee(*map(int, n.split(",")))) for n in self.champs if str(self.donnee(*map(int, n.split(","))))} or None


class CasePion(QWidget):
    """Une case de la réglette d'un ``tableau`` à ``pions`` (1.47, baguenaudier) : un rond plein quand elle porte un pion,
    un rond pointillé sinon, comme la figure du sujet ; un clic, un toucher sans glisser ou Espace bascule. Lue et écrite
    comme une case tapée (``text``, ``setText``) : le second mot avec un pion, rien sans. Écarté : le menu « vide/pion »
    de chaque case, où l'élève lisait des mots au lieu de voir la rangée de pions qu'il fait évoluer (l'utilisateur,
    04/10/2026)."""

    def __init__(self, mots):
        super().__init__()
        self.pion, self.plein = str(mots[1]), False
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.toucher = tactile.Toucher()  # au doigt, la page défile : seul un toucher sans glisser bascule, à son lever

    def text(self):
        return self.pion if self.plein else ""

    def setText(self, texte):
        self.plein = texte == self.pion
        self.update()

    def basculer(self):
        if self.isEnabled():
            self.setText("" if self.plein else self.pion)

    def mousePressEvent(self, evenement):
        if not self.toucher.appui(evenement):
            self.basculer()

    def mouseMoveEvent(self, evenement):
        self.toucher.bouge(evenement)

    def mouseReleaseEvent(self, evenement):
        if self.toucher.leve(evenement):
            self.basculer()

    def keyPressEvent(self, evenement):
        if evenement.key() in (Qt.Key.Key_Space, Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.basculer()
        else:
            super().keyPressEvent(evenement)

    def sizeHint(self):
        return QSize(40, 30)

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        couleur = self.palette().color(QPalette.ColorRole.Text)
        rayon = min(self.width(), self.height()) * 0.28
        centre = QPointF(self.rect().center()) + QPointF(0.5, 0.5)
        if self.plein:
            peintre.setPen(Qt.PenStyle.NoPen)
            peintre.setBrush(couleur)
        else:
            stylo = QPen(couleur, 1.5, Qt.PenStyle.DotLine)
            peintre.setPen(stylo)
        peintre.drawEllipse(centre, rayon, rayon)
        if self.hasFocus():
            peintre.setPen(QPen(TableEntourer.BLEU, 1))
            peintre.setBrush(Qt.BrushStyle.NoBrush)
            peintre.drawEllipse(centre, rayon + 4, rayon + 4)


class TableEntourer(QTableWidget):
    """La grille d'un ``tableau`` à ``a_entourer`` (1.37) : toute donnée, un clic entoure une case d'un rond bleu (le bleu
    d'un sommet choisi sur un ``dessin``), un second clic l'efface ; au doigt comme à la souris. Écarté : une case à cocher
    ou un fond coloré par case, qui ne disent pas le geste du sujet papier (« entourer le bit erroné »)."""

    BLEU = QColor("#1e88e5")

    def __init__(self, *args):
        super().__init__(*args)
        self.entourees = set()  # les références « ligne,colonne » entourées par l'élève
        self.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.viewport().setCursor(Qt.CursorShape.PointingHandCursor)
        self.toucher = tactile.Toucher()  # au doigt, la page défile : seul un toucher sans glisser entoure, à son lever

    def mousePressEvent(self, evenement):
        if not self.toucher.appui(evenement):
            self._entourer(evenement)

    def mouseMoveEvent(self, evenement):
        self.toucher.bouge(evenement)

    def mouseReleaseEvent(self, evenement):
        if self.toucher.leve(evenement):
            self._entourer(evenement)

    def _entourer(self, evenement):
        index = self.indexAt(evenement.position().toPoint())
        if self.isEnabled() and index.isValid():
            self.entourees ^= {f"{index.row()},{index.column()}"}
            self.viewport().update()

    def zone(self, reference):
        """Le texte de la case, dans les coordonnées du viewport : c'est lui qu'on entoure, pas toute la case."""
        r, c = map(int, reference.split(","))
        cadre = QRectF(self.visualRect(self.model().index(r, c)))
        metrique = QFontMetricsF(self.font())
        largeur = min(metrique.horizontalAdvance(self.item(r, c).text()) or metrique.height(), cadre.width() - 14)
        return QRectF(cadre.center().x() - largeur / 2, cadre.center().y() - metrique.height() / 2, largeur, metrique.height())

    def paintEvent(self, evenement):
        super().paintEvent(evenement)
        peintre = QPainter(self.viewport())
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.setPen(QPen(self.BLEU, 2.5))
        for reference in self.entourees:
            rond_a_la_main(peintre, self.zone(reference))


class FriseGantt(QWidget):
    """La saisie d'un ``tableau`` à ``frise`` (1.13) : le chronogramme d'ordonnancement comme au bac, une ligne par
    processus, une colonne par instant. Un clic colore la case du processus exécuté à cet instant (et décolore celle
    d'un autre processus dans la même colonne : un seul s'exécute à la fois) ; un second clic l'efface ; glisser le
    bouton enfoncé répète le même geste le long de la ligne, pour un processus qui dure. Au doigt (``tactile.ACTIF``),
    seul un toucher sans glisser colore, à son lever : tout glisser fait défiler la page, comme partout ailleurs sur un
    téléphone (écarté, prendre le geste quand il part à l'horizontale : Qt donne le doigt au défilement dès l'appui,
    avant de savoir où il va). Les colonnes données sont
    grisées et ne réagissent pas. Écarté : le menu par case du tableau, où l'élève lisait une rangée de « P1 », « P2 »
    au lieu de voir les barres qu'il doit tracer. La toile se réduit comme celle d'un ``dessin`` (``ToileGraphe``)."""

    question = property(lambda self: self._question())
    HAUT, ENTETE = 28, 24  # la hauteur d'une ligne de processus ; celle de la ligne des instants

    def __init__(self, question):
        super().__init__()
        self._question, self.choisis = weakref.ref(question), {}  # case -> processus posé par l'élève
        self.geste = None  # pendant un glisser : (ligne du processus, poser ou effacer, dernière colonne traitée)
        self._mesurer()
        politique = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        politique.setHeightForWidth(True)
        self.setSizePolicy(politique)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toucher, self.tap = tactile.Toucher(), None  # au doigt : la case touchée, colorée au lever d'un toucher

    def _gras(self):
        gras = QFont(self.font().resolve(QApplication.font()))
        gras.setBold(True)
        return gras

    def _mesurer(self):
        """Les colonnes à la largeur de leur libellé, en gras comme il est peint, refaites quand la police change : celle
        de la feuille de style du lecteur n'arrive qu'après la construction (en-têtes « 0 – 1 » chevauchés, 04/10/2026)."""
        q, metriques = self.question, QFontMetricsF(self._gras())
        self.noms = math.ceil(max(metriques.horizontalAdvance(p) for p in q.processus())) + 16
        self.largeurs = [max(self.HAUT, math.ceil(metriques.horizontalAdvance(libelle)) + 10) for libelle, _ in q.instants()]
        self.naturelle = QSize(self.noms + sum(self.largeurs) + 1, self.ENTETE + self.HAUT * len(q.processus()) + 1)
        largeur_mini = min(self.naturelle.width(), TOILE_MINIMUM)
        self.setMinimumSize(largeur_mini, self.heightForWidth(largeur_mini))
        self.updateGeometry()

    def sizeHint(self):
        return self.naturelle

    def heightForWidth(self, largeur):
        return math.ceil(self.naturelle.height() * min(1, largeur / self.naturelle.width()))

    def _echelle(self):
        return min(1, self.width() / self.naturelle.width())

    def event(self, evenement):
        if evenement.type() == QEvent.Type.FontChange:
            self._mesurer()
        return super().event(evenement)

    def cellule(self, k, i):
        """Le rectangle de l'instant ``k`` sur la ligne du processus ``i`` (``i`` = -1 : l'en-tête), en coordonnées naturelles."""
        x = self.noms + sum(self.largeurs[:k])
        return QRectF(x, self.ENTETE + self.HAUT * i if i >= 0 else 0, self.largeurs[k], self.HAUT if i >= 0 else self.ENTETE)

    def _sous(self, position):
        """(instant, processus) sous ce point, ``None`` hors de la grille ; le processus vaut -1 dans l'en-tête."""
        x, y = position.x() - self.noms, position.y() - self.ENTETE
        if x < 0:
            return None
        for k, largeur in enumerate(self.largeurs):
            if x < largeur:
                i = math.floor(y / self.HAUT)
                return (k, i) if i < len(self.question.processus()) else None
            x -= largeur
        return None

    def paintEvent(self, _):
        q = self.question
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.scale(self._echelle(), self._echelle())
        processus, instants = q.processus(), q.instants()
        peintre.fillRect(QRectF(0, self.ENTETE, self.naturelle.width() - 1, self.HAUT * len(processus)), QColor("#ffffff"))
        gras = self._gras()
        for k, (libelle, case) in enumerate(instants):
            donnee = case not in q.cellules
            if donnee:
                peintre.fillRect(QRectF(self.cellule(k, 0).topLeft(), self.cellule(k, len(processus) - 1).bottomRight()), CASE_DONNEE)
            for i, p in enumerate(processus):
                if (q.execute(case, None) if donnee else self.choisis.get(case)) == p:
                    fond, trait = (QColor("#b0bec5"), QColor("#78909c")) if donnee else map(QColor, PALETTE[i % len(PALETTE)])
                    peintre.setPen(QPen(trait, 1.5))
                    peintre.setBrush(fond)
                    peintre.drawRect(self.cellule(k, i).adjusted(2, 4, -2, -4))
            peintre.setPen(QColor("#37474f"))
            peintre.setFont(gras)
            peintre.drawText(self.cellule(k, -1), int(Qt.AlignmentFlag.AlignCenter), libelle)
        peintre.setFont(gras)
        for i, p in enumerate(processus):
            peintre.drawText(QRectF(0, self.ENTETE + self.HAUT * i, self.noms - 8, self.HAUT),
                             int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter), p)
        peintre.setPen(QPen(QColor("#b0bec5"), 1))
        peintre.setBrush(Qt.BrushStyle.NoBrush)
        for i in range(len(processus) + 1):
            peintre.drawLine(QPointF(self.noms, self.ENTETE + self.HAUT * i), QPointF(self.naturelle.width() - 1, self.ENTETE + self.HAUT * i))
        for k in range(len(instants) + 1):
            x = self.noms + sum(self.largeurs[:k])
            peintre.drawLine(QPointF(x, self.ENTETE), QPointF(x, self.naturelle.height() - 1))

    def _appliquer(self, k, i, poser):
        case = self.question.instants()[k][1]
        if case not in self.question.cellules:
            return
        p = self.question.processus()[i]
        if poser:
            self.choisis[case] = p
        elif self.choisis.get(case) == p:
            del self.choisis[case]

    def mousePressEvent(self, evenement):
        sous = self._sous(evenement.position() / self._echelle())
        if not self.isEnabled() or sous is None or sous[1] < 0:
            return
        if self.toucher.appui(evenement):
            # au doigt, la page défile (defiler_au_doigt) : seul un toucher sans glisser colore, à son lever ; le
            # QScroller laisse passer la souris que Qt tire du doigt, qu'il défile ou non
            self.tap = sous
            return
        self._geste(*sous)

    def _geste(self, k, i):
        case = self.question.instants()[k][1]
        poser = self.choisis.get(case) != self.question.processus()[i]
        self.geste = (i, poser, k)
        self._appliquer(k, i, poser)
        self.update()

    def mouseMoveEvent(self, evenement):
        self.toucher.bouge(evenement)
        if self.geste is None:
            return
        sous = self._sous(QPointF(evenement.position().x(), self.ENTETE * self._echelle()) / self._echelle())
        if sous is None:
            return
        i, poser, dernier = self.geste
        for k in range(min(dernier, sous[0]), max(dernier, sous[0]) + 1):  # un glisser rapide saute des colonnes
            self._appliquer(k, i, poser)
        self.geste = (i, poser, sous[0])
        self.update()

    def mouseReleaseEvent(self, evenement):
        if self.toucher.leve(evenement) and self.tap:
            self._geste(*self.tap)
        self.geste = self.tap = None

    def saisie(self):
        q = self.question
        if not self.choisis:
            return None
        saisie = {case: self.choisis.get(case, q.vide()) for _, case in q.instants() if case in q.cellules}
        return {n: v for n, v in saisie.items() if v} or None

    def poser(self, valeur):
        q = self.question
        self.choisis = {case: p for _, case in q.instants() if case in q.cellules and (p := q.execute(case, valeur))}
        self.update()


class SurimpressionFrise(Surimpression):
    """La correction à la main d'une ``frise`` : les cases justes d'un même processus, d'affilée, entourées d'un seul rond
    (une barre juste, pas dix ronds) ; une case fausse barrée ; la case attendue encadrée de vert en pointillé, « à
    colorer ». En seconde chance, les ratures seules : la réponse reste à trouver."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        frise = q.gantt
        coin, echelle = self.cadre(frise).topLeft(), frise._echelle()
        processus, juste = q.processus(), q.juste()

        def rect(k, i):
            r = frise.cellule(k, i).adjusted(2, 4, -2, -4)
            return QRectF(coin + r.topLeft() * echelle, r.size() * echelle)

        suite = []  # la barre juste en cours : [(k, i)]

        def fermer():
            if suite:
                self.entourer(peintre, rect(suite[0][0], suite[0][1]).united(rect(suite[-1][0], suite[-1][1])), marge=(4, 4))
                suite.clear()

        for k, (_, case) in enumerate(q.instants()):
            if case not in q.cellules:
                fermer()
                continue
            pose, attendu = frise.choisis.get(case), q.execute(case, juste)
            if pose is not None and q.trou_juste(case, pose):
                i = processus.index(pose)
                if suite and suite[-1] != (k - 1, i):
                    fermer()
                if self.fausses is None:
                    suite.append((k, i))
                continue
            fermer()
            if pose is not None:
                r = rect(k, processus.index(pose))
                self.stylo(peintre, self.ROUGE)
                peintre.drawLine(r.bottomLeft() + QPointF(2, -2), r.topRight() + QPointF(-2, 2))
            if attendu is not None and self.fausses is None:
                peintre.setPen(QPen(self.VERT, 2, Qt.PenStyle.DashLine))
                peintre.drawRect(rect(k, processus.index(attendu)))
        fermer()


class ChampConversion(QLineEdit):
    """Une case de ``SaisieConversion`` : son ``niveau`` (1 exposant, -1 indice de base, 0 la ligne) se VOIT au curseur,
    réduit à sa moitié haute ou basse — sans cela, rien ne dit que Maj+↑ a fait basculer (l'utilisateur, 03/10/2026).
    Le curseur natif est alors masqué (largeur 0, ``Style``) et redessiné ici, clignotant à la cadence du système."""

    class Style(QProxyStyle):
        def pixelMetric(self, metrique, option=None, widget=None):
            if metrique == QStyle.PixelMetric.PM_TextCursorWidth and getattr(widget, "niveau", 0):
                return 0
            return super().pixelMetric(metrique, option, widget)

    def __init__(self, parent):
        super().__init__(parent)
        self._niveau, self.visible, self.marges, self.ligne_de_base = 0, True, (0, 0), None
        self.textChanged.connect(self.recaler)
        self.style_curseur = ChampConversion.Style()  # sans base : celle de l'application, qu'il ne doit pas posséder
        self.style_curseur.setParent(self)
        self.setStyle(self.style_curseur)
        self.battement = QTimer(self, interval=max(250, QApplication.cursorFlashTime() // 2))
        self.battement.timeout.connect(self.battre)

    def poser_marges(self, gauche, droite):
        self.marges = (gauche, droite)
        self.recaler()

    def caler(self, ligne_de_base):
        """La ligne de base du texte à ``ligne_de_base`` pixels du haut du champ : celle du texte de la figure (``noyau.svg``),
        quelle que soit la police. Centré par Qt (AlignVCenter), le texte saisi tombait plus bas que les « + » et les
        étiquettes dans le lecteur web (l'utilisateur, 04/10/2026), dont les polices n'ont pas les métriques du poste."""
        self.ligne_de_base = ligne_de_base
        self.ensurePolished()  # le corps de la feuille de style (``SaisieConversion.styler``) dans ``font()``
        self.setAlignment(self.alignment() & ~Qt.AlignmentFlag.AlignVertical_Mask | Qt.AlignmentFlag.AlignTop)
        self.recaler()

    def recaler(self):
        """Aligné à droite, l'exposant ou la base qui termine le texte déborde dans la marge, comme sur la figure
        (``noyau.queue_suscrite``) ; vide, le curseur attend un chiffre plus à gauche : le premier chiffre tapé prend cette
        place, et le curseur avance derrière lui (l'utilisateur, 03/10/2026) au lieu de rester collé au bord. En haut, de
        quoi poser la ligne de base où ``caler`` la veut (1 : la marge verticale que Qt ajoute en AlignTop)."""
        gauche, droite = self.marges
        haut = 0 if self.ligne_de_base is None else max(0, self.ligne_de_base - 1 - QFontMetrics(self.font()).ascent())
        if self.alignment() & Qt.AlignmentFlag.AlignRight:
            gauche, metrique = 0, QFontMetrics(self.font())  # la marge est à droite : à gauche, « + 16 », « =30 » ont toute la place
            droite += metrique.horizontalAdvance("0") if not self.text() else \
                -round(QFontMetricsF(self.font()).horizontalAdvance(noyau.queue_suscrite(self.text())[1]))
            largeur = QFontMetricsF(self.font()).horizontalAdvance(self.text())
            droite = max(0, min(droite, self.contentsRect().width() - 12 - largeur))  # 8 px d air à gauche (Qt en retire 3 de plus) : un « - » ou un « = » de tête ne touche pas le bord
        if (self.textMargins().right(), self.textMargins().top()) != (droite, haut):
            self.setTextMargins(gauche, haut, droite, 0)

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.recaler()

    def battre(self):
        self.visible = not self.visible
        self.update()

    @staticmethod
    def frappe(champ, evenement):
        """Le niveau d'écriture (``SaisieConversion``, « Saisie ») : Maj+↑/↓, « ^ » et « _ » le changent, un chiffre s'écrit à
        ce niveau, tout autre caractère ou le départ vers une autre case ramène à la ligne. True : frappe prise ; False :
        laissée au champ ; None : pas de son ressort (flèche, raccourci, autre caractère), à l'appelant d'en décider."""
        if evenement.type() == QEvent.Type.FocusOut:  # une autre case (flèches, Tab, clic) : retour à la ligne
            champ.niveau = 0
        if evenement.type() != QEvent.Type.KeyPress:
            return False
        modificateurs = evenement.modifiers() & ~Qt.KeyboardModifier.KeypadModifier
        touche, texte, niveau = evenement.key(), evenement.text(), champ.niveau
        if modificateurs == Qt.KeyboardModifier.ShiftModifier and touche in (Qt.Key.Key_Up, Qt.Key.Key_Down):
            champ.niveau = max(-1, min(1, niveau + (1 if touche == Qt.Key.Key_Up else -1)))
            return True
        if not modificateurs and touche in (Qt.Key.Key_Left, Qt.Key.Key_Right) and isinstance(champ, QLineEdit) \
                and not champ.hasSelectedText():
            return ChampConversion.pas(champ, 1 if touche == Qt.Key.Key_Right else -1)
        if modificateurs & ~Qt.KeyboardModifier.ShiftModifier or not texte:
            return None
        if texte in "^_":
            champ.niveau = 1 if texte == "^" else -1
            return True
        if texte.isdigit() and niveau:
            champ.insert(texte.translate(noyau.EXPOSANT if niveau > 0 else noyau.INDICE))
            return True
        champ.niveau = 0  # un chiffre sans niveau, ou « 14×16² + … » : l'espace ramène à la ligne
        return None

    @staticmethod
    def pas(champ, sens):
        """← ou → dans le texte : le curseur prend le niveau du caractère qu'il vient de passer ; à la frontière d'un
        exposant ou d'une base (« 37|₁₀ »), un second appui l'y fait entrer sans bouger (l'utilisateur, 03/10/2026 : « le
        curseur doit s'adapter au chiffre à gauche, puis à droite lors de deux appuis successifs si on vient de la gauche,
        l'inverse dans l'autre sens »). Au bord du texte : None, la case voisine (``SaisieConversion.fleche``)."""
        texte, p = champ.text(), champ.cursorPosition()
        if not 0 <= p + sens <= len(texte):
            return None
        niveaux = [1 if c in "⁰¹²³⁴⁵⁶⁷⁸⁹" else -1 if c in "₀₁₂₃₄₅₆₇₈₉" else 0 for c in texte]
        quitte, devant = (niveaux[p - 1] if p else None), (niveaux[p] if p < len(texte) else None)
        if sens < 0:
            quitte, devant = devant, quitte
        if devant != quitte == champ.niveau:  # au début du texte, ``quitte`` est None : jamais un niveau
            champ.niveau = devant
        else:
            champ.setCursorPosition(p + sens)
            champ.niveau = niveaux[p] if sens > 0 else niveaux[p - 1]
        return True

    @property
    def niveau(self):
        return self._niveau

    @niveau.setter
    def niveau(self, niveau):
        self._niveau, self.visible = niveau, True
        self.battement.start() if niveau else self.battement.stop()
        self.update()

    def paintEvent(self, evenement):
        super().paintEvent(evenement)
        if not (self._niveau and self.visible and self.hasFocus()):
            return
        r = self.cursorRect()
        haut = QFontMetrics(self.font()).ascent()  # la hauteur d'un chiffre, autour du milieu de la case
        milieu = r.center().y() + 1
        y0, y1 = (milieu - haut // 2 - 2, milieu - 1) if self._niveau > 0 else (milieu + 1, milieu + haut // 2 + 3)
        peintre = QPainter(self)
        peintre.fillRect(QRect(r.center().x() + 1, y0, 1, y1 - y0), self.palette().color(QPalette.ColorRole.Text))


class ZoneConversion(QPlainTextEdit):
    """La justification libre d'un polynôme (niveau 4) : plusieurs lignes, sous le nom des méthodes d'un ``ChampConversion``
    dont se sert la grille ; le niveau d'écriture (exposant, indice) y vaut comme dans une case, sans son curseur dessiné."""

    def __init__(self, parent):
        super().__init__(parent)
        self.niveau = 0
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

    text, setText, insert = QPlainTextEdit.toPlainText, QPlainTextEdit.setPlainText, QPlainTextEdit.insertPlainText

    def poser_marges(self, gauche, droite):
        self.setViewportMargins(gauche, 0, droite, 0)


class SaisieConversion(QWidget):
    """Ce que la figure (``GrilleConversion``) et le tableau (``TableConversion``) d'une question ``conversion`` ont en
    commun : un champ de saisie sans cadre sur chaque case à remplir, posé par la sous-classe (``support``, ``placer``),
    qui dessine le reste (``dessiner``). À chaque frappe le plan est recalculé sur ce qui est écrit : une flèche paraît quand la case
    qu'elle désigne est remplie — juste ou non, sinon son absence trahirait l'erreur (l'utilisateur, 01/10/2026) — et
    une division de plus s'ouvre quand le quotient précédent est écrit. ``methode`` : celle de la grille, quand l'élève
    choisit la sienne (``methode`` « choix » de la question, une grille par méthode possible).

    Une puissance écrite dans la ligne « en décimales » se recopie dans les autres grilles du sujet, sous la même
    puissance (2⁷, 16¹…) : l'élève ne remplit l'en-tête qu'une fois (demande de l'utilisateur, 01/10/2026). Seulement
    dans une case vide, ou qui portait la valeur d'avant (recopiée elle aussi) : ce que l'élève a écrit lui-même dans une
    autre grille ne s'écrase pas. Une case recopiée reste modifiable, et se corrige comme une saisie.

    Saisie (demandes de l'utilisateur, 03/10/2026) : le signe d'une case (« + » d'un terme de somme, « - » d'une
    soustraction successive, ``signe`` du plan) se pose de lui-même devant ce que l'élève écrit, s'il ne l'a pas mis ;
    les flèches du clavier passent à la case voisine (gauche et droite seulement depuis le bord du texte, pour garder le
    déplacement du curseur) ; un bit écrit (0 ou 1) passe à la case de droite. Dans un polynôme aux niveaux 1 et 2, « + »
    passe à la case suivante de la ligne, et au niveau 2 l'ouvre d'abord (``ouvertes``, que ``actualiser`` passe au plan). Maj+↑ fait écrire les chiffres en exposant
    (16², Maj+↓ en revient), Maj+↓ en indice de base (94₁₀) ; « ^ » et « _ » font de même sur un clavier sans Maj (tablette),
    et tout autre caractère, ou le passage à une autre case, revient à la ligne. « x » et « * » s'écrivent « × ». (Ni Maj+chiffre, qui tape le chiffre en
    AZERTY, ni Ctrl+chiffre, qui change d'onglet dans Chrome.)

    Taille : le texte de la figure et les chiffres saisis au corps du sujet (demande de l'utilisateur, 03/10/2026, plutôt
    que des chiffres plus petits que l'énoncé), tant que la grille tient dans la largeur ; dans une fenêtre plus étroite,
    toute la figure se réduit avec elle, chiffres compris (``placer``), jusqu'à ``ECHELLE_MINI``. Les chiffres sont à droite
    de leur case, à ``MARGE`` du bord (unités sous unités), et le niveau d'une case se voit au curseur (``ChampConversion``)."""

    question = property(lambda self: (self.figure or self._question()).pour({"methode": self.methode}))
    GRILLES = weakref.WeakSet()
    gelee = False  # le premier essai d'un rattrapage : ni modifiable, ni réécrit par une puissance recopiée
    corrigee = False  # la correction montrée : les cases qu'elle remplit sont ouvertes (``actualiser``)
    ECHELLE_MINI = 0.9  # pixels par point : des chiffres de 9 px, en deçà illisibles ; la page défile alors de côté

    def __init__(self, question, methode=None, figure=None):
        super().__init__()
        self._question, self.rendu, self.methode = weakref.ref(question), None, methode  # voir ``Surimpression.question``
        self.figure = figure  # la conversion dessinée, quand ce n'est pas la question elle-même (le second essai)
        self.echelle, self.styles, self.poses = None, {}, {}
        politique = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)  # pas Fixed en hauteur : le
        politique.setHeightForWidth(True)  # layout la bornerait au sizeHint, et une grille réduite garderait sa hauteur
        self.setSizePolicy(politique)
        self.champs, self.signes, self.avant, self.ouvertes = {}, {}, {}, {}
        for c in self.question.plan(tout=True)["cases"]:
            if c["remplir"] and c["cle"] not in self.champs:
                zone = c["h"] > 1 and c["cle"] == "justification"
                champ = ZoneConversion(self.support()) if zone else ChampConversion(self.support())
                self.styles[c["cle"]] = (f"{type(champ).__mro__[1].__name__} {{ background: transparent;"
                                         f" color: {c['couleur'] or '#000000'};"
                                         f" font-weight: {'bold' if c['gras'] else 'normal'}; padding: 0;")  # + son corps
                champ.textChanged.connect(self.actualiser)
                if not zone:
                    champ.setFrame(False)
                    champ.setAlignment({"g": Qt.AlignmentFlag.AlignLeft, "c": Qt.AlignmentFlag.AlignHCenter}.get(
                        c["aligne"], Qt.AlignmentFlag.AlignRight) | Qt.AlignmentFlag.AlignVCenter)
                    champ.textEdited.connect(functools.partial(self.saisi, c["cle"]))  # émis AVANT textChanged : ``avant``
                    champ.textChanged.connect(functools.partial(self.retenir, c["cle"]))  # est encore l'ancien texte
                champ.installEventFilter(self)
                self.champs[c["cle"]], self.signes[c["cle"]] = champ, c.get("signe", "")
        plan = self.question.plan(tout=True)
        entetes = {c["x"]: c["texte"] or c["attendu"] for c in plan["cases"] if c["y"] < 1 and (c["cle"] or "e")[0] == "e"}
        self.puissances = {c["cle"]: entetes[c["x"]] for c in plan["cases"] if c["remplir"] and c["cle"][0] == "p"}  # p3 : « 2⁴ »
        self.precedent = {}
        for cle in self.puissances:
            self.champs[cle].textChanged.connect(functools.partial(self.propager, cle))
        SaisieConversion.GRILLES.add(self)
        self.actualiser()

    def propager(self, cle, texte):
        """Recopie la puissance ``cle`` qui vient de changer dans les grilles ouvertes de la même fenêtre."""
        avant, self.precedent[cle] = self.precedent.get(cle, ""), texte
        for autre in list(SaisieConversion.GRILLES):
            try:
                question = autre._question()
                if autre is self or question is None or question.fermee or autre.gelee or autre.window() is not self.window():
                    continue
            except RuntimeError:  # grille d'une fenêtre déjà détruite côté Qt, pas encore ramassée côté Python
                continue
            for k, puissance in autre.puissances.items():
                if puissance == self.puissances[cle] and autre.champs[k].text() in ("", avant):
                    autre.champs[k].setText(texte)

    def ecrites(self):
        return {cle: champ.text() for cle, champ in self.champs.items() if champ.text().strip()}

    def retenir(self, cle, _):
        self.avant[cle] = self.champs[cle].text()  # le texte du champ, pas celui du signal : un ``saisi`` qui le remplace
        # émet son propre textChanged avant que Qt n'émette celui de la frappe, avec le texte d'avant le remplacement

    def saisi(self, cle, texte):
        """Ce que l'élève vient de taper (pas un ``setText`` : réponse rechargée, puissance recopiée) dans la case ``cle``."""
        champ, signe = self.champs[cle], self.signes[cle]
        nu = texte.strip()
        if signe and nu and nu[0] not in "+-=":  # « 32 » → « - 32 » : le signe d'abord, le curseur reste après la frappe
            position = champ.cursorPosition()
            champ.setText(signe + nu)
            champ.setCursorPosition(position + len(signe) - (len(texte) - len(texte.lstrip())))
        elif signe and nu == signe.strip() and len(texte) < len(self.avant.get(cle, "")):
            champ.clear()  # le chiffre effacé : le signe posé par le lecteur s'en va avec, la case redevient vide
        if cle[0] in "bz" and nu in ("0", "1"):
            self.aller(champ, 1, 0)

    def aller(self, champ, dx, dy):
        """Donne la main à la case visible la plus proche de ``champ`` dans la direction (dx, dy), texte sélectionné."""
        depart, meilleur = champ.geometry().center(), None
        for autre in self.champs.values():
            if autre is champ or not autre.isVisible():
                continue
            v = autre.geometry().center() - depart
            avance, ecart = v.x() * dx + v.y() * dy, abs(v.x() * dy) + abs(v.y() * dx)
            if avance > 0 and ecart <= 2 * avance:  # dans un cône de ±63° autour de la direction
                if meilleur is None or avance + 2 * ecart < meilleur[0]:
                    meilleur = (avance + 2 * ecart, autre)
        if meilleur:
            meilleur[1].setFocus(Qt.FocusReason.OtherFocusReason)
            meilleur[1].selectAll()
        return meilleur is not None

    def eventFilter(self, champ, evenement):
        if evenement.type() not in (QEvent.Type.KeyPress, QEvent.Type.FocusOut):  # tout le reste (peinture, géométrie,
            return False  # style : des milliers à la construction) n'est pas une frappe
        pris = ChampConversion.frappe(champ, evenement)
        if pris is not None:
            return pris
        modificateurs, texte = evenement.modifiers() & ~Qt.KeyboardModifier.KeypadModifier, evenement.text()
        if evenement.key() == Qt.Key.Key_Backspace and not modificateurs and not champ.text():  # case vide : on remonte à
            return self.retour(champ)  # la précédente (l'utilisateur, 04/10/2026)
        if modificateurs & ~Qt.KeyboardModifier.ShiftModifier or not texte:  # Ctrl+C, Ctrl+Z… ; flèches, effacement
            return (modificateurs == Qt.KeyboardModifier.NoModifier and isinstance(champ, ChampConversion)
                    and self.fleche(champ, evenement.key()))
        if texte in "xX*" and champ.text().strip() not in ("0", "-0"):  # « 0x2E » : le préfixe Python reste
            champ.insert("×")
            return True
        if texte == "+":
            return self.terme_suivant(champ)
        return False

    def terme_suivant(self, champ):
        """« + » dans une case d'un polynôme aux niveaux 1 et 2 : la case suivante de la ligne, ouverte d'abord au niveau 2."""
        q = self.question
        cle = next(k for k, c in self.champs.items() if c is champ)
        if q.procede() != "polynomial" or q.niveau > 2 or not re.fullmatch(r"[tw]\d+", cle):
            return False
        ligne, j = cle[0], int(cle[1:])
        if q.niveau == 2:
            self.ouvertes[ligne] = max(self.ouvertes.get(ligne, 0), j + 2)
            self.actualiser()
        suivante = self.champs.get(f"{ligne}{j + 1}")
        if suivante is not None and suivante.isVisibleTo(self):
            suivante.setFocus(Qt.FocusReason.OtherFocusReason)
            suivante.selectAll()
        return True

    def fleche(self, champ, touche):
        """Une flèche sans modificateur passe à la case voisine (gauche et droite seulement depuis le bord du texte)."""
        tout = champ.selectedText() == champ.text()
        if touche == Qt.Key.Key_Up:
            return self.aller(champ, 0, -1)
        if touche == Qt.Key.Key_Down:
            return self.aller(champ, 0, 1)
        if touche == Qt.Key.Key_Left and (tout or champ.cursorPosition() == 0):
            return self.aller(champ, -1, 0) or self.a_la_ligne(champ, -1)
        if touche == Qt.Key.Key_Right and (tout or champ.cursorPosition() == len(champ.text())):
            return self.aller(champ, 1, 0) or self.a_la_ligne(champ, 1)
        return False

    def retour(self, champ):
        """Retour arrière dans une case vide : la case précédente, comme ←, mais le curseur au bout de son texte, pour que
        les retours suivants l'effacent chiffre par chiffre."""
        if self.aller(champ, -1, 0) or self.a_la_ligne(champ, -1):
            precedente = QApplication.focusWidget()
            if isinstance(precedente, QLineEdit):
                precedente.deselect()
                precedente.end(False)
        return True

    def a_la_ligne(self, champ, sens):
        """Au bout d'une ligne, → passe à la première case de la ligne suivante, ← à la dernière de la précédente, comme
        on lit : de la dernière puissance pondérée, le « nombre décimal » dessous (l'utilisateur, 04/10/2026) — rien dans le
        cône de ``aller``, la flèche faisait défiler la page. Au bout de la grille, la flèche ne fait rien, mais est prise."""
        ordre = sorted((c for c in self.champs.values() if c.isVisible()), key=lambda c: (c.y(), c.x()))
        i = ordre.index(champ) + sens if champ in ordre else -1
        if 0 <= i < len(ordre):
            ordre[i].setFocus(Qt.FocusReason.OtherFocusReason)
            ordre[i].selectAll()
        return True

    def actualiser(self):
        """Le plan de ce qui est écrit : la figure à repeindre, les champs à placer, ceux d'une division refermée à cacher
        (ce qu'ils contiennent n'est plus lu, voir ``Conversion._lire``)."""
        q = self.question
        ouvrir = {}
        if self.corrigee and q.procede() in ("divisions", "polynomial"):  # les divisions et les termes que la correction
            ouvrir = {k: v for k, v in q.juste().items() if k[0] in "qtw"}  # écrit : dans des cases ouvertes pour elle
        self.plan = q.plan({**ouvrir, **self.ecrites(), **{"+" + ligne: k for ligne, k in self.ouvertes.items()}})
        if self.corrigee:  # les cases que la correction écrit ont leurs flèches, comme si l'élève les avait remplies (demande
            # de l'utilisateur, 04/10/2026 : « il manque les flèches sur la correction de la question 10 ») : celles du plan
            # juste, entre deux cases de cette grille-ci
            juste = {k: v for k, v in q.juste().items() if k != "methode"}
            cles = {c["cle"] for c in self.plan["cases"]}
            self.plan["fleches"] = [f for f in q.plan({**juste, **self.ecrites()})["fleches"] if {f["de"], f["vers"]} <= cles]
        self.sens = self.sens_de_lecture()  # le sens de lecture des restes est la réponse : montré après une première
        if not self.sens:  # soumission ou un indice (demande de l'utilisateur, 03/10/2026)
            self.plan["fleches"] = [f for f in self.plan["fleches"] if f["genre"] != "lecture"]
        self.dessiner(q)
        g = q.geometrie(self.plan)
        self.repere = q, g  # pour ``placer`` : ``question`` et ``geometrie`` se recalculent à chaque appel
        self.naturelle = (g["x"](self.plan["largeur"]) + 1, g["y"](self.plan["hauteur"]) + 1)  # en points
        self.setMinimumWidth(math.ceil(self.naturelle[0] * min(self.maxi(), self.ECHELLE_MINI)))
        self.updateGeometry()  # une division ouverte allonge la grille
        self.placer()
        self.update()
        surimpression = getattr(self._question(), "surimpression", None)
        if surimpression is not None and surimpression.montree:
            surimpression.update()

    def sens_de_lecture(self):
        etat = self._question()
        return bool(etat.seconde or etat.fermee or etat.debloques)

    def maxi(self):
        """Pixels par point au corps du sujet : la police de la grille, que lui donne la feuille de style du sujet."""
        return QFontInfo(self.font()).pixelSize() / noyau.Conversion.CORPS

    def sizeHint(self):
        return QSize(math.ceil(self.naturelle[0] * self.maxi()), self.heightForWidth(math.ceil(self.naturelle[0] * self.maxi())))

    def heightForWidth(self, largeur):
        return math.ceil(self.naturelle[1] * min(self.maxi(), largeur / self.naturelle[0]))

    def poser(self, case, x, y, l, h):
        """Le champ de ``case`` sur son rectangle (en pixels), sa ligne de base sur celle de ``noyau.svg`` : le SVG noircit
        la rangée de pixels où tombe la sienne (63,4 : la 63e), le champ celle au-dessus de la sienne."""
        champ = self.champs[case["cle"]]
        q, g = self.repere
        base = math.floor(q.ligne_de_base(self.plan, case, g) * self.echelle) + 1 - y
        if self.poses.get(case["cle"]) == (x, y, l, h, base, self.echelle):  # une frappe replace toutes les cases : seules
            return  # celles qui ont bougé (une division ouverte, une autre échelle) sont à recaler
        self.poses[case["cle"]] = (x, y, l, h, base, self.echelle)
        champ.setGeometry(x, y, l, h)
        if isinstance(champ, ChampConversion):
            champ.caler(base)

    def styler(self):
        """L'échelle de la largeur reçue (pixels par point), et les chiffres des champs à son corps."""
        echelle = min(self.maxi(), self.width() / self.naturelle[0])
        if echelle != self.echelle:
            self.echelle, marge = echelle, round(noyau.Conversion.MARGE * echelle)  # le texte où le SVG l'écrit
            for cle, champ in self.champs.items():  # le corps dans la feuille de style, pas setFont : celle du sujet
                champ.setStyleSheet(f"{self.styles[cle]} font-size: {round(noyau.Conversion.CORPS * echelle)}px; }}")
                champ.poser_marges(marge - 2, marge - 5)  # (« QWidget { font-size: 12pt } ») l'emporterait ; marges
                # moins ce que Qt y ajoute (mesuré : le chiffre saisi sur celui du PDF, à 1 px)
        return echelle

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.placer()


class GrilleConversion(SaisieConversion):
    """La figure d'une question ``conversion`` : le SVG du noyau peint en fond, les champs posés sur ses cases."""

    def support(self):
        """Le parent des champs : la grille elle-même, que la figure peint en fond."""
        return self

    def dessiner(self, q):
        """La figure du plan : le SVG peint en fond, ses traits droits à part (``_tracer_nets``)."""
        svg = q.svg(self.plan, police=self.font().family(), ecrites=self.ecrites())
        self.traits = [{k: v for k, v in re.findall(r'([\w-]+)="([^"]*)"', m)} for m in re.findall(f"<(?:rect|line) ([^>]*{noyau.NET})/>", svg)]
        self.rendu = QSvgRenderer(QByteArray(re.sub(f"<(?:rect|line) [^>]*{noyau.NET}/>", "", svg).encode()))

    def placer(self):
        """Les champs sur leurs cases, à l'échelle de la largeur reçue, et leurs chiffres au corps de la figure."""
        echelle = self.styler()
        presentes = set()
        for c in self.plan["cases"]:
            if c["remplir"]:
                x, y, l, h = (round(v * echelle) for v in self.repere[0].rectangle(self.plan, c, self.repere[1]))
                self.poser(c, x, y, l, h)
                presentes.add(c["cle"])
        for cle, champ in self.champs.items():
            champ.setVisible(cle in presentes)

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        cible = QRectF(0, 0, self.naturelle[0] * self.echelle, self.naturelle[1] * self.echelle)
        self.rendu.render(peintre, cible)
        self._tracer_nets(peintre, cible.width() / self.rendu.viewBoxF().width())
        peintre.end()

    def _tracer_nets(self, peintre, echelle):
        """Les traits droits de la grille (``noyau.NET``), sans anticrénelage et calés au centre d'un pixel de l'écran :
        chaque bord fait un pixel net (deux pour un trait épais), où qu'il tombe."""
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        ratio = self.devicePixelRatioF()
        cale = lambda v: (math.floor(v * echelle * ratio) + 0.5) / ratio  # noqa: E731
        for t in self.traits:
            stylo = QPen(QColor(t["stroke"]), max(1, round(float(t["stroke-width"]) * echelle * ratio)) / ratio)
            peintre.setPen(stylo)
            peintre.setBrush(Qt.BrushStyle.NoBrush)
            if "x1" in t:
                peintre.drawLine(QPointF(cale(float(t["x1"])), cale(float(t["y1"]))), QPointF(cale(float(t["x2"])), cale(float(t["y2"]))))
            else:
                x, y = float(t["x"]), float(t["y"])
                peintre.drawRect(QRectF(QPointF(cale(x), cale(y)), QPointF(cale(x + float(t["width"])), cale(y + float(t["height"])))))


class TableConversion(SaisieConversion):
    """La grille d'une question ``en_tableau`` (à l'essai, à côté de ``GrilleConversion`` pour comparer : l'utilisateur,
    04/10/2026) : un vrai tableau Qt, ses cellules tirées du plan par ``noyau.Conversion.tableau`` (fusions comprises), les
    champs posés sur leurs cellules, les textes donnés et les étiquettes peints par le tableau, les flèches par-dessus
    (``svg(calque=True)``). Saisie, navigation, propagation, rattrapage et surimpression : ``SaisieConversion``. Le
    tableau est en (0, 0), ses champs ont les coordonnées qu'ils auraient sur la figure."""

    class Tableau(QTableWidget):
        def __init__(self, grille):
            super().__init__(grille)
            self.grille = grille
            for entete in (self.horizontalHeader(), self.verticalHeader()):
                entete.hide()
                entete.setMinimumSectionSize(1)
            self.setFrameShape(QFrame.Shape.NoFrame)
            self.setShowGrid(False)
            self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            self.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
            self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            self.setStyleSheet("QTableView { background: transparent; border: none; }")
            self.setItemDelegate(TableConversion.Peintre(self))

        def wheelEvent(self, evenement):
            evenement.ignore()  # rien à faire défiler : la molette va à la page

        def paintEvent(self, evenement):
            super().paintEvent(evenement)  # fonds et textes (``Peintre``), puis les bords et les flèches
            g = self.grille
            peintre = QPainter(self.viewport())
            ratio = self.devicePixelRatioF()
            peintre.setBrush(Qt.BrushStyle.NoBrush)
            for c in g.cellules["cellules"]:
                x0, y0, x1, y1 = g.coins(c)
                if c["bord"]:  # chaque bord sur le pixel qui commence la cellule suivante : deux voisines le partagent
                    peintre.setPen(QPen(QColor("#7f7f7f"), max(1, round(0.75 * g.echelle * ratio)) / ratio))
                    peintre.drawRect(QRectF(x0 + 0.5, y0 + 0.5, x1 - x0, y1 - y0))
                if c["epais"]:
                    peintre.setPen(QPen(QColor("#000000"), max(1, round(1.5 * g.echelle * ratio)) / ratio))
                    peintre.drawLine(QPointF(x0 + 0.5, y0), QPointF(x0 + 0.5, y1 + 1))
            peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
            g.rendu.render(peintre, QRectF(0, 0, g.naturelle[0] * g.echelle, g.naturelle[1] * g.echelle))
            peintre.end()

    class Peintre(QStyledItemDelegate):
        """Une cellule comme ``noyau.svg`` l'écrit : son fond, puis le texte donné à sa ligne de base, à ``MARGE`` du bord,
        l'exposant ou la base qui le termine dans la marge ; une étiquette centrée, ligne par ligne."""

        def paint(self, peintre, option, index):
            g = self.parent().grille
            c = g.par_position.get((index.row(), index.column()))
            if c is None:
                return
            x0, y0, x1, y1 = g.coins(c)
            e, q = g.echelle, g.question
            if c["fond"]:
                peintre.fillRect(QRect(x0, y0, x1 - x0, y1 - y0), QColor(c["fond"]))
            quoi = c["case"] or c["etiquette"]
            if quoi is None or c["case"] and c["case"]["remplir"]:
                return
            police, metrique = g.police(bool(quoi.get("gras")))
            peintre.save()
            peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
            peintre.setFont(police)
            peintre.setPen(QColor(quoi.get("couleur") or "#000000"))
            if c["etiquette"]:
                lignes = quoi["texte"].split("\n")
                haut = y0 + (y1 - y0 - len(lignes) * q.CORPS * 1.2 * e) / 2
                for i, ligne in enumerate(lignes):
                    peintre.drawText(QPointF((x0 + x1 - metrique.horizontalAdvance(ligne)) / 2,
                                             haut + (i + 0.82) * q.CORPS * 1.2 * e), ligne)
            elif str(quoi["texte"]).strip():
                base = y0 + (y1 - y0) / 2 + q.CORPS * 0.36 * e
                corps, queue = noyau.queue_suscrite(quoi["texte"]) if quoi["aligne"] == "d" else (quoi["texte"], "")
                largeur = metrique.horizontalAdvance(corps)
                x = {"d": x1 - q.MARGE * e - largeur, "g": x0 + q.MARGE * e}.get(quoi["aligne"], (x0 + x1 - largeur) / 2)
                peintre.drawText(QPointF(x, base), corps + queue)
            peintre.restore()

    def support(self):
        if not hasattr(self, "table"):
            self.table = TableConversion.Tableau(self)
            self.cellules, self.par_position, self.bornes, self.structure = {"cellules": []}, {}, ([0], [0]), None
        return self.table.viewport()

    def dessiner(self, q):
        self.rendu = QSvgRenderer(QByteArray(q.svg(self.plan, police=self.font().family(), calque=True).encode()))
        self.cellules = q.tableau(self.plan)
        self.par_position = {(c["ligne"], c["colonne"]): c for c in self.cellules["cellules"]}
        fusions = [(c["ligne"], c["colonne"], c["hauteur"], c["largeur"]) for c in self.cellules["cellules"]
                   if c["hauteur"] > 1 or c["largeur"] > 1]
        structure = self.cellules["lignes"], self.cellules["colonnes"], fusions
        if structure == self.structure:  # une frappe change les textes, pas le tableau : ni fusions ni tailles à refaire
            return
        self.structure, self.bornes = structure, ([0], [0])  # d'autres lignes et colonnes : ``placer`` les redimensionne
        t = self.table
        t.clearSpans()
        t.setRowCount(len(self.cellules["lignes"]))
        t.setColumnCount(len(self.cellules["colonnes"]))
        for fusion in fusions:
            t.setSpan(*fusion)

    def coins(self, c):
        """Les bords d'une cellule en pixels : (gauche, haut, droite, bas), chacun au premier pixel de la suivante."""
        xs, ys = self.bornes
        return xs[c["colonne"]], ys[c["ligne"]], xs[c["colonne"] + c["largeur"]], ys[c["ligne"] + c["hauteur"]]

    def police(self, gras):
        """La police des textes peints et ses métriques, au corps de l'échelle : une par échelle, pas une par cellule peinte."""
        if getattr(self, "_polices", (None,))[0] != self.echelle:
            self._polices = self.echelle, {}
        if gras not in self._polices[1]:
            police = QFont(self.font())
            police.setPixelSize(max(1, round(noyau.Conversion.CORPS * self.echelle)))
            police.setBold(gras)
            self._polices[1][gras] = police, QFontMetricsF(police)
        return self._polices[1][gras]

    def placer(self):
        e = self.styler()
        bornes = lambda tailles: [round(v * e) for v in itertools.accumulate(tailles, initial=0)]  # noqa: E731
        xs, ys = bornes(self.cellules["colonnes"]), bornes(self.cellules["lignes"])
        if (xs, ys) != self.bornes:  # chaque setColumnWidth relance la mise en page du tableau : seulement si elle change
            self.bornes = xs, ys
            for j in range(len(xs) - 1):
                self.table.setColumnWidth(j, xs[j + 1] - xs[j])
            for i in range(len(ys) - 1):
                self.table.setRowHeight(i, ys[i + 1] - ys[i])
            self.table.setGeometry(0, 0, xs[-1] + 1, ys[-1] + 1)
        presentes = set()
        for c in self.cellules["cellules"]:
            if c["case"] and c["case"]["remplir"]:
                x0, y0, x1, y1 = self.coins(c)
                self.poser(c["case"], x0, y0, x1 - x0, y1 - y0)
                presentes.add(c["case"]["cle"])
        for cle, champ in self.champs.items():
            champ.setVisible(cle in presentes)
        self.table.viewport().update()


def grille_conversion(question, methode=None, figure=None):
    """La grille d'une conversion : un vrai tableau pour une question ``en_tableau`` dont la méthode en est un, la figure
    sinon (les divisions et le polynôme ne sont pas des tableaux)."""
    q = (figure or question).pour({"methode": methode})
    tableau = q.en_tableau and q.plan(tout=True)["grille"]
    return (TableConversion if tableau else GrilleConversion)(question, methode, figure)


class Conversion(Annotee, noyau.Conversion, Question):

    """Quand l'élève choisit sa méthode : un bouton par méthode au-dessus des grilles, une seule grille visible, celle du
    bouton coché ; ce qui est écrit dans une autre grille y reste, mais n'est pas lu.

    Le rattrapage (``noyau.Conversion.soumettre``) : la grille du premier essai se fige, sa correction s'écrit dessous en
    rouge, puis la consigne et la grille du second essai (``grille_bis``), dont la saisie va sous la clé « bis »."""

    grille_bis = None

    def _corps(self, d):
        self.grilles, self.boutons, self.zone_bis = {}, {}, QVBoxLayout()
        self.surimpression = SurimpressionConversion(self)
        if "{" in self.nombre:  # tiré par ``variables`` : la question brute d'une banque, que l'on lit sans l'afficher
            d.addWidget(Texte(f"*Nombre tiré au hasard : {self.nombre}*", inline=True))
            return
        if self.demande_base():
            d.addWidget(Texte(f"*{noyau.CONSIGNE_BASE_ECRAN.format(quoi='le résultat')}*", inline=True))
        self.grilles = {m: grille_conversion(self, m) for m in self.methodes()}
        if len(self.grilles) > 1:
            rangee, groupe = QHBoxLayout(), QButtonGroup(self)
            rangee.addWidget(QLabel("Méthode :"))
            for m in self.grilles:
                self.boutons[m] = QRadioButton(noyau.NOM_METHODE[m])
                self.boutons[m].toggled.connect(self._montrer)
                groupe.addButton(self.boutons[m])
                rangee.addWidget(self.boutons[m])
            rangee.addStretch()
            d.addLayout(rangee)
            self.boutons[self.procede()].setChecked(True)
        for grille in self.grilles.values():
            d.addWidget(grille)
            self.entrees += grille.champs.values()
        self.entrees += self.boutons.values()
        d.addLayout(self.zone_bis)  # vide jusqu'au rattrapage
        self._montrer()

    def _ouvrir_bis(self):
        if self.grille_bis or not self.grilles:
            return
        correction, consigne = self.correction_premier()
        figes = [*(c for g in self.grilles.values() for c in g.champs.values()), *self.boutons.values()]
        self.entrees = [w for w in self.entrees if all(w is not f for f in figes)]
        for w in figes:
            w.setGraphicsEffect(None)
            w.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            if isinstance(w, (QLineEdit, QPlainTextEdit)):
                w.setReadOnly(True)  # lisible tel quel : désactivé, Qt le griserait
                w.setEnabled(True)
            else:
                w.setEnabled(False)
        for g in self.grilles.values():
            g.gelee = True
        texte = Texte(correction, manuscrit=True)  # écrite à la main comme la correction sous la question, jamais voilée
        self.ecrits = [(texte, "#c0392b")]
        self._styler_ecrits(False)
        self.zone_bis.addWidget(texte)
        self.zone_bis.addWidget(Texte(consigne))
        self.grille_bis = grille_conversion(self, figure=self.bis(self.premier(self._lire())))
        self.zone_bis.addWidget(self.grille_bis)
        self.entrees += self.grille_bis.champs.values()
        self.mettre_a_jour()
        self._annoter(False)  # la grille figée corrigée par-dessus

    def _annoter(self, montree):
        """Une grille figée par le rattrapage reste corrigée en surimpression, la correction complète du premier essai sur
        sa grille plutôt qu'écrite dessous (demande de l'utilisateur, 04/10/2026)."""
        for grille in [*self.grilles.values(), *filter(None, [self.grille_bis])]:
            if grille.corrigee != (montree or grille.gelee):
                grille.corrigee = montree or grille.gelee
                grille.actualiser()
        super()._annoter(montree or bool(self.grille_bis))

    def _attendu(self):
        return ""  # les deux grilles corrigées à la main (``SurimpressionConversion``) : rien répété dessous (04/10/2026)

    @property
    def grille(self):
        return self.grilles[next((m for m, b in self.boutons.items() if b.isChecked()), self.methodes()[0])]

    def _montrer(self):
        for grille in self.grilles.values():
            grille.setVisible(grille is self.grille)

    def mettre_a_jour(self):
        super().mettre_a_jour()
        for grille in [*self.grilles.values(), *filter(None, [self.grille_bis])]:  # la flèche du sens de lecture paraît à
            if grille.sens != grille.sens_de_lecture():  # la première soumission ou au premier indice
                grille.actualiser()

    def _lire(self):
        if not self.grilles:
            return None
        saisie = self._ecrites(self.grille)
        if saisie and self.boutons:
            saisie["methode"] = self.grille.methode
        if self.grille_bis and (bis := self._ecrites(self.grille_bis)):
            saisie["bis"] = bis
        return saisie or None

    @staticmethod
    def _ecrites(grille):
        presentes = {c["cle"] for c in grille.plan["cases"] if c["remplir"]}
        return {k: v for k, v in grille.ecrites().items() if k in presentes}

    @staticmethod
    def _poser(champ, texte):
        """Sans signal (une réponse rechargée ne se recopie ni ne se signe), mais la marge suit le texte : sans ``recaler``,
        une case rechargée gardait celle d'une case vide, ses chiffres un « 0 » à gauche des autres (03/10/2026)."""
        champ.blockSignals(True)
        champ.setText(texte)
        champ.blockSignals(False)
        if isinstance(champ, ChampConversion):
            champ.recaler()

    def _ecrire(self, valeur):
        if self.boutons:
            self.boutons[self.pour(valeur).methode].setChecked(True)
        for grille in self.grilles.values():
            for cle, champ in grille.champs.items():
                self._poser(champ, str((valeur or {}).get(cle, "")) if grille is self.grille else "")
            grille.precedent = {cle: grille.champs[cle].text() for cle in grille.puissances}
            grille.actualiser()
        bis = (valeur or {}).get("bis") or {}
        if bis:
            self._ouvrir_bis()
        if self.grille_bis:
            for cle, champ in self.grille_bis.champs.items():
                self._poser(champ, str(bis.get(cle, "")))
            self.grille_bis.actualiser()


class SurimpressionOrdre(Surimpression):
    """La correction à la main d'un rangement (04/10/2026) : devant chaque étiquette ou ligne, dans la marge, son bon
    rang écrit à la main, en vert si elle est à sa place, en rouge sinon ; une ligne de code mal indentée reçoit en plus
    une flèche rouge sous son début, jusqu'à la colonne où elle devait commencer. Écarté : flécher chaque élément vers
    sa place, illisible dès trois éléments déplacés, et raturer l'élément, qui n'est pas faux mais mal placé."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        if q.langage:
            e = q.editeur
            origine = QPointF(e.viewport().mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos())
            pas, justes = e.fontMetrics().horizontalAdvance(" " * PAS), q.niveaux_justes()
            rangees = []
            for k, (i, n) in enumerate(zip(e.ordre, e.niveaux)):
                curseur = QTextCursor(e.document().findBlockByNumber(k))
                curseur.movePosition(QTextCursor.MoveOperation.Right, n=PAS * n)
                ligne = QRectF(e.cursorRect(curseur)).translated(origine)
                if i >= len(q.elements):  # une ligne distractrice : barrée sur toute sa longueur
                    ligne.setWidth(e.fontMetrics().horizontalAdvance(e.lignes[i]) + 2 * Etiquette.RETRAIT)
                    ligne.translate(-Etiquette.RETRAIT, 0)
                rangees.append((i, ligne))
                if i < len(q.elements) and n != justes[i]:
                    debut, fin = QPointF(ligne.left(), ligne.bottom()), QPointF(ligne.left() + (justes[i] - n) * pas, ligne.bottom())
                    sens = 1 if fin.x() > debut.x() else -1
                    self.stylo(peintre, self.ROUGE, 2)
                    peintre.drawLine(debut, fin)
                    peintre.drawPolyline(QPolygonF([fin + QPointF(-6 * sens, -4), fin, fin + QPointF(-6 * sens, 4)]))
            gauche, taille = self.cadre(q.console if q.executable else e).left(), QFontInfo(e.font()).pixelSize()
            justes = q.juste()
        else:  # vers la suite juste la plus proche de celle de l'élève (``variantes``)
            rangees, justes = self.rangees(q.liste), q.suite_visee(q._lire())
            gauche, taille = self.cadre(q.liste).left(), QFontInfo(q.liste.font()).pixelSize()
        hauteur = QFontMetricsF(QFont()).capHeight()  # le rang centré sur la ligne, à peu près : l'écriture est penchée
        for k, (i, rangee) in enumerate(rangees):
            if i not in justes:  # un intrus mis dans la suite : barré
                self.raturer(peintre, rangee.left() + Etiquette.RETRAIT, rangee.right() - Etiquette.RETRAIT, rangee.center().y())
                continue
            self.ecrire(peintre, QPointF(gauche - 6, rangee.center().y() + hauteur / 2), str(justes.index(i) + 1), taille,
                        self.VERT if k < len(justes) and justes[k] == i else self.ROUGE, droite=True)
        if q.intrus:  # une étape oubliée dans la réserve : son rang en rouge devant elle
            gauche = self.cadre(q.reserve).left()
            for i, rangee in self.rangees(q.reserve):
                if i in justes:
                    self.ecrire(peintre, QPointF(gauche - 6, rangee.center().y() + hauteur / 2), str(justes.index(i) + 1),
                                taille, self.ROUGE, droite=True)

    def rangees(self, liste):
        """(indice de l'élément, cadre) de chaque étiquette de ``liste``, dans les coordonnées de la surimpression."""
        origine = QPointF(liste.viewport().mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos())
        return [(liste.item(k).data(Qt.ItemDataRole.UserRole), QRectF(liste.visualItemRect(liste.item(k))).translated(origine))
                for k in range(liste.count())]


class Ordre(Annotee, noyau.Ordre, Question):

    def _corps(self, d):
        self.surimpression = SurimpressionOrdre(self)
        if self.langage:
            saisir = " Appuyez un instant sur une ligne pour la saisir." if tactile.ACTIF else ""  # l'appui long, au doigt seulement
            d.addWidget(Texte(dire("*Glissez les lignes dans le bon ordre, et indentez-les en les glissant vers la droite ou par Tab / "
                                   f"Maj+Tab (Ctrl+Z annule) ; le texte, lui, ne se modifie pas.{saisir}*"), inline=True))
            lignes = [code_nu(e) for e in self.elements + self.intrus]
            # avec intrus, toutes les lignes partent de la réserve (« Lignes proposées ») et l'éditeur est vide
            self.editeur = hauteur(EditeurLignes(lignes, [] if self.intrus else self.depart, None if self.intrus else
                                                 [0] * len(lignes)), len(lignes))  # suit la police du sujet, posée après
            # : une ligne restait cachée
            if self.executable:
                self.console = ConsoleCode(self.editeur, self)  # la console porte l'éditeur, entre ses boutons et sa sortie
                d.addWidget(self.console)
                self.entrees.append(self.console)
            else:
                d.addWidget(self.editeur)
            self.entrees.append(self.editeur)
            if self.intrus:
                self._reserve_de_code(d, lignes)
            return
        # les étiquettes d'un classement : même police que l'énoncé, un élément long va à la ligne, et la hauteur
        # se recalcule à la largeur réelle — mesurée avant l'affichage, elle coupait les derniers éléments
        if self.intrus:
            return self._corps_intrus(d)
        self.liste = etiquettes(lambda: self.liste.setFixedHeight(hauteur_etiquettes(self.liste, self.elements)))
        self.liste.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        tactile.AppuiLong(self.liste.viewport(), self._saisir)  # au doigt, un glissé fait défiler la page
        self._ecrire(None)
        consigne = " : appuyez un instant sur un élément pour le saisir" if tactile.ACTIF else ""  # l'appui long, au doigt seulement
        d.addWidget(Texte(dire(f"*Glissez les éléments dans le bon ordre{consigne}.*"), inline=True))
        d.addWidget(self.liste)
        self.entrees.append(self.liste)

    def _corps_intrus(self, d):
        """Avec ``intrus`` : la réserve « Étapes proposées », qui les contient toutes au départ, et « Votre suite » à
        sa droite, comme les colonnes d'un ``Classement``. Une étape se glisse d'une liste à l'autre, et se range dans la
        suite en l'y glissant ; un appui simple (le geste sûr au doigt) l'ajoute au bout de la suite, ou l'en retire."""
        grille = QGridLayout()
        self.reserve, self.liste = etiquettes(self._ajuster), etiquettes(self._ajuster)
        for k, (titre, liste) in enumerate([("Étapes proposées", self.reserve), ("Votre suite", self.liste)]):
            grille.addWidget(Texte(f"*{titre}*" if k == 0 else f"**{titre}**", inline=True), 0, k)
            liste.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
            liste.touchee.connect(functools.partial(self._basculer, liste))
            grille.addWidget(liste, 1, k)
            grille.setColumnStretch(k, 1)
        self._ecrire(None)
        d.addWidget(Texte(dire("*Glissez les étapes utiles dans « Votre suite », dans l'ordre ; certaines n'en font pas "
                               "partie. Un appui simple ajoute une étape au bout de la suite, ou l'en retire.*"), inline=True))
        d.addLayout(grille)
        self.entrees += [self.reserve, self.liste]

    def _reserve_de_code(self, d, lignes):
        """Un Parsons à lignes distractrices (1.3) : sous l'éditeur, la réserve des lignes qu'il ne contient pas, dans
        l'ordre ``depart`` ; un appui y envoie une ligne au bout de l'éditeur, la croix de l'éditeur l'y renvoie. La
        réserve se déduit de l'éditeur à chaque changement : Ctrl+Z la suit sans rien à défaire de son côté."""
        self.editeur.retirable = True
        self.textes_reserve = [f"`{l.lstrip(' ')}`" for l in lignes]
        self.reserve = etiquettes(lambda: self.reserve.setFixedHeight(hauteur_etiquettes(self.reserve, self.textes_reserve)))
        self.reserve.touchee.connect(lambda element: self.editeur.ajouter(element.data(Qt.ItemDataRole.UserRole)))
        self.editeur.textChanged.connect(self._garnir_reserve)
        self._garnir_reserve()
        d.insertWidget(d.count() - 1, Texte(dire("*Envoyez dans l'éditeur, d'un appui, les lignes utiles ; certaines n'en "
                                                  "font pas partie. La croix au bout d'une ligne la renvoie parmi les lignes proposées.*"), inline=True))
        d.addWidget(Texte("*Lignes proposées*", inline=True))
        d.addWidget(self.reserve)
        self.entrees.append(self.reserve)

    def _garnir_reserve(self):
        self.reserve.clear()
        for i in self.depart:
            if i not in self.editeur.ordre:
                self.reserve.addItem(self._etiquette(self.textes_reserve, i))

    def _saisir(self, position):
        element = self.liste.itemAt(position.toPoint())
        if element is not None and self.liste.isEnabled():
            self.liste.setCurrentItem(element)
            self.liste.startDrag(Qt.DropAction.MoveAction)

    def _ajuster(self):
        """Les deux listes à la hauteur de toutes les étapes : la suite peut toutes les recevoir."""
        hauteur = hauteur_etiquettes(self.reserve, self.elements + self.intrus)
        self.reserve.setFixedHeight(hauteur)
        self.liste.setFixedHeight(hauteur)

    def _basculer(self, liste, element):
        (self.liste if liste is self.reserve else self.reserve).addItem(liste.takeItem(liste.row(element)))

    def _attendu(self):
        return ""  # le bon rang écrit devant chaque élément (``SurimpressionOrdre``)

    def _lire(self):
        if self.intrus and not self.langage:
            return [self.liste.item(k).data(Qt.ItemDataRole.UserRole) for k in range(self.liste.count())] or None
        if self.langage:
            ordre, niveaux = list(self.editeur.ordre), list(self.editeur.niveaux)
            vide = not ordre if self.intrus else ordre == self.depart and not any(niveaux)
            return None if vide else {"ordre": ordre, "niveaux": niveaux}
        ordre = [self.liste.item(k).data(Qt.ItemDataRole.UserRole) for k in range(self.liste.count())]
        return None if ordre == self.depart else ordre

    def _ecrire(self, valeur):
        if self.langage:  # une liste (le corrigé, une ancienne copie) se montre avec la bonne indentation
            if valeur is None:
                self.editeur.ranger(*([], []) if self.intrus else (self.depart, [0] * len(self.elements)))
            elif isinstance(valeur, dict):
                self.editeur.ranger(valeur["ordre"], valeur["niveaux"])
            else:
                self.editeur.ranger(valeur)
            return
        etapes = self.elements + self.intrus
        self.liste.clear()
        if self.intrus:
            self.reserve.clear()
            for i in self.depart:
                if i not in (valeur or []):
                    self.reserve.addItem(self._etiquette(etapes, i))
        for i in (valeur or []) if self.intrus else self.depart if valeur is None else valeur:
            self.liste.addItem(self._etiquette(etapes, i))

    @staticmethod
    def _etiquette(textes, i):
        element = QListWidgetItem(textes[i])  # le Markdown, c'est ``Etiquette`` qui le peint
        element.setData(Qt.ItemDataRole.UserRole, i)
        return element


GOUTTIERE = 140  # la colonne où se tracent les liens d'un appariement, entre les deux rangées de puces, en pixels
RAYON_PUCE = 6  # rayon d'une puce d'appariement, en pixels


class Liens(QWidget):
    """La gouttière d'un ``Appariement``, comme sur le papier : une puce au bout de chaque élément, de chaque côté, et
    les traits qui les relient. On tire un trait d'une puce vers une puce d'en face, dans un sens ou dans l'autre, ou
    l'on clique l'une puis l'autre (la puce ou son texte). Retirer un trait de sa puce de gauche et le lâcher dans le
    vide le défait. ``liens`` : pour chaque élément de gauche, la position de son élément à droite, ou ``None``."""

    def __init__(self, gauches, droites):
        super().__init__()
        self.gauches, self.droites = gauches, droites  # les textes, qui donnent la hauteur de chaque puce
        self.liens = [None] * len(gauches)
        self.origine = None  # (côté, rang) de la puce d'où part le trait en cours, ou celle cliquée en attente de l'autre
        self.souris = None  # où suit le trait en cours ; ``None`` une fois la puce seulement cliquée
        self.setFixedWidth(GOUTTIERE)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Ignored)  # la hauteur est celle des rangées de texte
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_AcceptTouchEvents)  # sinon le doigt fait défiler la page (un ancêtre,
        # defiler_au_doigt) au lieu de tirer un trait : voir tactile.relayer_en_souris

    def event(self, evenement):
        if evenement.type() in (QEvent.Type.TouchBegin, QEvent.Type.TouchUpdate, QEvent.Type.TouchEnd):
            if tactile.relayer_en_souris(self, evenement):
                return True
        return super().event(evenement)

    def _puce(self, cote, rang):
        texte = (self.gauches if cote == 0 else self.droites)[rang]
        y = texte.geometry().center().y() - self.geometry().top()
        return QPointF(RAYON_PUCE + 2 if cote == 0 else self.width() - RAYON_PUCE - 2, y)

    def _visee(self, position):
        """La puce la plus proche en hauteur, du côté de la gouttière où est la souris."""
        cote = 0 if position.x() < self.width() / 2 else 1
        textes = self.gauches if cote == 0 else self.droites
        return cote, min(range(len(textes)), key=lambda r: abs(self._puce(cote, r).y() - position.y()))

    def viser(self, cible):
        """Une puce cliquée (ou son texte) : la relie à celle qui attendait en face, ou attend à son tour."""
        if not self.isEnabled():
            return
        if self.origine is not None and self.origine[0] != cible[0]:
            self._relier(self.origine, cible)
            self.origine = None
        else:
            self.origine = None if self.origine == cible else cible
        self.update()

    def _relier(self, a, b):
        gauche, droite = (a, b) if a[0] == 0 else (b, a)
        self.liens[gauche[1]] = droite[1]

    def mousePressEvent(self, evenement):
        cible = self._visee(evenement.position())
        if self.origine is not None and self.origine[0] != cible[0]:
            self.viser(cible)
            return
        self.origine, self.souris = cible, evenement.position()
        self.update()

    def mouseMoveEvent(self, evenement):
        if self.origine is not None and self.souris is not None:
            self.souris = evenement.position()
            self.update()

    def mouseReleaseEvent(self, evenement):
        if self.origine is None or self.souris is None:
            return
        cible = self._visee(evenement.position())
        depart = self._puce(*self.origine)
        if cible[0] != self.origine[0]:
            self._relier(self.origine, cible)
            self.origine = None
        elif (evenement.position() - depart).manhattanLength() > 2 * RAYON_PUCE:  # lâché ailleurs que sur une puce d'en face
            if self.origine[0] == 0:
                self.liens[self.origine[1]] = None
            self.origine = None
        # sinon, un simple clic : la puce attend celle d'en face
        self.souris = None
        self.update()

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        trait = self.palette().highlight().color()
        tire = self.origine if self.souris is not None else None  # le lien d'une puce qu'on retire suit la souris
        peintre.setPen(QPen(trait, 2))
        for g, d in enumerate(self.liens):
            if d is not None and tire != (0, g):
                peintre.drawLine(self._puce(0, g), self._puce(1, d))
        if tire is not None:
            peintre.setPen(QPen(trait, 2, Qt.PenStyle.DashLine))
            peintre.drawLine(self._puce(*tire), self.souris)
        relies = {(0, g) for g, d in enumerate(self.liens) if d is not None} | {(1, d) for d in self.liens if d is not None}
        for cote, textes in enumerate((self.gauches, self.droites)):
            for rang in range(len(textes)):
                puce = (cote, rang)
                peintre.setPen(QPen(trait if puce == self.origine else self.palette().text().color(), 2 if puce == self.origine else 1))
                peintre.setBrush(trait if puce in relies or puce == self.origine else self.palette().base().color())
                peintre.drawEllipse(self._puce(cote, rang), RAYON_PUCE, RAYON_PUCE)


class SurimpressionAppariement(Surimpression):
    """La correction à la main d'un appariement (04/10/2026), dans la gouttière : un lien juste repassé en vert ; un lien
    faux raturé d'un zigzag rouge en travers, au quart de sa longueur, et le bon lien tracé en vert, comme celui que l'élève a oublié.
    Écarté : écrire en face de chaque élément le texte de sa bonne réponse, qui recopie la colonne de droite et laisse
    à l'élève la ligne à retrouver, alors que le trait vert la montre d'un coup d'œil."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        toile = q.toile
        coin = self.cadre(toile).topLeft()
        for g, d in enumerate(toile.liens):
            attendu = q.ordre.index(g)  # la place affichée de sa bonne réponse
            depart = coin + toile._puce(0, g)
            if d is not None and d != attendu:
                self.barrer(peintre, depart, coin + toile._puce(1, d))
            self.stylo(peintre, self.VERT)
            peintre.drawLine(depart, coin + toile._puce(1, attendu))


class LargeurCommune(QObject):
    """Des textes d'une même colonne, larges au plus de la plus longue d'entre eux, sans retour à la ligne. Recalculé
    quand la police change, comme ``Hauteur`` : mesurée à la construction, dans la police par défaut, la largeur
    coupait la fin du texte une fois la police du sujet posée (« OSPF » affiché « OSP », 04/10/2026)."""

    def __init__(self, textes):
        super().__init__(textes[0])
        self.textes = textes
        for texte in textes:
            texte.installEventFilter(self)
        self.poser()

    def poser(self):
        largeur = max(math.ceil(largeur_naturelle(t.document())) + 2 for t in self.textes)
        for texte in self.textes:
            texte.setMaximumWidth(largeur)

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.FontChange:
            self.poser()
        return False


class Appariement(Annotee, noyau.Appariement, Question):

    def _corps(self, d):
        """Deux colonnes de textes et, entre elles, la gouttière où l'élève relie les puces, comme sur la copie papier."""
        droites = [p.droite for p in self.paires] + self.distracteurs
        self.ordre = melange(range(len(droites)), self.graine)  # position affichée -> indice dans droites
        gauches = [Texte(p.gauche, inline=True) for p in self.paires]
        for texte in gauches:  # alignés sur leurs puces, comme sur papier
            texte.document().setDefaultTextOption(QTextOption(Qt.AlignmentFlag.AlignRight))
        LargeurCommune(gauches)  # la colonne n'est pas plus large que sa plus longue proposition
        droites = [Texte(droites[i], inline=True) for i in self.ordre]
        self.toile = Liens(gauches, droites)
        grille = QGridLayout()
        grille.setVerticalSpacing(10)
        for cote, textes in enumerate((gauches, droites)):
            for rang, texte in enumerate(textes):
                texte.clic.connect(functools.partial(lambda puce, *_: self.toile.viser(puce), (cote, rang)))
                grille.addWidget(texte, rang, 2 * cote)
        grille.addWidget(self.toile, 0, 1, max(len(gauches), len(droites)), 1)
        grille.setColumnStretch(2, 1)  # la place qui reste va à droite : la plus longue de gauche touche la marge, comme sur papier (28/09/2026)
        d.addWidget(Texte(dire("*Reliez chaque élément de gauche à un élément de droite : tirez un trait d'une puce à l'autre, "
                          "ou cliquez l'une puis l'autre. Pour défaire un lien, tirez-le depuis sa puce de gauche et lâchez-le "
                          "dans le vide.*"), inline=True))
        d.addLayout(grille)
        self.entrees.append(self.toile)
        self.surimpression = SurimpressionAppariement(self)

    def _attendu(self):
        return ""  # les bons liens tracés en vert dans la gouttière (``SurimpressionAppariement``)

    def _lire(self):
        choix = [None if p is None else self.ordre[p] for p in self.toile.liens]
        return None if all(i is None for i in choix) else choix

    def _ecrire(self, valeur):
        self.toile.liens = [None if valeur is None or valeur[g] is None else self.ordre.index(valeur[g]) for g in range(len(self.paires))]
        self.toile.origine = self.toile.souris = None
        self.toile.update()


class SurimpressionPoint(Surimpression):
    """La correction à la main d'un point à placer (04/10/2026) : chaque zone attendue contournée en vert sur l'image,
    et la croix de l'élève entourée de vert si elle tombe dans l'une, barrée de rouge sinon. Écarté : poser une croix
    verte au centre de la bonne zone, qui laisse croire que seul ce point-là était juste."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        coin, echelle = q._image()
        coin += self.cadre(q.vue.viewport()).topLeft()
        self.stylo(peintre, self.VERT)
        for z in q.zones:
            if isinstance(z, noyau.Cercle):
                peintre.drawEllipse(coin + QPointF(z.x, z.y) * echelle, z.rayon * echelle, z.rayon * echelle)
            else:
                peintre.drawRoundedRect(QRectF(coin + QPointF(z.x, z.y) * echelle, QSizeF(z.largeur, z.hauteur) * echelle), 6, 6)
        if q.point is not None:
            croix = coin + QPointF(*q.point) * echelle
            if q.corriger(q.point)[0]:
                self.entourer(peintre, QRectF(croix - QPointF(7, 7), QSizeF(14, 14)))
            else:
                self.stylo(peintre, self.ROUGE)
                peintre.drawLine(croix + QPointF(-10, 9), croix + QPointF(10, -9))


class PointSelection(Annotee, noyau.PointSelection, Question):

    def _attendu(self):
        return ""  # les zones attendues contournées en vert sur l'image (``SurimpressionPoint``)

    def _corps(self, d):
        self.surimpression = SurimpressionPoint(self)
        self.point = None
        self.vue = Texte(f"![]({self.image})")
        self.vue.clic.connect(self._cliquer)
        self.croix = QLabel("✚", self.vue.viewport())
        self.croix.setStyleSheet("color: red; font-weight: bold; background: transparent;")
        self.croix.hide()
        self.vue.document().documentLayout().documentSizeChanged.connect(self._placer_croix)
        d.addWidget(Texte(dire("*Cliquez sur l'image.*"), inline=True))
        d.addWidget(self.vue)
        self.entrees.append(self.vue)

    def _image(self):
        """Le coin de l'image dans la vue et son échelle (unités affichées par pixel de l'image), mesurés là où le
        document la dessine, comme ``Figure._placer`` : ``ObjetSvg`` la met à la taille du texte (×1,2 à l'écran) et la
        réduit avec la largeur. L'ancien calcul (pixels bruts, coin en 0, 0) plaçait la croix à côté du clic (04/10/2026)."""
        document = self.vue.document()
        objet = next((f for f in fragments(document) if f.charFormat().objectType() == OBJET_SVG), None)
        if objet is None:  # média absent
            return QPointF(0, 0), 1
        curseur = QTextCursor(document)
        curseur.setPosition(objet.position())
        largeur = self.vue.svg.intrinsicSize(document, objet.position(), objet.charFormat()).width()
        return QPointF(self.vue.cursorRect(curseur).topLeft()), largeur / (QImage.fromData(MEDIAS[self.image]).width() or 1)

    def _cliquer(self, x, y):
        if self.vue.isEnabled():
            coin, echelle = self._image()
            self._ecrire([round((x - coin.x()) / echelle), round((y - coin.y()) / echelle)])

    def _lire(self):
        return self.point

    def _ecrire(self, valeur):
        self.point = valeur
        self._placer_croix()

    def _placer_croix(self, *_):
        """La croix sur son point, replacée quand l'image change de taille avec la largeur du texte."""
        self.croix.setVisible(self.point is not None)
        if self.point is not None:
            coin, echelle = self._image()
            centre = coin + QPointF(*self.point) * echelle
            self.croix.move(int(centre.x()) - 6, int(centre.y()) - 9)


RAYON = 22  # rayon d'un sommet du type ``dessin``, en pixels
ECART = 7   # décalage d'une arête orientée sur sa droite, pour que A→B et B→A ne se superposent pas
VISEE = 10  # distance à une arête en deçà de laquelle un clic la vise, en pixels
TOILE_MINIMUM = 240  # en deçà, une toile ne se réduit plus : ses sommets ne seraient plus visables au doigt
# mode « coloration » : le fond du sommet, et la pastille de son numéro de couleur (le numéro seul départage à l'impression)
PALETTE = [("#ffcdd2", "#c62828"), ("#c8e6c9", "#2e7d32"), ("#bbdefb", "#1565c0"), ("#fff9c4", "#f9a825"),
           ("#e1bee7", "#6a1b9a"), ("#ffe0b2", "#ef6c00"), ("#b2ebf2", "#00838f"), ("#d7ccc8", "#4e342e")]
TENU = 2 * (RAYON - 3)  # largeur de nom qu'un cercle peut contenir : au-delà, le nom s'écrit dessous


class ToileGraphe(QWidget):
    """La zone de dessin d'une question ``dessin`` : l'élève tire un trait d'un sommet à l'autre pour créer une
    arête, clique une arête puis Suppr pour l'effacer. Les sommets, eux, sont ceux du sujet et ne bougent pas."""

    question = property(lambda self: self._question())

    def __init__(self, question):
        super().__init__()
        self._question, self.aretes = weakref.ref(question), []  # voir ``Surimpression.question``
        self.chemin = []  # modes « chemin » et « sommets » : les sommets cliqués, dans l'ordre
        self.teintes = {}  # mode « coloration » : nom -> couleur
        self.sommets = question.disposes(RAYON + 4)  # ceux d'un arbre du décor sans place : disposés comme en mode arbre
        self.depart, self.souris, self.choisie = None, None, None
        self._fond = ...  # chargé au premier dessin : MEDIAS n'est rempli qu'après la construction des questions
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        metriques = self.fontMetrics()
        deborde = [s for s in self.sommets if metriques.horizontalAdvance(str(s.nom)) > TENU]
        cote = max([metriques.horizontalAdvance(str(s.nom)) / 2 + 3 for s in deborde] + [RAYON])
        largeur = max([s.x for s in self.sommets] or [0]) + RAYON + cote
        hauteur = max([s.y for s in self.sommets] or [0]) + 2 * RAYON + (metriques.height() if deborde else 0)
        # La taille naturelle, celle des coordonnées du sujet ; plus étroite (un téléphone), la toile se dessine à
        # l'échelle et la souris est ramenée dans ces coordonnées (``_echelle``) : la figure du bac NSI 2026, 504 px,
        # imposait un ascenseur horizontal à tout le sujet sous 540 px.
        self.naturelle = QSize(int(largeur), int(hauteur))
        largeur_mini = min(self.naturelle.width(), TOILE_MINIMUM)
        self.setMinimumSize(largeur_mini, self.heightForWidth(largeur_mini))
        politique = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        politique.setHeightForWidth(True)
        self.setSizePolicy(politique)

    def sizeHint(self):
        return self.naturelle

    def heightForWidth(self, largeur):
        return math.ceil(self.naturelle.height() * min(1, largeur / self.naturelle.width()))

    def _echelle(self):
        return min(1, self.width() / self.naturelle.width())

    def fond(self):
        if self._fond is ...:
            self._fond = QImage.fromData(MEDIAS[self.question.image]) if self.question.image in MEDIAS else None
        return self._fond

    # -- géométrie

    def _sommet(self, nom):
        return next((s for s in self.sommets if s.nom == nom), None)

    def _sous(self, position):
        """Le nom du sommet sous ce point, s'il y en a un."""
        return next((s.nom for s in self.sommets
                     if (s.x - position.x()) ** 2 + (s.y - position.y()) ** 2 <= RAYON ** 2), None)

    def _trait(self, arete):
        """Les deux bouts du trait dessiné, de bord à bord, décalés sur la droite si le graphe est orienté."""
        depart, arrivee = self._sommet(arete[0]), self._sommet(arete[1])
        dx, dy = arrivee.x - depart.x, arrivee.y - depart.y
        longueur = math.hypot(dx, dy) or 1
        ux, uy = dx / longueur, dy / longueur
        ecart = ECART if self.question.oriente else 0
        return (QPointF(depart.x + ux * RAYON - uy * ecart, depart.y + uy * RAYON + ux * ecart),
                QPointF(arrivee.x - ux * RAYON - uy * ecart, arrivee.y - uy * RAYON + ux * ecart))

    def _milieu(self, arete):
        a, b = self._trait(arete)
        return QPointF((a.x() + b.x()) / 2, (a.y() + b.y()) / 2)

    def _distance(self, arete, position):
        """La distance de ce point au trait de l'arête, sur toute sa longueur."""
        a, b = self._trait(arete)
        dx, dy = b.x() - a.x(), b.y() - a.y()
        t = ((position.x() - a.x()) * dx + (position.y() - a.y()) * dy) / (dx * dx + dy * dy or 1)
        t = min(1, max(0, t))  # le point du trait le plus proche, sans dépasser ses bouts
        return math.hypot(a.x() + t * dx - position.x(), a.y() + t * dy - position.y())

    def _visee(self, position):
        """L'arête la plus proche de ce point, s'il en est à portée : n'importe où le long du trait, pas seulement
        en son milieu (viser le milieu à 14 px près était trop dur, demande de l'utilisateur, 24/09/2026)."""
        proches = [(self._distance(arete, position), i) for i, arete in enumerate(self.aretes)]
        distance, i = min(proches, default=(None, None))
        return i if distance is not None and distance <= VISEE else None

    # -- dessin

    def paintEvent(self, _):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.scale(self._echelle(), self._echelle())
        if self.fond() is not None:
            peintre.drawImage(0, 0, self.fond())
        for donnee in self.question.decor:  # sous le tracé de l'élève, qui surligne donc ce qu'il choisit
            self._peindre_arete(peintre, (donnee.source, donnee.cible, donnee.etiquette), QColor("#b0bec5"))
        bleu = QColor("#1e88e5")
        peintre.setPen(QPen(bleu, 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        # le chemin de l'élève, de centre à centre, sous les sommets ; un parcours n'a que ses numéros : deux sommets
        # visités de suite n'y sont pas forcément voisins, et le trait barrerait la figure là où il n'y a pas d'arête
        relie = self.question.mode == "chemin" and self.question.parcours is None  # en mode sommets, aucun ordre
        for a, b in zip(self.chemin, self.chemin[1:]) if relie else ():
            a, b = self._sommet(a), self._sommet(b)
            peintre.drawLine(QPointF(a.x, a.y), QPointF(b.x, b.y))
        for i, arete in enumerate(self.aretes):
            if i == self.choisie:  # l'arête choisie, que Suppr effacera : en bleu, et un halo pour qu'on la voie de loin
                peintre.setPen(QPen(QColor(30, 136, 229, 70), 10, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                peintre.drawLine(*self._trait(arete))
            self._peindre_arete(peintre, arete, QColor("#1e88e5") if i == self.choisie else QColor("#37474f"))
        if self.depart is not None and self.souris is not None:
            peintre.setPen(QPen(QColor("#9e9e9e"), 2, Qt.PenStyle.DashLine))
            sommet = self._sommet(self.depart)
            peintre.drawLine(QPointF(sommet.x, sommet.y), self.souris)
        for sommet in self.sommets:
            self._peindre_sommet(peintre, sommet, str(sommet.nom) in self.chemin and self.question.mode == "sommets",
                                 self.teintes.get(str(sommet.nom)))
        for sommet in self.sommets if self.question.mode == "chemin" else ():  # chaque passage, en pastille bleue
            rangs = [str(i + 1) for i, nom in enumerate(self.chemin) if nom == str(sommet.nom)]
            if rangs:
                texte = ",".join(rangs)
                largeur = max(18, peintre.fontMetrics().horizontalAdvance(texte) + 8)
                cadre = QRectF(sommet.x + RAYON * 0.7 - largeur / 2, sommet.y - RAYON * 0.7 - 9, largeur, 18)
                peintre.setPen(Qt.PenStyle.NoPen)
                peintre.setBrush(bleu)
                peintre.drawRoundedRect(cadre, 9, 9)
                peintre.setPen(QColor("#ffffff"))
                peintre.drawText(cadre, int(Qt.AlignmentFlag.AlignCenter), texte)
        for sommet in self.sommets:  # mode coloration : le numéro de la couleur, en pastille, comme sous les sommets du bac
            couleur = self.teintes.get(str(sommet.nom))
            if couleur is not None:
                cadre = QRectF(sommet.x + RAYON * 0.7 - 9, sommet.y - RAYON * 0.7 - 9, 18, 18)
                peintre.setPen(Qt.PenStyle.NoPen)
                peintre.setBrush(QColor(PALETTE[couleur % len(PALETTE)][1]))
                peintre.drawEllipse(cadre)
                peintre.setPen(QColor("#ffffff"))
                peintre.drawText(cadre, int(Qt.AlignmentFlag.AlignCenter), str(couleur))

    def _peindre_sommet(self, peintre, sommet, choisi=False, couleur=None):
        """``choisi`` : un sommet désigné en mode « sommets », cerclé et teinté de bleu ; ``couleur`` : son numéro en mode
        « coloration », qui le remplit de la teinte de la palette."""
        peintre.setPen(QPen(QColor("#1e88e5") if choisi else QColor("#37474f"), 3 if choisi else 2))
        peintre.setBrush(QColor("#bbdefb") if choisi else QColor(PALETTE[couleur % len(PALETTE)][0]) if couleur is not None
                         else QColor("#ffffff"))
        centre = QPointF(sommet.x, sommet.y)
        peintre.drawEllipse(centre, RAYON, RAYON)
        if sommet.marque == "final":  # l'état acceptant d'un automate : le double cercle
            peintre.drawEllipse(centre, RAYON - 4, RAYON - 4)
        if sommet.marque == "initial":
            peintre.drawLine(QPointF(sommet.x - 2 * RAYON, sommet.y), QPointF(sommet.x - RAYON, sommet.y))
        nom = sommet.libelle()
        largeur = peintre.fontMetrics().horizontalAdvance(nom)
        if largeur <= TENU:
            cadre = QRect(int(sommet.x - RAYON), int(sommet.y - RAYON), 2 * RAYON, 2 * RAYON)
        else:  # un nom trop long pour son cercle s'écrit dessous : « Internet » y serait coupé net
            cadre = QRect(int(sommet.x - largeur / 2 - 3), int(sommet.y + RAYON),
                          int(largeur) + 6, peintre.fontMetrics().height())
            peintre.fillRect(cadre, QColor("#ffffff"))  # les arêtes qui partent du nœud passent dessous
        peintre.drawText(cadre, int(Qt.AlignmentFlag.AlignCenter), nom)

    def _peindre_arete(self, peintre, arete, couleur):
        peintre.setPen(QPen(couleur, 2))
        peintre.setBrush(couleur)
        a, b = self._trait(arete)
        peintre.drawLine(a, b)
        if self.question.oriente:
            angle = math.atan2(b.y() - a.y(), b.x() - a.x())
            pointe = [b] + [QPointF(b.x() - 12 * math.cos(angle + c), b.y() - 12 * math.sin(angle + c))
                            for c in (0.4, -0.4)]
            peintre.drawPolygon(QPolygonF(pointe))
        if arete[2] and not (self.sommets is not self.question.sommets and self.question.cotes() == ["g", "d"]):
            # (un arbre disposé : g et d se voient à la place du fils, comme au PDF)
            milieu = self._milieu(arete)
            peintre.setPen(QPen(couleur, 1))
            peintre.setBrush(QColor("#ffffff"))
            largeur = peintre.fontMetrics().horizontalAdvance(str(arete[2])) + 8
            peintre.drawRect(int(milieu.x() - largeur / 2), int(milieu.y() - 9), largeur, 18)
            peintre.drawText(int(milieu.x() - largeur / 2), int(milieu.y() - 9), largeur, 18,
                             int(Qt.AlignmentFlag.AlignCenter), str(arete[2]))

    # -- la souris

    def mousePressEvent(self, evenement):
        if not self.isEnabled():
            return
        position = evenement.position() / self._echelle()
        if self.question.mode == "chemin":  # un clic sur un sommet le met au bout du chemin
            nom = self._sous(position)
            if nom is not None and (not self.chemin or self.chemin[-1] != str(nom)):
                self.chemin.append(str(nom))
                self.update()
            return
        if self.question.mode == "coloration":  # chaque clic passe à la couleur suivante, après la dernière plus aucune
            nom = self._sous(position)
            if nom is not None:
                suivante = self.teintes.get(str(nom), -1) + 1
                if suivante < self.question.couleurs:
                    self.teintes[str(nom)] = suivante
                else:
                    self.teintes.pop(str(nom), None)
                self.update()
            return
        if self.question.mode == "sommets":  # un clic désigne un sommet, un second le retire
            nom = self._sous(position)
            if nom is not None:
                if str(nom) in self.chemin:
                    self.chemin.remove(str(nom))
                else:
                    self.chemin.append(str(nom))
                self.update()
            return
        self.depart, self.souris = self._sous(position), position
        self.choisie = None if self.depart is not None else self._visee(position)
        self.update()

    def mouseMoveEvent(self, evenement):
        self.souris = evenement.position() / self._echelle()
        if self.depart is not None:
            self.update()

    def mouseReleaseEvent(self, evenement):
        if not self.isEnabled() or self.depart is None:
            return
        depart, self.depart = self.depart, None
        arrivee = self._sous(evenement.position() / self._echelle())
        if arrivee is not None and arrivee != depart:  # jamais de boucle : un clic sur un sommet, sans glisser, en
            # posait une, dessinée en rond au-dessus du sommet (vu par l'utilisateur, 24/09/2026)
            if self.question.etiquettes:
                self._etiqueter(depart, arrivee, evenement.position().toPoint())
            else:
                self.ajouter([depart, arrivee, ""])
        self.update()

    def _etiqueter(self, depart, arrivee, position):
        """L'étiquette de l'arête qu'on vient de tracer : un menu des étiquettes du sujet, qui ajoute l'arête au choix
        (``popup``, pas ``exec`` : le navigateur n'a pas de boucle imbriquée) ; refermé sans choix, rien n'est tracé."""
        menu = QMenu(self)
        menu.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        for e in self.question.etiquettes:
            menu.addAction(str(e)).setData(str(e))
        self.tracee = depart, arrivee
        menu.triggered.connect(self._etiquette_choisie)
        menu.popup(self.mapToGlobal(position))

    def _etiquette_choisie(self, action):
        self.ajouter([*self.tracee, action.data()])

    def ajouter(self, arete):
        if self.question.cle(*arete) not in [self.question.cle(*a) for a in self.aretes]:
            self.aretes.append(list(arete))
            self.update()

    def keyPressEvent(self, evenement):
        if self.question.mode == "chemin" and self.chemin and evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.chemin.pop()
            self.update()
        elif self.choisie is not None and evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            del self.aretes[self.choisie]
            self.choisie = None
            self.update()
        else:
            super().keyPressEvent(evenement)


class ToileLabyrinthe(ToileGraphe):
    """La toile d'un ``dessin`` à ``grille`` : des cellules et leurs murs, comme au bac (2022 Métropole jour 2) ; un clic
    sur un mur intérieur l'ouvre (l'arête entre les deux cellules), un second le referme. Le mur visé est le plus proche
    à un quart de pas près, de part et d'autre : la bande d'un demi-pas, et non le trait de 3 px. Les murs extérieurs ne
    réagissent pas. Un passage se trace (``_trait``) d'un centre de cellule à l'autre, à travers le mur ouvert : c'est
    là que la surimpression et le corrigé imprimé le repassent en vert, sur le labyrinthe attendu."""

    PAS, MARGE = 50, 24  # le côté d'une cellule ; la place des numéros de ligne et de colonne

    def __init__(self, question):
        super().__init__(question)
        haut, long = question.grille
        self.sommets = [Sommet(f"{l},{c}", self.MARGE + self.PAS * (c + 0.5), self.MARGE + self.PAS * (l + 0.5))
                        for l in range(haut) for c in range(long)]
        self.naturelle = QSize(self.MARGE + self.PAS * long + 4, self.MARGE + self.PAS * haut + 4)
        largeur_mini = min(self.naturelle.width(), TOILE_MINIMUM)
        self.setMinimumSize(largeur_mini, self.heightForWidth(largeur_mini))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_AcceptTouchEvents)  # au doigt : ouvrir un mur, pas faire défiler

    def event(self, evenement):
        if evenement.type() in (QEvent.Type.TouchBegin, QEvent.Type.TouchUpdate, QEvent.Type.TouchEnd):
            if tactile.relayer_en_souris(self, evenement):
                return True
        return super().event(evenement)

    def _trait(self, arete):
        a, b = self._sommet(str(arete[0])), self._sommet(str(arete[1]))
        return QPointF(a.x, a.y), QPointF(b.x, b.y)

    def mur(self, position):
        """Les deux cellules du mur intérieur visé, ou ``None``."""
        haut, long = self.question.grille
        fx, fy = (position.x() - self.MARGE) / self.PAS, (position.y() - self.MARGE) / self.PAS
        l, c = math.floor(fy), math.floor(fx)
        candidats = []
        if 0 <= l < haut and 1 <= round(fx) < long:  # un mur vertical, entre deux colonnes
            candidats.append((abs(fx - round(fx)), (f"{l},{round(fx) - 1}", f"{l},{round(fx)}")))
        if 0 <= c < long and 1 <= round(fy) < haut:  # un mur horizontal, entre deux lignes
            candidats.append((abs(fy - round(fy)), (f"{round(fy) - 1},{c}", f"{round(fy)},{c}")))
        distance, mur = min(candidats, default=(1, None))
        return mur if distance <= 0.25 else None

    def paintEvent(self, _):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.scale(self._echelle(), self._echelle())
        haut, long = self.question.grille
        m, pas = self.MARGE, self.PAS
        peintre.fillRect(QRectF(m, m, pas * long, pas * haut), QColor("#ffffff"))
        peintre.setPen(QColor("#78909c"))  # les numéros de colonne et de ligne, ceux des coordonnées du sujet
        for c in range(long):
            peintre.drawText(QRectF(m + pas * c, 0, pas, m), int(Qt.AlignmentFlag.AlignCenter), str(c))
        for l in range(haut):
            peintre.drawText(QRectF(0, m + pas * l, m, pas), int(Qt.AlignmentFlag.AlignCenter), str(l))
        peintre.setPen(QPen(QColor("#37474f"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        for bouts in self.question.murs(self.aretes):
            peintre.drawLine(*(QPointF(m + pas * x, m + pas * y) for x, y in bouts))
        peintre.drawRect(QRectF(m, m, pas * long, pas * haut))

    def mousePressEvent(self, evenement):
        if not self.isEnabled():
            return
        mur = self.mur(evenement.position() / self._echelle())
        if mur is not None:
            cles = [self.question.cle(*a) for a in self.aretes]
            cle = self.question.cle(*mur, "")
            if cle in cles:
                del self.aretes[cles.index(cle)]
            else:
                self.aretes.append([*mur, ""])
            self.update()

    def mouseMoveEvent(self, evenement):
        pass

    def mouseReleaseEvent(self, evenement):
        pass

    def keyPressEvent(self, evenement):
        QWidget.keyPressEvent(self, evenement)


PLACE = 13  # rayon d'un emplacement libre sous un nœud, en mode « arbre »


class ToileArbre(ToileGraphe):
    """La toile d'un ``dessin`` en mode « arbre » : les valeurs à placer attendent en haut ; l'élève en tire une (ou la
    clique, puis clique la place) jusqu'à un emplacement libre, en pointillé sous chaque nœud — fils gauche ou droit,
    ou « + » d'un arbre n-aire, dont il choisit alors l'étiquette. L'arbre se dispose seul (``noyau.Dessin.agencement``) :
    l'élève construit la forme, il ne relie pas des ronds déjà placés qui la donneraient. Un nœud posé se tire vers une
    autre place avec ses descendants ; cliqué puis Suppr, il retourne en haut avec eux."""

    def __init__(self, question):
        self.tenue = None  # la valeur cliquée en haut, qu'un clic sur une place posera
        super().__init__(question)
        self._disposer()

    def _disposer(self):
        """Positions des valeurs à placer (une rangée en haut), des nœuds posés et des places libres, et la taille."""
        q = self.question
        haut = 2 * RAYON + 30 + (self.fontMetrics().height() if any(  # la place d'un nom écrit sous son cercle
            self.fontMetrics().horizontalAdvance(s.libelle()) > TENU for s in q.sommets) else 0)
        triples = [[a.source, a.cible, a.etiquette] for a in q.decor] + self.aretes
        positions, places = q.agencement(triples)
        if not positions:  # rien de posé : la place de la racine
            places = [("", "", RAYON, 0)]
        gauche = RAYON + 6 - min([x for x, _ in positions.values()] + [p[2] for p in places])
        self.positions = {n: (x + gauche, y + haut + RAYON) for n, (x, y) in positions.items()}
        self.places = [(p, c, x + gauche, y + haut + RAYON) for p, c, x, y in places]
        piles = {}  # les valeurs de même texte (les « + » d'un arbre de décision) : une seule en haut, avec leur nombre
        for s in q.sommets:
            if str(s.nom) not in self.positions:
                piles.setdefault(s.libelle(), []).append(str(s.nom))
        self.piles = {noms[0]: len(noms) for noms in piles.values() if len(noms) > 1}
        larges = [self.fontMetrics().horizontalAdvance(v) for v in piles]  # un nom plus large que son cercle s'écrit dessous
        pastille = 22 if self.piles else 0  # « ×n », à droite du cercle
        pas = max([2 * RAYON + 8] + [w + 12 for w in larges]) + pastille
        self.reserve = {noms[0]: (RAYON + 6 + i * pas, RAYON + 4) for i, noms in enumerate(piles.values())}
        xs = [x for x, _ in self.positions.values()] + [x + pastille for x, _ in self.reserve.values()] + [
            p[2] for p in self.places]
        ys = [y for _, y in self.positions.values()] + [p[3] for p in self.places]
        self.naturelle = QSize(int(max(xs + [0]) + RAYON + 6), int(max(ys + [haut]) + RAYON + 6))
        largeur_mini = min(self.naturelle.width(), TOILE_MINIMUM)
        self.setMinimumSize(largeur_mini, self.heightForWidth(largeur_mini))
        self.updateGeometry()

    def update(self):
        self._disposer()
        super().update()

    def _sommet(self, nom):
        nom = str(nom)
        x, y = self.positions.get(nom) or self.reserve.get(nom) or (0, 0)
        return Sommet(nom, x, y, texte=self.question.libelles().get(nom, ""))

    def _sous(self, position):
        """Ce qu'il y a sous ce point : ("r", valeur) en haut, ("n", nœud) posé, ("p", parent, côté) une place libre."""
        for genre, rayon, lieux in (("r", RAYON, self.reserve), ("n", RAYON, self.positions)):
            for nom, (x, y) in lieux.items():
                if (x - position.x()) ** 2 + (y - position.y()) ** 2 <= rayon ** 2:
                    return genre, nom
        for parent, cote, x, y in self.places:
            if (x - position.x()) ** 2 + (y - position.y()) ** 2 <= (RAYON if parent == "" else PLACE + 4) ** 2:
                return "p", parent, cote
        return None

    def _descendants(self, nom):
        noms = [nom]
        for n in noms:
            noms += [e for p, e, _ in self.aretes if p == n]
        return noms

    def poser(self, nom, parent, cote):
        """Pose ``nom`` (avec ses descendants s'il était déjà posé) à la place libre (parent, côté)."""
        if parent in self._descendants(nom):  # sous lui-même : l'arbre se refermerait en boucle
            return
        if cote == "+":  # n-aire : l'étiquette de la branche, parmi celles que ce nœud n'a pas encore
            prises = [c for p, _, c in self.aretes if p == parent] + [a.etiquette for a in self.question.decor if str(a.source) == parent]
            menu = QMenu(self)
            menu.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            for e in self.question.cotes():
                if e not in prises:
                    menu.addAction(e).setData(e)
            menu.triggered.connect(lambda action: self.poser(nom, parent, action.data()))
            x, y = self.positions[parent]
            menu.popup(self.mapToGlobal(QPoint(int(x * self._echelle()), int((y + RAYON) * self._echelle()))))
            return
        self.aretes = [a for a in self.aretes if a[1] != nom] + [[parent, nom, cote]]
        self.tenue = self.choisie = None
        self.update()

    def paintEvent(self, _):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.scale(self._echelle(), self._echelle())
        binaire = self.question.cotes() == ["g", "d"]
        pointille = QPen(QColor("#90a4ae"), 1.5, Qt.PenStyle.DashLine)
        for parent, cote, x, y in self.places:
            peintre.setPen(pointille)
            peintre.setBrush(Qt.BrushStyle.NoBrush)
            if parent != "":
                px, py = self.positions[parent]
                peintre.drawLine(QPointF(px, py + RAYON), QPointF(x, y - PLACE))
            rayon = RAYON if parent == "" else PLACE
            peintre.drawEllipse(QPointF(x, y), rayon, rayon)
            if not binaire:
                peintre.drawText(QRectF(x - rayon, y - rayon, 2 * rayon, 2 * rayon), int(Qt.AlignmentFlag.AlignCenter), "+")
        for a in self.question.decor:
            self._peindre_arete(peintre, (a.source, a.cible, "" if binaire else a.etiquette), QColor("#b0bec5"))
        for a in self.aretes:
            if a[0] != "":  # ["", racine, ""] : la racine, sans trait
                self._peindre_arete(peintre, (a[0], a[1], "" if binaire else a[2]), QColor("#37474f"))
        for nom in [*self.positions, *self.reserve]:
            self._peindre_sommet(peintre, self._sommet(nom))
            if nom in (self.tenue, self.choisie):  # tenue ou choisie : en bleu, avec un halo
                peintre.setPen(QPen(QColor(30, 136, 229, 90), 6))
                peintre.setBrush(Qt.BrushStyle.NoBrush)
                peintre.drawEllipse(QPointF(*(self.positions.get(nom) or self.reserve[nom])), RAYON + 3, RAYON + 3)
            if nom in self.piles:  # le nombre de valeurs identiques qui attendent, en pastille
                x, y = self.reserve[nom]
                peintre.setPen(QColor("#37474f"))
                peintre.drawText(QRectF(x + RAYON + 2, y - 8, 24, 16), int(Qt.AlignmentFlag.AlignVCenter),
                                 f"×{self.piles[nom]}")
        if self.depart is not None and self.souris is not None:
            peintre.setPen(QPen(QColor("#9e9e9e"), 2, Qt.PenStyle.DashLine))
            peintre.drawLine(QPointF(*(self.positions.get(self.depart[1]) or self.reserve[self.depart[1]])), self.souris)

    def mousePressEvent(self, evenement):
        if not self.isEnabled():
            return
        self.souris = evenement.position() / self._echelle()
        sous = self._sous(self.souris)
        if sous and sous[0] == "p" and self.tenue is not None:
            self.poser(self.tenue, *sous[1:])
            return
        self.depart = sous if sous and sous[0] in "rn" and (sous[0] == "r" or any(a[1] == sous[1] for a in self.aretes)) else None
        self.choisie = sous[1] if sous and sous[0] == "n" and self.depart else None
        self.update()

    def mouseReleaseEvent(self, evenement):
        if not self.isEnabled() or self.depart is None:
            return
        depart, self.depart = self.depart, None
        sous = self._sous(evenement.position() / self._echelle())
        if sous and sous[0] == "p":
            self.poser(depart[1], *sous[1:])
        elif sous == depart and depart[0] == "r":  # un clic sans glisser : la valeur est tenue, un clic sur une place la pose
            self.tenue = None if self.tenue == depart[1] else depart[1]
        self.update()

    def keyPressEvent(self, evenement):
        if self.choisie is not None and evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            partis = self._descendants(self.choisie)
            self.aretes = [a for a in self.aretes if a[1] not in partis]
            self.choisie = None
            self.update()
        else:
            QWidget.keyPressEvent(self, evenement)


class SurimpressionDessin(Surimpression):
    """La correction à la main d'un dessin (04/10/2026), sur la toile. Arêtes : une juste repassée en vert, une fausse
    raturée d'un zigzag rouge en travers, une manquante tracée en vert pointillé (le pointillé dit « à tracer », pas « tracé par toi »).
    Sommets : chaque attendu entouré de vert, un désigné à tort barré. Chemin : un sommet au bon rang entouré, au mauvais
    barré avec le bon rang écrit à côté. Coloration : un sommet coloré sans conflit entouré, une arête entre deux mêmes
    couleurs barrée, un sommet sans couleur barré. Partition : un sommet d'un groupe juste entouré, les autres barrés,
    chaque groupe attendu non formé encadré de vert. Arbre : un nœud à sa place entouré, ailleurs barré avec le texte
    attendu à cette place. Rien pour un réseau ni un arbre de Huffman : plusieurs réponses justes, le message suffit.
    Écarté : dessiner le graphe attendu à côté, qui oblige à comparer deux figures, là où les traits sont sur celle de
    l'élève."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        toile = q.toile
        coin, echelle = self.cadre(toile).topLeft(), toile._echelle()
        r, taille = RAYON * echelle, QFontInfo(toile.font()).pixelSize()

        def centre(nom):
            s = toile._sommet(nom)
            return coin + QPointF(s.x, s.y) * echelle

        def entourer(nom):
            self.entourer(peintre, QRectF(centre(nom) - QPointF(r, r), QSizeF(2 * r, 2 * r)), marge=(4, 4))

        def barrer(nom, ecrit=""):  # en travers du cercle, et ce qui était attendu écrit en vert dessous, à droite
            c = centre(nom)
            self.stylo(peintre, self.ROUGE)
            peintre.drawLine(c + QPointF(-r, r * 0.8), c + QPointF(r, -r * 0.8))
            if ecrit:
                self.ecrire(peintre, c + QPointF(r * 0.8, r + taille), ecrit, taille, self.VERT)

        def trait(arete):
            a, b = toile._trait(arete)
            return coin + a * echelle, coin + b * echelle

        if q.mode == "sommets":
            choisis, attendus = set(toile.chemin), {str(n) for n in q.juste()}
            for nom in attendus:
                entourer(nom)
            for nom in choisis - attendus:
                barrer(nom)
        elif q.mode == "chemin":
            saisie = list(toile.chemin)
            attendu = saisie if q.corriger(saisie)[0] == 1 else [str(n) for n in q.juste()]  # un des chemins acceptés
            for s in toile.sommets:
                mis, dus = ([str(i + 1) for i, n in enumerate(c) if n == str(s.nom)] for c in (saisie, attendu))
                if mis != dus:
                    barrer(s.nom, ",".join(dus))
                elif mis:
                    entourer(s.nom)
        elif q.mode == "coloration":
            teintes, conflits = toile.teintes, set()
            if q.propriete == "partition":  # un sommet entouré si son groupe est l'un des attendus, barré sinon ; chaque
                # groupe attendu non formé encadré en vert, le geste demandé au bac
                attendus, faits = {frozenset(map(str, g)) for g in q.groupes}, q._groupes_saisis(teintes)
                for s in toile.sommets:
                    nom = str(s.nom)
                    if any(nom in g for g in faits & attendus):
                        entourer(nom)
                    elif nom in teintes or any(nom in g for g in attendus):
                        barrer(nom)
                for g in attendus - faits:
                    points = [centre(n) for n in g]
                    xs, ys = [c.x() for c in points], [c.y() for c in points]
                    self.entourer(peintre, QRectF(min(xs) - r, min(ys) - r, max(xs) - min(xs) + 2 * r, max(ys) - min(ys) + 2 * r))
                return
            for a in q.decor:
                if str(a.source) in teintes and teintes.get(str(a.source)) == teintes.get(str(a.cible)):
                    self.barrer(peintre, *trait((a.source, a.cible, "")))
                    conflits |= {str(a.source), str(a.cible)}
            for s in toile.sommets:
                if str(s.nom) not in teintes:
                    barrer(s.nom)
                elif str(s.nom) not in conflits:
                    entourer(s.nom)
        elif q.mode == "arbre":
            if not q.propriete:  # Huffman : plusieurs arbres justes
                donne = [[a.source, a.cible, a.etiquette] for a in q.decor]
                attendus, textes, parents = q.formes(donne + q._attendues()), q.libelles(), {}
                for p, e, c in donne + toile.aretes:
                    parents[str(e)] = (str(p), str(c))

                def place(nom):  # les côtés de la racine jusqu'au nœud, comme ``formes``
                    p, c = parents.get(nom, ("", ""))
                    return () if p == "" else (*place(p), c)
                for _, nom, _ in toile.aretes:
                    ici = place(str(nom))
                    if attendus.get(ici) == textes.get(str(nom), str(nom)):
                        entourer(nom)
                    else:
                        barrer(nom, attendus.get(ici, ""))
        elif q.propriete != "reseau":  # un réseau : plusieurs câblages justes
            restantes = {}
            for a in q._attendues():
                restantes.setdefault(q.cle(*a), []).append(a)
            for a in toile.aretes:
                if restantes.get(q.cle(*a)):
                    restantes[q.cle(*a)].pop()
                    self.stylo(peintre, self.VERT)
                    peintre.drawLine(*trait(a))
                else:
                    self.barrer(peintre, *trait(a))
            peintre.setPen(QPen(self.VERT, 2.5, Qt.PenStyle.DashLine, Qt.PenCapStyle.RoundCap))
            for a in (a for reste in restantes.values() for a in reste):
                depart, arrivee = trait(a)
                peintre.drawLine(depart, arrivee)
                if q.oriente:
                    angle = math.atan2(arrivee.y() - depart.y(), arrivee.x() - depart.x())
                    for cote in (0.4, -0.4):
                        peintre.drawLine(arrivee, arrivee - QPointF(math.cos(angle + cote), math.sin(angle + cote)) * 12)
                if a[2]:
                    self.ecrire(peintre, (depart + arrivee) / 2 + QPointF(6, -6), str(a[2]), taille, self.VERT)


class Dessin(Annotee, noyau.Dessin, Question):

    def _attendu(self):
        """Tracé sur la toile (``SurimpressionDessin``), sauf l'arbre attendu, gardé en texte : ses places manquantes
        n'existent pas sur l'arbre de l'élève, et un réseau, qui en a plusieurs justes."""
        return super()._attendu() if self.mode == "arbre" or self.propriete == "reseau" else ""

    def _corps(self, d):
        self.surimpression = SurimpressionDessin(self)
        labyrinthe = self.grille and not self._problemes_grille([s.nom for s in self.sommets])  # une grille fausse : le graphe brut
        self.toile = ToileArbre(self) if self.mode == "arbre" else ToileLabyrinthe(self) if labyrinthe else ToileGraphe(self)
        d.addWidget(Texte(dire("*Cliquez les sommets dans l'ordre ; Suppr retire le dernier.*" if self.mode == "chemin" else
                          "*Cliquez chaque sommet de la réponse ; un second clic le retire.*" if self.mode == "sommets" else
                          "*Cliquez chaque équipement pour le ranger dans un groupe : une même couleur, un même groupe ; chaque "
                          "clic passe à la couleur suivante, après la dernière l'équipement n'a plus de groupe.*"
                          if self.propriete == "partition" else
                          f"*Cliquez un sommet pour lui donner une couleur (0 à {self.couleurs - 1}) ; chaque clic passe à "
                          "la suivante, après la dernière le sommet n'en a plus.*" if self.mode == "coloration" else
                          "*Tirez chaque valeur jusqu'à sa place, en pointillé sous un nœud (ou cliquez-la, puis la "
                          "place) ; cliquez un nœud posé, puis Suppr pour le retirer avec ses descendants.*"
                          if self.mode == "arbre" else
                          "*Cliquez un mur pour l'ouvrir ; un second clic le referme.*" if self.grille else
                          "*Tirez un trait d'un sommet à l'autre pour tracer une arête ; cliquez une arête, puis "
                          "Suppr pour l'effacer.*"), inline=True))
        d.addWidget(self.toile)
        self.entrees.append(self.toile)

    def _lire(self):
        if self.mode == "coloration":
            return dict(self.toile.teintes) or None
        if self.mode in ("chemin", "sommets"):
            return list(self.toile.chemin) or None
        return [list(a) for a in self.toile.aretes] or None

    def _ecrire(self, valeur):
        if self.mode == "coloration":
            self.toile.teintes = {str(n): c for n, c in (valeur or {}).items()}
            self.toile.update()
            return
        if self.mode in ("chemin", "sommets"):
            self.toile.chemin = [str(n) for n in (valeur or [])]
            self.toile.update()
            return
        self.toile.aretes = [list(a) for a in (valeur or [])]
        self.toile.choisie = None
        self.toile.update()


class SurimpressionCode(Surimpression):
    """La correction à la main d'un programme ou d'une requête, jugés sur leur exécution (l'utilisateur, 04/10/2026 :
    « même s'il y a plusieurs bonnes réponses possibles, tu peux barrer les fausses ») : entouré de vert quand tous les
    tests passent, barré d'un trait rouge sinon, en travers du texte écrit. La solution reste dessous, en bloc de code :
    plusieurs lignes de programme ne s'écrivent pas lisiblement à la main, et elle doit rester copiable. ``verdict`` :
    la fraction posée par ``_annoter`` (la correction lance un sous-processus : jamais dans ``paintEvent``).
    Une réponse en partie juste (l'utilisateur, 04/10/2026 : « il faut barrer que la partie fausse pour les réponses à
    moitié juste ») : seules ses ``fautes`` sont raturées, ligne par ligne - une clause ou une condition d'une requête,
    une fonction d'un programme (``noyau.Code.fautes``) -, et une partie MANQUANTE est marquée d'un signe d'insertion
    rouge là où elle aurait dû s'écrire."""

    verdict, fautes = None, ()

    def paintEvent(self, evenement):
        q = self.question
        editeur = q.editeur
        if self.verdict is None or q.saisie is None or not editeur.isVisible():
            return
        vue, decalage = self.cadre(editeur.viewport()), editeur.contentOffset()
        zone, lignes, bloc, places = QRectF(), 0, editeur.document().firstBlock(), []
        while bloc.isValid():
            haut = editeur.blockBoundingGeometry(bloc).translated(decalage).topLeft() + vue.topLeft()
            for n in range(bloc.layout().lineCount()):
                ligne = bloc.layout().lineAt(n)
                places.append((bloc.position() + ligne.textStart(), bloc.text()[ligne.textStart():][:ligne.textLength()], ligne, haut))
                if bloc.text().strip():
                    zone, lignes = zone.united(ligne.naturalTextRect().translated(haut)), lignes + 1
            bloc = bloc.next()
        zone = zone.intersected(vue)  # un programme plus long que l'éditeur y défile
        if zone.isEmpty():
            return
        peintre = self.peintre()
        if self.fautes:
            peintre.setClipRect(vue)  # une faute hors de la partie visible du programme
            for a, b in self.fautes:
                for debut, texte, ligne, haut in places:
                    x = lambda p: haut.x() + ligne.cursorToX(p - debut)[0]  # noqa: E731, B023
                    y = haut.y() + ligne.y() + ligne.height() / 2
                    if a == b and debut <= a <= debut + len(texte):  # partie manquante : un « ^ » sous la ligne
                        self.stylo(peintre, self.ROUGE)
                        bas = haut.y() + ligne.y() + ligne.height()
                        peintre.drawPolyline([QPointF(x(a) - 4, bas + 3), QPointF(x(a), bas - 3), QPointF(x(a) + 4, bas + 3)])
                        break
                    g, d = max(a, debut), min(b, debut + len(texte))
                    while g < d and texte[g - debut].isspace():  # les blancs de bord ne se raturent pas
                        g += 1
                    while d > g and texte[d - 1 - debut].isspace():
                        d -= 1
                    if g < d:
                        self.raturer(peintre, x(g), x(d), y)
        elif self.verdict == 1 and lignes == 1:
            self.entourer(peintre, zone, marge=(8, 4))
        elif self.verdict == 1:  # un rond autour de plusieurs lignes en couperait les coins (capture, 04/10/2026)
            self.stylo(peintre, self.VERT)
            peintre.save()
            peintre.translate(zone.center())
            peintre.rotate(-math.degrees(math.atan2(2, zone.width() / 2)))  # penché comme le rond, tracé à la main
            peintre.drawRoundedRect(QRectF(-zone.width() / 2 - 8, -zone.height() / 2 - 4, zone.width() + 16, zone.height() + 8), 12, 12)
            peintre.restore()
        elif lignes == 1:
            self.raturer(peintre, zone.left(), zone.right(), zone.center().y())
        else:  # un paragraphe barré par le correcteur : du coin bas gauche au coin haut droit
            self.stylo(peintre, self.ROUGE)
            peintre.drawLine(zone.bottomLeft() + QPointF(-3, 2), zone.topRight() + QPointF(3, -2))


class Code(Annotee, noyau.Code, Question):

    def _annoter(self, montree, fausses=None):
        self.surimpression.verdict = self.corriger(self.saisie)[0] if montree and self.saisie is not None else None
        self.surimpression.fautes = self.fautes(self.saisie) if self.surimpression.verdict is not None else ()
        super()._annoter(montree, fausses)

    def _corps(self, d):
        # la place de la réponse attendue, plus la ligne où le curseur attend ; ``lignes`` règle le papier (défaut 10),
        # pas l'écran : « au minimum pour la réponse attendue, et qu'elle grandisse si on écrit plus » (30/09/2026).
        # Plafond de 30 : seuls les projets Pyxel le passent (64 à 360 lignes, le jeu entier), où un cadre vide de
        # plusieurs écrans séparerait l'énoncé de la console ; toutes les autres solutions du dépôt en ont 25 au plus
        self.editeur = hauteur(EditeurCode(self.vierge(), self.gabarit() if self.verrouille else None, self.premiere_ligne),
                               min(self.solution.rstrip("\n").count("\n") + 2, 30))
        if self.langage in ("python", "sql", "assembleur"):
            self.console = ConsoleCode(self.editeur, self)  # la console porte l'éditeur, entre ses boutons et sa sortie
            self.console.reprendre(self.trace_console)
            self.console.rangee = self._ranger_console
            d.addWidget(self.console)
            self.entrees.append(self.console)
        else:
            d.addWidget(self.editeur)
        self.entrees.append(self.editeur)
        self.surimpression = SurimpressionCode(self)
        self.editeur.updateRequest.connect(lambda *_: self.surimpression.update())  # le texte défile : le trait le suit
        if self.suite_de:  # le code repris est celui de l'élève : violet, comme ce qu'il écrit ; la solution, bleue (donnée)
            self.editeur.donne = self.vierge() if self.depart_corrige() else ""
        self._vierge_montre = self.vierge()
        self.editeur.textChanged.connect(self._prevenir_suites)
        if self.editeur_externe:  # hors des entrées : le lien se corrige encore quand la question est soumise
            self.champ_lien = QLineEdit(self.lien)
            self.champ_lien.setPlaceholderText("https://www.pyxelstudio.net/studio/…")
            self.champ_lien.textChanged.connect(self._noter_lien)
            self.ligne_lien = QWidget()
            self.ligne_lien.setProperty("copiable", True)  # un lien se colle de l'extérieur ; le reste de la question reste fermé
            ligne = QHBoxLayout(self.ligne_lien)
            ligne.setContentsMargins(0, 0, 0, 0)
            ligne.addWidget(QLabel(dire("Lien de votre projet Pyxel Studio :")))
            ligne.addWidget(self.champ_lien, 1)
            d.addWidget(self.ligne_lien)

    def _ranger_console(self):
        self.trace_console = self.console.etat()
        self.changee.emit()

    def _noter_lien(self, texte):
        self.lien = texte.strip()
        self.changee.emit()

    def mettre_a_jour(self):
        super().mettre_a_jour()
        if self.langage in ("python", "sql", "assembleur"):
            self.console.masquer_execution(self.sans_execution)
        (self.console if self.langage in ("python", "sql", "assembleur") else self.editeur).setHidden(self.editeur_externe)
        if self.editeur_externe:  # le lien se demande une fois, à la première de ces questions
            self.ligne_lien.setHidden(self.premiere_externe not in (None, self))

    def _rapatrier(self):
        """Un code écrit hors du lecteur (``editeur_externe``) : l'app.py du projet Pyxel Studio de l'élève, lu à chaque
        soumission, devient la saisie, que les ``tests_code`` corrigent comme celle d'un éditeur — et la copie garde
        l'état du programme à chaque étape. Sans lien, ou projet illisible, la question ne se soumet pas et le dit.
        Rend vrai quand la soumission peut suivre."""
        if not self.editeur_externe or self.fermee or not self.actif:
            return True
        premiere = self.premiere_externe or self
        if not premiere.lien:
            ici = "ci-dessous" if premiere is self else f"à la question {premiere.numero}"
            self._dire(dire(f"*Donnez d'abord le lien de votre projet Pyxel Studio, {ici} : c'est votre programme qui est corrigé.*"))
            return False
        try:
            self._ecrire(pyxel_studio.code(premiere.lien))
        except ValueError as erreur:
            self._dire(dire("*Votre projet n'a pas pu être lu :") + f" {erreur}.*")
            return False
        return True

    def _lire(self):
        texte, fixes = self.editeur.toPlainText(), self.editeur.fixes
        # ``suite_de`` : ``vierge()`` suit l'origine, la question n'est intacte que si elle montre encore le code proposé
        if texte == (self._vierge_montre if self.suite_de else self.vierge()):
            return None
        if fixes and self.reprend:  # le code repris affiché redevient sa ligne « # @reprend » (``gabarit_saisie``)
            zones = noyau.zones_du_gabarit(fixes, texte)
            return noyau.remplir(self.gabarit_saisie(), [texte[a:b] for a, b in zones]) if zones else None
        return texte

    def _ecrire(self, valeur):
        # verrouillé, une saisie qui ne suit pas le gabarit (copie d'avant le verrouillage) n'aurait aucune zone où écrire
        if valeur is not None and self.editeur.fixes:
            zones = noyau.zones_du_gabarit(self.gabarit_saisie() if self.reprend else self.editeur.fixes, valeur)
            if zones is None and len(self.reprises) < len(self.reprend):
                self.en_attente = valeur  # une copie se charge : la question reprise n'est pas encore donnée (``reprendre``)
            valeur = None if zones is None else noyau.remplir(self.editeur.fixes, [valeur[a:b] for a, b in zones])
        # une saisie rendue (copie rouverte), même vide, est celle de l'élève : ``suite_de`` ne la remplace plus
        self._vierge_montre = self.vierge() if valeur is None else None
        self.editeur.setPlainText(self.vierge() if valeur is None else valeur)

    def partir_de(self, question):
        super().partir_de(question)
        question.changee.connect(self._suivre_depart)  # close et corrigée, elle donne sa solution ; rouverte, le code de l'élève
        self._suivre_depart()

    def _prevenir_suites(self):
        for suite in self.suites:
            suite._suivre_depart()

    def _suivre_depart(self):
        """``suite_de`` : tant que l'élève n'a rien écrit ici (l'éditeur montre encore le dernier code proposé), il
        reprend son code actuel à la question citée ; une zone qu'il a retravaillée n'est plus jamais touchée. Une
        question pas encore bâtie n'a rien à suivre : elle se bâtira sur ``vierge()``. Une question close non plus : son
        éditeur reste ce qu'il était à sa correction (06/10/2026). En cascade, par ``textChanged``."""
        if vars(self).get("batie") is False or self.fermee or self.editeur.toPlainText() != self._vierge_montre:
            return
        self._vierge_montre = self.vierge()
        self.editeur.donne = self._vierge_montre if self.depart_corrige() else ""
        if self.editeur.toPlainText() != self._vierge_montre:
            self.editeur.setPlainText(self._vierge_montre)

    def reprendre(self, question):
        """L'écran montre, à la place de la solution de ``question``, ce que l'élève y a écrit, et le suit tant qu'elle
        change (elle est close avant que celle-ci ne paraisse : ``revelations``)."""
        super().reprendre(question)
        question.changee.connect(self._suivre_reprise)
        self._suivre_reprise()

    def _suivre_reprise(self):
        if self.verrouille and self.editeur.fixes != self.gabarit_ecran():
            saisie = self.__dict__.pop("en_attente", None) or self._lire()
            self.editeur.fixes = self.gabarit_ecran()
            self.editeur.repris = [q.code_eleve() for q in self.reprises.values()]
            self._ecrire(saisie)

    if navigateur():  # la correction attend un Web Worker : elle se fait AVANT la soumission, la question grisée
        verdicts = {}  # id -> {saisie, fraction, message}, ce que _verifier rend

        def _verifier(self, saisie):
            v = self.verdicts.get(self.id)
            return (v["fraction"], v["message"]) if v is not None and v["saisie"] == saisie else (None, None)

        def soumettre(self):
            """Sans verdict pour cette saisie, la question attend, grisée, que le worker l'ait corrigée, puis se soumet
            comme en natif ; sans test, ou déjà corrigée, rien à attendre. Une question figée avant le verdict (temps
            écoulé) reste « en attente » : le professeur la corrige. Déjà en correction, rien : « Corriger mes réponses »
            la soumettrait une seconde fois, et le second verdict lui ôterait sa seconde chance."""
            if getattr(self, "en_correction", False) or not self._rapatrier():
                return
            saisie, suite = self.saisie, super().soumettre
            if self.fermee or not self.actif or not self.testee() or self.corriger(saisie) != (None, None):
                return suite()

            def verdict(fraction, message):
                self.verdicts[self.id] = self.verdict = {"saisie": saisie, "fraction": fraction, "message": message}
                self._corrections.pop((saisie, self.classe), None)
                self.en_correction = False
                self.setEnabled(True)
                suite()

            self.en_correction = True
            self.setEnabled(False)
            self._dire("*Vérification en cours…*")
            # la correction native (subprocess.run, doublé par qtpy6 : un Web Worker attendu par JSPI) dans un slot,
            # seule entrée où l'attente est possible, la page restant vivante pendant ce temps
            QTimer.singleShot(0, lambda: verdict(*noyau.Code._verifier(self, saisie)))
    else:
        def soumettre(self):
            if self._rapatrier():
                super().soumettre()


class Sql(noyau.Sql, Code):
    pass


class Etiquette(QStyledItemDelegate):
    """Une étiquette de ``Classement`` ou d'``Ordre`` : son Markdown peint (un ``QListWidgetItem`` n'affiche que du
    texte nu, et l'élève lisait « **1** »), et sa hauteur calculée sur la largeur RÉELLE de sa colonne : celle que
    ``QListView`` estime avec ``setWordWrap`` ne suit pas le rétrécissement de la colonne, et l'étiquette longue
    finissait coupée d'un « … » au lieu d'aller à la ligne."""

    RETRAIT = 4  # l'écart entre le liseré et le texte, celui que le style laissait au texte nu

    def _document(self, police, texte):
        largeur = self.parent().viewport().width() - 2 * self.parent().spacing() - 2 * self.RETRAIT
        return memoriser(self, (police.key(), texte, largeur), functools.partial(self._composer, police, texte, largeur))

    @staticmethod
    def _composer(police, texte, largeur):
        document = QTextDocument()
        document.setDocumentMargin(0)
        document.setDefaultFont(police)
        document.setHtml(html_case(texte))
        document.setTextWidth(largeur)
        return document

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        option.text = ""  # le style ne dessine plus que le cadre ; le texte, c'est ``paint`` qui s'en charge
        # ni fond ni liseré bleu une fois cliquée, survolée ou déposée : le cadre reste gris, seule l'étiquette en cours
        # de glisser-déposer l'épaissit (``paint``) — demande de l'utilisateur, 28/09/2026
        option.state &= ~(QStyle.StateFlag.State_Selected | QStyle.StateFlag.State_MouseOver | QStyle.StateFlag.State_HasFocus)

    def paint(self, peintre, option, index):
        super().paint(peintre, option, index)
        document = self._document(option.font, index.data())
        peintre.save()
        peintre.translate(option.rect.topLeft()
                          + QPoint(self.RETRAIT, max(0, int((option.rect.height() - document.size().height()) / 2))))
        document.drawContents(peintre)
        peintre.restore()
        if index.row() in self.parent().glissees:
            peintre.save()
            peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
            peintre.setPen(QPen(option.palette.highlight().color(), 3))
            peintre.drawRoundedRect(QRectF(option.rect).adjusted(1.5, 1.5, -1.5, -1.5), 4, 4)
            peintre.restore()

    def sizeHint(self, option, index):
        return self.taille(option.font, index.data())

    def taille(self, police, texte):
        return QSize(self.parent().viewport().width() - 2 * self.parent().spacing(),
                     math.ceil(self._document(police, texte).size().height()) + 2 * tactile.marge() + 4)


class Colonne(QListWidget):
    """Une liste d'étiquettes (colonne d'un ``Classement``, liste d'un ``Ordre``) : sa largeur change la hauteur de ses
    étiquettes, donc la sienne. ``touchee`` est le ``itemClicked`` d'un appui simple : au doigt, celui d'un toucher
    seulement (``tactile.Toucher``), un glissé faisant défiler la page sans rien ajouter ni retirer (TODO Lecteur web, 12)."""

    touchee = Signal(QListWidgetItem)

    def __init__(self, ajuster):
        super().__init__()
        self.ajuster = ajuster
        self.toucher, self.doigt, self.clic = tactile.Toucher(), False, True
        self.itemClicked.connect(lambda element: self.clic and self.touchee.emit(element))
        self.glissees = set()  # les rangs des étiquettes en cours de glisser-déposer, au cadre épaissi
        self.rendre = None  # ce que fait un double appui sur une étiquette (``Classement`` : la renvoyer à la réserve)
        self._appui = (None, 0)  # l'étiquette du dernier appui, et son instant (ms)

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.ajuster()

    def startDrag(self, actions):
        self.glissees = {index.row() for index in self.selectedIndexes()}
        try:
            super().startDrag(actions)  # l'image qui suit le doigt ou la souris est peinte avec le cadre épais
        finally:
            self.glissees = set()
            self.viewport().update()

    def _double(self, evenement):
        """Le double appui compté à la main, au second appui sur la même étiquette : ni la souris ni le doigt ne livrent
        la même suite d'événements. La souris envoie un appui PUIS un double clic ; le doigt, un double clic SEUL (mesuré
        par ``QTest.touchEvent``, 28/09/2026 : l'étiquette ne revenait jamais dans « À classer »). Compter les deux,
        l'étiquette renvoyée n'étant plus là pour le second, les réunit ; le double clic de ``QListWidget``, lui, ouvrirait
        l'édition."""
        element, instant = self.itemAt(evenement.position().toPoint()), evenement.timestamp()
        double = (element is not None and element is self._appui[0]
                  and instant - self._appui[1] <= QApplication.styleHints().mouseDoubleClickInterval())
        self._appui = (None if double else element, instant)
        if double:
            self.rendre(element)
        return double

    def mousePressEvent(self, evenement):
        self.doigt = self.toucher.appui(evenement)
        if self.rendre is None or not self._double(evenement):
            super().mousePressEvent(evenement)

    def mouseMoveEvent(self, evenement):
        self.toucher.bouge(evenement)
        super().mouseMoveEvent(evenement)

    def mouseReleaseEvent(self, evenement):
        self.clic = not self.doigt or self.toucher.leve(evenement)  # lu par ``itemClicked``, émis par Qt au relâchement
        super().mouseReleaseEvent(evenement)

    def mouseDoubleClickEvent(self, evenement):
        if self.rendre is None:
            super().mouseDoubleClickEvent(evenement)
        else:
            self._double(evenement)


def etiquettes(ajuster):
    """Une ``Colonne`` d'étiquettes à glisser, qui vont à la ligne plutôt que d'être coupées."""
    liste = Colonne(ajuster)
    liste.setDefaultDropAction(Qt.DropAction.MoveAction)
    liste.setWordWrap(True)
    liste.setSpacing(2)  # des étiquettes séparées, pas des lignes ; la marge d'une feuille de style, elle, fausserait le retour à la ligne
    liste.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    liste.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # la hauteur tient tout ; une barre rétrécirait le texte, qui passerait à la ligne et déborderait
    liste.setResizeMode(QListWidget.ResizeMode.Adjust)  # recalcule les hauteurs quand la colonne change de largeur
    liste.setItemDelegate(Etiquette(liste))
    liste.setStyleSheet(f"QListWidget::item {{ border: 1px solid #b0b0b0; border-radius: 4px; padding: {tactile.marge()}px 0; }}")
    return liste


def hauteur_etiquettes(liste, textes):
    """La hauteur qui tient toutes ces étiquettes, sans vide dessous, à la largeur actuelle de ``liste``."""
    etiquette, police, marge = liste.itemDelegate(), liste.font(), liste.spacing()
    return sum(etiquette.taille(police, t).height() + 2 * marge for t in textes) + 2 * liste.frameWidth()  # l'espacement, dessus et dessous


class SurimpressionClassement(Surimpression):
    """La correction à la main d'un classement, comme sur un tableau papier (04/10/2026) : une étiquette dans sa bonne
    colonne entourée de vert ; dans une autre, barrée en rouge et récrite en rouge au bas de sa colonne, où il reste
    toujours la place (chaque colonne a la hauteur de toutes les étiquettes) ; restée « À classer », seulement récrite.
    Écarté : écrire le nom de la bonne catégorie à côté de l'étiquette, qui ne tient pas dans une colonne étroite."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        juste, retrait = q.juste(), Etiquette.RETRAIT
        manquants, bas = [[] for _ in q.categories], []
        for k, liste in enumerate(q.colonnes):
            origine = QPointF(liste.viewport().mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos())
            bas.append(origine.y())
            for r in range(liste.count()):
                element = liste.item(r)
                i, cadre = element.data(Qt.ItemDataRole.UserRole), QRectF(liste.visualItemRect(element)).translated(origine)
                bas[-1] = cadre.bottom()
                document = liste.itemDelegate()._document(liste.font(), element.text())
                hauteur = document.size().height()  # le texte placé comme le peint ``Etiquette.paint``
                texte = QRectF(cadre.left() + retrait, cadre.top() + max(0, int((cadre.height() - hauteur) / 2)),
                               document.idealWidth(), hauteur)
                if k and juste[i] == k - 1:
                    self.entourer(peintre, texte, marge=(4, 2))
                    continue
                if k:  # une rature par ligne du texte, au milieu de chacune
                    bloc = document.begin()
                    while bloc.isValid():
                        for n in range(bloc.layout().lineCount()):
                            ligne = bloc.layout().lineAt(n).naturalTextRect().translated(bloc.layout().position() + texte.topLeft())
                            self.raturer(peintre, ligne.left(), ligne.right(), ligne.center().y())
                        bloc = bloc.next()
                manquants[juste[i]].append(i)
        for c, elements in enumerate(manquants):
            liste = q.colonnes[c + 1]
            peintre.setFont(self.main(QFontInfo(liste.font()).pixelSize()))
            peintre.setPen(self.ROUGE)
            gauche = self.cadre(liste.viewport()).left() + liste.spacing() + retrait
            y = bas[c + 1] + 2 * liste.spacing()
            for i in elements:
                nu = QTextDocument()
                nu.setHtml(html_case(q.elements[i].texte))  # l'écriture à la main n'a ni gras ni code
                ecrit = peintre.drawText(QRectF(gauche, y, liste.viewport().width() - 2 * (liste.spacing() + retrait), 1000),
                                         Qt.TextFlag.TextWordWrap, nu.toPlainText())
                y = ecrit.bottom() + 2 * liste.spacing()


class Classement(Annotee, noyau.Classement, Question):

    def _corps(self, d):
        """Un tableau comme sur papier : une colonne par catégorie, où glisser les étiquettes depuis la réserve
        « À classer », à gauche. Chaque colonne est une liste qui peut contenir tous les éléments : on dépose
        aussi dans une colonne vide, et un double-clic renvoie l'étiquette à la réserve."""
        grille = QGridLayout()
        self.colonnes = []  # la réserve, puis les catégories dans l'ordre de ``categories``
        for k, titre in enumerate(["À classer", *self.categories]):
            grille.addWidget(Texte(f"*{titre}*" if k == 0 else f"**{titre}**", inline=True), 0, k)
            liste = etiquettes(self._ajuster)
            liste.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
            if k:
                liste.rendre = functools.partial(self._rendre, liste)
            grille.addWidget(liste, 1, k)
            grille.setColumnStretch(k, 1)
            self.colonnes.append(liste)
        d.addWidget(Texte(dire("*Glissez chaque élément dans sa colonne (double-clic : il revient dans « À classer »).*"), inline=True))
        d.addLayout(grille)
        self.entrees += self.colonnes
        self._ecrire(None)
        self.surimpression = SurimpressionClassement(self)

    def _attendu(self):
        return ""  # chaque étiquette mal classée récrite dans sa colonne (``SurimpressionClassement``)

    def _ajuster(self):
        """Toutes les colonnes à la hauteur de la réserve pleine : de quoi tenir tous les éléments, sans vide dessous.
        Les colonnes ont la même largeur, donc chaque étiquette la même hauteur dans n'importe laquelle."""
        reserve = self.colonnes[0] if len(self.colonnes) == len(self.categories) + 1 else None
        if reserve is None:
            return  # colonnes en cours de création
        hauteur = hauteur_etiquettes(reserve, (e.texte for e in self.elements))
        for liste in self.colonnes:
            liste.setFixedHeight(hauteur)

    def _rendre(self, liste, element):
        self.colonnes[0].addItem(liste.takeItem(liste.row(element)))

    def _lire(self):
        choix = [None] * len(self.elements)
        for k, liste in enumerate(self.colonnes[1:]):
            for rang in range(liste.count()):
                choix[liste.item(rang).data(Qt.ItemDataRole.UserRole)] = k
        return None if all(c is None for c in choix) else choix

    def _ecrire(self, valeur):
        for liste in self.colonnes:
            liste.clear()
        for i in self.depart:
            element = QListWidgetItem(self.elements[i].texte)
            element.setData(Qt.ItemDataRole.UserRole, i)
            self.colonnes[0 if valeur is None or valeur[i] is None else valeur[i] + 1].addItem(element)


class SurimpressionSchema(Surimpression):
    """La correction à la main d'un schéma relationnel (04/10/2026), ligne par ligne et seulement sur ce que la question
    demande, en suivant la note : un nom, une référence ou un domaine justes entourés de vert, faux barrés en rouge avec
    l'attendu écrit à leur suite ; une case de clé primaire comme une case à cocher (rond vert, rature, flèche verte si
    oubliée). Un nom faux reçoit le premier attribut que l'élève n'a pas trouvé, et sa ligne se corrige pour lui ; ceux
    qui restent s'écrivent à droite du bouton « + attribut »."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        saisie = q._lire_tout()
        for r in q.a_remplir():
            paires = q.apparier(r, saisie[r.nom])
            manquants = q.manquants(r, paires)
            for ligne, (valeurs, a) in zip(q.lignes[r.nom], paires):
                trouve = a is not None
                if not trouve and manquants:
                    a = manquants.pop(0)
                if isinstance(ligne["nom"], QLineEdit):
                    self.corriger_champ(peintre, ligne["nom"], valeurs["nom"], trouve, a.nom if a else "")
                if "cles" in q.demande and ligne["libres"]["cle"]:
                    self._case(peintre, ligne["cle"], valeurs["cle"], bool(a and a.cle), trouve)
                menu, choisie = ligne["reference"], valeurs["reference"]
                if "etrangeres" in q.demande:
                    attendue = a.reference if a else ""
                    bonne = trouve and bool(attendue) and q.designe(choisie) is q.designe(attendue)
                    option = QStyleOptionComboBox()
                    menu.initStyleOption(option)
                    champ = menu.style().subControlRect(QStyle.ComplexControl.CC_ComboBox, option,
                                                        QStyle.SubControl.SC_ComboBoxEditField, menu)
                    self.corriger_champ(peintre, menu, choisie, bonne, attendue, champ.left() + 2)
                if "domaines" in q.demande:
                    self.corriger_champ(peintre, ligne["domaine"], valeurs["domaine"], trouve and a.domaine_juste(valeurs["domaine"]),
                                        (a.domaines or [""])[0] if a else "")
            if manquants:  # seulement quand l'élève écrit les attributs : ailleurs, les lignes sont les attributs
                bouton = q.lignes[r.nom][0]["nom"].parentWidget().findChild(QPushButton)
                cadre = self.cadre(bouton)
                taille = QFontInfo(bouton.font()).pixelSize()
                self.ecrire(peintre, QPointF(cadre.right() + 10, cadre.center().y() + taille / 3),
                            ", ".join(a.nom for a in manquants), taille)

    def _case(self, peintre, case, cochee, attendue, trouve):
        """La case « clé primaire » d'une ligne : juste seulement si l'attribut est trouvé, comme dans la note."""
        option = QStyleOptionButton()
        case.initStyleOption(option)
        zone = QRectF(case.style().subElementRect(QStyle.SubElement.SE_CheckBoxIndicator, option, case))
        zone.translate(self.cadre(case).topLeft())
        if cochee and attendue and trouve:
            self.entourer(peintre, zone, marge=(4, 4))
        elif cochee:
            self.stylo(peintre, self.ROUGE)
            d = zone.width() / 2 + 3.5
            peintre.drawLine(zone.center() + QPointF(-d, d), zone.center() + QPointF(d, -d))
        elif attendue:
            self.flecher(peintre, QPointF(zone.left() - 4, zone.center().y()))


class Schema(Annotee, noyau.Schema, Question):

    def _attendu(self):
        return ""  # corrigé à la main sur les lignes (``SurimpressionSchema``)

    def _corps(self, d):
        """Une boîte par relation, une ligne par attribut (son nom, la case « clé primaire », la clé qu'il référence, son
        domaine) et, sous chaque boîte, la relation dans la notation du bac, recomposée à chaque changement."""
        self.surimpression = SurimpressionSchema(self)
        consigne = {"attributs": "Écrivez les attributs de chaque relation.", "cles": "Cochez les attributs de la clé primaire.",
                    "etrangeres": "Pour chaque clé étrangère, choisissez la clé primaire qu'elle référence.",
                    "domaines": "Donnez le domaine de chaque attribut."}
        d.addWidget(Texte(dire("*" + " ".join(consigne[c] for c in SCHEMA_DEMANDES if c in self.demande) + "*"), inline=True))
        self.lignes, self.grilles, self.apercus = {}, {}, {}
        for r in self.relations:
            if r.fixe:
                d.addWidget(Texte(self.notation(r.nom, [self.ligne_juste(a) for a in r.attributs], "domaines" in self.demande, cibles=False), inline=True))
                continue
            cadre = QFrame()
            cadre.setFrameShape(QFrame.Shape.StyledPanel)
            colonne = QVBoxLayout(cadre)
            colonne.addWidget(QLabel(f"<b>{html.escape(r.nom)}</b>"))
            self.grilles[r.nom] = QGridLayout()
            for x, entete in enumerate(["Attribut", "Clé primaire", "Référence (clé étrangère)", "Domaine"][:3 + ("domaines" in self.demande)]):
                self.grilles[r.nom].addWidget(etiquette := QLabel(f"<i>{entete}</i>"), 0, x)
                etiquette.setVisible(x != 2 or self._references_visibles(r))
            colonne.addLayout(self.grilles[r.nom])
            self.lignes[r.nom] = []
            if "attributs" in self.demande:
                ajout = QPushButton("+ attribut")
                ajout.clicked.connect(functools.partial(self._ajouter, r, None))
                colonne.addWidget(ajout, alignment=Qt.AlignmentFlag.AlignLeft)
                for _ in range(len(r.attributs)):
                    self._ajouter(r, None)
            else:
                for a in r.attributs:
                    self._ajouter(r, a)
            self.apercus[r.nom] = QLabel()
            colonne.addWidget(self.apercus[r.nom])
            d.addWidget(cadre)
            self.entrees.append(cadre)
        self._actualiser()

    def _ajouter(self, relation, attribut, *_):
        """Une ligne d'attribut : ``attribut`` donné (son nom affiché, et ce que la question ne demande pas, posé et figé),
        ou ``None`` pour une ligne que l'élève remplit."""
        y = len(self.lignes[relation.nom]) + 1
        ligne = {"nom": QLabel(attribut.nom) if attribut else QLineEdit(), "cle": QCheckBox(), "reference": QComboBox()}
        ligne["reference"].setEditable(False)
        if "domaines" in self.demande:
            ligne["domaine"] = QLineEdit()
        if attribut:
            if "cles" not in self.demande:
                ligne["cle"].setChecked(attribut.cle)
                ligne["cle"].setEnabled(False)
            if "etrangeres" not in self.demande:
                ligne["reference"].setEnabled(False)
        ligne["reference"].setVisible(self._references_visibles(relation))
        for x, w in enumerate(ligne.values()):
            self.grilles[relation.nom].addWidget(w, y, x)
        if isinstance(ligne["nom"], QLineEdit):
            ligne["nom"].textChanged.connect(self._actualiser)
        if "domaine" in ligne:
            ligne["domaine"].textChanged.connect(self._actualiser)
        ligne["cle"].toggled.connect(self._actualiser)
        ligne["reference"].currentTextChanged.connect(self._actualiser)
        ligne["attribut"] = attribut
        ligne["libres"] = {"cle": "cles" in self.demande or not attribut, "reference": "etrangeres" in self.demande or not attribut}
        self.lignes[relation.nom].append(ligne)
        if attribut and "etrangeres" not in self.demande:
            self._references(relation.nom, ligne)
            ligne["reference"].setCurrentText(attribut.reference)
        self._actualiser()

    def _references_visibles(self, relation):
        """La colonne des références, seulement si l'élève les choisit ou si la relation en a à montrer."""
        return "etrangeres" in self.demande or any(a.reference for a in relation.attributs)

    def _cibles(self, relation):
        """Les clés qu'un attribut de ``relation`` peut référencer : les attributs des AUTRES relations, tels qu'affichés
        ou tels que l'élève les a écrits."""
        cibles = []
        for r in self.relations:
            if r.nom == relation:
                continue
            noms = [self._nom(l) for l in self.lignes.get(r.nom, [])] if r.nom in self.lignes else [a.nom for a in r.attributs]
            cibles += [f"{r.nom}.{n.strip()}" for n in noms if n.strip()]
        return cibles

    @staticmethod
    def _nom(ligne):
        return ligne["attribut"].nom if ligne["attribut"] else ligne["nom"].text()

    def _references(self, relation, ligne):
        menu, courant = ligne["reference"], ligne["reference"].currentText()
        options = [""] + self._cibles(relation)
        if [menu.itemText(i) for i in range(menu.count())] != options:
            menu.blockSignals(True)
            menu.clear()
            menu.addItems(options)
            menu.setCurrentText(courant if courant in options else "")
            menu.blockSignals(False)

    def _actualiser(self, *_):
        if not getattr(self, "apercus", None):
            return
        saisie = self._lire_tout()
        for r in self.lignes:
            for ligne in self.lignes[r]:
                if ligne["libres"]["reference"]:
                    self._references(r, ligne)
            if r in self.apercus:
                self.apercus[r].setText("Notation : " + re.sub(r"\[([^]]*)\]\{\.souligne\}", r"<u>\1</u>",
                                                               html.escape(self.notation(r, saisie[r], "domaines" in self.demande))))

    def _lire_tout(self):
        return {r: [{"nom": self._nom(l).strip(), "cle": l["cle"].isChecked(), "reference": l["reference"].currentText(),
                     "domaine": l["domaine"].text().strip() if "domaine" in l else ""} for l in lignes]
                for r, lignes in self.lignes.items()}

    def _lire(self):
        """``None`` tant que l'élève n'a rien fait : ce que la question pose d'elle-même (noms donnés, clés figées) ne compte pas."""
        saisie, faite = self._lire_tout(), False
        for r, lignes in self.lignes.items():
            for l, valeurs in zip(lignes, saisie[r]):
                faite |= bool(isinstance(l["nom"], QLineEdit) and valeurs["nom"] or valeurs.get("domaine")
                              or l["libres"]["cle"] and valeurs["cle"] or l["libres"]["reference"] and valeurs["reference"])
        return saisie if faite else None

    def _ecrire(self, valeur):
        for r in self.relations:
            if r.nom not in self.lignes:
                continue
            lignes = (valeur or {}).get(r.nom) or []
            while "attributs" in self.demande and len(self.lignes[r.nom]) < len(lignes):
                self._ajouter(r, None)
            for i, l in enumerate(self.lignes[r.nom]):
                v = lignes[i] if i < len(lignes) else {}
                if isinstance(l["nom"], QLineEdit):
                    l["nom"].setText(v.get("nom", ""))
                if l["libres"]["cle"]:
                    l["cle"].setChecked(bool(v.get("cle")))
                if "domaine" in l:
                    l["domaine"].setText(v.get("domaine", ""))
            self._actualiser()  # les menus de références ont leurs options avant qu'on y choisisse
            for i, l in enumerate(self.lignes[r.nom]):
                if l["libres"]["reference"]:
                    l["reference"].setCurrentText((lignes[i] if i < len(lignes) else {}).get("reference", ""))
        self._actualiser()


class SurimpressionPermissions(Surimpression):
    """La correction à la main d'une grille de droits, comme celle des cases à cocher : un droit attendu coché entouré de
    vert (un droit à retirer et retiré aussi), oublié fléché, une case cochée à tort raturée en rouge ; un droit qui ne
    change pas et reste juste reste nu. En terminal, la commande juste est entourée, une fausse barrée et la commande attendue écrite à sa suite ; la
    grille, qui montre ce qu'a fait la commande de l'élève, se corrige de même."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        apres = q.droits_saisis(q._lire())
        for i, case in enumerate(q.cases):
            zone = QRectF(indicateur(case)).translated(self.cadre(case).topLeft())
            if apres[i] == q.droits[i]:
                if q.droits[i] != q.avant[i]:  # un droit à changer, changé : ajouté ou retiré
                    self.entourer(peintre, zone, marge=(4, 4))
            elif q.droits[i] != "-":
                self.flecher(peintre, QPointF(zone.left() - 4, zone.center().y()))
            else:
                self.stylo(peintre, self.ROUGE)
                d = zone.width() / 2 + 3.5
                peintre.drawLine(zone.center() + QPointF(-d, d), zone.center() + QPointF(d, -d))
        if q.commande:
            texte = q.champ.text().rstrip()
            juste = bool(texte) and q.corriger(texte)[0] == 1
            self.corriger_champ(peintre, q.champ, texte, juste, "" if juste else q.juste())


class Permissions(Annotee, noyau.Permissions, Question):

    def _attendu(self):
        return ""  # corrigé à la main sur la grille et la commande (``SurimpressionPermissions``)

    def _corps(self, d):
        """La grille propriétaire, groupe, autres × r, w, x ; en terminal, l'invite et la commande au-dessus, la réponse
        du terminal dessous, et la grille, en lecture seule, montre les droits que donne la commande."""
        self.surimpression = SurimpressionPermissions(self)
        if self.commande:
            invite = QHBoxLayout()
            invite.addWidget(etiquette := QLabel(f"{html.escape(self.utilisateur or 'eleve')}@nsi:~$"))
            self.champ = QLineEdit()
            for w in (etiquette, self.champ):
                w.setFont(QFont(MONO))
            invite.addWidget(self.champ, 1)
            d.addLayout(invite)
            self.reponse = QLabel()
            self.reponse.setFont(QFont(MONO))
            d.addWidget(self.reponse)
            self.champ.textChanged.connect(self._actualiser)
            self.champ.returnPressed.connect(lambda: self.retenue or self.soumettre())
            self.entrees.append(self.champ)
        grille = QGridLayout()
        grille.addWidget(QLabel(f"<i>Droits de</i> <tt>{html.escape(self.fichier)}</tt>"), 0, 0)
        for j, entete in enumerate(("lecture (r)", "écriture (w)", "exécution (x)")):
            grille.addWidget(QLabel(f"<i>{entete}</i>"), 0, j + 1, Qt.AlignmentFlag.AlignCenter)
        self.cases = []
        for i, categorie in enumerate(noyau.CATEGORIES_UNIX):
            grille.addWidget(QLabel(categorie), i + 1, 0)
            for j in range(3):
                case = CaseCarree()
                grille.addWidget(case, i + 1, j + 1, Qt.AlignmentFlag.AlignCenter)
                self.cases.append(case)
                if self.commande:  # l'effet de la commande, que l'élève ne coche pas
                    case.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
                    case.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                else:
                    self.entrees.append(case)
        grille.setColumnStretch(4, 1)
        d.addLayout(grille)
        self._afficher(self.avant)

    def _afficher(self, droits):
        for case, droit in zip(self.cases, droits):
            case.setChecked(droit != "-")

    def _actualiser(self, *_):
        """La commande tapée, exécutée à mesure : ses droits dans la grille, ou le message du terminal."""
        try:
            droits, message = self.executer(self.champ.text()), ""
        except ValueError as erreur:
            droits, message = self.avant, str(erreur)
        self._afficher(droits)
        self.reponse.setText(message)
        self.reponse.setVisible(bool(message))

    def _lire(self):
        if self.commande:
            return self.champ.text().strip() or None
        droits = "".join(l if case.isChecked() else "-" for case, l in zip(self.cases, "rwx" * 3))
        return None if droits == self.avant else droits

    def _ecrire(self, valeur):
        if self.commande:
            self.champ.setText(valeur or "")
        else:
            self._afficher(valeur or self.avant)


class AxeGradue(QWidget):
    """La saisie d'un ``axe`` (1.56) : la figure du noyau (``noyau.Axe.svg``, la même que sur le papier), une bande par
    sorte d'objet au-dessus de l'axe. Un clic dans la bande d'un objet à poser le pose au cran le plus proche, un second
    clic au même cran le retire ; sous les bandes (sur l'axe, ses nombres), le clic vaut pour l'objet à poser s'il est
    seul. Les objets donnés sont gris et ne réagissent pas. Au doigt (``tactile.ACTIF``), seul un toucher sans glisser
    pose, à son lever : tout glisser fait défiler la page (comme ``FriseGantt``). Se réduit comme une toile de dessin."""

    question = property(lambda self: self._question())
    ECRAN = 1.2  # pixels par point de la figure : l'écran agrandit tout de 12/10, comme ``ObjetSvg``

    def __init__(self, question):
        super().__init__()
        self._question, self.poses, self.rendu = weakref.ref(question), {}, None  # poses : nom -> {cran}
        self.toucher, self.tap = tactile.Toucher(), None  # au doigt : le cran touché, posé au lever d'un toucher
        g = question.geometrie()
        self.naturelle = QSize(math.ceil(g["largeur"] * self.ECRAN), math.ceil(g["hauteur"] * self.ECRAN))
        largeur_mini = min(self.naturelle.width(), TOILE_MINIMUM)
        self.setMinimumSize(largeur_mini, self.heightForWidth(largeur_mini))
        politique = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        politique.setHeightForWidth(True)
        self.setSizePolicy(politique)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def sizeHint(self):
        return self.naturelle

    def heightForWidth(self, largeur):
        return math.ceil(self.naturelle.height() * min(1, largeur / self.naturelle.width()))

    def facteur(self):
        """Pixels du widget par point de la figure."""
        return self.ECRAN * min(1, self.width() / self.naturelle.width())

    def saisie(self):
        q = self.question
        saisie = {nom: [q.position(k) for k in sorted(crans)] for nom, crans in self.poses.items() if crans}
        return saisie or None

    def poser(self, valeur):
        self.poses = {nom: self.question.crans(positions) for nom, positions in (valeur or {}).items()}
        self.rendu = None
        self.update()

    def paintEvent(self, _):
        if self.rendu is None:
            svg = self.question.svg(self.saisie(), police=self.font().resolve(QApplication.font()).family())
            self.rendu = QSvgRenderer(QByteArray(svg.encode()))
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.facteur() / self.ECRAN
        self.rendu.render(peintre, QRectF(0, 0, self.naturelle.width() * r, self.naturelle.height() * r))

    def point(self, i, k):
        """Le milieu de l'objet ``i`` posé au cran ``k``, en pixels du widget."""
        q, g = self.question, self.question.geometrie()
        return QPointF(g["x"](q.position(k)), g["bande"](i) - 14) * self.facteur()

    def _sous(self, position):
        """(objet à poser, cran) sous ce point, ``None`` ailleurs."""
        q, g = self.question, self.question.geometrie()
        x, y = position.x() / self.facteur(), position.y() / self.facteur()
        k = round((x - g["gauche"]) / (g["unite"] * q.cran()))
        if not 0 <= k <= round((q.fin - q.debut) / q.cran()) or abs(x - g["x"](q.position(k))) > g["unite"] * q.cran() / 2 + 1:
            return None
        i = math.floor(y / q.BANDE)
        if i < len(q.objets):
            objet = q.objets[i]
        elif len(q.a_poser()) == 1:
            objet = q.a_poser()[0]
        else:
            return None
        return None if objet.donne else (objet.nom, k)

    def mousePressEvent(self, evenement):
        sous = self._sous(evenement.position())
        if not self.isEnabled() or sous is None:
            return
        if self.toucher.appui(evenement):
            self.tap = sous
            return
        self._basculer(*sous)

    def mouseMoveEvent(self, evenement):
        self.toucher.bouge(evenement)

    def mouseReleaseEvent(self, evenement):
        if self.toucher.leve(evenement) and self.tap:
            self._basculer(*self.tap)
        self.tap = None

    def _basculer(self, nom, k):
        self.poses.setdefault(nom, set()).symmetric_difference_update({k})
        self.rendu = None
        self.update()


class SurimpressionAxe(Surimpression):
    """La correction à la main d'un ``axe`` : un objet posé à la bonne place entouré de vert, un objet de trop barré de
    rouge, une place attendue oubliée encadrée de vert en pointillé ; et la double flèche de portée, en vert sous l'axe,
    de chaque objet attendu qui en a une. En seconde chance, les ratures seules : la réponse reste à trouver."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        axe, g = q.axe, q.geometrie()
        coin, f = self.cadre(axe).topLeft(), axe.facteur()

        def zone(i, k):  # l'objet de la bande i au cran k, en coordonnées de la surimpression
            x, base = g["x"](q.position(k)), g["bande"](i)
            return QRectF(coin + QPointF(x - 9, base - 30) * f, QSizeF(18, 30) * f)

        for i, o in enumerate(q.objets):
            if o.donne:
                continue
            attendus, poses = q.crans(o.positions), axe.poses.get(o.nom, set())
            for k in poses:
                if k not in attendus:
                    r = zone(i, k)
                    self.stylo(peintre, self.ROUGE)
                    peintre.drawLine(r.bottomLeft(), r.topRight())
                elif self.fausses is None:
                    self.entourer(peintre, zone(i, k), marge=(3, 3))
            if self.fausses is not None:
                continue
            for k in attendus - poses:
                peintre.setPen(QPen(self.VERT, 2, Qt.PenStyle.DashLine))
                peintre.drawRect(zone(i, k))
            if o.portee:
                self.stylo(peintre, self.VERT, 2)
                y = coin.y() + g["portee"] * f
                for p in o.positions:
                    a = coin.x() + g["x"](max(q.debut, p - o.portee)) * f
                    b = coin.x() + g["x"](min(q.fin, p + o.portee)) * f
                    peintre.drawLine(QPointF(a, y), QPointF(b, y))
                    for bout, sens in ((a, 1), (b, -1)):
                        peintre.drawPolyline(QPolygonF([QPointF(bout + 7 * sens, y - 4), QPointF(bout, y), QPointF(bout + 7 * sens, y + 4)]))


class Axe(Annotee, noyau.Axe, Question):

    def _attendu(self):
        return ""  # corrigé à la main sur l'axe (``SurimpressionAxe``)

    def _corps(self, d):
        self.axe, self.surimpression = AxeGradue(self), SurimpressionAxe(self)
        noms = [o.nom for o in self.a_poser()]
        quoi = f"chaque {noms[0]}" if len(noms) == 1 else "chaque objet dans sa bande"
        d.addWidget(Texte(f"*Cliquez au-dessus de l'axe pour placer {quoi} ; un second clic au même endroit l'efface.*", inline=True))
        d.addWidget(self.axe)
        self.entrees.append(self.axe)

    def _lire(self):
        return self.axe.saisie()

    def _ecrire(self, valeur):
        self.axe.poser(valeur)


class Chaine(QWidget):
    """La saisie d'une ``liste_chainee`` (1.44) : la figure du noyau (``noyau.ListeChainee.svg``, la même que sur le papier),
    où l'élève tire la flèche de chaque case pointeur. Un clic (un toucher) sur une case à remplir l'arme, surlignée ; le
    clic suivant sur un maillon, lui-même compris, y pose la flèche, sur la case armée y écrit ``None``, ailleurs désarme ;
    Suppr vide la case armée. À la souris, glisser de la case au maillon fait la même chose d'un geste (press/move/release,
    sans ``QDrag``) ; au doigt, un glissé fait défiler la page, et le toucher puis toucher suffit. Se réduit comme une toile
    de dessin."""

    question = property(lambda self: self._question())
    ECRAN = 1.2  # pixels par point de la figure, comme ``AxeGradue``

    def __init__(self, question):
        super().__init__()
        self._question, self.pointeurs, self.rendu = weakref.ref(question), {}, None  # pointeurs : "nom.champ" -> nom ou None
        self.armee, self.tire, self.tap = None, None, None  # la case armée ; le point où glisse la flèche tirée ; l'appui du doigt
        self.toucher = tactile.Toucher()
        g = question.geometrie()
        self.naturelle = QSize(math.ceil(g["largeur"] * self.ECRAN), math.ceil(g["hauteur"] * self.ECRAN))
        largeur_mini = min(self.naturelle.width(), TOILE_MINIMUM)
        self.setMinimumSize(largeur_mini, self.heightForWidth(largeur_mini))
        politique = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        politique.setHeightForWidth(True)
        self.setSizePolicy(politique)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def sizeHint(self):
        return self.naturelle

    def heightForWidth(self, largeur):
        return math.ceil(self.naturelle.height() * min(1, largeur / self.naturelle.width()))

    def facteur(self):
        """Pixels du widget par point de la figure."""
        return self.ECRAN * min(1, self.width() / self.naturelle.width())

    def rect(self, x, y, l, h):
        f = self.facteur()
        return QRectF(x * f, y * f, l * f, h * f)

    def poser(self, valeur):
        self.pointeurs, self.armee = dict(valeur or {}), None
        self._changer()

    def _changer(self):
        self.rendu = None
        self.update()

    def paintEvent(self, _):
        q = self.question
        if self.rendu is None:
            self.rendu = QSvgRenderer(QByteArray(q.svg(self.pointeurs, police=self.font().resolve(QApplication.font()).family()).encode()))
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.facteur() / self.ECRAN
        self.rendu.render(peintre, QRectF(0, 0, self.naturelle.width() * r, self.naturelle.height() * r))
        if self.armee:
            case = self.case(self.armee)
            peintre.fillRect(case, QColor(21, 101, 192, 60))
            if self.tire is not None:
                peintre.setPen(QPen(QColor("#1565c0"), 1.5, Qt.PenStyle.DashLine))
                peintre.drawLine(case.center(), self.tire)

    def case(self, cle):
        """Le rectangle de la case « nom.champ », en pixels du widget."""
        q = self.question
        nom, _, champ = cle.rpartition(".")
        return self.rect(*q.geometrie()["case"]([m.nom for m in q.maillons].index(nom), champ))

    def _sous(self, position):
        """(maillon sous ce point ou ``None``, clé de la case à remplir sous ce point ou ``None``)."""
        q, g = self.question, self.question.geometrie()
        for i, m in enumerate(q.maillons):
            if self.rect(*g["boite"](i)).contains(position):
                for c in q.pointeurs():
                    if c not in m.donnes and self.rect(*g["case"](i, c)).contains(position):
                        return m.nom, f"{m.nom}.{c}"
                return m.nom, None
        return None, None

    def _cliquer(self, position):
        maillon, cle = self._sous(position)
        if self.armee is None:
            self.armee = cle
        elif maillon is None:
            self.armee = None
        else:
            self.pointeurs[self.armee] = None if cle == self.armee else maillon
            self.armee = None
        self._changer()

    def mousePressEvent(self, evenement):
        if not self.isEnabled():
            return
        if self.toucher.appui(evenement):  # au doigt, rien avant le lever : un glissé fait défiler la page
            self.tap = evenement.position()  # le point de l'appui : la page qui défile déplace celui du lever
            return
        armee = self.armee
        self._cliquer(evenement.position())
        if armee is None and self.armee is not None:  # le clic qui arme peut commencer un glisser
            self.tire = evenement.position()

    def mouseMoveEvent(self, evenement):
        self.toucher.bouge(evenement)
        if self.tire is not None:
            self.tire = evenement.position()
            self.update()

    def mouseReleaseEvent(self, evenement):
        if self.toucher.leve(evenement) and self.tap is not None:
            self._cliquer(self.tap)
        elif self.tire is not None:
            self.tire = None
            maillon, cle = self._sous(evenement.position())
            if maillon is not None and cle != self.armee:  # relâché sur un autre maillon : la flèche est tirée
                self._cliquer(evenement.position())
            self.update()
        self.tap = None

    def keyPressEvent(self, evenement):
        if self.armee and evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.pointeurs.pop(self.armee, None)
            self.armee = None
            self._changer()
        else:
            super().keyPressEvent(evenement)


class SurimpressionChaine(Surimpression):
    """La correction à la main d'une ``liste_chainee`` : un pointeur juste a sa case entourée de vert ; une flèche fausse est
    barrée en rouge au quart de son trait, un ``None`` faux raturé ; la flèche attendue (ou ``None``) est tracée à la main en
    vert, sur toute case fausse ou vide. En seconde chance, les ratures seules : la réponse reste à trouver."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        chaine = q.chaine
        coin, f = self.cadre(chaine).topLeft(), chaine.facteur()
        index = {m.nom: i for i, m in enumerate(q.maillons)}

        def point(x, y):
            return coin + QPointF(x, y) * f

        for cle in q.a_remplir():
            nom, _, champ = cle.rpartition(".")
            case = chaine.case(cle).translated(coin)
            attendu, rempli = q.attendu(cle), cle in chaine.pointeurs
            saisi = chaine.pointeurs.get(cle)
            if rempli and saisi == attendu:
                if self.fausses is None:
                    self.entourer(peintre, case.adjusted(4, 4, -4, -4), marge=(3, 3))
                continue
            if rempli and saisi is None:
                self.raturer(peintre, case.left() + 3, case.right() - 3, case.center().y())
            elif rempli:
                depart, controles, arrivee = q.trace(index[nom], champ, index[saisi])
                if controles:  # le travers au quart de la courbe, sur le trait et perpendiculaire à lui
                    a, b, c, d = (point(*p) for p in (depart, *controles, arrivee))
                    ici = (a * 27 + b * 27 + c * 9 + d) / 64  # la courbe de Bézier en t = 1/4
                    tangente = ((b - a) * 27 + (c - b) * 18 + (d - c) * 3) / 16  # sa dérivée
                    self.barrer(peintre, ici - tangente * 0.25, ici + tangente * 0.75)
                else:
                    self.barrer(peintre, point(*depart), point(*arrivee))
            if self.fausses is not None:
                continue
            if attendu is None:
                taille = QFontInfo(chaine.font()).pixelSize()
                ligne = case.bottom() + taille if q.cote(champ) < 0 else case.top() - 4
                self.ecrire(peintre, QPointF(case.center().x(), ligne), "None", taille, self.VERT, droite=False)
                continue
            depart, controles, arrivee = q.trace(index[nom], champ, index[attendu])
            chemin = QPainterPath(point(*depart))
            if controles:
                chemin.cubicTo(point(*controles[0]), point(*controles[1]), point(*arrivee))
            else:
                chemin.lineTo(point(*arrivee))
            self.stylo(peintre, self.VERT, 2)
            peintre.drawPath(chemin)
            avant = point(*(controles[1] if controles else depart))
            bout = point(*arrivee)
            sens = bout - avant
            sens /= math.hypot(sens.x(), sens.y()) or 1
            travers = QPointF(-sens.y(), sens.x())
            peintre.drawPolyline(QPolygonF([bout - sens * 8 + travers * 4, bout, bout - sens * 8 - travers * 4]))


class ListeChainee(Annotee, noyau.ListeChainee, Question):

    def _attendu(self):
        return ""  # corrigé à la main sur la figure (``SurimpressionChaine``)

    def _corps(self, d):
        self.chaine, self.surimpression = Chaine(self), SurimpressionChaine(self)
        d.addWidget(Texte("*Cliquez sur une case pointeur, puis sur le maillon visé ; cliquez deux fois sur la case pour "
                          "y écrire `None`, Suppr l'efface.*", inline=True))
        d.addWidget(self.chaine)
        self.entrees.append(self.chaine)

    def _lire(self):
        return dict(self.chaine.pointeurs) or None

    def _ecrire(self, valeur):
        self.chaine.poser(valeur)


class BoutonGlyphe(QToolButton):
    """Un bouton plat dont le texte, un ou deux signes, s'écrit entier au centre : ``QToolButton`` réserve ses marges
    de style et abrège « ↙↘ » en « … » dans les 32 pixels que lui laisse un champ."""

    def paintEvent(self, _):
        peintre = QPainter(self)
        if self.isEnabled() and self.underMouse():
            peintre.fillRect(self.rect(), QColor(0, 0, 0, 25))
        groupe = QPalette.ColorGroup.Active if self.isEnabled() else QPalette.ColorGroup.Disabled
        peintre.setPen(self.palette().color(groupe, QPalette.ColorRole.ButtonText))
        peintre.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.text())


class ArbreDeroulement(QWidget):
    """La saisie d'un ``deroulement`` (1.58) : l'arbre que l'élève construit, aux places de ``noyau.Deroulement.places``
    (les mêmes que sur le papier). La liste de départ est donnée, grisée ; le bouton ↙↘ d'une liste la sépare en deux
    cases vides, et la case de sa fusion paraît dessous, au miroir de l'arbre ; le bouton × retire une séparation dont
    toutes les cases sont vides (il est grisé sinon : rien de ce que l'élève a écrit ne s'efface d'un clic). Les flèches,
    de chaque liste vers ses moitiés et des moitiés vers leur fusion, suivent les cases quand la largeur change."""

    question = property(lambda self: self._question())
    ECRAN = 1.2  # pixels par point de la figure, comme ``AxeGradue``
    COLONNE_MINIMUM = 92  # en pixels : en deçà, « [46, 108] » ne se lit plus entier à côté de son bouton
    BOUTON = 32  # la largeur, en pixels, du bouton ↙↘ ou × logé au bout du champ d'une liste

    def __init__(self, question):
        super().__init__()
        self._question, self.arbre, self.champs, self.boutons = weakref.ref(question), {"texte": question.racine()}, {}, {}
        politique = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        self.setSizePolicy(politique)
        self._construire()

    def sizeHint(self):
        return QSize(math.ceil(self.question.LARGEUR * self.ECRAN), self.height())

    def _feuilles(self, n=None):
        n = n or self.arbre
        return sum(map(self._feuilles, n["fils"])) if n.get("fils") else 1

    def _noeud(self, chemin):
        n = self.arbre
        for i in chemin:
            n = n["fils"][i]
        return n

    def _relever(self):
        """Les textes des champs recopiés dans ``arbre``, avant de le remanier ou de le rendre."""
        for (chemin, sorte), champ in self.champs.items():
            if chemin:
                self._noeud(chemin)[sorte] = champ.text().strip()
            elif sorte == "fusion":
                self.arbre["fusion"] = champ.text().strip()

    def _construire(self):
        """Un champ par case de ``arbre``, et le bouton de chaque liste : à refaire à chaque séparation ou retrait."""
        for w in [*self.champs.values(), *self.boutons.values()]:
            w.deleteLater()
        self.champs, self.boutons = {}, {}
        q = self.question
        racine = QLineEdit(q.racine(), self)
        racine.setReadOnly(True)
        racine.setStyleSheet("QLineEdit { background: #e8e8e8; }")
        self.champs[(), "texte"] = racine
        for chemin, sorte, texte in q.cases_de(self.arbre):
            self.champs[chemin, sorte] = QLineEdit(texte, self)
        for (chemin, sorte), champ in self.champs.items():
            champ.setAlignment(Qt.AlignmentFlag.AlignCenter)
            champ.show()
            if sorte != "texte":
                continue
            separee = bool(self._noeud(chemin).get("fils"))
            bouton = self.boutons[chemin] = BoutonGlyphe(self)
            bouton.setText("×" if separee else "↙↘")
            bouton.setToolTip("Retirer cette séparation" if separee else "Séparer cette liste en deux")
            bouton.setAutoRaise(True)
            bouton.setCursor(Qt.CursorShape.PointingHandCursor)
            bouton.clicked.connect(functools.partial(self._retirer if separee else self._separer, chemin))
            champ.setTextMargins(0, 0, self.BOUTON, 0)
            bouton.show()
        for champ in self.champs.values():
            champ.textChanged.connect(self._actualiser)
        figure = q.places(self.arbre)
        hauteur = math.ceil(figure["hauteur"] * self._vertical())
        self.setFixedHeight(hauteur)
        self.setMinimumWidth(self._feuilles() * self.COLONNE_MINIMUM)
        self.updateGeometry()
        self._placer()
        self._actualiser()

    def _vertical(self):
        """Pixels par point de la figure en hauteur : un champ doit tenir sa ligne, quel que soit le corps de l'écran."""
        return max(self.ECRAN, (QFontMetrics(self.font()).height() + 10) / self.question.HAUTEUR)

    def _place(self, case, figure, fx, fy):
        x, y, l, h = figure["cases"][case]
        return QRect(round(x * fx), round(y * fy), round(l * fx), round(h * fy))

    def _echelles(self):
        q = self.question
        largeur = max(self.width(), self.minimumWidth())
        fx = min(self.ECRAN, largeur / q.LARGEUR)
        plafond = (QFontMetrics(self.font()).horizontalAdvance(q.racine()) + self.BOUTON + 16) / fx  # le corps de l'écran
        return q.places(self.arbre, largeur / fx, plafond), fx, self._vertical()

    def _placer(self):
        figure, fx, fy = self._echelles()
        for case, champ in self.champs.items():
            champ.setGeometry(self._place(case, figure, fx, fy))
        for chemin, bouton in self.boutons.items():
            r = self.champs[chemin, "texte"].geometry()
            bouton.setGeometry(r.right() - self.BOUTON - 1, r.top() + 2, self.BOUTON, r.height() - 4)
        self.update()

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self._placer()

    def _actualiser(self):
        """Le × d'une séparation n'est actif que si toutes ses cases sont vides."""
        self._relever()
        q = self.question
        for chemin, bouton in self.boutons.items():
            n = self._noeud(chemin)
            if not n.get("fils"):
                continue
            vide = not any(t for c, _, t in q.cases_de(n)) and not n.get("fusion")
            bouton.setEnabled(vide)
            bouton.setToolTip("Retirer cette séparation" if vide else "Videz d'abord les cases du dessous")

    def _separer(self, chemin):
        self._relever()
        n = self._noeud(chemin)
        n["fils"], n["fusion"] = [{"texte": ""}, {"texte": ""}], ""
        self._construire()
        self.champs[chemin + (0,), "texte"].setFocus()

    def _retirer(self, chemin):
        self._relever()
        n = self._noeud(chemin)
        n.pop("fils", None), n.pop("fusion", None)
        self._construire()

    def saisie(self):
        self._relever()
        return copier(self.arbre) if self.arbre.get("fils") else None

    def poser(self, valeur):
        self.arbre = copier(valeur) if valeur else {}
        self.arbre["texte"] = self.question.racine()  # donnée, quoi qu'en dise une copie
        self._construire()

    def paintEvent(self, _):
        figure, fx, fy = self._echelles()
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        couleur = self.palette().color(QPalette.ColorRole.WindowText)
        peintre.setPen(QPen(couleur, 1.2))
        peintre.setBrush(couleur)
        for x1, y1, x2, y2 in figure["fleches"]:
            a, b = QPointF(x1 * fx, y1 * fy + 1), QPointF(x2 * fx, y2 * fy - 1)
            sens = b - a
            u = sens / (math.hypot(sens.x(), sens.y()) or 1)
            base = b - u * 7
            peintre.drawLine(a, base)
            peintre.drawPolygon(QPolygonF([b, base + QPointF(-u.y(), u.x()) * 3, base - QPointF(-u.y(), u.x()) * 3]))


class SurimpressionDeroulement(Surimpression):
    """La correction à la main d'un ``deroulement``, case par case : juste entourée de vert ; fausse barrée de rouge et
    ce qu'elle attendait écrit en rouge, à sa suite s'il y a la place dans la case, au-dessus sinon ; une case de trop
    (une séparation qui n'avait pas lieu d'être), ou qui suit une liste illisible, barrée seule. En seconde chance, les
    ratures seules. Ce que l'élève n'a pas construit est dit sous la question (``noyau.Deroulement._attendu``)."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        arbre = q.arbre
        saisie = arbre.saisie() or {"texte": q.racine()}
        attendus = q.attendus(saisie)
        for case, attendu in attendus.items():
            champ = arbre.champs.get(case)
            if champ is None:
                continue
            texte = champ.text().strip()
            juste = q.egal(texte, attendu)
            if juste and self.fausses is not None:
                continue
            cadre, metrique = self.cadre(champ), QFontMetricsF(champ.font())
            ligne = cadre.top() + (cadre.height() - metrique.height()) / 2 + metrique.ascent()
            largeur = min(metrique.horizontalAdvance(texte), cadre.width() - 24)
            debut = cadre.center().x() - largeur / 2 - (ArbreDeroulement.BOUTON / 2 if case[1] == "texte" else 0)  # le bouton ↙↘ décale le texte
            if texte and juste:
                self.entourer(peintre, QRectF(debut, ligne - metrique.ascent() * 0.8, largeur, metrique.ascent()))
                continue
            if texte:
                self.raturer(peintre, debut, debut + largeur, ligne + metrique.tightBoundingRect(texte).center().y())
            if self.fausses is not None or attendu is TROP or attendu is ILLISIBLE:
                continue
            taille = QFontInfo(champ.font()).pixelSize()
            ecrit = QFontMetricsF(self.main(taille)).horizontalAdvance(attendu)
            if not texte:
                self.ecrire(peintre, QPointF(cadre.center().x() - ecrit / 2, ligne), attendu, taille)
            elif debut + largeur + 8 + ecrit <= cadre.right() - 20:
                self.ecrire(peintre, QPointF(debut + largeur + 8, ligne), attendu, taille)
            else:  # juste au-dessus de la case, centré : la liste raturée se lit encore dessous
                self.ecrire(peintre, QPointF(cadre.center().x() - ecrit / 2, cadre.top() - 2), attendu, taille)


class Deroulement(Annotee, noyau.Deroulement, Question):

    def _corps(self, d):
        self.arbre, self.surimpression = ArbreDeroulement(self), SurimpressionDeroulement(self)
        d.addWidget(Texte("*Cliquez sur ↙↘ pour séparer une liste en deux : la case de leur fusion paraît dessous, et × retire "
                          "une séparation vide. Une case remplie en trop annule une case juste.*", inline=True))
        d.addWidget(self.arbre)
        self.entrees.append(self.arbre)

    def _lire(self):
        return self.arbre.saisie()

    def _ecrire(self, valeur):
        self.arbre.poser(valeur)


class ToilePasAPas(ToileGraphe):
    """Le graphe d'un ``pas_a_pas`` : les routes et leurs longueurs ; un clic entoure une ville (à ③, l'ajoute au
    chemin) ; sous chaque ville, deux champs, « distance à A » à gauche et « en venant de » à droite. Elle montre l'état
    en cours, modifiable, ou celui d'une étape soumise relue (``PasAPas.vue``). Taille fixe, sans mise à l'échelle :
    les champs, des widgets, ne se réduiraient pas avec le dessin."""

    CHAMP = 38  # largeur d'un champ, en pixels

    def __init__(self, question):
        QWidget.__init__(self)
        self._question, self.aretes, self.chemin, self.teintes = weakref.ref(question), [], [], {}
        self.depart = self.souris = self.choisie = self._fond = None
        self.sommets, self.champs, self.entourees = question.sommets, {}, []
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        for s in self.sommets:
            paire = []
            for cle, bulle in (("distance", f"Distance à {question.depart}"), ("venant_de", "En venant de")):
                champ = QLineEdit(self)
                champ.setFixedWidth(self.CHAMP)
                champ.setAlignment(Qt.AlignmentFlag.AlignCenter)
                champ.setToolTip(bulle)
                champ.setPlaceholderText("dist." if cle == "distance" else "de")
                champ.textEdited.connect(lambda texte, nom=str(s.nom), cle=cle: question._saisir(nom, cle, texte))
                champ.move(max(0, int(s.x - self.CHAMP - 1 + (self.CHAMP + 2) * len(paire))), int(s.y + RAYON + 6))
                paire.append(champ)
            self.champs[str(s.nom)] = paire
        haut = self.champs[str(self.sommets[0].nom)][0].sizeHint().height() if self.sommets else 0
        self.naturelle = QSize(int(max([s.x for s in self.sommets] or [0]) + self.CHAMP + 8),
                               int(max([s.y for s in self.sommets] or [0]) + RAYON + 6 + haut + 4))
        self.setFixedSize(self.naturelle)

    def _echelle(self):
        return 1

    def montrer(self, etat, lecture):
        """``etat`` dans les champs (sans toucher un champ déjà juste : le curseur de l'élève y resterait), en lecture
        seule si ``lecture``."""
        self.entourees, self.chemin = list(etat["entourees"]), list(etat["chemin"])
        for nom, (distance, venant) in self.champs.items():
            for champ, texte in ((distance, etat["distance"].get(nom, "")), (venant, etat["venant_de"].get(nom, ""))):
                if champ.text() != str(texte):
                    champ.setText(str(texte))
                champ.setReadOnly(lecture)
        self.update()

    def paintEvent(self, _):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        for a in self.question.decor:
            self._peindre_arete(peintre, (a.source, a.cible, a.etiquette), QColor("#78909c"))
        bleu = QColor("#1e88e5")
        peintre.setPen(QPen(bleu, 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        for a, b in zip(self.chemin, self.chemin[1:]):  # la remontée ③, de centre à centre sous les sommets
            a, b = self._sommet(a), self._sommet(b)
            if a and b:
                peintre.drawLine(QPointF(a.x, a.y), QPointF(b.x, b.y))
        for s in self.sommets:
            self._peindre_sommet(peintre, s)
            if str(s.nom) in self.entourees:  # le rond de l'élève, en bleu comme ses autres gestes
                peintre.setPen(QPen(bleu, 3))
                peintre.setBrush(Qt.BrushStyle.NoBrush)
                peintre.drawEllipse(QPointF(s.x, s.y), RAYON + 5, RAYON + 5)

    def mousePressEvent(self, evenement):
        nom = self._sous(evenement.position())
        if self.isEnabled() and nom is not None:
            self.question._cliquer(str(nom))

    def mouseReleaseEvent(self, evenement):
        pass

    def keyPressEvent(self, evenement):
        if evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace) and self.chemin:
            self.question._cliquer(self.chemin[-1])  # à ③, un clic sur la dernière ville du chemin la retire
        else:
            QWidget.keyPressEvent(self, evenement)


class AlgorithmePasAPas(QWidget):
    """L'algorithme à gauche du graphe, une ligne par instruction, et la flèche bleue sur l'étape en cours, comme dans un
    débogueur (demande de l'utilisateur, 07/10/2026)."""

    LARGEUR = 320  # la colonne du texte

    def __init__(self, lignes):
        super().__init__()
        grille = QGridLayout(self)
        grille.setContentsMargins(0, 0, 0, 0)
        grille.setColumnStretch(1, 1)
        self.fleches, self.textes, self.reperes = [], [], [r for r, _ in lignes]
        for i, (repere, texte) in enumerate(lignes):
            fleche, ligne = QLabel(), QLabel(texte)
            fleche.setFixedWidth(22)
            fleche.setStyleSheet("color: #1e88e5; font-weight: bold;")
            ligne.setWordWrap(True)
            ligne.setContentsMargins(18 if repere in ("a", "b") else 0, 0, 0, 0)  # a) et b) sous ②
            # largeur fixe et hauteur de la ligne en GRAS (celle de la flèche) : dans la rangée à côté du graphe, la
            # hauteur selon la largeur d'un texte qui passe à la ligne n'est pas demandée, et le texte était coupé
            ligne.setFixedWidth(self.LARGEUR)
            gras = ligne.font()
            gras.setBold(True)
            hauteur = QFontMetrics(gras).boundingRect(QRect(0, 0, self.LARGEUR - ligne.contentsMargins().left(), 10_000),
                                                       Qt.TextFlag.TextWordWrap, texte).height()
            ligne.setMinimumHeight(hauteur)
            grille.addWidget(fleche, i, 0, Qt.AlignmentFlag.AlignTop)
            grille.addWidget(ligne, i, 1)
            self.fleches.append(fleche)
            self.textes.append(ligne)

    def pointer(self, repere):
        """La flèche sur la ligne de ``repere`` (aucune si ``None`` : la question est close)."""
        for r, fleche, ligne in zip(self.reperes, self.fleches, self.textes):
            fleche.setText("➜" if r == repere and repere else "")
            ligne.setStyleSheet("font-weight: bold;" if r == repere and repere else "")


class SurimpressionPasAPas(Surimpression):
    """La correction à la main d'une étape soumise, relue par ◀ : ce qu'elle avait de faux, sur ce que l'élève avait
    soumis. Un champ faux barré, ce qu'il attendait écrit en rouge à sa suite ; une ville entourée à tort barrée, une
    oubliée entourée de vert ; à ③, le chemin attendu en vert pointillé. Rien sur le juste : chaque étape ne change que
    quelques villes, entourer tout le reste noierait la correction."""

    def paintEvent(self, evenement):
        q, peintre = self.question, self.peintre()
        if q.vue is None:
            return
        toile, attendu = q.toile, q._normal(q.etapes()[q.vue]["etat"])
        donne = q._normal(q._etat_saisie()["etapes"][q.vue]["etat"])
        fautes, coin = q.fautes(q.vue, donne), self.cadre(toile).topLeft()

        def centre(nom):
            s = toile._sommet(nom)
            return coin + QPointF(s.x, s.y)

        if fautes.get("chemin"):
            peintre.setPen(QPen(self.VERT, 2.5, Qt.PenStyle.DashLine, Qt.PenCapStyle.RoundCap))
            for a, b in zip(attendu["chemin"], attendu["chemin"][1:]):
                peintre.drawLine(centre(a), centre(b))
        if fautes.get("entourees"):
            r = RAYON + 5
            for nom in set(attendu["entourees"]) - set(donne["entourees"]):
                self.entourer(peintre, QRectF(centre(nom) - QPointF(r, r), QSizeF(2 * r, 2 * r)), marge=(3, 3))
            self.stylo(peintre, self.ROUGE)
            for nom in set(donne["entourees"]) - set(attendu["entourees"]):
                peintre.drawLine(centre(nom) + QPointF(-r, r * 0.8), centre(nom) + QPointF(r, -r * 0.8))
        for nom in fautes.get("villes", []):
            for champ, cle in zip(toile.champs.get(nom, ()), ("distance", "venant_de")):
                juste = attendu[cle].get(nom) == donne[cle].get(nom)
                if not juste:
                    self.corriger_champ(peintre, champ, champ.text(), False, str(attendu[cle].get(nom, "")))


class PasAPas(Annotee, noyau.PasAPas, Question):
    """Le widget d'un ``pas_a_pas`` : l'algorithme et sa flèche à gauche, le graphe à droite, sous eux ◀ ▶ pour relire les
    étapes soumises (leur correction tracée, rien de modifiable) ; « Soumettre l'étape » est le bouton de la question. La
    saisie est celle du noyau (``_valeur``), que la toile affiche et que chaque geste modifie : les étapes passées n'ont
    pas de widgets, une saisie lue dans les champs n'en serait que la moitié."""

    oriente, vue, correction_montree = False, None, False  # ``vue`` : le rang de l'étape relue, ``None`` pour l'étape en cours

    def _corps(self, d):
        self.surimpression, self.toile = SurimpressionPasAPas(self), ToilePasAPas(self)
        self.algorithme_vu = AlgorithmePasAPas(self.lignes())
        d.addWidget(Texte(dire(f"*Cliquez une ville pour l'entourer ; un second clic retire un entourage posé à cette "
                               f"étape. Sous chaque ville : à gauche sa distance à {self.depart}, à droite « en venant "
                               f"de ». À ③, cliquez les villes du chemin, de {self.arrivee} à {self.depart}.*"), inline=True))
        ligne = QHBoxLayout()
        ligne.addWidget(self.algorithme_vu, 0, Qt.AlignmentFlag.AlignTop)
        ligne.addWidget(self.toile, 0, Qt.AlignmentFlag.AlignTop)
        ligne.addStretch()
        d.addLayout(ligne)
        navigation = QHBoxLayout()
        self.precedente, self.suivante, self.ou_etape = QPushButton("◀"), QPushButton("▶"), QLabel()
        self.precedente.setToolTip("Relire l'étape précédente et sa correction")
        self.suivante.setToolTip("Étape suivante")
        self.precedente.clicked.connect(lambda: self.relire(-1))
        self.suivante.clicked.connect(lambda: self.relire(1))
        for w in (self.precedente, self.suivante, self.ou_etape):
            navigation.addWidget(w)
        navigation.addStretch()
        d.addLayout(navigation)
        self.entrees.append(self.toile)

    def _batir(self):
        super()._batir()
        if not self.sous_questions:
            self.bouton_soumettre.setText("Soumettre l'étape")
            self.bouton_soumettre.REFERENCE = "Soumettre l'étape"  # plus long que la largeur commune des boutons
            self.nets = (*self.nets, self.precedente, self.suivante)  # relire une étape, la question soumise et voilée
            for b in (self.precedente, self.suivante):
                b.installEventFilter(self)

    # -- les gestes de l'élève, sur l'état en cours

    def _en_cours(self):
        """L'état modifiable, ou ``None`` : une étape relue, la question close ou pas encore posée."""
        if self.vue is not None or self.fermee or not self.actif:
            return None
        if self._valeur is None:
            self._valeur = self._etat_saisie({})
        return self._valeur["en_cours"]

    def _cliquer(self, nom):
        etat, k = self._en_cours(), self.etape()
        if etat is None or k >= len(self.etapes()):
            return
        if self.etapes()[k]["repere"] == "③":  # le chemin : la ville au bout, ou la dernière retirée
            chemin = etat.setdefault("chemin", [])
            if chemin and chemin[-1] == nom:
                chemin.pop()
            else:
                chemin.append(nom)
        elif nom in etat["entourees"]:  # retiré seulement s'il est de cette étape : avant, il était dans l'état de départ
            if k == 0 or nom not in self.etapes()[k - 1]["etat"]["entourees"]:
                etat["entourees"].remove(nom)
        else:
            etat["entourees"].append(nom)
        self._rafraichir()

    def _saisir(self, nom, cle, texte):
        etat = self._en_cours()
        if etat is not None:
            etat.setdefault(cle, {})[nom] = texte.strip()

    # -- l'affichage

    def relire(self, sens):
        """◀ ▶ : une étape soumise relue, avec sa correction ; au-delà de la dernière soumise, l'étape en cours. Rien n'est
        modifié dans la saisie."""
        faites = self.etape()
        rang = (faites if self.vue is None else self.vue) + sens
        self.vue = None if rang >= faites else max(0, rang)
        self._annoter(self.correction_montree)

    def _annoter(self, montree, fausses=None):
        self.correction_montree = montree  # la correction de la question, montrée ou non (``Annotee``) ; une étape relue a la sienne
        super()._annoter(montree or self.vue is not None, fausses)
        self._rafraichir()

    def _ecrire(self, valeur):
        super()._ecrire(valeur)
        self.vue = None
        self._rafraichir()

    def mettre_a_jour(self):
        super().mettre_a_jour()
        self._rafraichir()

    def _rafraichir(self):
        s, etapes = self._etat_saisie(), self.etapes()
        k, n = len(s["etapes"]), len(etapes)
        if self.vue is not None:
            e = s["etapes"][self.vue]
            self.toile.montrer(self._normal(e["etat"]) | {"distance": e["etat"].get("distance") or {},
                                                          "venant_de": e["etat"].get("venant_de") or {}}, True)
            verdict = ("juste" if e.get("essais", 1) == 1 else "juste au second essai") if e.get("juste") else \
                "fausse : corrigée en rouge et en vert"
            self.ou_etape.setText(f"Étape {self.vue + 1} sur {n} (relue) : {verdict}.")
            self.algorithme_vu.pointer(etapes[self.vue]["repere"])
        else:
            self.toile.montrer(self._normal(s["en_cours"]) | {"distance": s["en_cours"].get("distance") or {},
                                                              "venant_de": s["en_cours"].get("venant_de") or {}},
                               self.fermee or not self.actif)
            justes = sum(bool(e.get("juste")) for e in s["etapes"])
            self.ou_etape.setText(f"Étapes justes : {justes} sur {n}." if k >= n or self.fermee else
                                  f"Étape {k + 1} sur {n}" + (" : seconde chance." if s["seconde"] else "."))
            self.algorithme_vu.pointer(None if k >= n or self.fermee else etapes[k]["repere"])
        self.precedente.setEnabled(k > 0 and self.vue != 0)
        self.suivante.setEnabled(self.vue is not None)


class Personnalise(noyau.Personnalise, Question):
    """Le widget écrit par le professeur (voir ``noyau.Personnalise``) : son code est exécuté ici, avec pour noms de
    départ ceux de ce module (les classes Qt, ``Texte``, ``hauteur``…)."""

    def _corps(self, d):
        self.message = Texte()
        self.message.setStyleSheet("QTextBrowser { background: transparent; color: #c0392b; }")
        d.addWidget(self.message)
        try:
            espace = dict(globals())
            exec(compile(self.widget, f"<widget {self.id}>", "exec"), espace)  # noqa: S102 - c'est le principe : le code du professeur
            absentes = [nom for nom in ("corps", "lire", "ecrire", "corriger") if not callable(espace.get(nom))]
            if absentes:
                raise NameError("fonctions absentes : " + ", ".join(absentes))
            self.fonctions = espace
        except Exception as exc:  # noqa: BLE001 - n'importe quelle erreur du code du professeur
            self._casser("widget", exc)
            return
        self._appeler("corps", None, d)

    def _casser(self, quoi, exc):
        super()._casser(quoi, exc)
        self.message.definir(f"**Question en panne** : {self.panne}\n\nSignalez-la : elle sera corrigée à la main.")

    def _lire(self):
        return self._appeler("lire", None)

    def _ecrire(self, valeur):
        self._appeler("ecrire", None, valeur)


class Groupe(noyau.Groupe, Question):

    def _corps(self, d):
        for sq in self.sous_questions:
            d.addWidget(sq)

    def numeroter(self, numero=None):
        """Le barème d'une sous-question entre parenthèses : le détail du total, pas des points en plus."""
        super().numeroter(numero)
        for sq in self.sous_questions:
            sq.parentheses = True
            sq.afficher_bareme()


class Banque(noyau.Banque, QWidget):
    """Affichée, la banque montre ses questions corrigées."""

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)
        self.corrigee = False
        d = QVBoxLayout(self)
        d.addWidget(Texte(f"# {self.matiere}\n\n{self.niveau} {self.theme}".rstrip()))
        d.addWidget(defilant(self.questions))
        self.resize(900, 800)

    def showEvent(self, evenement):
        """Affichée, la banque montre ses questions corrigées (une seule fois : ce n'est pas son état enregistré)."""
        if not self.corrigee:
            self.corrigee = True
            for q in self.questions:
                q.presenter_corrige()
        super().showEvent(evenement)


class Paresse(paresse.Paresse):
    """Seules les questions à moins d'un écran de la vue sont remises en page, et une question construite sous
    ``differee`` se bâtit en entrant dans la vue (``qtpy6.paresse``) : un redimensionnement ne relit plus que leurs
    textes, pas les 684 d'un sujet de 85 questions (mesuré hors écran sur la révision NSI Terminale : 20
    redimensionnements, 968 → 480 ms ; 40 crans de molette, 150 → 220 ms, le prix des réveils). Choix, pièges et tests :
    ``Notes/QCM - Réactivité du lecteur.md``."""

    def minuteries(self, questions):
        # un tableau recalcule ses lignes par sa minuterie ; une question de type tableau EST un Tableau : elle compte.
        # Une frise n'a ni grille ni minuterie : l'AttributeError levée ici, sous un appel de Qt, faisait planter PySide
        return [(t.hauteurs, t._ajuster) for q in questions for t in [q, *q.findChildren(Tableau)]
                if isinstance(t, Tableau) and "hauteurs" in vars(t)]


def defilant(widgets):
    """Une zone défilante qui empile ``widgets``."""
    zone, contenu = ZoneDefilante(), QWidget(objectName="contenu")  # dans le navigateur, seule la bande qui entre est repeinte
    zone.setWidgetResizable(True)
    # par la feuille de style, pas par setFont : un widget qui a la sienne (Texte, listes, tableaux) n'hérite pas
    # de la police de son parent ; la taille seule, la famille et le gras de chacun restent les siens. Le fond aussi :
    # Breeze peint le viewport au gris de la fenêtre, plus sombre que le fond du sujet qu'on voit autour (séparateur
    # du cours, l'utilisateur, 29/09/2026) ; une feuille de style passe devant le thème
    contenu.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
    empile = QVBoxLayout(contenu)
    for w in widgets:
        empile.addWidget(w)
    empile.addStretch()
    zone.setWidget(contenu)
    # la barre verticale, quand elle paraît, tient lieu de marge droite (l'utilisateur, 03/10/2026)
    marges = empile.contentsMargins()
    zone.verticalScrollBar().rangeChanged.connect(
        lambda _, fin: empile.setContentsMargins(marges.left(), marges.top(), 0 if fin else marges.right(), marges.bottom()))
    # posée APRÈS que tout y est rangé : chaque widget rangé sous une feuille de style la repropage à tout son sous-arbre
    # (python_tp, 27 sections : 1,52 → 1,10 s en natif, 4,0 → 3,5 s dans le navigateur, écran identique, 02/10/2026)
    contenu.setStyleSheet(f"QWidget {{ font-size: {TAILLE_POLICE}pt; }} QWidget#contenu {{ background: {fond_sujet().name()}; }}")
    tactile.defiler_au_doigt(zone)  # au doigt, la page défile comme partout ailleurs sur un téléphone
    Paresse(zone, [q for q in contenu.findChildren(Question) if not isinstance(q.parentWidget(), Question)])
    return zone


def encadre(markdown):
    """Les consignes du sujet dans le cadre vert des cours du professeur (fond et bordure relevés dans « Les réseaux
    sociaux.docx ») : en tête de la zone qui défile, elles s'effacent de la vue dès que l'élève descend aux questions."""
    cadre = QFrame(objectName="consignes")
    cadre.setStyleSheet("QFrame#consignes { background: #eefae6; border: 1px solid #6b934e; }")
    d = QVBoxLayout(cadre)
    d.setContentsMargins(10, 8, 10, 8)
    d.addWidget(Texte(markdown))
    return cadre


class Section(noyau.Section, QWidget):
    """Son titre et ses consignes se voilent comme ses questions une fois toutes traitées ou soumises : le voile des
    traitées tant qu'elles ne sont pas toutes soumises (demande de l'utilisateur, 27/09/2026). Posé, comme celui d'une
    question, sur le contenu de la zone défilante, de toute sa largeur, jusqu'à la première question."""

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)
        d = QVBoxLayout(self)
        self.entete = [Texte(texte) for texte in (self.partie and f"# {self.partie}", self.titre and f"## {self.titre}", self.consignes) if texte]
        for w in self.entete:
            d.addWidget(w)
        self.feuilles = [f for q in self.questions if isinstance(q, Question) for f in q.feuilles()]
        for q in self.questions:
            if isinstance(q, Question):
                d.addWidget(q)
        self.voile = Voile(self) if self.entete and self.feuilles else None
        if self.voile:
            for f in self.feuilles:
                f.changee.connect(self._poser_voile)
            self.installEventFilter(self)

    def eventFilter(self, objet, evenement):
        if evenement.type() in (QEvent.Type.Move, QEvent.Type.Resize, QEvent.Type.Show, QEvent.Type.ParentChange):
            self._poser_voile()
        return False

    def _poser_voile(self):
        v, hote = vars(self).get("voile"), self.parentWidget()
        if not v or hote is None:
            return
        if v.parentWidget() is not hote:
            v.setParent(hote)
        premiere = next((w for w in self.children() if isinstance(w, Question) and not w.isHidden()), None)
        bas = premiere.y() if premiere else self.height()
        v.setGeometry(0, self.y(), hote.width(), bas)
        v.teinter(Voile.niveau(self.feuilles), self.isVisible())
        v.raise_()


COULEURS = {"vert": "#92d050", "bleu": "#00b0f0", "rouge": "#ff0000", "or": "#ffc000"}


def barre(intitule, couleur):
    """Une jauge de 0 à 100 %, son intitulé écrit dedans : ce qu'elle mesure se lit sans légende. Fine : la police de
    l'interface, et la hauteur de son texte, bordure comprise — deux empilées font celle d'un bouton (l'utilisateur, 02/10/2026)."""
    b = QProgressBar()
    b.setRange(0, 100)
    b.setFormat(intitule)
    b.setAlignment(Qt.AlignmentFlag.AlignCenter)
    police = QApplication.font()
    police.setItalic(True)
    b.setFont(police)
    b.setFixedHeight(QFontMetrics(police).height() + 2)
    colorer(b, couleur)
    return b


def colorer(barre, couleur):
    """Remplit ``barre`` de la couleur nommée ; sans effet si c'est déjà la sienne (le chronomètre appelle chaque seconde)."""
    if barre.property("couleur") != couleur:
        barre.setProperty("couleur", couleur)
        # l'arrondi des boutons voisins, 2 px en Fusion, le style du lecteur ici comme dans le navigateur (demande de l'utilisateur, 27/09/2026)
        barre.setStyleSheet("QProgressBar { border: 1px solid #a0a0a0; border-radius: 2px; background: #f2f2f2; color: #707070; }"
                            f"QProgressBar::chunk {{ background: {COULEURS[couleur]}; border-radius: 1px; }}")


class Manuscrit(QWidget):
    """L'appréciation écrite à la main — tablette graphique, souris en secours — par-dessus le champ tapé, qu'il
    enveloppe : dès qu'il y a de l'encre, elle prime et le texte se cache ; toute effacée (clic droit), il revient.
    Les traits (``noyau.Paquet.appreciation_encre``) sont en fractions de la HAUTEUR du champ, x compris : l'aspect de
    l'écriture ne dépend pas de la fenêtre, une écriture plus large que le champ se réduit sans se déformer. Le même
    peintre sert à l'élève, lecteur natif ou web (demande de l'utilisateur, 04/10/2026, « je veux qu'elle fasse
    authentique ») ; seul le professeur (``professeur``) écrit ou efface."""

    modifiee = Signal()  # un trait posé ou effacé : la copie est à enregistrer
    ENCRE = "#c0392b"  # le rouge du cadre de la note
    POINTE = 0.035  # épaisseur d'un trait à pleine pression, en fraction de la hauteur
    SEUIL = 0.01  # deux points plus proches que 1 % de la hauteur sont fondus : l'encre reste légère
    TABLETTE = (QEvent.Type.TabletPress, QEvent.Type.TabletMove, QEvent.Type.TabletRelease)

    def __init__(self, champ):
        super().__init__()
        self.champ, self.traits, self.en_cours, self.professeur = champ, [], [], False
        disposition = QVBoxLayout(self)
        disposition.setContentsMargins(0, 0, 0, 0)
        disposition.addWidget(champ)
        self.setFixedHeight(champ.minimumHeight())
        champ.viewport().installEventFilter(self)  # le stylet écrit par-dessus le champ tapé, qui l'ignorerait

    def poser(self, traits):
        """Les traits de la copie : s'il y en a, ils remplacent le texte tapé, qui se cache ; effacés, il revient."""
        self.traits = traits
        self.champ.setVisible(not traits)
        self.update()

    def tracer(self, points):
        """Un trait ajouté, points ``(x, y, pression)`` en pixels : rangé en fractions de la hauteur, arrondi (trois
        décimales, deux pour la pression, points plus proches que ``SEUIL`` fondus)."""
        h, trait, precedent = self.height(), [], None
        for x, y, pression in points:
            u = (round(x / h, 3), round(y / h, 3))
            if precedent and abs(u[0] - precedent[0]) + abs(u[1] - precedent[1]) < self.SEUIL:
                continue
            trait.append([u[0], u[1], round(pression, 2)])
            precedent = u
        if trait:
            self.traits.append(trait)
            self.poser(self.traits)
            self.modifiee.emit()

    def eventFilter(self, _, evenement):
        if evenement.type() in self.TABLETTE and self.professeur:
            self._stylet(evenement)
            return True
        return False

    def tabletEvent(self, evenement):  # le champ caché par l'encre : le stylet arrive directement ici
        if self.professeur:
            self._stylet(evenement)
            evenement.accept()

    def _stylet(self, evenement):
        point = self.mapFromGlobal(evenement.globalPosition().toPoint())
        self._point(evenement.type(), point.x(), point.y(), evenement.pressure() or 0.6)

    def mousePressEvent(self, evenement):
        self._point(QEvent.Type.TabletPress, evenement.position().x(), evenement.position().y(), 0.6)

    def mouseMoveEvent(self, evenement):
        self._point(QEvent.Type.TabletMove, evenement.position().x(), evenement.position().y(), 0.6)

    def mouseReleaseEvent(self, evenement):
        self._point(QEvent.Type.TabletRelease, evenement.position().x(), evenement.position().y(), 0.6)

    def _point(self, type_, x, y, pression):
        if not self.professeur or (type_ == QEvent.Type.TabletMove and not self.en_cours):
            return  # un survol du stylet sans appui, ou l'élève
        self.en_cours.append((x, y, pression))
        if type_ == QEvent.Type.TabletRelease:
            points, self.en_cours = self.en_cours, []
            self.tracer(points)
        self.update()

    def contextMenuEvent(self, evenement):
        if not (self.professeur and self.traits):
            return
        menu = QMenu(self)
        dernier, tout = menu.addAction("Effacer le dernier trait"), menu.addAction("Tout effacer")
        choix = menu.exec(evenement.globalPos())
        if choix is not None:
            self.poser(self.traits[:-1] if choix is dernier else [])
            self.modifiee.emit()

    def paintEvent(self, _):
        if not self.traits and not self.en_cours:
            return
        h = self.height()
        # x et y en fractions de la hauteur : l'échelle naturelle est h, réduite si l'écriture déborde du champ
        echelle = min(h, (self.width() - 4) / (max(x for t in self.traits for x, _, _ in t) or 1)) if self.traits else h
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        crayon = QPen(QColor(self.ENCRE), 1, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        for trait in self.traits:
            self._peindre(peintre, crayon, [(x * echelle, y * echelle, p) for x, y, p in trait], h)
        self._peindre(peintre, crayon, self.en_cours, h)

    def _peindre(self, peintre, crayon, points, hauteur):
        for (x1, y1, p1), (x2, y2, p2) in zip(points, points[1:] or points):
            crayon.setWidthF(max(1.0, self.POINTE * hauteur * (p1 + p2) / 2))
            peintre.setPen(crayon)
            peintre.drawLine(QPointF(x1, y1), QPointF(x2, y2))  # un point seul : le rond de la pointe


class Paquet(noyau.Paquet, QWidget):
    """Le widget du paquet : une entête (TOUS les boutons globaux, les jauges, le bilan) et le sujet, défilant sur toute
    la largeur, ou une question par écran, le titre et le visuel en tête. La logique est celle de ``noyau.Paquet``."""

    finie = Signal()  # l'épreuve vient de se terminer (bouton, fin du temps) : la copie est à enregistrer
    annotee = Signal()  # le professeur vient de changer la note ou l'appréciation : la copie est à enregistrer
    recommencee = Signal()  # « Nouvel essai » : le lecteur ouvre la copie de l'essai suivant (``nouvel_essai_suivant``)

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)

    chantier = None  # ouverte sous ``differee``, la construction en tâche de fond du reste de la copie

    @property
    def a_batir(self):
        """Les questions que le chantier reste à bâtir."""
        return self.chantier.reste if self.chantier else ()

    def _construire(self):
        self._noter()
        palette = self.palette()
        palette.setColor(self.backgroundRole(), fond_sujet())
        self.setPalette(palette)
        self.setAutoFillBackground(True)
        # Deux parties : une entête, une seule rangée (la navigation, les jauges, ce qui termine) et le bilan ; puis le
        # sujet, qui défile sur toute la largeur et commence comme la copie papier, par le titre, le sous-titre, le visuel
        # du thème et le cadre de la note (l'utilisateur, 02/10/2026 : dans l'entête, ils prenaient la place du sujet, et
        # il fallait une poignée pour les rogner ; 26/09 : la colonne de droite décentrait le titre).
        d = QVBoxLayout(self)
        d.setContentsMargins(0, 0, 0, 0)
        d.setSpacing(0)
        bandeau = QWidget()  # l'entête a son propre fond, celui de la barre de titre
        palette = bandeau.palette()
        fond_entete(palette)
        bandeau.setPalette(palette)
        bandeau.setAutoFillBackground(True)
        # La taille du sujet (``defilant``) ; tous en noir et en gras, sans fond ni contour, seul un gris léger marque le
        # bouton pressé ou enfoncé (« Cours ») ; « Rendre ma copie » n'a pas de rouge : sa fenêtre de confirmation suffit
        # contre l'erreur (l'utilisateur, 02/10/2026).
        bandeau.setStyleSheet(f"QPushButton {{ font-size: {TAILLE_POLICE}pt; font-weight: bold; color: black; border: none;"
                              " background: transparent; padding: 4px 8px; }"
                              "QPushButton:pressed, QPushButton:checked { background: rgba(0, 0, 0, 0.1); border-radius: 6px; }"
                              "QPushButton:disabled { color: #a0a0a0; }")
        entete = QVBoxLayout(bandeau)
        entete.setContentsMargins(9, 9, 9, 4)  # le trait tout de suite sous les boutons (l'utilisateur, 01/10/2026)
        entete.setSpacing(6)  # sans quoi les dispositions imbriquées héritent du 0 de ``d`` : boutons collés
        # Le titre et le visuel centrés ; le bilan de la copie rendue vient dessous, avant les consignes (``_cadre_note``).
        self.haut = QWidget()
        # pas plus haut que son contenu : le titre est Expanding, et l'en-tête prendrait sinon toute la hauteur libre
        self.haut.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        gauche = QVBoxLayout(self.haut)
        gauche.setContentsMargins(0, 0, 0, 0)
        titre = Texte(self.entete())
        bloc = titre.document().begin()
        while bloc.isValid():  # le sous-titre sous le titre, pas à la distance qui sépare deux paragraphes
            format_ = bloc.blockFormat()
            format_.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            if format_.headingLevel() in (1, 2):
                format_.setBottomMargin(0) if format_.headingLevel() == 1 else format_.setTopMargin(4)
            QTextCursor(bloc).setBlockFormat(format_)
            bloc = bloc.next()
        image = entete_harmonisee(titre.document(), QImage.fromData(self.medias[LOGO]) if LOGO in self.medias else None)
        gauche.addWidget(titre)
        if image:
            visuel = QLabel()
            visuel.setPixmap(image)
            gauche.addWidget(visuel, 0, Qt.AlignmentFlag.AlignHCenter)
        self.barre_temps, self.barre_avancement = barre("temps écoulé", "bleu"), barre("avancement réponses", "vert")
        self.barre_bonus = barre("bonus", "or") if self.feuilles_bonus else None
        mesure = QFontMetrics(self.barre_temps.font())
        for b, texte in ((self.barre_temps, "temps écoulé : 0 h 00 min 00 s"), (self.barre_avancement, "avancement réponses"),
                         (self.barre_bonus, "bonus")):  # un minimum fixe : le chronomètre ne fait pas bouger la rangée à chaque seconde
            if b is not None:
                b.setMinimumWidth(mesure.horizontalAdvance(texte) + 16)
        # Les jauges empilées, l'avancement au-dessus du temps et de même largeur : où l'on en est par rapport au temps se
        # lit d'un coup d'œil (l'utilisateur, 02/10/2026) ; à droite de l'avancement, le bonus, large comme sa part des questions.
        self.jauges = QWidget()
        jauges = QVBoxLayout(self.jauges)
        jauges.setContentsMargins(0, 0, 0, 0)
        jauges.setSpacing(1)
        avancement = QHBoxLayout()
        avancement.setSpacing(1)
        avancement.addWidget(self.barre_avancement, len(self.feuilles) - len(self.feuilles_bonus))
        if self.barre_bonus is not None:
            avancement.addWidget(self.barre_bonus, len(self.feuilles_bonus))
        jauges.addLayout(avancement)
        jauges.addWidget(self.barre_temps)
        # Deux gestes nommés par leur conséquence, et seulement ceux qui ont un sens dans CE sujet (demande de
        # l'utilisateur, 25/09/2026 : « Soumettre toutes les questions » et « Terminer » ne se distinguaient pas, et le
        # premier ne servait à rien sans seconde chance, le cas d'une évaluation sommative).
        self.bouton_tout = QPushButton("Corriger mes réponses")
        self.bouton_tout.setToolTip("Corrige toutes les questions encore ouvertes sans terminer l'épreuve : une réponse fausse "
                                    "peut être reprise, à points réduits, tant qu'il reste du temps.")
        self.bouton_tout.clicked.connect(self._corriger_tout)
        self.bouton_tout.setVisible(self.rejouable())
        self.bouton_terminer = QPushButton("Rendre ma copie")
        self.aide_terminer = ("Fin de l'épreuve : les questions encore ouvertes sont figées telles quelles, sans reprise possible"
                              + (", puis la note et la correction s'affichent." if self.corrigee() else
                                 ", puis la note et la correction s'afficheront à l'échéance." if self.correction else "."))
        self.bouton_terminer.setToolTip(self.aide_terminer)
        self.bouton_terminer.clicked.connect(self._rendre_copie)
        # une révision rendue se repasse en entier, d'autres valeurs tirées (l'utilisateur, 03/10/2026)
        self.bouton_essai = QPushButton("Nouvel essai")
        self.bouton_essai.setToolTip("Repasser toute l'épreuve, avec d'autres valeurs : cette copie est gardée telle quelle")
        self.bouton_essai.clicked.connect(self.recommencee)
        self.bouton_essai.hide()
        self.precedent, self.suivant = QPushButton("Précédent"), QPushButton("Suivant")
        self.prec_libre, self.suiv_libre = QPushButton("◀"), QPushButton("▶")  # l'icône seule (l'utilisateur, 02/10/2026)
        self.prec_libre.setToolTip("Question précédente non traitée ou à réessayer")
        self.suiv_libre.setToolTip("Question suivante non traitée ou à réessayer")
        self.precedent.clicked.connect(self._pas)
        self.suivant.clicked.connect(self._pas)
        self.prec_libre.clicked.connect(self._non_traitee)
        self.suiv_libre.clicked.connect(self._non_traitee)
        rangee = Rangee(6, elargir=True)  # passe à la ligne à la largeur d'un téléphone, au lieu d'imposer la sienne au sujet
        self.panneau_cours = None  # lu à la première ouverture (``_montrer_cours``)
        self.cours_en_mosaique = False  # vue du cours choisie par l'élève (onglets, ou l'un sous l'autre) : gardée quand le panneau est refait
        if self.acces_cours and self.cours:
            self.bouton_cours = QPushButton("Cours", checkable=True)
            self.bouton_cours.setToolTip("Ouvrir ou fermer le cours, à côté des questions")
            self.bouton_cours.toggled.connect(self._montrer_cours)
        # Chaque bouton à la largeur de son texte plus une même part de la place libre, texte centré : sans fond ni
        # contour, ce qui se voit est l'écart entre les textes, égal entre les boutons, et sa moitié au bord gauche et
        # avant les jauges (l'utilisateur, 02/10/2026, après des cases égales : les flèches y semblaient isolées et
        # « Rendre ma copie » collé aux jauges ; puis un écart entier avant les jauges). La part libre est DANS le bouton
        # (``elargir``), pas dans des ressorts entre eux : le gris du bouton pressé couvre l'écart (même jour, « plus
        # large, pour que la zone grise quand ils sont activés soit plus large »). Tous prennent la hauteur de la ligne.
        for w in (*([self.bouton_cours] if self.acces_cours and self.cours else []),
                  *((self.precedent, self.suivant) if self.affichage == "question" else ()), self.prec_libre, self.suiv_libre,
                  *([self.bouton_tout] if self.rejouable() else []), self.bouton_terminer,
                  *([self.bouton_essai] if self.nouvel_essai else [])):
            w.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            rangee.addWidget(w)
        rangee.addWidget(self.jauges)  # ``Maximum`` : ses barres extensibles la feraient prendre sa part de la place libre
        self.jauges.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        entete.addLayout(rangee)
        self.bilan = Texte()
        entete.addWidget(self.bilan)
        d.addWidget(bandeau)
        trait = QWidget()  # le bord de l'entête : un trait sombre d'un pixel (l'utilisateur, 01/10/2026)
        trait.setFixedHeight(1)
        palette = trait.palette()
        palette.setColor(trait.backgroundRole(), palette.color(QPalette.ColorRole.Dark))
        trait.setPalette(palette)
        trait.setAutoFillBackground(True)
        d.addWidget(trait)
        tete = [self.haut, self._cadre_note(), *([encadre(self.consignes)] if self.consignes else [])]  # en tête du sujet
        if self.affichage == "question":
            # Un écran n'est construit qu'à sa première visite (``_afficher_page``) : construire les 218 zones défilantes
            # d'un TP coûtait 2,5 s de plus à l'ouverture dans le navigateur, pour n'en montrer qu'une (mesuré le
            # 02/10/2026). Les questions des autres écrans attendent dans un conteneur caché, la fenêtre restant la
            # leur (``window()``) et aucune ne pouvant s'afficher seule.
            self.pile, self.ecrans, self.tete = QStackedWidget(), {}, tete
            self.attente = QWidget(self)
            self.attente.hide()
            for q in self.pages:
                q.setParent(self.attente)
            self._afficher_page(min(self.courante, len(self.pages) - 1))
            corps = self.pile
        else:
            self.defilement = corps = defilant([*tete, *self.sections])
            self.defilement.setFrameShape(QFrame.Shape.NoFrame)
        # Les questions à droite ; à gauche, ouverts sur demande, les questions épinglées au-dessus du cours (l'utilisateur,
        # 03/10/2026 : la table de correspondances de l'exercice 1 sous les yeux pendant toutes les conversions), les limites
        # déplaçables. La colonne de gauche n'est montrée que si elle a quelque chose (``_regler_gauche``).
        self.separation, self.gauche = QSplitter(Qt.Orientation.Horizontal), QSplitter(Qt.Orientation.Vertical)
        self.gauche.hide()
        self.separation.addWidget(self.gauche)
        self.separation.addWidget(corps)
        corps = self.separation
        self.epingles, self.epinglees = None, {}  # la zone des questions épinglées ; question → mention laissée à sa place
        for f in self.feuilles:
            f.epinglage.connect(lambda oui, f=f: self._epingler(f, oui))
        d.addWidget(corps, 1)
        if self.affichage != "question":
            self.descente = QPropertyAnimation(self.defilement.verticalScrollBar(), b"value", self, duration=DESCENTE_MS,
                                               easingCurve=QEasingCurve.Type.OutCubic)
            self.attente = QTimer(self, singleShot=True, timeout=self._descendre)
        self.resize(900, 800)
        super()._construire()
        # Ouverte sous ``differee``, la copie a rendu la main l'écran bâti (``Paresse.rafraichir``) : le reste se bâtit en
        # tâche de fond, par tranches de 20 ms entre deux événements de l'élève, et jamais pendant un défilement (la
        # première descente du bac sautait de 27 à 69 px au lieu de 8). Jusqu'au bout, les boutons qui parcourent toutes
        # les questions restent grisés (``_rafraichir_vue``) ; une question atteinte avant son tour se bâtit d'elle-même.
        self.chantier = paresse.Chantier(self, self.questions())
        self.chantier.fini.connect(self._rafraichir_vue)

    def _panneau_cours(self):
        """Les PDF du cours (``cours``), un onglet chacun, caché jusqu'au bouton « Cours », lus à sa première ouverture
        (``lire_cours``). Le texte s'y sélectionne et se copie ; dans le navigateur, qtpy6 les dessine par pdf.js dans un bloc
        de la page, dont la lecture ne compte pas comme une sortie sous ``anti_triche``, et que l'écran noir cache (paquet
        désactivé)."""
        from qtpy6.QtPdf import QPdfDocument  # noqa: PLC0415 - QtPdf n'est chargé que pour un sujet qui a un cours
        from qtpy6.QtPdfWidgets import QPdfView  # noqa: PLC0415

        onglets = QTabWidget(tabBarAutoHide=True, documentMode=True)
        # sans le trait que le style natif tire sous les onglets en mode document : le navigateur n'en a pas, et l'utilisateur
        # le préfère sans (08/10/2026 : « le rendu devrait etre identique en natif et sur le web »)
        onglets.tabBar().setDrawBase(False)
        # dessinés par une feuille de style, pas par le style (Fusion en natif comme dans le navigateur) : même rendu partout,
        # l'onglet choisi sur fond blanc comme la page qu'il montre (même demande), les autres du gris de la barre du lecteur :
        # transparents, ils prenaient le fond de la fenêtre, presque blanc dans le navigateur (08/10/2026 : « j'ai demande du
        # fond blanc uniqument pour l'onglet actif ! »)
        onglets.tabBar().setStyleSheet("QTabBar::tab { background: #dddddd; border: none; padding: 4px 12px;"
                                       " border-top-left-radius: 4px; border-top-right-radius: 4px; }"
                                       " QTabBar::tab:selected { background: white; }"
                                       " QTabBar::tab:hover:!selected { background: #eeeeee; }")
        onglets.tabBar().setFocusPolicy(Qt.FocusPolicy.NoFocus)  # sans le pointillé de focus, que Fusion seul dessine
        self.montres = self.masques_cours()
        limites = self.cours_pages if isinstance(self.cours_pages, list) else [self.cours_pages] * len(self.cours)
        for cours, zones, limite in zip(self.cours, self.montres, limites):
            octets = self.lire_cours(cours)
            if octets is None:
                onglets.addTab(QLabel(f"Cours introuvable : {Path(cours).name}", alignment=Qt.AlignmentFlag.AlignCenter),
                               Path(cours).stem)
                continue
            vue = QPdfView()
            vue.setPageMode(QPdfView.PageMode.MultiPage)
            vue.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            vue.setPageLimit(limite)  # pas au-delà du cours vu en classe (qtpy6)
            vue.setDocumentMargins(QMargins())  # la page à pleine largeur, seul l'écart entre pages reste (l'utilisateur, 29/09/2026)
            if hasattr(vue, "verticalScrollBar"):  # sur ordinateur ; le pdf.js du navigateur a la barre et le doigt de celui-ci
                BarreParDessus(vue)
                tactile.defiler_au_doigt(vue)  # sinon le doigt y sélectionne le texte, comme la souris
            # pas enfant de la vue : détruit pendant la sienne, le document qui se ferme prévenait une vue à moitié détruite
            # (plantage à la sortie de Python, QAbstractScrollArea::viewport, pile relevée sous gdb le 05/10/2026)
            document = QPdfDocument(onglets)
            tampon = QBuffer(document)  # lu au fil des pages : il vit aussi longtemps que le document
            tampon.setData(QByteArray(octets))
            tampon.open(QBuffer.OpenModeFlag.ReadOnly)
            document.load(tampon)
            vue.setDocument(document)
            masques = {}  # la réponse d'une question ouverte, en pavés (qtpy6 : setMasks, pages comptées depuis 0)
            for page, x0, y0, x1, y1 in zones:
                masques.setdefault(page - 1, []).append(QRectF(x0, y0, x1 - x0, y1 - y0))
            vue.setMasks(masques)
            # le code seul se sélectionne et se copie, pour Pyxel Studio (``Sujet.cours_code``, vide sans éditeur externe) :
            # la vue copie elle-même (copiable : GardeCopie la laisse faire), dans le navigateur aussi
            code = {}
            for page, x, y, largeur, hauteur in self.cours_code.get(cours, ()):
                code.setdefault(page, []).append(QRectF(x, y, largeur, hauteur))
            vue.setCopyZones(code)
            if code:
                vue.setProperty("copiable", True)
                vue.setCopyFilter(indentation_copiee)
            onglets.addTab(vue, Path(cours).stem)
        if onglets.count() < 2:  # un seul cours : rien à répartir
            return onglets
        # Onglets, ou mosaïque (les cours l'un sous l'autre, chacun avec son titre) au choix de l'élève, comme les docks de
        # SmartPythonEditor (demande de l'utilisateur, 06/10/2026). Les vues passent de l'un à l'autre : même widget, même page lue.
        # Deux boutons, comme là-bas (l'utilisateur, 08/10/2026 : « mêmes icônes […] alignés avec les onglets ou le titre de
        # la tuile de mosaïque en haut à droite ») : l'un dans le coin de la barre d'onglets, l'autre sur la ligne de titre
        # de la première tuile ; un seul bouton déplacé de l'un à l'autre devrait changer d'icône et de parent à chaque bascule.
        panneau, mosaique = QWidget(), QSplitter(Qt.Orientation.Vertical)
        vers_mosaique = BoutonIcone("mosaique", "Montrer les cours l'un sous l'autre")
        vers_onglets = BoutonIcone("onglets", "Montrer les cours en onglets")
        vers_mosaique.setObjectName("vers_mosaique")
        vers_onglets.setObjectName("vers_onglets")
        onglets.setCornerWidget(vers_mosaique, Qt.Corner.TopRightCorner)
        colonne = QVBoxLayout(panneau)
        colonne.setContentsMargins(0, 0, 0, 0)
        # la mosaïque AVANT les onglets (un seul des deux est visible) : enfants détruits dans cet ordre, ses vues partent
        # avant les documents, enfants des onglets, comme en onglets (sinon BarreParDessus relit une barre déjà détruite)
        colonne.addWidget(mosaique, 1)
        colonne.addWidget(onglets, 1)

        def repartir(en_mosaique):
            self.cours_en_mosaique = en_mosaique
            if en_mosaique:
                while onglets.count():
                    titre, vue = onglets.tabText(0), onglets.widget(0)
                    onglets.removeTab(0)
                    case = QWidget()
                    case.titre = titre
                    pile = QVBoxLayout(case)
                    pile.setContentsMargins(0, 0, 0, 0)
                    pile.setSpacing(0)
                    ligne = QHBoxLayout()
                    etiquette = QLabel(f"<b>{titre}</b>")
                    etiquette.setMinimumHeight(vers_onglets.sizeHint().height())  # toutes les tuiles, titre à même hauteur
                    ligne.addWidget(etiquette, 1)
                    if not mosaique.count():  # la première tuile, en haut : le bouton du retour aux onglets
                        ligne.addWidget(vers_onglets)
                        vers_onglets.show()  # caché au retour précédent aux onglets
                    pile.addLayout(ligne)
                    pile.addWidget(vue, 1)
                    mosaique.addWidget(case)
                    vue.show()
            else:
                vers_onglets.setParent(panneau)  # sorti de sa tuile avant qu'elle ne soit détruite
                # caché explicitement : Qt ne cache que ce qui était montré, et à l'ouverture en onglets le bouton, jamais
                # montré, paraissait avec le panneau, en haut à gauche, par-dessus les onglets (08/10/2026)
                vers_onglets.hide()
                while mosaique.count():
                    case = mosaique.widget(0)
                    vue = case.layout().itemAt(1).widget()
                    onglets.addTab(vue, case.titre)
                    case.setParent(None)  # sort du séparateur (``count`` baisse) ; ``hide`` l'y laisserait
                    case.deleteLater()  # pas de ``vue.show()`` : les onglets montrent la page courante seule (pdf.js peindrait l'autre)
            onglets.setVisible(not en_mosaique)
            mosaique.setVisible(en_mosaique)

        vers_mosaique.clicked.connect(lambda: repartir(True))
        vers_onglets.clicked.connect(lambda: repartir(False))
        repartir(self.cours_en_mosaique)
        return panneau

    def _montrer_cours(self, ouvert):
        if self.panneau_cours is None:
            self.panneau_cours = self._panneau_cours()
            self.gauche.addWidget(self.panneau_cours)  # à gauche des questions (l'utilisateur, 29/09/2026), sous les épinglées
        self.panneau_cours.setVisible(ouvert)
        self._regler_gauche(ouvert)

    def _regler_gauche(self, elargir):
        """La colonne de gauche montrée si elle a une question épinglée ou le cours ouvert ; ``elargir`` : elle reprend un peu
        moins de la moitié de la largeur (à chaque ouverture du cours, au premier épinglage), et les épinglées la hauteur
        qu'il leur faut, jusqu'à la moitié, quand le cours est dessous."""
        cours = self.panneau_cours is not None and not self.panneau_cours.isHidden()
        if self.epingles is not None:
            self.epingles.setVisible(bool(self.epinglees))
        self.gauche.setVisible(cours or bool(self.epinglees))
        if elargir and not self.gauche.isHidden():
            largeur = self.separation.width()
            self.separation.setSizes([largeur * 9 // 20, largeur * 11 // 20])
        if cours and self.epinglees:
            hauteur = self.gauche.height()
            haut = min(hauteur // 2, self.epingles.widget().sizeHint().height())
            self.gauche.setSizes([haut, hauteur - haut])

    def _epingler(self, question, oui):
        """Déplace ``question`` dans la colonne de gauche (``oui``), ou l'y reprend pour la remettre à sa place : c'est le
        même widget, qui garde sa saisie et reste modifiable là-haut. Une mention grise tient sa place dans le sujet. Elle
        change aussi de ``Paresse`` : celle du sujet la mesurerait hors de sa zone et en gèlerait la mise en page."""
        if oui:
            if self.epingles is None:
                self.epingles = defilant([])
                self.gauche.insertWidget(0, self.epingles)
            # à sa place, son numéro dans la même colonne, en gras, et sa lettre si c'est une sous-question : « 3. Question
            # épinglée à gauche » (demande de l'utilisateur, 03/10/2026)
            mention = QWidget()
            ligne = QHBoxLayout(mention)
            ligne.setContentsMargins(question.layout().contentsMargins())
            rang = QLabel(question.rang.text())
            rang.setFixedWidth(question.rang.width())
            rang.setVisible(not question.rang.isHidden())
            ligne.addWidget(rang, 0, Qt.AlignmentFlag.AlignTop)
            mention.texte = QLabel(f"<b>{question.marque}</b> " * bool(question.marque) + "<i style='color:gray'>Question épinglée à gauche</i>")
            ligne.addWidget(mention.texte, 1)
            zone = question.parentWidget()
            while not hasattr(zone, "paresse"):
                zone = zone.parentWidget()
            rang = zone.paresse.elements.index(question) if question in zone.paresse.elements else None
            if rang is not None:
                zone.paresse.elements.pop(rang)
                self.epingles.paresse.elements.append(question)
            question.parentWidget().layout().replaceWidget(question, mention)
            self.epinglees[question] = mention, zone.paresse, rang
            pile = self.epingles.widget().layout()
            pile.insertWidget(pile.count() - 1, question)  # avant le ressort de ``defilant``
        else:
            mention, paresse, rang = self.epinglees.pop(question)
            if rang is not None:
                self.epingles.paresse.elements.remove(question)
                paresse.elements.insert(rang, question)
            mention.parentWidget().layout().replaceWidget(mention, question)
            mention.deleteLater()
        question.show()
        self._regler_gauche(oui and len(self.epinglees) == 1 and (self.panneau_cours is None or self.panneau_cours.isHidden()))

    def recharger_cours(self):
        """Le panneau du cours construit avant que ``lire_cours`` ait ses PDF (« Cours introuvable » : dans le navigateur, ils
        arrivent après l'ouverture de l'épreuve) est jeté, et refait tout de suite s'il est ouvert."""
        if self.panneau_cours is not None:
            self.panneau_cours.deleteLater()
            self.panneau_cours = None
            if self.bouton_cours.isChecked():
                self._montrer_cours(True)

    RESSORTS_MAX = 4  # points forts et points à travailler repris en tête du rapport, de chaque côté

    def _cadre_note(self):
        """Le bilan de la copie rendue, entre le titre et les consignes, de toute la largeur (demande de l'utilisateur,
        02/10/2026) : la note, écrite à la main par le professeur (``POLICE_MAIN``, en rouge) — ``noter`` la rend
        modifiable —, sinon celle de la machine ; le détail de la partie obligatoire et du rattrapage par les bonus ;
        l'appréciation — tapée, ou écrite à la main à la tablette graphique (``Manuscrit``, qui prime), une suggestion
        grise tirée du bilan sous les yeux du professeur seul ; et le rapport de l'élève, réussite par thème, sous-thème, compétence, capacité, niveau de Bloom
        et catégorie de la pensée informatique (``noyau.Paquet.statistiques``), ses points forts et ce qu'il doit
        travailler en tête. Absent pendant l'épreuve, rapport et détail absents tant que la correction ne se montre pas."""
        self.cadre_note = cadre = QFrame()
        cadre.setObjectName("cadre_note")
        cadre.setStyleSheet("#cadre_note { border: 1px solid palette(mid); border-radius: 4px; background: palette(base); }"
                            f" QLineEdit, QPlainTextEdit, #libelle_total {{ border: none; background: transparent;"
                            f" color: #c0392b; font-family: {POLICE_MAIN}; font-size: {TAILLE_MAIN}pt; }}"
                            f" QLabel {{ font-size: {TAILLE_POLICE}pt; }} #libelle_note {{ font-weight: bold; }}"
                            " #champ_appreciation { font-weight: bold; }"  # le texte du sujet
                            " #libelle_suggestion { color: gray; font-style: italic; }")
        d = QVBoxLayout(cadre)
        grille = QGridLayout()
        grille.setColumnStretch(1, 1)
        d.addLayout(grille)
        self.champ_note, self.champ_appreciation = QLineEdit(), QPlainTextEdit()
        self.champ_appreciation.setObjectName("champ_appreciation")
        self.champ_note.setFixedWidth(QFontMetrics(self.champ_note.font()).horizontalAdvance("00,00") * 2)
        self.champ_note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main = QFontMetrics(QFont(POLICE_MAIN, TAILLE_MAIN))  # la feuille de style ne s'applique qu'à l'affichage
        self.champ_appreciation.setFixedHeight(3 * main.lineSpacing() + 12)  # trois lignes d'écriture, toute la largeur
        self.champ_note.editingFinished.connect(self._lire_note)
        self.champ_appreciation.textChanged.connect(self._lire_appreciation)
        self.manuscrit = Manuscrit(self.champ_appreciation)  # l'appréciation à la tablette graphique, qui prime sur le texte
        self.manuscrit.modifiee.connect(self._lire_encre)
        note = QHBoxLayout()
        note.addWidget(self.champ_note)
        libelle_total = QLabel(f"/ {self.total:g}")
        libelle_total.setObjectName("libelle_total")
        note.addWidget(libelle_total)
        self.libelle_detail = QLabel()  # exercices retenus, partie obligatoire et rattrapage par les bonus
        note.addSpacing(12)
        note.addWidget(self.libelle_detail)
        # la note sans les points laissés au professeur (demande de l'utilisateur, 09/10/2026 : « plus évident que la note
        # est temporaire, et qu'il manque encore x points qui attendent la correction manuelle du professeur »)
        self.libelle_provisoire = QLabel()
        self.libelle_provisoire.setStyleSheet("color: #c0392b;")
        note.addSpacing(12)
        note.addWidget(self.libelle_provisoire)
        note.addStretch()
        libelle = QLabel("Note :")
        libelle.setObjectName("libelle_note")
        grille.addWidget(libelle, 0, 0)
        grille.addLayout(note, 0, 1)
        grille.addWidget(QLabel("Appréciation :"), 1, 0, Qt.AlignmentFlag.AlignTop)
        grille.addWidget(self.manuscrit, 1, 1)
        # la suggestion composée depuis le bilan (``noyau.suggerer_appreciation``), au professeur seul, jamais écrite
        # d'office : il écrit l'appréciation lui-même, à la main (demande de l'utilisateur, 04/10/2026)
        self.libelle_suggestion = QLabel(wordWrap=True)
        self.libelle_suggestion.setObjectName("libelle_suggestion")
        grille.addWidget(self.libelle_suggestion, 2, 1)
        self.libelle_sorties = QLabel()  # les sorties d'une épreuve sous surveillance (``lecteur.Lecteur.baisser``)
        grille.addWidget(self.libelle_sorties, 3, 0, 1, 2)
        # au professeur seul : ce que les nouvelles versions du sujet ont changé à la copie (``noyau.Paquet.migrer``)
        self.libelle_migrations = QLabel(wordWrap=True)
        grille.addWidget(self.libelle_migrations, 4, 0, 1, 2)
        self.libelle_forces = QLabel(wordWrap=True, textFormat=Qt.TextFormat.RichText)
        d.addWidget(self.libelle_forces)
        self.rapport = QWidget()  # un tableau par axe, qui passent à la ligne à la largeur d'un téléphone
        self.rangee_rapport = Rangee(24)
        self.rapport.setLayout(self.rangee_rapport)
        d.addWidget(self.rapport)
        self.statistiques_montrees = None
        self.champ_appreciation.setPlainText(self.appreciation)
        self.manuscrit.poser(self.appreciation_encre)
        self.professeur = False
        self._afficher_note()
        return cadre

    def noter(self, professeur):
        """Le professeur (``lecteur`` : sa machine, qui a son mot de passe) écrit la note et l'appréciation d'une copie
        rendue ; l'élève les lit, sans pouvoir les changer."""
        self.professeur = professeur
        self._afficher_note()

    def _afficher_note(self):
        self.cadre_note.setVisible(self.fin is not None)  # rien pendant l'épreuve (demande de l'utilisateur, 27/09/2026)
        for champ in (self.champ_note, self.champ_appreciation):
            champ.setReadOnly(not (self.professeur and self.fin is not None))
        corrigee = self.corrigee() and self.fin is not None
        obtenus = self.resultat()[0] if corrigee else None
        # les bonus rattrapent des points perdus ailleurs, sans dépasser le total (``noyau.Section``)
        note = self.note if self.note is not None else None if obtenus is None else min(obtenus, self.total)
        self.champ_note.setText("" if note is None else f"{note:g}".replace(".", ","))
        gagnes, possibles = self.bonus()
        details = []
        if corrigee and self.exercices_au_choix:  # point 1.54 : dire lesquels la note compte
            hors_bonus = [s for s in self.sections if not s.bonus]
            numeros = [str(hors_bonus.index(s) + 1) for s in self.sections_retenues()]
            details.append(f"exercices retenus (les {self.exercices_au_choix} meilleurs sur {len(hors_bonus)}) : "
                           + (", ".join(numeros[:-1]) + " et " + numeros[-1] if len(numeros) > 1 else "".join(numeros)))
        if corrigee and self.feuilles_bonus:
            details.append(f"partie obligatoire : {obtenus - gagnes:g} / {self.total:g}  ·  rattrapage par les bonus :"
                           f" + {gagnes:g} (sur {possibles:g})".replace(".", ","))
        self.libelle_detail.setVisible(bool(details))
        self.libelle_detail.setText("  ·  ".join(details))
        attente = self.resultat()[2] if corrigee and self.note is None else 0
        self.libelle_provisoire.setVisible(bool(attente))
        self.libelle_provisoire.setText(f"<b>Note provisoire</b> : il manque {attente:g} point{'s' if attente >= 2 else ''} "
                                        "en attente de correction manuelle par le professeur".replace(".", ","))
        self.libelle_sorties.setVisible(bool(self.sorties))
        self.libelle_sorties.setText(sorties_de_l_epreuve(self.sorties))
        self.libelle_migrations.setVisible(bool(self.professeur and self.migrations))
        self.libelle_migrations.setText(migrations_de_la_copie(self.migrations))
        self.manuscrit.professeur = self.professeur and self.fin is not None
        statistiques = self.statistiques() if corrigee else []
        suggestion = (noyau.suggerer_appreciation(min(obtenus, self.total) / self.total,
                                                  *noyau.ressorts(statistiques, self.RESSORTS_MAX))
                      if self.professeur and corrigee and self.total else "")
        self.libelle_suggestion.setVisible(bool(suggestion))
        self.libelle_suggestion.setText(suggestion and f"Suggestion : {suggestion}")
        self._afficher_rapport(statistiques)

    def _afficher_rapport(self, statistiques):
        """Les tableaux du rapport, refaits seulement s'ils ont changé ; une réussite d'au moins ``SEUIL_FORT`` en vert,
        sous ``SEUIL_FAIBLE`` en rouge, et ces lignes-là reprises en tête, en points forts et points à travailler."""
        if statistiques == self.statistiques_montrees:
            return
        self.statistiques_montrees = statistiques
        while (element := self.rangee_rapport.takeAt(0)) is not None:
            tableau = element.widget()
            tableau.setParent(None)  # tout de suite : ``deleteLater`` attend le retour à la boucle d'événements
            tableau.deleteLater()
        nom = html.escape  # tel qu'écrit : une majuscule ajoutée ferait « Str » ou « For » des noms de Python
        virgule = lambda x: f"{round(x, 2):g}".replace(".", ",")
        for axe, lignes in statistiques:
            rangs = []
            for libelle, gagne, note in lignes:
                taux = gagne / note
                couleur = noyau.VERT if taux >= noyau.SEUIL_FORT else "#c0392b" if taux < noyau.SEUIL_FAIBLE else ""
                rangs.append(f"<tr><td>{nom(libelle)}</td><td align='right' style='padding-left: 10px; color: {couleur or 'black'}'>"
                             f"<b>{round(100 * taux)} %</b></td><td align='right' style='padding-left: 8px; color: gray'>"
                             f"{virgule(gagne)} / {virgule(note)}</td></tr>")
            tableau = QLabel(f"<b>{axe}</b><table cellspacing='0' cellpadding='1'>{''.join(rangs)}</table>",
                             textFormat=Qt.TextFormat.RichText)
            tableau.setAlignment(Qt.AlignmentFlag.AlignTop)
            self.rangee_rapport.addWidget(tableau)
        # en tête, les RESSORTS_MAX plus nets de chaque côté (``noyau.ressorts``, partagés avec la suggestion d'appréciation)
        forts, faibles = noyau.ressorts(statistiques, self.RESSORTS_MAX)
        resume = [f"<b>{titre}</b> : {', '.join(nom(n) for n in liste)}" for titre, liste in
                  (("Points forts", forts), ("À travailler", faibles)) if liste]
        self.libelle_forces.setText("<br>".join(resume))
        self.libelle_forces.setVisible(bool(resume))
        self.rapport.setVisible(bool(statistiques))

    def _lire_note(self):
        texte = self.champ_note.text().strip().replace(",", ".")
        try:
            self.note = float(texte) if texte else None
        except ValueError:
            pass
        self._afficher_note()
        self.annotee.emit()

    def _lire_appreciation(self):
        self.appreciation = self.champ_appreciation.toPlainText()
        self.annotee.emit()

    def _lire_encre(self):
        self.appreciation_encre = self.manuscrit.traits
        self.annotee.emit()

    def _afficher_page(self, n):
        page = self.ecrans.get(n)
        if page is None:
            self.pages[n].batir()
            page = self.ecrans[n] = defilant([*self.tete, self.pages[n]] if n == 0 else [self.pages[n]])  # le titre au premier
            page.setFrameShape(QFrame.Shape.NoFrame)
            self.pile.addWidget(page)
        self.pile.setCurrentWidget(page)

    def _suite(self, feuille):
        """La question qui vient d'être soumise reste un instant sous les yeux avant que la vue ne se recale dessus : un
        mouvement immédiat la faisait disparaître sans que l'élève comprenne où elle était passée."""
        if self.affichage != "sujet":
            return super()._suite(feuille)
        self.attente.stop()  # tout changement annule la descente en attente : « Modifier » pendant la pause la retient
        self.descente.stop()
        super()._suite(feuille)
        if self.attente.isActive():  # une descente vient d'être demandée : elle attend la fin de la pause
            self.attente.start(PAUSE_MS)

    def _devant(self):
        """Parmi les questions ouvertes visibles à l'écran, celle sous la souris, sinon la plus haute."""
        libres = [f for q in self._page() for f in q.feuilles()
                  if f.actif and not (f.fermee or f.cachee) and not f.visibleRegion().isEmpty()]
        sous = QApplication.widgetAt(QCursor.pos())
        while sous is not None and sous not in libres:
            sous = sous.parentWidget()
        return sous or min(libres, key=lambda f: f.mapTo(self, QPoint()).y(), default=None)

    def _defiler(self, n, recadrer=False):
        self.cible, self.recadrer = n, recadrer  # au prochain tour, la mise en page retombée ; _suite y ajoute la pause
        self.descente.stop()
        self.attente.start(0)

    def _descendre(self):
        zone = self.defilement
        debut, fin = zone.verticalScrollBar().value(), self.unites[self.cible].mapTo(zone.widget(), QPoint(0, 0)).y()
        if self.recadrer and fin <= debut:
            return
        self.descente.setStartValue(debut)
        self.descente.setEndValue(fin)
        self.descente.start()

    def _rafraichir_vue(self):
        if self.panneau_cours is not None and self.masques_cours() != self.montres:  # une question close démasque son cours
            self.recharger_cours()
        for b, feuilles in ((self.barre_avancement, [f for f in self.feuilles if f not in self.feuilles_bonus]), (self.barre_bonus, self.feuilles_bonus)):
            if feuilles:
                b.setValue(round(100 * sum(f.avancement() for f in feuilles) / len(feuilles)))
        en_cours = bool(self.a_batir)  # construction en tâche de fond (``chantier``) : rien qui parcoure tout le sujet
        self.bouton_tout.setEnabled(self.demarre and self.fin is None and not self.retenue and not en_cours
                                    and not all(f.fermee for f in self.feuilles))
        self.bouton_terminer.setEnabled(not self.retenue and not en_cours)
        self.bouton_terminer.setToolTip(self.retenue and "La copie se rend dans le dernier quart du temps." or self.aide_terminer)
        if self.affichage == "question":
            self.precedent.setVisible(self.retour and self.fin is None)
            self.precedent.setEnabled(self.courante > 0)
            self.suivant.setEnabled(self.courante < len(self.pages) - 1)
        if self.fin is None:
            self.prec_libre.setVisible(self.retour)
        self.prec_libre.setEnabled(not en_cours and self._voisine(-1) is not None)
        self.suiv_libre.setEnabled(not en_cours and self._voisine(1) is not None)

    def _corriger_tout(self):  # par une méthode : branché tel quel, le « checked » du clic vaudrait ``confirmer``
        self.soumettre_tout()

    def _rendre_copie(self):  # idem
        self.rendre()

    def _pas(self):
        self.aller(self.courante + (1 if self.sender() == self.suivant else -1))

    def _non_traitee(self):
        self.sauter(1 if self.sender() == self.suiv_libre else -1)

    def _confirmer(self):
        """L'élève confirme dans une boîte NON bloquante (le navigateur n'a pas de boucle imbriquée) : c'est elle qui
        soumet, sans redemander ; ici on répond toujours non, ``soumettre_tout`` s'arrête là en attendant son clic."""
        self._demander("Corriger mes réponses",
                       "Toutes les questions encore ouvertes vont être corrigées. L'épreuve continue : une réponse "
                       "fausse pourra être reprise, à points réduits, tant qu'il reste du temps.\n\nContinuer ?",
                       self._corriger_sans_demander)
        return False

    def _corriger_sans_demander(self):
        self.soumettre_tout(confirmer=False)

    def _demander(self, titre, texte, oui):
        boite = QMessageBox(QMessageBox.Icon.Question, titre, texte, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, self)
        boite.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        boite.accepted.connect(oui)
        boite.open()

    def bilan_rendu(self):
        """Ce que rendre la copie maintenant coûte, chiffré : les questions ni traitées ni soumises (corrigées telles
        quelles) et les secondes chances ouvertes mais non jouées (perdues) ; vide si tout est traité ou soumis."""
        ouvertes = [f for f in self.feuilles if not f.fermee]
        lignes = [(len([f for f in ouvertes if not (f.complete() or f.seconde)]), "Questions ni traitées ni soumises, corrigées telles quelles : "),
                  (len([f for f in ouvertes if f.seconde]), "Secondes chances non jouées, perdues : ")]
        return "\n".join(f"{texte}{n}" for n, texte in lignes if n)

    def rendre(self, confirmer=True):
        """Le bouton « Rendre ma copie » : ``terminer``, après avoir dit ce qui sera figé. La fin du temps, elle, ne demande rien."""
        if confirmer:
            self._demander("Rendre ma copie", (self.bilan_rendu() or "Toutes les questions sont traitées ou soumises.")
                           + "\n\nRendre la copie ? Plus rien ne pourra être modifié ensuite.", self.terminer)
            return
        self.terminer()

    def _noter(self):
        for f in self.feuilles:  # la note d'une question soumise ne s'affiche que si la correction le fait
            f.notee = self.corrigee()
            f.afficher_bareme()

    def _montrer_fin(self):
        super()._montrer_fin()
        self._noter()  # une correction différée se montre à l'échéance, la copie déjà rendue
        for b in (self.precedent, self.suivant):
            b.hide()
        # la copie corrigée, ◀ ▶ mènent aux questions qui n'ont pas tous leurs points (l'utilisateur, 03/10/2026)
        for b, sens in ((self.prec_libre, "précédente"), (self.suiv_libre, "suivante")):
            b.setVisible(self.corrigee())
            b.setToolTip(f"Question {sens} qui n'a pas tous ses points")
        self._rafraichir_vue()
        self.bouton_tout.setEnabled(False)
        self.bouton_terminer.hide()
        self.bouton_essai.setVisible(self.nouvel_essai and bool(self.origine))
        self.finie.emit()
        self._afficher_note()  # la note va dans le cadre de l'entête ; reste ici ce qu'elle ne dit pas
        attente = self.resultat()[2] if self.corrigee() and self.note is None else 0
        self.bilan.definir(f"**Épreuve terminée** — <span style=\"color:#c0392b\">**note provisoire** : {attente:g} "
                           f"{'points restent' if attente >= 2 else 'point reste'} à corriger par le professeur.</span>" if attente
                           else "**Épreuve terminée** — la correction et la note s'afficheront à l'échéance." if self.masquee
                           else "**Épreuve terminée.**")
