"""Le modèle objet de QCM/ : banques, questions, sujets et paquets élèves, en classes Python (voir README.md).

Chaque classe se lit et s'écrit en JSON par serializejson : le fichier est un JSON plat où ``"__class__"`` nomme la
classe, les valeurs par défaut du ``__init__`` étant omises. Un parseur tiers qui ignore ``__class__`` retrouve
l'arbre de dictionnaires. Au chargement, ``__init__`` est rappelé avec les champs du fichier : un champ inconnu ou
manquant est une ``TypeError``, jamais un champ ignoré.

Le type d'une question est sa classe (``ChoixUnique``…), et ``type`` en donne le nom historique (``"choix_unique"``).
Ne restent des dictionnaires que les clés qui sont des DONNÉES : ``contextes``, ``medias``, ``variables``,
``competences_livret``, ``trous``.

Tout ce qui contient des questions est un widget Qt (qtpy6, PySide6) : les dix-sept types, ``Section``, ``Paquet`` et
``Banque``. Une même classe sert donc à la banque du professeur, au paquet livré et au rendu de l'élève, à des états
différents : ``charger(fichier).show()`` affiche n'importe lequel. Seul ``DefinitionSujet`` reste une donnée pure.
La réponse de l'élève est le champ ``saisie`` (``reponse`` est, pour une alternative, la bonne réponse) : une property
branchée sur les widgets de saisie, que ``Objet.__serializejson__`` écrit avec les autres champs, si bien que
l'enregistrement du fichier suffit à conserver la session (réponses, indices débloqués, seconde chance, fin).
Le paquet livré à l'élève contient les questions COMPLÈTES : c'est son chiffrement (``mot_de_passe``) qui les protège.
"""

import configparser
import functools
import html
import math
import os
import re
import time
import weakref
from pathlib import Path

import noyau
import pyxel_studio
from noyau import *  # noqa: F403 - modele.py EST le noyau, avec des widgets : ses importeurs y trouvent tout (serializejson compris)
from qtpy6.QtCore import (QBuffer, QByteArray, QCoreApplication, QEasingCurve, QEvent, QMargins, QObject, QPoint, QPointF,
                          QPropertyAnimation, QRect, QRectF, QSize, QSizeF, Qt, QTimer, Signal)
from qtpy6.QtGui import (QAbstractTextDocumentLayout, QColor, QCursor, QFont, QFontInfo, QFontMetrics, QImage, QKeySequence, QPaintEngine, QPainter, QPalette,
                         QPen, QPixmap, QPolygonF, QPyTextObject, QRegion, QTextBlockFormat, QTextCharFormat, QTextCursor, QTextDocument, QTextFormat,
                         QTextOption)
from qtpy6.QtSvg import QSvgRenderer
from qtpy6.web import application as application_web, navigateur, tactile
from qtpy6.web.dispositions import Rangee
from qtpy6.web.defilement import ZoneDefilante
from qtpy6.QtWidgets import (QAbstractButton, QAbstractItemView, QApplication, QButtonGroup, QCheckBox, QComboBox, QFrame,
                             QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                             QListWidget, QListWidgetItem, QMenu, QMessageBox, QPlainTextEdit, QProgressBar,
                             QPushButton, QRadioButton, QScrollArea, QSizePolicy, QSplitter, QStackedWidget, QStyle, QStyledItemDelegate, QStyleOptionButton,
                             QTableWidget, QTableWidgetItem, QTabWidget, QTextBrowser, QToolButton, QVBoxLayout, QWidget)

from console_code import ConsoleCode, intitule
from editeur_code import EditeurCode, EditeurLignes
from texte_md import BORDURE_TABLEAU, CADRE_CODE, ENTETE_TABLEAU, GRIS_FAIT, LARGEUR_COCHE, MONO, VERT_REPONSE, Markdown, cellule

IMAGES = {"png", "jpg", "jpeg", "gif", "webp", "svg"}
LARGEUR_MAX = 900  # largeur d'affichage maximale d'une image, en pixels
HAUTEUR_VISUEL = 90  # le visuel du thème dans l'entête du sujet, en pixels
TAILLE_POLICE = 12  # le texte du sujet, en points : les 16 px d'un navigateur, là où la police du système en donne 13
TAILLE_MAIN = TAILLE_POLICE + 2  # POLICE_MAIN (Kalam), pour la correction : ses lettres basses (x-height) sont plus
# petites qu'à corps égal (mesuré par QFontMetrics hors écran : Kalam à 12 pt vaut 8,4, la police du sujet 8,6). 13 pt
# (8,9) paraissait encore petit à côté du texte : 14 pt (10,0), partout à l'écran (demandes de l'utilisateur, 27 et 28/09/2026)
VIOLET_REFORMULER = "#8e44ad"  # le lien « (reformuler) »
ROSE_INDICE = 0.12  # la part de rouge dans le fond du bouton d'indice
PAUSE_MS, DESCENTE_MS = 700, 450  # la question soumise reste un instant sous les yeux, puis la vue se recale dessus


def charger(chemin, mot_de_passe=None):
    """L'objet (Banque, DefinitionSujet, Paquet…) écrit dans le fichier, chiffré ou non."""
    application()
    return serializejson.load(str(chemin), authorized_classes=list(serializejson.constructors), encryption_key=mot_de_passe)


def sauver(objet, chemin, mot_de_passe=None):
    """Écrit l'objet ; chiffré (age, scrypt) si ``mot_de_passe`` : le coût de scrypt n'est payé qu'une fois par processus."""
    # dans le navigateur, la copie se range (localStorage) et s'envoie (Dropbox) en texte : l'armure ASCII d'age (base64) ;
    # ailleurs le binaire, d'un tiers plus court
    serializejson.dump(objet, str(chemin), bytes_compression=None, index=None, sort_keys=False, single_line_list_numbers=False,
                       encryption_key=mot_de_passe, encryption_in_base64=navigateur())
    serializejson.wait_writes()



# --- l'écran : une application, du texte Markdown, des lignes cochables ------------------------------------------


def application():
    """La QApplication du processus, créée au besoin (``qtpy6.web.application`` : hors session graphique, sans fenêtre ;
    dans le navigateur, où Qt n'a AUCUNE police système, celles du sujet et celle de l'interface du natif, Noto Sans, ce
    que « Sans Serif 9 » donne sur la machine, sont livrées dans ``polices/`` à côté de ce fichier et chargées là)."""
    return application_web(polices=Path(__file__).parent / "polices", defaut=("Noto Sans", 9))


def fond_sujet():
    """Le fond du sujet : entre le gris de la fenêtre (trop terne) et le blanc des champs (qui s'y perdraient), aux trois
    quarts vers le blanc."""
    fenetre, champ = QApplication.palette().window().color(), QApplication.palette().base().color()
    return QColor(*((a + 3 * b) // 4 for a, b in zip(fenetre.getRgb()[:3], champ.getRgb()[:3])))


def fond_entete(palette):
    """Donne à ``palette`` le fond de l'entête du sujet : celui de la barre de titre, lu dans le thème KDE (« Header »),
    plus foncé quand la fenêtre a le focus, comme elle ; ailleurs, le gris de la fenêtre, assombri d'autant qu'en Breeze
    clair (239 → 222) quand elle a le focus. ``configparser`` et pas QSettings : celui-ci lit « [Colors:Header][Inactive] »
    comme une seconde « [Colors:Header] », qui écrase la première."""
    theme = configparser.ConfigParser(interpolation=None, strict=False)
    theme.read(os.path.expanduser("~/.config/kdeglobals"), encoding="utf-8")
    fenetre = QApplication.palette().window().color()
    for groupe, section, defaut in ((QPalette.ColorGroup.Active, "Colors:Header", fenetre.darker(108)),
                                    (QPalette.ColorGroup.Inactive, "Colors:Header][Inactive", fenetre)):
        try:
            couleur = QColor(*map(int, theme.get(section, "BackgroundNormal").split(",")))
        except (configparser.Error, TypeError, ValueError):  # pas de KDE, ou une couleur écrite autrement que « r,g,b »
            couleur = defaut
        palette.setColor(groupe, QPalette.ColorRole.Window, couleur)


def question(widget):
    """La question qui contient ``widget`` (ou ``widget`` lui-même), None hors d'une question."""
    while widget is not None and not isinstance(widget, Question):
        widget = widget.parentWidget()
    return widget


def copiable(widget):
    """Vrai si une question qui contient ``widget`` (ou lui-même) porte ``copiable`` : sans elle, rien ne se copie.
    Toutes les questions qui le contiennent comptent : un Groupe copiable le transmet à ses sous-questions. Hors question,
    un widget à la propriété ``copiable`` (l'accueil du lecteur : le code s'y colle) le transmet de même à ses enfants."""
    while widget is not None:
        if isinstance(widget, Question) and widget.copiable or widget.property("copiable"):
            return True
        widget = widget.parentWidget()
    return False


def cadre_code(document, position):
    """La table du cadre de code (texte_md.bloc_code) où se trouve ``position``, None hors d'un code."""
    curseur = QTextCursor(document)
    curseur.setPosition(position)
    table = curseur.currentTable()
    return table if table is not None and table.format().background().color() == QColor(CADRE_CODE[0]) else None


def code_selectionne(texte):
    """Le code sélectionné dans un Texte d'un projet, tel qu'écrit ; None si la sélection n'est pas dans un cadre de code."""
    curseur = texte.textCursor()
    if not texte.property("code_seul") or not curseur.hasSelection() or cadre_code(texte.document(), curseur.anchor()) is None:
        return None
    return curseur.selectedText().replace("\u2029", "\n")


def sorties_de_l_epreuve(sorties):
    """« Sorties de l'épreuve : 2 (3 min 10 s hors de l'épreuve) », suivi de l'heure de chacune ; une copie rouverte (page
    fermée ou rechargée) n'a pas d'heure de départ, ni de durée."""
    def heure(t):
        return time.strftime("%H:%M:%S", time.localtime(t)) if t else "?"
    duree = round(sum(retour - depart for depart, retour in sorties if depart and retour))
    return "\n".join([f"Sorties de l'épreuve : {len(sorties)} ({duree // 60} min {duree % 60} s hors de l'épreuve)"]
                     + [f"  {'copie rouverte' if depart is None else 'sortie à ' + heure(depart)}, retour à {heure(retour)}"
                        for depart, retour in sorties])


class GardeCopie(QObject):
    """Installé par le lecteur seulement : rien de ce que l'élève voit ne peut être copié, sauf dans une question
    ``copiable``. Le texte n'est plus sélectionnable ; Ctrl+C, Ctrl+X, Ctrl+Inser, Maj+Suppr et le menu contextuel sont
    interceptés AVANT que le presse-papiers ne reçoive quoi que ce soit (un gestionnaire de presse-papiers le lirait aussitôt).
    Dans un projet, le code de l'énoncé est écrit pour être collé dans l'éditeur : un cadre de code s'y sélectionne et se
    copie (Ctrl+C), un cadre à la fois, et rien autour."""

    def __init__(self, app):
        super().__init__(app)
        app.installEventFilter(self)

    GARDES = frozenset((QEvent.Type.Show, QEvent.Type.KeyPress, QEvent.Type.ShortcutOverride, QEvent.Type.ContextMenu))

    def eventFilter(self, objet, evenement):
        """Appelé pour chaque événement de l'application : le type d'abord, le seul test qui écarte presque tout."""
        type_ = evenement.type()
        if type_ not in self.GARDES or not isinstance(objet, QWidget):
            return False
        if type_ == QEvent.Type.Show and isinstance(objet, Texte):  # dans les deux sens : un Texte affiché avant d'avoir son parent est venu sans question
            libre, q = copiable(objet), question(objet)
            objet.setProperty("code_seul", not libre and q is not None and q.projet)
            objet.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction if libre
                                          else Qt.TextInteractionFlag.TextSelectableByMouse if objet.property("code_seul")
                                          else Qt.TextInteractionFlag.NoTextInteraction)
            if objet.property("code_seul") and not objet.property("limite"):
                objet.setProperty("limite", True)
                objet.selectionChanged.connect(functools.partial(self.limiter, objet))
        elif type_ in (QEvent.Type.KeyPress, QEvent.Type.ShortcutOverride):
            if evenement.matches(QKeySequence.StandardKey.Copy) or evenement.matches(QKeySequence.StandardKey.Cut):
                if copiable(objet):
                    return False
                code = code_selectionne(objet) if type_ == QEvent.Type.KeyPress and isinstance(objet, Texte) else None
                if code is not None:
                    QApplication.clipboard().setText(code)
                return True
        elif type_ == QEvent.Type.ContextMenu and not copiable(objet):
            return True
        return False

    @staticmethod
    def limiter(texte):
        """Une sélection ne sort pas du cadre de code où elle a commencé ; commencée ailleurs, elle s'efface."""
        curseur = texte.textCursor()
        if not curseur.hasSelection():
            return
        cadre = cadre_code(texte.document(), curseur.anchor())
        if cadre is None:
            curseur.clearSelection()
        else:
            position = min(max(curseur.position(), cadre.firstCursorPosition().position()), cadre.lastCursorPosition().position())
            if position == curseur.position():
                return
            curseur.setPosition(position, QTextCursor.MoveMode.KeepAnchor)
        texte.setTextCursor(curseur)


def a_l_echelle(html):
    """Les tailles écrites en points dans le HTML, comptées pour le corps de 10 pt du papier, à l'échelle du corps de
    l'écran. Le code (``MONO``, 9 pt sur le papier) prend, lui, le corps entier de l'écran, celui de l'éditeur de
    code (demande de l'utilisateur, 28/09/2026) : 9 pt y deviennent TAILLE_POLICE, pas 10,8."""
    return re.sub(rf"(font-family:'{MONO}'; )?font-size:(\d+(?:\.\d+)?)pt",
                  lambda m: f"{m.group(1) or ''}font-size:{float(m.group(2)) * TAILLE_POLICE / (9 if m.group(1) else 10):g}pt", html)


A_NOTER = f'<u style="color:#bfbfbf">{"&nbsp;" * 5}</u>&nbsp;/&nbsp;'  # exporter_pdf.A_NOTER : la place de la note
INDENTATION_PAPIER = re.compile(r'<span style="color:transparent">(\$+)</span>')  # texte_md.indentation_visible


class MarkdownEcran(Markdown):
    """Une image se dit par son nom : ``Texte.loadResource`` la fournit, quand ses octets sont là (après la construction).
    L'indentation d'un bloc de code reste des espaces, que son ``<pre>`` préserve : les « $ » transparents du papier
    (pour le copier d'un lecteur de PDF) se verraient dans une sélection, et se copieraient."""

    sons = None  # liste (ancre, nom, légende) accumulée par ``media`` pendant un ``Texte.definir`` ; None ailleurs
    # (``html_case``, peint sans widgets) : un son y reste alors le texte injouable du papier, comme prévu.
    AUDIO = {"mp3", "ogg", "flac", "m4a"}  # un bouton les joue à l'écran (qtpy6.web.audio) ; vidéo : injouable, reste en texte

    def media(self, m):
        legende, nom = m.group(1), m.group(2)
        extension = nom.rsplit(".", 1)[-1].lower()
        if extension in IMAGES:
            return f'<img src="{nom}">'
        if extension in self.AUDIO and self.sons is not None and nom in MEDIAS:
            ancre = f"son{len(self.sons)}"
            self.sons.append((ancre, nom, legende))
            legende_html = f' <i>{html.escape(legende)}</i>' if legende else ""
            return f'<a name="{ancre}">{"&nbsp;" * 3}</a>{legende_html}'
        return super().media(m)

    def code(self, *args, **kwargs):
        """Le fond du cadre sur sa case : Qt ne peint pas le ``bgcolor`` d'un tableau en ``border-collapse:collapse``,
        et le code prenait le fond du sujet. Le gris du papier, légèrement plus foncé que la page, pour ne pas être pris
        pour le blanc d'un éditeur où l'on écrit (l'utilisateur, 30/09/2026, après le blanc pur du 26/09)."""
        html = INDENTATION_PAPIER.sub(lambda m: " " * len(m.group(1)), super().code(*args, **kwargs))
        return html.replace("<tr><td ", f'<tr><td bgcolor="{CADRE_CODE[0]}" ', 1)


MD = MarkdownEcran({}, LARGEUR_MAX)


def largeur_naturelle(document):
    """La largeur d'un texte sans retour à la ligne : celle de sa plus longue ligne."""
    copie = document.clone()
    copie.setTextWidth(-1)
    return copie.idealWidth()


def fragments(document):
    """Les fragments de texte du document, dans l'ordre."""
    bloc = document.begin()
    while bloc.isValid():
        it = bloc.begin()
        while not it.atEnd():
            yield it.fragment()
            it += 1
        bloc = bloc.next()


OBJET_SVG, NOM_SVG = QTextFormat.UserObject + 1, QTextFormat.UserProperty + 1
POUCE = {"in": 1, "cm": 1 / 2.54, "mm": 1 / 25.4, "pt": 1 / 72, "pc": 1 / 6, "px": 1 / 96, "": 1 / 96}


def taille_svg(octets):
    """Largeur et hauteur, en pouces, que la racine d'un SVG déclare (``width="5.17in"``) : son pHYs à lui. Sans unité,
    des pixels d'écran. Absentes, on échoue : la taille d'affichage n'est écrite nulle part ailleurs."""
    racine = re.search(rb"<svg\b[^>]*>", octets).group(0)
    return [float(m.group(1)) * POUCE[m.group(2).decode()]
            for m in (re.search(rb'\s%s="([\d.]+)(\w*)"' % cote, racine) for cote in (b"width", b"height"))]


class ObjetSvg(QPyTextObject):  # QObject + QTextObjectInterface : la classe fournie par PySide, le double héritage n'y suffit pas
    """Les images des médias dessinées dans un QTextDocument par ce gestionnaire plutôt que par la ressource image de Qt :
    un SVG en vecteurs (net à toute échelle, à l'écran comme dans le PDF, là où une image serait rééchantillonnée), un PNG
    à pleine résolution réduit au dessin (net sur un écran HiDPI). Et la largeur d'affichage suit celle du texte : sur un
    téléphone, une figure large se réduit au lieu d'être coupée au bord (``intrinsicSize`` est redemandée à chaque
    changement de largeur du document). ``echelle`` : les unités du document par pouce de la taille déclarée dans le
    média (pixels à l'écran, points sur le papier), ``largeur_max`` la largeur d'affichage à ne pas dépasser.

    À l'écran, la figure dessinée une fois à la taille des pixels est gardée en image (``images``), copiée telle quelle aux
    peintures suivantes : relancer ``QSvgRenderer.render`` (ou réduire le PNG) à chaque peinture coûtait à chaque défilement.
    Seulement sur un moteur raster (fenêtre, QImage) sans rotation : le PDF et le SVG gardent les vecteurs."""

    IMAGES = True  # False : toujours en vecteurs (comparaison des pixels)
    PLAFOND = 8  # images gardées par document : quelques tailles (redimensionnement, échelle d'écran)

    def __init__(self, document, medias, echelle, largeur_max):
        super().__init__(document)  # vit tant que le document : la disposition ne retient pas son gestionnaire
        self.medias, self.echelle, self.largeur_max, self.rendus, self.images = medias, echelle, largeur_max, {}, {}
        document.documentLayout().registerHandler(OBJET_SVG, self)

    def poser(self):
        """Après chaque ``setHtml`` : le HTML ne sait pas déclarer d'objet personnalisé, chaque ``<img>`` dont le nom est
        dans les médias est remplacé par l'objet que ce gestionnaire dessine."""
        document = self.parent()
        images = [(f.position(), f.charFormat().toImageFormat().name()) for f in fragments(document) if f.charFormat().isImageFormat()]
        for position, nom in reversed(images):  # de la fin : les positions restent justes
            if nom in self.medias:
                format_ = QTextCharFormat()
                format_.setObjectType(OBJET_SVG)
                format_.setProperty(NOM_SVG, nom)
                curseur = QTextCursor(document)
                curseur.setPosition(position)
                curseur.setPosition(position + 1, QTextCursor.MoveMode.KeepAnchor)
                curseur.insertText("\ufffc", format_)

    def rendu(self, nom):
        """Le SVG prêt à dessiner ou le PNG décodé, et sa taille en pouces : ce que déclare la racine du SVG, la résolution
        du PNG (``pHYs``, la taille dans le Word d'origine) ; sans elle, ses pixels comptent pour des unités du document."""
        if nom not in self.rendus:
            octets = self.medias[nom]
            if nom.lower().endswith(".svg"):
                # le texte d'un SVG prend la police du sujet (celle du document : le système à l'écran, Carlito sur le
                # papier), quelle que soit la famille écrite dans le fichier ; sa taille reste celle du fichier, en unités
                # de la figure, donc à l'échelle de la figure — demande de l'utilisateur, 24/09/2026
                famille = self.parent().defaultFont().family().encode()
                # sauf la main du correcteur (Kalam), dans les figures que le corrigé remplit (``Conversion.svg``)
                image = QSvgRenderer(QByteArray(re.sub(rb'font-family="(?!Kalam")[^"]*"', b'font-family="' + famille + b'"', octets)))
                largeur, hauteur = taille_svg(octets)
            else:
                image = QImage.fromData(octets)
                par_pouce = image.dotsPerMeterX() * 0.0254 if b"pHYs" in octets else self.echelle
                largeur, hauteur = image.width() / par_pouce, image.height() / par_pouce
            self.rendus[nom] = image, largeur, hauteur
        return self.rendus[nom]

    def intrinsicSize(self, document, position, format_):
        _, largeur, hauteur = self.rendu(format_.property(NOM_SVG))
        largeur_max = min(self.largeur_max, document.textWidth()) if document.textWidth() > 0 else self.largeur_max
        facteur = min(self.echelle, largeur_max / largeur)
        return QSizeF(largeur * facteur, hauteur * facteur)

    @staticmethod
    def dessiner(peintre, image, rect):
        if isinstance(image, QSvgRenderer):
            image.render(peintre, rect)
        else:
            peintre.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            peintre.drawImage(rect, image)

    def drawObject(self, peintre, rect, document, position, format_):
        nom = format_.property(NOM_SVG)
        image = self.rendu(nom)[0]
        t = peintre.deviceTransform()
        if (not self.IMAGES or peintre.paintEngine().type() != QPaintEngine.Type.Raster or t.m12() or t.m21() or t.m13() or t.m23()
                or t.m11() != t.m22() or t.m11() <= 0):
            self.dessiner(peintre, image, rect)
            return
        # au pixel près : l'image est dessinée avec le même décalage sous le pixel que la figure l'aurait été, puis copiée
        # sur la grille, sans rééchantillonnage
        e, coin = t.m11(), t.map(rect.topLeft())
        x, y = math.floor(coin.x()), math.floor(coin.y())
        dx, dy = round((coin.x() - x) * 64) / 64, round((coin.y() - y) * 64) / 64
        cle = nom, round(rect.width() * e), round(rect.height() * e), dx, dy, e
        if cle not in self.images:
            if len(self.images) >= self.PLAFOND:
                self.images.clear()
            pixels = QImage(math.ceil(rect.width() * e + dx), math.ceil(rect.height() * e + dy), QImage.Format.Format_ARGB32_Premultiplied)
            pixels.fill(Qt.GlobalColor.transparent)
            p = QPainter(pixels)
            p.setRenderHints(peintre.renderHints())
            p.translate(dx, dy)
            p.scale(e, e)
            self.dessiner(p, image, QRectF(0, 0, rect.width(), rect.height()))
            p.end()
            pixels.setDevicePixelRatio(e)
            self.images[cle] = pixels
        peintre.drawImage(t.inverted()[0].map(QPointF(x, y)), self.images[cle])


class MenuCentre(QComboBox):
    """Un menu dont le mot choisi est centré : un champ en lecture seule dont l'appui ouvre la liste, et dont le
    relâchement sur une ligne la choisit — appuyer, glisser, relâcher : un seul geste, pas deux clics."""

    # Deux appuis rapprochés (souris, ou deux petits coups de doigt) font un double clic, pas un second appui : laissé au
    # champ, il y sélectionnait le mot au lieu d'ouvrir la liste (vu au doigt par l'utilisateur, 28/09/2026)
    APPUIS = (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonDblClick)

    def __init__(self):
        super().__init__()
        self.ouverture = None  # où l'appui a ouvert la liste ; None une fois l'appui fait dans la liste elle-même
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self.lineEdit().setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lineEdit().installEventFilter(self)
        self.view().window().installEventFilter(self)  # le cadre de la liste déroulée
        self.view().viewport().installEventFilter(self)

    def eventFilter(self, objet, evenement):
        if objet is self.lineEdit() and evenement.type() in self.APPUIS:
            self.ouverture = evenement.globalPosition().toPoint()
            self.showPopup()
            return True
        if objet is self.view().viewport() and evenement.type() == QEvent.Type.MouseButtonPress:
            self.ouverture = None
        if objet is self.view().viewport() and evenement.type() == QEvent.Type.MouseButtonRelease:
            # La vue ne choisit qu'au relâchement d'un appui reçu par elle. Celui de l'appui d'ouverture choisit s'il a
            # glissé : sans glisser, la liste ouverte par-dessus le champ prendrait la ligne sous le doigt.
            deplacement = None if self.ouverture is None else evenement.globalPosition().toPoint() - self.ouverture
            index = self.view().indexAt(evenement.position().toPoint())
            if index.isValid() and (deplacement is None or deplacement.manhattanLength() >= QApplication.startDragDistance()):
                self.setCurrentIndex(index.row())
                self.hidePopup()
            return True
        if (objet is self.view().window() and evenement.type() == QEvent.Type.MouseButtonRelease
                and not self.view().geometry().contains(evenement.position().toPoint())):
            # Le relâchement qui suit l'appui d'ouverture tombe sur le champ, hors de la liste : personne ne le prend, et
            # Qt-WASM (6.10, Firefox, souris comme doigt) referme alors la liste avant tout choix. Le consommer la garde
            # ouverte jusqu'au clic sur une ligne ou à côté ; sur le bureau, il était déjà sans effet.
            return True
        return super().eventFilter(objet, evenement)

    def addItems(self, textes):
        super().addItems(textes)
        for i in range(self.count()):
            self.setItemData(i, Qt.AlignmentFlag.AlignCenter, Qt.ItemDataRole.TextAlignmentRole)
        self.setCurrentIndex(-1)  # rien de choisi, sans ligne vide dans la liste

    def largeur(self, police):
        return max(QFontMetrics(police).horizontalAdvance(self.itemText(i)) for i in range(self.count())) + 16


class MenuBinaire(MenuCentre):
    """Un menu à deux mots : tant que rien n'est choisi, il montre « mot **/** mot » ; le mot survolé se grise, le mot
    appuyé se grise davantage, et le relâcher dessus le choisit. Une fois choisi, chaque appui passe à l'autre mot : une
    liste de deux lignes n'apporterait rien (demande de l'utilisateur, 28/09/2026)."""

    def __init__(self, mots):
        super().__init__()
        self.addItems(mots)
        self.deux = DeuxMots(mots, self.lineEdit())
        self.lineEdit().setMouseTracking(True)  # le survol sans bouton
        self.lineEdit().textChanged.connect(self._texte_change)  # ``setCurrentText`` ne touche que lui

    def _texte_change(self, texte):
        self.deux.setVisible(not texte)

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.deux.setFont(self.lineEdit().font())  # celle de la feuille de style, qui ne descend pas jusqu'à l'incrustation
        self.deux.resize(self.lineEdit().size())

    def eventFilter(self, objet, evenement):
        type_ = evenement.type()
        if objet is self.lineEdit() and self.currentText() and type_ in (*self.APPUIS, QEvent.Type.MouseButtonRelease):
            if type_ in self.APPUIS:
                self.setCurrentIndex(1 - self.currentIndex())  # choisi : l'appui passe à l'autre mot, sans liste
            return True
        souris = (QEvent.Type.MouseMove, *self.APPUIS, QEvent.Type.MouseButtonRelease, QEvent.Type.Leave)
        if objet is self.lineEdit() and type_ in souris and not self.currentText():
            deux = self.deux
            deux.survol = None if type_ == QEvent.Type.Leave else deux.cote(evenement.position().x())
            if type_ in self.APPUIS:
                deux.appui = deux.survol
            if type_ == QEvent.Type.MouseButtonRelease:
                choisi, deux.appui = deux.appui == deux.survol, None
                if choisi:
                    self.setCurrentIndex(deux.survol)  # relâché sur le mot appuyé ; glissé vers l'autre, rien
            deux.update()
            if type_ not in (QEvent.Type.MouseMove, QEvent.Type.Leave):
                return True
        return super().eventFilter(objet, evenement)

    def largeur(self, police):
        return QFontMetrics(gras(police)).horizontalAdvance(f"{self.itemText(0)} / {self.itemText(1)}") + 16


class DeuxMots(QWidget):
    """« mot **/** mot » posé sur le champ d'un ``MenuBinaire`` : il dessine, le champ reçoit la souris."""

    def __init__(self, mots, champ):
        super().__init__(champ)
        self.mots, self.survol, self.appui = mots, None, None  # côtés (0 ou 1) survolé et appuyé
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    def zones(self):
        """Le rectangle de chaque mot et celui de la barre, centrés dans le champ."""
        normale, grasse = QFontMetrics(self.font()), QFontMetrics(gras(self.font()))
        a, b = (normale.horizontalAdvance(mot) for mot in self.mots)
        espace, barre = normale.horizontalAdvance(" "), grasse.horizontalAdvance("/")
        x = (self.width() - a - b - 2 * espace - barre) / 2
        h = self.height()
        return QRectF(x, 0, a, h), QRectF(x + a + espace, 0, barre, h), QRectF(x + a + 2 * espace + barre, 0, b, h)

    def cote(self, x):
        return 0 if x < self.zones()[1].center().x() else 1

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        premier, barre, second = self.zones()
        peintre.setPen(Qt.PenStyle.NoPen)
        for cote, zone in enumerate((premier, second)):
            opacite = 55 if self.appui == cote else 25 if self.survol == cote and self.appui is None else 0
            if opacite:
                peintre.setBrush(QColor(0, 0, 0, opacite))
                peintre.drawRoundedRect(zone.adjusted(-3, 1, 3, -1), 3, 3)
        peintre.setPen(self.palette().color(QPalette.ColorRole.Text))
        for zone, mot in ((premier, self.mots[0]), (second, self.mots[1])):
            peintre.drawText(zone, Qt.AlignmentFlag.AlignCenter, mot)
        peintre.setFont(gras(self.font()))
        peintre.drawText(barre, Qt.AlignmentFlag.AlignCenter, "/")


def gras(police):
    police = QFont(police)
    police.setBold(True)
    return police


def menu(mots, deux=True):
    """Le champ d'un trou à choisir : deux mots se choisissent d'un appui, davantage dans une liste. ``deux`` faux met
    aussi deux mots dans une liste : un texte dont un trou en a trois déroule tous les siens."""
    if deux and len(mots) == 2:
        return MenuBinaire(mots)
    champ = MenuCentre()
    champ.addItems(mots)
    return champ


TAILLE_TITRE = {1: 22, 2: 17}  # le titre et le sous-titre de l'entête du sujet, en points, avant harmonisation des largeurs
TITRE_MAX, VISUEL_MIN = 40, 60  # ce que l'harmonisation s'autorise : le titre jusqu'à 40 pt, le visuel pas sous 60 px de haut


def entete_harmonisee(document, image):
    """Le titre, le sous-titre et le visuel de l'entête à la même largeur autant que possible (l'utilisateur, 28/09/2026) :
    celle de la plus longue des deux lignes de texte. Le titre grossit jusqu'à ``TITRE_MAX``, le sous-titre sans dépasser
    80 % du titre, le visuel se met à la largeur atteinte (entre ``VISUEL_MIN`` et 4/3 de ``HAUTEUR_VISUEL`` de haut).
    Écrit les tailles dans ``document`` et rend le visuel (``image`` : QImage, ou None) à sa taille."""
    titres, bloc = {}, document.begin()
    while bloc.isValid():
        if bloc.blockFormat().headingLevel() in TAILLE_TITRE:
            titres[bloc.blockFormat().headingLevel()] = bloc
        bloc = bloc.next()

    def largeur(niveau, taille):
        police = QFont(document.defaultFont())
        police.setBold(True)
        police.setPointSizeF(taille)
        return max(QFontMetrics(police).horizontalAdvance(ligne) for ligne in titres[niveau].text().split("\u2028"))

    base = {n: largeur(n, TAILLE_TITRE[n]) or 1 for n in titres}
    cible = max(base.values(), default=0)
    tailles = {}
    if 1 in titres:
        tailles[1] = min(TAILLE_TITRE[1] * cible / base[1], TITRE_MAX)
    if 2 in titres:
        tailles[2] = min(TAILLE_TITRE[2] * cible / base[2], 0.8 * tailles.get(1, TITRE_MAX))
    for niveau, taille in tailles.items():
        morceau = titres[niveau].begin()
        while not morceau.atEnd():
            fragment, curseur = morceau.fragment(), QTextCursor(document)
            format_ = fragment.charFormat()
            format_.clearProperty(QTextFormat.Property.FontSizeAdjustment)  # celui du h1/h2, qui l'emporterait sur la taille
            format_.setFontPointSize(taille)
            curseur.setPosition(fragment.position())
            curseur.setPosition(fragment.position() + fragment.length(), QTextCursor.MoveMode.KeepAnchor)
            curseur.setCharFormat(format_)  # pas mergeCharFormat, qui ne retire aucune propriété
            morceau += 1
    if image is None or image.isNull():
        return None
    atteinte = max((largeur(n, t) for n, t in tailles.items()), default=0) or image.width()
    hauteur = min(max(round(atteinte * image.height() / image.width()), VISUEL_MIN), HAUTEUR_VISUEL * 4 // 3)
    return QPixmap.fromImage(image).scaledToHeight(hauteur, Qt.TransformationMode.SmoothTransformation)


class Texte(QTextBrowser):
    """Du Markdown, sans cadre ni ascenseur, à la hauteur de son contenu."""

    clic = Signal(int, int)

    def __init__(self, markdown="", trou=None, inline=False, manuscrit=False):
        super().__init__()
        self.incrustes = {}  # nom d'ancre -> widget posé sur le texte, à la place de l'ancre
        self.liens = {}  # href -> action, d'un clic sur le lien ou tout près (``lien_sous``)
        self.boutons_son = []  # un par son du texte, repris par definir() quand le même son revient
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setOpenLinks(False)
        self.setStyleSheet("QTextBrowser { background: transparent; }")
        self.document().setDocumentMargin(0)
        self.document().documentLayout().documentSizeChanged.connect(self._ajuster)  # QTextEdit garde la largeur du texte égale à la sienne
        self.svg = ObjetSvg(self.document(), MEDIAS, 96 * TAILLE_POLICE / 10, LARGEUR_MAX)  # même échelle que les PNG
        self.definir(markdown, trou, inline, manuscrit=manuscrit)

    def definir(self, markdown, trou=None, inline=False, coche=None, manuscrit=False):
        anciens = {bouton.son: bouton for bouton in self.boutons_son}  # repris tels quels : un son en cours garde son bouton
        MD.sons = []
        rendu = MD.inline(markdown, manuscrit=manuscrit) if inline else MD.html(markdown, trou, coche=coche, manuscrit=manuscrit)
        self.boutons_son = [anciens.pop(son, None) or self._bouton_son(*son) for son in MD.sons]
        MD.sons = None
        for bouton in anciens.values():
            if self.incrustes.get(bouton.objectName()) is bouton:  # son ancre peut être passée à un nouveau bouton
                del self.incrustes[bouton.objectName()]
            bouton.hide()  # caché, pas détruit : il part avec le texte. Détruit, il libérait la lambda qu'il avait alors,
            # dernière référence au texte : texte détruit pendant la destruction de son enfant, plantage de PySide (01/10/2026)
        self.setHtml(a_l_echelle(rendu))
        self.svg.poser()
        self.setHidden(not markdown)
        self._ajuster(self.document().size())

    def _bouton_son(self, ancre, nom, legende):
        """Un bouton qui joue ``nom`` (``qtpy6.web.audio``), posé par ``_placer`` comme n'importe quel incrusté."""
        bouton = QToolButton(self.viewport())
        bouton.setObjectName(ancre)
        bouton.son = ancre, nom, legende
        bouton.setText("▶")
        bouton.setToolTip(legende or nom)
        cote = tactile.CIBLE if tactile.ACTIF else 22
        bouton.setFixedSize(cote, cote)
        bouton.hide()
        bouton.clicked.connect(self._jouer_son)
        self.incrustes[ancre] = bouton
        return bouton

    def _jouer_son(self):
        from qtpy6.web import audio  # noqa: PLC0415 - seulement au clic, inerte ailleurs (voir qtpy6.web.audio)

        bouton = self.sender()
        nom = bouton.son[1]
        bouton.setEnabled(False)
        audio.jouer(nom, MEDIAS[nom], nom.rsplit(".", 1)[-1].lower(), fini=lambda: bouton.setEnabled(True))

    def _ajuster(self, taille):
        self.setFixedHeight(max(int(taille.height()) + 2, self._placer()))  # un champ centré sur la dernière ligne peut en déborder

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self._placer()

    def _placer(self):
        """Chaque widget incrusté se pose sur l'emplacement réservé par son ancre ``<a name=…>`` ; rend le bas du plus bas."""
        if not self.incrustes:
            return 0  # le cas courant : rien à poser, et le parcours des fragments revient à chaque redimensionnement
        bas = 0
        for fragment in fragments(self.document()):
            for nom in fragment.charFormat().anchorNames():
                widget = self.incrustes.get(nom)
                if widget is not None:
                    curseur = QTextCursor(self.document())
                    curseur.setPosition(fragment.position())
                    rect = self.cursorRect(curseur)
                    widget.move(rect.left(), rect.top() + (rect.height() - widget.height()) // 2)
                    widget.show()
                    bas = max(bas, widget.geometry().bottom() + 2)
        return bas

    def sizeHint(self):
        return QSize(400, int(self.document().size().height()) + 2)

    def loadResource(self, type_, url):
        if url.toString() in MEDIAS:
            return QImage()  # ``ObjetSvg.poser`` remplace l'image dès le HTML posé : rien à charger ici
        return super().loadResource(type_, url)

    def lien_sous(self, position):
        """Le lien d'action (``liens``) sous ``position`` ou à quelques pixels : un mot en italique est une cible trop
        petite, surtout au doigt (demande de l'utilisateur, 28/09/2026 : « la zone pour cliquer dessus doit être assez large »)."""
        if not self.liens:
            return None
        rayon = tactile.CIBLE // 2 if tactile.ACTIF else 10
        for dy in (0, -rayon // 2, rayon // 2, -rayon, rayon):
            for dx in (0, -rayon // 2, rayon // 2, -rayon, rayon):
                lien = self.anchorAt(position + QPoint(dx, dy))
                if lien in self.liens:
                    return lien
        return None

    def mousePressEvent(self, evenement):
        lien = self.lien_sous(evenement.position().toPoint())
        if lien:
            self.liens[lien]()
            return
        self.clic.emit(int(evenement.position().x()), int(evenement.position().y()))
        super().mousePressEvent(evenement)

    def mouseMoveEvent(self, evenement):
        super().mouseMoveEvent(evenement)
        if self.liens:
            proche = self.lien_sous(evenement.position().toPoint())
            self.viewport().setCursor(Qt.CursorShape.PointingHandCursor if proche else Qt.CursorShape.IBeamCursor)


class Ligne(QWidget):
    """Une case ou un bouton radio et son texte Markdown. Un appui de la case à la fin du texte, sur toute la hauteur
    de la rangée, actionne le bouton ; dans le vide à droite du texte, non : on y pose le doigt pour faire défiler la
    page (demande de l'utilisateur, 27/09/2026)."""

    def __init__(self, bouton, markdown):
        super().__init__()
        self.bouton, self.texte = bouton, Texte(markdown, inline=True)
        disposition = QHBoxLayout(self)
        disposition.setContentsMargins(0, 0, 0, 0)
        # case, texte et commentaire de correction centrés sur la hauteur de la rangée (demande de l'utilisateur, 27/09/2026)
        disposition.addWidget(bouton, 0, Qt.AlignmentFlag.AlignVCenter)
        disposition.addWidget(self.texte, 1, Qt.AlignmentFlag.AlignVCenter)
        self.texte.viewport().installEventFilter(self)  # le texte garde l'appui qui tombe sur ses lettres : on l'y guette

    def _appui(self, evenement, x):
        fin = self.texte.x() + math.ceil(self.texte.document().idealWidth()) + 8  # le doigt qui déborde du dernier mot
        if evenement.button() == Qt.MouseButton.LeftButton and x <= fin:
            self.bouton.click()

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.MouseButtonPress:
            self._appui(evenement, objet.mapTo(self, evenement.position().toPoint()).x())
        return False

    def mousePressEvent(self, evenement):
        if not self.texte.geometry().contains(evenement.position().toPoint()):  # un appui du texte qui remonte : déjà vu
            self._appui(evenement, evenement.position().x())
        super().mousePressEvent(evenement)


def decocher(boutons, groupe=None):
    if groupe:
        groupe.setExclusive(False)
    for b in boutons:
        b.setChecked(False)
    if groupe:
        groupe.setExclusive(True)


class Hauteur(QObject):
    """``lignes`` lignes de haut au moins, et toutes celles du texte, repliées comprises : rien ne se cache sous le
    bord. Recalculé quand la police change : la feuille de style du sujet (``defilant``) l'agrandit une fois le champ
    construit, et une hauteur figée sur l'ancienne coupait les dernières lignes (question 31 de la révision).
    Une hauteur FIXE, pas minimale : au-dessus, la disposition donnait au champ sa hauteur préférée, 192 px pour
    tout QPlainTextEdit, et trois lignes de code flottaient dans un cadre de sept (révision 01, 30/09/2026)."""

    def __init__(self, editeur, lignes):
        super().__init__(editeur)
        self.lignes = lignes
        editeur.installEventFilter(self)
        editeur.document().documentLayout().documentSizeChanged.connect(self._reposer)
        # l'ascenseur, lui, se règle APRÈS la mise en page : c'est là qu'on voit une ligne repliée à la nouvelle largeur
        editeur.verticalScrollBar().rangeChanged.connect(self._reposer)
        self.poser(editeur)

    def _reposer(self):
        self.poser(self.parent())

    def poser(self, editeur):
        """La hauteur réelle des blocs, pas un nombre de lignes : une ligne qui porte un « œ » prend la police de
        secours, plus haute que ``lineSpacing()``."""
        disposition, bloc, texte = editeur.document().documentLayout(), editeur.document().begin(), 0
        while bloc.isValid():
            texte += disposition.blockBoundingRect(bloc).height()
            bloc = bloc.next()
        ligne = editeur.fontMetrics().lineSpacing() + getattr(disposition, "ecart", lambda: 0)()  # l'éditeur de code aère
        editeur.setFixedHeight(max(self.lignes * ligne, math.ceil(texte)) + 16)

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.FontChange:
            self.poser(objet)
        return False


def hauteur(editeur, lignes):
    Hauteur(editeur, lignes)
    return editeur


# --- questions ------------------------------------------------------------------------------------------------

class Case(QCheckBox):
    """La case d'une action à faire, dessinée : un petit rond au contour épais, comme une puce, et un V vert qui le
    recouvre en le débordant une fois l'action faite (dessin choisi par l'utilisateur, 24/09/2026 : la case native,
    13 px bord gris pâle, se perdait sur le fond gris du lecteur)."""

    COTE = 20  # le widget ; le rond est plus petit, le V déborde du rond sans sortir du widget
    RAYON = 6

    def sizeHint(self):
        return QSize(self.COTE, self.COTE)

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        c, inactif = self.COTE, None if self.isEnabled() else "#9e9e9e"
        peintre.setPen(QPen(QColor(inactif or (GRIS_FAIT if self.isChecked() else "#37474f")), 2))  # gris comme son texte une fois faite
        peintre.setBrush(QColor("white"))
        peintre.drawEllipse(QPointF(c / 2, c / 2), self.RAYON, self.RAYON)
        if self.isChecked():
            peintre.setPen(QPen(QColor(inactif or "#43a047"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            # la pointe au centre du rond, pour qu'on lise un V et non un trait le long du bord (remarque du 24/09/2026)
            peintre.drawPolyline(QPolygonF([QPointF(c * 0.27, c * 0.4), QPointF(c * 0.5, c * 0.64), QPointF(c * 0.93, c * 0.08)]))


class CaseCarree(QCheckBox):
    """La case d'un choix multiple, dessinée à plat : Fusion fonce le haut de la sienne en dégradé (remarque de
    l'utilisateur, 27/09/2026 : « je veux quelque chose de plat »). Même taille que la case native, feuille de style
    tactile comprise (``PM_IndicatorWidth`` la suit)."""

    def sizeHint(self):
        cote = self.style().pixelMetric(QStyle.PixelMetric.PM_IndicatorWidth, None, self)
        return QSize(cote, cote)

    minimumSizeHint = sizeHint

    def hitButton(self, position):
        return self.rect().contains(position)

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        cote = min(self.width(), self.height())
        carre = QRectF((self.width() - cote) / 2 + 0.5, (self.height() - cote) / 2 + 0.5, cote - 1, cote - 1)
        actif = self.isEnabled()
        bord = self.palette().color(QPalette.ColorRole.Highlight) if self.hasFocus() else QColor("#8c8c8c" if actif else "#c4c4c4")
        peintre.setPen(QPen(bord, 1))
        peintre.setBrush(QColor("white" if actif else "#f4f4f4"))
        peintre.drawRect(carre)
        if self.isChecked():
            peintre.setPen(QPen(QColor("#202020" if actif else "#9e9e9e"), max(1.6, cote / 8), Qt.PenStyle.SolidLine,
                                Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            x, y, c = carre.x(), carre.y(), carre.width()
            peintre.drawPolyline(QPolygonF([QPointF(x + c * 0.22, y + c * 0.52), QPointF(x + c * 0.42, y + c * 0.74),
                                            QPointF(x + c * 0.8, y + c * 0.26)]))


def ligne_de_base(texte):
    """Où tombe la ligne de base de la première ligne du Texte ``texte``, dans ses coordonnées."""
    bloc = texte.document().firstBlock()
    ligne = bloc.layout().lineAt(0)
    return texte.document().documentLayout().blockBoundingRect(bloc).y() + ligne.y() + ligne.ascent()


def recrire(peintre, calque, texte, couleur, decalage=0):
    """Écrit sur ``calque`` (voile, surimpression), à sa place et en ``couleur``, le Texte ``texte`` que le contenu
    dessous garde transparent : la main du professeur passe ainsi au-dessus du voile, qui la ternirait."""
    peintre.save()
    peintre.translate(QPointF(texte.mapTo(calque.parentWidget(), QPoint(0, 0)) - calque.pos()) + QPointF(0, decalage))
    contexte = QAbstractTextDocumentLayout.PaintContext()
    contexte.palette.setColor(QPalette.ColorRole.Text, QColor(couleur))
    texte.document().documentLayout().draw(peintre, contexte)
    peintre.restore()


def indicateur(bouton):
    """Le rectangle de la case ou du rond que l'élève voit, dans les coordonnées du bouton."""
    if isinstance(bouton, CaseCarree):
        cote = min(bouton.width(), bouton.height())
        return QRect((bouton.width() - cote) // 2, (bouton.height() - cote) // 2, cote, cote)
    option = QStyleOptionButton()
    bouton.initStyleOption(option)
    return bouton.style().subElementRect(QStyle.SubElement.SE_RadioButtonIndicator, option, bouton)


class Voile(QWidget):
    """Un gris un peu plus foncé que le fond, translucide, sur une question validée ou soumise : le fond fonce et le texte
    s'éclaircit d'un même geste. Posé sur le contenu de la zone défilante, pas sur la question : il en prend toute la
    largeur et descend jusqu'à la question suivante, voiles bout à bout ; ses boutons restent nets et cliquables, percés
    dans le voile (demande de l'utilisateur, 26/09/2026). Il retient les clics (ignorés, ils remontent au contenu, jamais
    aux champs dessous) ; la molette remonte de même jusqu'à la zone défilante. Il récrit par-dessus, net, ce qui est de
    la main du professeur (``manuscrits`` : texte et couleur), que le widget dessous garde transparent."""

    def __init__(self, parent):
        super().__init__(parent)
        self.couleur, self.manuscrits = QColor(), []
        self.hide()

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.fillRect(self.rect(), self.couleur)
        for texte, couleur in self.manuscrits:
            recrire(peintre, self, texte, couleur)

    @staticmethod
    def niveau(questions):
        """De combien le voile fonce le fond : 117 si ``questions`` sont toutes soumises, 0 sinon (pas de voile). Une
        question « traitée » n'en a plus : elle le devient toute seule, et reste modifiable (28/09/2026)."""
        return 117 if all(q.fermee for q in questions) else 0

    def teinter(self, niveau, visible=True):
        self.setVisible(bool(niveau) and visible)
        self.couleur = fond_sujet().darker(niveau or 100)
        self.couleur.setAlphaF(0.44)  # fond 251 → 241 (validée), 235 (soumise) ; texte noir → gris 100
        self.update()


class Surimpression(QWidget):
    """La correction d'une question à choix tracée à la main par-dessus, comme un professeur sur la copie (demande de
    l'utilisateur, 26/09/2026) : une rature oblique rouge sur une case fausse cochée (pas une croix, 28/09/2026), un rond
    vert autour d'une bonne, une flèche verte à gauche de chaque réponse exacte, et le commentaire (``feedback``) de chaque
    proposition à sa droite, de la couleur de son trait. Au-dessus du voile, qui la ternirait ; ``_poser_voile`` la pose
    avec lui. Transparente à la souris."""

    ROUGE, VERT = QColor("#d32f2f"), QColor(VERT_REPONSE)  # le vert vif des cours (demande de l'utilisateur, 26/09/2026)
    question = property(lambda self: self._question())  # référence faible : une forte ferait un cycle, que seul le ramasse-miettes
    # libère, n'importe quand, et Qt plante s'il détruit les widgets au milieu d'un de ses appels (tests_modele, 01/10/2026)

    def __init__(self, question):
        super().__init__(question)
        self._question, self.montree = weakref.ref(question), False
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.hide()

    def paintEvent(self, evenement):
        q = self.question
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.setBrush(Qt.BrushStyle.NoBrush)
        coches = set(q._cochees())
        for i, b in enumerate(q.boutons):
            case = indicateur(b)
            c = QPointF(b.mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos()) + QRectF(case).center()
            rayon = case.width() / 2 + 6.5  # le rond englobe la case, de 13 px à la souris comme au doigt (27/09/2026)
            juste = q.propositions[i].correcte
            peintre.setPen(QPen(self.VERT if juste else self.ROUGE, 2.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                                Qt.PenJoinStyle.RoundJoin))
            if juste and i in coches:  # une bonne réponse cochée : le rond seul ; oubliée : la flèche seule (27/09/2026)
                peintre.save()
                peintre.translate(c)
                peintre.rotate(-8)
                peintre.drawEllipse(QPointF(0, 0), rayon, rayon * 0.85)
                peintre.restore()
            elif juste:
                pointe = c + QPointF(-case.width() / 2 - 4, 0)
                peintre.drawLine(pointe + QPointF(-20, 1), pointe)  # un trait de main : à peine incliné
                peintre.drawPolyline(QPolygonF([pointe + QPointF(-7, -5), pointe, pointe + QPointF(-7, 5)]))
            elif i in coches:
                d = case.width() / 2 + 3.5
                peintre.drawLine(c + QPointF(-d, d), c + QPointF(d, -d))
            note = q.notes.get(i)
            if note:  # le Texte réserve la place, transparent : on l'écrit ici, au-dessus du voile
                texte = note.parentWidget().layout().itemAt(1).widget()
                # Kalam n'a pas les hauteurs de la police du corps : centrés, les deux textes n'ont pas la même ligne de
                # base ; le commentaire descend sur celle de la proposition (demande de l'utilisateur, 28/09/2026)
                decalage = texte.y() + ligne_de_base(texte) - note.y() - ligne_de_base(note)  # frères dans la rangée
                recrire(peintre, self, note, self.VERT if juste else self.ROUGE, decalage)


class SurimpressionTrous(Surimpression):
    """La même correction à la main sur les champs d'un texte à trous : la réponse fausse barrée en rouge, la bonne
    entourée de vert (demande de l'utilisateur, 28/09/2026) : une rature horizontale, pas une croix. Un trou laissé vide,
    ou sans réponse attendue, reste nu : le mot attendu est dans la correction écrite dessous."""

    def paintEvent(self, evenement):
        q = self.question
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.setBrush(Qt.BrushStyle.NoBrush)
        saisie = q._lire() or {}
        for n, champ in q.champs.items():
            trou = q.trous[n]
            if trou.reponses is None or not saisie.get(n):
                continue
            juste = q.trou_juste(n, saisie[n])
            peintre.setPen(QPen(self.VERT if juste else self.ROUGE, 2.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            cadre = QRectF(QRect(champ.mapTo(self.parentWidget(), QPoint(0, 0)) - self.pos(), champ.size()))
            if juste:  # le rond englobe le champ, penché de 2 px quelle que soit sa largeur, comme tracé à la main
                peintre.save()
                peintre.translate(cadre.center())
                peintre.rotate(-math.degrees(math.atan2(2, cadre.width() / 2)))
                peintre.drawEllipse(QPointF(0, 0), cadre.width() / 2 + 5, cadre.height() / 2 + 3)
                peintre.restore()
            else:  # une rature d'un bord à l'autre du champ, à mi-hauteur
                y = cadre.center().y()
                peintre.drawLine(QPointF(cadre.left() - 3, y + 1), QPointF(cadre.right() + 3, y - 1))


class Question(noyau.Question, QWidget):
    """Le widget d'une question : l'énoncé, le corps propre à chaque type (``_corps``, ``_lire``/``_ecrire``), la
    justification, les indices et la barre de validation. La logique est celle de ``noyau.Question``."""

    changee = Signal()  # la question a changé d'état (soumise, validée, figée) : à enregistrer
    notee = parentheses = False  # voir afficher_bareme

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        self.entrees, self.cases, self.voile, self.surimpression = [], [], None, None
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)  # jamais plus haute que son contenu
        exterieur = QHBoxLayout(self)  # le numéro dans sa colonne, le reste en retrait : comme sur la copie
        exterieur.setContentsMargins(0, 6, 0, 10)
        self.rang = QLabel()
        exterieur.addWidget(self.rang, 0, Qt.AlignmentFlag.AlignTop)
        self.disposition = QVBoxLayout()
        exterieur.addLayout(self.disposition, 1)
        super().__init__(*args, **kw)

    def _montrer_enonce(self):
        texte = self.enonce_simplifie if self.reformulee and self.enonce_simplifie else self.enonce
        anciennes, self.cases = self.cases, []  # reprises par _case : cocher regrise le texte, pas de quoi refaire les cases
        self.texte_enonce.definir(f"**{self.marque}** {texte}" if self.marque else texte,
                                  coche=(lambda: self._case(anciennes)) if self.projet else None)
        for case in anciennes[len(self.cases):]:  # l'énoncé reformulé a moins d'actions
            del self.texte_enonce.incrustes[case.objectName()]
            self.entrees.remove(case)
            case.deleteLater()
        self.liens_poses = self.liens_enonce()
        self.texte_enonce.liens = {href: action for href, _, _, action in self.liens_poses}
        if self.liens_poses:  # au bout du dernier paragraphe, ou sous un bloc final (code, tableau), hors de lui
            curseur = QTextCursor(self.texte_enonce.document().rootFrame().lastCursorPosition())
            curseur.insertHtml("&nbsp;" + "&nbsp;".join(f'<a href="{href}" style="text-decoration:none"><i style="color:{couleur}">({mot})</i></a>'
                                                         for href, mot, couleur, _ in self.liens_poses))

    def liens_enonce(self):
        """Reformuler : un mot en italique entre parenthèses au bout de l'énoncé, en violet, au lieu d'un bouton (demande de
        l'utilisateur, 28/09/2026 : moins de boutons par question ; l'aide, d'abord un lien voisin, est redevenue un bouton
        le 30/09/2026). (href, mot, couleur, action)."""
        if self.enonce_simplifie:
            return [("reformuler", "énoncé d'origine" if self.reformulee else "reformuler", VIOLET_REFORMULER, self.reformuler)]
        return []

    def _case(self, anciennes):
        """La case à cocher d'une action (puce « - ») de l'énoncé d'un projet, à la place de sa puce : une liste de
        choses à faire, dont l'état, ``cochees``, s'enregistre avec la copie. Celle du même rang dans l'énoncé
        précédent (``anciennes``) est reprise."""
        n = len(self.cases)
        if n < len(anciennes):
            case = anciennes[n]
        else:
            case = Case(self.texte_enonce.viewport())
            case.setObjectName(f"coche{n}")
            case.setChecked(n in self.cochees)
            case.toggled.connect(self._cocher)
            case.hide()
            self.texte_enonce.incrustes[f"coche{n}"] = case
            self.entrees.append(case)  # inactive comme la saisie : sous le voile, ou grisée avant que la question ne soit posée
        self.cases.append(case)
        return cellule(f'<a name="coche{n}">&nbsp;</a>', LARGEUR_COCHE), n in self.cochees

    def _cocher(self):
        self.cochees = [n for n, case in enumerate(self.cases) if case.isChecked()]
        self.changee.emit()
        self._montrer_enonce()  # le texte d'une action cochée se grise (demande de l'utilisateur, 24/09/2026)

    def avancement(self):
        """La part faite de la question, de 0 à 1 : tout dès qu'elle est validée ou soumise ; avant, dans un projet,
        la part de ses actions cochées (demande de l'utilisateur, 24/09/2026 : « prendre en compte ces cases cochées
        pour monitorer l'avancement »)."""
        if self.repondue or self.fermee:
            return 1
        return len(self.cochees) / len(self.cases) if self.cases else 0

    def numeroter(self, numero=None):
        """« 1. » dans la colonne de gauche, comme sur la copie (demande de l'utilisateur, 26/09/2026)."""
        super().numeroter(numero)
        self.rang.setText(f"<b>{numero}.</b>" if numero else "")
        self.rang.setVisible(bool(numero))  # une sous-question n'a pas de colonne : sa lettre ouvre son énoncé

    def afficher_bareme(self):
        """À droite de l'énoncé, en italique comme sur la copie : « ____ / 1 point », la place de la note, que la
        note obtenue remplace une fois la question soumise, si le sujet montre la correction (``notee``). Entre
        parenthèses pour une sous-question : le détail du total, pas des points en plus. La note obtenue en vert si elle
        est entière, en rouge sinon, le barème qui suit toujours gris (demandes de l'utilisateur, 26/09/2026)."""
        if self.sous_questions:
            texte = points_txt(self.total()).replace(" ", "&nbsp;")
        elif self.notee and self.fermee and self.obtenu is not None:  # la justification a son propre barème
            couleur = (Surimpression.VERT if self.obtenu >= self.points else Surimpression.ROUGE).name()
            texte = (f"<span style='color:{couleur}; font-family:{POLICE_MAIN}; font-size:{TAILLE_MAIN}pt; "
                     f"font-style:normal'>{self.obtenu:g}</span>&nbsp;/&nbsp;{points_txt(self.points)}")  # le barème reste gris
        else:
            texte = A_NOTER + points_txt(self.total()).replace(" ", "&nbsp;")
        self.gris.setText(f"<i style='color:gray'>{f'({texte})' if self.parentheses else texte}</i>")

    def _construire(self):
        """L'énoncé, le corps, la barre de validation, puis la saisie et l'état de session relus (``noyau``)."""
        d = self.disposition
        self.numeroter()
        self.texte_enonce, self.gris = Texte(), QLabel()
        ligne = QHBoxLayout()
        ligne.addWidget(self.texte_enonce, 1)
        ligne.addWidget(self.gris, 0, Qt.AlignmentFlag.AlignTop)
        d.addLayout(ligne)
        self.afficher_bareme()
        self._montrer_enonce()
        self._corps(d)
        if not self.sous_questions:
            if self.justification:
                d.addWidget(Texte(f"**Justification** ({points_txt(self.justification.points)}) : {self.justification.consigne}", inline=True))
                self.justif = hauteur(QPlainTextEdit(), 3)
                d.addWidget(self.justif)
                self.entrees.append(self.justif)
            barre = Rangee(d.spacing())
            self.bouton_aide, self.bouton_indice, self.bouton_soumettre, self.bouton_modifier = (
                QPushButton("Aide"), QPushButton(), QPushButton("Soumettre"), QPushButton("Modifier"))
            self.bouton_aide.setToolTip("Une piste pour démarrer, sans perdre de points.")
            for b in (self.bouton_soumettre, self.bouton_modifier, self.bouton_aide, self.bouton_indice):
                barre.addWidget(b)  # tous regroupés à gauche, sous la question (l'utilisateur, 30/09/2026)
            d.addLayout(barre)
            self.barre = barre
            self.zone_indices = QVBoxLayout()  # l'aide et les indices sous les boutons, au-dessus de la correction (30/09/2026)
            d.addLayout(self.zone_indices)
            self.voile, self.sous_voile = Voile(self), []  # ``_poser_voile`` le déplace sur le contenu qui défile
            self.nets = (self.bouton_soumettre, self.bouton_modifier, self.bouton_aide, self.bouton_indice)
            for b in self.nets:
                b.installEventFilter(self)  # un bouton qui apparaît ou se déplace : le trou du voile le suit
            self.retour = Texte()
            d.addWidget(self.retour)
            self.bouton_soumettre.clicked.connect(self.soumettre)
            self.bouton_modifier.clicked.connect(self.rouvrir)
            self.bouton_indice.clicked.connect(self.debloquer)
            self.bouton_aide.clicked.connect(self.aider)
        palette = QPalette()  # seul le fond des boutons est résolu, le reste s'hérite ; bouton par bouton : sous la feuille
        palette.setColor(QPalette.ColorRole.Button, palette.button().color().darker(104))  # de style de la zone qui défile,
        for b in self.findChildren(QPushButton):  # celle de la question ne se propage pas. À peine plus foncés que ceux
            b.setPalette(palette)  # de l'en-tête (demande de l'utilisateur, 26/09/2026)
        if not self.sous_questions:  # l'indice, qui coûte des points, sur un rose très pâle : un rouge presque transparent
            rose, fond = QPalette(palette), palette.button().color()  # sur le gris des boutons (l'utilisateur, 28/09/2026)
            rose.setColor(QPalette.ColorRole.Button, QColor(*(round(c + (r - c) * ROSE_INDICE) for c, r in
                                                               zip((fond.red(), fond.green(), fond.blue()), (255, 0, 0)))))
            self.bouton_indice.setPalette(rose)
        super()._construire()

    def afficher_contexte(self, markdown):
        super().afficher_contexte(markdown)
        self.disposition.insertWidget(0, Texte(markdown))

    def _dire(self, markdown, couleur=""):
        super()._dire(markdown, couleur)
        self._styler_retour()
        self.retour.definir(markdown, self._trou_corrige, manuscrit=bool(couleur))
        # décollé des boutons, et en Kalam, dont l'interligne est très haut, lignes et paragraphes resserrés comme sur le
        # corrigé imprimé (demande de l'utilisateur, 28/09/2026 : « Ce n'est pas la bonne réponse » trop près des boutons,
        # trop loin de « Vous pouvez réessayer »)
        document = self.retour.document()
        cadre = document.rootFrame().frameFormat()
        cadre.setTopMargin(TAILLE_POLICE * 0.8)
        document.rootFrame().setFrameFormat(cadre)
        if couleur:
            curseur, bloc = QTextCursor(document), document.begin()
            while bloc.isValid():
                forme = bloc.blockFormat()
                forme.setLineHeight(85, QTextBlockFormat.LineHeightTypes.ProportionalHeight.value)
                forme.setTopMargin(0)
                forme.setBottomMargin(TAILLE_POLICE * 0.3)
                curseur.setPosition(bloc.position())
                curseur.setBlockFormat(forme)
                bloc = bloc.next()
        self._prevoir_voile()  # une correction écrite à la main passe au-dessus du voile

    def _styler_retour(self, couleur=None):
        """Le retour en ``couleur`` (``transparent`` : le voile l'écrit) ; en rouge ou en vert, la main du professeur."""
        couleur = couleur or self.dit[1]
        style = ("QTextBrowser { background: transparent; "
                 + (f"color: {couleur}; font-family: {POLICE_MAIN}; font-size: {TAILLE_MAIN}pt;" if couleur else "") + " }")
        if self.retour.styleSheet() != style:  # un voile reposé à chaque déplacement : pas de feuille réappliquée pour rien
            self.retour.setStyleSheet(style)

    def _montrer_indice(self, markdown, tete=False):
        texte = Texte(markdown, manuscrit=True)  # l'aide et les indices, écrits à la main comme une piste du professeur,
        # « Aide » ou « Indice » seul en gras (l'utilisateur, 30/09/2026)
        texte.setStyleSheet(f"QTextBrowser {{ background: transparent; font-family: {POLICE_MAIN}; font-size: {TAILLE_MAIN}pt; }}")
        self.zone_indices.insertWidget(0 if tete else -1, texte)

    def montrer(self, visible):
        super().montrer(visible)
        self.setVisible(visible)
        if self.voile and not visible:  # posé hors de la question, il ne se cache pas avec elle
            self.voile.hide()

    @property
    def justifie(self):
        return self.justif.toPlainText() if self.justification else ""

    @justifie.setter
    def justifie(self, texte):
        if self.justification:
            self.justif.setPlainText(texte)

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.Move and self.sous_voile and objet is self.sous_voile[-1]:
            return False  # le contenu qui défile emporte le voile avec lui : rien à recalculer à chaque cran de molette
        if evenement.type() in (QEvent.Type.Move, QEvent.Type.Resize, QEvent.Type.Show, QEvent.Type.Hide):
            self._prevoir_voile()
        return False

    def _prevoir_voile(self):
        if not vars(self).get("voile_prevu"):
            self.voile_prevu = True  # un redimensionnement en envoie des centaines : un seul calcul, au tour de boucle suivant
            QTimer.singleShot(0, self, self._poser_voile)

    def _poser_voile(self):
        """Le voile sur le contenu de la zone défilante (la fenêtre, hors d'elle), de la question à la suivante : le haut
        du widget qui suit, ici ou chez le premier ancêtre qui en a un. Chaque ancêtre jusqu'au contenu est écouté : un
        déplacement de la section entière ne se voit pas depuis la question."""
        self.voile_prevu = False
        v = vars(self).get("voile")  # un événement tardif, l'objet Python déjà vidé : ``__getattr__`` du noyau lèverait
        if not v:
            return
        chaine, hote = [self], self
        while hote.parentWidget() is not None and not isinstance(hote.parentWidget().parentWidget(), QScrollArea):
            hote = hote.parentWidget()
            chaine.append(hote)
        if v.parentWidget() is not hote:
            visible = not v.isHidden()
            v.setParent(hote)
            v.setVisible(visible)  # ``setParent`` le cache : une question voilée avant sa première pose perdait son voile
            for w in self.sous_voile:
                w.removeEventFilter(self)
            self.sous_voile = chaine
            for w in chaine:
                w.installEventFilter(self)
        haut = self.mapTo(hote, QPoint(0, 0)).y() if hote is not self else 0
        bas = haut + self.height()
        for w in chaine[:-1]:
            freres = [f for f in w.parentWidget().children() if isinstance(f, QWidget) and not isinstance(f, Voile) and not f.isHidden()
                      and f.y() >= w.y() + w.height()]
            if freres:
                bas = min(f.y() for f in freres) + (w.parentWidget().mapTo(hote, QPoint(0, 0)).y() if w.parentWidget() is not hote else 0)
                break
        v.setGeometry(0, haut, hote.width(), bas - haut)
        trous = QRegion(v.rect())
        for b in self.nets:
            if not b.isHidden():
                trous -= QRegion(QRect(b.mapTo(hote, QPoint(0, 0)) - v.pos(), b.size()))
        # la correction écrite à la main, que le voile récrit nette au-dessus de lui comme la surimpression (demande de
        # l'utilisateur, 28/09/2026 : « Bonne réponse ! » plus pâle que le rond vert)
        net = bool(self.dit[1]) and not self.retour.isHidden() and not v.isHidden()
        v.manuscrits = [(self.retour, self.dit[1])] if net else []
        self._styler_retour("transparent" if net else None)
        v.setMask(trous)
        v.update()
        v.raise_()
        s = vars(self).get("surimpression")
        if s:
            if s.parentWidget() is not hote:
                s.setParent(hote)
            s.setGeometry(v.geometry())
            s.setVisible(s.montree and not self.cachee)
            s.raise_()

    def mettre_a_jour(self):
        """Ce qui est actif, visible et écrit sur les boutons, selon l'état de la question."""
        self.afficher_bareme()
        ouvert = self.actif and not self.fermee
        niveau = Voile.niveau([self])  # voilée si soumise
        voilee = bool(niveau and self.voile)
        for w in self.entrees:
            case = isinstance(w, QAbstractButton)
            # une case sous le voile reste active, sans focus : désactivée, Qt la grisait PUIS le voile la ternissait,
            # bien plus pâle que son libellé (remarque de l'utilisateur, 26/09/2026) ; le voile retient la souris
            w.setEnabled(ouvert or (case and voilee))  # un champ, lui, reste inactif : le voile ne retient pas le clavier
            if case:
                w.setFocusPolicy(Qt.FocusPolicy.NoFocus if voilee else Qt.FocusPolicy.StrongFocus)
                if voilee:
                    w.clearFocus()
            estompe = not (ouvert or niveau)  # pas encore posée, ou figée : le voile ne la couvre pas
            if estompe != (w.graphicsEffect() is not None):  # grisé de façon visible, quel que soit le style Qt
                w.setGraphicsEffect(QGraphicsOpacityEffect(w, opacity=0.45) if estompe else None)
        if self.voile:
            self.voile.teinter(niveau, not self.cachee)
            self._prevoir_voile()  # la correction que le voile récrit suit sa visibilité
        self.bouton_soumettre.setVisible(ouvert and not self.retenue)
        self.bouton_modifier.setVisible(self.actif and self.fermee and not self.seconde and self.modifiable)
        self.bouton_aide.setVisible(ouvert and bool(self.aide) and not self.aidee)
        attente = self.indice_delai()
        self.bouton_indice.setVisible(ouvert and attente is not None)
        if attente is not None:
            retire = round(self.indices[self.debloques].malus * self.points, 2)  # en points : un pourcentage se lit mal
            self.bouton_indice.setEnabled(not attente)
            self.bouton_indice.setText("Indice" + (f" : −{points_txt(retire)}" if retire else "") + (f" (dans {attente} s)" if attente else ""))
            self.bouton_indice.setToolTip(f"Voir cet indice retire {points_txt(retire)} sur {points_txt(self.points)}, même si la réponse est juste."
                                          if retire else "Cet indice ne retire aucun point.")


class Alternative(noyau.Alternative, Question):

    def _corps(self, d):
        self.boutons = [QRadioButton(libelle) for libelle in self.libelles]
        self.groupe = QButtonGroup(self)
        rangee = QHBoxLayout()
        for b in self.boutons:
            self.groupe.addButton(b)
            rangee.addWidget(b)
        rangee.addStretch()
        d.addLayout(rangee)
        self.entrees += self.boutons

    def _lire(self):
        return None if not any(b.isChecked() for b in self.boutons) else self.boutons[0].isChecked()

    def _ecrire(self, valeur):
        decocher(self.boutons, self.groupe)
        if valeur is not None:
            self.boutons[0 if valeur else 1].setChecked(True)


class Annotee:
    """Une question corrigée aussi à la main (``self.surimpression``) : les traits paraissent avec la correction ou la
    confirmation, et s'effacent avec elle (« Modifier »)."""

    def montrer_correction(self, couleur=""):
        super().montrer_correction(couleur)
        self._annoter(True)

    def confirmer(self):
        super().confirmer()
        self._annoter(True)

    def _dire(self, markdown, couleur=""):
        super()._dire(markdown, couleur)
        if not markdown:  # la correction effacée (« Modifier ») : ses traits aussi
            self._annoter(False)

    def _annoter(self, montree):
        self.surimpression.montree = montree
        self._poser_voile()  # qui la montre ou la cache
        self.surimpression.update()


class Choix(Annotee, noyau.Choix, Question):

    def _corps(self, d):
        ordre = melange(range(len(self.propositions)), self.graine) if self.melanger else range(len(self.propositions))
        self.groupe = QButtonGroup(self) if self.EXCLUSIF else None
        boutons, self.notes = {}, {}
        for i in ordre:
            boutons[i] = QRadioButton() if self.EXCLUSIF else CaseCarree()
            if self.groupe:
                self.groupe.addButton(boutons[i])
            rangee = Ligne(boutons[i], self.propositions[i].texte)
            if self.propositions[i].feedback:  # sa place à droite du choix, vide jusqu'à la correction
                note = self.notes[i] = Texte(self.propositions[i].feedback, inline=True, manuscrit=True)
                # l'écriture d'un professeur (demande de l'utilisateur, 26/09/2026), en Kalam (choisie le 27/09/2026) : pas d'italique, elle penche déjà
                note.setStyleSheet(f"QTextBrowser {{ background: transparent; color: transparent; font-family: {POLICE_MAIN};"
                                   f" font-size: {TAILLE_MAIN}pt; }}")
                note.hide()
                rangee.layout().addWidget(note, 1, Qt.AlignmentFlag.AlignVCenter)
            d.addWidget(rangee)
        self.boutons = [boutons[i] for i in range(len(self.propositions))]
        self.entrees += self.boutons
        self.surimpression = Surimpression(self)

    def _attendu(self):
        return "\n".join(f"- {p.texte}" for p in self.propositions if p.correcte)  # les commentaires : en surimpression

    def _annoter(self, montree):
        for i, note in self.notes.items():
            texte = note.parentWidget().layout().itemAt(1).widget()  # le choix se resserre sur son texte, la note le suit
            texte.setMaximumWidth(math.ceil(texte.document().idealWidth()) + 2 if montree else 16777215)  # QWIDGETSIZE_MAX
            note.setVisible(montree)
        super()._annoter(montree)

    def _ecrire(self, valeur):
        decocher(self.boutons, self.groupe)
        for i in [] if valeur is None else [valeur] if isinstance(valeur, int) else valeur:
            self.boutons[i].setChecked(True)


class ChoixUnique(noyau.ChoixUnique, Choix):

    def _lire(self):
        return next(iter(self._cochees()), None)


class ChoixMultiples(noyau.ChoixMultiples, Choix):

    def _lire(self):
        return self._cochees() or None


class ReponseCourte(noyau.ReponseCourte, Question):

    def _corps(self, d):
        self.champ = QLineEdit()
        self.champ.returnPressed.connect(self._entree)
        d.addWidget(self.champ)
        self.entrees.append(self.champ)

    def _entree(self):
        if not self.retenue:  # Entrée suit « Soumettre », caché si retenue
            self.soumettre()

    def _lire(self):
        return self.champ.text() or None

    def _ecrire(self, valeur):
        self.champ.setText(valeur or "")


class ReponseOuverte(noyau.ReponseOuverte, Question):

    def _corps(self, d):
        if self.console:
            self.interpreteur = ConsoleCode(EditeurCode(""), self)
            self.interpreteur.masquer_programme(True)
            d.addWidget(self.interpreteur)
            self.entrees.append(self.interpreteur)
            d.addWidget(intitule("Votre réponse"))  # deux cadres l'un sous l'autre : dire lequel est noté
        self.editeur = hauteur(QPlainTextEdit(), self.lignes)
        d.addWidget(self.editeur)
        self.entrees.append(self.editeur)

    def mettre_a_jour(self):
        super().mettre_a_jour()
        if self.console:
            self.interpreteur.setVisible(not self.sans_execution)

    def _lire(self):
        return self.editeur.toPlainText() or None

    def _ecrire(self, valeur):
        self.editeur.setPlainText(valeur or "")


def lire_champs(champs):
    """Ce qui est rempli dans un ensemble de champs, ``None`` si rien ne l'est."""
    saisie = {n: c.currentText() if isinstance(c, QComboBox) else c.text() for n, c in champs.items()}
    return {n: t for n, t in saisie.items() if t} or None


def ecrire_champs(champs, valeur):
    """Y reposer une saisie ; un champ absent de ``valeur`` est vidé."""
    for n, c in champs.items():
        texte = (valeur or {}).get(n, "")
        c.setCurrentText(texte) if isinstance(c, QComboBox) else c.setText(texte)


class TexteATrous(Annotee, noyau.TexteATrous, Question):

    def _corps(self, d):
        self.champs = {}
        listes = {n: melange(trou.choix, f"{self.graine}|{n}") if trou.choix else melange(self.choix, self.graine) if self.choix else None
                  for n, trou in self.trous.items()}
        # tous les menus d'un texte sous la même forme : « A / B » seulement si aucun trou n'a plus de deux mots (demande
        # de l'utilisateur, 28/09/2026, « pour harmoniser »)
        deux = all(len(liste) == 2 for liste in listes.values() if liste)
        for n, liste in listes.items():
            if liste:
                self.champs[n] = menu([*map(str, liste)], deux)
            else:
                self.champs[n] = QLineEdit()
                self.champs[n].setFixedWidth(100)
        texte = Texte()
        # mesuré à la police du sujet, que la feuille de style du parent ne donnera au texte qu'à l'affichage : à la
        # police par défaut, l'ancre en espaces laissait un vide après le menu, et le menu coupait ses mots d'un « … »
        police = texte.font()
        police.setPointSizeF(TAILLE_POLICE)
        metrique = QFontMetrics(police)
        blanc = metrique.horizontalAdvance("\u00a0")
        # au doigt, des champs plus hauts qu'une ligne, et des lignes espacées d'autant (demande de l'utilisateur, 28/09/2026)
        hauteur = tactile.CIBLE - 8 if tactile.ACTIF else metrique.height() - 2
        for n, champ in self.champs.items():  # chaque champ prend la place d'une ancre, faite d'espaces insécables
            champ.setParent(texte.viewport())
            champ.setStyleSheet(f"QComboBox, QLineEdit {{ font-size: {TAILLE_POLICE}pt; padding: 0px 4px; margin: 0px; min-height: 0px;"
                                " border: 1px solid gray; border-radius: 3px; }"
                                "QComboBox::drop-down { width: 0px; border: none; } QComboBox::down-arrow { image: none; }")  # pas plus haut qu'une ligne
            largeur = champ.largeur(police) if isinstance(champ, MenuCentre) else 100
            champ.setFixedSize(largeur, hauteur)
            champ.hide()
            texte.incrustes[f"trou{n}"] = champ
        texte.definir(self.texte, trou=lambda n: f'<a name="trou{n}">{"&nbsp;" * -(-self.champs[n].width() // blanc)}</a>')
        if tactile.ACTIF:
            curseur = QTextCursor(texte.document())
            curseur.select(QTextCursor.SelectionType.Document)
            interligne = QTextBlockFormat()
            interligne.setLineHeight(hauteur + 8, QTextBlockFormat.LineHeightTypes.MinimumHeight.value)
            curseur.mergeBlockFormat(interligne)
        d.addWidget(texte)
        self.entrees += self.champs.values()
        self.surimpression = SurimpressionTrous(self)

    def _lire(self):
        return lire_champs(self.champs)

    def _ecrire(self, valeur):
        ecrire_champs(self.champs, valeur)


MARGE_ENTETE = 4  # écrite une fois : la feuille de style l'applique, ``_ajuster`` la retranche pour mesurer le repli
STYLE_TABLEAU = (f"QTableWidget {{ gridline-color: {BORDURE_TABLEAU}; border: 1px solid {BORDURE_TABLEAU}; }}"
                 f"QHeaderView::section {{ background: {ENTETE_TABLEAU}; padding: {MARGE_ENTETE}px; border: 0;"
                 f" border-right: 1px solid {BORDURE_TABLEAU}; border-bottom: 1px solid {BORDURE_TABLEAU}; }}")
CASE_DONNEE = QColor("#f7f7f7")  # les cases fournies sont grisées : ce qui reste blanc dans la grille est ce qu'il y a à remplir


@functools.cache
def html_case(markdown):
    """Le HTML d'une case : ``sizeHint`` le redemande à chaque redimensionnement, et Markdown est lent."""
    return a_l_echelle(MD.inline(markdown))


def memoriser(delegue, cle, composer, plafond=256):
    """Le document d'une case, composé une fois par (texte, largeur…) : un délégué le recomposait à chaque peinture (setHtml
    et mise en page, 0,03 à 0,5 ms natif, dix fois plus dans le navigateur) et une vue repeint toutes ses cases à chaque
    survol, défilement ou glisser. Vidé d'un coup au-delà du plafond (largeurs successives d'un redimensionnement)."""
    cache = delegue.__dict__.setdefault("_documents", {})
    if cle not in cache:
        if len(cache) >= plafond:
            cache.clear()
        cache[cle] = composer()
    return cache[cle]


class CaseMarkdown(QStyledItemDelegate):
    """Peint le Markdown des cases DONNÉES, qu'un ``QTableWidgetItem`` ne sait afficher qu'en texte nu.

    Les cases à remplir sont laissées au rendu natif : c'est lui qui donne le champ blanc occupant toute la case."""

    def _document(self, index, largeur):
        return memoriser(self, (index.data() or "", largeur), functools.partial(self._composer, index.data() or "", largeur))

    @staticmethod
    def _composer(texte, largeur):
        document = QTextDocument()
        document.setDocumentMargin(4)
        document.setHtml(html_case(texte))
        option = QTextOption(Qt.AlignmentFlag.AlignCenter)
        option.setWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)  # une adresse « 192.168.1.0/24 » n'a pas d'espace où couper
        document.setDefaultTextOption(option)
        document.setTextWidth(largeur)  # sans largeur imposée, le texte long déborde sur la colonne voisine
        return document

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        if not index.flags() & Qt.ItemFlag.ItemIsEditable:
            option.text = ""  # le style ne dessine plus que le fond ; le texte, c'est ``paint`` qui s'en charge

    def paint(self, peintre, option, index):
        super().paint(peintre, option, index)
        if index.flags() & Qt.ItemFlag.ItemIsEditable:
            return
        document = self._document(index, option.rect.width())
        peintre.save()  # peindre le document à la main, c'est devoir recentrer soi-même ce que le style centrait
        peintre.translate(option.rect.topLeft()
                          + QPoint(0, max(0, int((option.rect.height() - document.size().height()) / 2))))
        document.drawContents(peintre)
        peintre.restore()

    def sizeHint(self, option, index):
        taille = self._document(index, self.parent().columnWidth(index.column())).size()
        return QSize(int(taille.width()), int(taille.height()))


class Tableau(noyau.Tableau, Question):

    def _corps(self, d):
        """La grille est un ``QTableWidget`` : c'est lui qui donne la case blanche entièrement éditable, la navigation
        au clavier et les colonnes étirées, sans rien en réécrire. ``champs`` retient ce qui porte la saisie — la case
        elle-même quand elle se tape, le menu quand elle se choisit — et ``lire_champs`` les lit indifféremment."""
        self.champs = {}
        self.table = QTableWidget(0, len(self.colonnes))
        self.table.setHorizontalHeaderLabels(self.colonnes)
        self.table.verticalHeader().hide()
        entete = self.table.horizontalHeader()
        entete.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        police = entete.font()
        police.setBold(True)  # le gras est posé ici, et non dans la feuille de style : ``_ajuster`` mesure ainsi la police réellement peinte
        entete.setFont(police)
        entete.setDefaultAlignment(Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap)  # sans ce drapeau, un en-tête trop long est coupé net
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.AllEditTriggers)  # un clic suffit : pas de double-clic à deviner
        self.table.setItemDelegate(CaseMarkdown(self.table))
        self.table.setStyleSheet(STYLE_TABLEAU)
        self.hauteurs = QTimer(self.table, singleShot=True)  # les colonnes ne sont à leur largeur définitive qu'une fois la mise en page retombée
        self.hauteurs.timeout.connect(self._ajuster)
        self.table.horizontalHeader().sectionResized.connect(self._differer)
        self._nombre_de_lignes(self.montrees())
        d.addWidget(self.table)
        self.entrees.append(self.table)
        if self.lignes_libres:  # l'élève ouvre ses lignes une à une, jusqu'au double de la grille attendue plus deux ;
            # au-delà, ou sous ``montrees``, le bouton ne fait rien : le griser dirait où est la limite
            rangee = QHBoxLayout()
            self.plus, self.moins = QPushButton("+ ligne"), QPushButton("− ligne")
            self.plus.clicked.connect(lambda: self._nombre_de_lignes(self.table.rowCount() + 1))
            self.moins.clicked.connect(lambda: self._nombre_de_lignes(self.table.rowCount() - 1))
            rangee.addWidget(self.plus)
            rangee.addWidget(self.moins)
            rangee.addStretch()
            d.addLayout(rangee)
            self.entrees += [self.plus, self.moins]

    def _nombre_de_lignes(self, n):
        """Ouvre ou referme des lignes jusqu'à en avoir ``n`` (entre ``montrees`` et le plafond) ; ce qui était écrit
        dans une ligne refermée est perdu, comme une ligne barrée."""
        n = max(self.montrees(), min(n, 2 * len(self.lignes) + 2))
        while self.table.rowCount() > n:
            r = self.table.rowCount() - 1
            for c in range(len(self.colonnes)):
                self.champs.pop(f"{r},{c}", None)
            self.table.removeRow(r)
        while self.table.rowCount() < n:
            self._poser_ligne(self.table.rowCount())
        self._differer()

    def _poser_ligne(self, r):
        """Ajoute la ligne ``r`` : ses cases données, ses champs ; au-delà de la grille attendue, les champs de sa
        dernière ligne et la numérotation prolongée (``donnee``)."""
        self.table.insertRow(r)
        modele = min(r, len(self.lignes) - 1)
        for c in range(len(self.colonnes)):
            reference = f"{r},{c}"
            trou = self.cellules.get(f"{modele},{c}")
            case = QTableWidgetItem("" if trou else self.donnee(r, c))
            case.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if trou is None:
                case.setFlags(case.flags() & ~Qt.ItemFlag.ItemIsEditable)
                case.setBackground(CASE_DONNEE)
            self.table.setItem(r, c, case)
            if trou is None:
                continue
            liste = (melange(trou.choix, f"{self.graine}|{modele},{c}") if trou.choix
                     else melange(self.choix, self.graine) if self.choix else None)
            if liste:
                self.champs[reference] = menu([*map(str, liste)])
                self.champs[reference].setCurrentText("")  # une ligne ouverte arrive vide : rien n'y est choisi
                self.table.setCellWidget(r, c, self.champs[reference])
            else:
                self.champs[reference] = case

    def _differer(self):
        self.hauteurs.start(0)

    def _ajuster(self):
        """Les colonnes étant étirées, la hauteur qu'il faut à une case dépend de la largeur qu'on vient de lui donner :
        elle se recalcule à chaque redimensionnement, sinon un texte passé à la ligne est coupé. L'en-tête n'a pas de
        délégué qui le mesure pour lui : sa hauteur se calcule à la main, à la police même qu'il peint."""
        entete = self.table.horizontalHeader()
        metriques = entete.fontMetrics()
        replie = max(metriques.boundingRect(QRect(0, 0, self.table.columnWidth(c) - 2 * MARGE_ENTETE, 0),
                                            Qt.TextFlag.TextWordWrap, str(titre)).height()
                     for c, titre in enumerate(self.colonnes))
        entete.setFixedHeight(replie + entete.sizeHint().height() - metriques.height())  # + ce que le style ajoute autour d'une ligne
        self.table.resizeRowsToContents()
        self.table.setFixedHeight(entete.height() + 2
                                  + sum(self.table.rowHeight(r) for r in range(self.table.rowCount())))

    def _lire(self):
        return lire_champs(self.champs)

    def _ecrire(self, valeur):
        if self.lignes_libres:
            self._nombre_de_lignes(self.lignes_ecrites(valeur))
        ecrire_champs(self.champs, valeur)


class GrilleConversion(QWidget):
    """La figure d'une question ``conversion`` : le SVG du noyau peint en fond, et un champ de saisie sans cadre posé sur
    chaque case à remplir. À chaque frappe le plan est recalculé sur ce qui est écrit : une flèche paraît quand la case
    qu'elle désigne est remplie — juste ou non, sinon son absence trahirait l'erreur (l'utilisateur, 01/10/2026) — et
    une division de plus s'ouvre quand le quotient précédent est écrit. ``methode`` : celle de la grille, quand l'élève
    choisit la sienne (``methode`` « choix » de la question, une grille par méthode possible).

    Une puissance écrite dans la ligne « en décimales » se recopie dans les autres grilles du sujet, sous la même
    puissance (2⁷, 16¹…) : l'élève ne remplit l'en-tête qu'une fois (demande de l'utilisateur, 01/10/2026). Seulement
    dans une case vide, ou qui portait la valeur d'avant (recopiée elle aussi) : ce que l'élève a écrit lui-même dans une
    autre grille ne s'écrase pas. Une case recopiée reste modifiable, et se corrige comme une saisie."""

    question = property(lambda self: self._question().pour({"methode": self.methode}))
    GRILLES = weakref.WeakSet()

    def __init__(self, question, methode=None):
        super().__init__()
        self._question, self.rendu, self.methode = weakref.ref(question), None, methode  # voir ``Surimpression.question``
        self.echelle = QFontInfo(self.font()).pixelSize() / noyau.Conversion.CORPS  # le texte de la figure à celui du lecteur
        police = QFont(self.font())
        police.setPixelSize(round(noyau.Conversion.CORPS * self.echelle))
        self.champs = {}
        for c in self.question.plan(tout=True)["cases"]:
            if c["remplir"] and c["cle"] not in self.champs:
                champ = QLineEdit(self)
                champ.setFrame(False)
                champ.setFont(police)
                champ.setAlignment({"g": Qt.AlignmentFlag.AlignLeft, "c": Qt.AlignmentFlag.AlignHCenter}.get(
                    c["aligne"], Qt.AlignmentFlag.AlignRight) | Qt.AlignmentFlag.AlignVCenter)
                champ.setStyleSheet(f"QLineEdit {{ background: transparent; color: {c['couleur'] or '#000000'};"
                                    f" font-weight: {'bold' if c['gras'] else 'normal'}; padding: 0 3px; }}")
                champ.textChanged.connect(self.actualiser)
                self.champs[c["cle"]] = champ
        plan = self.question.plan(tout=True)
        entetes = {c["x"]: c["texte"] for c in plan["cases"] if c["y"] == 0 and not c["cle"]}
        self.puissances = {c["cle"]: entetes[c["x"]] for c in plan["cases"] if c["remplir"] and c["cle"][0] == "p"}  # p3 : « 2⁴ »
        self.precedent = {}
        for cle in self.puissances:
            self.champs[cle].textChanged.connect(functools.partial(self.propager, cle))
        GrilleConversion.GRILLES.add(self)
        self.actualiser()

    def propager(self, cle, texte):
        """Recopie la puissance ``cle`` qui vient de changer dans les grilles ouvertes de la même fenêtre."""
        avant, self.precedent[cle] = self.precedent.get(cle, ""), texte
        for autre in list(GrilleConversion.GRILLES):
            try:
                question = autre._question()
                if autre is self or question is None or question.fermee or autre.window() is not self.window():
                    continue
            except RuntimeError:  # grille d'une fenêtre déjà détruite côté Qt, pas encore ramassée côté Python
                continue
            for k, puissance in autre.puissances.items():
                if puissance == self.puissances[cle] and autre.champs[k].text() in ("", avant):
                    autre.champs[k].setText(texte)

    def ecrites(self):
        return {cle: champ.text() for cle, champ in self.champs.items() if champ.text().strip()}

    def actualiser(self):
        """Le plan de ce qui est écrit : la figure à repeindre, les champs à placer, ceux d'une division refermée à cacher
        (ce qu'ils contiennent n'est plus lu, voir ``Conversion._lire``)."""
        q = self.question
        self.plan = q.plan(self.ecrites())
        svg = q.svg(self.plan, police=self.font().family(), ecrites=self.ecrites())
        self.rendu = QSvgRenderer(QByteArray(svg.encode()))
        presentes = set()
        for c in self.plan["cases"]:
            if c["remplir"]:
                x, y, l, h = (round(v * self.echelle) for v in q.rectangle(self.plan, c))
                self.champs[c["cle"]].setGeometry(x + 1, y + 1, l - 2, h - 2)
                presentes.add(c["cle"])
        for cle, champ in self.champs.items():
            champ.setVisible(cle in presentes)
        g = q.geometrie(self.plan)
        self.setFixedSize(math.ceil((g["x"](self.plan["largeur"]) + 1) * self.echelle),
                          math.ceil((g["y"](self.plan["hauteur"]) + 1) * self.echelle))
        self.update()

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.rendu.render(peintre, QRectF(0, 0, self.width(), self.height()))
        peintre.end()


class Conversion(noyau.Conversion, Question):

    """Quand l'élève choisit sa méthode : un bouton par méthode au-dessus des grilles, une seule grille visible, celle du
    bouton coché ; ce qui est écrit dans une autre grille y reste, mais n'est pas lu."""

    def _corps(self, d):
        self.grilles, self.boutons = {}, {}
        if "{" in self.nombre:  # tiré par ``variables`` : la question brute d'une banque, que l'on lit sans l'afficher
            d.addWidget(Texte(f"*Nombre tiré au hasard : {self.nombre}*", inline=True))
            return
        self.grilles = {m: GrilleConversion(self, m) for m in self.methodes()}
        if len(self.grilles) > 1:
            rangee, groupe = QHBoxLayout(), QButtonGroup(self)
            rangee.addWidget(QLabel("Méthode :"))
            for m in self.grilles:
                self.boutons[m] = QRadioButton(noyau.NOM_METHODE[m])
                self.boutons[m].toggled.connect(self._montrer)
                groupe.addButton(self.boutons[m])
                rangee.addWidget(self.boutons[m])
            rangee.addStretch()
            d.addLayout(rangee)
            self.boutons[self.procede()].setChecked(True)
        for grille in self.grilles.values():
            d.addWidget(grille)
            self.entrees += grille.champs.values()
        self.entrees += self.boutons.values()
        self._montrer()

    @property
    def grille(self):
        return self.grilles[next((m for m, b in self.boutons.items() if b.isChecked()), self.methodes()[0])]

    def _montrer(self):
        for grille in self.grilles.values():
            grille.setVisible(grille is self.grille)

    def _lire(self):
        if not self.grilles:
            return None
        presentes = {c["cle"] for c in self.grille.plan["cases"] if c["remplir"]}
        saisie = {k: v for k, v in self.grille.ecrites().items() if k in presentes}
        return {**saisie, "methode": self.grille.methode} if saisie and self.boutons else saisie or None

    def _ecrire(self, valeur):
        if self.boutons:
            self.boutons[self.pour(valeur).methode].setChecked(True)
        for grille in self.grilles.values():
            for cle, champ in grille.champs.items():
                champ.blockSignals(True)
                champ.setText(str((valeur or {}).get(cle, "")) if grille is self.grille else "")
                champ.blockSignals(False)
            grille.precedent = {cle: grille.champs[cle].text() for cle in grille.puissances}
            grille.actualiser()


class Ordre(noyau.Ordre, Question):

    def _corps(self, d):
        if self.langage:
            d.addWidget(Texte("*Glissez les lignes dans le bon ordre, et indentez-les en les glissant vers la droite ou par Tab / "
                              "Maj+Tab (Ctrl+Z annule) ; le texte, lui, ne se modifie pas.*", inline=True))
            self.editeur = hauteur(EditeurLignes([code_nu(e) for e in self.elements], self.depart, [0] * len(self.elements)),
                                   len(self.elements))  # suit la police du sujet, posée après : une ligne restait cachée
            if self.executable:
                self.console = ConsoleCode(self.editeur, self)  # la console porte l'éditeur, entre ses boutons et sa sortie
                d.addWidget(self.console)
                self.entrees.append(self.console)
            else:
                d.addWidget(self.editeur)
            self.entrees.append(self.editeur)
            return
        # les étiquettes d'un classement : même police que l'énoncé, un élément long va à la ligne, et la hauteur
        # se recalcule à la largeur réelle — mesurée avant l'affichage, elle coupait les derniers éléments
        self.liste = etiquettes(lambda: self.liste.setFixedHeight(hauteur_etiquettes(self.liste, self.elements)))
        self.liste.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self._ecrire(None)
        d.addWidget(Texte("*Glissez les éléments dans le bon ordre.*", inline=True))
        d.addWidget(self.liste)
        self.entrees.append(self.liste)

    def _lire(self):
        if self.langage:
            ordre, niveaux = list(self.editeur.ordre), list(self.editeur.niveaux)
            return None if ordre == self.depart and not any(niveaux) else {"ordre": ordre, "niveaux": niveaux}
        ordre = [self.liste.item(k).data(Qt.ItemDataRole.UserRole) for k in range(self.liste.count())]
        return None if ordre == self.depart else ordre

    def _ecrire(self, valeur):
        if self.langage:  # une liste (le corrigé, une ancienne copie) se montre avec la bonne indentation
            if valeur is None:
                self.editeur.ranger(self.depart, [0] * len(self.elements))
            elif isinstance(valeur, dict):
                self.editeur.ranger(valeur["ordre"], valeur["niveaux"])
            else:
                self.editeur.ranger(valeur)
            return
        self.liste.clear()
        for i in self.depart if valeur is None else valeur:
            element = QListWidgetItem(self.elements[i])  # le Markdown, c'est ``Etiquette`` qui le peint
            element.setData(Qt.ItemDataRole.UserRole, i)
            self.liste.addItem(element)


GOUTTIERE = 140  # la colonne où se tracent les liens d'un appariement, entre les deux rangées de puces, en pixels
RAYON_PUCE = 6  # rayon d'une puce d'appariement, en pixels


class Liens(QWidget):
    """La gouttière d'un ``Appariement``, comme sur le papier : une puce au bout de chaque élément, de chaque côté, et
    les traits qui les relient. On tire un trait d'une puce vers une puce d'en face, dans un sens ou dans l'autre, ou
    l'on clique l'une puis l'autre (la puce ou son texte). Retirer un trait de sa puce de gauche et le lâcher dans le
    vide le défait. ``liens`` : pour chaque élément de gauche, la position de son élément à droite, ou ``None``."""

    def __init__(self, gauches, droites):
        super().__init__()
        self.gauches, self.droites = gauches, droites  # les textes, qui donnent la hauteur de chaque puce
        self.liens = [None] * len(gauches)
        self.origine = None  # (côté, rang) de la puce d'où part le trait en cours, ou celle cliquée en attente de l'autre
        self.souris = None  # où suit le trait en cours ; ``None`` une fois la puce seulement cliquée
        self.setFixedWidth(GOUTTIERE)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Ignored)  # la hauteur est celle des rangées de texte
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_AcceptTouchEvents)  # sinon le doigt fait défiler la page (un ancêtre,
        # defiler_au_doigt) au lieu de tirer un trait : voir tactile.relayer_en_souris

    def event(self, evenement):
        if evenement.type() in (QEvent.Type.TouchBegin, QEvent.Type.TouchUpdate, QEvent.Type.TouchEnd):
            if tactile.relayer_en_souris(self, evenement):
                return True
        return super().event(evenement)

    def _puce(self, cote, rang):
        texte = (self.gauches if cote == 0 else self.droites)[rang]
        y = texte.geometry().center().y() - self.geometry().top()
        return QPointF(RAYON_PUCE + 2 if cote == 0 else self.width() - RAYON_PUCE - 2, y)

    def _visee(self, position):
        """La puce la plus proche en hauteur, du côté de la gouttière où est la souris."""
        cote = 0 if position.x() < self.width() / 2 else 1
        textes = self.gauches if cote == 0 else self.droites
        return cote, min(range(len(textes)), key=lambda r: abs(self._puce(cote, r).y() - position.y()))

    def viser(self, cible):
        """Une puce cliquée (ou son texte) : la relie à celle qui attendait en face, ou attend à son tour."""
        if not self.isEnabled():
            return
        if self.origine is not None and self.origine[0] != cible[0]:
            self._relier(self.origine, cible)
            self.origine = None
        else:
            self.origine = None if self.origine == cible else cible
        self.update()

    def _relier(self, a, b):
        gauche, droite = (a, b) if a[0] == 0 else (b, a)
        self.liens[gauche[1]] = droite[1]

    def mousePressEvent(self, evenement):
        cible = self._visee(evenement.position())
        if self.origine is not None and self.origine[0] != cible[0]:
            self.viser(cible)
            return
        self.origine, self.souris = cible, evenement.position()
        self.update()

    def mouseMoveEvent(self, evenement):
        if self.origine is not None and self.souris is not None:
            self.souris = evenement.position()
            self.update()

    def mouseReleaseEvent(self, evenement):
        if self.origine is None or self.souris is None:
            return
        cible = self._visee(evenement.position())
        depart = self._puce(*self.origine)
        if cible[0] != self.origine[0]:
            self._relier(self.origine, cible)
            self.origine = None
        elif (evenement.position() - depart).manhattanLength() > 2 * RAYON_PUCE:  # lâché ailleurs que sur une puce d'en face
            if self.origine[0] == 0:
                self.liens[self.origine[1]] = None
            self.origine = None
        # sinon, un simple clic : la puce attend celle d'en face
        self.souris = None
        self.update()

    def paintEvent(self, evenement):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        trait = self.palette().highlight().color()
        tire = self.origine if self.souris is not None else None  # le lien d'une puce qu'on retire suit la souris
        peintre.setPen(QPen(trait, 2))
        for g, d in enumerate(self.liens):
            if d is not None and tire != (0, g):
                peintre.drawLine(self._puce(0, g), self._puce(1, d))
        if tire is not None:
            peintre.setPen(QPen(trait, 2, Qt.PenStyle.DashLine))
            peintre.drawLine(self._puce(*tire), self.souris)
        relies = {(0, g) for g, d in enumerate(self.liens) if d is not None} | {(1, d) for d in self.liens if d is not None}
        for cote, textes in enumerate((self.gauches, self.droites)):
            for rang in range(len(textes)):
                puce = (cote, rang)
                peintre.setPen(QPen(trait if puce == self.origine else self.palette().text().color(), 2 if puce == self.origine else 1))
                peintre.setBrush(trait if puce in relies or puce == self.origine else self.palette().base().color())
                peintre.drawEllipse(self._puce(cote, rang), RAYON_PUCE, RAYON_PUCE)


class Appariement(noyau.Appariement, Question):

    def _corps(self, d):
        """Deux colonnes de textes et, entre elles, la gouttière où l'élève relie les puces, comme sur la copie papier."""
        droites = [p.droite for p in self.paires] + self.distracteurs
        self.ordre = melange(range(len(droites)), self.graine)  # position affichée -> indice dans droites
        gauches = [Texte(p.gauche, inline=True) for p in self.paires]
        largeur = max(math.ceil(largeur_naturelle(t.document())) + 2 for t in gauches)
        for texte in gauches:  # alignés sur leurs puces, comme sur papier
            texte.document().setDefaultTextOption(QTextOption(Qt.AlignmentFlag.AlignRight))
            texte.setMaximumWidth(largeur)  # la colonne n'est pas plus large que sa plus longue proposition
        droites = [Texte(droites[i], inline=True) for i in self.ordre]
        self.toile = Liens(gauches, droites)
        grille = QGridLayout()
        grille.setVerticalSpacing(10)
        for cote, textes in enumerate((gauches, droites)):
            for rang, texte in enumerate(textes):
                texte.clic.connect(functools.partial(lambda puce, *_: self.toile.viser(puce), (cote, rang)))
                grille.addWidget(texte, rang, 2 * cote)
        grille.addWidget(self.toile, 0, 1, max(len(gauches), len(droites)), 1)
        grille.setColumnStretch(2, 1)  # la place qui reste va à droite : la plus longue de gauche touche la marge, comme sur papier (28/09/2026)
        d.addWidget(Texte("*Reliez chaque élément de gauche à un élément de droite : tirez un trait d'une puce à l'autre, "
                          "ou cliquez l'une puis l'autre. Pour défaire un lien, tirez-le depuis sa puce de gauche et lâchez-le "
                          "dans le vide.*", inline=True))
        d.addLayout(grille)
        self.entrees.append(self.toile)

    def _lire(self):
        choix = [None if p is None else self.ordre[p] for p in self.toile.liens]
        return None if all(i is None for i in choix) else choix

    def _ecrire(self, valeur):
        self.toile.liens = [None if valeur is None or valeur[g] is None else self.ordre.index(valeur[g]) for g in range(len(self.paires))]
        self.toile.origine = self.toile.souris = None
        self.toile.update()


class PointSelection(noyau.PointSelection, Question):

    def _corps(self, d):
        self.point = None
        self.vue = Texte(f"![]({self.image})")
        self.vue.clic.connect(self._cliquer)
        self.croix = QLabel("✚", self.vue.viewport())
        self.croix.setStyleSheet("color: red; font-weight: bold; background: transparent;")
        self.croix.hide()
        d.addWidget(Texte("*Cliquez sur l'image.*", inline=True))
        d.addWidget(self.vue)
        self.entrees.append(self.vue)

    def _echelle(self):
        image = QImage.fromData(MEDIAS[self.image]) if self.image in MEDIAS else None
        return min(1, LARGEUR_MAX / image.width()) if image and image.width() else 1

    def _cliquer(self, x, y):
        if self.vue.isEnabled():
            self._ecrire([round(x / self._echelle()), round(y / self._echelle())])

    def _lire(self):
        return self.point

    def _ecrire(self, valeur):
        self.point = valeur
        self.croix.setVisible(valeur is not None)
        if valeur is not None:
            self.croix.move(int(valeur[0] * self._echelle()) - 6, int(valeur[1] * self._echelle()) - 9)


RAYON = 22  # rayon d'un sommet du type ``dessin``, en pixels
ECART = 7   # décalage d'une arête orientée sur sa droite, pour que A→B et B→A ne se superposent pas
VISEE = 10  # distance à une arête en deçà de laquelle un clic la vise, en pixels
TOILE_MINIMUM = 240  # en deçà, une toile ne se réduit plus : ses sommets ne seraient plus visables au doigt
TENU = 2 * (RAYON - 3)  # largeur de nom qu'un cercle peut contenir : au-delà, le nom s'écrit dessous


class ToileGraphe(QWidget):
    """La zone de dessin d'une question ``dessin`` : l'élève tire un trait d'un sommet à l'autre pour créer une
    arête, clique une arête puis Suppr pour l'effacer. Les sommets, eux, sont ceux du sujet et ne bougent pas."""

    question = property(lambda self: self._question())

    def __init__(self, question):
        super().__init__()
        self._question, self.aretes = weakref.ref(question), []  # voir ``Surimpression.question``
        self.chemin = []  # mode « chemin » : les sommets cliqués, dans l'ordre
        self.depart, self.souris, self.choisie = None, None, None
        self._fond = ...  # chargé au premier dessin : MEDIAS n'est rempli qu'après la construction des questions
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        metriques = self.fontMetrics()
        deborde = [s for s in question.sommets if metriques.horizontalAdvance(str(s.nom)) > TENU]
        cote = max([metriques.horizontalAdvance(str(s.nom)) / 2 + 3 for s in deborde] + [RAYON])
        largeur = max([s.x for s in question.sommets] or [0]) + RAYON + cote
        hauteur = max([s.y for s in question.sommets] or [0]) + 2 * RAYON + (metriques.height() if deborde else 0)
        # La taille naturelle, celle des coordonnées du sujet ; plus étroite (un téléphone), la toile se dessine à
        # l'échelle et la souris est ramenée dans ces coordonnées (``_echelle``) : la figure du bac NSI 2026, 504 px,
        # imposait un ascenseur horizontal à tout le sujet sous 540 px.
        self.naturelle = QSize(int(largeur), int(hauteur))
        largeur_mini = min(self.naturelle.width(), TOILE_MINIMUM)
        self.setMinimumSize(largeur_mini, self.heightForWidth(largeur_mini))
        politique = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        politique.setHeightForWidth(True)
        self.setSizePolicy(politique)

    def sizeHint(self):
        return self.naturelle

    def heightForWidth(self, largeur):
        return math.ceil(self.naturelle.height() * min(1, largeur / self.naturelle.width()))

    def _echelle(self):
        return min(1, self.width() / self.naturelle.width())

    def fond(self):
        if self._fond is ...:
            self._fond = QImage.fromData(MEDIAS[self.question.image]) if self.question.image in MEDIAS else None
        return self._fond

    # -- géométrie

    def _sommet(self, nom):
        return next((s for s in self.question.sommets if s.nom == nom), None)

    def _sous(self, position):
        """Le nom du sommet sous ce point, s'il y en a un."""
        return next((s.nom for s in self.question.sommets
                     if (s.x - position.x()) ** 2 + (s.y - position.y()) ** 2 <= RAYON ** 2), None)

    def _trait(self, arete):
        """Les deux bouts du trait dessiné, de bord à bord, décalés sur la droite si le graphe est orienté."""
        depart, arrivee = self._sommet(arete[0]), self._sommet(arete[1])
        dx, dy = arrivee.x - depart.x, arrivee.y - depart.y
        longueur = math.hypot(dx, dy) or 1
        ux, uy = dx / longueur, dy / longueur
        ecart = ECART if self.question.oriente else 0
        return (QPointF(depart.x + ux * RAYON - uy * ecart, depart.y + uy * RAYON + ux * ecart),
                QPointF(arrivee.x - ux * RAYON - uy * ecart, arrivee.y - uy * RAYON + ux * ecart))

    def _milieu(self, arete):
        a, b = self._trait(arete)
        return QPointF((a.x() + b.x()) / 2, (a.y() + b.y()) / 2)

    def _distance(self, arete, position):
        """La distance de ce point au trait de l'arête, sur toute sa longueur."""
        a, b = self._trait(arete)
        dx, dy = b.x() - a.x(), b.y() - a.y()
        t = ((position.x() - a.x()) * dx + (position.y() - a.y()) * dy) / (dx * dx + dy * dy or 1)
        t = min(1, max(0, t))  # le point du trait le plus proche, sans dépasser ses bouts
        return math.hypot(a.x() + t * dx - position.x(), a.y() + t * dy - position.y())

    def _visee(self, position):
        """L'arête la plus proche de ce point, s'il en est à portée : n'importe où le long du trait, pas seulement
        en son milieu (viser le milieu à 14 px près était trop dur, demande de l'utilisateur, 24/09/2026)."""
        proches = [(self._distance(arete, position), i) for i, arete in enumerate(self.aretes)]
        distance, i = min(proches, default=(None, None))
        return i if distance is not None and distance <= VISEE else None

    # -- dessin

    def paintEvent(self, _):
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        peintre.scale(self._echelle(), self._echelle())
        if self.fond() is not None:
            peintre.drawImage(0, 0, self.fond())
        for donnee in self.question.decor:  # sous le tracé de l'élève, qui surligne donc ce qu'il choisit
            self._peindre_arete(peintre, (donnee.source, donnee.cible, donnee.etiquette), QColor("#b0bec5"))
        bleu = QColor("#1e88e5")
        peintre.setPen(QPen(bleu, 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        # le chemin de l'élève, de centre à centre, sous les sommets ; un parcours n'a que ses numéros : deux sommets
        # visités de suite n'y sont pas forcément voisins, et le trait barrerait la figure là où il n'y a pas d'arête
        for a, b in zip(self.chemin, self.chemin[1:]) if self.question.parcours is None else ():
            a, b = self._sommet(a), self._sommet(b)
            peintre.drawLine(QPointF(a.x, a.y), QPointF(b.x, b.y))
        for i, arete in enumerate(self.aretes):
            if i == self.choisie:  # l'arête choisie, que Suppr effacera : en bleu, et un halo pour qu'on la voie de loin
                peintre.setPen(QPen(QColor(30, 136, 229, 70), 10, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                peintre.drawLine(*self._trait(arete))
            self._peindre_arete(peintre, arete, QColor("#1e88e5") if i == self.choisie else QColor("#37474f"))
        if self.depart is not None and self.souris is not None:
            peintre.setPen(QPen(QColor("#9e9e9e"), 2, Qt.PenStyle.DashLine))
            sommet = self._sommet(self.depart)
            peintre.drawLine(QPointF(sommet.x, sommet.y), self.souris)
        for sommet in self.question.sommets:
            self._peindre_sommet(peintre, sommet)
        for sommet in self.question.sommets:  # le rang de chaque passage, en pastille bleue en haut à droite
            rangs = [str(i + 1) for i, nom in enumerate(self.chemin) if nom == str(sommet.nom)]
            if rangs:
                texte = ",".join(rangs)
                largeur = max(18, peintre.fontMetrics().horizontalAdvance(texte) + 8)
                cadre = QRectF(sommet.x + RAYON * 0.7 - largeur / 2, sommet.y - RAYON * 0.7 - 9, largeur, 18)
                peintre.setPen(Qt.PenStyle.NoPen)
                peintre.setBrush(bleu)
                peintre.drawRoundedRect(cadre, 9, 9)
                peintre.setPen(QColor("#ffffff"))
                peintre.drawText(cadre, int(Qt.AlignmentFlag.AlignCenter), texte)

    def _peindre_sommet(self, peintre, sommet):
        peintre.setPen(QPen(QColor("#37474f"), 2))
        peintre.setBrush(QColor("#ffffff"))
        centre = QPointF(sommet.x, sommet.y)
        peintre.drawEllipse(centre, RAYON, RAYON)
        if sommet.marque == "final":  # l'état acceptant d'un automate : le double cercle
            peintre.drawEllipse(centre, RAYON - 4, RAYON - 4)
        if sommet.marque == "initial":
            peintre.drawLine(QPointF(sommet.x - 2 * RAYON, sommet.y), QPointF(sommet.x - RAYON, sommet.y))
        nom = str(sommet.nom)
        largeur = peintre.fontMetrics().horizontalAdvance(nom)
        if largeur <= TENU:
            cadre = QRect(int(sommet.x - RAYON), int(sommet.y - RAYON), 2 * RAYON, 2 * RAYON)
        else:  # un nom trop long pour son cercle s'écrit dessous : « Internet » y serait coupé net
            cadre = QRect(int(sommet.x - largeur / 2 - 3), int(sommet.y + RAYON),
                          int(largeur) + 6, peintre.fontMetrics().height())
        peintre.drawText(cadre, int(Qt.AlignmentFlag.AlignCenter), nom)

    def _peindre_arete(self, peintre, arete, couleur):
        peintre.setPen(QPen(couleur, 2))
        peintre.setBrush(couleur)
        a, b = self._trait(arete)
        peintre.drawLine(a, b)
        if self.question.oriente:
            angle = math.atan2(b.y() - a.y(), b.x() - a.x())
            pointe = [b] + [QPointF(b.x() - 12 * math.cos(angle + c), b.y() - 12 * math.sin(angle + c))
                            for c in (0.4, -0.4)]
            peintre.drawPolygon(QPolygonF(pointe))
        if arete[2]:
            milieu = self._milieu(arete)
            peintre.setPen(QPen(couleur, 1))
            peintre.setBrush(QColor("#ffffff"))
            largeur = peintre.fontMetrics().horizontalAdvance(str(arete[2])) + 8
            peintre.drawRect(int(milieu.x() - largeur / 2), int(milieu.y() - 9), largeur, 18)
            peintre.drawText(int(milieu.x() - largeur / 2), int(milieu.y() - 9), largeur, 18,
                             int(Qt.AlignmentFlag.AlignCenter), str(arete[2]))

    # -- la souris

    def mousePressEvent(self, evenement):
        if not self.isEnabled():
            return
        position = evenement.position() / self._echelle()
        if self.question.mode == "chemin":  # un clic sur un sommet le met au bout du chemin
            nom = self._sous(position)
            if nom is not None and (not self.chemin or self.chemin[-1] != str(nom)):
                self.chemin.append(str(nom))
                self.update()
            return
        self.depart, self.souris = self._sous(position), position
        self.choisie = None if self.depart is not None else self._visee(position)
        self.update()

    def mouseMoveEvent(self, evenement):
        self.souris = evenement.position() / self._echelle()
        if self.depart is not None:
            self.update()

    def mouseReleaseEvent(self, evenement):
        if not self.isEnabled() or self.depart is None:
            return
        depart, self.depart = self.depart, None
        arrivee = self._sous(evenement.position() / self._echelle())
        if arrivee is not None and arrivee != depart:  # jamais de boucle : un clic sur un sommet, sans glisser, en
            # posait une, dessinée en rond au-dessus du sommet (vu par l'utilisateur, 24/09/2026)
            if self.question.etiquettes:
                self._etiqueter(depart, arrivee, evenement.position().toPoint())
            else:
                self.ajouter([depart, arrivee, ""])
        self.update()

    def _etiqueter(self, depart, arrivee, position):
        """L'étiquette de l'arête qu'on vient de tracer : un menu des étiquettes du sujet, qui ajoute l'arête au choix
        (``popup``, pas ``exec`` : le navigateur n'a pas de boucle imbriquée) ; refermé sans choix, rien n'est tracé."""
        menu = QMenu(self)
        menu.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        for e in self.question.etiquettes:
            menu.addAction(str(e)).setData(str(e))
        self.tracee = depart, arrivee
        menu.triggered.connect(self._etiquette_choisie)
        menu.popup(self.mapToGlobal(position))

    def _etiquette_choisie(self, action):
        self.ajouter([*self.tracee, action.data()])

    def ajouter(self, arete):
        if self.question.cle(*arete) not in [self.question.cle(*a) for a in self.aretes]:
            self.aretes.append(list(arete))
            self.update()

    def keyPressEvent(self, evenement):
        if self.question.mode == "chemin" and self.chemin and evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.chemin.pop()
            self.update()
        elif self.choisie is not None and evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            del self.aretes[self.choisie]
            self.choisie = None
            self.update()
        else:
            super().keyPressEvent(evenement)


class Dessin(noyau.Dessin, Question):

    def _corps(self, d):
        self.toile = ToileGraphe(self)
        d.addWidget(Texte("*Cliquez les sommets dans l'ordre ; Suppr retire le dernier.*" if self.mode == "chemin" else
                          "*Tirez un trait d'un sommet à l'autre pour tracer une arête ; cliquez une arête, puis "
                          "Suppr pour l'effacer.*", inline=True))
        d.addWidget(self.toile)
        self.entrees.append(self.toile)

    def _lire(self):
        if self.mode == "chemin":
            return list(self.toile.chemin) or None
        return [list(a) for a in self.toile.aretes] or None

    def _ecrire(self, valeur):
        if self.mode == "chemin":
            self.toile.chemin = [str(n) for n in (valeur or [])]
            self.toile.update()
            return
        self.toile.aretes = [list(a) for a in (valeur or [])]
        self.toile.choisie = None
        self.toile.update()


class Code(noyau.Code, Question):

    def _corps(self, d):
        # la place de la réponse attendue, plus la ligne où le curseur attend ; ``lignes`` règle le papier (défaut 10),
        # pas l'écran : « au minimum pour la réponse attendue, et qu'elle grandisse si on écrit plus » (30/09/2026).
        # Plafond de 30 : seuls les projets Pyxel le passent (64 à 360 lignes, le jeu entier), où un cadre vide de
        # plusieurs écrans séparerait l'énoncé de la console ; toutes les autres solutions du dépôt en ont 25 au plus
        self.editeur = hauteur(EditeurCode(self.vierge(), self.gabarit() if self.verrouille else None),
                               min(self.solution.rstrip("\n").count("\n") + 2, 30))
        if self.langage in ("python", "sql"):
            self.console = ConsoleCode(self.editeur, self)  # la console porte l'éditeur, entre ses boutons et sa sortie
            d.addWidget(self.console)
            self.entrees.append(self.console)
        else:
            d.addWidget(self.editeur)
        self.entrees.append(self.editeur)
        if self.editeur_externe:  # hors des entrées : le lien se corrige encore quand la question est soumise
            self.champ_lien = QLineEdit(self.lien)
            self.champ_lien.setPlaceholderText("https://www.pyxelstudio.net/studio/…")
            self.champ_lien.textChanged.connect(self._noter_lien)
            self.ligne_lien = QWidget()
            ligne = QHBoxLayout(self.ligne_lien)
            ligne.setContentsMargins(0, 0, 0, 0)
            ligne.addWidget(QLabel("Lien de ton projet Pyxel Studio :"))
            ligne.addWidget(self.champ_lien, 1)
            d.addWidget(self.ligne_lien)

    def _noter_lien(self, texte):
        self.lien = texte.strip()
        self.changee.emit()

    def mettre_a_jour(self):
        super().mettre_a_jour()
        if self.langage in ("python", "sql"):
            self.console.masquer_execution(self.sans_execution)
        (self.console if self.langage in ("python", "sql") else self.editeur).setHidden(self.editeur_externe)
        if self.editeur_externe:  # le lien se demande une fois, à la première de ces questions
            self.ligne_lien.setHidden(self.premiere_externe not in (None, self))

    def _rapatrier(self):
        """Un code écrit hors du lecteur (``editeur_externe``) : l'app.py du projet Pyxel Studio de l'élève, lu à chaque
        soumission, devient la saisie, que les ``tests_code`` corrigent comme celle d'un éditeur — et la copie garde
        l'état du programme à chaque étape. Sans lien, ou projet illisible, la question ne se soumet pas et le dit.
        Rend vrai quand la soumission peut suivre."""
        if not self.editeur_externe or self.fermee or not self.actif:
            return True
        premiere = self.premiere_externe or self
        if not premiere.lien:
            ici = "ci-dessous" if premiere is self else f"à la question {premiere.numero}"
            self._dire(f"*Donne d'abord le lien de ton projet Pyxel Studio, {ici} : c'est ton programme qui est corrigé.*")
            return False
        try:
            self._ecrire(pyxel_studio.code(premiere.lien))
        except ValueError as erreur:
            self._dire(f"*Ton projet n'a pas pu être lu : {erreur}.*")
            return False
        return True

    def _lire(self):
        return self.editeur.toPlainText() if self.editeur.toPlainText() != self.vierge() else None

    def _ecrire(self, valeur):
        # verrouillé, une saisie qui ne suit pas le gabarit (copie d'avant le verrouillage) n'aurait aucune zone où écrire
        if valeur is not None and self.editeur.fixes and noyau.zones_du_gabarit(self.editeur.fixes, valeur) is None:
            valeur = None
        self.editeur.setPlainText(self.vierge() if valeur is None else valeur)

    if navigateur():  # la correction attend un Web Worker : elle se fait AVANT la soumission, la question grisée
        verdicts = {}  # id -> {saisie, fraction, message}, ce que _verifier rend

        def _verifier(self, saisie):
            v = self.verdicts.get(self.id)
            return (v["fraction"], v["message"]) if v is not None and v["saisie"] == saisie else (None, None)

        def soumettre(self):
            """Sans verdict pour cette saisie, la question attend, grisée, que le worker l'ait corrigée, puis se soumet
            comme en natif ; sans test, ou déjà corrigée, rien à attendre. Une question figée avant le verdict (temps
            écoulé) reste « en attente » : le professeur la corrige. Déjà en correction, rien : « Corriger mes réponses »
            la soumettrait une seconde fois, et le second verdict lui ôterait sa seconde chance."""
            if getattr(self, "en_correction", False) or not self._rapatrier():
                return
            saisie, suite = self.saisie, super().soumettre
            if self.fermee or not self.actif or not self.testee() or self._verifier(saisie) != (None, None):
                return suite()

            def verdict(fraction, message):
                self.verdicts[self.id] = {"saisie": saisie, "fraction": fraction, "message": message}
                self._corrections.pop((saisie, self.classe), None)
                self.en_correction = False
                self.setEnabled(True)
                suite()

            self.en_correction = True
            self.setEnabled(False)
            self._dire("*Vérification en cours…*")
            # la correction native (subprocess.run, doublé par qtpy6 : un Web Worker attendu par JSPI) dans un slot,
            # seule entrée où l'attente est possible, la page restant vivante pendant ce temps
            QTimer.singleShot(0, lambda: verdict(*noyau.Code._verifier(self, saisie)))
    else:
        def soumettre(self):
            if self._rapatrier():
                super().soumettre()


class Sql(noyau.Sql, Code):
    pass


class Etiquette(QStyledItemDelegate):
    """Une étiquette de ``Classement`` ou d'``Ordre`` : son Markdown peint (un ``QListWidgetItem`` n'affiche que du
    texte nu, et l'élève lisait « **1** »), et sa hauteur calculée sur la largeur RÉELLE de sa colonne : celle que
    ``QListView`` estime avec ``setWordWrap`` ne suit pas le rétrécissement de la colonne, et l'étiquette longue
    finissait coupée d'un « … » au lieu d'aller à la ligne."""

    RETRAIT = 4  # l'écart entre le liseré et le texte, celui que le style laissait au texte nu

    def _document(self, police, texte):
        largeur = self.parent().viewport().width() - 2 * self.parent().spacing() - 2 * self.RETRAIT
        return memoriser(self, (police.key(), texte, largeur), functools.partial(self._composer, police, texte, largeur))

    @staticmethod
    def _composer(police, texte, largeur):
        document = QTextDocument()
        document.setDocumentMargin(0)
        document.setDefaultFont(police)
        document.setHtml(html_case(texte))
        document.setTextWidth(largeur)
        return document

    def initStyleOption(self, option, index):
        super().initStyleOption(option, index)
        option.text = ""  # le style ne dessine plus que le cadre ; le texte, c'est ``paint`` qui s'en charge
        # ni fond ni liseré bleu une fois cliquée, survolée ou déposée : le cadre reste gris, seule l'étiquette en cours
        # de glisser-déposer l'épaissit (``paint``) — demande de l'utilisateur, 28/09/2026
        option.state &= ~(QStyle.StateFlag.State_Selected | QStyle.StateFlag.State_MouseOver | QStyle.StateFlag.State_HasFocus)

    def paint(self, peintre, option, index):
        super().paint(peintre, option, index)
        document = self._document(option.font, index.data())
        peintre.save()
        peintre.translate(option.rect.topLeft()
                          + QPoint(self.RETRAIT, max(0, int((option.rect.height() - document.size().height()) / 2))))
        document.drawContents(peintre)
        peintre.restore()
        if index.row() in self.parent().glissees:
            peintre.save()
            peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
            peintre.setPen(QPen(option.palette.highlight().color(), 3))
            peintre.drawRoundedRect(QRectF(option.rect).adjusted(1.5, 1.5, -1.5, -1.5), 4, 4)
            peintre.restore()

    def sizeHint(self, option, index):
        return self.taille(option.font, index.data())

    def taille(self, police, texte):
        return QSize(self.parent().viewport().width() - 2 * self.parent().spacing(),
                     math.ceil(self._document(police, texte).size().height()) + 2 * tactile.marge() + 4)


class Colonne(QListWidget):
    """Une liste d'étiquettes (colonne d'un ``Classement``, liste d'un ``Ordre``) : sa largeur change la hauteur de ses
    étiquettes, donc la sienne."""

    def __init__(self, ajuster):
        super().__init__()
        self.ajuster = ajuster
        self.glissees = set()  # les rangs des étiquettes en cours de glisser-déposer, au cadre épaissi
        self.rendre = None  # ce que fait un double appui sur une étiquette (``Classement`` : la renvoyer à la réserve)
        self._appui = (None, 0)  # l'étiquette du dernier appui, et son instant (ms)

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.ajuster()

    def startDrag(self, actions):
        self.glissees = {index.row() for index in self.selectedIndexes()}
        try:
            super().startDrag(actions)  # l'image qui suit le doigt ou la souris est peinte avec le cadre épais
        finally:
            self.glissees = set()
            self.viewport().update()

    def _double(self, evenement):
        """Le double appui compté à la main, au second appui sur la même étiquette : ni la souris ni le doigt ne livrent
        la même suite d'événements. La souris envoie un appui PUIS un double clic ; le doigt, un double clic SEUL (mesuré
        par ``QTest.touchEvent``, 28/09/2026 : l'étiquette ne revenait jamais dans « À classer »). Compter les deux,
        l'étiquette renvoyée n'étant plus là pour le second, les réunit ; le double clic de ``QListWidget``, lui, ouvrirait
        l'édition."""
        element, instant = self.itemAt(evenement.position().toPoint()), evenement.timestamp()
        double = (element is not None and element is self._appui[0]
                  and instant - self._appui[1] <= QApplication.styleHints().mouseDoubleClickInterval())
        self._appui = (None if double else element, instant)
        if double:
            self.rendre(element)
        return double

    def mousePressEvent(self, evenement):
        if self.rendre is None or not self._double(evenement):
            super().mousePressEvent(evenement)

    def mouseDoubleClickEvent(self, evenement):
        if self.rendre is None:
            super().mouseDoubleClickEvent(evenement)
        else:
            self._double(evenement)


def etiquettes(ajuster):
    """Une ``Colonne`` d'étiquettes à glisser, qui vont à la ligne plutôt que d'être coupées."""
    liste = Colonne(ajuster)
    liste.setDefaultDropAction(Qt.DropAction.MoveAction)
    liste.setWordWrap(True)
    liste.setSpacing(2)  # des étiquettes séparées, pas des lignes ; la marge d'une feuille de style, elle, fausserait le retour à la ligne
    liste.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    liste.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # la hauteur tient tout ; une barre rétrécirait le texte, qui passerait à la ligne et déborderait
    liste.setResizeMode(QListWidget.ResizeMode.Adjust)  # recalcule les hauteurs quand la colonne change de largeur
    liste.setItemDelegate(Etiquette(liste))
    liste.setStyleSheet(f"QListWidget::item {{ border: 1px solid #b0b0b0; border-radius: 4px; padding: {tactile.marge()}px 0; }}")
    return liste


def hauteur_etiquettes(liste, textes):
    """La hauteur qui tient toutes ces étiquettes, sans vide dessous, à la largeur actuelle de ``liste``."""
    etiquette, police, marge = liste.itemDelegate(), liste.font(), liste.spacing()
    return sum(etiquette.taille(police, t).height() + 2 * marge for t in textes) + 2 * liste.frameWidth()  # l'espacement, dessus et dessous


class Classement(noyau.Classement, Question):

    def _corps(self, d):
        """Un tableau comme sur papier : une colonne par catégorie, où glisser les étiquettes depuis la réserve
        « À classer », à gauche. Chaque colonne est une liste qui peut contenir tous les éléments : on dépose
        aussi dans une colonne vide, et un double-clic renvoie l'étiquette à la réserve."""
        grille = QGridLayout()
        self.colonnes = []  # la réserve, puis les catégories dans l'ordre de ``categories``
        for k, titre in enumerate(["À classer", *self.categories]):
            grille.addWidget(Texte(f"*{titre}*" if k == 0 else f"**{titre}**", inline=True), 0, k)
            liste = etiquettes(self._ajuster)
            liste.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
            if k:
                liste.rendre = functools.partial(self._rendre, liste)
            grille.addWidget(liste, 1, k)
            grille.setColumnStretch(k, 1)
            self.colonnes.append(liste)
        d.addWidget(Texte("*Glissez chaque élément dans sa colonne (double-clic : il revient dans « À classer »).*", inline=True))
        d.addLayout(grille)
        self.entrees += self.colonnes
        self._ecrire(None)

    def _ajuster(self):
        """Toutes les colonnes à la hauteur de la réserve pleine : de quoi tenir tous les éléments, sans vide dessous.
        Les colonnes ont la même largeur, donc chaque étiquette la même hauteur dans n'importe laquelle."""
        reserve = self.colonnes[0] if len(self.colonnes) == len(self.categories) + 1 else None
        if reserve is None:
            return  # colonnes en cours de création
        hauteur = hauteur_etiquettes(reserve, (e.texte for e in self.elements))
        for liste in self.colonnes:
            liste.setFixedHeight(hauteur)

    def _rendre(self, liste, element):
        self.colonnes[0].addItem(liste.takeItem(liste.row(element)))

    def _lire(self):
        choix = [None] * len(self.elements)
        for k, liste in enumerate(self.colonnes[1:]):
            for rang in range(liste.count()):
                choix[liste.item(rang).data(Qt.ItemDataRole.UserRole)] = k
        return None if all(c is None for c in choix) else choix

    def _ecrire(self, valeur):
        for liste in self.colonnes:
            liste.clear()
        for i in self.depart:
            element = QListWidgetItem(self.elements[i].texte)
            element.setData(Qt.ItemDataRole.UserRole, i)
            self.colonnes[0 if valeur is None or valeur[i] is None else valeur[i] + 1].addItem(element)


class Personnalise(noyau.Personnalise, Question):
    """Le widget écrit par le professeur (voir ``noyau.Personnalise``) : son code est exécuté ici, avec pour noms de
    départ ceux de ce module (les classes Qt, ``Texte``, ``hauteur``…)."""

    def _corps(self, d):
        self.message = Texte()
        self.message.setStyleSheet("QTextBrowser { background: transparent; color: #c0392b; }")
        d.addWidget(self.message)
        try:
            espace = dict(globals())
            exec(compile(self.widget, f"<widget {self.id}>", "exec"), espace)  # noqa: S102 - c'est le principe : le code du professeur
            absentes = [nom for nom in ("corps", "lire", "ecrire", "corriger") if not callable(espace.get(nom))]
            if absentes:
                raise NameError("fonctions absentes : " + ", ".join(absentes))
            self.fonctions = espace
        except Exception as exc:  # noqa: BLE001 - n'importe quelle erreur du code du professeur
            self._casser("widget", exc)
            return
        self._appeler("corps", None, d)

    def _casser(self, quoi, exc):
        super()._casser(quoi, exc)
        self.message.definir(f"**Question en panne** : {self.panne}\n\nSignalez-la : elle sera corrigée à la main.")

    def _lire(self):
        return self._appeler("lire", None)

    def _ecrire(self, valeur):
        self._appeler("ecrire", None, valeur)


class Groupe(noyau.Groupe, Question):

    def _corps(self, d):
        for sq in self.sous_questions:
            d.addWidget(sq)

    def numeroter(self, numero=None):
        """Le barème d'une sous-question entre parenthèses : le détail du total, pas des points en plus."""
        super().numeroter(numero)
        for sq in self.sous_questions:
            sq.parentheses = True
            sq.afficher_bareme()


class Banque(noyau.Banque, QWidget):
    """Affichée, la banque montre ses questions corrigées."""

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)
        self.corrigee = False
        d = QVBoxLayout(self)
        d.addWidget(Texte(f"# {self.matiere}\n\n{self.niveau} {self.theme}".rstrip()))
        d.addWidget(defilant(self.questions))
        self.resize(900, 800)

    def showEvent(self, evenement):
        """Affichée, la banque montre ses questions corrigées (une seule fois : ce n'est pas son état enregistré)."""
        if not self.corrigee:
            self.corrigee = True
            for q in self.questions:
                q.presenter_corrige()
        super().showEvent(evenement)


class Paresse(QObject):
    """Seules les questions à moins d'un écran de la vue sont remises en page : la disposition des autres est
    désactivée (``QLayout.setEnabled``), et un redimensionnement ne relit plus que leurs textes, pas les 684 d'un
    sujet de 85 questions (mesuré hors écran sur la révision NSI Terminale : 20 redimensionnements, 968 → 480 ms ;
    40 crans de molette, 150 → 220 ms, le prix des réveils).
    Une question qui approche de l'écran est réveillée, et le défilement compensé pour que ce qui est à l'écran ne
    bouge pas. Choix, pièges et tests : ``Notes/QCM - Réactivité du lecteur.md``."""

    MARGE = 1  # en hauteurs de vue, au-dessus et au-dessous de l'écran

    def __init__(self, zone, questions):
        super().__init__(zone)
        self.zone, self.contenu, self.questions = zone, zone.widget(), questions
        zone.verticalScrollBar().valueChanged.connect(self.rafraichir)
        zone.viewport().installEventFilter(self)
        self.rafraichir()

    def eventFilter(self, objet, evenement):
        if evenement.type() == QEvent.Type.Resize:
            QTimer.singleShot(0, self, self.rafraichir)  # après la mise en page que ce Resize déclenche
        return False

    def _haut(self, q):
        return q.mapTo(self.contenu, QPoint()).y() - self.zone.verticalScrollBar().value()

    def _en_vue(self, q):
        vue, haut = self.zone.viewport().height(), self._haut(q)
        return haut + q.height() > -self.MARGE * vue and haut < (1 + self.MARGE) * vue

    def rafraichir(self):
        barre = self.zone.verticalScrollBar()
        repere = next((q for q in self.questions if self._haut(q) + q.height() > 0), None)
        avant = self._haut(repere) if repere else 0
        reveillees = []
        for q in self.questions:
            disposition, en_vue = q.layout(), self._en_vue(q)
            if en_vue and not disposition.isEnabled():
                disposition.setEnabled(True)
                disposition.invalidate()
                # un LayoutRequest reçu désactivée l'a laissée « à refaire », état où Qt n'en reposte plus : sans cet
                # appel, une question gelée dès la construction du sujet ne serait jamais mise en page
                disposition.activate()
                reveillees.append(q)
            elif not en_vue and disposition.isEnabled():
                disposition.setEnabled(False)
        if reveillees and repere:
            # la hauteur corrigée remonte niveau par niveau (question, section, contenu, zone défilante), chacun par
            # un LayoutRequest différé, et un tableau recalcule ses lignes par sa minuterie : tout est fait tout de
            # suite, pour compenser le défilement sur des positions définitives
            # une question de type tableau EST un Tableau : la question elle-même compte
            tableaux = [t for q in reveillees for t in [q, *q.findChildren(Tableau)] if isinstance(t, Tableau)]
            for _ in range(5):
                QCoreApplication.sendPostedEvents(None, QEvent.Type.LayoutRequest)
                for tableau in tableaux:
                    if tableau.hauteurs.isActive():
                        tableau.hauteurs.stop()
                        tableau._ajuster()
            barre.setValue(barre.value() + self._haut(repere) - avant)


def defilant(widgets):
    """Une zone défilante qui empile ``widgets``."""
    zone, contenu = ZoneDefilante(), QWidget(objectName="contenu")  # dans le navigateur, seule la bande qui entre est repeinte
    zone.setWidgetResizable(True)
    # par la feuille de style, pas par setFont : un widget qui a la sienne (Texte, listes, tableaux) n'hérite pas
    # de la police de son parent ; la taille seule, la famille et le gras de chacun restent les siens. Le fond aussi :
    # Breeze peint le viewport au gris de la fenêtre, plus sombre que le fond du sujet qu'on voit autour (séparateur
    # du cours, l'utilisateur, 29/09/2026) ; une feuille de style passe devant le thème
    contenu.setStyleSheet(f"QWidget {{ font-size: {TAILLE_POLICE}pt; }} QWidget#contenu {{ background: {fond_sujet().name()}; }}")
    contenu.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
    empile = QVBoxLayout(contenu)
    for w in widgets:
        empile.addWidget(w)
    empile.addStretch()
    zone.setWidget(contenu)
    tactile.defiler_au_doigt(zone)  # au doigt, la page défile comme partout ailleurs sur un téléphone
    Paresse(zone, [q for q in contenu.findChildren(Question) if not isinstance(q.parentWidget(), Question)])
    return zone


def encadre(markdown):
    """Les consignes du sujet dans le cadre vert des cours du professeur (fond et bordure relevés dans « Les réseaux
    sociaux.docx ») : en tête de la zone qui défile, elles s'effacent de la vue dès que l'élève descend aux questions."""
    cadre = QFrame(objectName="consignes")
    cadre.setStyleSheet("QFrame#consignes { background: #eefae6; border: 1px solid #6b934e; }")
    d = QVBoxLayout(cadre)
    d.setContentsMargins(10, 8, 10, 8)
    d.addWidget(Texte(markdown))
    return cadre


class Section(noyau.Section, QWidget):
    """Son titre et ses consignes se voilent comme ses questions une fois toutes traitées ou soumises : le voile des
    traitées tant qu'elles ne sont pas toutes soumises (demande de l'utilisateur, 27/09/2026). Posé, comme celui d'une
    question, sur le contenu de la zone défilante, de toute sa largeur, jusqu'à la première question."""

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)
        d = QVBoxLayout(self)
        self.entete = [Texte(texte) for texte in (self.titre and f"## {self.titre}", self.consignes) if texte]
        for w in self.entete:
            d.addWidget(w)
        self.feuilles = [f for q in self.questions if isinstance(q, Question) for f in q.feuilles()]
        for q in self.questions:
            if isinstance(q, Question):
                d.addWidget(q)
        self.voile = Voile(self) if self.entete and self.feuilles else None
        if self.voile:
            for f in self.feuilles:
                f.changee.connect(self._poser_voile)
            self.installEventFilter(self)

    def eventFilter(self, objet, evenement):
        if evenement.type() in (QEvent.Type.Move, QEvent.Type.Resize, QEvent.Type.Show, QEvent.Type.ParentChange):
            self._poser_voile()
        return False

    def _poser_voile(self):
        v, hote = vars(self).get("voile"), self.parentWidget()
        if not v or hote is None:
            return
        if v.parentWidget() is not hote:
            v.setParent(hote)
        premiere = next((w for w in self.children() if isinstance(w, Question) and not w.isHidden()), None)
        bas = premiere.y() if premiere else self.height()
        v.setGeometry(0, self.y(), hote.width(), bas)
        v.teinter(Voile.niveau(self.feuilles), self.isVisible())
        v.raise_()


COULEURS = {"vert": "#92d050", "bleu": "#00b0f0", "rouge": "#ff0000", "or": "#ffc000"}


def barre(intitule, couleur):
    """Une jauge de 0 à 100 %, son intitulé écrit dedans : ce qu'elle mesure se lit sans légende. Fine : la police de
    l'interface, et la hauteur de son texte, bordure comprise — deux empilées font celle d'un bouton (l'utilisateur, 02/10/2026)."""
    b = QProgressBar()
    b.setRange(0, 100)
    b.setFormat(intitule)
    b.setAlignment(Qt.AlignmentFlag.AlignCenter)
    police = QApplication.font()
    police.setItalic(True)
    b.setFont(police)
    b.setFixedHeight(QFontMetrics(police).height() + 2)
    colorer(b, couleur)
    return b


def colorer(barre, couleur):
    """Remplit ``barre`` de la couleur nommée ; sans effet si c'est déjà la sienne (le chronomètre appelle chaque seconde)."""
    if barre.property("couleur") != couleur:
        barre.setProperty("couleur", couleur)
        # l'arrondi des boutons voisins, 2 px en Fusion, le style du lecteur ici comme dans le navigateur (demande de l'utilisateur, 27/09/2026)
        barre.setStyleSheet("QProgressBar { border: 1px solid #a0a0a0; border-radius: 2px; background: #f2f2f2; color: #707070; }"
                            f"QProgressBar::chunk {{ background: {COULEURS[couleur]}; border-radius: 1px; }}")


class Paquet(noyau.Paquet, QWidget):
    """Le widget du paquet : une entête (TOUS les boutons globaux, les jauges, le bilan) et le sujet, défilant sur toute
    la largeur, ou une question par écran, le titre et le visuel en tête. La logique est celle de ``noyau.Paquet``."""

    finie = Signal()  # l'épreuve vient de se terminer (bouton, fin du temps) : la copie est à enregistrer
    annotee = Signal()  # le professeur vient de changer la note ou l'appréciation : la copie est à enregistrer

    def __init__(self, *args, **kw):
        application()
        QWidget.__init__(self)
        super().__init__(*args, **kw)

    def _construire(self):
        self._noter()
        palette = self.palette()
        palette.setColor(self.backgroundRole(), fond_sujet())
        self.setPalette(palette)
        self.setAutoFillBackground(True)
        # Deux parties : une entête, une seule rangée (la navigation, les jauges, ce qui termine) et le bilan ; puis le
        # sujet, qui défile sur toute la largeur et commence comme la copie papier, par le titre, le sous-titre, le visuel
        # du thème et le cadre de la note (l'utilisateur, 02/10/2026 : dans l'entête, ils prenaient la place du sujet, et
        # il fallait une poignée pour les rogner ; 26/09 : la colonne de droite décentrait le titre).
        d = QVBoxLayout(self)
        d.setContentsMargins(0, 0, 0, 0)
        d.setSpacing(0)
        bandeau = QWidget()  # l'entête a son propre fond, celui de la barre de titre
        palette = bandeau.palette()
        fond_entete(palette)
        bandeau.setPalette(palette)
        bandeau.setAutoFillBackground(True)
        bandeau.setStyleSheet(f"QPushButton {{ font-size: {TAILLE_POLICE}pt; }}")  # la taille du sujet (``defilant``)
        entete = QVBoxLayout(bandeau)
        entete.setContentsMargins(9, 9, 9, 4)  # le trait tout de suite sous les boutons (l'utilisateur, 01/10/2026)
        entete.setSpacing(6)  # sans quoi les dispositions imbriquées héritent du 0 de ``d`` : boutons collés
        # Le titre et le visuel centrés ; le bilan de la copie rendue vient dessous, avant les consignes (``_cadre_note``).
        self.haut = QWidget()
        # pas plus haut que son contenu : le titre est Expanding, et l'en-tête prendrait sinon toute la hauteur libre
        self.haut.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
        gauche = QVBoxLayout(self.haut)
        gauche.setContentsMargins(0, 0, 0, 0)
        titre = Texte(self.entete())
        bloc = titre.document().begin()
        while bloc.isValid():  # le sous-titre sous le titre, pas à la distance qui sépare deux paragraphes
            format_ = bloc.blockFormat()
            format_.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            if format_.headingLevel() in (1, 2):
                format_.setBottomMargin(0) if format_.headingLevel() == 1 else format_.setTopMargin(4)
            QTextCursor(bloc).setBlockFormat(format_)
            bloc = bloc.next()
        image = entete_harmonisee(titre.document(), QImage.fromData(self.medias[LOGO]) if LOGO in self.medias else None)
        gauche.addWidget(titre)
        if image:
            visuel = QLabel()
            visuel.setPixmap(image)
            gauche.addWidget(visuel, 0, Qt.AlignmentFlag.AlignHCenter)
        self.barre_temps, self.barre_avancement = barre("temps écoulé", "bleu"), barre("avancement réponses", "vert")
        self.barre_bonus = barre("bonus", "or") if self.feuilles_bonus else None
        mesure = QFontMetrics(self.barre_temps.font())
        for b, texte in ((self.barre_temps, "temps écoulé : 0 h 00 min 00 s"), (self.barre_avancement, "avancement réponses"),
                         (self.barre_bonus, "bonus")):  # un minimum fixe : le chronomètre ne fait pas bouger la rangée à chaque seconde
            if b is not None:
                b.setMinimumWidth(mesure.horizontalAdvance(texte) + 16)
        # Les jauges empilées, l'avancement au-dessus du temps et de même largeur : où l'on en est par rapport au temps se
        # lit d'un coup d'œil (l'utilisateur, 02/10/2026) ; à droite de l'avancement, le bonus, large comme sa part des questions.
        self.jauges = QWidget()
        jauges = QVBoxLayout(self.jauges)
        jauges.setContentsMargins(0, 0, 0, 0)
        jauges.setSpacing(1)
        avancement = QHBoxLayout()
        avancement.setSpacing(1)
        avancement.addWidget(self.barre_avancement, len(self.feuilles) - len(self.feuilles_bonus))
        if self.barre_bonus is not None:
            avancement.addWidget(self.barre_bonus, len(self.feuilles_bonus))
        jauges.addLayout(avancement)
        jauges.addWidget(self.barre_temps)
        # Deux gestes nommés par leur conséquence, et seulement ceux qui ont un sens dans CE sujet (demande de
        # l'utilisateur, 25/09/2026 : « Soumettre toutes les questions » et « Terminer » ne se distinguaient pas, et le
        # premier ne servait à rien sans seconde chance, le cas d'une évaluation sommative).
        self.bouton_tout = QPushButton("Corriger mes réponses")
        self.bouton_tout.setToolTip("Corrige toutes les questions encore ouvertes sans terminer l'épreuve : une réponse fausse "
                                    "peut être reprise, à points réduits, tant qu'il reste du temps.")
        self.bouton_tout.clicked.connect(self._corriger_tout)
        self.bouton_tout.setVisible(self.rejouable())
        self.bouton_terminer = QPushButton("Rendre ma copie")
        self.aide_terminer = ("Fin de l'épreuve : les questions encore ouvertes sont figées telles quelles, sans reprise possible"
                              + (", puis la note et la correction s'affichent." if self.corrigee() else
                                 ", puis la note et la correction s'afficheront à l'échéance." if self.correction else "."))
        self.bouton_terminer.setToolTip(self.aide_terminer)
        self.bouton_terminer.clicked.connect(self._rendre_copie)
        self.precedent, self.suivant = QPushButton("Précédent"), QPushButton("Suivant")
        self.prec_libre, self.suiv_libre = QPushButton("◀ Non traitée"), QPushButton("Non traitée ▶")
        self.precedent.clicked.connect(self._pas)
        self.suivant.clicked.connect(self._pas)
        self.prec_libre.clicked.connect(self._non_traitee)
        self.suiv_libre.clicked.connect(self._non_traitee)
        rangee = Rangee(6, uniforme=True)  # passe à la ligne à la largeur d'un téléphone, au lieu d'imposer la sienne au sujet
        self.panneau_cours = None  # lu à la première ouverture (``_montrer_cours``)
        if self.acces_cours and self.cours:
            self.bouton_cours = QPushButton("Cours", checkable=True)
            self.bouton_cours.setToolTip("Ouvrir ou fermer le cours, à côté des questions")
            self.bouton_cours.toggled.connect(self._montrer_cours)
            self.bouton_cours.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            rangee.addWidget(self.bouton_cours)
        # les boutons et les jauges se partagent la largeur à parts égales ; tous prennent la hauteur de la ligne, celle
        # des boutons (``Preferred`` : elle peut grandir) (demandes de l'utilisateur, 26/09/2026)
        for w in (self.precedent, self.suivant, self.prec_libre, self.suiv_libre, self.bouton_tout, self.bouton_terminer, self.jauges):
            w.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        for b in (self.precedent, self.suivant) if self.affichage == "question" else ():
            rangee.addWidget(b)
        if self.affichage == "question":
            rangee.addSpacing(18)  # deux groupes : l'écran voisin, puis la question voisine encore à traiter
        rangee.addWidget(self.prec_libre)
        rangee.addWidget(self.suiv_libre)
        for w in (self.jauges, self.bouton_tout, self.bouton_terminer):
            rangee.addWidget(w)
        entete.addLayout(rangee)
        self.bilan = Texte()
        entete.addWidget(self.bilan)
        d.addWidget(bandeau)
        trait = QWidget()  # le bord de l'entête : un trait sombre d'un pixel (l'utilisateur, 01/10/2026)
        trait.setFixedHeight(1)
        palette = trait.palette()
        palette.setColor(trait.backgroundRole(), palette.color(QPalette.ColorRole.Dark))
        trait.setPalette(palette)
        trait.setAutoFillBackground(True)
        d.addWidget(trait)
        tete = [self.haut, self._cadre_note(), *([encadre(self.consignes)] if self.consignes else [])]  # en tête du sujet
        if self.affichage == "question":
            self.pile = QStackedWidget()
            for n, q in enumerate(self.pages):  # sur le premier écran seulement
                page = defilant([*tete, q] if n == 0 else [q])
                page.setFrameShape(QFrame.Shape.NoFrame)
                self.pile.addWidget(page)
            self.pile.setCurrentIndex(min(self.courante, len(self.pages) - 1))
            corps = self.pile
        else:
            self.defilement = corps = defilant([*tete, *self.sections])
            self.defilement.setFrameShape(QFrame.Shape.NoFrame)
        if self.acces_cours and self.cours:  # les questions à gauche, le cours à droite, la limite déplaçable
            self.separation = QSplitter(Qt.Orientation.Horizontal)
            self.separation.addWidget(corps)
            corps = self.separation
        d.addWidget(corps, 1)
        if self.affichage != "question":
            self.descente = QPropertyAnimation(self.defilement.verticalScrollBar(), b"value", self, duration=DESCENTE_MS,
                                               easingCurve=QEasingCurve.Type.OutCubic)
            self.attente = QTimer(self, singleShot=True, timeout=self._descendre)
        self.resize(900, 800)
        super()._construire()

    def _panneau_cours(self):
        """Les PDF du cours (``cours``), un onglet chacun, caché jusqu'au bouton « Cours », lus à sa première ouverture
        (``lire_cours``). Le texte s'y sélectionne et se copie ; dans le navigateur, qtpy6 les dessine par pdf.js dans un bloc
        de la page, dont la lecture ne compte pas comme une sortie sous ``surveillance``, et que l'écran noir cache (paquet
        désactivé)."""
        from qtpy6.QtPdf import QPdfDocument  # noqa: PLC0415 - QtPdf n'est chargé que pour un sujet qui a un cours
        from qtpy6.QtPdfWidgets import QPdfView  # noqa: PLC0415

        onglets = QTabWidget(tabBarAutoHide=True, documentMode=True)
        for chemin in self.cours:
            octets = self.lire_cours(chemin)
            if octets is None:
                onglets.addTab(QLabel(f"Cours introuvable : {Path(chemin).name}", alignment=Qt.AlignmentFlag.AlignCenter),
                               Path(chemin).stem)
                continue
            vue = QPdfView()
            vue.setPageMode(QPdfView.PageMode.MultiPage)
            vue.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            vue.setPageLimit(self.cours_pages)  # pas au-delà du cours vu en classe (qtpy6)
            vue.setDocumentMargins(QMargins())  # la page à pleine largeur, seul l'écart entre pages reste (l'utilisateur, 29/09/2026)
            document = QPdfDocument(vue)
            tampon = QBuffer(document)  # lu au fil des pages : il vit aussi longtemps que le document
            tampon.setData(QByteArray(octets))
            tampon.open(QBuffer.OpenModeFlag.ReadOnly)
            document.load(tampon)
            vue.setDocument(document)
            onglets.addTab(vue, Path(chemin).stem)
        return onglets

    def _montrer_cours(self, ouvert):
        if self.panneau_cours is None:
            self.panneau_cours = self._panneau_cours()
            self.separation.insertWidget(0, self.panneau_cours)  # à gauche des questions (l'utilisateur, 29/09/2026)
        self.panneau_cours.setVisible(ouvert)
        if ouvert:  # le cours prend un peu moins de la moitié de la largeur, à chaque ouverture
            largeur = self.separation.width()
            self.separation.setSizes([largeur * 9 // 20, largeur * 11 // 20])

    def recharger_cours(self):
        """Le panneau du cours construit avant que ``lire_cours`` ait ses PDF (« Cours introuvable » : dans le navigateur, ils
        arrivent après l'ouverture de l'épreuve) est jeté, et refait tout de suite s'il est ouvert."""
        if self.panneau_cours is not None:
            self.panneau_cours.deleteLater()
            self.panneau_cours = None
            if self.bouton_cours.isChecked():
                self._montrer_cours(True)

    RESSORTS_MAX = 4  # points forts et points à travailler repris en tête du rapport, de chaque côté

    def _cadre_note(self):
        """Le bilan de la copie rendue, entre le titre et les consignes, de toute la largeur (demande de l'utilisateur,
        02/10/2026) : la note, écrite à la main par le professeur (``POLICE_MAIN``, en rouge) — ``noter`` la rend
        modifiable —, sinon celle de la machine ; le détail de la partie obligatoire et du rattrapage par les bonus ;
        l'appréciation ; et le rapport de l'élève, réussite par thème, sous-thème, compétence, capacité, niveau de Bloom
        et catégorie de la pensée informatique (``noyau.Paquet.statistiques``), ses points forts et ce qu'il doit
        travailler en tête. Absent pendant l'épreuve, rapport et détail absents tant que la correction ne se montre pas."""
        self.cadre_note = cadre = QFrame()
        cadre.setObjectName("cadre_note")
        cadre.setStyleSheet("#cadre_note { border: 1px solid palette(mid); border-radius: 4px; background: palette(base); }"
                            f" QLineEdit, QPlainTextEdit, #libelle_total {{ border: none; background: transparent;"
                            f" color: #c0392b; font-family: {POLICE_MAIN}; font-size: {TAILLE_MAIN}pt; }}"
                            f" QLabel {{ font-size: {TAILLE_POLICE}pt; }} #libelle_note {{ font-weight: bold; }}"
                            " #champ_appreciation { font-weight: bold; }")  # le texte du sujet
        d = QVBoxLayout(cadre)
        grille = QGridLayout()
        grille.setColumnStretch(1, 1)
        d.addLayout(grille)
        self.champ_note, self.champ_appreciation = QLineEdit(), QPlainTextEdit()
        self.champ_appreciation.setObjectName("champ_appreciation")
        self.champ_note.setFixedWidth(QFontMetrics(self.champ_note.font()).horizontalAdvance("00,00") * 2)
        self.champ_note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main = QFontMetrics(QFont(POLICE_MAIN, TAILLE_MAIN))  # la feuille de style ne s'applique qu'à l'affichage
        self.champ_appreciation.setFixedHeight(3 * main.lineSpacing() + 12)  # trois lignes d'écriture, toute la largeur
        self.champ_note.editingFinished.connect(self._lire_note)
        self.champ_appreciation.textChanged.connect(self._lire_appreciation)
        note = QHBoxLayout()
        note.addWidget(self.champ_note)
        libelle_total = QLabel(f"/ {self.total:g}")
        libelle_total.setObjectName("libelle_total")
        note.addWidget(libelle_total)
        self.libelle_detail = QLabel()  # partie obligatoire et rattrapage, si le sujet a des bonus
        note.addSpacing(12)
        note.addWidget(self.libelle_detail)
        note.addStretch()
        libelle = QLabel("Note :")
        libelle.setObjectName("libelle_note")
        grille.addWidget(libelle, 0, 0)
        grille.addLayout(note, 0, 1)
        grille.addWidget(QLabel("Appréciation :"), 1, 0, Qt.AlignmentFlag.AlignTop)
        grille.addWidget(self.champ_appreciation, 1, 1)
        self.libelle_sorties = QLabel()  # les sorties d'une épreuve sous surveillance (``lecteur.Lecteur.baisser``)
        grille.addWidget(self.libelle_sorties, 2, 0, 1, 2)
        self.libelle_forces = QLabel(wordWrap=True, textFormat=Qt.TextFormat.RichText)
        d.addWidget(self.libelle_forces)
        self.rapport = QWidget()  # un tableau par axe, qui passent à la ligne à la largeur d'un téléphone
        self.rangee_rapport = Rangee(24)
        self.rapport.setLayout(self.rangee_rapport)
        d.addWidget(self.rapport)
        self.statistiques_montrees = None
        self.champ_appreciation.setPlainText(self.appreciation)
        self.professeur = False
        self._afficher_note()
        return cadre

    def noter(self, professeur):
        """Le professeur (``lecteur`` : sa machine, qui a son mot de passe) écrit la note et l'appréciation d'une copie
        rendue ; l'élève les lit, sans pouvoir les changer."""
        self.professeur = professeur
        self._afficher_note()

    def _afficher_note(self):
        self.cadre_note.setVisible(self.fin is not None)  # rien pendant l'épreuve (demande de l'utilisateur, 27/09/2026)
        for champ in (self.champ_note, self.champ_appreciation):
            champ.setReadOnly(not (self.professeur and self.fin is not None))
        corrigee = self.corrigee() and self.fin is not None
        obtenus = self.resultat()[0] if corrigee else None
        # les bonus rattrapent des points perdus ailleurs, sans dépasser le total (``noyau.Section``)
        note = self.note if self.note is not None else None if obtenus is None else min(obtenus, self.total)
        self.champ_note.setText("" if note is None else f"{note:g}".replace(".", ","))
        gagnes, possibles = self.bonus()
        self.libelle_detail.setVisible(corrigee and bool(self.feuilles_bonus))
        if corrigee and self.feuilles_bonus:
            self.libelle_detail.setText(f"partie obligatoire : {obtenus - gagnes:g} / {self.total:g}  ·  rattrapage par les bonus :"
                                        f" + {gagnes:g} (sur {possibles:g})".replace(".", ","))
        self.libelle_sorties.setVisible(bool(self.sorties))
        self.libelle_sorties.setText(sorties_de_l_epreuve(self.sorties))
        self._afficher_rapport(self.statistiques() if corrigee else [])

    def _afficher_rapport(self, statistiques):
        """Les tableaux du rapport, refaits seulement s'ils ont changé ; une réussite d'au moins ``SEUIL_FORT`` en vert,
        sous ``SEUIL_FAIBLE`` en rouge, et ces lignes-là reprises en tête, en points forts et points à travailler."""
        if statistiques == self.statistiques_montrees:
            return
        self.statistiques_montrees = statistiques
        while (element := self.rangee_rapport.takeAt(0)) is not None:
            tableau = element.widget()
            tableau.setParent(None)  # tout de suite : ``deleteLater`` attend le retour à la boucle d'événements
            tableau.deleteLater()
        nom = html.escape  # tel qu'écrit : une majuscule ajoutée ferait « Str » ou « For » des noms de Python
        virgule = lambda x: f"{round(x, 2):g}".replace(".", ",")
        lignes_vues = []
        for axe, lignes in statistiques:
            rangs = []
            for libelle, gagne, note in lignes:
                taux = gagne / note
                couleur = noyau.VERT if taux >= noyau.SEUIL_FORT else "#c0392b" if taux < noyau.SEUIL_FAIBLE else ""
                lignes_vues.append((taux, note, nom(libelle)))
                rangs.append(f"<tr><td>{nom(libelle)}</td><td align='right' style='padding-left: 10px; color: {couleur or 'black'}'>"
                             f"<b>{round(100 * taux)} %</b></td><td align='right' style='padding-left: 8px; color: gray'>"
                             f"{virgule(gagne)} / {virgule(note)}</td></tr>")
            tableau = QLabel(f"<b>{axe}</b><table cellspacing='0' cellpadding='1'>{''.join(rangs)}</table>",
                             textFormat=Qt.TextFormat.RichText)
            tableau.setAlignment(Qt.AlignmentFlag.AlignTop)
            self.rangee_rapport.addWidget(tableau)
        # en tête, les RESSORTS_MAX plus nets de chaque côté : les mieux réussis, et à réussite égale ceux qui portent le
        # plus de points (une réussite sur beaucoup de points en dit plus long) ; un libellé vu sur deux axes, une fois
        lignes_vues.sort(key=lambda ligne: (-ligne[0], -ligne[1]))
        forts = [nom_ for taux, _, nom_ in lignes_vues if taux >= noyau.SEUIL_FORT]
        faibles = [nom_ for taux, _, nom_ in sorted(lignes_vues, key=lambda ligne: (ligne[0], -ligne[1])) if taux < noyau.SEUIL_FAIBLE]
        resume = [f"<b>{titre}</b> : {', '.join(list(dict.fromkeys(liste))[:self.RESSORTS_MAX])}" for titre, liste in
                  (("Points forts", forts), ("À travailler", faibles)) if liste]
        self.libelle_forces.setText("<br>".join(resume))
        self.libelle_forces.setVisible(bool(resume))
        self.rapport.setVisible(bool(statistiques))

    def _lire_note(self):
        texte = self.champ_note.text().strip().replace(",", ".")
        try:
            self.note = float(texte) if texte else None
        except ValueError:
            pass
        self._afficher_note()
        self.annotee.emit()

    def _lire_appreciation(self):
        self.appreciation = self.champ_appreciation.toPlainText()
        self.annotee.emit()

    def _afficher_page(self, n):
        self.pile.setCurrentIndex(n)

    def _suite(self, feuille):
        """La question qui vient d'être soumise reste un instant sous les yeux avant que la vue ne se recale dessus : un
        mouvement immédiat la faisait disparaître sans que l'élève comprenne où elle était passée."""
        if self.affichage != "sujet":
            return super()._suite(feuille)
        self.attente.stop()  # tout changement annule la descente en attente : « Modifier » pendant la pause la retient
        self.descente.stop()
        super()._suite(feuille)
        if self.attente.isActive():  # une descente vient d'être demandée : elle attend la fin de la pause
            self.attente.start(PAUSE_MS)

    def _devant(self):
        """Parmi les questions ouvertes visibles à l'écran, celle sous la souris, sinon la plus haute."""
        libres = [f for q in self._page() for f in q.feuilles()
                  if f.actif and not (f.fermee or f.cachee) and not f.visibleRegion().isEmpty()]
        sous = QApplication.widgetAt(QCursor.pos())
        while sous is not None and sous not in libres:
            sous = sous.parentWidget()
        return sous or min(libres, key=lambda f: f.mapTo(self, QPoint()).y(), default=None)

    def _defiler(self, n, recadrer=False):
        self.cible, self.recadrer = n, recadrer  # au prochain tour, la mise en page retombée ; _suite y ajoute la pause
        self.descente.stop()
        self.attente.start(0)

    def _descendre(self):
        zone = self.defilement
        debut, fin = zone.verticalScrollBar().value(), self.unites[self.cible].mapTo(zone.widget(), QPoint(0, 0)).y()
        if self.recadrer and fin <= debut:
            return
        self.descente.setStartValue(debut)
        self.descente.setEndValue(fin)
        self.descente.start()

    def _rafraichir_vue(self):
        for b, feuilles in ((self.barre_avancement, [f for f in self.feuilles if f not in self.feuilles_bonus]), (self.barre_bonus, self.feuilles_bonus)):
            if feuilles:
                b.setValue(round(100 * sum(f.avancement() for f in feuilles) / len(feuilles)))
        self.bouton_tout.setEnabled(self.demarre and self.fin is None and not self.retenue and not all(f.fermee for f in self.feuilles))
        self.bouton_terminer.setEnabled(not self.retenue)
        self.bouton_terminer.setToolTip(self.retenue and "La copie se rend dans le dernier quart du temps." or self.aide_terminer)
        if self.affichage == "question":
            self.precedent.setVisible(self.retour)
            self.precedent.setEnabled(self.courante > 0)
            self.suivant.setEnabled(self.courante < len(self.pages) - 1)
        self.prec_libre.setVisible(self.retour)
        self.prec_libre.setEnabled(self._voisine(-1) is not None)
        self.suiv_libre.setEnabled(self._voisine(1) is not None)

    def _corriger_tout(self):  # par une méthode : branché tel quel, le « checked » du clic vaudrait ``confirmer``
        self.soumettre_tout()

    def _rendre_copie(self):  # idem
        self.rendre()

    def _pas(self):
        self.aller(self.courante + (1 if self.sender() == self.suivant else -1))

    def _non_traitee(self):
        self.sauter(1 if self.sender() == self.suiv_libre else -1)

    def _confirmer(self):
        """L'élève confirme dans une boîte NON bloquante (le navigateur n'a pas de boucle imbriquée) : c'est elle qui
        soumet, sans redemander ; ici on répond toujours non, ``soumettre_tout`` s'arrête là en attendant son clic."""
        self._demander("Corriger mes réponses",
                       "Toutes les questions encore ouvertes vont être corrigées. L'épreuve continue : une réponse "
                       "fausse pourra être reprise, à points réduits, tant qu'il reste du temps.\n\nContinuer ?",
                       self._corriger_sans_demander)
        return False

    def _corriger_sans_demander(self):
        self.soumettre_tout(confirmer=False)

    def _demander(self, titre, texte, oui):
        boite = QMessageBox(QMessageBox.Icon.Question, titre, texte, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, self)
        boite.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        boite.accepted.connect(oui)
        boite.open()

    def bilan_rendu(self):
        """Ce que rendre la copie maintenant coûte, chiffré : les questions ni traitées ni soumises (corrigées telles
        quelles) et les secondes chances ouvertes mais non jouées (perdues) ; vide si tout est traité ou soumis."""
        ouvertes = [f for f in self.feuilles if not f.fermee]
        lignes = [(len([f for f in ouvertes if not (f.complete() or f.seconde)]), "Questions ni traitées ni soumises, corrigées telles quelles : "),
                  (len([f for f in ouvertes if f.seconde]), "Secondes chances non jouées, perdues : ")]
        return "\n".join(f"{texte}{n}" for n, texte in lignes if n)

    def rendre(self, confirmer=True):
        """Le bouton « Rendre ma copie » : ``terminer``, après avoir dit ce qui sera figé. La fin du temps, elle, ne demande rien."""
        if confirmer:
            self._demander("Rendre ma copie", (self.bilan_rendu() or "Toutes les questions sont traitées ou soumises.")
                           + "\n\nRendre la copie ? Plus rien ne pourra être modifié ensuite.", self.terminer)
            return
        self.terminer()

    def _noter(self):
        for f in self.feuilles:  # la note d'une question soumise ne s'affiche que si la correction le fait
            f.notee = self.corrigee()
            f.afficher_bareme()

    def _montrer_fin(self):
        super()._montrer_fin()
        self._noter()  # une correction différée se montre à l'échéance, la copie déjà rendue
        for b in (self.precedent, self.suivant, self.prec_libre, self.suiv_libre):
            b.hide()
        self.bouton_tout.setEnabled(False)
        self.bouton_terminer.hide()
        self.finie.emit()
        self._afficher_note()  # la note va dans le cadre de l'entête ; reste ici ce qu'elle ne dit pas
        attente = self.resultat()[2] if self.corrigee() and self.note is None else 0
        self.bilan.definir(f"**Épreuve terminée** — {attente:g} points restent à corriger par le professeur." if attente
                           else "**Épreuve terminée** — la correction et la note s'afficheront à l'échéance." if self.masquee
                           else "**Épreuve terminée.**")
