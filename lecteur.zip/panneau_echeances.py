"""Le panneau des réglages d'un sujet pour une classe, le même partout (le professeur, 20/11/2026, W830 : « un seul panneau
avec les champs utiles . ») : la fenêtre « Déployer » (``deployer_qcm.Colonne``) et la page des classes
(``tableau_eleves.Reglages``, natif et lecteur web) le montrent avec les mêmes libellés, dans le même ordre (``REGLAGES``).

Chaque case de date (départ, échéances, rattrapage) est un ``SelecteurDate`` : n'importe quel jour, n'importe quelle
heure (le professeur, 20/11/2026 12:44-12:50 : « je veux pouvoir choisir n'importe quel jour et n'importe qu'elle
heure . », « ça ne peux pas remplacer le menu ? »), des raccourcis selon les cours connus (fin du cours, cours suivant,
minuit, fin d'année) ; une date absolue, heure de Paris sans fuseau. Les dates ne sont pas bornées par ce que le code
d'accès sait porter : echeances.csv fait foi, ``deployer_qcm.Colonne.reglages`` seul traduit pour le code (au plus près).
Une case que le panneau n'a pas changée est rendue telle qu'il l'a reçue (``cases``) : une valeur écrite à la main n'est
jamais réécrite sans qu'on y touche.

Les cours viennent de l'emploi du temps ÉcoleDirecte du professeur (``plan_de_classe/emploi_du_temps.py``, importé à la
demande) : aucun dans le lecteur web, ni sans configuration ; restent les raccourcis minuit et fin d'année.
Qt (qtpy6), ``codes``, ``echeances`` et ``noyau`` seulement : le lecteur web l'embarque (``web/construire.py``)."""

from __future__ import annotations

import json
import math
import sys
from datetime import date as Date, datetime, time, timedelta
from pathlib import Path
from collections import namedtuple
from types import ModuleType
from typing import Any, Callable

from qtpy6.QtCore import QDate, Qt, Signal
from qtpy6.QtGui import QBrush, QColor, QTextCharFormat
from qtpy6.QtWidgets import (QCalendarWidget, QCheckBox, QComboBox, QFormLayout, QHBoxLayout, QListWidget,
                             QListWidgetItem, QToolButton, QVBoxLayout, QWidget)

import codes
import echeances
from noyau import ECRAN, SOUMISSIONS, TEMPS

ICI = Path(__file__).resolve().parent

RETARD = 10  # minutes laissées aux retardataires après départ + durée
DUREE_MAX = 315  # minutes : ce que le code sait porter (``codes``, 6 bits de 5 minutes)
JOURS = 30  # échéances « minuit » proposées
JOURS_SEMAINE = "lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim."
LARGEUR = 22  # caractères : la largeur d'une case de réglage, la liste déroulée montre le texte entier

REGLAGES = ("Départ", "Durée", "Échéance 100 %", "Échéance 50 %", "Rattrapage", "Soumission", "Anti-triche", "Temps",
            "À la maison")  # une ligne chacun, dans cet ordre, partout
DATES = ("Départ", "Échéance 100 %", "Échéance 50 %", "Rattrapage")  # celles de ces lignes qui sont un ``SelecteurDate``
COLONNES = ("debut", "duree", "fin_creneau", "echeance", "echeance_tardive", "soumission", "anti_triche", "temps", "maison")
# les colonnes d'echeances.csv de ces lignes, dans le même ordre

Cours = namedtuple("Cours", "debut fin texte")  # comme ``emploi_du_temps.Cours`` : un départ hors de l'emploi du temps


SANS_ECHEANCE, SANS_DUREE = "sans échéance", "sans durée"  # le vrai état : le code n'en porte pas, le sujet non plus
# la case « maison » d'echeances.csv (W732, ``echeances.gel_entre_seances``) : vide, l'avancement de la classe décide
MAISONS = {"": "selon l'avancement", "oui": "à finir à la maison", "non": "en pause entre les séances"}


def jour(date: datetime) -> str:
    """« mar. 24/11 »."""
    return f"{JOURS_SEMAINE[date.weekday()]} {date:%d/%m}"


def libelle(date: datetime) -> str:
    """« mar. 24/11 08:00 », ou « minuit : mar. 24/11 » pour le minuit qui finit ce jour-là."""
    if (date.hour, date.minute) == (0, 0):
        return f"minuit : {jour(date - timedelta(minutes=1))}"
    return f"{jour(date)} {date:%H:%M}"


def au_pas(date: datetime) -> datetime:
    """``date`` arrondie aux 5 minutes du dessous, comme ``code_eleve.donner`` le fait du départ."""
    return date.replace(minute=date.minute // codes.PAS * codes.PAS, second=0, microsecond=0)


def sans_fuseau(date: datetime | None) -> datetime | None:
    """``date`` à l'heure de Paris, sans fuseau (``echeances.en_texte``), comme les cours de l'emploi du temps et les cases
    d'echeances.csv ; une date sans fuseau, et ``None``, restent telles quelles."""
    return date and (datetime.strptime(echeances.en_texte(date), echeances.FORMAT) if date.tzinfo else date)


def date_de(case: str | None) -> datetime | None:
    """La case « JJ/MM/AAAA HH:MM » d'echeances.csv en date sans fuseau ; ``None`` si vide, « sans » ou illisible."""
    try:
        return datetime.strptime((case or "").strip(), echeances.FORMAT)
    except ValueError:
        return None


def elargir(menu: QComboBox) -> None:
    """La liste dépliée de ``menu`` assez large pour ses textes entiers."""
    menu.view().setMinimumWidth(menu.view().sizeHintForColumn(0) + 24)


def etroit(menu: QComboBox) -> QComboBox:
    """``menu`` à la largeur d'une colonne, sa liste dépliée assez large pour ses textes entiers."""
    menu.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
    menu.setMinimumContentsLength(LARGEUR)
    elargir(menu)
    return menu


def emploi_du_temps() -> ModuleType | None:
    """``plan_de_classe/emploi_du_temps.py``, ``None`` là où il n'est pas (le lecteur web, une copie de ``QCM/`` seule)."""
    dossier = str(ICI.parent / "plan_de_classe")
    if dossier not in sys.path:
        sys.path.append(dossier)
    try:
        import emploi_du_temps as module  # noqa: PLC0415 - la machine du professeur seulement
    except ImportError:
        return None
    return module


def cours_du_professeur() -> list:
    """Les cours de l'emploi du temps ÉcoleDirecte, aucun s'il n'est pas configuré ou ne se lit pas (ni réseau ni cache), ni
    dans le lecteur web."""
    module = emploi_du_temps()
    if module is None:
        return []
    try:
        source = json.loads((ICI.parent / "plan_de_classe/config.json").read_text()).get("emploi_du_temps")
        return module.charger(source) if source else []
    except (OSError, ValueError):
        return []


_MEMOIRE: dict[Date, list] = {}


def cours_du_jour() -> list:
    """``cours_du_professeur()`` lu une fois par jour et par processus : la page des classes a un panneau par sujet et se
    refait à chaque enregistrement, l'emploi du temps se télécharge (5 s au plus sans réseau)."""
    aujourd_hui = datetime.now().date()
    if aujourd_hui not in _MEMOIRE:
        _MEMOIRE.clear()
        _MEMOIRE[aujourd_hui] = cours_du_professeur()
    return _MEMOIRE[aujourd_hui]


def classe_du_cours(cours: Any, classes: list[str]) -> str | None:
    """Le nom de classe (parmi ``classes``) que cite le cours (``emploi_du_temps.classe_du_cours``), ``None`` sans."""
    module = emploi_du_temps()
    return module.classe_du_cours(cours, classes) if module else None


def cours_de_la_classe(cours: list, classe: str, apres: datetime) -> list:
    """Les cours de ``cours`` qui citent ``classe`` et ne sont pas finis à ``apres``."""
    return [c for c in cours if c.fin > apres and classe_du_cours(c, [classe]) == classe]


BLEU_PALE = "#d6eaf8"  # les jours et heures de cours de la classe (le professeur, 20/11/2026 13:22 : « afficher les jour et
# les heure de la classe en bleu pale, et la la date et l'heure selectionné en vert. »)
VERT_VIF = "#92d050"  # le jour et l'heure choisis : le vert vif des cours (Notes/Consignes/style.md, « important positif ») ;
# le professeur, 20/11/2026 13:25 : « je veux le vert vif de mes cours »


class ChampDate(QComboBox):
    """Le bouton d'un ``SelecteurDate`` fermé, avec l'aspect d'un champ (cadre et flèche d'un menu déroulant) : il montre
    un seul texte, et son clic, au lieu d'une liste, appelle ``ouvrir`` (le volet en ligne)."""

    def __init__(self, ouvrir: Callable[[], None], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.ouvrir = ouvrir

    def setText(self, texte: str) -> None:  # noqa: N802 (le texte du champ, comme celui d'un bouton)
        self.clear()
        self.addItem(texte)

    def text(self) -> str:
        return self.currentText()

    def showPopup(self) -> None:  # noqa: N802
        self.ouvrir()


class SelecteurDate(QWidget):
    """Une case de date du panneau (départ, échéances, rattrapage) : un champ (``ChampDate``) qui dit la valeur ; un clic ouvre EN LIGNE
    sous lui des raccourcis, puis le calendrier à gauche et les heures au pas de 5 minutes à droite ; les jours et heures de
    cours de la classe sur fond ``BLEU_PALE``, le jour et l'heure choisis en vert (``VERT_VIF``) ; une heure ou un raccourci pose la valeur et referme (le professeur, 20/11/2026 12:48-12:50 : « je veux
    pouvoir choisir n'importe quel jour et n'importe qu'elle heure . », « ça ne peux pas remplacer le menu ? »). Pas de
    dialogue : le lecteur web le montre aussi. Un seul ouvert dans la fenêtre. Le volet est sous le champ, ou ailleurs si
    l'hôte le prend (``volet_a_part`` : la fenêtre « Déployer », dont les colonnes sont trop étroites, le met sur toute la
    largeur de sa grille). Sa forme peut changer sans toucher au panneau, qui ne connaît que ``valeur``, ``poser``,
    ``raccourcis``, ``fermer`` et le signal ``change`` (une valeur posée par l'utilisateur)."""

    change = Signal()

    def __init__(self, vide: str, cours: list, reference: datetime, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.vide, self.cours, self.reference = vide, cours, reference  # ``vide`` : ce que dit la valeur ``None``
        self._valeur: datetime | None = None
        self._raccourcis: list[tuple[str, datetime | None]] = []
        self.bouton = ChampDate(self.basculer)
        self.bouton.setText(vide)
        self.volet = QWidget()
        self.rangee = QHBoxLayout()
        self.rangee.setContentsMargins(0, 0, 0, 0)
        self.calendrier = QCalendarWidget()
        self.calendrier.setGridVisible(False)
        self.calendrier.setVerticalHeaderFormat(QCalendarWidget.VerticalHeaderFormat.NoVerticalHeader)
        self.calendrier.selectionChanged.connect(self.remplir_heures)
        vert = VERT_VIF
        choisi = f"selection-background-color: {vert}; selection-color: black;"
        self.calendrier.setStyleSheet(f"QCalendarWidget QAbstractItemView {{ {choisi} }}")
        de_cours = QTextCharFormat()
        de_cours.setBackground(QBrush(QColor(BLEU_PALE)))
        for jour_de_cours in {c.debut.date() for c in self.cours if c.debut}:
            self.calendrier.setDateTextFormat(QDate(jour_de_cours.year, jour_de_cours.month, jour_de_cours.day), de_cours)
        self.heures = QListWidget()
        self.heures.setStyleSheet(f"QListWidget {{ {choisi} }} QListWidget::item:selected {{ background: {vert}; color: black; }}")
        self.heures.setFixedWidth(self.heures.fontMetrics().horizontalAdvance("00:00") + 40)
        self.heures.itemClicked.connect(self.heure_choisie)
        self.heures.itemActivated.connect(self.heure_choisie)
        bas = QHBoxLayout()
        bas.setContentsMargins(0, 0, 0, 0)
        bas.addWidget(self.calendrier)
        bas.addWidget(self.heures)
        volet = QVBoxLayout(self.volet)
        volet.setContentsMargins(0, 0, 0, 0)
        volet.addLayout(self.rangee)
        volet.addLayout(bas)
        self.volet.hide()
        pile = QVBoxLayout(self)
        pile.setContentsMargins(0, 0, 0, 0)
        pile.setSpacing(2)
        pile.addWidget(self.bouton)
        pile.addWidget(self.volet)

    def valeur(self) -> datetime | None:
        """La date montrée (sans fuseau, heure de Paris), ``None`` pour ``vide``."""
        return self._valeur

    def texte(self) -> str:
        """Ce que dit le bouton : ``vide``, ou la date, nommée par son raccourci s'il y en a un (« fin du cours : … »)."""
        if self._valeur is None:
            return self.vide
        date = libelle(self._valeur)
        nom = next((t for t, d in self._raccourcis if d == self._valeur and t != "minuit" and not t.startswith(date)), "")
        return f"{nom} : {date}" if nom else date

    def poser(self, date: datetime | None, emettre: bool = False) -> None:
        """La valeur ``date`` montrée ; ``change`` si ``emettre`` (un choix de l'utilisateur)."""
        self._valeur = date
        self.bouton.setText(self.texte())
        if emettre:
            self.change.emit()

    def raccourcis(self, choix: list[tuple[str, datetime | None]]) -> None:
        """Les petits boutons au-dessus du calendrier : (texte, date), ``None`` pour ``vide``."""
        self._raccourcis = list(choix)
        while self.rangee.count():  # les boutons d'avant, et l'espace qui les pousse à gauche
            ancien = self.rangee.takeAt(0).widget()
            if ancien:
                ancien.deleteLater()
        for texte, date in self._raccourcis:
            bouton = QToolButton()
            bouton.setText(texte)
            bouton.setToolTip(libelle(date) if date else self.vide)
            bouton.clicked.connect(lambda _c=False, d=date: self.choisi(d))
            self.rangee.addWidget(bouton)
        self.rangee.addStretch(1)
        self.bouton.setText(self.texte())

    def choisi(self, date: datetime | None) -> None:
        self.poser(date, emettre=True)
        self.fermer()

    def basculer(self) -> None:
        if not self.volet.isHidden():
            self.fermer()
        else:
            self.ouvrir()

    def ouvrir(self) -> None:
        """Le volet ouvert au jour de la valeur (sinon de ``reference``), son heure choisie ; les autres sélecteurs de la
        fenêtre fermés."""
        for autre in self.window().findChildren(SelecteurDate):
            if autre is not self:
                autre.fermer()
        date = self._valeur or self.reference
        self.calendrier.setSelectedDate(QDate(date.year, date.month, date.day))
        self.remplir_heures()
        self.volet.show()

    def volet_a_part(self) -> QWidget:
        """Le volet, retiré de sous le champ, pour que l'hôte le place ailleurs (il reste piloté par ce sélecteur)."""
        self.layout().removeWidget(self.volet)
        return self.volet

    def fermer(self) -> None:
        self.volet.hide()

    def jour_choisi(self) -> Date:
        choisi = self.calendrier.selectedDate()
        return Date(choisi.year(), choisi.month(), choisi.day())

    def remplir_heures(self) -> None:
        """07:00 à 23:55 au pas de 5 minutes, et l'heure de la valeur si elle n'y est pas ; sur fond ``BLEU_PALE``, les heures
        des cours de ce jour (du début à la fin) ; l'heure de la valeur choisie, montrée."""
        jour_choisi = self.jour_choisi()
        heures = {f"{h:02d}:{m:02d}" for h in range(7, 24) for m in range(0, 60, codes.PAS)}
        if self._valeur and self._valeur.date() == jour_choisi:
            heures.add(f"{self._valeur:%H:%M}")
        bornes = {f"{d:%H:%M}" for c in self.cours for d in (c.debut, c.fin) if d and d.date() == jour_choisi}
        de_cours = [(f"{c.debut:%H:%M}", f"{c.fin:%H:%M}") for c in self.cours if c.debut and c.fin and c.debut.date() == jour_choisi]
        self.heures.clear()
        for heure in sorted(heures | bornes):
            element = QListWidgetItem(heure)
            if any(debut <= heure <= fin for debut, fin in de_cours):
                element.setBackground(QBrush(QColor(BLEU_PALE)))
            self.heures.addItem(element)
        voulue = f"{self._valeur:%H:%M}" if self._valeur else next(iter(sorted(bornes)), "08:00")
        rang = next((i for i in range(self.heures.count()) if self.heures.item(i).text() == voulue), 0)
        self.heures.setCurrentRow(rang)
        self.heures.scrollToItem(self.heures.item(rang))

    def heure_choisie(self, element: QListWidgetItem) -> None:
        heures, minutes = map(int, element.text().split(":"))
        self.choisi(datetime.combine(self.jour_choisi(), time(heures, minutes)))


class Panneau(QWidget):
    """Les réglages d'un sujet pour une classe, une case par ligne de ``REGLAGES`` (``cases_dans_l_ordre``), et ``cases()`` :
    les colonnes ``COLONNES`` d'echeances.csv telles que le fichier les écrit ; ``change`` à chaque case qui bouge.

    ``sorte`` (``tableau_eleves.sorte_du_sujet``) choisit les dates par défaut (le professeur, 08/11/2026) : une révision sans
    échéance, un TP à finir pour le cours suivant (rattrapage : le cours d'après), les autres à départ + durée + ``RETARD`` ;
    l'échéance 100 % à la fin du cours. ``cours`` : les cours de la classe (``emploi_du_temps.Cours``, heures de Paris sans
    fuseau), en cours ou à venir, éventuellement aucun ; ``noms`` (cours → nom) : sans classe, les cours de toutes les
    classes, au départ seulement, nommés, aucun « cours suivant ». ``maintenant`` (sans fuseau, heure de Paris) : le départ
    « maintenant » compte depuis lui, au pas de 5 minutes. ``valeurs`` : les cases d'echeances.csv à montrer (colonne →
    case, « JJ/MM/AAAA HH:MM » pour une date, vide ou « sans » : sans échéance, vide au départ : maintenant) ; une colonne
    absente prend sa valeur par défaut. ``libelles`` : faux, le panneau ne dispose rien et l'appelant place lui-même
    ``cases_dans_l_ordre`` (la fenêtre « Déployer », une grille pour toutes ses classes)."""

    change = Signal()

    def __init__(self, sorte: str, cours: list, maintenant: datetime, valeurs: dict[str, str] | None = None,
                 noms: dict[Any, str] | None = None, libelles: bool = True, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.sorte, self.cours, self.noms = sorte, sorted(cours, key=lambda c: c.debut), noms
        self.sans_classe = noms is not None
        self.maintenant = maintenant
        valeurs = dict(valeurs or {})
        reference = au_pas(maintenant)
        self.depart = SelecteurDate("maintenant", self.cours, reference)
        self.duree = QComboBox()
        self.duree.addItem(SANS_DUREE, None)
        for minutes in range(codes.PAS, DUREE_MAX + 1, codes.PAS):
            self.duree.addItem(f"{minutes} min" + (f" ({minutes // 60} h {minutes % 60:02d})" if minutes >= 60 else ""), minutes)
        etroit(self.duree)
        self.fin = SelecteurDate(SANS_ECHEANCE, self.cours, reference)  # fin_creneau : rendu avant, fait en classe
        self.fin.setToolTip("Rendu avant (5 minutes de marge) : fait en classe, coefficient plein")
        self.echeance = SelecteurDate(SANS_ECHEANCE, self.cours, reference)  # celle du code : rendu avant, à la maison
        self.echeance.setToolTip("Après elle, le code ne sert plus ; rendu entre les deux échéances : à la maison, coefficient moitié")
        self.tardive = SelecteurDate(SANS_ECHEANCE, self.cours, reference)  # echeance_tardive : l'absent, ou qui n'a rien rendu
        self.tardive.setToolTip("Pour l'absent ou qui n'a rien validé à l'échéance 50 % : noté à la maison")
        self.soumission = QComboBox()
        for mode, texte in SOUMISSIONS.items():
            self.soumission.addItem(texte, mode)
            self.soumission.setItemData(self.soumission.count() - 1, texte, Qt.ItemDataRole.ToolTipRole)
        etroit(self.soumission)
        self.anti_triche = QCheckBox("plein écran")
        self.anti_triche.setToolTip("Plein écran, chaque sortie de l'épreuve noircit l'écran une minute")
        self.temps = QComboBox()
        for mode, texte in TEMPS.items():
            self.temps.addItem(texte, mode)
        etroit(self.temps)
        self.maison = QComboBox()  # l'interrupteur que lit ``echeances.gel_entre_seances`` (W732)
        for case, texte in MAISONS.items():
            self.maison.addItem(texte, case)
        etroit(self.maison)
        self.selecteurs = (self.depart, self.fin, self.echeance, self.tardive)
        self.cases_dans_l_ordre: list[QWidget] = [self.depart, self.duree, self.fin, self.echeance, self.tardive, self.soumission,
                                                  self.anti_triche, self.temps, self.maison]

        duree = (valeurs.get("duree") or "").strip()
        if duree.isdigit() and self.duree.findData(int(duree)) < 0:  # écrite à la main hors du pas de 5 minutes
            self.duree.addItem(f"{int(duree)} min", int(duree))
        self.duree.setCurrentIndex(max(self.duree.findData(int(duree)), 0) if duree.isdigit() else 0)
        soumission = (valeurs.get("soumission") or "").strip()
        self.soumission.setCurrentIndex(max(self.soumission.findData(int(soumission)), 0) if soumission.isdigit() else 0)
        # cochée d'office : seul « non » la décoche (le professeur, TODO NSI Première : « cocher par defaut l'anti-triche »)
        self.anti_triche.setChecked((valeurs.get("anti_triche") or "").strip().lower() != "non")
        self.temps.setCurrentIndex(max(self.temps.findData((valeurs.get("temps") or ECRAN).strip().lower()), 0))
        self.maison.setCurrentIndex(max(self.maison.findData((valeurs.get("maison") or "").strip().lower()), 0))
        if "debut" in valeurs:
            self.depart.poser(date_de(valeurs["debut"]))
        else:  # le cours en cours (ou qui commence dans les 10 minutes), sinon le prochain
            module = emploi_du_temps() if self.cours else None
            choisi = (module and module.cours_en_cours(self.cours, maintenant)
                      or next((c for c in self.cours if c.debut > maintenant), None))
            self.depart.poser(choisi and choisi.debut)
        # les défauts que chaque date suit tant qu'elle y est (``defauts``) : aucune date encore
        self.fin_par_defaut = self.echeance_par_defaut = self.tardive_par_defaut = None
        # une date reçue (la ligne d'echeances.csv, même vide) ne suit aucun défaut : elle ne bouge que choisie
        self.recues_figees = {s for s, c in ((self.fin, "fin_creneau"), (self.echeance, "echeance"),
                                             (self.tardive, "echeance_tardive")) if c in valeurs}
        self.defauts()
        for selecteur, colonne in ((self.fin, "fin_creneau"), (self.echeance, "echeance"), (self.tardive, "echeance_tardive")):
            if colonne in valeurs:
                selecteur.poser(date_de(valeurs[colonne]))
        if "echeance" in valeurs:  # les raccourcis du rattrapage, et son défaut s'il n'est pas reçu, suivent l'échéance reçue
            self.defaut_tardive()
        self.depart.change.connect(self.defauts)
        self.duree.currentIndexChanged.connect(lambda *_: self.echeance_suit())
        self.echeance.change.connect(self.defaut_tardive)
        for selecteur in self.selecteurs:
            selecteur.change.connect(self.change.emit)
        for menu in (self.soumission, self.temps, self.maison):
            menu.currentIndexChanged.connect(lambda *_: self.change.emit())
        self.anti_triche.toggled.connect(lambda *_: self.change.emit())
        # ce que le panneau montrait à l'ouverture, et les cases reçues : une case qui n'a pas bougé est rendue telle quelle
        self.montrees, self.recues = self.montre(), {c: valeurs[c] for c in COLONNES if c in valeurs}
        if libelles:
            formulaire = QFormLayout(self)
            formulaire.setContentsMargins(0, 0, 0, 0)
            for nom, case in zip(REGLAGES, self.cases_dans_l_ordre):
                formulaire.addRow(nom, case)

    def base(self) -> datetime:
        """Le départ choisi, ou ``maintenant``, au pas de 5 minutes : ce dont partent les échéances."""
        return au_pas(self.depart_date() or self.maintenant)

    def cours_du_depart(self) -> Any:
        """Le cours qui commence au départ choisi, ``None`` sans (maintenant, ou une date hors de l'emploi du temps)."""
        depart = self.depart_date()
        return next((c for c in self.cours if c.debut == depart), None) if depart else None

    def fin_du_cours(self) -> datetime | None:
        """La fin du cours du départ, au pas de 5 minutes du dessus, ``None`` sans cours."""
        cours = self.cours_du_depart()
        return cours and cours.fin and au_pas(cours.fin - timedelta(minutes=1)) + timedelta(minutes=codes.PAS)

    def cours_apres(self, date: datetime) -> list:
        """Les cours de la classe des jours après ``date`` (aucun sans classe), dans l'ordre."""
        return [] if self.sans_classe else [c for c in self.cours if c.debut.date() > date.date()]

    def fin_annee(self, date: datetime) -> tuple[str, datetime]:
        return "fin d'année", sans_fuseau(codes.fin_annee(date))

    def defauts(self) -> None:
        """Les raccourcis de chaque case, et ses dates par défaut selon la sorte, au départ choisi : l'échéance 100 % à la fin
        du cours (aucune pour une révision), puis la 50 % (``echeance_suit``) et le rattrapage (``defaut_tardive``). Une date
        ne suit son défaut que tant qu'elle y est : une date reçue (la ligne d'echeances.csv) ou choisie reste ; un défaut que
        rien ne donne (ni cours ni durée : le lecteur web) laisse la case comme elle est."""
        base, fin_du_cours = self.base(), self.fin_du_cours()
        suivant = next(iter(self.cours_apres(base)), None)
        minuit = datetime.combine(base.date() + timedelta(days=1), time())
        departs = [(f"{jour(c.debut)} {c.debut:%H:%M}"
                    + (f" ({nom})" if self.noms is not None and (nom := self.noms.get(c) or c.texte) else ""), c.debut)
                   for c in self.cours[:4]]
        self.depart.raccourcis([("maintenant", None), *departs])
        echeances_offertes = [(SANS_ECHEANCE, None), *([("fin du cours", fin_du_cours)] if fin_du_cours else []),
                              ("minuit", minuit), *([("cours suivant", suivant.debut)] if suivant else []), self.fin_annee(base)]
        self.fin.raccourcis(echeances_offertes)
        self.echeance.raccourcis(echeances_offertes)
        fin = None if self.sorte == "Révisions" else fin_du_cours
        if (fin or self.sorte == "Révisions") and self.suit(self.fin, self.fin_par_defaut):
            self.fin.poser(fin)
        self.fin_par_defaut = fin
        self.echeance_suit()

    def suit(self, selecteur: SelecteurDate, defaut: datetime | None) -> bool:
        """La date de ``selecteur`` suit-elle son défaut : ni reçue, ni choisie ailleurs que sur ce défaut."""
        return selecteur not in self.recues_figees and selecteur.valeur() == defaut

    def defaut_echeance(self) -> datetime | None:
        """L'échéance 50 % par défaut : aucune pour une révision, le cours suivant pour un TP, départ + durée + ``RETARD``
        au pas de 5 minutes, sinon la fin du cours (``None`` sans cours)."""
        base = self.base()
        suivant = next(iter(self.cours_apres(base)), None)
        if self.sorte == "Révisions":
            return None
        if self.sorte == "TP" and suivant:
            return suivant.debut
        if self.duree.currentData():
            return base + timedelta(minutes=math.ceil((self.duree.currentData() + RETARD) / codes.PAS) * codes.PAS)
        return self.fin_du_cours()

    def echeance_suit(self) -> None:
        """Le départ ou la durée changés : l'échéance 50 % suit son défaut si elle y était encore, puis le rattrapage."""
        defaut = self.defaut_echeance()
        if (defaut or self.sorte == "Révisions") and self.suit(self.echeance, self.echeance_par_defaut):
            self.echeance.poser(defaut)
        self.echeance_par_defaut = defaut
        self.defaut_tardive()
        self.change.emit()

    def defaut_tardive(self) -> None:
        """Le rattrapage : ses raccourcis (le cours suivant l'échéance 50 %, la fin d'année) ; pour un TP, par défaut, le
        premier cours après l'échéance, qu'il suit tant qu'il y est ; sinon aucun."""
        echeance = self.echeance_datee()
        suivant = next(iter(self.cours_apres(echeance)), None) if echeance else None
        self.tardive.raccourcis([(SANS_ECHEANCE, None), *([("cours suivant", suivant.debut)] if suivant else []),
                                 self.fin_annee(echeance or self.base())])
        defaut = suivant.debut if self.sorte == "TP" and suivant else None
        if defaut and self.suit(self.tardive, self.tardive_par_defaut):
            self.tardive.poser(defaut)
        self.tardive_par_defaut = defaut

    def depart_date(self) -> datetime | None:
        """Le départ choisi, ``None`` pour « maintenant »."""
        return self.depart.valeur()

    def echeance_datee(self) -> datetime | None:
        """L'échéance 50 % choisie, ``None`` sans échéance."""
        return self.echeance.valeur()

    def montre(self) -> dict[str, Any]:
        """Ce que montre chaque case, colonne par colonne (des dates, des nombres, ``None`` : maintenant ou sans)."""
        return {"debut": self.depart_date(), "duree": self.duree.currentData(), "fin_creneau": self.fin.valeur(),
                "echeance": self.echeance_datee(), "echeance_tardive": self.tardive.valeur(),
                "soumission": self.soumission.currentData(), "anti_triche": self.anti_triche.isChecked(),
                "temps": self.temps.currentData(), "maison": self.maison.currentData()}

    def case(self, colonne: str, valeur: Any) -> str:
        """``valeur`` (``montre``) écrite comme echeances.csv l'écrit."""
        if colonne == "debut":
            return (valeur or au_pas(self.maintenant)).strftime(echeances.FORMAT)
        if colonne in ("fin_creneau", "echeance", "echeance_tardive"):
            return valeur.strftime(echeances.FORMAT) if valeur else echeances.SANS if colonne == "echeance" else ""
        if colonne == "anti_triche":
            return "oui" if valeur else "non"
        return "" if valeur is None else str(valeur)

    def cases(self) -> dict[str, str]:
        """Les colonnes ``COLONNES`` d'echeances.csv telles que le fichier les écrit : celles qui n'ont pas bougé depuis
        l'ouverture, telles que reçues (une valeur écrite à la main reste) ; les autres, ce que montre le panneau
        (« sans » : sans échéance 50 % ; le départ « maintenant » : l'ouverture, au pas de 5 minutes)."""
        montre = self.montre()
        return {c: self.recues[c] if c in self.recues and montre[c] == self.montrees[c] else self.case(c, montre[c])
                for c in COLONNES}
