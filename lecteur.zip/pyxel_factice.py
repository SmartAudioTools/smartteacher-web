"""Faux module pyxel, pour vérifier un jeu d'élève sans fenêtre (verifier.py l'installe à la place du vrai).

Le programme de l'élève s'exécute normalement jusqu'à ``run(update, draw)``, qui mémorise les deux fonctions et
rend la main au lieu de boucler (le vrai ``run`` ne rend jamais la main, et avale les exceptions). Les tests
pilotent ensuite le jeu image par image :

    appuyer(KEY_UP); images(1)
    assert personnage["vitesse_verticale"] < 0, "Le singe doit monter quand on appuie sur ↑"

Les dessins de la dernière image sont relevés dans ``dessins`` : [("rect", (x, y, l, h, couleur)), ...].
Les constantes (touches, couleurs…) sont recopiées d'un Pyxel installé par ``python pyxel_factice.py --regenerer``.
"""

import math
import random
import sys

# CONSTANTES
# Pyxel 2.9.8
globals().update(dict(
    COLOR_BLACK=0, COLOR_BROWN=4, COLOR_CYAN=12, COLOR_DARK_BLUE=5, COLOR_GRAY=13, COLOR_GREEN=3,
    COLOR_LIGHT_BLUE=6, COLOR_LIME=11, COLOR_NAVY=1, COLOR_ORANGE=9, COLOR_PEACH=15, COLOR_PINK=14,
    COLOR_PURPLE=2, COLOR_RED=8, COLOR_WHITE=7, COLOR_YELLOW=10, EFFECT_FADEOUT=3, EFFECT_HALF_FADEOUT=4,
    EFFECT_NONE=0, EFFECT_QUARTER_FADEOUT=5, EFFECT_SLIDE=1, EFFECT_VIBRATO=2, FONT_HEIGHT=6, FONT_WIDTH=4,
    GAMEPAD1_AXIS_LEFTX=1342177792, GAMEPAD1_AXIS_LEFTY=1342177793, GAMEPAD1_AXIS_RIGHTX=1342177794,
    GAMEPAD1_AXIS_RIGHTY=1342177795, GAMEPAD1_AXIS_TRIGGERLEFT=1342177796, GAMEPAD1_AXIS_TRIGGERRIGHT=1342177797,
    GAMEPAD1_BUTTON_A=1342177798, GAMEPAD1_BUTTON_B=1342177799, GAMEPAD1_BUTTON_BACK=1342177802,
    GAMEPAD1_BUTTON_DPAD_DOWN=1342177810, GAMEPAD1_BUTTON_DPAD_LEFT=1342177811,
    GAMEPAD1_BUTTON_DPAD_RIGHT=1342177812, GAMEPAD1_BUTTON_DPAD_UP=1342177809, GAMEPAD1_BUTTON_GUIDE=1342177803,
    GAMEPAD1_BUTTON_LEFTSHOULDER=1342177807, GAMEPAD1_BUTTON_LEFTSTICK=1342177805,
    GAMEPAD1_BUTTON_RIGHTSHOULDER=1342177808, GAMEPAD1_BUTTON_RIGHTSTICK=1342177806,
    GAMEPAD1_BUTTON_START=1342177804, GAMEPAD1_BUTTON_X=1342177800, GAMEPAD1_BUTTON_Y=1342177801,
    GAMEPAD2_AXIS_LEFTX=1342178048, GAMEPAD2_AXIS_LEFTY=1342178049, GAMEPAD2_AXIS_RIGHTX=1342178050,
    GAMEPAD2_AXIS_RIGHTY=1342178051, GAMEPAD2_AXIS_TRIGGERLEFT=1342178052, GAMEPAD2_AXIS_TRIGGERRIGHT=1342178053,
    GAMEPAD2_BUTTON_A=1342178054, GAMEPAD2_BUTTON_B=1342178055, GAMEPAD2_BUTTON_BACK=1342178058,
    GAMEPAD2_BUTTON_DPAD_DOWN=1342178066, GAMEPAD2_BUTTON_DPAD_LEFT=1342178067,
    GAMEPAD2_BUTTON_DPAD_RIGHT=1342178068, GAMEPAD2_BUTTON_DPAD_UP=1342178065, GAMEPAD2_BUTTON_GUIDE=1342178059,
    GAMEPAD2_BUTTON_LEFTSHOULDER=1342178063, GAMEPAD2_BUTTON_LEFTSTICK=1342178061,
    GAMEPAD2_BUTTON_RIGHTSHOULDER=1342178064, GAMEPAD2_BUTTON_RIGHTSTICK=1342178062,
    GAMEPAD2_BUTTON_START=1342178060, GAMEPAD2_BUTTON_X=1342178056, GAMEPAD2_BUTTON_Y=1342178057,
    GAMEPAD3_AXIS_LEFTX=1342178304, GAMEPAD3_AXIS_LEFTY=1342178305, GAMEPAD3_AXIS_RIGHTX=1342178306,
    GAMEPAD3_AXIS_RIGHTY=1342178307, GAMEPAD3_AXIS_TRIGGERLEFT=1342178308, GAMEPAD3_AXIS_TRIGGERRIGHT=1342178309,
    GAMEPAD3_BUTTON_A=1342178310, GAMEPAD3_BUTTON_B=1342178311, GAMEPAD3_BUTTON_BACK=1342178314,
    GAMEPAD3_BUTTON_DPAD_DOWN=1342178322, GAMEPAD3_BUTTON_DPAD_LEFT=1342178323,
    GAMEPAD3_BUTTON_DPAD_RIGHT=1342178324, GAMEPAD3_BUTTON_DPAD_UP=1342178321, GAMEPAD3_BUTTON_GUIDE=1342178315,
    GAMEPAD3_BUTTON_LEFTSHOULDER=1342178319, GAMEPAD3_BUTTON_LEFTSTICK=1342178317,
    GAMEPAD3_BUTTON_RIGHTSHOULDER=1342178320, GAMEPAD3_BUTTON_RIGHTSTICK=1342178318,
    GAMEPAD3_BUTTON_START=1342178316, GAMEPAD3_BUTTON_X=1342178312, GAMEPAD3_BUTTON_Y=1342178313,
    GAMEPAD4_AXIS_LEFTX=1342178560, GAMEPAD4_AXIS_LEFTY=1342178561, GAMEPAD4_AXIS_RIGHTX=1342178562,
    GAMEPAD4_AXIS_RIGHTY=1342178563, GAMEPAD4_AXIS_TRIGGERLEFT=1342178564, GAMEPAD4_AXIS_TRIGGERRIGHT=1342178565,
    GAMEPAD4_BUTTON_A=1342178566, GAMEPAD4_BUTTON_B=1342178567, GAMEPAD4_BUTTON_BACK=1342178570,
    GAMEPAD4_BUTTON_DPAD_DOWN=1342178578, GAMEPAD4_BUTTON_DPAD_LEFT=1342178579,
    GAMEPAD4_BUTTON_DPAD_RIGHT=1342178580, GAMEPAD4_BUTTON_DPAD_UP=1342178577, GAMEPAD4_BUTTON_GUIDE=1342178571,
    GAMEPAD4_BUTTON_LEFTSHOULDER=1342178575, GAMEPAD4_BUTTON_LEFTSTICK=1342178573,
    GAMEPAD4_BUTTON_RIGHTSHOULDER=1342178576, GAMEPAD4_BUTTON_RIGHTSTICK=1342178574,
    GAMEPAD4_BUTTON_START=1342178572, GAMEPAD4_BUTTON_X=1342178568, GAMEPAD4_BUTTON_Y=1342178569, IMAGE_SIZE=256,
    KEY_0=48, KEY_1=49, KEY_2=50, KEY_3=51, KEY_4=52, KEY_5=53, KEY_6=54, KEY_7=55, KEY_8=56, KEY_9=57, KEY_A=97,
    KEY_AGAIN=1073741945, KEY_ALT=1342177283, KEY_ALTERASE=1073741977, KEY_AMPERSAND=38,
    KEY_APPLICATION=1073741925, KEY_ASTERISK=42, KEY_AT=64, KEY_B=98, KEY_BACKQUOTE=96, KEY_BACKSLASH=92,
    KEY_BACKSPACE=8, KEY_C=99, KEY_CANCEL=1073741979, KEY_CAPSLOCK=1073741881, KEY_CARET=94,
    KEY_CLEAR=1073741980, KEY_CLEARAGAIN=1073741986, KEY_COLON=58, KEY_COMMA=44, KEY_COPY=1073741948,
    KEY_CRSEL=1073741987, KEY_CTRL=1342177282, KEY_CURRENCYSUBUNIT=1073742005, KEY_CURRENCYUNIT=1073742004,
    KEY_CUT=1073741947, KEY_D=100, KEY_DECIMALSEPARATOR=1073742003, KEY_DELETE=127, KEY_DOLLAR=36,
    KEY_DOWN=1073741905, KEY_E=101, KEY_END=1073741901, KEY_EQUALS=61, KEY_ESCAPE=27, KEY_EXCLAIM=33,
    KEY_EXECUTE=1073741940, KEY_EXSEL=1073741988, KEY_F=102, KEY_F1=1073741882, KEY_F10=1073741891,
    KEY_F11=1073741892, KEY_F12=1073741893, KEY_F13=1073741928, KEY_F14=1073741929, KEY_F15=1073741930,
    KEY_F16=1073741931, KEY_F17=1073741932, KEY_F18=1073741933, KEY_F19=1073741934, KEY_F2=1073741883,
    KEY_F20=1073741935, KEY_F21=1073741936, KEY_F22=1073741937, KEY_F23=1073741938, KEY_F24=1073741939,
    KEY_F3=1073741884, KEY_F4=1073741885, KEY_F5=1073741886, KEY_F6=1073741887, KEY_F7=1073741888,
    KEY_F8=1073741889, KEY_F9=1073741890, KEY_FIND=1073741950, KEY_G=103, KEY_GREATER=62, KEY_GUI=1342177284,
    KEY_H=104, KEY_HASH=35, KEY_HELP=1073741941, KEY_HOME=1073741898, KEY_I=105, KEY_INSERT=1073741897,
    KEY_J=106, KEY_K=107, KEY_KP_0=1073741922, KEY_KP_00=1073742000, KEY_KP_000=1073742001, KEY_KP_1=1073741913,
    KEY_KP_2=1073741914, KEY_KP_3=1073741915, KEY_KP_4=1073741916, KEY_KP_5=1073741917, KEY_KP_6=1073741918,
    KEY_KP_7=1073741919, KEY_KP_8=1073741920, KEY_KP_9=1073741921, KEY_KP_A=1073742012,
    KEY_KP_AMPERSAND=1073742023, KEY_KP_AT=1073742030, KEY_KP_B=1073742013, KEY_KP_BACKSPACE=1073742011,
    KEY_KP_BINARY=1073742042, KEY_KP_C=1073742014, KEY_KP_CLEAR=1073742040, KEY_KP_CLEARENTRY=1073742041,
    KEY_KP_COLON=1073742027, KEY_KP_COMMA=1073741957, KEY_KP_D=1073742015, KEY_KP_DBLAMPERSAND=1073742024,
    KEY_KP_DBLVERTICALBAR=1073742026, KEY_KP_DECIMAL=1073742044, KEY_KP_DIVIDE=1073741908, KEY_KP_E=1073742016,
    KEY_KP_ENTER=1073741912, KEY_KP_EQUALS=1073741927, KEY_KP_EQUALSAS400=1073741958, KEY_KP_EXCLAM=1073742031,
    KEY_KP_F=1073742017, KEY_KP_GREATER=1073742022, KEY_KP_HASH=1073742028, KEY_KP_HEXADECIMAL=1073742045,
    KEY_KP_LEFTBRACE=1073742008, KEY_KP_LEFTPAREN=1073742006, KEY_KP_LESS=1073742021, KEY_KP_MEMADD=1073742035,
    KEY_KP_MEMCLEAR=1073742034, KEY_KP_MEMDIVIDE=1073742038, KEY_KP_MEMMULTIPLY=1073742037,
    KEY_KP_MEMRECALL=1073742033, KEY_KP_MEMSTORE=1073742032, KEY_KP_MEMSUBTRACT=1073742036,
    KEY_KP_MINUS=1073741910, KEY_KP_MULTIPLY=1073741909, KEY_KP_OCTAL=1073742043, KEY_KP_PERCENT=1073742020,
    KEY_KP_PERIOD=1073741923, KEY_KP_PLUS=1073741911, KEY_KP_PLUSMINUS=1073742039, KEY_KP_POWER=1073742019,
    KEY_KP_RIGHTBRACE=1073742009, KEY_KP_RIGHTPAREN=1073742007, KEY_KP_SPACE=1073742029, KEY_KP_TAB=1073742010,
    KEY_KP_VERTICALBAR=1073742025, KEY_KP_XOR=1073742018, KEY_L=108, KEY_LALT=1073742050, KEY_LCTRL=1073742048,
    KEY_LEFT=1073741904, KEY_LEFTBRACKET=91, KEY_LEFTPAREN=40, KEY_LESS=60, KEY_LGUI=1073742051,
    KEY_LSHIFT=1073742049, KEY_M=109, KEY_MENU=1073741942, KEY_MINUS=45, KEY_MUTE=1073741951, KEY_N=110,
    KEY_NONE=1342177280, KEY_NUMLOCKCLEAR=1073741907, KEY_O=111, KEY_OPER=1073741985, KEY_OUT=1073741984,
    KEY_P=112, KEY_PAGEDOWN=1073741902, KEY_PAGEUP=1073741899, KEY_PASTE=1073741949, KEY_PAUSE=1073741896,
    KEY_PERCENT=37, KEY_PERIOD=46, KEY_PLUS=43, KEY_POWER=1073741926, KEY_PRINTSCREEN=1073741894,
    KEY_PRIOR=1073741981, KEY_Q=113, KEY_QUESTION=63, KEY_QUOTE=39, KEY_QUOTEDBL=34, KEY_R=114,
    KEY_RALT=1073742054, KEY_RCTRL=1073742052, KEY_RETURN=13, KEY_RETURN2=1073741982, KEY_RGUI=1073742055,
    KEY_RIGHT=1073741903, KEY_RIGHTBRACKET=93, KEY_RIGHTPAREN=41, KEY_RSHIFT=1073742053, KEY_S=115,
    KEY_SCROLLLOCK=1073741895, KEY_SELECT=1073741943, KEY_SEMICOLON=59, KEY_SEPARATOR=1073741983,
    KEY_SHIFT=1342177281, KEY_SLASH=47, KEY_SPACE=32, KEY_STOP=1073741944, KEY_SYSREQ=1073741978, KEY_T=116,
    KEY_TAB=9, KEY_THOUSANDSSEPARATOR=1073742002, KEY_U=117, KEY_UNDERSCORE=95, KEY_UNDO=1073741946,
    KEY_UNKNOWN=0, KEY_UP=1073741906, KEY_V=118, KEY_VOLUMEDOWN=1073741953, KEY_VOLUMEUP=1073741952, KEY_W=119,
    KEY_X=120, KEY_Y=121, KEY_Z=122, MOUSE_BUTTON_LEFT=1342177540, MOUSE_BUTTON_MIDDLE=1342177541,
    MOUSE_BUTTON_RIGHT=1342177542, MOUSE_BUTTON_X1=1342177543, MOUSE_BUTTON_X2=1342177544,
    MOUSE_POS_X=1342177536, MOUSE_POS_Y=1342177537, MOUSE_WHEEL_X=1342177538, MOUSE_WHEEL_Y=1342177539,
    NUM_CHANNELS=4, NUM_COLORS=16, NUM_IMAGES=3, NUM_MUSICS=8, NUM_SOUNDS=64, NUM_TILEMAPS=8, NUM_TONES=4,
    TILEMAP_SIZE=256, TILE_SIZE=8, TONE_NOISE=3, TONE_PULSE=2, TONE_SQUARE=1, TONE_TRIANGLE=0,
    WATCH_RESET_EXIT_CODE=82
))
# FIN DES CONSTANTES

width = height = frame_count = 0
mouse_x = mouse_y = mouse_wheel = 0
dessins = []  # appels de dessin de la dernière image, vidé (en place) à chaque image
_jeu = {"update": None, "draw": None}
_appuis = {}  # touche -> numéro de l'image où elle a été enfoncée


# UN DÉCOR FACTICE, pour les exercices qui cherchent une plateforme sous les pieds du personnage. Le vrai décor
# vient du fichier de ressources, que le faux ``load`` ne lit pas : sans lui, le code qui analyse la tilemap au
# lancement du jeu lèverait une erreur dès la première ligne. tilemap(1) porte donc ici une plateforme, de la
# tuile 20 à la tuile 39 en x, sur la ligne de tuiles 24 (y = 192 pixels), en couleur 8 (celle que l'exercice 26
# traverse vers le bas) ; tilemap(2) est vide. image(2) donne la couleur des pixels de ces deux tuiles.
_TUILE_PLATEFORME, _TUILE_VIDE = (1, 0), (0, 0)
_COULEUR_PLATEFORME = 8
_LIGNE_PLATEFORME, _COLONNES_PLATEFORME = 24, range(20, 40)


class _Enregistreur:
    """Image, fond de carte, son… : tout appel de méthode est relevé dans ``dessins`` et ne fait rien d'autre."""

    def __init__(self, nom):
        self._nom = nom

    def __getattr__(self, methode):
        return lambda *args, **kwargs: dessins.append((f"{self._nom}.{methode}", args))

    def pget(self, x, y):
        """Le décor factice décrit plus haut : la tuile pour une tilemap, la couleur d'un pixel pour image(2)."""
        if self._nom.startswith("tilemap"):
            return (_TUILE_PLATEFORME if self._nom == "tilemap(1)" and y == _LIGNE_PLATEFORME and x in _COLONNES_PLATEFORME
                    else _TUILE_VIDE)
        return _COULEUR_PLATEFORME if self._nom == "image(2)" and 8 <= x < 16 and y == 0 else 0

    def __repr__(self):  # « tilemap(1) » : lisible dans un message, comparable d'une image à l'autre
        return self._nom

    def __eq__(self, autre):
        return repr(self) == repr(autre)


def _dessin(nom):
    def dessiner(*args, **kwargs):
        dessins.append((nom, args))
    dessiner.__name__ = nom
    return dessiner


for _nom in ("blt", "blt3d", "bltm", "bltm3d", "camera", "circ", "circb", "clip", "cls", "dither", "elli", "ellib",
             "fill", "line", "pal", "pset", "rect", "rectb", "text", "tri", "trib"):
    globals()[_nom] = _dessin(_nom)


def _rien(*args, **kwargs):
    return None


for _nom in ("flip", "fullscreen", "icon", "integer_scale", "load", "load_pal", "mouse", "perf_monitor", "play",
             "playm", "quit", "reset", "reset_screencast", "save", "save_pal", "screen_mode", "screencast",
             "screenshot", "show", "stop", "title", "warp_mouse", "set_mouse_pos"):
    globals()[_nom] = _rien


def init(largeur, hauteur, **options):
    global width, height
    width, height = largeur, hauteur


def run(update, draw):
    _jeu["update"], _jeu["draw"] = update, draw


def image(n):
    return _Enregistreur(f"image({n})")


def tilemap(n):
    return _Enregistreur(f"tilemap({n})")


def sound(n):
    return _Enregistreur(f"sound({n})")


def music(n):
    return _Enregistreur(f"music({n})")


def pget(x, y):
    return 0


def btn(touche):
    return touche in _appuis


def btnp(touche, hold=None, repeat=None):
    return _appuis.get(touche) == frame_count


def btnr(touche):
    return False


def btnv(touche):
    return 0


# fonctions mathématiques de Pyxel (angles en degrés)
ceil, floor, sqrt = math.ceil, math.floor, math.sqrt


def sgn(x):
    return (x > 0) - (x < 0)


def clamp(x, bas, haut):
    return max(bas, min(x, haut))


def sin(degres):
    return math.sin(math.radians(degres))


def cos(degres):
    return math.cos(math.radians(degres))


def atan2(y, x):
    return math.degrees(math.atan2(y, x))


def rseed(graine):
    random.seed(graine)


def rndi(a, b):
    return random.randint(min(a, b), max(a, b))


def rndf(a, b):
    return random.uniform(a, b)


# AIDES POUR LES TESTS (hors de l'API Pyxel, absentes de « from pyxel import * »)

def appuyer(*touches):
    """Enfonce les touches : btn() les voit jusqu'à relacher(), btnp() à la prochaine image seulement."""
    for touche in touches:
        _appuis.setdefault(touche, frame_count)


def relacher(*touches):
    """Relâche les touches données, ou toutes."""
    for touche in touches or list(_appuis):
        _appuis.pop(touche, None)


def images(n=1):
    """Fait tourner le jeu n images : update() puis draw() ; ``dessins`` garde celles de la dernière."""
    global frame_count
    if _jeu["update"] is None:
        raise AssertionError("Le jeu ne se lance pas : il manque run(update, draw) à la fin du programme")
    for _ in range(n):
        del dessins[:]
        _jeu["update"]()
        _jeu["draw"]()
        frame_count += 1


AIDES = {"appuyer": appuyer, "relacher": relacher, "images": images, "dessins": dessins}
__all__ = [nom for nom in globals() if not nom.startswith("_") and nom not in AIDES
           and nom not in ("AIDES", "math", "random", "sys")]


def _regenerer():
    """Recopie les constantes du Pyxel installé dans ce fichier."""
    import pyxel  # le vrai : ce fichier ne s'appelle pas pyxel.py
    constantes = {n: getattr(pyxel, n) for n in sorted(dir(pyxel)) if n.isupper() and not n.startswith("_")
                  and isinstance(getattr(pyxel, n), int)}
    lignes, ligne = [], ""
    for nom, valeur in constantes.items():
        morceau = f"{nom}={valeur}, "
        if len(ligne) + len(morceau) > 110:
            lignes.append(ligne.rstrip())
            ligne = ""
        ligne += morceau
    lignes.append(ligne.rstrip().rstrip(","))
    bloc = f"# Pyxel {pyxel.VERSION}\nglobals().update(dict(\n    " + "\n    ".join(lignes) + "\n))"
    source = open(__file__, encoding="utf-8").read()
    debut, fin = source.index("# CONSTANTES\n") + len("# CONSTANTES\n"), source.index("# FIN DES CONSTANTES")
    source = source[:debut] + bloc + "\n" + source[fin:]
    open(__file__, "w", encoding="utf-8").write(source)


if __name__ == "__main__" and "--regenerer" in sys.argv:
    _regenerer()
