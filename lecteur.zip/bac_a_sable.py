"""Borne ce que le programme d'un élève peut employer et faire, dans le processus enfant de verifier.py.

Trois couches indépendantes, chacune fermant ce que les autres laissent ouvert (mesuré : deux couches seules
laissaient écrire un fichier et lancer une commande) :

  1. ``analyser``  — ce que le code DIT, lu avant la première instruction : le vocabulaire qui n'existe que pour
                     s'évader (réflexion, attributs internes) et ce qui n'est pas au programme de la classe ;
  2. ``espace``    — ce que le code IMPORTE : un ``__import__`` propre à son espace de noms, borné aux modules du niveau ;
  3. ``poser``     — ce que le code FAIT : un crochet d'audit qui refuse écriture de fichier, lecture hors du dossier de
                     l'exercice, réseau, processus et code natif, d'où que l'appel vienne.

Ne borne pas le temps (délai de garde de verifier.py) ni la lecture dans le dossier de l'exercice, et ne remplace
pas un confinement du système d'exploitation. S'applique au code de l'ÉLÈVE seulement : les tests du professeur
emploient ``inspect``, ``globals``, ``any`` et ne sont jamais analysés.

Bibliothèque standard seule : ce module est importé par le côté enfant de verifier.py.
"""

import ast
import builtins
import sys
import unicodedata
from pathlib import Path

# CE QUI EST AU PROGRAMME, PAR NIVEAU -----------------------------------------------------------------------
# Relevé dans « L'ESSENTIEL DU LANGAGE PYTHON » (seconde, première) et ses TP (``type()`` : TP 6, 8 et 13 de Seconde,
# absent du cours), dans le BO pour la terminale et dans les ``import`` des cours de première. Chaque niveau ajoute
# au précédent. Une question peut fournir sa propre liste (``Code.autorises``), qui remplace celle du niveau.

SECONDE = {
    "fonctions": {"print", "input", "int", "float", "str", "bool", "len", "list", "range", "round", "abs", "type"},
    "modules": {"math", "random", "turtle"},
}
PREMIERE = {
    "fonctions": SECONDE["fonctions"] | {"tuple", "dict", "set", "max", "min", "sum", "sorted", "id", "enumerate",
                                         "zip", "isinstance", "chr", "ord", "bin", "hex", "repr", "open"},
    "modules": SECONDE["modules"] | {"time", "pyxel", "csv"},
}
TERMINALE = {
    "fonctions": PREMIERE["fonctions"] | {"super", "any", "all", "map", "filter", "reversed", "iter", "next", "object",
                                          "Exception", "ValueError", "TypeError", "IndexError", "KeyError",
                                          "ZeroDivisionError", "AssertionError", "StopIteration"},
    "modules": PREMIERE["modules"] | {"statistics", "fractions", "itertools", "functools", "collections", "json", "re",
                                      "copy", "datetime", "sqlite3"},
}
DEFAUT = TERMINALE  # classe inconnue : la plus large, la sécurité ne dépend pas de la classe

# CE QUI NE SERT QU'À SORTIR DU BAC À SABLE, QUEL QUE SOIT LE NIVEAU -----------------------------------------
ATTRIBUTS = {"__class__", "__base__", "__bases__", "__subclasses__", "__mro__", "mro", "__globals__", "__code__",
             "__closure__", "cell_contents", "__func__", "__self__", "__dict__", "__builtins__", "__import__",
             "__getattribute__", "__reduce__", "__reduce_ex__", "__loader__", "__spec__", "modules", "f_globals",
             "f_builtins", "f_locals", "gi_frame", "cr_frame",
             # sqlite3 : défaire le bornage que ``poser`` met sur chaque connexion, ou charger du code natif
             "set_authorizer", "setlimit", "enable_load_extension", "load_extension"}
REFLEXION = {"eval", "exec", "compile", "getattr", "setattr", "delattr", "vars", "globals", "locals", "__import__",
             "breakpoint", "memoryview"}


class Interdit(PermissionError):
    """Ce que le programme a tenté n'est pas permis dans un exercice."""


class HorsProgramme(Interdit):
    """Ce que le programme emploie n'est pas au programme de la classe."""


def programme(classe="", autorises=None):
    """La liste blanche d'une question : la sienne si elle en a une, sinon celle de sa classe (« Première »,
    « 2nde », « 1GEN2 », « Tle »…), à défaut la plus large."""
    if autorises is not None:
        return {"fonctions": set(autorises) & set(dir(builtins)), "modules": set(autorises) - set(dir(builtins))}
    nom = "".join(c for c in unicodedata.normalize("NFD", classe.lower()) if not unicodedata.combining(c)).strip()
    if nom.startswith(("2", "seconde")):
        return SECONDE
    if nom.startswith(("1", "premiere")):
        return PREMIERE
    return TERMINALE if nom.startswith(("t", "terminale")) else DEFAUT


# COUCHE 1 : ce que le code DIT -----------------------------------------------------------------------------

def analyser(source, permis, fichier="<code>", connus=(), premiere=1):
    """Lève ``HorsProgramme`` pour ce que l'élève n'a pas appris, ``Interdit`` pour ce qui sert à sortir du bac à
    sable. Un filtre sur le vocabulaire, pas sur l'algorithmique. Les noms que l'élève définit lui-même (une
    variable ``sum``), et ceux que le sujet lui fournit (``connus`` : le prélude de la question), ne sont pas ceux des
    builtins. ``premiere`` : le numéro qu'affiche l'éditeur pour la première ligne (``Code.premiere_ligne``)."""
    arbre = ast.parse(source, fichier)
    ast.increment_lineno(arbre, premiere - 1)  # l'arbre n'est que lu, jamais compilé : un numéro ≤ 0 n'y gêne pas
    noeuds = list(ast.walk(arbre))
    siens = set(connus) | {n.id for n in noeuds if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del))}
    siens |= {n.name for n in noeuds if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    siens |= {a.arg for n in noeuds if isinstance(n, ast.arguments) for a in (*n.posonlyargs, *n.args, *n.kwonlyargs)}
    siens |= {(a.asname or a.name).split(".")[0] for n in noeuds if isinstance(n, (ast.Import, ast.ImportFrom)) for a in n.names}
    for n in noeuds:
        if isinstance(n, ast.Attribute) and (n.attr in ATTRIBUTS or _blanchiment(n.attr, permis)):
            raise Interdit(f"ligne {n.lineno} : « .{n.attr} » n'est pas autorisé ici")
        if isinstance(n, ast.Name) and n.id not in siens:
            if n.id in REFLEXION:
                raise Interdit(f"ligne {n.lineno} : « {n.id} » n'est pas autorisé ici")
            # « __name__ », « __file__ » sont des attributs du module builtins, pas des fonctions du programme :
            # un élève qui écrit « if __name__ == "__main__" » ne doit pas être refusé (mesuré).
            if hasattr(builtins, n.id) and not n.id.startswith("__") and n.id not in permis["fonctions"]:
                raise HorsProgramme(f"ligne {n.lineno} : « {n.id} » n'est pas au programme")
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            for nom in ([a.name for a in n.names] if isinstance(n, ast.Import) else [n.module or ""]):
                if nom.split(".")[0] not in permis["modules"]:
                    raise HorsProgramme(f"ligne {n.lineno} : le module « {nom} » n'est pas au programme")


def _blanchiment(nom, permis):
    """« inspect.os », « random._os » : un module refusé atteint par la bande, sans l'importer. Un module doublé
    (``permis["doublures"]``, « os » simulé) l'est aussi : par la bande, ce serait le vrai."""
    net = nom.lstrip("_")
    return ((net in sys.modules or net in ("importlib", "gc"))
            and (net not in permis["modules"] or net in permis.get("doublures", {})))


# COUCHE 2 : ce que le code IMPORTE -------------------------------------------------------------------------

def espace(permis, **noms):
    """L'espace de noms de l'élève : les vrais builtins, sauf ``__import__``, borné aux modules du niveau. La
    bibliothèque standard, elle, garde le vrai : ses imports internes ne sont pas ceux de l'élève. ``permis["doublures"]``
    : {nom: module} rendus à la place du vrai (« os » simulé, ``verifier.SystemeSimule``), et déjà importés."""
    doublures = permis.get("doublures", {})

    def importer(nom, globaux=None, locaux=None, depuis=(), niveau=0):
        if nom.split(".")[0] not in permis["modules"]:
            raise Interdit(f"le module « {nom} » n'est pas autorisé ici")
        if nom in doublures:  # « import os.path » lie « os », « from os.path import join » lit « os.path »
            return doublures[nom if depuis else nom.split(".")[0]]
        return builtins.__import__(nom, globaux, locaux, depuis, niveau)
    return {**{n: m for n, m in doublures.items() if "." not in n}, **noms,
            "__builtins__": {**vars(builtins), "__import__": importer}}


# COUCHE 3 : ce que le code FAIT ----------------------------------------------------------------------------

def poser(dossier, aussi=(), avec_sqlite3: bool = False) -> None:
    """Après cet appel, écrire un fichier, lire hors de ``dossier`` (et de ``aussi``, des chemins ajoutés à la main),
    ouvrir le réseau, lancer un processus ou
    appeler du code natif lève ``Interdit``, d'où que cela vienne. Irréversible : un crochet d'audit ne s'enlève
    pas. Limite aussi la mémoire (1 Go) : une boucle d'allocation meurt en ``MemoryError`` au lieu de faire
    gonfler la machine pendant le délai de garde.

    Les familles d'événements sont écrites en dur dans le crochet : une variable se réécrit depuis le code de
    l'élève, une constante de code non. ``lisibles`` est une fermeture, mais elle n'est atteignable que par
    ``__closure__``, ``__code__`` ou ``gc``, tous refusés par ``analyser``.

    ``avec_sqlite3`` : sqlite3 au programme de la question. Sinon il n'est pas importé (dans le navigateur, sa roue de
    0,6 Mo, que ne doit pas payer un ▶ python de Seconde ou de Première) et toute connexion est refusée. Importé plus
    tard, après le crochet, il ne s'installerait pas : la roue s'écrit dans site-packages (mesuré, DONE)."""
    try:
        import resource  # noqa: PLC0415 - absent sous Windows
        resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
    except ImportError:
        pass
    lisibles = (str(Path(dossier).resolve()), sys.prefix, sys.base_prefix, str(Path(ast.__file__).parent), *aussi)
    bornee = _borner_sqlite3() if avec_sqlite3 else None

    def crochet(evenement, arguments):
        if evenement == "open":
            chemin, mode, drapeaux = (list(arguments) + [None, None, None])[:3]
            # ``os.open`` ne passe pas de mode mais des drapeaux entiers : O_WRONLY|O_RDWR|O_CREAT|O_APPEND|O_TRUNC
            if (set(str(mode)) & set("wxa+")) if mode else (drapeaux or 0) & 0x1C3:
                raise Interdit("écrire dans un fichier n'est pas autorisé ici")
            if isinstance(chemin, (str, bytes)):
                absolu = str(Path(chemin.decode() if isinstance(chemin, bytes) else chemin).resolve())
                if not absolu.startswith(lisibles):
                    raise Interdit("lire un fichier hors du dossier de l'exercice n'est pas autorisé ici")
        # sqlite3 ouvre ses fichiers en C, sans événement « open » : la base elle-même est bornée au dossier de
        # l'exercice (un URI « file: » pourrait en sortir), puis chaque connexion refuse ATTACH, que VACUUM INTO
        # emploie aussi (mesuré : l'un et l'autre créent un fichier à l'adresse donnée)
        elif evenement == "sqlite3.connect":
            base = str(arguments[0].decode() if isinstance(arguments[0], bytes) else arguments[0])
            if base not in ("", ":memory:") and (base.startswith("file:")
                                                  or not str(Path(base).resolve()).startswith(lisibles[0])):
                raise Interdit("ouvrir une base hors du dossier de l'exercice n'est pas autorisé ici")
        elif evenement == "sqlite3.connect/handle" and type(arguments[0]) is not bornee:
            raise Interdit("cette connexion sqlite3 n'est pas autorisée ici : ouvrir la base par sqlite3.connect")
        # Par famille, pas par nom : ``socket.socket()`` lève ``socket.__new__``, qu'une liste nominative rate.
        # Pas de famille ``marshal.`` : la machinerie d'import démarshale les .pyc (random, json, re… refusés).
        elif evenement.startswith(("os.", "socket.", "subprocess.", "shutil.", "ctypes.", "urllib.", "ftplib.",
                                   "smtplib.", "http.client.", "webbrowser.", "pty.", "fcntl.", "winreg.",
                                   "tempfile.", "pickle.", "mmap.", "resource.", "glob.", "code.interact",
                                   "cpython.", "sqlite3.enable_load_extension", "sqlite3.load_extension")) and evenement not in (
                "os.listdir", "os.scandir", "os.stat", "os.getcwd", "os.chdir"):  # la bibliothèque standard en a besoin
            raise Interdit(f"« {evenement} » n'est pas autorisé ici")

    sys.addaudithook(crochet)


def _borner_sqlite3():
    """Le crochet voit la connexion sqlite3 avant son initialisation, trop tôt pour lui poser un autoriseur : c'est donc
    ``sqlite3.connect`` qui ne fabrique plus que des ``Bornee``, dont l'autoriseur refuse ATTACH (et VACUUM INTO), et le
    crochet qui refuse toute autre connexion (``sqlite3.Connection(…)`` direct, ``_sqlite3.connect``, une sous-classe)."""
    try:
        import sqlite3  # noqa: PLC0415
    except ImportError:  # un Python sans sqlite3 (Pyodide-Qt) : aucune connexion à borner
        return None

    class Bornee(sqlite3.Connection):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.set_authorizer(lambda action, *_: sqlite3.SQLITE_DENY if action == sqlite3.SQLITE_ATTACH else sqlite3.SQLITE_OK)

    connect = sqlite3.connect
    sqlite3.connect = lambda *args, **kwargs: connect(*args, **kwargs, factory=Bornee)
    return Bornee
