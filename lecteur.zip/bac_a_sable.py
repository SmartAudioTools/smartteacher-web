"""Borne ce que le programme d'un élève peut employer et faire, dans le processus enfant de verifier.py.

Trois couches indépendantes, chacune fermant ce que les autres laissent ouvert (mesuré : deux couches seules
laissaient écrire un fichier et lancer une commande) :

  1. ``analyser``  — ce que le code DIT, lu avant la première instruction : le vocabulaire qui n'existe que pour
                     s'évader (réflexion, attributs internes) et ce qui n'est pas au programme de la classe ;
  2. ``espace``    — ce que le code IMPORTE : un ``__import__`` propre à son espace de noms, borné aux modules du niveau ;
  3. ``poser``     — ce que le code FAIT : un crochet d'audit qui refuse écriture de fichier, lecture hors du dossier de
                     l'exercice, réseau, processus et code natif, d'où que l'appel vienne.

Ne borne pas le temps (délai de garde de verifier.py) ni la lecture dans le dossier de l'exercice, et ne remplace
pas un confinement du système d'exploitation. S'applique au code de l'ÉLÈVE seulement : les tests du professeur
emploient ``inspect``, ``globals``, ``any`` et ne sont jamais analysés.

Bibliothèque standard seule : ce module est importé par le côté enfant de verifier.py.
"""

import ast
import builtins
import sys
import unicodedata
from pathlib import Path

# CE QUI EST AU PROGRAMME, PAR NIVEAU -----------------------------------------------------------------------
# Relevé dans « L'ESSENTIEL DU LANGAGE PYTHON » (seconde, première), dans le BO pour la terminale et dans les
# ``import`` des cours de première. Chaque niveau ajoute au précédent. Une question peut fournir sa propre liste
# (``Code.autorises``), qui remplace celle du niveau.

SECONDE = {
    "fonctions": {"print", "input", "int", "float", "str", "bool", "len", "list", "range", "round", "abs"},
    "modules": {"math", "random", "turtle"},
}
PREMIERE = {
    "fonctions": SECONDE["fonctions"] | {"tuple", "dict", "set", "max", "min", "sum", "sorted", "type", "id", "enumerate",
                                         "zip", "isinstance", "chr", "ord", "bin", "hex", "repr", "open"},
    "modules": SECONDE["modules"] | {"time", "pyxel", "csv"},
}
TERMINALE = {
    "fonctions": PREMIERE["fonctions"] | {"super", "any", "all", "map", "filter", "reversed", "iter", "next", "object",
                                          "Exception", "ValueError", "TypeError", "IndexError", "KeyError",
                                          "ZeroDivisionError", "AssertionError", "StopIteration"},
    "modules": PREMIERE["modules"] | {"statistics", "fractions", "itertools", "functools", "collections", "json", "re",
                                      "copy", "datetime", "sqlite3"},
}
DEFAUT = TERMINALE  # classe inconnue : la plus large, la sécurité ne dépend pas de la classe

# CE QUI NE SERT QU'À SORTIR DU BAC À SABLE, QUEL QUE SOIT LE NIVEAU -----------------------------------------
ATTRIBUTS = {"__class__", "__base__", "__bases__", "__subclasses__", "__mro__", "mro", "__globals__", "__code__",
             "__closure__", "cell_contents", "__func__", "__self__", "__dict__", "__builtins__", "__import__",
             "__getattribute__", "__reduce__", "__reduce_ex__", "__loader__", "__spec__", "modules", "f_globals",
             "f_builtins", "f_locals", "gi_frame", "cr_frame"}
REFLEXION = {"eval", "exec", "compile", "getattr", "setattr", "delattr", "vars", "globals", "locals", "__import__",
             "breakpoint", "memoryview"}


class Interdit(PermissionError):
    """Ce que le programme a tenté n'est pas permis dans un exercice."""


class HorsProgramme(Interdit):
    """Ce que le programme emploie n'est pas au programme de la classe."""


def programme(classe="", autorises=None):
    """La liste blanche d'une question : la sienne si elle en a une, sinon celle de sa classe (« Première »,
    « 2nde », « 1GEN2 », « Tle »…), à défaut la plus large."""
    if autorises is not None:
        return {"fonctions": set(autorises) & set(dir(builtins)), "modules": set(autorises) - set(dir(builtins))}
    nom = "".join(c for c in unicodedata.normalize("NFD", classe.lower()) if not unicodedata.combining(c)).strip()
    if nom.startswith(("2", "seconde")):
        return SECONDE
    if nom.startswith(("1", "premiere")):
        return PREMIERE
    return TERMINALE if nom.startswith(("t", "terminale")) else DEFAUT


# COUCHE 1 : ce que le code DIT -----------------------------------------------------------------------------

def analyser(source, permis, fichier="<code>", connus=(), premiere=1):
    """Lève ``HorsProgramme`` pour ce que l'élève n'a pas appris, ``Interdit`` pour ce qui sert à sortir du bac à
    sable. Un filtre sur le vocabulaire, pas sur l'algorithmique. Les noms que l'élève définit lui-même (une
    variable ``sum``), et ceux que le sujet lui fournit (``connus`` : le prélude de la question), ne sont pas ceux des
    builtins. ``premiere`` : le numéro qu'affiche l'éditeur pour la première ligne (``Code.premiere_ligne``)."""
    arbre = ast.parse(source, fichier)
    ast.increment_lineno(arbre, premiere - 1)  # l'arbre n'est que lu, jamais compilé : un numéro ≤ 0 n'y gêne pas
    noeuds = list(ast.walk(arbre))
    siens = set(connus) | {n.id for n in noeuds if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del))}
    siens |= {n.name for n in noeuds if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    siens |= {a.arg for n in noeuds if isinstance(n, ast.arguments) for a in (*n.posonlyargs, *n.args, *n.kwonlyargs)}
    siens |= {(a.asname or a.name).split(".")[0] for n in noeuds if isinstance(n, (ast.Import, ast.ImportFrom)) for a in n.names}
    for n in noeuds:
        if isinstance(n, ast.Attribute) and (n.attr in ATTRIBUTS or _blanchiment(n.attr, permis)):
            raise Interdit(f"ligne {n.lineno} : « .{n.attr} » n'est pas autorisé ici")
        if isinstance(n, ast.Name) and n.id not in siens:
            if n.id in REFLEXION:
                raise Interdit(f"ligne {n.lineno} : « {n.id} » n'est pas autorisé ici")
            # « __name__ », « __file__ » sont des attributs du module builtins, pas des fonctions du programme :
            # un élève qui écrit « if __name__ == "__main__" » ne doit pas être refusé (mesuré).
            if hasattr(builtins, n.id) and not n.id.startswith("__") and n.id not in permis["fonctions"]:
                raise HorsProgramme(f"ligne {n.lineno} : « {n.id} » n'est pas au programme")
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            for nom in ([a.name for a in n.names] if isinstance(n, ast.Import) else [n.module or ""]):
                if nom.split(".")[0] not in permis["modules"]:
                    raise HorsProgramme(f"ligne {n.lineno} : le module « {nom} » n'est pas au programme")


def _blanchiment(nom, permis):
    """« inspect.os », « random._os » : un module refusé atteint par la bande, sans l'importer."""
    net = nom.lstrip("_")
    return (net in sys.modules or net in ("importlib", "gc")) and net not in permis["modules"]


# COUCHE 2 : ce que le code IMPORTE -------------------------------------------------------------------------

def espace(permis, **noms):
    """L'espace de noms de l'élève : les vrais builtins, sauf ``__import__``, borné aux modules du niveau. La
    bibliothèque standard, elle, garde le vrai : ses imports internes ne sont pas ceux de l'élève."""
    def importer(nom, globaux=None, locaux=None, depuis=(), niveau=0):
        if nom.split(".")[0] not in permis["modules"]:
            raise Interdit(f"le module « {nom} » n'est pas autorisé ici")
        return builtins.__import__(nom, globaux, locaux, depuis, niveau)
    return {**noms, "__builtins__": {**vars(builtins), "__import__": importer}}


# COUCHE 3 : ce que le code FAIT ----------------------------------------------------------------------------

def poser(dossier, aussi=()):
    """Après cet appel, écrire un fichier, lire hors de ``dossier`` (et de ``aussi``, des chemins ajoutés à la main),
    ouvrir le réseau, lancer un processus ou
    appeler du code natif lève ``Interdit``, d'où que cela vienne. Irréversible : un crochet d'audit ne s'enlève
    pas. Limite aussi la mémoire (1 Go) : une boucle d'allocation meurt en ``MemoryError`` au lieu de faire
    gonfler la machine pendant le délai de garde.

    Les familles d'événements sont écrites en dur dans le crochet : une variable se réécrit depuis le code de
    l'élève, une constante de code non. ``lisibles`` est une fermeture, mais elle n'est atteignable que par
    ``__closure__``, ``__code__`` ou ``gc``, tous refusés par ``analyser``."""
    try:
        import resource  # noqa: PLC0415 - absent sous Windows
        resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
    except ImportError:
        pass
    lisibles = (str(Path(dossier).resolve()), sys.prefix, sys.base_prefix, str(Path(ast.__file__).parent), *aussi)

    def crochet(evenement, arguments):
        if evenement == "open":
            chemin, mode, drapeaux = (list(arguments) + [None, None, None])[:3]
            # ``os.open`` ne passe pas de mode mais des drapeaux entiers : O_WRONLY|O_RDWR|O_CREAT|O_APPEND|O_TRUNC
            if (set(str(mode)) & set("wxa+")) if mode else (drapeaux or 0) & 0x1C3:
                raise Interdit("écrire dans un fichier n'est pas autorisé ici")
            if isinstance(chemin, (str, bytes)):
                absolu = str(Path(chemin.decode() if isinstance(chemin, bytes) else chemin).resolve())
                if not absolu.startswith(lisibles):
                    raise Interdit("lire un fichier hors du dossier de l'exercice n'est pas autorisé ici")
        # Par famille, pas par nom : ``socket.socket()`` lève ``socket.__new__``, qu'une liste nominative rate.
        # Pas de famille ``marshal.`` : la machinerie d'import démarshale les .pyc (random, json, re… refusés).
        elif evenement.startswith(("os.", "socket.", "subprocess.", "shutil.", "ctypes.", "urllib.", "ftplib.",
                                   "smtplib.", "http.client.", "webbrowser.", "pty.", "fcntl.", "winreg.",
                                   "tempfile.", "pickle.", "mmap.", "resource.", "glob.", "code.interact",
                                   "cpython.")) and evenement not in (
                "os.listdir", "os.scandir", "os.stat", "os.getcwd", "os.chdir"):  # la bibliothèque standard en a besoin
            raise Interdit(f"« {evenement} » n'est pas autorisé ici")

    sys.addaudithook(crochet)
