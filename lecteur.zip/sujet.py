"""Charge un sujet et ses banques : la partie commune aux exportateurs (voir README.md).

Une banque du sujet est un CHEMIN, ou la banque elle-même : c'est la forme que ``lire`` refait d'un paquet (``.qcm``,
ou le même embarqué dans un PDF), un sujet autoportant qui ne dépend plus de fichiers qui bougeront.
"""

import json
import os
import re
import subprocess
import tempfile
import zlib
from pathlib import Path
from typing import Any

from modele import LOGO, Banque, DefinitionSujet, au_choix, Paquet, Section, charger, copier, ordonner, parametres
from adresse import adresser, tutoyer, tutoyer_objet
from noyau import Conversion
from texte_md import RACINE
import codes

SUJETS = RACINE / "sujets"  # rangés par niveau, comme banque/ : NSI Première, NSI Terminale, SNT, ESGI, Exemples
PROF = Path("/DATA/Projets/TRAVAIL/Prof")  # le dossier des cours, où ``dossier`` range les exports d'un sujet
NIVEAUX = json.loads((RACINE / "referentiels/niveaux_bloom.json").read_text(encoding="utf-8"))["niveaux"]
NIVEAU_DU_VERBE = {verbe: niveau["libelle"] for niveau in NIVEAUX.values() for verbe in niveau["verbes"]}


def les_sujets() -> list[Path]:
    """Tous les sujets, dans leurs dossiers de niveau (``*/*.json`` : pas le ``.claude`` que Claude Code y sème), et ceux
    que ``entrainement.py`` compose pour « Réviser » (``*/Révisions/*.json``) ; pas de ``rglob`` : ``SNT/.old``."""
    return sorted([*SUJETS.glob("*/*.json"), *SUJETS.glob("*/Révisions/*.json")])


def points(p):
    return f"{p:g}".replace(".", ",") + (" points" if p >= 2 else " point")


def niveau_bloom(q):
    return NIVEAU_DU_VERBE.get(q.verbe_action, "")


def lire(chemin, mot_de_passe=None):
    """La définition d'un sujet : son fichier, ou celle que refait un paquet (``.qcm`` d'un export électronique, celui
    qu'embarque un PDF, ou un paquet en clair) : questions et médias embarqués, plus aucun chemin de banque, les
    réglages du sujet tels qu'à l'export. Sans lui, corriger un scan après avoir retouché une question deviendrait
    impossible : la page vierge de référence ne serait plus celle que l'élève avait entre les mains."""
    if chemin.suffix == ".pdf":
        with tempfile.TemporaryDirectory() as dossier:
            qcm = Path(dossier) / chemin.with_suffix(".qcm").name  # le nom de l'élève : la clé de sa classe (voir.essayer)
            qcm.write_bytes(piece_jointe(chemin))
            return lire(qcm, mot_de_passe)
    if chemin.suffix == ".qcm":
        from voir import essayer  # noqa: PLC0415 - les mots de passe essayés à l'ouverture d'un .qcm (professeur, défaut)
        objet, _ = essayer(chemin, mot_de_passe)
    else:
        objet = charger(chemin)
    if not isinstance(objet, Paquet):
        return objet
    if not (objet.graine or objet.graine_sujet):
        raise ValueError(f"{chemin} : la copie d'un élève, déjà préparée pour lui ; prendre le sujet distribué")
    banque = Banque(objet.matiere, [copier(q) for q in objet.questions()], theme=objet.theme, contextes=dict(objet.contextes), bases=dict(objet.bases),
                    medias={nom: octets for nom, octets in objet.medias.items() if nom != LOGO})
    sections = [Section([q.id for q in s.questions], s.titre, s.consignes, s.bonus, s.nouvelle_page, s.electronique, s.partie) for s in objet.sections]
    # sauf le cours : le paquet le cite depuis le dossier du .qcm, plus du professeur, et le papier ne s'en sert pas
    reglages = {k: v for k, v in objet.__serializejson__()[2].items() if k in parametres(DefinitionSujet) and k != "cours"}
    # une copie papier : ses questions sont celles imprimées, ``graine_sujet`` rend le tirage du sujet (``Paquet``)
    graine = {"graine": objet.graine or objet.graine_sujet}
    # ses questions bonus portent déjà leurs points réduits (``exporter_eleve.paquet``) : ne pas les réduire une seconde fois
    return DefinitionSujet(**{**copier(reglages), **graine, **reglages_deduits(objet), "banques": [banque], "sections": sections,
                              "coefficient_bonus": 1})


def reglages_deduits(objet: Paquet) -> dict[str, Any]:
    """Les réglages du sujet que ``Paquet`` n'a pas en champ, refaits de ce qu'il porte : sans eux, relire un paquet
    remettait les conversions au niveau 1 (``Sujet`` l'impose à toutes), perdait les PDF du jugement (le cours n'est pas
    repris) et les niveaux d'un sujet sur plusieurs niveaux."""
    deduits: dict[str, Any] = {}
    if niveau := next((f.niveau for q in objet.questions() for f in q.feuilles() if isinstance(f, Conversion)), None):
        deduits["niveau_conversions"] = niveau
    if pdfs := (objet.jugement or {}).get("cours_pdf"):  # relatifs au dossier du .qcm (``exporter_eleve.paquet``)
        deduits["cours_jugement"] = [os.path.relpath(os.path.normpath(sortie(objet, "qcm") / c), PROF) for c in pdfs]
    try:
        niveaux = {codes.niveau(classe) for classe in objet.inscrits or {}}
    except ValueError:  # un nom de classe qui ne dit pas son niveau : rien de deviné
        niveaux = set()
    if len(niveaux) > 1:
        deduits["niveaux"] = [n for n in ("Seconde", "Première", "Terminale") if n in niveaux]
    return deduits


def piece_jointe(chemin, nom=None):
    """Le ``.qcm`` qu'embarque un PDF d'``exporter_pdf.py`` (``QPdfWriter.addFileAttachment`` : un flux compressé, que
    désigne le ``/EF`` de sa fiche de fichier), la première pièce jointe ; ou, avec ``nom``, la pièce de ce nom
    (``exporter_pdf.PLAN``, le plan des cases). Lu à la main, faute de bibliothèque PDF : seuls ces PDF-là sont visés,
    dont Qt écrit le nom de fichier en UTF-16 avec sa marque d'ordre, juste avant le ``/EF``. Sans ``nom``, le plan des
    cases n'est jamais pris pour le ``.qcm`` : un PDF exporté sans paquet ne joint que lui. La copie pour l'élève
    (``codes.PIECE_ELEVE``) ne sort qu'à défaut de celle du professeur : c'est la seule que garde le PDF corrigé (le
    professeur, 17/11/2026 : « Je ne veux pas garder des doublons ») ; ``voir.essayer`` l'ouvre par la clé de la classe
    de l'élève (W806)."""
    octets = Path(chemin).read_bytes()
    def fiches(nom):
        avant = rb"/F\s*\(" + re.escape("\ufeff".encode("utf-16-be") + nom.encode("utf-16-be")) + rb"\)\s*" if nom else b""
        return re.finditer(avant + rb"/EF\s*<<\s*/F\s+(\d+)\s+0\s+R", octets)
    plan = {f[1] for n in ("plan.json", "positions.json") for f in fiches(n)} if not nom else set()  # exporter_pdf.PLAN, POSITIONS
    plan |= {str(n).encode() for n in codes.fiches_eleve(octets)} if not nom else set()  # la copie pour l'élève (W763)
    fiche = next((f for f in fiches(nom) if f[1] not in plan), None)
    if fiche is None and not nom and (eleve := codes.piece_eleve(octets)) is not None:  # pièce élève seule (17/11/2026)
        return eleve  # lue par codes : qpdf l'écrit avec un /Params imbriqué que le motif ci-dessous ne prend pas
    flux = fiche and re.search(rb"(?m)^" + fiche[1] + rb" 0 obj\s*<<([^>]*)>>\s*stream\r?\n", octets)
    if not flux or b"/FlateDecode" not in flux[1]:
        raise ValueError(f"{chemin} : pas de {nom or '.qcm'} joint (PDF d'avant la pièce jointe, ou réenregistré par un autre logiciel)")
    try:
        return zlib.decompressobj().decompress(octets[flux.end():])
    except zlib.error:  # un flux vide : celui du .qcm des PDF d'octobre 2026 (rev 715), joint sans contenu
        raise ValueError(f"{chemin} : {nom or '.qcm'} joint vide ou illisible") from None


def diaporama(cours: Path) -> Path:
    """Le PDF du diaporama du cours dont ``cours`` est le PDF : « <titre> - diaporama.pdf » à côté, exporté du .pptx du
    même nom par ``.construction/cours/moteur/exporter_pdf.sh`` (l'utilisateur, 06/11/2026 : « pour les cours il faut
    proposer la version pdf et la version slides »)."""
    return cours.with_name(f"{cours.stem} - diaporama.pdf")


def sortie(definition, sorte):
    """Le dossier où exporter le sujet ``definition``, ``sorte`` : « qcm », « pdf » ou « corrigé ». C'est le dossier du cours
    que nomme son ``dossier`` (« NSI/NSI Première/Python/TP »), tel quel : un sujet électronique n'y a que son ``.qcm``, ses PDF
    se font à la demande, depuis le menu de Dolphin (``pdf_qcm.py``), à côté de lui ; un DS papier, ses deux PDF (demande de
    l'utilisateur, 30/09/2026, qui remplace les sous-dossiers « QCM », « PDF » et « PDF Correction » du 28/09). À défaut de
    ``dossier``, ``Exports/qcm`` ou ``Exports/pdf`` (le corrigé avec le sujet) pour les sujets hors cours (ESGI, bac, exemples)."""
    if not definition.dossier:
        return RACINE / "Exports" / ("qcm" if sorte == "qcm" else "pdf")
    return PROF / definition.dossier


def revision():
    """La révision de SmartTeacher au moment de l'export (« 43:1a2b3c4d », un « + » final si le dépôt avait des
    modifications non commitées), pour pouvoir y revenir si la mise en page des PDF a changé depuis : les questions
    figées ne suffisent pas, le rendu doit être celui d'alors. Chaîne vide hors dépôt (pas de Mercurial, ou export
    depuis une copie installée) : c'est un repère, pas une condition de l'export. Une archive (``deployer.sh`` exporte depuis un
    ``hg archive``, qui n'est pas un dépôt) donne la sienne par ``SMARTTEACHER_REVISION``."""
    if archivee := os.environ.get("SMARTTEACHER_REVISION"):
        return archivee
    try:
        sortie = subprocess.run(["hg", "id", "-i", "-n", "-R", str(RACINE.parent)], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired):  # hg absent ; ou verrou du dépôt tenu par une autre session, un export n'attend pas derrière elle
        return ""
    if sortie.returncode:
        return ""
    empreinte, numero = sortie.stdout.split()  # « 1a2b3c4d+ 43+ », le + signalant des modifications non commitées
    return f"{numero.rstrip('+')}:{empreinte}"


def zones_code(pdf: Path) -> list[list[float]]:
    """[[page, x, y, largeur, hauteur], …] en points depuis le haut gauche : par ligne, l'étendue de son texte en police à
    chasse fixe (le code des documents, en DejaVu Sans Mono). Une ligne et non un mot : la sélection du lecteur se vérifie
    par ligne (``QPdfView.setCopyZones`` de qtpy6). [] sans pdftohtml ou pour un PDF illisible : rien ne se copie."""
    try:
        xml = subprocess.run(["pdftohtml", "-xml", "-i", "-zoom", "1", "-stdout", str(pdf)],
                             capture_output=True, text=True, check=True).stdout
    except (OSError, subprocess.CalledProcessError):
        return []
    mono = set(re.findall(r'<fontspec id="(\d+)"[^>]*family="[^"]*Mono', xml))
    lignes = {}
    for page, contenu in re.findall(r'<page number="(\d+)".*?>(.*?)</page>', xml, re.S):
        for haut, gauche, largeur, hauteur, police in re.findall(
                r'<text top="(-?\d+)" left="(-?\d+)" width="(\d+)" height="(\d+)" font="(\d+)"', contenu):
            if police in mono:
                cle, (x0, y0) = (int(page) - 1, int(haut)), (int(gauche), int(haut))
                a = lignes.get(cle, [x0, y0, x0 + int(largeur), y0 + int(hauteur)])
                lignes[cle] = [min(a[0], x0), min(a[1], y0), max(a[2], x0 + int(largeur)), max(a[3], y0 + int(hauteur))]
    return [[page, x0, y0, x1 - x0, y1 - y0] for (page, _), (x0, y0, x1, y1) in sorted(lignes.items())]


def conflits(banques):
    """Les noms de contexte, de média ou de base que deux des ``banques`` ([(nom de fichier, Banque)]) définissent
    différemment : ``Sujet.__init__`` les fusionne banque après banque, la dernière écraserait l'autre, et les questions de
    la première afficheraient le texte (ou l'image) de la seconde. Valeurs égales : rien, le même préambule recopié dans
    deux banques est légitime ; les médias se comparent par octets."""
    fusion, messages = {"contexte": {}, "media": {}, "base": {}}, []  # genre -> {nom: (valeur, banque qui l'a posée)}
    for fichier, banque in banques:
        for genre, contenu in (("contexte", banque.contextes), ("media", banque.medias), ("base", banque.bases)):
            for nom, valeur in contenu.items():
                deja, ou = fusion[genre].setdefault(nom, (valeur, fichier))
                if deja != valeur:
                    messages.append(f"{genre} « {nom} » : défini différemment par « {ou} » et par « {fichier} », "
                                    "la dernière banque chargée écraserait l'autre")
    return messages


def au_dixieme(points: float) -> float:
    """``points`` au dixième de point, un dixième au moins s'il y en a : une question bonus vaut quelque chose. Le quart de
    point, essayé d'abord, saute trop : douze points de bonus sur un total de 20 tombaient à 3,5 au lieu de 5."""
    return max(0.1, round(points * 10) / 10) if points > 0 else 0


def coefficient_bonus(points: list[float], total: float) -> float:
    """Ce que valent les questions bonus, rapportées à leur barème (``points`` : celui de chaque feuille, justification à
    part) : la moitié, moins si l'ensemble, au dixième de point, dépasse le quart de ``total`` ; sous ce quart, rien n'est
    forcé. Demande de l'utilisateur, 24/10/2026 : « avoir des notes qui soient plus faibles pour les questions bonus […] on
    limite à 5 points en diminuant encore », puis « le quart du total ». La note ajoute les bonus sans dépasser ``total``
    (``Paquet.resultat``, l'en-tête de la copie)."""
    coefficient = 0.5
    while coefficient > 0.01 and round(sum(au_dixieme(p * coefficient) for p in points), 6) > total / 4:
        coefficient -= 0.001
    return coefficient


def reduire(question: Any, coefficient: float, arrondi: Any = au_dixieme) -> Any:
    """``question`` aux points d'une question bonus : ceux de chaque feuille, justification comprise, et ceux de sa version
    pour l'écran, multipliés par ``coefficient`` au dixième de point (``au_dixieme``) ; ``arrondi=None`` : sans arrondi
    (``Sujet.limiter_le_temps``)."""
    arrondi = arrondi or (lambda p: p)
    if question.sous_questions:
        return copier(question, sauf=("sous_questions", "saisie"),
                      imposes={"sous_questions": [reduire(sq, coefficient, arrondi) for sq in question.sous_questions]})
    imposes = {"points": arrondi(question.points * coefficient)}
    if question.justification:
        imposes["justification"] = copier(question.justification,
                                          imposes={"points": arrondi(question.justification.points * coefficient)})
    if isinstance(question.electronique, dict):
        imposes["electronique"] = _variante_reduite(question.electronique, coefficient, arrondi)
    return copier(question, sauf=("saisie",), imposes=imposes)


def rebaremer(question: Any, points: dict[str, float]) -> Any:
    """``question`` dont chaque feuille nommée dans ``points`` ({id de feuille : points}) prend ces points (``reduire`` à
    son propre coefficient, justification et version pour l'écran comprises), les autres inchangées
    (``Sujet.limiter_le_temps``, barème du temps limité)."""
    if question.sous_questions:
        return copier(question, sauf=("sous_questions", "saisie"),
                      imposes={"sous_questions": [rebaremer(sq, points) for sq in question.sous_questions]})
    if question.id not in points:
        return question
    return reduire(question, points[question.id] / question.points, arrondi=None)


def _variante_reduite(variante: dict[str, Any], coefficient: float, arrondi: Any = au_dixieme) -> dict[str, Any]:
    """La version pour l'écran d'une question (``Question.electronique``), ses points réduits comme ceux du papier."""
    variante = dict(variante)
    if "points" in variante:
        variante["points"] = arrondi(variante["points"] * coefficient)
    if isinstance(variante.get("sans_ide"), dict):
        variante["sans_ide"] = _variante_reduite(variante["sans_ide"], coefficient, arrondi)
    return variante


def graine_de(definition: Any) -> str:
    """La graine du sujet ``definition``, d'où son tirage et la clé de son ``.qcm`` (``exporter_eleve.cle_neuve``)."""
    return str(definition.graine if definition.graine is not None else definition.titre)


class Sujet:
    def __init__(self, chemin: Path | str, eleve: dict[str, str] | None = None, regle_bonus: bool = False,
                 temps_limite: bool = False) -> None:
        """``eleve`` : {"nom", "prenom"} pour une copie individuelle (en-tête rempli, tirages propres à l'élève).
        ``regle_bonus`` : les bonus à la règle du 24/10/2026 (``coefficient_bonus``) même si la définition fixe le
        coefficient ; c'est la NOTE d'un sujet imprimé avant elle (``layout_retrouve.SujetImprime.note``), son papier
        gardant le barème plein (le professeur, 08/11/2026 : « réduire après coup, en gardant l'ancien sujet pour extraire
        le sujet du scan »)."""
        self.chemin = Path(chemin)
        self.definition = d = lire(self.chemin)
        self.eleve = eleve
        self.graine = graine_de(d) + (f"|{eleve['nom']}|{eleve['prenom']}" if eleve else "")
        self.questions, self.contextes, self.medias, self.bases = {}, {}, {}, {}  # medias : nom -> bytes
        self.groupe_de = {}  # id de sous-question -> id de son groupe
        self.banques = []  # gardées en vie : une banque (widget Qt) ramassée détruit ses questions avec elle
        for fichier in d.banques:
            banque = fichier if isinstance(fichier, Banque) else charger((self.chemin.parent / fichier).resolve())
            self.banques.append(banque)
            self.questions.update({q.id: q for q in banque.questions})
            self.groupe_de.update({sq.id: q.id for q in banque.questions for sq in q.sous_questions})
            self.contextes.update(banque.contextes)
            self.medias.update(banque.medias)
            self.bases.update(banque.bases)
        if erreurs := conflits([(f if isinstance(f, str) else "banque embarquée", b) for f, b in zip(d.banques, self.banques)]):
            raise ValueError(f"{self.chemin} : " + " ; ".join(erreurs))  # pas d'export d'un sujet dont une banque écrase l'autre
        adresser(d.adresse)  # les messages du programme, dont les consignes des widgets que ``tutoyer_objet`` refait
        if d.adresse == "tu":  # les banques vouvoient, le sujet tutoie : ses textes et ceux des questions qu'il pose (``adresse.py``)
            cites = {r if isinstance(r, str) else r.id for s in d.sections for r in s.questions}
            self.questions |= {i: tutoyer_objet(q) for i, q in self.questions.items() if i in cites}
            self.contextes = tutoyer_objet(self.contextes, "contextes")
            d.titre, d.sous_titre, d.consignes = (tutoyer(t) for t in (d.titre, d.sous_titre, d.consignes))
            d.sections = tutoyer_objet(d.sections)
        for q in self.questions.values():  # le niveau des conversions est celui du sujet : on change d'aide sans toucher la banque
            for f in q.feuilles():
                if isinstance(f, Conversion):
                    f.niveau = d.niveau_conversions
        self.sections = [self.resoudre(section) for section in d.sections]
        if temps_limite and d.retirees_temps_limite:  # tiers-temps sans allongement : questions retirées, même total
            self.limiter_le_temps(d.retirees_temps_limite, d.bareme_temps_limite)
        self.total = sum(au_choix([sum(p for _, p in resolues) for section, resolues in self.sections if not section.bonus],
                                  d.exercices_au_choix))
        # les bonus, à leur barème réduit, s'impriment et s'affichent tels quels (``coefficient_bonus``)
        self.coefficient_bonus = (None if regle_bonus else d.coefficient_bonus) or coefficient_bonus(
            [p for section, resolues in self.sections if section.bonus for q, _ in resolues for f in q.feuilles()
             for p in (f.points, f.justification.points if f.justification else 0) if p], self.total)
        if self.coefficient_bonus != 1:
            self.sections = [(section, [(r, r.total()) for r in (reduire(q, self.coefficient_bonus) for q, _ in resolues)]
                              if section.bonus else resolues) for section, resolues in self.sections]
        # le visuel propre au sujet (themes/<nom du sujet>.png : TP1 Localisation, 07/10/2026), sinon celui du thème
        visuels = [RACINE / "themes" / f"{self.chemin.stem}.png"] + ([RACINE / "themes" / f"{d.theme}.png"] if d.theme else [])
        self.logo = next((v for v in visuels if v.exists()), None)

    def limiter_le_temps(self, retirees: list[str], bareme: dict[str, float] | None = None) -> None:
        """Le sujet d'un élève tiers-temps quand la durée ne peut pas s'allonger (le professeur, 10/11/2026 : « dans ce cas il
        faut retire des questions ») : les questions ``retirees`` (ids, ``DefinitionSujet.retirees_temps_limite``) sortent de
        leurs sections. ``bareme`` ({id de feuille gardée : points}, ``DefinitionSujet.bareme_temps_limite``) donne les
        nouveaux points des feuilles qu'il nomme, les autres gardent les leurs, et le total doit être celui du sujet complet
        (le professeur, 10/11/2026 : « tu peux adapter les barème question par question pour retomber sur 20 ») ; sans lui,
        les points des questions gardées sont mis à l'échelle (``reduire``, sans arrondi). Les bonus ne bougent pas."""
        if inconnues := set(retirees) - {q.id for _, resolues in self.sections for q, _ in resolues}:
            raise ValueError(f"{self.chemin.name} : retirees_temps_limite hors du sujet : {sorted(inconnues)}")
        complet = sum(p for section, resolues in self.sections if not section.bonus for _, p in resolues)
        gardees = [(section, [(q, p) for q, p in resolues if q.id not in retirees]) for section, resolues in self.sections]
        reste = sum(p for section, resolues in gardees if not section.bonus for _, p in resolues)
        if not reste:
            raise ValueError(f"{self.chemin.name} : retirees_temps_limite retire toutes les questions")
        if bareme:
            feuilles = {f.id for section, resolues in gardees if not section.bonus for q, _ in resolues for f in q.feuilles()}
            if inconnues := set(bareme) - feuilles:
                raise ValueError(f"{self.chemin.name} : bareme_temps_limite hors des feuilles gardées : {sorted(inconnues)}")
            for section, resolues in gardees:  # une feuille sans points ou justifiée n'a pas un seul nombre à remplacer
                for q, _ in resolues:
                    for f in q.feuilles():
                        if f.id in bareme and (not f.points or f.justification):
                            raise ValueError(f"{self.chemin.name} : bareme_temps_limite sur {f.id}, feuille sans points"
                                             " ou justifiée")
            # une question qu'il ne nomme pas garde ses points posés (imposés par le sujet compris)
            self.sections = [(section, resolues if section.bonus else
                              [(r, r.total()) if any(f.id in bareme for f in q.feuilles()) else (q, p)
                               for q, p in resolues for r in [rebaremer(q, bareme)]])
                             for section, resolues in gardees if resolues]
            if abs((total := sum(p for s, resolues in self.sections if not s.bonus for _, p in resolues)) - complet) > 1e-9:
                raise ValueError(f"{self.chemin.name} : bareme_temps_limite fait {total:g} points au lieu de {complet:g}")
            return
        coefficient = complet / reste
        self.sections = [(section, resolues if section.bonus else
                          [(r, p * coefficient) for (q, p) in resolues for r in [reduire(q, coefficient, arrondi=None)]])
                         for section, resolues in gardees if resolues]

    def posees(self, section):
        """[(question de la banque, points imposés par le sujet ou ``None``)] : les questions de ``section``, dans son ordre."""
        posees = []
        for reference in section.questions:
            id_, forces = (reference, None) if isinstance(reference, str) else (reference.id, reference.points)
            if id_ not in self.questions:
                raise ValueError(f"{self.chemin} : question inconnue {id_}")
            posees.append((self.questions[id_], forces))
        return posees

    def cours_masques(self) -> dict[str, dict[str, list[float]]]:
        """{cours du sujet : {id : zone}} : les questions posées dont il donne la réponse (``masque_cours`` = son nom sans
        extension, d'une question ou d'une de ses sous-questions) et où (``zone_cours``) ; le lecteur la montre en pavés tant
        qu'elles restent ouvertes (``Paquet.masques_cours``). Une question de banque le porte, pas le sujet : la question sait
        où est sa réponse. Seulement dans un entraînement, dont les « Révision NN » (l'utilisateur, 10/11/2026 : « un revision
        est juste un entraintment sur tout une thématique, et sans personnalisation ») (06/11/2026 : « pour l'instant seulement dans les
        entraînements de Réviser, les TP aident à découvrir le cours ») : un TP montre le cours entier."""
        if not self.definition.est_revision:
            return {}
        masques = {c: {q.id: f.zone_cours for s in self.definition.sections for q, _ in self.posees(s)
                       for f in (q, *q.sous_questions) if f.masque_cours == Path(c).stem and f.zone_cours}
                   for c in self.definition.cours}
        return {c: zones for c, zones in masques.items() if zones}

    def cours_code(self) -> dict[str, list[list[float]]]:
        """{cours du sujet : zones de code} : seul leur texte se copie dans le lecteur (l'utilisateur, 06/10/2026 : « que les
        partie du pdf qui correspond à du code python »), vers l'éditeur du lecteur comme vers un éditeur externe. Le 06/10,
        un sujet sans éditeur externe n'en avait aucune ; levé le 13/10/2026 (« le code python dans le pdf du cours n'est
        pas copiable depuis le lecteur dans le lecteur, ce n'est pas normal », puis « oui » à l'ouvrir à tous les sujets)."""
        zones = {c: zones_code(PROF / c) for c in self.definition.cours}
        return {c: z for c, z in zones.items() if z}

    def resoudre(self, section):
        """(section, resolues) : ``resolues`` = ses (question tirée, points), une seule aide chacune, mélangées si le sujet le
        demande, chacune après celles dont elle révèle la réponse (comme le lecteur les prépare, ``Paquet.nommer``)."""
        resolues = []
        for q, forces in self.posees(section):
            q = q.instancier(f"{self.graine}|{q.id}", points=forces)
            for f in q.feuilles():
                f.garder_une_aide(self.definition.acces_cours)
            resolues.append((q, q.total() if forces is None else forces))
        d = self.definition
        return section, ordonner(resolues, self.groupe_de, d.melanger_questions and d.titre)
