"""Le formulaire d'un sujet PDF : des champs AcroForm posés sur ce que l'élève remplit, pour composer à l'ordinateur
dans un lecteur de PDF (Okular, Firefox, Edge, Acrobat) le même sujet que celui qu'on imprime (le professeur,
21/11/2026, AS-11 : « prendre directement le PDF du sujet … et juste rajouter des champs dessus », « autant les mettre
… sur tous les PDF générés »).

Les places viennent de la pièce jointe ``positions.json`` qu'``exporter_pdf.positions_imprimees`` écrit au moment de la
mise en page : cases (carrées : à cocher ; rondes : un bouton radio par question), lignes de réponse (un champ de
plusieurs lignes, de la première à la dernière), trous, cases vides des tableaux bordés, et les traits Nom, Prénom,
Classe (un champ par nom, son texte repris sur chaque page), et les puces d'un appariement (``appariement``). Aucune relecture du PDF : une seule source des places.
L'écriture est en Kalam (``modele.MAIN``, incorporée), assez grande pour une vue faible ; les champs n'ont ni bord ni
fond opaque, pour ne pas doubler le trait imprimé. Les champs s'ajoutent par ``qpdf --update-from-json`` (pas de
bibliothèque PDF dans SmartPython).

    $P formulaire_pdf.py <sujet.pdf> [sortie.pdf]
"""
from __future__ import annotations

import base64
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

MAIN = Path(__file__).parent / "polices" / "Kalam-Regular.ttf"  # modele.MAIN, sans charger Qt
TAILLE_MAX = 16  # points : l'écriture d'un champ d'une ligne (Nom, case de tableau, trou), si sa hauteur le permet
PAS_LIGNES = 79 * 72 / 300  # points : le pas des lignes d'écriture du sujet, pour un champ d'une seule ligne
TRAIT = 3 * 72 / 300  # points : l'épaisseur d'un trait de tableau (``traits_des_tableaux``)
ZONE = 7  # points : le demi-côté de la zone cliquable autour d'une puce d'appariement


def qpdf(*arguments: str) -> bytes:
    """La sortie de qpdf ; son code 3 (avertissements, la commande a abouti) n'est pas une erreur."""
    fini = subprocess.run(["qpdf", *arguments], capture_output=True)
    if fini.returncode not in (0, 3):
        raise subprocess.CalledProcessError(fini.returncode, ["qpdf", *arguments], fini.stdout, fini.stderr)
    return fini.stdout


def lire_positions(pdf: Path) -> dict[str, Any]:
    return json.loads(qpdf("--show-attachment=positions.json", str(pdf)))


def champs_du_sujet(positions: dict[str, Any], identite: bool = True) -> list[dict[str, Any]]:
    """Les champs à poser : {nom, sorte (« case », « radio », « texte » ; pour un appariement « bouton », « dessin », « cache »), widgets [(page, [x0, y0, x1, y1] en points
    depuis le haut de la page)], taille, multiligne, valeurs (une par widget d'un radio)}."""
    k = 72 / positions["ppp"]
    pt = lambda r: [v * k for v in r]  # noqa: E731
    interligne = interligne_kalam()

    def ligne(nom: str, page: int, r: list[float], centre: bool = False) -> dict[str, Any]:
        """Un champ d'une ligne posé sur le bas de ``r`` (le trait ou le bas de la case), haut d'une ligne d'écriture :
        un lecteur aligne le texte d'un champ d'une ligne en haut ou au milieu, jamais sur le trait."""
        taille = min(TAILLE_MAX, (r[3] - r[1]) / interligne)
        return {"nom": nom, "sorte": "texte", "widgets": [(page, [r[0], r[3] - taille * interligne, r[2], r[3]])],
                "taille": round(taille, 1), "multiligne": False, "centre": centre}

    champs = []
    if identite:
        par_nom: dict[str, list] = {}
        for c in positions.get("identite", []):
            par_nom.setdefault(c["champ"], []).append(ligne(c["champ"], c["page"], pt(c["rect"]))["widgets"][0])
        champs += [{"nom": nom, "sorte": "texte", "widgets": w, "taille": min(TAILLE_MAX, (w[0][1][3] - w[0][1][1]) / interligne),
                    "multiligne": False} for nom, w in par_nom.items()]
    for q in positions["questions"]:
        qid = q["id"]
        cases = q.get("cases") or []
        if cases and all(c["forme"] == "rond" for c in cases):
            champs.append({"nom": qid, "sorte": "radio", "widgets": [(c["page"], pt(c["rect"])) for c in cases],
                           "valeurs": [f"c{c['proposition'] if c['proposition'] is not None else i}" for i, c in enumerate(cases)]})
        else:
            champs += [{"nom": f"{qid}_c{c['proposition'] if c['proposition'] is not None else i}", "sorte": "case",
                        "widgets": [(c["page"], pt(c["rect"]))]} for i, c in enumerate(cases)]
        for p, lignes in groupes_de_lignes(q.get("lignes", [])):
            rects = [pt(l["rect"]) for l in lignes]
            pas = rects[1][1] - rects[0][1] if len(rects) > 1 else PAS_LIGNES
            rect = [min(r[0] for r in rects), rects[0][1] - pas, max(r[2] for r in rects), rects[-1][1]]
            if len(rects) == 1:
                champs.append(ligne(f"{qid}_l{len(champs)}", p, rect))
            else:  # une ligne de texte par ligne imprimée : la taille dont l'interligne de Kalam est le pas
                champs.append({"nom": f"{qid}_l{len(champs)}", "sorte": "texte", "widgets": [(p, rect)],
                               "taille": round(pas / interligne, 1), "multiligne": True})
        for i, t in enumerate(q.get("trous", [])):
            r = pt(t["rect"])
            champs.append(ligne(f"{qid}_t{i}", t["page"], [r[0], r[3] - PAS_LIGNES, r[2], r[3]], centre=True))
        for i, c in enumerate(sans_coin(q.get("cellules", []))):
            r = pt(c["rect"])  # du milieu d'un trait au milieu de l'autre : le dedans commence un demi-trait plus loin
            dedans = [r[0] + TRAIT / 2, r[1] + TRAIT / 2, r[2] - TRAIT / 2, r[3] - TRAIT / 2]
            if dedans[3] - dedans[1] > 2 * PAS_LIGNES:
                champs.append({"nom": f"{qid}_k{i}", "sorte": "texte", "widgets": [(c["page"], dedans)],
                               "taille": round(PAS_LIGNES / interligne, 1), "multiligne": True})
            else:  # une seule ligne, centrée dans la case
                champ = ligne(f"{qid}_k{i}", c["page"], dedans, centre=True)
                champ["widgets"] = [(c["page"], dedans)]
                champs.append(champ)
        if q.get("puces"):
            champs += appariement(qid, [(c["page"], (pt(c["rect"])[0] + pt(c["rect"])[2]) / 2,
                                         (pt(c["rect"])[1] + pt(c["rect"])[3]) / 2) for c in q["puces"]])
    return champs


def appariement(qid: str, centres: list[tuple[int, float, float]]) -> list[dict[str, Any]]:
    """Les champs d'un appariement relié par clics (le professeur, 21/11/2026 : « qui clique sur le bouton de départ,
    qui clique sur le bouton d'arrivée et que ça trace un... trait ») : un clic sur une puce de gauche l'entoure, un clic
    sur une puce de droite trace le trait du départ vers elle, et lui seul. Tous les traits possibles sont dessinés à
    l'avance, chacun dans une case en lecture seule que le script coche : pdf.js (Firefox) ne redessine pas un widget
    caché qu'un script montre. La réponse : ``<qid>_g<i>`` (texte caché) vaut le rang affiché ``j`` de la puce de
    droite reliée à la gauche ``i``. ``centres`` : (page, x, y) de chaque puce, en points."""
    xs = [x for _, x, _ in centres]
    milieu = (min(xs) + max(xs)) / 2
    gauches = [c for c in centres if c[1] < milieu]
    droites = [c for c in centres if c[1] >= milieu]
    n, m = len(gauches), len(droites)
    boite = lambda c, d=ZONE: [c[1] - d, c[2] - d, c[1] + d, c[2] + d]  # noqa: E731
    champs = []
    for i, a in enumerate(gauches):
        champs.append({"nom": f"{qid}_g{i}", "sorte": "cache", "widgets": [(a[0], boite(a, 1))]})
        for j, b in enumerate(droites):
            if b[0] == a[0]:  # un trait ne change pas de page
                r = [min(a[1], b[1]) - 1, min(a[2], b[2]) - 1, max(a[1], b[1]) + 1, max(a[2], b[2]) + 1]
                champs.append({"nom": f"{qid}_t{i}_{j}", "sorte": "dessin", "widgets": [(a[0], r)], "dessin": trait(a, b)})
        champs.append({"nom": f"{qid}_s{i}", "sorte": "dessin", "widgets": [(a[0], boite(a))], "dessin": anneau})
    champs.append({"nom": f"{qid}_actif", "sorte": "cache", "widgets": [(gauches[0][0], boite(gauches[0], 1))]})
    for i, a in enumerate(gauches):
        js = (f'this.getField("{qid}_actif").value = "{i}";'
              f'for (var k = 0; k < {n}; k++) this.getField("{qid}_s" + k).value = k == {i} ? "Oui" : "Off";')
        champs.append({"nom": f"{qid}_pg{i}", "sorte": "bouton", "widgets": [(a[0], boite(a))], "js": js})
    for j, b in enumerate(droites):
        js = (f'var i = this.getField("{qid}_actif").value;'
              f'if (i !== "") {{ this.getField("{qid}_g" + i).value = "{j}";'
              f'for (var k = 0; k < {m}; k++) {{ var t = this.getField("{qid}_t" + i + "_" + k);'
              f'if (t) t.value = k == {j} ? "Oui" : "Off"; }}'
              f'this.getField("{qid}_s" + i).value = "Off"; this.getField("{qid}_actif").value = ""; }}')
        champs.append({"nom": f"{qid}_pd{j}", "sorte": "bouton", "widgets": [(b[0], boite(b))], "js": js})
    return champs


def trait(a: tuple[int, float, float], b: tuple[int, float, float]):
    """Le dessin du trait de ``a`` à ``b`` dans la boîte (x0, y0, x1, y1) de son widget, repère du XObject (y vers le haut)."""
    def dessin(x0: float, y0: float, x1: float, y1: float) -> str:
        return f"q 0 0 0.6 RG 1.4 w 1 J {a[1] - x0:.2f} {y1 - a[2]:.2f} m {b[1] - x0:.2f} {y1 - b[2]:.2f} l S Q"
    return dessin


def anneau(x0: float, y0: float, x1: float, y1: float) -> str:
    """Le cercle qui entoure la puce de départ choisie, inscrit dans la boîte de son widget."""
    c = (x1 - x0) / 2
    r, k = c - 1, 0.5523 * (c - 1)
    return (f"q 0 0 0.6 RG 1 w {c + r:.2f} {c:.2f} m {c + r:.2f} {c + k:.2f} {c + k:.2f} {c + r:.2f} {c:.2f} {c + r:.2f} c "
            f"{c - k:.2f} {c + r:.2f} {c - r:.2f} {c + k:.2f} {c - r:.2f} {c:.2f} c "
            f"{c - r:.2f} {c - k:.2f} {c - k:.2f} {c - r:.2f} {c:.2f} {c - r:.2f} c "
            f"{c + k:.2f} {c - r:.2f} {c + r:.2f} {c - k:.2f} {c + r:.2f} {c:.2f} c S Q")


def sans_coin(cellules: list[dict]) -> list[dict]:
    """Les cases vides d'un tableau, sans le coin d'en-tête : seule vide de sa ligne et de sa colonne, avec d'autres
    cases vides en bas à droite (tableau à double entrée)."""
    def coin(c: dict) -> bool:
        x0, y0, x1, y1 = c["rect"]
        autres = [d["rect"] for d in cellules if d is not c and d["page"] == c["page"]]
        return (not any(abs(r[1] - y0) < 5 for r in autres) and not any(abs(r[0] - x0) < 5 for r in autres)
                and any(r[0] >= x1 - 5 and r[1] >= y1 - 5 for r in autres))
    return [c for c in cellules if not coin(c)]


def groupes_de_lignes(lignes: list[dict]) -> list[tuple[int, list[dict]]]:
    """Les lignes de réponse d'une question, par page et par suite de lignes au même pas (une question coupée par
    la page, ou deux zones d'écriture, font deux champs)."""
    groupes: list[tuple[int, list[dict]]] = []
    for l in lignes:
        if groupes and groupes[-1][0] == l["page"]:
            d = groupes[-1][1]
            pas = d[1]["rect"][1] - d[0]["rect"][1] if len(d) > 1 else None
            if pas is None or abs(l["rect"][1] - d[-1]["rect"][1] - pas) < 3:
                d.append(l)
                continue
        groupes.append((l["page"], [l]))
    return groupes


def interligne_kalam() -> float:
    """La hauteur d'une ligne de Kalam (ascendante, descendante, interligne de ``hhea``), en corps."""
    from fontTools.ttLib import TTFont  # noqa: PLC0415 - à l'écriture d'un formulaire : le lecteur web importe ce module sans fontTools
    f = TTFont(MAIN)
    return (f["hhea"].ascent - f["hhea"].descent + f["hhea"].lineGap) / f["head"].unitsPerEm


def police_kalam() -> tuple[dict, dict, bytes]:
    """La police Kalam incorporée en TrueType simple, codage WinAnsi : (police, descripteur sans FontFile2, fichier)."""
    from fontTools.ttLib import TTFont  # noqa: PLC0415 - voir interligne_kalam
    donnees = MAIN.read_bytes()
    f = TTFont(MAIN)
    echelle = 1000 / f["head"].unitsPerEm
    carte, chasses = f.getBestCmap(), f["hmtx"]
    largeurs = []
    for code in range(32, 256):
        try:
            car = bytes([code]).decode("cp1252")
        except UnicodeDecodeError:
            car = " "
        glyphe = carte.get(ord(car))
        largeurs.append(round(chasses[glyphe][0] * echelle) if glyphe else 0)
    tete, hhea = f["head"], f["hhea"]
    descripteur = {"/Type": "/FontDescriptor", "/FontName": "/Kalam", "/Flags": 32,
                   "/FontBBox": [round(v * echelle) for v in (tete.xMin, tete.yMin, tete.xMax, tete.yMax)],
                   "/ItalicAngle": 0, "/Ascent": round(hhea.ascent * echelle), "/Descent": round(hhea.descent * echelle),
                   "/CapHeight": round(getattr(f["OS/2"], "sCapHeight", 700) * echelle), "/StemV": 80}
    police = {"/Type": "/Font", "/Subtype": "/TrueType", "/BaseFont": "/Kalam", "/FirstChar": 32, "/LastChar": 255,
              "/Widths": largeurs, "/Encoding": "/WinAnsiEncoding"}
    return police, descripteur, donnees


def ajouter_formulaire(pdf: Path, sortie: Path | None = None, identite: bool = True) -> int:
    """Pose les champs de ``champs_du_sujet`` sur ``pdf`` (réécrit sur place sans ``sortie``) ; rend leur nombre.
    ``identite`` False : Nom, Prénom et Classe sont déjà imprimés (copie nominative), pas de champ dessus."""
    sortie = sortie or pdf
    champs = champs_du_sujet(lire_positions(pdf), identite)
    if not champs:
        return 0
    brut = json.loads(qpdf("--json-output=2", "--json-stream-data=none", str(pdf)))
    objets = brut["qpdf"][1]
    racine = brut["qpdf"][1]["trailer"]["value"]["/Root"]
    pages = [p["object"] for p in json.loads(qpdf("--json", "--json-key=pages", str(pdf)))["pages"]]
    hauteurs = {}
    for i, ref in enumerate(pages, 1):
        boite = objets[f"obj:{ref}"]["value"]["/MediaBox"]
        hauteurs[i] = boite[3]
    suivant = [max(int(cle.split(":")[1].split()[0]) for cle in objets if cle.startswith("obj:")) + 1]
    neufs: dict[str, Any] = {}

    def neuf(valeur: dict, flux: bytes | None = None) -> str:
        ref = f"{suivant[0]} 0 R"
        suivant[0] += 1
        neufs[f"obj:{ref}"] = ({"value": valeur} if flux is None else
                               {"stream": {"dict": valeur, "data": base64.b64encode(flux).decode()}})
        return ref

    def apparence(l: float, h: float, contenu: str, ressources: dict | None = None) -> str:
        return neuf({"/Type": "/XObject", "/Subtype": "/Form", "/BBox": [0, 0, l, h]} | ({"/Resources": ressources} if ressources else {}),
                    contenu.encode())

    police, descripteur, donnees = police_kalam()
    descripteur["/FontFile2"] = neuf({"/Length1": len(donnees)}, donnees)
    police["/FontDescriptor"] = neuf(descripteur)
    kalam = neuf(police)
    zadb = neuf({"/Type": "/Font", "/Subtype": "/Type1", "/BaseFont": "/ZapfDingbats"})
    annots: dict[int, list[str]] = {}
    racines = []
    for champ in champs:
        parent = f"{suivant[0]} 0 R"
        suivant[0] += 1
        enfants = []
        for k, (page, (x0, y0, x1, y1)) in enumerate(champ["widgets"]):
            h = hauteurs[page]
            l, haut = x1 - x0, y1 - y0
            widget: dict[str, Any] = {"/Type": "/Annot", "/Subtype": "/Widget", "/Parent": parent, "/F": 4,
                                      "/P": pages[page - 1], "/Rect": [round(x0, 2), round(h - y1, 2), round(x1, 2), round(h - y0, 2)]}
            if champ["sorte"] == "bouton":  # une puce d'appariement : invisible, son clic lance le script du champ.
                # Les deux déclencheurs : pdf.js (Firefox) ne lance que /A, Chrome (PDFium) a été vérifié par /AA /U ;
                # le script est idempotent (le second passage d'un clic à droite trouve le départ déjà effacé).
                script = {"/S": "/JavaScript", "/JS": "u:" + champ["js"]}
                widget |= {"/MK": {}, "/AP": {"/N": apparence(l, haut, "")}, "/H": "/N", "/A": script, "/AA": {"/U": script}}
            elif champ["sorte"] == "dessin":  # un trait ou un anneau tout prêt : case en lecture seule, que le script coche
                widget |= {"/MK": {}, "/AS": "/Off", "/AP": {"/N": {"/Oui": apparence(l, haut, champ["dessin"](x0, y0, x1, y1)),
                                                                   "/Off": apparence(l, haut, "")}}}
            elif champ["sorte"] == "cache":  # la réponse d'un appariement, que les scripts écrivent et que la correction lit
                widget |= {"/F": 6, "/MK": {}}
            elif champ["sorte"] == "texte":
                widget["/MK"] = {}  # sans fond ni bord : les traits, cases et cadres imprimés restent visibles
                widget["/AP"] = {"/N": apparence(l, haut, "/Tx BMC EMC",
                                                     {"/Font": {"/Kalam": kalam}})}  # qpdf --generate-appearances reprend ces ressources
            else:
                cote = min(l, haut)
                if champ["sorte"] == "case":
                    marque = f"q 0 0 0.6 RG 1.6 w 1 J {cote * .2:.2f} {cote * .2:.2f} m {cote * .8:.2f} {cote * .8:.2f} l S " \
                             f"{cote * .2:.2f} {cote * .8:.2f} m {cote * .8:.2f} {cote * .2:.2f} l S Q"
                    etat = "/Oui"
                else:  # un disque plein dans le rond imprimé
                    r, c = cote * 0.3, cote / 2
                    m = 0.5523 * r
                    marque = (f"0 0 0.6 rg {c + r:.2f} {c:.2f} m {c + r:.2f} {c + m:.2f} {c + m:.2f} {c + r:.2f} {c:.2f} {c + r:.2f} c "
                              f"{c - m:.2f} {c + r:.2f} {c - r:.2f} {c + m:.2f} {c - r:.2f} {c:.2f} c "
                              f"{c - r:.2f} {c - m:.2f} {c - m:.2f} {c - r:.2f} {c:.2f} {c - r:.2f} c "
                              f"{c + m:.2f} {c - r:.2f} {c + r:.2f} {c - m:.2f} {c + r:.2f} {c:.2f} c f")
                    etat = "/" + champ["valeurs"][k]
                widget["/AS"] = "/Off"
                if champ["sorte"] == "radio":  # chaque rond, champ enfant au nom vide : Okular (poppler-qt) ne groupe que
                    widget["/T"] = "u:"           # des champs frères, Firefox (pdf.js) que des ronds de même nom complet
                widget["/MK"] = {"/CA": "u:8" if champ["sorte"] == "case" else "u:l"}
                widget["/AP"] = {"/N": {etat: apparence(l, haut, marque), "/Off": apparence(l, haut, "")}}
            ref = neuf(widget)
            enfants.append(ref)
            annots.setdefault(page, []).append(ref)
        valeur: dict[str, Any] = {"/T": "u:" + champ["nom"], "/Kids": enfants}
        if champ["sorte"] == "bouton":
            valeur |= {"/FT": "/Btn", "/Ff": 65536}  # bouton poussoir
        elif champ["sorte"] == "dessin":
            valeur |= {"/FT": "/Btn", "/Ff": 1, "/V": "/Off"}  # case en lecture seule : l'élève ne la coche pas lui-même
        elif champ["sorte"] == "cache":
            valeur |= {"/FT": "/Tx", "/V": "u:", "/DA": "u:/Kalam 8 Tf 0 g"}
        elif champ["sorte"] == "texte":
            valeur |= {"/FT": "/Tx", "/V": "u:", "/DA": f"u:/Kalam {champ['taille']} Tf 0 0 0.6 rg",
                       "/Ff": 4096 if champ["multiligne"] else 0, "/Q": 1 if champ.get("centre") else 0}
        else:
            valeur |= {"/FT": "/Btn", "/V": "/Off", "/DA": "u:/ZaDb 0 Tf 0 0 0.6 rg"}
            if champ["sorte"] == "radio":
                valeur["/Ff"] = 49152  # radio, sans tout décocher par un second clic
        neufs[f"obj:{parent}"] = {"value": valeur}
        racines.append(parent)
    for page, refs in annots.items():
        valeur = dict(objets[f"obj:{pages[page - 1]}"]["value"])
        avant = valeur.get("/Annots", [])
        if isinstance(avant, str):  # « 45 0 R » : le tableau des liens que Qt a posés, en objet à part
            avant = objets[f"obj:{avant}"]["value"]
        valeur["/Annots"] = list(avant) + refs
        neufs[f"obj:{pages[page - 1]}"] = {"value": valeur}
    catalogue = dict(objets[f"obj:{racine}"]["value"])
    catalogue["/AcroForm"] = {"/Fields": racines, "/NeedAppearances": False,  # nos apparences : sinon Okular redessine les ronds (glyphe ZapfDingbats décentré)
                              "/DA": f"u:/Kalam {TAILLE_MAX} Tf 0 g",
                              "/DR": {"/Font": {"/Kalam": kalam, "/ZaDb": zadb}}}
    neufs[f"obj:{racine}"] = {"value": catalogue}
    octets = pdf.read_bytes()
    sortie.write_bytes(octets + mise_a_jour(octets, neufs, objets["trailer"]["value"], suivant[0]))
    return len(champs)


def mise_a_jour(octets: bytes, neufs: dict[str, Any], remorque: dict[str, Any], taille: int) -> bytes:
    """Les objets ``neufs`` (forme JSON de qpdf) en mise à jour incrémentale : les octets du PDF restent tels quels,
    pièces jointes comprises, que ``sujet.piece_jointe`` relit à la main dans la mise en forme de Qt."""
    morceaux, places = [b"\n"], {}
    for cle, objet in sorted(neufs.items(), key=lambda e: int(e[0].split(":")[1].split()[0])):
        numero = int(cle.split(":")[1].split()[0])
        places[numero] = len(octets) + sum(map(len, morceaux))
        if "stream" in objet:
            donnees = base64.b64decode(objet["stream"]["data"])
            corps = en_pdf(objet["stream"]["dict"] | {"/Length": len(donnees)}).encode() + b"\nstream\n" + donnees + b"\nendstream"
        else:
            corps = en_pdf(objet["value"]).encode()
        morceaux.append(b"%d 0 obj\n" % numero + corps + b"\nendobj\n")
    xref = len(octets) + sum(map(len, morceaux))
    table = b"xref\n" + b"".join(b"%d 1\n%010d 00000 n \n" % (n, places[n]) for n in sorted(places))
    remorque = {k: v for k, v in remorque.items() if k in ("/Root", "/Info", "/ID")} | {"/Size": taille,
                "/Prev": int(re.findall(rb"startxref\s+(\d+)", octets)[-1])}
    return b"".join(morceaux) + table + b"trailer\n" + en_pdf(remorque).encode() + b"\nstartxref\n%d\n%%%%EOF\n" % xref


def en_pdf(v: Any) -> str:
    """Une valeur de la forme JSON de qpdf (``--json-output=2``) en syntaxe PDF."""
    if isinstance(v, bool):
        return "true" if v else "false"
    if v is None:
        return "null"
    if isinstance(v, (int, float)):
        return f"{v:.4f}".rstrip("0").rstrip(".") if isinstance(v, float) else str(v)
    if isinstance(v, list):
        return "[" + " ".join(map(en_pdf, v)) + "]"
    if isinstance(v, dict):
        return "<<" + " ".join(f"{k} {en_pdf(w)}" for k, w in v.items()) + ">>"
    if v.startswith("/") or re.fullmatch(r"\d+ \d+ R", v):
        return v
    if v.startswith("u:"):
        return "<FEFF" + v[2:].encode("utf-16-be").hex().upper() + ">" if not v[2:].isascii() else \
            "(" + v[2:].replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)") + ")"
    if v.startswith("b:"):
        return "<" + v[2:] + ">"
    raise ValueError(f"valeur qpdf inconnue : {v!r}")


if __name__ == "__main__":
    print(ajouter_formulaire(Path(sys.argv[1]), Path(sys.argv[2]) if len(sys.argv) > 2 else None), "champs")
