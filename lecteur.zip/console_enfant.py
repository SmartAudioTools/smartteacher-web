"""Côté enfant de la console du lecteur : un interpréteur qui reste vivant entre deux commandes du parent.

Lancé par ``console_code.py`` (``python -u console_enfant.py``). Le parent écrit une commande JSON par ligne sur
stdin, l'enfant répond sur stdout : la sortie du programme telle quelle, et des lignes de contrôle
(``\\x1e{json}``) qui disent où il en est.

    {"dossier", "classe", "autorises"}    première ligne : où travailler, ce que le programme peut employer
    {"langage", "base"}                   sur la même ligne : « sql » ouvre l'invite « sql> » sur ce jeu de données,
                                          « assembleur » l'invite « asm> » (``main_assembleur``)
    {"prelude"}                           sur la même ligne : le code caché de la question, rejoué avant chaque programme
    {"premiere_ligne"}                    sur la même ligne : le numéro de la première ligne de l'éditeur (défaut 1)
    {"fichiers"}                          sur la même ligne : les fichiers du sujet, {nom: contenu}, posés dans le dossier (un .py s'importe)
    {"executer": source}                  le programme de l'éditeur, dans un espace de noms neuf
    {"ligne": texte}                      une ligne de l'invite « >>> », dans l'espace du dernier programme
    {"saisie": texte}                     la réponse à un ``input()`` en attente

    {"fin": true, "suite": bool}          la commande est finie ; ``suite`` : l'invite attend la suite du bloc
    {"attend": true}                      un ``input()`` attend une ``saisie``

Le programme de l'élève est borné comme dans verifier.py (bac_a_sable.py) ; en SQL, par l'autoriseur de
``verifier.base_sql``, le crochet d'audit de Python ne voyant pas sqlite3. Pas de délai de garde ici : c'est le
bouton Arrêter du parent, qui tue le processus. Bibliothèque standard seule, comme verifier.py.
"""

import code
import io
import json
import linecache
import os
import re
import sys
import traceback
from pathlib import Path

import bac_a_sable
from verifier import (ICI, REGISTRES, ErreurAssembleur, ErreurPrelude, SystemeSimule, _decrire, _FauxPyxel, assembler, base_sql,
                      decouper_sql, deposer, derouler, ecrire_registres, jeu_sql, lire_registres, preluder)

FICHIER = "<editeur>"
INVITE = "<console>"


def pile(exc, premiere=1):
    """L'erreur comme Python l'imprime, « Traceback (most recent call last): » et chaque appel, réduite aux trames de
    l'élève (éditeur et invite) : ni le lecteur ni le bac à sable n'y paraissent. Un refus de l'analyse, levé avant
    toute ligne de l'élève, reste la phrase d'une ligne du lecteur, comme le nom qualifié d'une erreur du bac à sable."""
    trames = [(f, n) for f, n in traceback.walk_tb(exc.__traceback__) if f.f_code.co_filename in (FICHIER, INVITE)]
    if not trames:
        return _decrire(exc)
    fin = ("".join(traceback.format_exception_only(exc)).rstrip() if type(exc).__module__ == "builtins"
           else _decrire(exc))
    appels = "".join(traceback.StackSummary.extract(trames).format())
    if premiere != 1:  # numérotées comme l'éditeur (``Code.premiere_ligne``) ; format() a déjà lu leur texte
        appels = re.sub(rf'(File "{FICHIER}", line )(\d+)', lambda m: m[1] + str(int(m[2]) + premiere - 1), appels)
    return "Traceback (most recent call last):\n" + appels + fin


def controle(**infos):
    sys.stdout.write("\x1e" + json.dumps(infos) + "\n")
    sys.stdout.flush()


class Invite(code.InteractiveConsole):
    """``>>>`` : comme InteractiveConsole, mais chaque ligne passe par ``analyser`` et les erreurs sont celles du lecteur."""

    def __init__(self, espace, permis):
        super().__init__(espace, INVITE)
        self.permis, self.connus = permis, set()  # ``connus`` : les noms du prélude, que l'analyse tient pour définis

    def runsource(self, source, filename=INVITE, symbol="single"):
        try:
            objet = self.compile(source, filename, symbol)
        except (OverflowError, SyntaxError, ValueError):
            self.showsyntaxerror(filename)
            return False
        if objet is None:
            return True  # le bloc n'est pas fini
        try:
            bac_a_sable.analyser(source, self.permis, filename, self.connus)
            exec(objet, self.locals)  # noqa: S102 - c'est le principe : exécuter le programme de l'élève
        except BaseException:  # noqa: BLE001 - toute erreur de l'élève, SystemExit compris
            self.showtraceback()
        return False

    def showsyntaxerror(self, filename=None, **_):
        exc = sys.exc_info()[1]
        print(f"erreur de syntaxe ({exc.msg})")

    def showtraceback(self):
        print(pile(sys.exc_info()[1]))


def espace_neuf(permis, commandes):
    """Un espace de noms d'élève ; son ``input()`` lit la réponse dans le flux des commandes, pas au clavier."""
    def saisie(invite=""):
        sys.stdout.write(str(invite))
        controle(attend=True)
        reponse = lire(commandes)
        if reponse is None:
            raise EOFError
        return reponse["saisie"]
    espace = bac_a_sable.espace(permis, __name__="__eleve__", __file__=FICHIER)
    espace["__builtins__"]["input"] = saisie
    return espace


def lire(commandes):
    ligne = commandes.readline()
    return json.loads(ligne) if ligne else None  # rien : le parent est parti


def executer(source, permis, commandes, prelude="", premiere=1):
    """Le programme de l'éditeur dans un espace neuf, après le prélude de la question ; rend l'espace et les noms du
    prélude."""
    espace, connus = espace_neuf(permis, commandes), set()
    linecache.cache[FICHIER] = len(source), None, source.splitlines(keepends=True), FICHIER  # la pile cite ses lignes
    try:
        objet = compile(source, FICHIER, "exec")
        connus = preluder(prelude, espace)
        bac_a_sable.analyser(source, permis, FICHIER, connus, premiere)
        exec(objet, espace)  # noqa: S102
    except SyntaxError as exc:
        print(f"ligne {exc.lineno + premiere - 1} : erreur de syntaxe ({exc.msg})")
    except ErreurPrelude as exc:
        print(exc)
    except BaseException as exc:  # noqa: BLE001
        print(pile(exc, premiere))
    return espace, connus


LIGNES_MAX = 200  # un produit cartésien ne doit pas remplir la console avant que l'élève n'ait le temps d'arrêter


def _tableau(entetes, lignes, tronque):
    """Le résultat en tableau texte : c'est la seule forme lisible dans la sortie du lecteur."""
    grille = [[str(e) for e in entetes]] + [["NULL" if v is None else str(v) for v in ligne] for ligne in lignes]
    larges = [max(len(g[c]) for g in grille) for c in range(len(entetes))]

    def aligner(g):
        return " | ".join(v.ljust(l) for v, l in zip(g, larges))

    corps = [aligner(grille[0]), "-+-".join("-" * l for l in larges)] + [aligner(g) for g in grille[1:]]
    return "\n".join(corps) + ("\n… (seules les premières lignes sont affichées)" if tronque else
                               f"\n({len(lignes)} ligne{'s' if len(lignes) > 1 else ''})")


def jouer(connexion, texte):
    """Exécute les requêtes de ``texte`` et imprime ce qu'elles rendent, une erreur SQL comprise."""
    import sqlite3  # noqa: PLC0415 - un worker sur Pyodide-Qt (stdlib sans sqlite3) doit pouvoir lancer une console python
    for requete in decouper_sql(texte):
        try:
            curseur = connexion.execute(requete)
            lignes = curseur.fetchmany(LIGNES_MAX + 1)
        except sqlite3.Error as exc:
            print(_decrire(exc))
            continue
        if curseur.description:
            print(_tableau([c[0] for c in curseur.description], lignes[:LIGNES_MAX], len(lignes) > LIGNES_MAX))
        else:
            print(f"{curseur.rowcount} ligne(s) modifiée(s)" if curseur.rowcount >= 0 else "fait")


def main_sql(reglages, commandes):
    """L'invite ``sql>``. La base est REJOUÉE à chaque « Exécuter », comme à la correction : l'élève peut essayer un
    UPDATE sans que l'essai suivant en hérite. Pas de bac_a_sable ici : le bornage est l'autoriseur de ``base_sql``."""
    connexion = None
    while (ordre := lire(commandes)) is not None:
        if "executer" in ordre:
            if connexion is not None:
                connexion.close()
            connexion = None
        elif "ligne" not in ordre:
            continue  # une saisie que plus rien n'attend : il n'y a pas d'input() en SQL
        if connexion is None:
            try:
                connexion = base_sql(jeu_sql(reglages.get("base", ""), reglages.get("prelude", "")))
            except Exception as exc:  # noqa: BLE001 - le jeu de données du sujet est fautif, le dire sans tomber
                print(f"le jeu de données de la question est refusé par SQLite : {_decrire(exc)}")
                controle(fin=True, suite=False)
                continue
        jouer(connexion, ordre.get("executer") or ordre.get("ligne", ""))
        controle(fin=True, suite=False)


def main_assembleur(commandes):
    """L'invite ``asm>``. Une ligne de valeurs (« r1 = 5, r2 = 7 ») fixe le DÉPART, d'où « Exécuter » relance le programme
    de l'éditeur, comme un test de la correction ; une ligne d'instructions s'exécute sur les registres du moment. Le
    programme est interprété (``verifier.derouler``), jamais exécuté par Python : pas de bac à sable à poser."""
    depart, registres = {}, {}
    while (ordre := lire(commandes)) is not None:
        texte = ordre.get("executer", ordre.get("ligne"))
        if texte is None:
            continue  # une saisie que plus rien n'attend
        try:
            if "ligne" in ordre and re.match(r"\s*[rR]\d+\s*=", texte):
                depart = lire_registres(texte)
                registres = {}
                print(f"départ : {ecrire_registres(depart)}")
            elif texte.strip():
                if "executer" in ordre:
                    registres = {}
                derouler(assembler(texte), registres := {n: registres.get(n, depart.get(n, 0)) for n in range(1, REGISTRES + 1)})
                print(ecrire_registres(registres))
        except (ErreurAssembleur, ValueError) as exc:
            print(exc if "executer" in ordre else
                  f"{exc}\n(écris une instruction, « addi r1, r1, 1 », ou des valeurs de départ, « r1 = 5, r2 = 7 »)")
        controle(fin=True, suite=False)


def main():
    sys.stdout.reconfigure(encoding="utf-8", write_through=True)
    commandes = io.TextIOWrapper(sys.stdin.buffer, encoding="utf-8")
    sys.stdin = io.StringIO()
    reglages = lire(commandes)
    if reglages.get("langage") == "sql":
        return main_sql(reglages, commandes)
    if reglages.get("langage") == "assembleur":
        return main_assembleur(commandes)
    dossier = str(Path(reglages["dossier"]).resolve())
    os.chdir(dossier)
    sys.path.insert(0, dossier)
    sys.meta_path.insert(0, _FauxPyxel())
    permis = bac_a_sable.programme(reglages["classe"], reglages["autorises"])
    try:
        permis = deposer(dossier, reglages.get("fichiers"), permis)
    except ErreurPrelude as exc:  # une base SQLite que ce lecteur ne sait pas ouvrir : le dire, la console reste utile
        print(exc)
    systeme = reglages.get("arborescence") and SystemeSimule(reglages["arborescence"])
    if systeme:
        permis = systeme.permettre(permis)
    bac_a_sable.poser(dossier, (str(ICI / "pyxel_factice.py"),))
    invite = Invite(espace_neuf(permis, commandes), permis)
    try:  # l'invite seule, sans programme exécuté, connaît déjà les noms fournis par la question
        invite.connus = preluder(reglages.get("prelude", ""), invite.locals)
    except ErreurPrelude as exc:
        print(exc)
    while (ordre := lire(commandes)) is not None:
        avant = systeme and systeme.lignes()
        if "executer" in ordre:
            if systeme:  # comme un test : le programme part de l'arbre du sujet
                systeme.raz()
                avant = None
            (invite.locals, invite.connus), suite = executer(ordre["executer"], permis, commandes, reglages.get("prelude", ""),
                                                                 reglages.get("premiere_ligne", 1)), False
            invite.resetbuffer()
        elif "ligne" in ordre:
            suite = invite.push(ordre["ligne"])
        else:
            continue  # une saisie que plus rien n'attend
        if systeme and systeme.lignes() != avant:  # l'effet de « os.mkdir », invisible sinon
            print(systeme.dessin())
        controle(fin=True, suite=suite)


if __name__ == "__main__":
    main()
