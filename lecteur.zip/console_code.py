"""La console d'une question de code : les boutons, l'éditeur, puis la sortie du programme et l'invite « >>> ».

Le widget porte les trois parties dans cet ordre, tout contre : un seul bloc à l'écran, de même largeur et de
même police, où l'on lit son programme au-dessus de ce qu'il a imprimé. Un intitulé gris nomme chaque zone, et
les numéros de ligne de l'éditeur (editeur_code.py) achèvent de les distinguer.

Le programme ne tourne jamais dans le lecteur : il tourne dans ``console_enfant.py``, un processus qui reste
vivant entre deux commandes (les variables du dernier programme restent visibles à l'invite) et qui est borné
par bac_a_sable.py comme à la correction. Arrêter tue ce processus : le suivant repart d'un espace vide.

Une copie rouverte retrouve la console comme l'élève l'a laissée (``etat`` / ``reprendre``) : la trace s'affiche telle
quelle, sans rien exécuter, et les commandes jouées depuis le dernier ▶ sont rejouées EN MUET au premier Entrée, dans
un slot Qt (le seul endroit où le navigateur peut attendre son Web Worker). La graine de ``random``, rangée avec
elles, rend au rejeu les tirages que la trace montre. Les variables elles-mêmes ne se sérialisent pas : fonctions,
classes et modules de l'élève ne passent pas serializejson (mesuré, DONE du 05/10/2026).
"""

import codecs
import json
import math
import random
import re
import sys
import tempfile
from pathlib import Path

from qtpy6.QtCore import QEvent, QPoint, Qt, QTimer
from qtpy6.QtCore import QProcess  # dans le navigateur, qtpy6 en fait un Web Worker sous la même surface
from qtpy6.QtGui import QColor, QFontDatabase, QKeySequence, QPainter, QPainterPath, QPalette, QShortcut, QTextCharFormat, QTextCursor
from qtpy6.QtWidgets import QAbstractScrollArea, QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QScrollArea, QStyle, QStyleOptionButton, QToolTip, QVBoxLayout, QWidget

from qtpy6.web.dispositions import Rangee

ENFANT = Path(__file__).resolve().parent / "console_enfant.py"
VOLUME = 1_000_000  # caractères de sortie avant arrêt d'office : `while True: print(1)` ne doit pas figer le lecteur
LIGNES_MIN, LIGNES_MAX = 3, 12  # la hauteur de la console : l'invite et un peu d'air, puis l'ascenseur
INVITE = "#ff08c1"  # le fuchsia des cours (thème Darcula collé dans « Python - Travaux Pratiques.docx »)
TRACE_MAX = 20_000  # caractères de trace gardés dans la copie, ~300 lignes : la fin d'une longue session suffit
AMORCES = re.compile(r"(>>>|\.\.\.|sql>|asm>) ")  # les invites possibles ; seules celles peintes en fuchsia en sont
REJEU_LENT = 1000  # ms : au-delà, la reprise d'une copie rouverte se signale (elle rejoue tout ce que l'élève avait tapé)
INTITULE = "#909090"  # « Éditeur » et « Interpréteur » : assez lisibles pour lever le doute, assez discrets pour s'oublier


def prechauffer(question) -> None:
    """Dans le navigateur, le processus est un Web Worker Pyodide qui met plusieurs secondes à naître (loadPyodide) :
    en monter un en réserve dès qu'une console paraît — et dès que le sien meurt ou est consommé — ramène le premier ▶
    et la relance après Arrêter vers le prix d'une commande ordinaire. Sans objet sur le bureau, où QProcess part en 0,2 s.
    Une console SQL, ou python avec sqlite3 au programme (Terminale) : la réserve installe aussi la roue de sqlite3
    (0,6 Mo), que ``bac_a_sable.poser`` importe sinon au premier ▶."""
    if sys.platform == "emscripten":
        from qtpy6.web import travailleur  # noqa: PLC0415

        import bac_a_sable  # noqa: PLC0415
        langage = getattr(question, "langage", "python")
        sqlite3 = langage == "sql" or (langage == "python" and "sqlite3" in bac_a_sable.programme(
            question.classe, question.autorises)["modules"])
        travailleur.prechauffer(("sqlite3",) if sqlite3 else ())


# des noms seuls, partout (l'utilisateur, 03/11/2026 : « revenir au simple "Interpréteur interactif" », « au simple "Éditeur" »)
INTITULE_CONSOLE, INTITULE_EDITEUR = "Interpréteur interactif", "Éditeur"


def intitule(texte):
    """Le nom d'une zone, en petit et en gris au-dessus d'elle : c'est ce qui dit où finit le programme."""
    etiquette = QLabel(texte)
    police = etiquette.font()
    police.setPointSizeF(police.pointSizeF() * 0.85)
    etiquette.setFont(police)
    etiquette.setStyleSheet(f"color: {INTITULE};")
    etiquette.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom)
    return etiquette


class Sortie(QPlainTextEdit):
    """La sortie du programme ET l'invite dans un seul widget : l'élève tape à la suite de ce qui s'écrit.

    ``gel`` est la position où commence ce qu'il a le droit de modifier ; tout ce qui précède est la trace de
    la session, qu'un Retour arrière ne doit pas pouvoir ronger."""

    def __init__(self, valider):
        super().__init__()
        self.valider, self.gel = valider, 0
        self.historique, self.rang, self.brouillon = [], 0, ""  # les lignes validées, et celle qu'on tapait avant d'y remonter
        self.setFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont))
        self.setUndoRedoEnabled(False)  # une console ne se défait pas : Ctrl+Z ressusciterait la trace
        self.setMaximumBlockCount(2000)
        self.document().documentLayout().documentSizeChanged.connect(self._hauteur)
        self._hauteur()

    def _hauteur(self, *_):
        """À la hauteur de ce qu'elle contient, entre ``LIGNES_MIN`` et ``LIGNES_MAX`` lignes, l'ascenseur au-delà :
        une console vide ne prend pas la place d'une sortie qu'elle n'aura peut-être jamais. Sur du texte brut, la
        hauteur du document EST son nombre de lignes, repliées comprises (QPlainTextDocumentLayout)."""
        lignes = min(max(math.ceil(self.document().documentLayout().documentSize().height()), LIGNES_MIN), LIGNES_MAX)
        self.setFixedHeight(lignes * self.fontMetrics().lineSpacing()
                            + math.ceil(2 * self.document().documentMargin()) + 2 * self.frameWidth()
                            + 1)  # sans ce pixel, QPlainTextEdit compte une ligne de trop et montre l'ascenseur (mesuré)

    def changeEvent(self, evenement):
        if evenement.type() == QEvent.Type.FontChange:  # la feuille de style du sujet agrandit la police après coup
            self._hauteur()
        super().changeEvent(evenement)

    def vider(self):
        """Une nouvelle exécution : la trace s'en va, et avec elle la frontière de ce qui s'y modifie."""
        self.clear()
        self.gel = 0

    def restaurer(self, texte, invites):
        """La trace d'une copie rouverte, ses invites (positions relevées par ``invites``) en fuchsia ; l'élève tape
        à la suite."""
        self.vider()
        debut = 0
        for position in invites:
            m = AMORCES.match(texte, position)
            self.ecrire(texte[debut:position])
            self.amorcer(m[1])
            debut = m.end()
        self.ecrire(texte[debut:])

    def invites(self, fin):
        """Les positions des invites avant ``fin`` : celles qui sont en fuchsia, pas une sortie du programme qui
        imprimerait « >>> », et où qu'elles soient sur la ligne (une sortie sans retour à la ligne final les précède)."""
        curseur, positions = self.textCursor(), []
        for m in AMORCES.finditer(self.toPlainText()[:fin]):
            curseur.setPosition(m.start() + 1)  # le format d'une position est celui du caractère qui la précède
            if curseur.charFormat().foreground().color() == QColor(INVITE):
                positions.append(m.start())
        return positions

    def ecrire(self, texte):
        """Ce qu'imprime le programme : à la fin, dans la couleur du texte, et l'invite d'édition le suit."""
        curseur = self.textCursor()
        curseur.movePosition(QTextCursor.MoveOperation.End)
        curseur.insertText(texte, QTextCharFormat())
        self.gel = curseur.position()
        self.setTextCursor(curseur)
        self.ensureCursorVisible()

    def amorcer(self, amorce):
        """« >>> » en fuchsia, puis le curseur : ce qui suit est à l'élève, et s'écrit dans la couleur du texte."""
        curseur = self.textCursor()
        curseur.movePosition(QTextCursor.MoveOperation.End)
        marque = QTextCharFormat()
        marque.setForeground(QColor(INVITE))
        curseur.insertText(amorce, marque)
        curseur.insertText(" ", QTextCharFormat())  # l'espace en couleur du texte : un clic juste après l'invite, qui
        self.gel = curseur.position()                 # reprend le format du caractère précédent, ne tape plus en fuchsia
        self.setTextCursor(curseur)
        self.ensureCursorVisible()

    def saisie(self):
        curseur = self.textCursor()
        curseur.setPosition(self.gel)
        curseur.movePosition(QTextCursor.MoveOperation.End, QTextCursor.MoveMode.KeepAnchor)
        return curseur.selectedText().replace(" ", "\n")

    def remplacer(self, texte):
        curseur = self.textCursor()
        curseur.setPosition(self.gel)
        curseur.movePosition(QTextCursor.MoveOperation.End, QTextCursor.MoveMode.KeepAnchor)
        curseur.insertText(texte, QTextCharFormat())
        self.setTextCursor(curseur)

    def remonter(self, pas):
        """↑ / ↓ : les lignes déjà validées, comme dans l'interpréteur de Python ; redescendre au bout rend la ligne en cours."""
        rang = min(max(self.rang + pas, 0), len(self.historique))
        if rang == self.rang:
            return
        if self.rang == len(self.historique):
            self.brouillon = self.saisie()
        self.rang = rang
        self.remplacer(self.historique[rang] if rang < len(self.historique) else self.brouillon)

    def keyPressEvent(self, evenement):
        touche = evenement.key()
        if touche in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            texte = self.saisie()
            if texte.strip() and texte != (self.historique or [None])[-1]:
                self.historique.append(texte)
            self.rang = len(self.historique)
            self.valider(texte)
            return
        if touche in (Qt.Key.Key_Up, Qt.Key.Key_Down) and not self.isReadOnly():
            self.remonter(-1 if touche == Qt.Key.Key_Up else 1)
            return
        if touche == Qt.Key.Key_Home:  # le début de la ligne, c'est après l'invite, pas avant
            curseur = self.textCursor()
            curseur.setPosition(self.gel, QTextCursor.MoveMode.KeepAnchor
                                if evenement.modifiers() & Qt.KeyboardModifier.ShiftModifier
                                else QTextCursor.MoveMode.MoveAnchor)
            self.setTextCursor(curseur)
            return
        efface = touche in (Qt.Key.Key_Backspace, Qt.Key.Key_Delete)
        if efface or evenement.text() and not evenement.matches(QKeySequence.StandardKey.Copy):
            curseur = self.textCursor()
            if min(curseur.position(), curseur.anchor()) < self.gel:
                self.moveCursor(QTextCursor.MoveOperation.End)  # on ne tape jamais dans la trace déjà écrite
            if (touche == Qt.Key.Key_Backspace and not self.textCursor().hasSelection()
                    and self.textCursor().position() <= self.gel):
                return
        super().keyPressEvent(evenement)


class BoutonSymbole(QPushButton):
    """Un bouton plat à un seul symbole (▶ Σ ■ ↶ ↷), centré sur son TRACÉ et non sur la boîte de sa police : centrés
    par Qt, ▶ et ■ tombaient plus bas que Σ et les flèches (l'utilisateur, 06/11/2026 : « les 5 boutons sont mal
    alignés »). Le fond (survol, appui) reste celui du style ; ``text()`` reste le symbole. Percé dans le ``voile`` d'une
    question soumise (``modele.Question._poser_voile``), il en peint la couleur sous lui : le fond reste celui du voile."""
    voile = None  # le ``modele.Voile`` qui le perce, posé par la question

    def paintEvent(self, evenement) -> None:
        peintre = QPainter(self)
        option = QStyleOptionButton()
        self.initStyleOption(option)
        option.text = ""
        if self.voile is not None and not self.voile.isHidden():
            peintre.fillRect(self.rect(), self.voile.couleur)
        self.style().drawControl(QStyle.ControlElement.CE_PushButton, option, peintre, self)
        trace = QPainterPath()  # le tracé, police de repli comprise (↶ ↷) : ``tightBoundingRect`` ne mesure que la première
        trace.addText(0, 0, self.font(), self.text())
        encre = trace.boundingRect()
        groupe = QPalette.ColorGroup.Active if self.isEnabled() else QPalette.ColorGroup.Disabled
        peintre.setPen(self.palette().color(groupe, QPalette.ColorRole.ButtonText))
        peintre.drawText(round((self.width() - encre.width()) / 2 - encre.left()),
                         round((self.height() - encre.height()) / 2 - encre.top()), self.text())


class BarreQuiSuit(QWidget):
    """Les boutons ▶ Σ ■ ↶ ↷ de ``console``, répétés en haut de la zone qui défile tant que leur rangée est passée
    au-dessus du bord et que l'éditeur se voit encore : l'éditeur grandit avec son code, et dans un long programme les
    boutons sortaient de l'écran (le professeur, 13/11/2026 : « pouvoir exécuter les boutons de l'éditeur, où que l'on
    soit dans le code » ; « barre qui suit » choisie plutôt que des boutons répétés sous l'éditeur). Chaque copie
    clique l'original, dont elle suit l'état (actif, visible) : un seul endroit pour ce que font les boutons."""

    def __init__(self, console: "ConsoleCode", zone: QAbstractScrollArea) -> None:
        super().__init__(zone.viewport())
        self.console, self.zone, self.place = console, zone, False
        self.setAutoFillBackground(True)  # le code qui passe dessous ne se lit pas à travers
        rangee = QHBoxLayout(self)
        rangee.setContentsMargins(0, 0, 0, 0)
        rangee.setSpacing(6)  # le pas de la ``Rangee(6)`` d'origine
        self.paires = []
        for original in console.boutons():
            copie = BoutonSymbole(original.text())
            copie.setFixedWidth(original.width() or original.fontMetrics().height() * 2)
            copie.setFlat(True)
            copie.setToolTip(original.toolTip())
            copie.setFocusPolicy(Qt.FocusPolicy.NoFocus)  # le curseur reste dans l'éditeur, où l'élève écrivait
            copie.clicked.connect(original.click)
            rangee.addWidget(copie)
            self.paires.append((original, copie))
        self.hide()
        zone.verticalScrollBar().valueChanged.connect(self.placer)
        zone.viewport().installEventFilter(self)
        console.editeur.installEventFilter(self)

    def eventFilter(self, objet, evenement) -> bool:
        if evenement.type() in (QEvent.Type.Resize, QEvent.Type.Move, QEvent.Type.Show, QEvent.Type.Hide) and not self.place:
            self.place = True  # se montrer ou se cacher ne doit pas la replacer : la vue la contient
            try:
                self.placer()
            except RuntimeError:  # la zone détruite avant l'éditeur, à la fermeture
                pass
            finally:
                self.place = False
        return False

    def placer(self, *_) -> None:
        """Montrée en haut de la zone, au droit des boutons d'origine, quand la rangée d'origine est au-dessus du bord
        et que le bas de l'éditeur est encore plus bas que la barre ; cachée sinon."""
        console, vue = self.console, self.zone.viewport()
        premier = next((o for o, _ in self.paires if o.isVisibleTo(console)), None)
        if premier is None or not console.isVisible() or not console.editeur.isVisible():
            self.hide()
            return
        for original, copie in self.paires:
            copie.setVisible(original.isVisibleTo(console))
            copie.setEnabled(original.isEnabled())
            copie.setToolTip(original.toolTip())
        self.adjustSize()
        haut = premier.mapTo(vue, QPoint(0, 0))
        bas = console.editeur.mapTo(vue, QPoint(0, console.editeur.height())).y()
        if haut.y() < 0 and bas > self.height():
            self.move(haut.x(), 0)
            self.show()
            self.raise_()
        else:
            self.hide()


def zone_qui_defile(widget: QWidget) -> QAbstractScrollArea | None:
    """La première zone à ascenseur qui contient ``widget`` (le sujet qui défile), ou None."""
    parent = widget.parentWidget()
    while parent is not None:
        if isinstance(parent, QScrollArea):
            return parent
        parent = parent.parentWidget()
    return None


class ConsoleCode(QWidget):
    """``editeur`` prend place entre les boutons et la console ; ``question`` dit la classe et la liste blanche."""

    def __init__(self, editeur, question):
        super().__init__()
        self.editeur, self.question = editeur, question
        self.correction = None  # l'``EditeurCorrection`` qui remplace l'éditeur dans la correction : ▶ en exécute la variante corrigée
        langage = getattr(question, "langage", "python")  # une réponse ouverte à console : Python
        self.amorce = {"sql": "sql>", "assembleur": "asm>"}.get(langage, ">>>")
        self.processus, self.occupe, self.attente, self.fige = None, False, False, False
        self.tampon, self.volume = "", 0
        # les commandes envoyées au processus depuis le dernier ▶ (depuis sa naissance en assembleur, dont les valeurs
        # de départ survivent à ▶), celles d'entre elles déjà finies, la graine de ``random`` du processus, et le
        # journal d'une copie rouverte qui attend d'être rejoué ; ``rangee`` : appelé quand l'``etat`` a changé
        self.journal, self.fait, self.graine, self.reprise, self.rejeu = [], [], None, None, False
        self.rangee = lambda: None
        self.suiveuse = None  # la ``BarreQuiSuit``, créée au premier affichage dans le sujet qui défile
        self.dossier = None  # créé au premier lancement seulement : exporter un sujet ne doit pas semer des dossiers
        self.bouton_executer, self.bouton_arreter = BoutonSymbole("▶"), BoutonSymbole("■")  # l'icône seule, la bulle dit le reste
        self.bouton_profiler = BoutonSymbole("Σ")  # la somme des opérations élémentaires : aucun temps n'est mesuré
        self.bouton_annuler, self.bouton_retablir = BoutonSymbole("↶"), BoutonSymbole("↷")
        for bouton in (self.bouton_executer, self.bouton_profiler, self.bouton_arreter, self.bouton_annuler,
                       self.bouton_retablir):
            bouton.setFixedWidth(bouton.fontMetrics().height() * 2)  # le style de Qt les ferait sinon larges de 80 px
            bouton.setFlat(True)  # l'icône seule, sans fond ni contour ; toute la surface du bouton reste cliquable (29/09/2026)
        for bouton, bulle in ((self.bouton_annuler, "Annuler (Ctrl+Z)"), (self.bouton_retablir, "Rétablir (Ctrl+Maj+Z)")):
            bouton.setToolTip(bulle)
            bouton.setFocusPolicy(Qt.FocusPolicy.NoFocus)  # annuler ne doit pas prendre le curseur à l'éditeur
        self.bouton_executer.setToolTip({"sql": "Exécuter les requêtes sur une base neuve",
                                         "assembleur": "Exécuter le programme depuis les valeurs de départ"}.get(
                                            langage, "Exécuter le programme") + " (Ctrl+Entrée)")
        self.bouton_arreter.setToolTip("Arrêter l'exécution")
        self.bouton_profiler.setToolTip("Exécuter en comptant les opérations élémentaires de chaque ligne")
        self.bouton_profiler.setVisible(self._profilable())
        self.sortie = Sortie(self.valider_ligne)
        # où s'écrit la réponse : l'éditeur, que la correction lit ; l'interpréteur ne sert qu'à voir et à essayer
        # (demande de l'utilisateur, 09/10/2026 : « l'interpréteur interactif ne servant qu'à voir la sortie quand on fait
        # play ou à taper des commandes pour déboguer »)
        self.intitule_console = intitule(INTITULE_CONSOLE)
        barre = Rangee(6)  # passe à la ligne sous 357 px (un téléphone), au lieu d'imposer sa largeur au sujet
        self.intitule_programme = intitule(INTITULE_EDITEUR)
        barre.addWidget(self.intitule_programme)
        barre.addStretch()
        # un pas régulier, Σ caché ou non : un blanc de groupe avant ↶ se lisait comme un double espace (l'utilisateur, 07/11/2026)
        for w in (self.bouton_executer, self.bouton_profiler, self.bouton_arreter, self.bouton_annuler,
                  self.bouton_retablir):
            barre.addWidget(w)
        disposition = QVBoxLayout(self)
        disposition.setContentsMargins(0, 0, 0, 0)
        disposition.setSpacing(2)  # tout se touche : l'intitulé appartient visiblement à la zone qu'il nomme
        disposition.addLayout(barre)
        disposition.addWidget(editeur)
        disposition.addWidget(self.intitule_console)
        disposition.addWidget(self.sortie)
        self.bouton_executer.clicked.connect(lambda: self.executer())  # sans le « checked » du signal
        self.bouton_profiler.clicked.connect(lambda: self.executer(profiler=True))
        self.bouton_arreter.clicked.connect(self.arreter)
        self.bouton_annuler.clicked.connect(editeur.undo)
        self.bouton_retablir.clicked.connect(editeur.redo)
        editeur.textChanged.connect(self._annulation)  # ce que l'éditeur sait défaire change à chaque frappe…
        editeur.annulation.connect(self._annulation)  # … et au lâcher d'un glissement, qui ne touche pas au texte
        self._annulation()
        QShortcut(QKeySequence("Ctrl+Return"), editeur, self.executer)
        self.sortie.amorcer(self.amorce)
        self._etat()
        prechauffer(self.question)

    # Commandes ------------------------------------------------------------------------------------------------

    def masquer_programme(self, masquer):
        """Réponse ouverte à ``console`` : l'interpréteur interactif seul, l'éditeur et ses boutons cachés."""
        for w in (self.intitule_programme, self.editeur, self.bouton_executer, self.bouton_arreter,
                  self.bouton_annuler, self.bouton_retablir):
            w.setVisible(not masquer)
        self.bouton_profiler.setVisible(not masquer and self._profilable())

    def masquer_execution(self, masquer):
        """Sujet ``sans_execution`` : un champ libre comme sur une copie, le programme ne tourne qu'à la soumission."""
        for w in (self.bouton_executer, self.bouton_arreter, self.intitule_console, self.sortie):
            w.setVisible(not masquer)
        self.bouton_profiler.setVisible(not masquer and self._profilable())

    def _profilable(self) -> bool:
        """Σ compte du Python, pas du SQL ni de l'assembleur, et seulement dans une question qui fait compter les
        opérations ou calculer une complexité (``Question.profileur`` ; par sujet le 03/11/2026, par question le 06/11)."""
        return getattr(self.question, "langage", "python") == "python" and self.question.profileur

    def executer(self, profiler=False):
        """``profiler`` : les passages et les opérations élémentaires de chaque ligne reviennent dans la marge droite
        de l'éditeur (``EditeurCode.montrer_profil``)."""
        if not self.bouton_executer.isEnabled() or self.sortie.isHidden():  # Ctrl+Entrée aussi
            return
        if self._prediction_refusee():
            return
        (self.correction or self.editeur).effacer_profil()
        self.sortie.vider()
        self.volume = 0
        if self.amorce != "asm>":  # ▶ repart d'un espace neuf : ce qui précède n'a plus à être rejoué
            self.journal, self.fait, self.reprise = [], [], None
        ordre = {"executer": (self.correction or self.editeur).texte_execute(), "graine": random.randrange(2 ** 31)}
        self.profile = ordre["executer"] if profiler else None  # le profil ne se pose que sur ce texte-là
        self._envoyer({**ordre, "profiler": True} if profiler else ordre)

    def _prediction_refusee(self) -> bool:
        """▶ ne part pas tant qu'une ligne attend sa prédiction : une bulle sur le bouton le dit ; rien ne s'écrit dans
        l'interpréteur, qui reste un interpréteur. Ni la correction, ni un éditeur en lecture seule : on n'y écrit plus rien."""
        manquantes = getattr(self.question, "predictions_manquantes", None)
        lignes = manquantes(self.editeur.toPlainText()) if manquantes and not self.correction and not self.editeur.isReadOnly() else []
        if not lignes:
            return False
        ou = f"à droite de la ligne {lignes[0]}" if len(lignes) == 1 else "à droite des lignes " + ", ".join(map(str, lignes))
        message = f"Avant d'exécuter : écrire votre prédiction en commentaire (après un #) {ou}."
        QToolTip.showText(self.bouton_executer.mapToGlobal(self.bouton_executer.rect().center()), message, self.bouton_executer)
        return True

    def valider_ligne(self, texte):
        self.sortie.ecrire("\n")
        if self.attente:
            self.attente = False
            self._envoyer({"saisie": texte})
        elif not self.occupe:
            self._envoyer({"ligne": texte})

    def etat(self):
        """Ce que la copie garde de la console : la trace (sans la ligne en cours de frappe), l'historique de ↑, et de
        quoi rejouer l'espace de noms. Rien tant que l'élève n'y a rien fait."""
        texte = self.sortie.toPlainText()[:self.sortie.gel]
        if not self.fait and self.reprise is None and texte.strip() in ("", self.amorce):
            return None
        coupe = texte.find("\n", len(texte) - TRACE_MAX) + 1 if len(texte) > TRACE_MAX else 0
        trace = {"texte": texte[coupe:], "invites": [p - coupe for p in self.sortie.invites(len(texte)) if p >= coupe]}
        if self.reprise is not None:
            return {**self.reprise, **trace}
        return {**trace, "historique": self.sortie.historique[-100:], "graine": self.graine, "journal": self.fait}

    def transcription(self) -> str | None:
        """Le contenu de la console tel qu'il se lit et se note : la trace, sans l'invite qui attend ; None si rien n'y
        a été fait."""
        etat = self.etat()
        return (etat["texte"].removesuffix(f"{self.amorce} ").rstrip() or None) if etat else None

    def reprendre(self, etat):
        """Une copie rouverte : la trace et l'historique reviennent, le journal attend le premier Entrée pour être
        rejoué. Une commande qui tournait encore à la fermeture a été tuée avec la page : la trace le dit."""
        if not etat:
            return
        texte = etat["texte"]
        invites = list(etat.get("invites", []))
        if "invites" not in etat or any(AMORCES.match(texte, p) is None for p in invites):
            # une trace de la rev 579, rangée sans ses invites, ou dont une invite ne tombe plus sur « >>> » (texte
            # réécrit sans elles, W597) : les invites en début de ligne, plutôt qu'une copie qui ne s'ouvre plus
            invites = [m.start() for m in re.finditer(r"(?m)^" + AMORCES.pattern, texte)]
        if not invites or AMORCES.match(texte, invites[-1]).end() != len(texte):
            texte += "\n■ Arrêté.\n"
            invites.append(len(texte))
            texte += self.amorce + " "
        self.sortie.restaurer(texte, invites)
        self.sortie.historique = list(etat.get("historique", []))
        self.sortie.rang = len(self.sortie.historique)
        self.reprise = dict(etat) if etat.get("journal") else None

    def arreter(self, *_):
        if self.processus is not None:
            self.processus.kill()  # _fini fait le reste

    # Le processus ---------------------------------------------------------------------------------------------

    def _envoyer(self, ordre):
        if self.processus is None:
            self.dossier = self.dossier or tempfile.TemporaryDirectory()  # là où le programme travaille : rien d'autre n'y est lisible
            self.processus = QProcess(self)
            self.processus.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
            self.processus.readyReadStandardOutput.connect(self._lire)
            self.processus.finished.connect(self._fini)
            self.decodeur = codecs.getincrementaldecoder("utf-8")("replace")
            self.tampon = ""
            reprise, self.reprise = self.reprise, None  # ▶ l'a déjà retirée, sauf en assembleur
            self.graine = reprise["graine"] if reprise else random.randrange(2 ** 31)
            self.journal = self.fait = list(reprise["journal"]) if reprise else []
            self.processus.start(sys.executable, ["-u", str(ENFANT)])
            self.processus.write((json.dumps({"dossier": self.dossier.name, "classe": self.question.classe,
                                              "autorises": self.question.autorises, "langage": getattr(self.question, "langage", "python"),
                                              "base": getattr(self.question, "script_base", str)(),  # ``str()`` : "" pour une ``Ordre``
                                              "prelude": getattr(self.question, "prelude_source", str)(),
                                              "premiere_ligne": getattr(self.question, "premiere_ligne", 1),
                                              "fichiers": getattr(self.question, "fichiers_deposes", dict)(),
                                              "arborescence": getattr(self.question, "arborescence", {}),
                                              "graine": self.graine}) + "\n").encode())
            if reprise:
                self.processus.write((json.dumps({"rejouer": reprise["journal"]}) + "\n").encode())
                self.rejeu = True
                QTimer.singleShot(REJEU_LENT, self._rejeu_lent)
            prechauffer(self.question)  # la réserve vient d'être consommée : en remonter une pour la prochaine console
        self.processus.write((json.dumps(ordre) + "\n").encode())
        self.journal = [*self.journal, ordre]
        self.occupe = True
        self._etat()

    def _lire(self):
        """La sortie du programme, et ses lignes de contrôle (``\\x1e{json}``) qui peuvent arriver coupées en deux."""
        self.tampon += self.decodeur.decode(bytes(self.processus.readAllStandardOutput()))
        while True:
            i = self.tampon.find("\x1e")
            fin = self.tampon.find("\n", i) if i >= 0 else -1
            self._ecrire(self.tampon if i < 0 else self.tampon[:i])
            if i < 0 or fin < 0:
                self.tampon = "" if i < 0 else self.tampon[i:]
                return
            try:
                self._controle(json.loads(self.tampon[i + 1:fin]))
            except ValueError:
                pass  # le programme a imprimé le séparateur : rien à en faire
            self.tampon = self.tampon[fin + 1:]

    def _controle(self, ordre):
        if "profil" in ordre:
            editeur = self.correction or self.editeur
            if editeur.texte_execute() == getattr(self, "profile", None):  # pas modifié pendant l'exécution
                editeur.montrer_profil(ordre["profil"])
        elif ordre.get("attend"):
            self.attente = True  # le programme a imprimé sa propre invite : l'élève tape à la suite
        elif ordre.get("fin"):
            self.occupe = self.rejeu = False
            self.sortie.amorcer("..." if ordre["suite"] else self.amorce)  # le bloc n'est pas fini : « ... »
            self.fait = self.journal
            self.rangee()
        self._etat()

    def _rejeu_lent(self):
        """La reprise dure : l'élève ne voit qu'une console occupée, qu'il sache pourquoi et comment en sortir."""
        if self.rejeu and self.occupe:
            self._ecrire("(reprise des commandes de la séance précédente… ■ pour l'arrêter)\n")

    def _fini(self, *_):
        arrete = self.occupe or self.attente
        au_repos = not arrete and self.sortie.toPlainText()[:self.sortie.gel].endswith(self.amorce + " ")
        if arrete:
            self._ecrire("\n■ Arrêté.\n")
        elif not au_repos:
            self._ecrire("\n")  # tué au milieu d'un bloc (« ... ») : le bloc meurt avec le processus
        self.processus = None
        self.occupe = self.attente = self.rejeu = False
        if not au_repos:  # tué au repos (question fermée) : « >>> » est déjà là, pas un second
            self.sortie.amorcer(self.amorce)
        self.journal = self.fait = []  # l'espace de noms est mort avec le processus : le suivant repart de rien
        self.rangee()
        self._etat()
        prechauffer(self.question)  # Arrêter relancera tout un processus : qu'il soit déjà chaud

    def _ecrire(self, texte):
        if not texte:
            return
        self.sortie.ecrire(texte)
        self.volume += len(texte)
        if self.volume > VOLUME and self.processus is not None:
            self.volume = 0
            self.arreter()
            self._ecrire("\n■ Trop de sortie : arrêté.\n")

    def _annulation(self):
        self.bouton_annuler.setEnabled(self.editeur.annulable() and not self.fige)
        self.bouton_retablir.setEnabled(self.editeur.retablissable() and not self.fige)
        self._suivre()

    def figer(self, fige):
        """La question soumise, sous son voile : la console reste active, son éditeur en lecture seule, pour qu'on y
        sélectionne et copie le code (``modele.Voile.event``) ; ce qui tournait s'arrête. ▶ Σ ■ restent actifs, percés
        dans le voile : le code rendu se relance et ses opérations se comptent après la correction (le professeur,
        19/11/2026, W807 : « il faut autoriser le play et le compteur d'operation , et qu'il ne soient pas bloqués par le
        voile, donc passer par dessus mais avec fond transprant ») ; ↶ ↷ restent éteints, l'éditeur en lecture seule."""
        if fige != self.fige:
            self.fige = fige
            if fige:
                self.arreter()
            self._etat()
            self._annulation()

    def executables(self) -> tuple[QPushButton, ...]:
        """Les boutons qui exécutent (▶ Σ ■) : percés dans le voile d'une question soumise (``figer``)."""
        return self.bouton_executer, self.bouton_profiler, self.bouton_arreter

    def boutons(self) -> tuple[QPushButton, ...]:
        """Les boutons de la rangée de l'éditeur, dans l'ordre de la rangée."""
        return (self.bouton_executer, self.bouton_profiler, self.bouton_arreter, self.bouton_annuler,
                self.bouton_retablir)

    def showEvent(self, evenement) -> None:
        super().showEvent(evenement)
        if self.suiveuse is None and (zone := zone_qui_defile(self)) is not None:  # posée dans le sujet : une seule fois
            self.suiveuse = BarreQuiSuit(self, zone)
        self._suivre()

    def _suivre(self) -> None:
        if self.suiveuse is not None:
            self.suiveuse.placer()

    def _etat(self):
        self.bouton_executer.setEnabled(not self.occupe)
        self.bouton_profiler.setEnabled(not self.occupe)
        self.bouton_arreter.setEnabled(self.occupe or self.attente)
        self.sortie.setReadOnly((self.fige or self.occupe) and not self.attente)
        if self.attente:
            self.sortie.setFocus()
        self._suivre()

    def changeEvent(self, evenement):
        """La question se ferme (soumise, validée) : le programme qui tourne n'a plus lieu de le faire."""
        if evenement.type() == QEvent.Type.EnabledChange and not self.isEnabled():
            self.arreter()
        super().changeEvent(evenement)
