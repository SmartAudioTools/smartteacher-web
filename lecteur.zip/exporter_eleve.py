"""Exporte un sujet en paquet élève : <sujet>.json, EN CLAIR, dans le dossier du cours que nomme son ``dossier`` (sinon
Exports/qcm/), où il se versionne (/DATA/Projets) ; il n'est chiffré qu'en partant vers les élèves, en <sujet>.qcm, le seul
fichier qu'ils reçoivent (``chiffre`` : « Déployer », ``web/dropbox_professeur.py deposer``, qui refuse tout sujet en clair).
Demande de l'utilisateur, 11/10/2026 : versionner les exports et voir leur historique, sans payer un fichier chiffré entier,
illisible pour hg, à chaque petite modification.

Le paquet contient les questions COMPLÈTES, réponses attendues, indices et explications compris : le lecteur (lecteur.py)
corrige en direct. C'est le chiffrement du fichier distribué (age, par une clé tirée du mot de passe professeur, ``codes``) qui les
protège d'un élève qui l'ouvre dans un éditeur ; l'élève ne l'ouvre qu'avec le code que donne ``code_eleve.py``, de sa
classe ou sans classe, daté au besoin : un sujet distribué à l'avance ne s'ouvre qu'au moment voulu. La note du lecteur n'est jamais la note officielle : le professeur corrige les rendus.
Le fichier rendu par l'élève est ce même fichier, réécrit à chaque réponse (voir.py l'ouvre).

Un seul fichier pour la classe, qui porte chaque question une seule fois, telle que la banque la donne, avec les réglages
du sujet (aides, seconde chance, entraînement, mélange des questions) : c'est le lecteur qui les applique à l'accueil et
tire ``variables`` et mélanges au nom de l'élève (``Paquet.nommer``, graine du sujet et nom) — deux voisins d'écran n'ont
pas les mêmes valeurs, et le même élève retrouve les siennes s'il rouvre le sujet. Le fichier refait donc aussi le sujet :
``exporter_pdf.py Exports/qcm/x.json`` en regénère le PDF, ``exporter_eleve.py`` le paquet, quand la banque aura changé.
Chaque question y garde ses deux versions, celle du papier et celle pour l'écran (``electronique`` : un TP fait dans
l'éditeur du lecteur plutôt que dans celui de l'élève), que le lecteur choisit à l'accueil : c'est le même paquet que
joint le PDF, et un PDF regénéré depuis le .qcm imprime le papier.

Les outils du professeur l'ouvrent seuls, sujet et copies (``codes.cle_du_fichier``). Avec les listes de classes
(``-c B3_P_NSINF_GR1.csv …`` : en-tête ``nom,prenom``, un fichier par classe, nommé d'après elle, sept au plus),
``code_eleve.py`` donne le code de chaque classe ; l'élève y ajoute son mot de passe, le même pour tous les sujets. Un élève absent des listes n'entre qu'avec le code sans
classe (sa copie va à part, « Hors liste ») ; l'ajouter à la liste, c'est réexporter, ce qui change la clé et donc les codes.

``--en-clair`` : un ``.qcm`` sans chiffrement ni inscrits, pour les sujets de démonstration du lecteur web (``web/construire.py``), dont les
réponses n'ont rien à cacher.
"""

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from serializejson._encryption import decrypt, encrypt, is_encrypted, prime

import codes
import echeances
from modele import LOGO, Paquet, Section, copier, sauver
from noyau import normaliser
from sujet import PROF, RACINE, Sujet, les_sujets, piece_jointe, reduire, revision, sortie


def paquet(sujet, inscrits=None):
    """Le ``Paquet`` d'un ``Sujet`` : ses questions telles que la banque les donne (aux points du sujet), les textes
    partagés qu'elles citent, ses médias, et les réglages du sujet, que le lecteur applique à l'accueil (``Paquet.nommer``).
    Chaque question et chaque section garde sa version pour l'écran (``electronique``) : le même paquet est joint au PDF,
    qui imprime le papier, et distribué, le lecteur prenant la version pour l'écran à l'accueil."""
    d = sujet.definition
    sections = [Section([copier(q, sauf=("saisie",), imposes=forcer(q, forces)) for q, forces in sujet.posees(s)],
                        s.titre, s.consignes, s.bonus, s.nouvelle_page, s.electronique, s.partie) for s in d.sections]
    for s in sections:  # les bonus à leur barème réduit, comme le papier les imprime (``sujet.coefficient_bonus``)
        if s.bonus and sujet.coefficient_bonus != 1:
            s.questions = [reduire(q, sujet.coefficient_bonus) for q in s.questions]
    for s in sections:
        for q in s.questions:
            sans_source(q)
    lues = [q for s in sections for q in s.questions for q in (q, q.version_electronique(d.sans_ide)) if q]
    cites = {n for q in lues for f in (q, *q.sous_questions) for n in f.contextes_cites()}
    bases = {n for q in lues for f in (q, *q.sous_questions) for n in getattr(f, "bases_citees", set)()}
    return Paquet(d.titre, d.destination, sections, d.sous_titre, d.theme, d.matiere, d.classe, d.date, d.consignes,
                  d.duree_minutes, d.fichier, {n: t for n, t in sujet.contextes.items() if n in cites},
                  sujet.medias | ({LOGO: sujet.logo.read_bytes()} if sujet.logo else {}), d.affichage, d.retour,
                  d.correction, graine=sujet.graine, sans_execution=d.sans_execution, inscrits=inscrits, revision=revision(),
                  melanger_questions=d.melanger_questions, seconde_chance=d.seconde_chance, est_revision=d.est_revision, validation=d.validation, reviser=d.reviser, insecables=d.insecables,
                  acces_cours=d.acces_cours, sans_ide=d.sans_ide, anti_triche=d.anti_triche, temps=d.temps,
                  cours=[os.path.relpath(PROF / c, sortie(d, "qcm")) for c in d.cours], cours_pages=d.cours_pages, dossier=d.dossier,
                  cours_masques={os.path.relpath(PROF / c, sortie(d, "qcm")): zones for c, zones in sujet.cours_masques().items()},
                  cours_code={os.path.relpath(PROF / c, sortie(d, "qcm")): zones for c, zones in sujet.cours_code().items()},
                  jugement={"cours_pdf": [os.path.relpath(PROF / c, sortie(d, "qcm")) for c in d.cours_jugement or d.cours]} if d.cours_jugement or d.cours else None,
                  nom=sujet.chemin.stem, exercices_au_choix=d.exercices_au_choix, numerotation_par_section=d.numerotation_par_section, nouvel_essai=d.nouvel_essai, adresse=d.adresse, plafond_nommage=d.plafond_nommage, bases={n: t for n, t in sujet.bases.items() if n in bases})


def sans_source(q: Any) -> None:
    """Retire de ``q``, de ses sous-questions et de ses marches le champ ``source`` (d'où vient la question) : il est
    au professeur, le paquet de l'élève, ``.qcm`` comme lecteur web (``web/construire.py`` passe par ici), ne le porte
    pas. Pas par ``copier(sauf=…)``, qui le retirerait aussi des arêtes d'un graphe (``Arete.source``)."""
    q.source = ""
    for f in (*q.sous_questions, *(q.marches or ())):
        sans_source(f)


def forcer(q, points):
    """Les points que le sujet impose à ``q`` (``None`` : ceux de la banque), aussi à sa version pour l'écran si elle
    en déclare d'autres : le sujet l'emporte sur les deux."""
    if points is None or q.sous_questions:
        return None
    variantes = [v for v in (q.electronique, isinstance(q.electronique, dict) and q.electronique.get("sans_ide")) if isinstance(v, dict)]
    if not any("points" in v for v in variantes):
        return {"points": points}
    electronique = {**q.electronique, "points": points}
    if isinstance(electronique.get("sans_ide"), dict):
        electronique["sans_ide"] = {**electronique["sans_ide"], "points": points}
    return {"points": points, "electronique": electronique}


def cle_neuve(graine: str, secret: str | None = None) -> tuple[str, str]:
    """``(mot de passe professeur, clé du fichier d'un sujet)`` : un sel déduit de la ``graine`` du sujet, que serializejson
    écrira dans l'en-tête age du prochain fichier chiffré par cette clé (``prime``), d'où les outils du professeur la
    recalculent. Un sujet réexporté, où que ce soit et sous n'importe quel nom, garde donc sa clé et les codes déjà donnés ;
    le .qcm porte son sel, un renommage après coup n'y change rien."""
    secret = secret or codes.professeur()
    if not secret:
        raise SystemExit(f"chiffrer un sujet demande le mot de passe professeur, absent : {codes.FICHIER}")
    sel = hashlib.sha256(f"smartteacher|{graine}".encode()).digest()[:16]
    cle = codes.cle_sujet(secret, sel)
    prime(cle, sel)
    return secret, cle


def listes_du_niveau(niveau: str | None) -> list[Path]:
    """Les listes de ``listes/`` dont le nom dit le ``niveau`` du sujet (champ ``classe`` : « Seconde »…) : celles qu'un
    export sans ``-c`` inscrit, pour que le déploiement (``deployer_qcm.py``) offre toutes ces classes et présélectionne
    celle du cours. Aucune sans niveau, ni pour un nom de liste qui ne dit pas le sien. Un « Réviser » porte le niveau de
    sa banque (« NSI Terminale », « SNT » : ``entrainement.definition_reviser``), lu comme celui de Dropbox
    (``codes.EN_LIGNE``) : sans liste, son .qcm n'inscrivait aucune classe et aucun élève ne l'ouvrait (W807, 19/11/2026)."""
    from entrainement import NIVEAUX as BANQUES  # noqa: PLC0415 - entrainement importe sujet : seulement à l'export
    niveau = codes.EN_LIGNE.get(BANQUES.get(niveau or "", ""), niveau)

    def niveau_de(liste):
        try:
            return normaliser(codes.niveau(liste.stem))
        except ValueError:
            return None
    return [l for l in sorted((RACINE / "listes").glob("*.csv")) if niveau and niveau_de(l) == normaliser(niveau)]


def listes_du_sujet(definition: Any) -> list[Path]:
    """Les listes qu'un export sans ``-c`` inscrit dans le ``.qcm`` du sujet ``definition`` : celles de ses niveaux."""
    return [l for n in definition.niveaux or [definition.classe] for l in listes_du_niveau(n)]


def exporter(chemin, dossier=None, listes=(), chiffrer=True) -> Path:
    """Exporte le sujet ``chemin`` : le paquet en clair, ``<sujet>.json``, inscrits compris (``preparer``), que l'on versionne ;
    il n'est chiffré qu'en partant vers les élèves (``chiffre`` : « Déployer », ``web/dropbox_professeur.py deposer``).
    ``chiffrer`` faux (``--en-clair``, démonstrations du lecteur web) : un ``.qcm`` en clair, sans inscrits. Un sujet
    « Réviser » est d'abord regénéré sur les banques du moment (``entrainement.a_jour``)."""
    from entrainement import a_jour  # noqa: PLC0415 - entrainement importe sujet et bilans : seulement pour exporter
    a_jour(Path(chemin))
    sujet = Sujet(chemin)
    dossier = dossier or sortie(sujet.definition, "qcm")
    dossier.mkdir(parents=True, exist_ok=True)
    fichier = dossier / f"{codes.nom_de_fichier(Path(chemin).stem)}.{'json' if chiffrer else 'qcm'}"
    contenu, _ = preparer(sujet, listes, chiffrer)
    sauver(contenu, fichier)
    print(fichier)
    return fichier


MAGIE_PAQUET = b'"__class__": "Paquet"'  # dans les 64 premiers octets d'un paquet en clair : la règle de Dolphin (associations/installer.sh)


def est_paquet(chemin: Path) -> bool:
    """``chemin`` est un paquet en clair (le ``.json`` qu'écrit ``exporter``), pas un sujet."""
    chemin = Path(chemin)
    if chemin.suffix != ".json" or not chemin.is_file():
        return False
    with chemin.open("rb") as f:
        return MAGIE_PAQUET in f.read(64)


CONF = Path(__file__).resolve().parent / "web" / "deployer.conf"  # non versionné : HOTE, DROPBOX, DEPOT, ANTHROPIC, MODELE


def jugement_configure(conf: Path | None = None, comptes: Path | None = None) -> dict[str, str] | None:
    """``{"cle", "modele"}`` de la correction automatique des réponses ouvertes, None sans clé : la clé du compte actif
    de ``web/comptes_api.json`` (``comptes_api``, choisi dans « Gérer les sujets », W1076), sinon ``ANTHROPIC=`` de
    ``web/deployer.conf`` ; ``MODELE=`` et ``ESCALADE=`` de ``deployer.conf``. La clé part chez l'élève, qui peut la lire
    dans son navigateur : une clé dédiée, plafonnée dans la console Anthropic (correction/README.md)."""
    import comptes_api  # noqa: PLC0415
    conf = conf or CONF
    lignes = {c: v.strip().strip("'\"") for c, v in (l.split("=", 1) for l in conf.read_text().splitlines() if "=" in l)} \
        if conf.exists() else {}  # une valeur entre guillemets vaut pour le shell qui source la conf : pas pour la clé
    compte = comptes_api.actif(comptes_api.lire(comptes or conf.with_name(comptes_api.FICHIER.name)))
    cle = compte and compte.get("cle") or lignes.get("ANTHROPIC")
    if not cle:
        return None
    return {"cle": cle, **{c: lignes[v] for c, v in (("modele", "MODELE"), ("escalade", "ESCALADE")) if lignes.get(v)}}


def texte_pdf(chemin: Path) -> str:
    """Le texte d'un cours PDF (``pdftotext``), donné au modèle qui juge ; "" si le PDF manque ou ne se lit pas : un dépôt n'est pas bloqué pour cela."""
    try:
        r = subprocess.run(["pdftotext", str(chemin), "-"], capture_output=True, text=True)
    except OSError as exc:
        print(f"{chemin} : pdftotext impossible ({exc})", file=sys.stderr)
        return ""
    if r.returncode:
        print(f"{chemin} : cours illisible ({r.stderr.strip()})", file=sys.stderr)
    return r.stdout.strip() if not r.returncode else ""


def sections_du_cours(pdf: Path) -> dict[str, str]:
    """Les sections {titre: texte} du cours ``pdf`` : son ``.sections.json`` voisin (``.construction/cours/sections_cours.py``),
    à défaut son texte entier en une section nommée d'après le fichier (la convention de ce script pour un cours sans
    titres) ; {} si rien ne se lit."""
    if (fichier := pdf.with_suffix(".sections.json")).is_file():
        return json.loads(fichier.read_text(encoding="utf-8"))
    return {pdf.stem: t} if (t := texte_pdf(pdf)) else {}


def chiffre(chemin: Path, cle_api: bool = True, cours_depuis: Path | None = None) -> bytes:
    """Les octets du ``.qcm`` que reçoivent les élèves : un paquet ``.json`` chiffré par la clé de sa graine (``cle_neuve`` :
    la même à chaque déploiement, donc les mêmes codes), la clé de correction automatique ajoutée s'il y en a une
    (``jugement_configure`` : ``Paquet.jugement``, jamais dans le paquet en clair versionné) ; un ``.qcm`` lu tel quel.
    Sans ``cle_api`` (le paquet que joint un PDF, ``exporter_pdf.paquet_chiffre``) : jamais de clé de correction, que
    ``paquet_de`` écrirait en clair à côté du PDF ; le paquet tel qu'en clair, comme celui que joint le PDF d'un sujet.
    ``cours_depuis`` : le dossier d'où partent les chemins des cours (``preparer`` : celui de l'export), quand le paquet
    a été écrit ailleurs (``qcm_de``, dossier temporaire)."""
    octets = Path(chemin).read_bytes()
    if not est_paquet(chemin):
        return octets if cle_api else sans_cle_api(octets)
    paquet = json.loads(octets)
    graine = paquet.get("graine") or paquet.get("graine_sujet")  # une copie papier en clair : la clé de son sujet
    if not graine:
        raise ValueError(f"{chemin} : paquet sans graine, il ne se chiffre pas")
    if not cle_api:
        return encrypt(octets, cle_neuve(graine)[1])
    # l'élève et les aménagements d'une copie imprimée (``Paquet.impression``) ne partent pas vers les élèves
    imprime = paquet.pop("impression", None)
    jugement, en_clair = jugement_configure(), paquet.pop("jugement", None)  # le paquet en clair ne porte que les chemins des cours (``cours_pdf``)
    if jugement:  # leurs sections {titre: texte} suivent la clé, jamais le paquet versionné (``contrat_jugement.extrait_cours``)
        cours: dict[str, str] | list[str] = {}
        for c in (en_clair or {}).get("cours_pdf", []):
            pdf = (cours_depuis or Path(chemin).parent) / c
            for titre, texte in sections_du_cours(pdf).items():  # un titre que porte déjà un autre cours : préfixé du sien
                cours[titre if titre not in cours else f"{pdf.stem} › {titre}"] = texte
        cours = cours or (en_clair or {}).get("cours", [])  # un paquet tiré d'un .qcm déployé : ses textes
        paquet["jugement"] = {**jugement, **({"cours": cours} if cours else {})}
    if jugement or en_clair or imprime:
        octets = json.dumps(paquet, ensure_ascii=False, indent="\t").encode()
    return encrypt(octets, cle_neuve(graine)[1])


def sans_cle_api(octets: bytes) -> bytes:
    """Un ``.qcm`` (déployé, ou en clair) sans la clé de correction automatique que ``chiffre`` y a mise, rechiffré à la
    même clé ; tel quel s'il n'en porte pas, ou si le mot de passe professeur ne l'ouvre pas."""
    cle = is_encrypted(octets) and codes.professeur() and codes.cle_du_mot(codes.professeur(), octets)
    if is_encrypted(octets) and not cle:
        return octets
    paquet = json.loads(decrypt(octets, cle) if cle else octets)
    jugement = paquet.get("jugement") or {}
    if "cle" not in jugement:
        return octets
    if reste := {k: v for k, v in jugement.items() if k not in ("cle", "modele", "escalade")}:
        paquet["jugement"] = reste
    else:
        del paquet["jugement"]
    clair = json.dumps(paquet, ensure_ascii=False, indent="\t").encode()
    return encrypt(clair, cle_neuve(paquet.get("graine") or paquet.get("graine_sujet"))[1]) if cle else clair


def paquet_de(chemin, dossier=None) -> Path:
    """Le paquet d'un sujet, quel que soit le fichier ouvert : un paquet (``.json`` en clair, ou ``.qcm``) lui-même ; celui
    qu'exporte un sujet ``.json`` (``exporter`` : dans le dossier du cours, ou ``dossier``) ; celui que joint un PDF
    (``exporter_pdf.py``), déchiffré à côté de lui (ou dans ``dossier``) sous le nom du sujet, sans « - corrigé ». Les trois
    formats ont le même clic droit dans Dolphin (``associations/``) et s'ouvrent d'un double clic dans le lecteur."""
    chemin = Path(chemin)
    if chemin.suffix == ".json":
        return chemin if est_paquet(chemin) else exporter(chemin, dossier)
    if chemin.suffix != ".pdf":
        return chemin
    octets = piece_jointe(chemin)
    if is_encrypted(octets):
        secret = codes.professeur()
        cle = secret and codes.cle_du_mot(secret, octets)
        if not cle:
            raise ValueError(f"{chemin} : le paquet joint ne s'ouvre qu'avec le mot de passe professeur ({codes.FICHIER})")
        octets = decrypt(octets, cle)
    clair = (dossier or chemin.parent) / (chemin.stem.removesuffix(" - corrigé") + ".json")
    if not clair.exists() or clair.read_bytes() != octets:
        clair.write_bytes(octets)
    return clair


def qcm_de(chemin, dossier: Path) -> Path:
    """Le ``.qcm`` chiffré d'un sujet (``paquet_de``, puis ``chiffre``), écrit dans ``dossier`` : un dossier temporaire,
    jamais celui du cours, où seul le paquet en clair est rangé. Le PDF d'une copie papier rendue (« <sujet> [<élève>].pdf »,
    ``correction/copie_papier.py``) joint la copie de l'élève : elle sort telle quelle, chiffrée, et s'ouvre par son code."""
    if Path(chemin).suffix == ".pdf" and codes.est_copie(Path(chemin).with_suffix(".qcm").name):
        copie = Path(dossier) / Path(chemin).with_suffix(".qcm").name
        copie.write_bytes(piece_jointe(chemin))
        return copie
    paquet_clair = paquet_de(chemin, dossier)
    if not est_paquet(paquet_clair):
        return paquet_clair
    # les chemins des cours partent du dossier de l'export, pas du dossier temporaire : rejeu du 21/11/2026 (W881),
    # « …/tmpj_og7c3f/../Localisation, cartographie et mobilité.pdf : cours illisible »
    ancre = (sortie(Sujet(chemin).definition, "qcm") if Path(chemin).suffix == ".json" and not est_paquet(chemin)
             else None)
    qcm = Path(dossier) / f"{paquet_clair.stem}.qcm"
    qcm.write_bytes(chiffre(paquet_clair, cours_depuis=ancre))
    return qcm


def preparer(sujet, listes=(), chiffrer=True, texte_echeances=None):
    """``(paquet, clé)`` du ``Sujet`` : ses classes inscrites (``listes``, celles de son niveau par défaut), chiffré par la clé
    de sa graine (``niveaux`` du sujet : plusieurs niveaux). Une classe dont la ligne d'échéances (``texte_echeances``,
    celui de Dropbox par défaut) a une case ``eleves`` n'inscrit qu'eux (``echeances.vise``) : un rattrapage. Le même pour le ``.qcm`` exporté et celui que joint le PDF, que « Déployer » en extrait (``deployer_qcm.py``)."""
    if not listes and chiffrer:
        listes = listes_du_sujet(sujet.definition)
    inscrits = {Path(l).stem: codes.lire_liste(l) for l in listes}
    texte = echeances.du_disque() if texte_echeances is None else texte_echeances
    for classe, liste in inscrits.items():
        if (ligne := echeances.lire(echeances.trouver(texte, {sujet.chemin.stem}, classe))).eleves:
            inscrits[classe] = [e for e in liste if echeances.vise(ligne, e[0], e[1])]
            if ligne.eleves - {echeances.empreinte_eleve(e[0], e[1]) for e in liste}:
                raise SystemExit(f"{sujet.chemin.stem}, {classe} : empreintes de la case eleves absentes de la liste")
    if len(inscrits) > codes.CLASSES:
        raise SystemExit(f"{len(inscrits)} classes : {codes.CLASSES} au plus par sujet")
    cle = None
    if chiffrer:
        cle = cle_neuve(sujet.graine)[1]
        inscrits = {classe: codes.inscrire(liste) for classe, liste in inscrits.items()}
    elif inscrits:
        raise SystemExit("--en-clair : sans listes de classes (leurs codes portent la clé)")
    return paquet(sujet, inscrits or None), cle


def main():
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujets", nargs="*", type=Path, help="sujets à exporter (défaut : tous ceux de sujets/)")
    analyseur.add_argument("-o", "--dossier", type=Path, help="dossier de sortie (défaut : celui du champ dossier du sujet, sinon Exports/qcm/)")
    analyseur.add_argument("-c", "--classes", nargs="+", type=Path, default=(), metavar="LISTE.csv",
                           help="listes des classes admises (nom,prenom), sept au plus : codes par code_eleve.py")
    analyseur.add_argument("--en-clair", action="store_true", help="sans chiffrement : sujets de démonstration")
    arguments = analyseur.parse_args()
    for chemin in arguments.sujets or les_sujets():
        exporter(chemin, arguments.dossier, arguments.classes, not arguments.en_clair)


if __name__ == "__main__":
    main()
