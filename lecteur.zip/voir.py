#!/usr/bin/env python3
"""Affiche un fichier du projet : une banque (corrigée), un paquet livré ou le rendu d'un élève, sans distinction.

    python voir.py FICHIER [--mot-de-passe MOT] [--capture IMAGE.png]

Tout ce qui contient des questions est un widget (modele.py) : ``charger(fichier).show()`` suffit. ``--capture`` écrit
l'image de la fenêtre et sort, sans rien montrer (vérification hors écran).
"""

import argparse
import sys
from pathlib import Path

from qtpy6 import erreurs
from qtpy6.QtWidgets import QInputDialog, QLineEdit, QMessageBox

import codes
from modele import application, charger

from serializejson import DecryptionError


def mot_de_passe_en_cause(erreur):
    """Vrai si c'est bien le mot de passe qui bloque. serializejson enveloppe TOUTE erreur de décodage dans le même
    ``ValueError`` « this document is encrypted » : sans ce tri, un paquet déchiffré mais impossible à reconstruire se
    présenterait comme un mot de passe refusé, qu'aucune saisie ne débloquerait. La cause distingue les deux — une
    ``ValueError`` (les octets lus ne sont pas du JSON) veut dire encore chiffré, tout le reste vient d'après."""
    cause = erreur.__cause__
    return isinstance(erreur, DecryptionError) or (isinstance(erreur, ValueError) and (cause is None or isinstance(cause, ValueError)))


def raison(chemin, erreur):
    """Ce qui empêche d'ouvrir le fichier, dit pour l'élève : lancé d'un double clic, le lecteur n'a pas de terminal où stderr se verrait."""
    message = f"{chemin} :\n{erreur.__cause__ or erreur}"
    if isinstance(erreur, PermissionError):
        try:
            proprietaire = Path(chemin).owner()
        except KeyError:  # compte isolé dont l'uid n'est pas dans /etc/passwd
            proprietaire = Path(chemin).stat().st_uid
        message += f"\n\nIl appartient à « {proprietaire} » : votre compte n'a pas le droit de le lire."
    return message


def renoncer(chemin, erreur, interactif):
    """Renonce en disant pourquoi (``raison``)."""
    message = raison(chemin, erreur)
    if interactif:
        QMessageBox.critical(None, "Impossible d'ouvrir ce fichier", message)
    raise SystemExit(message)


class MotDePasseRequis(Exception):
    """Le fichier est chiffré et aucun des mots de passe essayés ne l'ouvre."""


def essayer(chemin, mot_de_passe=None):
    """``(objet, mot de passe qui l'a ouvert)`` : celui donné, sinon aucun, sinon la clé que le mot de passe professeur du
    professeur en déduit (``codes`` : tout sujet exporté, et ses copies).
    ``MotDePasseRequis`` si aucun ne convient ; toute autre erreur (fichier absent, illisible, corrompu) remonte telle quelle,
    sans quoi elle se présenterait comme un mot de passe refusé, qu'aucune saisie ne débloquera. Le tri, ``mot_de_passe_en_cause``."""
    for essai in [mot_de_passe] if mot_de_passe else [None, *filter(None, [codes.cle_du_fichier(chemin)])]:
        try:
            return charger(chemin, essai), essai
        except Exception as erreur:  # noqa: BLE001 - tout peut échouer ici : on trie ce qui vient du mot de passe
            if not mot_de_passe_en_cause(erreur):
                raise
            derniere = erreur
    raise MotDePasseRequis(str(derniere)) from derniere


def ouvrir(chemin, mot_de_passe=None, interactif=True):
    """``essayer``, puis le mot de passe demandé (``interactif``) jusqu'à ce qu'il convienne ou que l'on renonce (``SystemExit``).
    Le lecteur de l'élève ne passe pas par ici : sa boîte d'accueil (``lecteur.Accueil``) demande le code sans bloquer."""
    while True:
        try:
            return essayer(chemin, mot_de_passe)
        except MotDePasseRequis as erreur:
            if not interactif:
                raise SystemExit(f"{chemin} : impossible de l'ouvrir ({erreur})") from erreur
        except Exception as erreur:  # noqa: BLE001 - tout le reste est dit tel quel
            renoncer(chemin, erreur, interactif)
        mot_de_passe, ok = QInputDialog.getText(None, "Mot de passe", f"{chemin} est chiffré. Mot de passe :", QLineEdit.EchoMode.Password)
        if not ok:
            raise SystemExit(1)


def main():
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("fichier")
    analyseur.add_argument("--mot-de-passe")
    analyseur.add_argument("--capture", help="écrit l'image de la fenêtre dans ce fichier, puis sort")
    a = analyseur.parse_args()
    app = application()
    if not a.capture:
        erreurs.installer()
    objet, _ = ouvrir(a.fichier, a.mot_de_passe, not a.capture)
    objet.show()
    if a.capture:
        for _ in range(3):
            app.processEvents()
        objet.grab().save(a.capture)
        return 0
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
