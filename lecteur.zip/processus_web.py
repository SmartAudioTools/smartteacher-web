"""La correction d'une question ``code`` dans le navigateur (``modele.Code.soumettre``) : un Web Worker de qtpy6web, à
part de ceux des consoles (un programme qui tourne dans une console ne la retarde pas), où ``enfant.verifier`` (web/enfant.py)
joue les tests du professeur. Un verdict par demande, rendu par rappel ; sans réponse au bout de DELAI, le worker est tué
et la question vaut zéro. Les consoles, elles, parlent au leur par ``qtpy6web.travailleur.Processus`` (console_code.py)."""

import functools
import json

from qtpy6web.travailleur import REGLAGES, Travailleur

DELAI = 10  # verifier.DELAI : secondes laissées à la correction d'une question avant de la tenir pour une boucle infinie


class Verificateur(Travailleur):
    def __init__(self):
        super().__init__(REGLAGES["indexURL"], REGLAGES["archives"], REGLAGES["module"], REGLAGES["cwd"])
        self.rappels = {}  # numéro d'appel -> rappel(fraction, message)
        self.termine.connect(lambda numero, verdict: self._repondre(numero, **json.loads(verdict)))
        self.erreur.connect(lambda numero, texte: self._repondre(numero, 0, "la vérification n'a pas pu se faire : " + texte))
        self.expire.connect(lambda numero: self._repondre(numero, 0, f"le programme ne s'est pas terminé en {DELAI} s : boucle infinie ?", tuer=True))

    def verifier(self, demande, rappel):
        """``demande`` = ``noyau.Code.epreuve()`` plus ``source`` ; ``rappel(fraction, message)`` au verdict."""
        self.rappels[self.appeler("verifier", json.dumps(demande), delai=DELAI)] = rappel

    def _repondre(self, numero, fraction, message, tuer=False):
        rappels = [self.rappels.pop(numero)]
        if tuer:  # le worker est perdu, et avec lui les demandes qui attendaient derrière celle-ci
            self.tuer()
            rappels += [self.rappels.pop(n) for n in list(self.rappels)]
        for rappel in rappels:
            rappel(fraction, message)


@functools.cache
def verificateur():
    return Verificateur()
