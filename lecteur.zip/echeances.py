"""Le fichier d'échéances du professeur (``echeances.csv``, à la racine de son dossier Dropbox ``SmartTeacherQcm/``) : ce qu'un
code de classe porte (départ, durée, échéance, anti-triche, temps, soumission), écrit en clair, une ligne par sujet et par
classe, qu'il voit et corrige à la main après avoir donné le code ou le lien. Quand le lecteur peut le lire (réseau), le
fichier GAGNE sur le code : une échéance repoussée dans le fichier vaut, même si le lien envoyé porte l'ancienne (décision de
l'utilisateur, 25/10/2026 : « oui, le fichier gagne »). Sans réseau, ou sans ligne pour ce sujet et cette classe, ou pour une
case vide, c'est le code qui vaut : il reste le repli complet.

Format (point-virgule, UTF-8 avec ou sans BOM, comme l'enregistre un tableur) ; seules ``sujet`` et ``classe`` sont exigées,
toute autre colonne peut manquer ou rester vide :
    sujet        le nom du dossier du sujet, ou celui du .qcm sans extension (un chemin : seul son dernier nom compte)
    classe       le nom de la classe, tel que dans les inscrits du sujet (« 2nd 5 »)
    debut        JJ/MM/AAAA HH:MM, heure de Paris : le sujet ne s'ouvre pas avant
    fin_creneau  JJ/MM/AAAA HH:MM : la fin de la séance en classe ; le lecteur ne s'en sert pas (notation_tp.py, oui)
    echeance     JJ/MM/AAAA HH:MM : le code ne sert plus après, la copie est rendue à cette heure
    duree        minutes : la durée de l'épreuve, à la place de celle du sujet
    anti_triche  oui ou non
    temps        ecran ou absolu (``noyau.TEMPS``)
    soumission   le numéro du mode de soumission (``noyau.SOUMISSIONS``, 0 à 6)
Les cinq premières colonnes sont celles que ``notation_tp.py`` lisait déjà ; les quatre dernières, ajoutées le 25/10/2026.
Une case illisible n'arrête rien : elle est ignorée (le code vaut pour elle) et dite dans ``Ligne.erreurs``.

Module pur Python, sans réseau : il tourne aussi dans le navigateur (Pyodide), et c'est l'appelant qui lui passe le texte
du fichier, ou ``None`` s'il n'a pas pu le lire. Le lecteur web le lit dans Dropbox (``dropbox.js``, ``racine``), et le
passe à l'accueil ; sans ce texte, ``du_disque`` le cherche là où le client Dropbox du professeur le synchronise
(``DOSSIER``) : dans le navigateur ou chez un élève sans Dropbox, il n'y est pas, et le code vaut seul.
"""

from __future__ import annotations

import csv
import io
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
from typing import NamedTuple

from codes import Code, _decalage_paris
from noyau import SOUMISSIONS, TEMPS

NOM = "echeances.csv"
DOSSIER = Path("/DATA/Dropbox/Applications/SmartTeacherQcm")  # le dossier de l'application, synchronisé chez le professeur
COLONNES = ("sujet", "classe", "debut", "fin_creneau", "echeance", "duree", "anti_triche", "temps", "soumission")
FORMAT = "%d/%m/%Y %H:%M"
DUREE_MAX = 24 * 60  # minutes : au-delà, une faute de frappe (le code, lui, s'arrête à 315)
OUI, NON = ("oui", "o", "vrai", "1", "x"), ("non", "n", "faux", "0")


class Ligne(NamedTuple):
    """Ce que la ligne d'un sujet et d'une classe change au code : ``None`` pour une case vide ou illisible."""
    depart: datetime | None = None  # en UTC, comme ``Code.depart``
    echeance: datetime | None = None
    duree: int | None = None
    anti_triche: bool | None = None
    temps: str | None = None
    soumission: int | None = None
    erreurs: tuple[str, ...] = ()  # les cases ignorées, pourquoi


def instant(texte: str) -> datetime:
    """« JJ/MM/AAAA HH:MM », heure de Paris, en UTC. À l'heure du changement d'octobre, qui se lit deux fois, la première."""
    local = datetime.strptime(texte.strip(), FORMAT).replace(tzinfo=timezone.utc)
    for decalage in (120, 60):
        utc = local - timedelta(minutes=decalage)
        if _decalage_paris(int(utc.timestamp()) // 60) == decalage:
            return utc
    return local - timedelta(minutes=60)  # l'heure sautée en mars : lue comme l'heure d'hiver


def du_disque() -> str | None:
    """Le texte de ``DOSSIER/NOM`` s'il est sur ce disque (la machine du professeur), ``None`` sinon ou s'il ne se lit pas."""
    try:
        return (DOSSIER / NOM).read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError):
        return None


def _nom(texte: str) -> str:
    return PurePosixPath(texte.strip().replace("\\", "/")).name


def trouver(texte: str | None, sujets: set[str], classe: str | None) -> dict[str, str] | None:
    """La ligne brute (colonne → case) du fichier ``texte`` pour l'un des noms ``sujets`` et la ``classe``, ou ``None``.
    La dernière l'emporte si plusieurs conviennent : une ligne ajoutée en bas corrige celle du dessus sans l'effacer."""
    if not texte or classe is None:
        return None
    trouvee, sujets = None, sujets - {""}
    try:
        for ligne in csv.DictReader(io.StringIO(texte.lstrip("﻿")), delimiter=";"):
            if _nom(ligne.get("sujet") or "") in sujets and (ligne.get("classe") or "").strip() == classe.strip():
                trouvee = ligne
    except csv.Error:  # un fichier abîmé (case de plus de 128 ko) : le code vaut seul
        return None
    return trouvee


def lire(ligne: dict[str, str] | None) -> Ligne:
    """Les cases de ``ligne`` (``trouver``), vérifiées une à une."""
    if not ligne:
        return Ligne()
    valeurs, erreurs = {}, []

    def case(colonne, lecture, attendu):
        texte = (ligne.get(colonne) or "").strip()
        if texte:
            try:
                valeurs[colonne] = lecture(texte)
            except (ValueError, OverflowError):  # OverflowError : une année 0001, que strptime lit
                erreurs.append(f"{colonne} « {texte} » ignorée : {attendu}")

    def entier_positif(texte):
        if not texte.isdigit() or not 0 < int(texte) <= DUREE_MAX:
            raise ValueError
        return int(texte)

    def booleen(texte):
        if texte.lower() not in OUI + NON:
            raise ValueError
        return texte.lower() in OUI

    def temps(texte):
        if (texte := texte.lower().replace("é", "e")) not in TEMPS:
            raise ValueError
        return texte

    def soumission(texte):
        if not texte.isdigit() or int(texte) not in SOUMISSIONS:
            raise ValueError
        return int(texte)

    case("debut", instant, "JJ/MM/AAAA HH:MM")
    case("echeance", instant, "JJ/MM/AAAA HH:MM")
    case("duree", entier_positif, f"un nombre de minutes, de 1 à {DUREE_MAX}")
    case("anti_triche", booleen, "oui ou non")
    case("temps", temps, " ou ".join(TEMPS))
    case("soumission", soumission, "un numéro de " + ", ".join(map(str, sorted(SOUMISSIONS))))
    if "debut" in valeurs and "echeance" in valeurs and valeurs["echeance"] <= valeurs["debut"]:
        erreurs.append("echeance ignorée : elle ne vient pas après le début")
        del valeurs["echeance"]
    return Ligne(valeurs.get("debut"), valeurs.get("echeance"), valeurs.get("duree"), valeurs.get("anti_triche"),
                 valeurs.get("temps"), valeurs.get("soumission"), tuple(erreurs))


def appliquer(code: Code, ligne: Ligne) -> Code:
    """``code`` où chaque case remplie de ``ligne`` remplace la valeur qu'il porte (le fichier gagne) ; la clé et la classe,
    qui ouvrent le fichier, restent celles du code."""
    remplace = {champ: valeur for champ, valeur in ligne._asdict().items() if champ != "erreurs" and valeur is not None}
    return code._replace(**remplace)
