"""Le fichier d'échéances du professeur (``echeances.csv``, à la racine de son dossier Dropbox ``SmartTeacherQcm/``) : ce qu'un
code de classe porte (départ, durée, échéance, anti-triche, temps, soumission), écrit en clair, une ligne par sujet et par
classe, qu'il voit et corrige à la main après avoir donné le code ou le lien. Quand le lecteur peut le lire (réseau), le
fichier GAGNE sur le code : une échéance repoussée dans le fichier vaut, même si le lien envoyé porte l'ancienne (décision de
l'utilisateur, 25/10/2026 : « oui, le fichier gagne »). Sans réseau, ou sans ligne pour ce sujet et cette classe, ou pour une
case vide, c'est le code qui vaut : il reste le repli complet.

Format (point-virgule, UTF-8 avec ou sans BOM, comme l'enregistre un tableur) ; seules ``sujet`` et ``classe`` sont exigées,
toute autre colonne peut manquer ou rester vide :
    sujet        le nom du dossier du sujet, ou celui du .qcm sans extension (un chemin : seul son dernier nom compte)
    classe       le nom de la classe, tel que dans les inscrits du sujet (« 2nd 5 »)
    debut        JJ/MM/AAAA HH:MM, heure de Paris : le sujet ne s'ouvre pas avant
    fin_creneau  JJ/MM/AAAA HH:MM : la fin de la séance en classe ; le lecteur ne s'en sert pas (notation_tp.py, oui)
    echeance     JJ/MM/AAAA HH:MM : le code ne sert plus après, la copie est rendue à cette heure
    duree        minutes : la durée de l'épreuve, à la place de celle du sujet
    anti_triche  oui ou non
    temps        ecran ou absolu (``noyau.TEMPS``)
    soumission   le numéro du mode de soumission (``noyau.SOUMISSIONS``, 0 à 6)
Les cinq premières colonnes sont celles que ``notation_tp.py`` lisait déjà ; les quatre dernières, ajoutées le 25/10/2026.
Une case illisible n'arrête rien : elle est ignorée (le code vaut pour elle) et dite dans ``Ligne.erreurs``.

``ajouter`` y écrit la ligne d'un code généré (fenêtre « Déployer », ``deployer_qcm.py``), sur le disque du professeur ;
``changer_echeance`` y recopie la ligne en vigueur avec une autre échéance (rubrique « Échéances en vigueur » de la même
fenêtre, demande de l'utilisateur, 05/11/2026 : « ajoute une interface pour gérer les échéances dans Déployer ») ; plus
largement, ``recopier`` (texte → texte, sans disque) et ``regler`` (sur le disque) y recopient la ligne en vigueur avec une
autre échéance, durée, soumission ou anti-triche : la page d'une classe, vue par le professeur, le fait ainsi pour chaque
sujet (``tableau_eleves.Reglages`` ; l'utilisateur, 05/11/2026 : « avoir des bouton en plus pour chaque sujet déployer, pour
gerer l'échéance, la dure, le mode de soumission, l'anti-triche »).

Module pur Python, sans réseau : il tourne aussi dans le navigateur (Pyodide), et c'est l'appelant qui lui passe le texte
du fichier, ou ``None`` s'il n'a pas pu le lire. Le lecteur web le lit dans Dropbox (``dropbox.js``, ``racine``), et le
passe à l'accueil ; sans ce texte, ``du_disque`` le cherche là où le client Dropbox du professeur le synchronise
(``DOSSIER``) : dans le navigateur ou chez un élève sans Dropbox, il n'y est pas, et le code vaut seul.
"""

from __future__ import annotations

import csv
import io
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
from typing import Callable, NamedTuple

from codes import Code, _decalage_paris
from noyau import SOUMISSIONS, TEMPS

NOM = "echeances.csv"
DOSSIER = Path("/DATA/Dropbox/Applications/SmartTeacherQcm")  # le dossier de l'application, synchronisé chez le professeur
COLONNES = ("sujet", "classe", "debut", "fin_creneau", "echeance", "duree", "anti_triche", "temps", "soumission")
FORMAT = "%d/%m/%Y %H:%M"
DUREE_MAX = 24 * 60  # minutes : au-delà, une faute de frappe (le code, lui, s'arrête à 315)
OUI, NON = ("oui", "o", "vrai", "1", "x"), ("non", "n", "faux", "0")


class Ligne(NamedTuple):
    """Ce que la ligne d'un sujet et d'une classe change au code : ``None`` pour une case vide ou illisible."""
    depart: datetime | None = None  # en UTC, comme ``Code.depart``
    echeance: datetime | None = None
    duree: int | None = None
    anti_triche: bool | None = None
    temps: str | None = None
    soumission: int | None = None
    erreurs: tuple[str, ...] = ()  # les cases ignorées, pourquoi


def instant(texte: str) -> datetime:
    """« JJ/MM/AAAA HH:MM », heure de Paris, en UTC. À l'heure du changement d'octobre, qui se lit deux fois, la première."""
    local = datetime.strptime(texte.strip(), FORMAT).replace(tzinfo=timezone.utc)
    for decalage in (120, 60):
        utc = local - timedelta(minutes=decalage)
        if _decalage_paris(int(utc.timestamp()) // 60) == decalage:
            return utc
    return local - timedelta(minutes=60)  # l'heure sautée en mars : lue comme l'heure d'hiver


def du_disque() -> str | None:
    """Le texte de ``DOSSIER/NOM`` s'il est sur ce disque (la machine du professeur), ``None`` sinon ou s'il ne se lit pas."""
    try:
        return (DOSSIER / NOM).read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError):
        return None


def _nom(texte: str) -> str:
    return PurePosixPath(texte.strip().replace("\\", "/")).name


def trouver(texte: str | None, sujets: set[str], classe: str | None) -> dict[str, str] | None:
    """La ligne brute (colonne → case) du fichier ``texte`` pour l'un des noms ``sujets`` et la ``classe``, ou ``None``.
    La dernière l'emporte si plusieurs conviennent : une ligne ajoutée en bas corrige celle du dessus sans l'effacer."""
    if not texte or classe is None:
        return None
    trouvee, sujets = None, sujets - {""}
    try:
        for ligne in csv.DictReader(io.StringIO(texte.lstrip("﻿")), delimiter=";"):
            if _nom(ligne.get("sujet") or "") in sujets and (ligne.get("classe") or "").strip() == classe.strip():
                trouvee = ligne
    except csv.Error:  # un fichier abîmé (case de plus de 128 ko) : le code vaut seul
        return None
    return trouvee


def lire(ligne: dict[str, str] | None) -> Ligne:
    """Les cases de ``ligne`` (``trouver``), vérifiées une à une."""
    if not ligne:
        return Ligne()
    valeurs, erreurs = {}, []

    def case(colonne, lecture, attendu):
        texte = (ligne.get(colonne) or "").strip()
        if texte:
            try:
                valeurs[colonne] = lecture(texte)
            except (ValueError, OverflowError):  # OverflowError : une année 0001, que strptime lit
                erreurs.append(f"{colonne} « {texte} » ignorée : {attendu}")

    def entier_positif(texte):
        if not texte.isdigit() or not 0 < int(texte) <= DUREE_MAX:
            raise ValueError
        return int(texte)

    def booleen(texte):
        if texte.lower() not in OUI + NON:
            raise ValueError
        return texte.lower() in OUI

    def temps(texte):
        if (texte := texte.lower().replace("é", "e")) not in TEMPS:
            raise ValueError
        return texte

    def soumission(texte):
        if not texte.isdigit() or int(texte) not in SOUMISSIONS:
            raise ValueError
        return int(texte)

    case("debut", instant, "JJ/MM/AAAA HH:MM")
    case("echeance", instant, "JJ/MM/AAAA HH:MM")
    case("duree", entier_positif, f"un nombre de minutes, de 1 à {DUREE_MAX}")
    case("anti_triche", booleen, "oui ou non")
    case("temps", temps, " ou ".join(TEMPS))
    case("soumission", soumission, "un numéro de " + ", ".join(map(str, sorted(SOUMISSIONS))))
    if "debut" in valeurs and "echeance" in valeurs and valeurs["echeance"] <= valeurs["debut"]:
        erreurs.append("echeance ignorée : elle ne vient pas après le début")
        del valeurs["echeance"]
    return Ligne(valeurs.get("debut"), valeurs.get("echeance"), valeurs.get("duree"), valeurs.get("anti_triche"),
                 valeurs.get("temps"), valeurs.get("soumission"), tuple(erreurs))


def en_texte(date: datetime | None) -> str:
    """L'inverse d'``instant`` : ``date`` (sans fuseau : celui de cette machine) en « JJ/MM/AAAA HH:MM », heure de Paris ; vide sans date."""
    if date is None:
        return ""
    utc = date.astimezone(timezone.utc)
    return (utc + timedelta(minutes=_decalage_paris(int(utc.timestamp()) // 60))).strftime(FORMAT)


def ajouter(sujet: str, classe: str, debut: datetime | None = None, fin_creneau: datetime | None = None,
            echeance: datetime | None = None, duree: int | None = None, anti_triche: bool | None = None,
            temps: str | None = None, soumission: int | None = None) -> bool:
    """Ajoute en bas de ``DOSSIER/NOM`` la ligne de ``sujet`` et ``classe``, qui l'emporte sur celles du dessus (``trouver``), ce
    que le lecteur et le tableau des classes liront ; vrai si une ligne a été écrite, faux si la dernière de ce sujet et de
    cette classe dit déjà la même chose. Jamais de réécriture des lignes : le fichier est au professeur, qui le tient à la
    main ; seul un en-tête auquel manquent des ``COLONNES`` est complété (``completer_entete``). Fichier absent : créé avec
    toutes les colonnes. Un réglage ``None`` laisse sa case vide. ``ValueError`` : un en-tête illisible ou sans ``sujet`` ni
    ``classe``, rien d'écrit. « Générer » (fenêtre « Déployer ») y écrit tout ce que porte le code généré : l'utilisateur,
    06/11/2026, « oui » à « Générer écrit aussi la soumission, l'anti-triche, le temps dans echeances.csv »."""
    return _ajouter_ligne({"sujet": sujet, "classe": classe, "debut": en_texte(debut), "fin_creneau": en_texte(fin_creneau),
                           "echeance": en_texte(echeance), "duree": "" if duree is None else str(duree),
                           "anti_triche": "" if anti_triche is None else "oui" if anti_triche else "non",
                           "temps": temps or "", "soumission": "" if soumission is None else str(soumission)})


def lignes_du_sujet(texte: str | None, sujets: set[str], classes: list[str]) -> dict[str, dict[str, str]]:
    """Pour chaque classe de ``classes`` qui en a une, la ligne brute en vigueur (``trouver``) de l'un des ``sujets``."""
    return {classe: ligne for classe in classes if (ligne := trouver(texte, sujets, classe))}


def changer_echeance(sujet: str, classe: str, echeance: datetime) -> bool:
    """``regler`` pour l'échéance seule, mise à ``echeance`` (sans fuseau : celui de cette machine) : la fenêtre « Déployer »
    repousse ou avance ainsi un sujet déjà donné."""
    return regler(sujet, classe, {"echeance": en_texte(echeance)})


def regler(sujet: str, classe: str, changements: dict[str, str]) -> bool:
    """``recopier`` sur le disque : la ligne en vigueur de ``sujet`` et ``classe``, corrigée de ``changements``, ajoutée en bas de
    ``DOSSIER/NOM`` sans réécrire le reste. Faux si elle disait déjà tout cela. ``ValueError`` comme ``recopier`` ; rien d'écrit."""
    texte = du_disque()
    return _ajouter_ligne(_recopiee(texte and completer_entete(texte), sujet, classe, changements))


def recopier(texte: str | None, sujet: str, classe: str, changements: dict[str, str]) -> str | None:
    """Le texte du fichier ``texte`` complété, en bas, de la ligne en vigueur de ``sujet`` et ``classe`` recopiée case pour case,
    avec ``changements`` (colonne → case : « 50 » pour ``duree``, « oui » pour ``anti_triche``, « 3 » pour ``soumission``,
    ``en_texte`` d'une date pour ``echeance`` ; vide : la valeur du code) : on ne réécrit jamais au-dessus, et une case écrite à
    la main reste. ``None`` si cette ligne disait déjà tout cela. Fonction PURE, sans disque : la page de la classe en ligne
    écrit son résultat dans Dropbox (``web/pyqt6/pont_tableau.py``), ``regler`` le fait sur le disque du professeur.
    ``ValueError`` : aucune ligne pour ce sujet et cette classe, une colonne absente de l'en-tête, une case changée que
    ``lire`` refuserait (durée hors de 1 à ``DUREE_MAX``, soumission hors de ``SOUMISSIONS``, échéance avant le début…), ou
    un en-tête illisible (comme ``ajouter``). Un en-tête auquel manquent des ``COLONNES`` est complété (``completer_entete``) :
    le texte rendu change alors sa première ligne, les autres restent."""
    texte = texte and completer_entete(texte)
    return _a_ajouter(texte or "", _recopiee(texte, sujet, classe, changements))


def _recopiee(texte: str | None, sujet: str, classe: str, changements: dict[str, str]) -> dict[str, str]:
    """La ligne en vigueur de ``sujet`` et ``classe`` dans ``texte`` (colonne → case), ``changements`` mis à leur place
    (``ValueError`` : voir ``recopier``)."""
    ligne = trouver(texte, {_nom(sujet)}, classe)
    if ligne is None:
        raise ValueError(f"{NOM} : aucune ligne pour {_nom(sujet)} en {classe}")
    valeurs = {colonne.strip(): (case or "").strip() for colonne, case in ligne.items() if colonne is not None}
    for colonne, case in changements.items():
        if colonne not in valeurs or colonne in ("sujet", "classe"):
            raise ValueError(f"{NOM} : la première ligne n'a pas de colonne {colonne}")
        valeurs[colonne] = case.strip()
    refus = [e.replace(" ignorée", " refusée", 1) for e in lire(valeurs).erreurs if e.split(" ", 1)[0] in changements]
    if refus:
        raise ValueError(" ; ".join(refus))
    return valeurs


def _a_ajouter(texte: str, valeurs: dict[str, str]) -> str | None:
    """Le texte ``texte`` complété, au bout, de ``valeurs`` (colonne → case), dans ses colonnes et avec ses fins de ligne, son
    BOM gardé, l'en-tête écrit si le fichier est vide, complété des ``COLONNES`` qui lui manquent sinon (``completer_entete``) ;
    ``None`` si la dernière ligne du même sujet et de la même classe dit déjà la même chose."""
    texte = completer_entete(texte)
    corps = texte.lstrip("\ufeff")
    try:
        colonnes = next(csv.reader(io.StringIO(corps), delimiter=";"), None)
    except csv.Error as erreur:  # un en-tête abîmé (case de plus de 128 ko)
        raise ValueError(f"{NOM} : la première ligne ne se lit pas ({erreur})") from erreur
    if colonnes is None:
        colonnes = list(COLONNES)
        debut_fichier = ";".join(colonnes) + "\n"
    else:
        colonnes = [c.strip() for c in colonnes]
        debut_fichier = "" if corps.endswith(("\n", "\r")) else "\n"
    derniere = trouver(corps, {_nom(valeurs["sujet"])}, valeurs["classe"])
    if derniere and all((derniere.get(c) or "").strip() == valeurs.get(c, "") for c in colonnes if c in valeurs and c != "sujet"):
        return None
    fin = "\r\n" if "\r\n" in corps else "\n"
    return texte + debut_fichier.replace("\n", fin) + ";".join(valeurs.get(c, "") for c in colonnes) + fin


def completer_entete(texte: str) -> str:
    """``texte`` dont la première ligne reçoit, au bout, les ``COLONNES`` qui lui manquent ; le BOM, les fins de ligne et toutes
    les autres lignes restent tels quels : une ligne écrite avant l'ajout, plus courte que l'en-tête, se lit avec des cases
    vides (``csv.DictReader``). Texte vide : rendu tel quel. ``ValueError`` : un en-tête illisible ou sans ``sujet`` ni
    ``classe``. Demande de l'utilisateur, 06/11/2026 : les colonnes des réglages ajoutées à un fichier qui ne les a pas."""
    bom = "\ufeff" if texte.startswith("\ufeff") else ""
    corps = texte[len(bom):]
    if not corps.strip():
        return texte
    coupure = len(corps)
    for fin in ("\r\n", "\n", "\r"):
        if (i := corps.find(fin)) != -1 and i < coupure:
            coupure = i
    entete = corps[:coupure]
    try:
        colonnes = [c.strip() for c in next(csv.reader([entete], delimiter=";"), [])]
    except csv.Error as erreur:
        raise ValueError(f"{NOM} : la première ligne ne se lit pas ({erreur})") from erreur
    if not {"sujet", "classe"} <= set(colonnes):
        raise ValueError(f"{NOM} : la première ligne n'a pas les colonnes sujet et classe")
    manquantes = [c for c in COLONNES if c not in colonnes]
    if not manquantes:
        return texte
    return bom + entete + "".join(";" + c for c in manquantes) + corps[coupure:]


REGLAGES = ("echeance", "duree", "anti_triche", "temps", "soumission")  # ce qu'un code porte et que la page d'une classe règle


def en_vigueur(texte: str | None) -> list[dict[str, str]]:
    """Les lignes brutes en vigueur de ``texte`` : pour chaque sujet (son dernier nom) et chaque classe, la dernière, dans
    l'ordre où chacune apparaît pour la première fois ; ``[]`` sans texte ou pour un fichier abîmé."""
    if not texte:
        return []
    lignes: dict[tuple[str, str], dict[str, str]] = {}
    try:
        for ligne in csv.DictReader(io.StringIO(texte.lstrip("\ufeff")), delimiter=";"):
            cle = (_nom(ligne.get("sujet") or ""), (ligne.get("classe") or "").strip())
            if all(cle):
                lignes[cle] = ligne
    except csv.Error:
        return []
    return list(lignes.values())


def manquantes(ligne: dict[str, str] | None) -> list[str]:
    """Les ``REGLAGES`` que ``ligne`` (brute) ne donne pas : case vide, absente ou illisible (``lire``)."""
    lue = lire(ligne)._asdict()
    return [c for c in REGLAGES if lue[c] is None]


def completer(texte: str | None, valeurs: Callable[[dict[str, str]], dict[str, str]]) -> str | None:
    """Le texte ``texte`` où chaque ligne en vigueur (``en_vigueur``) à laquelle manque un réglage (``manquantes``) est recopiée
    en bas, ses cases manquantes remplies par ``valeurs(ligne)`` (colonne → case, comme ``recopier`` ; une case vide reste
    vide : une échéance vide est « sans échéance ») ; ``None`` s'il n'y a rien à ajouter. Les lignes déjà écrites ne changent
    pas, l'en-tête est complété (``completer_entete``). Fonction PURE : ``tableau_eleves.py completer`` la passe sur le fichier
    du professeur, et lui seul lance l'écriture. Demande de l'utilisateur, 06/11/2026 : « il faut que l'interface puisse
    retrouver toutes ces informations dans echeances.csv »."""
    if not texte:
        return None
    nouveau = completer_entete(texte)
    for ligne in en_vigueur(nouveau):
        if not (vides := manquantes(ligne)):
            continue
        remplies = valeurs(ligne)
        changements = {c: remplies[c] for c in vides if remplies.get(c)}
        if not changements:
            continue
        ajoute = _a_ajouter(nouveau, _recopiee(nouveau, ligne["sujet"], ligne["classe"], changements))
        nouveau = nouveau if ajoute is None else ajoute
    return None if nouveau == texte else nouveau


def ecrire(ancien: str, nouveau: str, chemin: Path | None = None) -> None:
    """``nouveau`` à la place d'``ancien`` dans ``chemin`` (par défaut ``DOSSIER/NOM``) : en ajout seul s'il le prolonge, sinon
    (en-tête complété) par un fichier voisin renommé par-dessus, pour qu'un client Dropbox ne voie jamais un fichier à
    moitié écrit."""
    chemin = chemin or DOSSIER / NOM
    if nouveau.startswith(ancien) and chemin.exists():
        with open(chemin, "a", encoding="utf-8", newline="") as fichier:
            fichier.write(nouveau[len(ancien):])
        return
    voisin = chemin.with_name(f".{chemin.name}.{os.getpid()}")
    with open(voisin, "w", encoding="utf-8", newline="") as fichier:
        fichier.write(nouveau)
    os.replace(voisin, chemin)


def _ajouter_ligne(valeurs: dict[str, str]) -> bool:
    """``valeurs`` (colonne → case) en bas de ``DOSSIER/NOM`` (``_a_ajouter``), sans réécrire une ligne : vrai si une ligne a
    été écrite. Le BOM d'un fichier enregistré par un tableur est gardé."""
    chemin = DOSSIER / NOM
    try:
        with open(chemin, encoding="utf-8", newline="") as fichier:
            texte = fichier.read()
    except FileNotFoundError:
        texte = ""
    nouveau = _a_ajouter(texte, valeurs)
    if nouveau is None:
        return False
    ecrire(texte, nouveau, chemin)
    return True


def appliquer(code: Code, ligne: Ligne) -> Code:
    """``code`` où chaque case remplie de ``ligne`` remplace la valeur qu'il porte (le fichier gagne) ; la clé et la classe,
    qui ouvrent le fichier, restent celles du code."""
    remplace = {champ: valeur for champ, valeur in ligne._asdict().items() if champ != "erreurs" and valeur is not None}
    return code._replace(**remplace)
