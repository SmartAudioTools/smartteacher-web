"""Le pont de la page PyQt6-WASM (page.html) : le lecteur natif tel quel dans le navigateur.

Le sujet arrive en octets ; l'élève passe par la boîte d'accueil du lecteur natif (``lecteur.Accueil`` : nom, prénom, code de
déverrouillage s'il en faut un), dans le canevas, puis la fenêtre de ``lecteur.py`` le remplit. La copie est le fichier que
``Lecteur.enregistrer`` réécrit : du texte, chiffrée comprise (l'armure ASCII d'age, ``modele.sauver``), rangée dans le
navigateur à chaque enregistrement (``qtpy6.web.stockage``, sous le titre et le nom, avec sa date) et reprise si la page se
recharge. Quand la page est reliée au professeur (son dossier Dropbox : ``DROPBOX`` de ``page.html``, ``dropbox.js``), la copie part aussi chez
lui, toutes les minutes tant que l'épreuve dure et cinq secondes après sa fin, et c'est la plus récente des deux copies,
celle du navigateur ou celle du professeur, qui est reprise, sur n'importe quel appareil ; sans professeur, elle est offerte
au téléchargement quand l'épreuve est finie.

Chez le professeur, la copie est le seul fichier (plus de fiche à côté, 27/09/2026) : ``codes.chemin_copie`` la range dans
le dossier du sujet, par classe et sujet, Dropbox la date (``server_modified``, l'heure de son serveur, pas celle de l'élève), et la garde du
mot de passe se vérifie en la déchiffrant (``Paquet.empreinte``) — sauf quand elle est encore celle que cette page a
déposée ou reprise, reconnue à sa date."""

import asyncio
import base64
import json
import math
import re
import time
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs

import bilans_widget
import cle_jugement
import codes
import echeances
import horloge
import noyau
from js import document, window  # Pyodide : le titre de l'onglet, la sortie de la page (surveiller)
from pyodide.ffi import create_proxy, jsnull
from lecteur import Lecteur, a_enchainer, accueillir, depart_du_bilan, emplacements_du_cours, relire_depart, section_de
from modele import GardeCopie, JugementModele, application, charger
from qtpy6.web import stockage, tactile, travailleur

PARENTS = 8  # les dossiers parents du sujet où chercher un cours sous son nom (emplacements_du_cours)
CHEMIN = "/sujet.qcm"  # le sujet, puis la copie que le lecteur y réécrit
BILAN = "/bilan" + bilans_widget.EXTENSION  # le bilan d'un élève, quand c'est lui que la page a reçu (``ouvrir_bilan``)
AUTRE = "/distante.qcm"  # une copie déposée chez le professeur, déchiffrée pour lire son empreinte
PROTEGEE = "{} a protégé sa copie par son mot de passe : sans lui, ce nom n'est pas accepté."
REMPLACEE = "Votre copie a changé chez le professeur depuis l'ouverture de cette page : rechargez la page pour reprendre la copie à jour."
CADENCE = 60, 5  # secondes entre deux envois au professeur : pendant l'épreuve, après sa fin
APP = application()  # charge aussi les polices de lecteur.zip
tactile.activer_au_doigt(APP)  # téléphone, tablette, portable tactile ; sinon au premier doigt posé, sur l'accueil
GardeCopie(APP)
PERIMEE = "Une nouvelle version de ce sujet a été mise en ligne : rechargez la page pour reprendre votre copie à jour."
SUJET = ACCUEIL = FENETRE = PAQUET = MOT = PAGE = ENVOIS = SOURCE = None  # SOURCE : chemin du sujet chez le professeur
IDENTITE = "smartteacher-qt|identite"  # nom, prénom (et secret de son mot de passe) du dernier élève entré sur ce navigateur
PROFESSEUR = "smartteacher-qt|professeur"  # le mot de passe professeur tapé une fois dans ce navigateur : il ouvre tout sujet
EMPREINTE = ""  # celle du mot de passe que l'élève a donné à l'accueil (sa publique, codes.publique) : elle garde sa copie chez le professeur
SUIVI = None  # (sujets, classe) : la ligne du fichier d'échéances que le lecteur relit pendant l'épreuve (``Lecteur.relire``)
CLASSE = LIMITE = None  # la classe du code donné à l'accueil (None : sans classe) et sa date limite (UTC), ou None
ENCHAINER = False  # la copie s'ouvre par l'accueil (``montrer``) : un « Réviser » déjà rendu passe à la série suivante (``afficher``)
REPRIS = 1  # l'essai le plus récent rangé dans ce navigateur à l'ouverture (``dernier_essai``) : sa copie est reprise
DEPOSEE = None  # la date (ms, Dropbox) de la dernière copie que cette page a déposée ou reprise : tant que c'est elle, elle est à l'élève
COURS_EN_LECTURE = False  # une lecture des PDF du cours est en route (``lire_les_cours``)
COURS_INTROUVABLES = set()  # les PDF du cours que le dossier du professeur dit ne pas avoir, à la dernière lecture
A_ENVOYER = False  # la copie a changé depuis le dernier envoi au professeur
DERNIER_ENVOI = float("-inf")  # time.monotonic() du début du dernier envoi : le premier part dès la première copie
PRESENCE, DERNIERE_PRESENCE = None, float("-inf")  # le dernier témoin de présence reçu par le professeur (``presence``), et l'heure de l'essai


ENFANT = ("console_enfant.py", "bac_a_sable.py", "verifier.py", "pyxel_factice.py")  # tout ce que les sous-processus
# importent du dossier du lecteur (console_enfant → bac_a_sable + verifier ; verifier → bac_a_sable + pyxel_factice par
# chemin et se relance en --enfant ; ses imports de codes, modele, exporter_eleve sont côté parent seulement)
PAQUETS_ENFANT = ("complexity_profiler",)  # les paquets du zip que console_enfant importe (le profileur de Σ)


def configurer(pyodide, roues=()):
    """Avant tout : les sous-processus des questions code (console_enfant.py de leur console, verifier.py de leur correction)
    tournent tels quels dans des Web Workers sous le Pyodide à ``pyodide`` (URL relative à la page, ou absolue — le même
    Pyodide-Qt que la page depuis le 05/10/2026 : un seul téléchargement) : ``QProcess`` et ``subprocess.run`` de qtpy6.web.
    ``roues`` : les .whl de ce qui manque à cette distribution (sqlite3), chargés au premier import (travailleur).
    Le filtre ne copie dans le worker, du dossier du lecteur (sous-dossiers compris : polices, sujet, copie), que les
    fichiers ``ENFANT`` et les paquets ``PAQUETS_ENFANT`` ; tout le reste — le dossier temporaire où le parent dépose base sql et fichiers de la question —
    passe entier. Sans lui, chaque premier ▶ zippait ~6 Mo (mortel sur téléphone) pour ~100 Ko utiles."""
    dossier = str(Path(noyau.__file__).resolve().parent) + "/"
    utiles = {dossier + nom for nom in ENFANT}
    paquets = tuple(dossier + nom + "/" for nom in PAQUETS_ENFANT)  # sans leurs fichiers, un paquet vide (espace de noms)
    travailleur.configurer(pyodide, roues,
                           filtre=lambda chemin: (not chemin.startswith(dossier) or chemin in utiles
                                                  or chemin.startswith(paquets)))


def service(nom):
    """Ce que la page a fourni sous ce nom (``demarrer``), ou None."""
    return getattr(PAGE, nom, None) if PAGE is not None else None


def cle(essai: int | None = None) -> str:
    """La place de la copie dans le navigateur : le même élève qui rouvre le même sujet la retrouve, au même essai
    (``essai_courant``, ou ``essai``)."""
    return f"smartteacher-qt|{PAQUET.nom or PAQUET.titre}|{PAQUET.eleve.lower()}{codes.essai(essai or essai_courant())}"


def cle_rendue(nom: str, eleve: str) -> str:
    """La place de la marque « copie rendue » de ce sujet par cet élève, quel qu'en soit l'essai : posée par ``ranger``, lue
    par la page d'accueil (``pont_tableau.commencee``)."""
    return f"smartteacher-qt|{nom}|{eleve.lower()}|rendue"


def cle_bonus(nom: str, eleve: str) -> str:
    """La place de la marque « TP aux questions obligatoires toutes closes, des bonus encore ouverts » (``noyau.BONUS``) :
    posée par ``ranger``, lue par ``pont_tableau.commencee``, qui le met dans le cadre « Bonus à finir » (W749)."""
    return f"smartteacher-qt|{nom}|{eleve.lower()}|bonus"


def essai_courant() -> int:
    """L'essai de la copie : celui de ``PAQUET``, ou l'essai plus récent repris à l'ouverture (``REPRIS``) tant que ``PAQUET``
    est encore le sujet (essai 1) ; sa copie lue, ``PAQUET`` a son numéro."""
    return max(PAQUET.essai, REPRIS)


def dernier_essai() -> int:
    """À l'ouverture d'une révision à essais : le plus récent rangé dans ce navigateur (« (Nème essai) », clés ``cle``), que
    la page reprend au lieu du premier (décision du professeur, 07/11/2026). Les essais se suivent : le premier absent arrête."""
    essai = PAQUET.essai
    while PAQUET.nouvel_essai and stockage.lire(cle(essai + 1)):
        essai += 1
    return essai


def ouvrir_bilan(contenu: bytes, nom: str) -> str:
    """Le bilan d'un élève (``bilans_widget``, ``bilans.py fichiers``, ``nom`` : son chemin chez le professeur) au lieu d'un
    sujet, plein canevas : sans rien demander s'il est en clair ou que le secret retenu par ce navigateur l'ouvre, sinon par le
    mot de passe. Ni copie, ni envoi au professeur. Rend ``"accueil"`` ou ``"epreuve"``."""
    global ACCUEIL
    Path(BILAN).write_bytes(contenu)
    etat = "accueil"

    def ouvert(zone):
        global FENETRE
        nonlocal etat
        FENETRE, etat = zone, "epreuve"
        document.title = zone.windowTitle()
        zone.showFullScreen()
        signaler("epreuve")

    identites = service("identites")
    identites = codes.identites_lire(None if identites in (None, jsnull) else str(identites.texte))
    try:
        secret = base64.b64decode(json.loads(stockage.lire(IDENTITE) or "[]")[2])
    except (ValueError, TypeError, IndexError):
        secret = None
    # le mot de passe professeur retenu ici l'a été après avoir ouvert un sujet (``retenir_identite``) : il ouvre tout bilan
    ACCUEIL = bilans_widget.montrer(BILAN, ouvert, bilans_widget.eleve_du_fichier(nom, identites), identites, secret,
                                    professeur=bool(stockage.lire(PROFESSEUR)))
    if ACCUEIL is not None:
        signaler("accueil")
    return etat


async def demarrer(contenu: Any, eleve: str = "", page: Any = None, jeton: str = "", nom: str = "") -> str:
    """Le ``.qcm`` (octets) : l'accueil, puis l'épreuve plein canevas. ``eleve`` : « Nom Prénom » déjà connu (la sonde,
    ``?eleve=``), l'accueil est sauté si le sujet s'ouvre sans code. ``jeton`` : le code de la classe tel que le lien le
    porte (``?code=``, ``codes.jeton``), déjà dans l'accueil : l'élève n'a que son nom à taper. ``page`` : ce que la page
    offre, un objet JS dont chaque membre est facultatif :
        lien                      l'élément <a> qui reçoit la copie à télécharger (sans lui, le téléchargement part tout seul)
        etat(e)                   prévenue de ce qui est à l'écran : "accueil", puis "epreuve"
        statut(texte, erreur)     une ligne pour l'élève quand sa copie est en échec (vide : rien à dire)
        lire(chemin)              Promise du fichier ``chemin`` du dossier du professeur, {copie (texte), date (ms)}, ou null
        ecrire(chemin, copie)     Promise de la date (ms) du fichier écrit ; sa présence fait partir la copie chez le
                                  professeur plutôt qu'au téléchargement
        presence(chemin, texte)   Promise : le témoin de présence ``texte`` (JSON) écrit à ``chemin`` (….etat.json), que le plan de
                                  classe du professeur lit sur son disque ; absente, aucun témoin n'est envoyé
        journal(chemin, texte)    Promise : la boîte noire d'une visite qui a gelé (….journal.txt), à côté de la copie
        erreurs_lire()            Promise du magasin d'erreurs types de la classe, {texte, rev}, ou null s'il n'existe pas encore
        erreurs_ecrire(texte, rev)  Promise de {rev}, ou null si le magasin a changé depuis ``rev`` (conflit) ; avec ``erreurs_lire``,
                                  fait partager à la classe les erreurs types de la correction automatique (``MagasinDropbox``)
        deplacer(de, vers)        Promise : ``de`` renommé ``vers`` (un numéro ajouté si ``vers`` existe), rien s'il n'existe pas
        cours(chemin)             Promise des octets (Uint8Array) d'un PDF du cours, ``chemin`` depuis le dossier du sujet
                                  (``Paquet.cours``), ou null
        echeances                 le texte du fichier d'échéances du professeur (``dropbox.js``, ``racine``), lu avant :
                                  il gagne sur le code (``lecteur.Accueil``) ; null ou absent (réseau, fichier), le code vaut
        relire_echeances()        Promise du même texte, relu pendant l'épreuve (``lecteur.Lecteur.relire``), ou null
        identites                 {texte, rev} du fichier d'empreintes (``codes.IDENTITES``, ``dropbox.js``), lu avant, ou null
        identites_lire()          Promise du même, relu avant d'y déposer l'empreinte d'une première visite
        identites_ecrire(texte, rev)  Promise de {rev}, ou null si le fichier a changé depuis ``rev`` (``deposer_identite``)
        amenagements              le texte de la table des aménagements que le lecteur applique (``amenagements_lecteur``,
                                  ``dropbox.js``, ``racine``), lu avant, ou null : aucun élève aménagé
        jugement                  le texte du fichier de la clé du modèle (``cle_jugement``), lu avant, ou null : celle du sujet
    ``nom`` : le nom du fichier reçu ; un bilan d'élève (``bilans_widget.EXTENSION``) s'ouvre par ``ouvrir_bilan``. Son
    chemin dans le dossier du professeur donne aussi au sujet le nom que cherche le fichier d'échéances.
    Rend ``"accueil"`` ou ``"epreuve"`` : ce qui est à l'écran, ou va l'être dès la réponse du professeur.
    Coroutine : l'heure en ligne est attendue ici, par un futur, avant l'accueil qui juge la date d'un code ; le
    ``QEventLoop.exec`` de ``horloge.demarrer`` ne bloque pas là où JSPI manque (6 boîtes noires « appelé hors d'un
    slot », W744) et la date était jugée sur l'horloge du PC (W766)."""
    global SUJET, ACCUEIL, PAGE, ENVOIS, SOURCE
    heure = asyncio.get_event_loop().create_future()
    if horloge._essayer(lambda: heure.done() or heure.set_result(None)):
        await heure  # au pire ``horloge.DELAI`` par serveur, hors ligne ; ``horloge.demarrer`` n'aura plus rien à attendre
    # un Uint8Array de la page : ``to_bytes`` le copie d'un bloc, ``bytes`` octet par octet (252 ms pour les 1,2 Mo de
    # python_tp, 02/10/2026)
    SUJET, PAGE, SOURCE = contenu.to_bytes() if hasattr(contenu, "to_bytes") else bytes(contenu), page, nom or None
    bilans_widget.ETATS_LOCAUX = etats_locaux  # le bilan lu (un Réviser composé dessus) compte les révisions d'ici
    if nom.endswith(bilans_widget.EXTENSION):
        return ouvrir_bilan(SUJET, nom)
    Path(CHEMIN).write_bytes(SUJET)
    if service("erreurs_lire") and service("erreurs_ecrire"):
        JugementModele.magasin = MagasinDropbox()  # réponses ouvertes et programmes faux (``modele.JugementModele``)
    if ENVOIS is None and service("ecrire"):
        ENVOIS = asyncio.ensure_future(envoyer_regulierement())
    texte, identites = service("echeances"), service("identites")
    # sans le fichier d'empreintes (pas de Dropbox, réseau), chaque visite est une première visite : rien ne se dépose
    identites = codes.identites_lire(None if identites in (None, jsnull) else str(identites.texte))
    # la table des aménagements de la page (``amenagements_lecteur``) ; absente (réseau, fichier), aucun élève n'est aménagé
    amenagements = service("amenagements")
    # la clé du modèle du fichier commun, qui prime sur celle du sujet et de la copie reprise (``cle_jugement``, W782)
    noyau.JUGEMENT_COMMUN = cle_jugement.lire(None if (j := service("jugement")) in (None, jsnull) else str(j))
    # un « Réviser » ouvert par le bouton d'une section de la page de la classe : cette section seule (``?section=``, W754)
    section = section_de((parse_qs(str(document.location.search).lstrip("?")).get("section") or [""])[0])
    ACCUEIL = accueillir(CHEMIN, montrer, codes.phrase_du_jeton(jeton), eleve,
                         echeances_signe(None if texte in (None, jsnull) else texte), nom or None, identites,
                         "" if amenagements in (None, jsnull) else str(amenagements), section)
    if ACCUEIL:
        preremplir()
    if ACCUEIL and ACCUEIL.isVisible():  # pas le professeur entré par son mot de passe retenu (``preremplir``)
        signaler("accueil")
        return "accueil"
    return "epreuve"


class MagasinDropbox:
    """``JugementModele.magasin`` : le fichier d'erreurs types que la classe partage chez le professeur. Ce que dit le crochet
    est asynchrone (le rappel vient plus tard) ; un échec réseau est dit au rappel comme une absence ou un conflit, la correction
    continue sans (l'erreur n'est alors pas partagée, elle reste dans la copie)."""

    def lire(self, rappel):
        """``rappel(texte, rev)`` : le magasin, ou ``(None, None)`` s'il n'existe pas ou est injoignable."""
        asyncio.ensure_future(self._lire(rappel))

    async def _lire(self, rappel):
        try:
            trouve = await service("erreurs_lire")()
            texte, rev = (None, None) if trouve in (None, jsnull) else (str(trouve.texte), str(trouve.rev))
        except Exception as erreur:  # noqa: BLE001 - réseau, quota, jeton : la correction se passe du partage
            print(f"erreurs partagées illisibles ({erreur})")
            texte = rev = None
        rappel(texte, rev)

    def ecrire(self, texte, rev, rappel):
        """``rappel(ok)`` : faux si le magasin a changé depuis ``rev`` (conflit), ou si l'écriture a échoué."""
        asyncio.ensure_future(self._ecrire(texte, rev, rappel))

    async def _ecrire(self, texte, rev, rappel):
        try:
            ok = await service("erreurs_ecrire")(texte, rev) not in (None, jsnull)
        except Exception as erreur:  # noqa: BLE001
            print(f"erreurs partagées non écrites ({erreur})")
            ok = False
        rappel(ok)


def montrer(paquet, mot):
    """Après l'accueil : la copie la plus récente, s'il y en a une, reprend la place du sujet, et la fenêtre du lecteur remplit
    le canevas. L'accueil appelle sans attendre de retour ; la copie du professeur, elle, s'attend."""
    global PAQUET, MOT, EMPREINTE, CLASSE, LIMITE, SUIVI, REPRIS, ENCHAINER
    PAQUET, MOT, ENCHAINER = paquet, mot, True
    REPRIS = dernier_essai()
    paquet = essai_de_la_section()
    SUIVI = vars(paquet).get("suivi_echeances")  # posé par l'accueil sur ce paquet seul : la copie reprise, l'essai suivant l'ont par ``afficher``
    if paquet.anti_triche and not maitre():  # tout de suite, pendant que le clic de l'accueil l'autorise ; afficher peut attendre le professeur
        agrandir()
    # posées par l'accueil (``Accueil.nommer``), même sauté : l'élève nommé par le lien, sur un code sans classe
    EMPREINTE, LIMITE, CLASSE = paquet.empreinte, paquet.limite, ACCUEIL and ACCUEIL.classe
    retenir_identite()
    if paquet.cours and service("cours"):
        lire_les_cours()
    if relie():
        asyncio.ensure_future(reprendre_puis_afficher())
    else:
        afficher(locale()[0])


def cle_du_code():
    """Où le navigateur garde le code venu du lien pour ce sujet : sous le sel du fichier distribué, que ses redépôts gardent
    (``exporter_eleve.cle_neuve``), et non son empreinte, qui change à chacun et perdait le code."""
    return f"smartteacher-qt|code|{codes.sel_du_fichier(SUJET)}"


def preremplir():
    """L'accueil rempli de ce que ce navigateur a retenu (``retenir_identite``) : nom et prénom du dernier élève, le code du
    sujet d'un lien déjà suivi, pour qu'un lien sans code rouvre encore le sujet. Rien ne commence seul pour un élève : il relit et valide (un poste partagé passe d'un élève à
    l'autre). Le mot de passe de l'élève n'est jamais retenu, seul son secret. Le mot de passe
    professeur, s'il a été tapé ici, passe avant tout : le professeur entre sous son nom sans voir l'accueil (l'utilisateur,
    02/10/2026 : « réouvert le lien, et la fenetre de login s'affiche toujours ») ; sans anti-triche pour lui, aucun clic
    n'est dû au plein écran."""
    mot = stockage.lire(PROFESSEUR)
    if mot and not ACCUEIL.maitre and ACCUEIL.professeur(mot):
        ACCUEIL.commencer()
        return
    try:
        nom, prenom, *secret = json.loads(stockage.lire(IDENTITE) or '["", ""]')
    except ValueError:
        nom, prenom, secret = "", "", []
    for champ, texte in ((ACCUEIL.nom, nom), (ACCUEIL.prenom, prenom)):
        if not champ.text().strip():
            champ.setText(texte)
    ACCUEIL.oublier = lambda: stockage.effacer(IDENTITE)
    if secret:  # entré par son mot de passe : il n'a plus à le taper ici
        ACCUEIL.garder((nom, prenom, base64.b64decode(secret[0])))
    code = stockage.lire(cle_du_code())
    if code and ACCUEIL.paquet is None and not ACCUEIL.code:  # un code du lien, même refusé (pas encore l'heure), passe avant
        ACCUEIL.code = code
        ACCUEIL.ouvrir(code)
    ACCUEIL.focaliser()


def retenir_identite():
    """Après l'accueil : nom et prénom tapés, et le code du lien, retenus pour la prochaine
    ouverture dans ce navigateur (``preremplir``). Pour le professeur, son mot de passe (l'utilisateur, 02/10/2026 : « je ne
    le taperais jamais sur l'appareil d'un élève ») : son nom, que le mot de passe pose, ne servirait à rien seul."""
    if ACCUEIL is None:
        return
    if ACCUEIL.maitre:
        if ACCUEIL.mot_professeur:  # pas sur la machine du professeur, où son fichier de mot de passe l'ouvre sans rien taper
            stockage.ecrire(PROFESSEUR, ACCUEIL.mot_professeur)
        return
    identite = [ACCUEIL.nom.text().strip(), ACCUEIL.prenom.text().strip()]
    if ACCUEIL.secret is not None:  # le nom de la liste, et de quoi entrer sans retaper son mot de passe
        identite = [*ACCUEIL.nomme, base64.b64encode(ACCUEIL.secret).decode()]
    else:  # copie rouverte, sujet sans liste : entrée sans mot de passe, qui n'efface pas le secret du même élève (W763,
        try:  # le professeur, 17/11/2026 : « à chaque ouverture de TP » le mot de passe redemandé)
            nom, prenom, *secret = json.loads(stockage.lire(IDENTITE) or "null")
            if secret and codes.nom_identite(nom, prenom) == codes.nom_identite(*identite):
                identite = [nom, prenom, *secret]
        except (ValueError, TypeError):
            pass
    if all(identite):  # une copie rouverte entre sans eux
        stockage.ecrire(IDENTITE, json.dumps(identite))
    if ACCUEIL.depot and service("identites_ecrire"):
        asyncio.ensure_future(deposer_identite(ACCUEIL.depot))
    if ACCUEIL.code:
        stockage.ecrire(cle_du_code(), ACCUEIL.code)


async def deposer_identite(entree, lire=None, ecrire=None, essais=3):
    """L'empreinte d'une première visite (``codes.deposer``) ajoutée au fichier d'empreintes du professeur, relu juste avant :
    un autre élève qui dépose en même temps fait échouer l'écriture (``rev``), on relit et réessaie. Un échec n'arrête pas
    l'épreuve : sans dépôt, la visite suivante est de nouveau une première visite, et la correction juge la copie.
    ``lire``, ``ecrire`` : ceux de dropbox.js, à défaut ceux que la page a donnés au sujet (``demarrer``)."""
    lire, ecrire = lire or service("identites_lire"), ecrire or service("identites_ecrire")
    for _ in range(essais):
        try:
            lu = await lire()
            texte, rev = (None, None) if lu in (None, jsnull) else (str(lu.texte), str(lu.rev))
            identites = codes.identites_lire(texte)
            if not codes.ajouter_depot(identites, entree):  # une autre publique sous ce nom : jamais réécrite d'ici
                return
            if await ecrire(json.dumps(identites, ensure_ascii=False, indent=1), rev) not in (None, jsnull):
                return
        except Exception as erreur:  # noqa: BLE001 - réseau, quota, jeton
            print(f"empreinte non déposée ({erreur})")
            return
    print("empreinte non déposée (le fichier change sans cesse)")


def place_du_cours(chemin: str) -> Path:
    """Où un PDF du cours reçu est posé : à côté du sujet, où ``lecteur.cours_a_cote`` le trouve sous son nom."""
    return Path(CHEMIN).parent / Path(chemin).name


def cours_absent(chemin: str) -> str:
    """Ce que dit l'onglet d'un cours sans octets (``Paquet.cours_absent``) : introuvable seulement si le dossier du professeur
    a répondu qu'il n'y est pas. Le 02/11/2026, sur le TP11, un cours en route ou un échec passager s'annonçaient aussi ainsi."""
    if COURS_EN_LECTURE:
        return "Chargement du cours…"
    if chemin in COURS_INTROUVABLES:
        return f"Cours introuvable : {Path(chemin).name}"
    return "Le cours n'a pas pu être chargé. Fermez puis rouvrez « Cours » pour réessayer."


def lire_les_cours() -> None:
    """Lit ce qui manque des PDF du cours, en arrière-plan : à l'ouverture de l'épreuve, puis à chaque ouverture du bouton « Cours »
    (l'échec d'une seule lecture durait sinon jusqu'au rechargement de la page). Rien s'il ne manque rien, ou si une lecture est en route."""
    global COURS_EN_LECTURE
    manquants = [c for c in PAQUET.cours if not place_du_cours(c).is_file()]
    if manquants and not COURS_EN_LECTURE:
        COURS_EN_LECTURE = True
        if FENETRE:
            FENETRE.paquet.recharger_cours()  # l'onglet ouvert dit le chargement
        asyncio.ensure_future(cours_du_professeur(manquants))


async def cours_du_professeur(manquants: list[str]) -> None:
    """Les PDF du cours (``Paquet.cours``, que le .qcm n'embarque pas) lus chez le professeur, tous à la fois, chacun au premier
    de ses ``emplacements_du_cours``, puis posés à ``place_du_cours``. L'épreuve ne les attend pas (le cours n'est lu qu'à
    l'ouverture de son panneau), et un panneau ouvert avant la fin de la lecture est refait (``Paquet.recharger_cours``)."""
    async def un(chemin):
        COURS_INTROUVABLES.discard(chemin)
        for c in emplacements_du_cours(chemin, PARENTS):
            try:
                if octets := await service("cours")(c):
                    place_du_cours(chemin).write_bytes(octets.to_bytes())
                    return True
            except Exception as erreur:  # noqa: BLE001 - injoignable : son onglet le dira, et le prochain clic réessaie
                print(f"cours {c} : {erreur}")
                if "chemin refusé" not in str(erreur):  # refusé : cet emplacement seul, hors du dossier du professeur
                    return False
        COURS_INTROUVABLES.add(chemin)
        return False

    global COURS_EN_LECTURE
    recu = any(await asyncio.gather(*map(un, manquants)))
    COURS_EN_LECTURE = False
    if recu:
        print("cours reçu")
    if FENETRE:
        FENETRE.paquet.recharger_cours()


def essai_de_la_section():
    """Un « Réviser » ouvert par le bouton d'une section (``Accueil.section``, ``?section=``, W754) dont la copie la plus
    récente de ce navigateur (``REPRIS``) a été composée sur une AUTRE section (la marque ``|section`` de son essai ; une
    copie sans marque l'a été sur tout le thème) : l'essai suivant, neuf, composé sur la section pressée ; la copie
    précédente reste telle quelle, reprise seulement si l'élève rouvre sa section. La marque de l'essai ouvert est posée.
    Rend le paquet à ouvrir (``PAQUET``)."""
    global PAQUET, REPRIS
    if not (PAQUET.reviser and PAQUET.nouvel_essai):
        return PAQUET
    section = list(getattr(PAQUET, "_section", None) or ())
    if REPRIS > 1 or stockage.lire(cle(REPRIS)):
        try:
            ancienne = json.loads(stockage.lire(cle(REPRIS) + "|section") or "[]")
        except ValueError:
            ancienne = []
        accueil, source = accueil_du_paquet(), getattr(PAQUET, "_source", None)
        if ancienne != section and accueil is not None and source is not None:
            source.essai = REPRIS + 1  # le sujet préparé de nouveau, comme ``composer_sur_le_bilan`` ; essai neuf
            accueil.paquet = source
            PAQUET = accueil.nommer(PAQUET.eleve, getattr(PAQUET, "_depart", None))
            REPRIS = PAQUET.essai
    stockage.ecrire(cle() + "|section", json.dumps(section, ensure_ascii=False))
    return PAQUET


def locale():
    """La copie rangée dans le navigateur et la date de son dernier enregistrement (ms), ou (None, 0)."""
    return stockage.lire(cle()), float(stockage.lire(cle() + "|date") or 0)


def chemin_distant():
    """Où va la copie dans le dossier du professeur : <dossier du sujet>/<sujet>/[<classe>/]<sujet> [<élève>].qcm, suivi
    de « (2ème essai) »… pour les essais suivants d'une révision."""
    return "/" + codes.chemin_copie(PAQUET.inscrits, CLASSE, PAQUET.nom or PAQUET.titre, PAQUET.eleve, PAQUET.dossier, essai_courant())


async def distante():
    """La copie déposée chez le professeur sous ce nom : ``(objet JS {copie, date}, son empreinte)``, ``(None, "")`` s'il n'y
    en a pas, ``(objet JS, None)`` si elle ne se déchiffre pas : ni reprise, ni garde, et jamais écrasée (``deposer``). Une empreinte
    que cet élève peut reprendre (``codes.garde_valable``) est rendue comme la sienne."""
    trouvee = await service("lire")(chemin_distant())
    if not trouvee:
        return None, ""
    if trouvee.date == DEPOSEE:
        return trouvee, EMPREINTE
    Path(AUTRE).write_text(trouvee.copie, encoding="utf-8")
    try:
        with noyau.en_donnees():  # l'empreinte seule : sans écran
            garde = charger(AUTRE, MOT).empreinte
        identites = ACCUEIL.identites if ACCUEIL else {}
        return trouvee, EMPREINTE if codes.garde_valable(identites, PAQUET.eleve, "", garde, EMPREINTE) else garde
    except Exception as erreur:  # noqa: BLE001 - le chiffrement authentifié ne sépare pas une autre clé d'un fichier retouché
        cause = "autre clé ou copie modifiée" if "decryption failed" in str(erreur) else "fichier abîmé"
        print(f"copie du professeur illisible, {cause} ({erreur}) : mise de côté au prochain envoi")
        return trouvee, None


async def reprendre_puis_afficher():
    """La copie à reprendre, celle du navigateur ou celle déposée chez le professeur : l'élève reprend là où il en
    était, y compris sur un autre appareil. Celle du professeur n'est reprise que si ce navigateur n'en a pas, ou si elle n'est
    pas celle qu'il y a lui-même déposée ou reprise en dernier (``|deposee``) : un autre appareil a écrit depuis. Pas de
    comparaison de dates, qui viennent de deux horloges : une soumission faite pendant un envoi, ou une heure de la page en
    retard, faisait reprendre la copie d'avant et rouvrait la question soumise (01/10/2026). Sans cette trace (copie d'avant ce
    jour), les dates décident encore. Une copie gardée par un autre mot de passe ferme l'épreuve."""
    copie, date = locale()
    connue = float(stockage.lire(cle() + "|deposee") or 0)
    try:
        trouvee, garde = await distante()
        if garde and garde != EMPREINTE:
            refus = PROTEGEE.format(PAQUET.eleve)
            statut(refus, True)
            if ACCUEIL:
                ACCUEIL.refuser(refus)
                signaler("accueil")
            return
        if trouvee and garde == EMPREINTE:
            if not copie or (trouvee.date != connue if connue else trouvee.date > date):
                copie = trouvee.copie
            retenir_depot(trouvee.date)
    except Exception as erreur:  # noqa: BLE001 - le professeur injoignable n'empêche pas l'épreuve
        print(f"copie du professeur injoignable ({erreur})")
    # l'essai suivant (``nouvel_essai``) part déjà d'un état daté, le bilan et sa copie rendue (``nouvel_essai_suivant``) :
    # le recomposer sur le bilan seul perdrait ce pli ; seul le sujet nommé par l'accueil, sans bilan lu (``(…, None)``), l'est
    if not copie and accueil_du_paquet() and PAQUET.reviser and getattr(PAQUET, "_source", None) is not None \
            and (getattr(PAQUET, "_depart", None) or ({}, None))[1] is None and service("fichier"):
        try:
            await composer_sur_le_bilan()
        except Exception as erreur:  # noqa: BLE001 - un bilan illisible n'empêche pas l'épreuve, composée sans lui
            print(f"bilan illisible, questionnaire composé sans lui ({erreur})")
    afficher(copie)


async def composer_sur_le_bilan():
    """Un sujet « Réviser » sans copie à reprendre : renommé par l'accueil sur l'état des notions de l'élève, lu dans son
    bilan chez le professeur (``lire_bilan``, ``lecteur.depart_du_bilan``) ; l'accueil, qui n'avait pas ce bilan sur le
    disque du navigateur, l'avait composé comme si rien n'était vu. Tel quel sans bilan lisible."""
    global PAQUET
    if not await lire_bilan():
        return
    accueil = accueil_du_paquet()
    depart = depart_du_bilan(BILAN, bilans_widget.cle_du_secret(accueil.secret))
    if depart[1] is not None:
        accueil.paquet = PAQUET._source
        PAQUET = accueil.nommer(PAQUET.eleve, depart)


def accueil_du_paquet():
    """L'accueil qui a nommé ``PAQUET`` : la boîte (``ACCUEIL``), ou l'accueil sauté (élève nommé par le lien ou par
    SmartOS), que ``lecteur.accueillir`` attache au paquet (``_accueil``)."""
    return ACCUEIL or getattr(PAQUET, "_accueil", None)


def afficher(copie):
    """La fenêtre du lecteur, sur la copie si elle se relit, sur le sujet sinon."""
    global FENETRE, PAQUET, REPRIS, ENCHAINER
    if copie:
        try:
            Path(CHEMIN).write_text(copie, encoding="utf-8")
            with noyau.en_donnees():  # l'écran, une fois, par ``Lecteur`` : lue avec le sien, la copie le construisait pour
                sujet, PAQUET = PAQUET, charger(CHEMIN, MOT)  # rien (python_tp : 4 s de plus que le sujet, 02/10/2026)
                # la copie passée sur le sujet déployé, question par question (``Paquet.migrer``) : un énoncé corrigé, une
                # question ajoutée ou retirée atteignent aussi les copies commencées ; telle quelle si ça échoue
                PAQUET = noyau.reprendre(sujet, PAQUET)
            PAQUET.eleve, PAQUET.empreinte = sujet.eleve, EMPREINTE
            if getattr(sujet, "_section", None):  # « Réviser » : la copie reprise garde ses questions, son essai suivant
                PAQUET._section = sujet._section  # part de la section pressée cette fois (``Paquet.nouvel_essai_suivant``)
            if getattr(sujet, "_borne", None) is not None:  # et des TP ouverts à la classe ce jour-là (W754)
                PAQUET._borne = sujet._borne
            # le cours est celui du sujet déployé, pas celui de la copie, même rendue (que ``migrer`` laisse telle quelle) : un
            # cours ajouté après le début de l'épreuve paraît aussi dans les copies commencées (l'utilisateur, 07/10/2026) ; son
            # accès aussi, sans quoi le bouton manque à une copie commencée avant ``acces_cours`` (Projet Monkey, 08/10/2026)
            PAQUET.cours, PAQUET.cours_pages, PAQUET.acces_cours = sujet.cours, sujet.cours_pages, sujet.acces_cours
            PAQUET.cours_masques, PAQUET.cours_code = sujet.cours_masques, sujet.cours_code
            # la copie d'un code en pause prend le nouveau code, s'il en est un autre : prolongée, ou rendue (13/10/2026)
            PAQUET.reprendre_code(LIMITE, ACCUEIL and ACCUEIL.duree, sujet.soumission)
            PAQUET.limite = PAQUET.limite or LIMITE  # celle de la première ouverture ; une copie d'avant le 30/09/2026 ne l'a pas
            print("copie reprise")
        except Exception as erreur:  # noqa: BLE001 - une copie illisible ne doit pas empêcher l'épreuve
            print(f"copie illisible ({erreur}) : le sujet repart de zéro")
            REPRIS = 1  # le sujet vierge reste à sa place : jamais écrit sur l'essai plus récent illisible
    document.title = PAQUET.titre.replace("\n", " ")
    PAQUET.suivi_echeances = SUIVI
    FENETRE = Lecteur(CHEMIN, PAQUET, MOT, maitre=maitre(), lire_echeances=service("relire_echeances") and lire_echeances)
    PAQUET = FENETRE.paquet  # l'écran du paquet en données de l'accueil (``Lecteur``)
    if service("cours"):
        PAQUET.cours_absent = cours_absent
        if PAQUET.acces_cours and PAQUET.cours:
            PAQUET.bouton_cours.toggled.connect(lambda ouvert: ouvert and lire_les_cours())
    FENETRE.enregistree.connect(ranger)
    FENETRE.recommencer = lambda: asyncio.ensure_future(nouvel_essai())
    journaliser(PAQUET)
    # page cachée : l'enregistrement différé, tout de suite ; page fermée, toujours : l'heure où l'élève était là (``vu``),
    # qu'une page rechargée compare (12/10/2026)
    document.addEventListener("visibilitychange", create_proxy(lambda *_: FENETRE.differe.isActive() and FENETRE.enregistrer()))
    window.addEventListener("pagehide", create_proxy(lambda *_: FENETRE.enregistrer()))
    FENETRE.showFullScreen()  # tout le canevas, sans barre de titre : l'élève ne peut ni fermer ni réduire la fenêtre
    FENETRE.differe.start()  # la première sauvegarde (le paquet entier sérialisé, ≈ 50 ms) après la main rendue ; la page
    # qui se cache ou se ferme d'ici là la fait tout de suite (02/10/2026)
    if FENETRE.surveillee():
        surveiller()
    asyncio.ensure_future(envoyer_boite_noire())
    enchainer, ENCHAINER = ENCHAINER and a_enchainer(PAQUET), False  # une fois : la série suivante, ou l'historique, s'ouvre telle quelle
    if enchainer:  # la série rendue part chez le professeur, la suivante prend sa place (W811)
        asyncio.ensure_future(nouvel_essai())
        return
    if service("fichier"):
        asyncio.ensure_future(bilan_du_professeur())
    signaler("epreuve")


async def bilan_du_professeur():
    """Le bilan de l'année de l'élève (``bilans.py fichiers``), lu dans « <niveau>/Bilans » chez le professeur, à côté du
    dossier des copies de ce niveau (``lecteur.bilan_a_cote`` sur le disque), et posé sous le bilan de la copie, en clair ou
    ouvert par le mot de passe tapé à l'accueil (``Paquet.poser_bilan``). En arrière-plan ; rien s'il n'y en a pas. Une
    copie « Réviser » reprise (page rechargée, autre appareil) y relit l'état d'où partira son essai suivant
    (``lecteur.relire_depart``)."""
    if await lire_bilan():
        cle = bilans_widget.cle_du_secret(ACCUEIL.secret) if ACCUEIL else None
        FENETRE.paquet.poser_bilan(BILAN, cle)
        relire_depart(FENETRE.paquet, BILAN, cle)


async def lire_bilan() -> bool:
    """Le bilan de l'année de l'élève, lu chez le professeur et écrit dans ``BILAN`` ; faux s'il n'y en a pas."""
    chemin = f"{chemin_distant().split('/')[1]}/Bilans/{bilans_widget.nom_du_fichier(PAQUET.eleve)}"
    try:
        octets = await service("fichier")(chemin)
    except Exception as erreur:  # noqa: BLE001 - pas de bilan pour cet élève, ou le professeur injoignable
        print(f"bilan {chemin} : {erreur}")
        return False
    Path(BILAN).write_bytes(octets.to_bytes())
    return True


async def nouvel_essai():
    """« Nouvel essai » : la copie rendue part d'abord chez le professeur, sous son nom, puis l'essai suivant prend sa place
    (``Paquet.nouvel_essai_suivant``), sous le sien (``cle``, ``chemin_distant``) ; repris s'il a déjà été commencé, ici ou
    ailleurs. L'ancienne fenêtre n'écrit plus rien : sa fermeture réécrirait sa copie par-dessus la nouvelle."""
    global PAQUET
    ancienne = FENETRE
    ancienne.enregistrer()
    if A_ENVOYER:
        await envoyer()
    ancienne.chemin = None
    with noyau.en_donnees():
        PAQUET = ancienne.paquet.nouvel_essai_suivant()
    if PAQUET.reviser:  # l'essai suivant garde la section (``nouvel_essai_suivant``) : sa marque, que ``essai_de_la_section`` relit
        stockage.ecrire(cle(PAQUET.essai) + "|section",
                        json.dumps(list(getattr(PAQUET, "_section", None) or ()), ensure_ascii=False))
    if relie():
        await reprendre_puis_afficher()
    else:
        afficher(locale()[0])
    ancienne.close()


def echeances_signe(texte) -> str | None:
    """Le fichier d'échéances lu par la page, sans sa signature, s'il est signé par le professeur (``echeances.verifie``) :
    le jeton Dropbox de la page permet à un tiers de le réécrire. ``None`` sinon : le code du lien vaut seul."""
    if not texte:
        return None
    signe = echeances.verifie(str(texte))
    if signe is None:
        print(f"{echeances.NOM} non signé ou modifié : ignoré, le code du lien vaut")
    return signe


def lire_echeances(rappel):
    """``Lecteur.lire_echeances`` dans le navigateur : le fichier d'échéances relu dans Dropbox, ``rappel(texte)`` à la
    réponse, ``rappel(None)`` si la lecture a échoué (le lecteur garde alors l'échéance qu'il connaît)."""
    async def lire():
        try:
            texte = await service("relire_echeances")()
        except Exception as erreur:  # noqa: BLE001 - réseau, quota, jeton : l'échéance connue vaut
            print(f"échéances non relues ({erreur})")
            texte = None
        rappel(echeances_signe(None if texte in (None, jsnull) else texte))
    asyncio.ensure_future(lire())


def maitre():
    """Le professeur, entré par son mot de passe : pas d'anti-triche pour lui (``Lecteur.surveillee``). Avant le 03/10/2026,
    sa copie d'élève rouverte tombait sous l'écran noir, qui inscrivait même une sortie dans la copie."""
    return bool(ACCUEIL and ACCUEIL.maitre)


def relie() -> bool:
    """La copie passe par le dossier du professeur (reprise, dépôt, témoin de présence) : la page y est reliée, et ce n'est
    pas lui qui l'ouvre. Sa propre copie, entré par son mot de passe, reste dans ce navigateur : elle n'a plus de place dans
    son dossier (« Hors liste », l'utilisateur, 25/10/2026 : « est-il possible d'arrêter de créer une copie hors liste pour
    le professeur ? »), comme dans le lecteur natif, où elle ne va nulle part (``lecteur.copie``)."""
    return bool(service("lire")) and not maitre()


def agrandir():
    """La page en plein écran ; le navigateur ne l'accorde que juste après un clic ou une touche, et le refus est sans suite.
    Chrome et Edge laissent aussi la page capter le clavier en plein écran (``navigator.keyboard.lock``, 29/09/2026) : Échap ne
    fait plus sortir qu'appuyée longuement, et Alt+Tab ou la touche Windows vont à la page quand le système le permet.
    Firefox et Safari ne l'ont pas : la sortie y reste possible, et c'est la surveillance qui la voit. Un refus va au journal
    (et à la boîte noire)."""
    if document.fullscreenElement not in (None, jsnull):
        return
    getattr(document.documentElement.requestFullscreen(), "catch")(create_proxy(lambda e: print(f"plein écran refusé : {e}")))
    clavier = getattr(window.navigator, "keyboard", None)
    if clavier is not None:  # Chrome et Edge seuls ont navigator.keyboard, et lock avec
        getattr(clavier.lock(), "catch")(create_proxy(lambda _: None))


def reduire():
    """La copie rendue, la page quitte le plein écran et rend le clavier (demande de l'utilisateur, 09/10/2026)."""
    if document.fullscreenElement not in (None, jsnull):
        getattr(document.exitFullscreen(), "catch")(create_proxy(lambda _: None))
    clavier = getattr(window.navigator, "keyboard", None)
    if clavier is not None:
        clavier.unlock()


def present():
    """L'élève est sur l'épreuve : onglet visible, page active, en plein écran (le ``null`` de JS arrive en ``jsnull``, pas None)."""
    return document.visibilityState == "visible" and document.hasFocus() and document.fullscreenElement not in (None, jsnull)


def surveiller():
    """Un sujet sous ``anti_triche`` : l'onglet caché (autre onglet, page fermée ou rechargée), la page qui perd le focus (autre
    application) ou la sortie du plein écran est une sortie (``Lecteur.juger``). Dans le navigateur, Qt ne dit rien de fiable
    là-dessus : ce sont les événements de la page qui le disent, et c'est elle qui passe en plein écran."""
    FENETRE.agrandir, FENETRE.present, FENETRE.reduire = agrandir, present, reduire
    for cible, nom in ((document, "visibilitychange"), (document, "fullscreenchange"), (window, "blur"), (window, "focus")):
        cible.addEventListener(nom, create_proxy(FENETRE.juger))
    # Le clic sur l'écran noir quand il montre « Passer en plein écran » : le plein écran demandé par la page DANS l'événement
    # du clic, que le navigateur accorde à coup sûr ; le clic que Qt rend au bouton ensuite peut arriver trop tard sur une
    # page chargée, et le refus était muet (l'utilisateur, 06/11/2026 : « le bouton pour reprendre […] ne fonctionne pas
    # toujours »).
    document.addEventListener("pointerdown", create_proxy(
        lambda *_: FENETRE.surveillee() and not FENETRE.rideau.isHidden() and FENETRE.plein.isVisible() and agrandir()))
    FENETRE.surveiller()


def cle_des_etats(eleve: str) -> str:
    """La place de l'état des notions de l'élève après sa dernière révision rendue (``ranger_etats``)."""
    return f"smartteacher-qt|notions|{eleve.lower()}"


def ranger_etats(paquet) -> None:
    """Une copie « Réviser » rendue : l'état des notions qu'elle donne (``revision.apres_copie``, le calcul du bilan du
    professeur) rangé dans le navigateur, d'où le bilan de l'élève refait ses jauges dès sa page suivante, sans attendre le
    professeur (``bilans_widget.ETATS_LOCAUX``, W457, 08/11/2026)."""
    import revision  # noqa: PLC0415 - revision importe noyau et bilans
    if paquet is None or paquet.fin is None or not paquet.eleve:
        return
    maintenant = time.time()
    if (etats := revision.apres_copie(paquet, maintenant)) is not None:
        stockage.ecrire(cle_des_etats(paquet.eleve), json.dumps([revision.en_bilan(etats), maintenant]))


def etats_locaux(eleve: str) -> tuple[list, float] | None:
    """``bilans_widget.ETATS_LOCAUX`` dans le navigateur : ce que ``ranger_etats`` y a rangé pour ``eleve``, ou None."""
    try:
        lignes, instant = json.loads(stockage.lire(cle_des_etats(eleve)) or "null")
    except (TypeError, ValueError):
        return None
    return lignes, float(instant)


def ranger():
    """Chaque enregistrement du lecteur : la copie dans le navigateur, datée ; puis chez le professeur (au prochain envoi), ou au
    téléchargement quand l'épreuve est finie."""
    global A_ENVOYER
    copie = Path(CHEMIN).read_text(encoding="utf-8")
    if not (stockage.ecrire(cle(), copie) and stockage.ecrire(cle() + "|date", str(horloge.secondes() * 1000))):
        print("copie non rangée dans le navigateur (stockage plein ou interdit)")
    ranger_etats(PAQUET)
    if PAQUET.fin is not None and PAQUET.eleve:  # la page d'accueil le sort de « À faire » (``pont_tableau.commencee``, W695)
        stockage.ecrire(cle_rendue(PAQUET.nom or PAQUET.titre, PAQUET.eleve), "1")
    elif PAQUET.eleve and PAQUET.destination in ("tp", "projet") and PAQUET.reste_a_finir() == noyau.BONUS:
        stockage.ecrire(cle_bonus(PAQUET.nom or PAQUET.titre, PAQUET.eleve), "1")
    if relie():
        A_ENVOYER = True
    elif PAQUET.fin is not None and not maitre():
        telecharger(copie)


def noter(texte: str) -> None:
    """Une ligne dans la boîte noire de la page (tenue par qtpy6, ``window.qtpy6BoiteNoire``, comme ``envoyer_boite_noire``)."""
    boite = getattr(window, "qtpy6BoiteNoire", None)
    if boite is not None:
        boite.noter(texte)


def journaliser(paquet) -> None:
    """Les gestes de l'élève dans la boîte noire de la page (``noter``) : l'écran affiché, une question
    soumise, validée ou figée, la copie rendue ; avec les envois ratés (``envoyer``), de quoi savoir ce qu'il faisait quand la
    page a gelé ou est morte (demande de l'utilisateur, 10/11/2026). Le numéro est le rang de la feuille, à partir de 1."""
    for i, f in enumerate(paquet.feuilles, 1):
        f.changee.connect(lambda i=i: noter(f"feuille {i} : soumise, validée ou figée"))
    if getattr(paquet, "pile", None) is not None:  # mode « question » : un écran par question
        paquet.pile.currentChanged.connect(lambda _: noter(f"écran {paquet.courante + 1} affiché"))
    paquet.finie.connect(lambda: noter("copie rendue"))


def telecharger(copie):
    stockage.telecharger(chemin_distant().rpartition("/")[2], copie, lien=service("lien"))  # « <sujet> [<élève>].qcm »


async def envoyer_regulierement():
    """Tant que la page vit (``demarrer``) : la copie part dès qu'elle change, au plus une fois par minute pendant l'épreuve
    et cinq secondes après sa fin ; un échec se retente au même rythme."""
    while True:
        await asyncio.sleep(1)
        if A_ENVOYER and time.monotonic() - DERNIER_ENVOI > CADENCE[PAQUET.fin is not None]:
            await envoyer()
        if service("presence") and relie() and FENETRE is not None:
            await envoyer_presence()


def presence():
    """Où en est l'élève, pour le plan de classe du professeur : l'état (``epreuve``, ``dehors`` tant que l'écran noir de la
    surveillance le bloque, ``pause`` à l'échéance d'un code ``PAUSES``, ``rendue``), les sorties inscrites, l'avancement en % (la jauge du lecteur, ``Paquet._rafraichir_vue``)
    et la plus lourde sanction d'un propos inacceptable (``propos`` : « copie », « question » ou None, ``modele.JugementModele._verifier_propos``)."""
    feuilles = PAQUET.feuilles
    niveaux = {(f.propos or {}).get("niveau") for f in feuilles}
    return {"eleve": PAQUET.eleve, "etat": "rendue" if PAQUET.fin is not None else "pause" if PAQUET.suspendue
            else "dehors" if FENETRE.leve == math.inf else "epreuve",
            "sorties": len(PAQUET.sorties), "avancement": round(100 * sum(f.avancement() for f in feuilles) / len(feuilles)) if feuilles else 0,
            "propos": next((n for n in ("copie", "question") if n in niveaux), None)}


# Ce qui, dans la boîte noire de la visite précédente, dit un gel : la page tuée sans être quittée (fil bloqué jusqu'au
# rechargement), une page sans main rendue, la boucle de Qt arrêtée, une erreur JS (``qtpy6web.js``, ``ouvrir_boite_noire``).
SIGNES_DE_GEL = ("page tuée", "gel de la page", "la boucle de Qt ne tourne plus", "erreur JS", "promesse rejetée")
# Le démarrage (Python, Qt, la copie construite d'un bloc : 3 à 6 s sur un ordinateur, jusqu'à 13 s sur un vieil Android) n'est
# pas un gel : ses boîtes, 209 des 275 reçues du 06 au 17/11, noyaient les vraies (décision du professeur, 17/11/2026, W762).
GEL_COURT, DEMARRAGE = 15, 60


def gel_court_au_demarrage(texte: str) -> bool:
    """Vrai si la boîte ne dit qu'un démarrage lent : des gels de la page, ou une boucle de Qt muette puis repartie, de moins de
    ``GEL_COURT`` s, tous dans les ``DEMARRAGE`` premières secondes de la visite (décision du professeur, 17/11/2026)."""
    tete, _, corps = texte.partition("\n")
    debut = re.search(r"visite du [\d/]+\D+?(\d\d):(\d\d):(\d\d)", tete)  # séparateur selon l\'ICU du navigateur
    if "page tuée" in tete or not debut:
        return False
    t0, signes, muette = (int(debut[1]) * 60 + int(debut[2])) * 60 + int(debut[3]), 0, None
    for ligne in corps.splitlines():
        h = re.match(r"(\d\d):(\d\d):(\d\d) (.*)", ligne)
        if not h:
            continue
        t, texte_ligne = ((int(h[1]) * 60 + int(h[2])) * 60 + int(h[3]) - t0) % 86400, h[4]
        if texte_ligne.startswith("la boucle de Qt tourne de nouveau") and muette is not None:
            if t - muette >= GEL_COURT:
                return False
            muette = None
            continue
        if not any(s in texte_ligne for s in SIGNES_DE_GEL):
            continue
        gel = re.match(r"gel de la page : ([\d.]+) s sans main rendue( \(×\d+ depuis [\d:]+\))?$", texte_ligne)  # noter : répétée
        muet = re.match(r"la boucle de Qt ne tourne plus depuis ([\d.]+) s \(page vivante ; [^)]*\)$", texte_ligne)
        if t > DEMARRAGE or not (gel and float(gel[1]) < GEL_COURT or muet):
            return False
        if muet:
            muette = t - float(muet[1])
        signes += 1
    return signes > 0 and muette is None


async def envoyer_boite_noire() -> None:
    """La boîte noire de la visite précédente de cette page, à côté de la copie (``<copie>.journal.txt``), si elle dit un gel :
    de quoi diagnostiquer les gels qu'on ne quitte qu'en rechargeant la page (demande de l'utilisateur, 06/11/2026). Sur un
    poste partagé, la visite précédente peut être celle d'un autre élève : l'en-tête de la boîte en donne l'heure."""
    boite = getattr(window, "qtpy6BoiteNoire", None)  # tenue par qtpy6 : la page, et le battement de Qt
    texte = None if boite is None else boite.precedente()
    texte = None if texte in (None, jsnull) else str(texte)
    if not texte or not any(s in texte for s in SIGNES_DE_GEL) or gel_court_au_demarrage(texte) \
            or not (service("journal") and relie()):
        return
    try:
        await service("journal")(chemin_distant().removesuffix(".qcm") + ".journal.txt", texte)
    except Exception as erreur:  # noqa: BLE001
        print(f"boîte noire non déposée ({erreur})")


async def envoyer_presence():
    """Le témoin de présence à côté de la copie (``chemin_distant``, « .etat.json ») : une sortie, un retour ou une sanction part dans les 2 s,
    un nouvel avancement au bout de 15 s (25 élèves partagent la limite d'appels du compte Dropbox du professeur), et le
    battement toutes les minutes dit au plan que l'élève est encore là. Un échec n'est pas dit à l'élève (le témoin est
    facultatif, et l'envoi de la copie le dit déjà) : le prochain tour le retente."""
    global PRESENCE, DERNIERE_PRESENCE
    etat, avant = presence(), PRESENCE
    delai = 60 if avant == etat else 2 if avant is None or avant["etat"] != etat["etat"] or avant["sorties"] != etat["sorties"] or avant.get("propos") != etat["propos"] else 15
    if time.monotonic() - DERNIERE_PRESENCE < delai:
        return
    DERNIERE_PRESENCE = time.monotonic()
    try:
        await service("presence")(chemin_distant().removesuffix(".qcm") + ".etat.json", json.dumps(etat))
        PRESENCE = etat
    except Exception as erreur:  # noqa: BLE001 - réseau, quota : le témoin est facultatif
        print(f"témoin de présence non envoyé ({erreur})")


async def envoyer():
    """La copie chez le professeur ; la page dit à l'élève ce qu'il en est, et lui offre la copie si l'envoi échoue à la fin."""
    global A_ENVOYER, DERNIER_ENVOI
    A_ENVOYER, DERNIER_ENVOI = False, time.monotonic()
    try:
        await deposer()
        statut("")  # un envoi réussi ne se dit pas (l'utilisateur, 02/10/2026 : « il faut supprimer ce bandeau ») ; il efface l'échec
    except Remplacee as erreur:  # ni nouvel essai ni téléchargement : cette copie-ci est périmée, la page rechargée reprend l'autre
        statut(str(erreur), True)
        noter("envoi refusé : copie remplacée chez le professeur")
    except Exception as erreur:  # noqa: BLE001 - réseau, quota, script : on réessaie
        A_ENVOYER = True
        noter(f"envoi raté : {erreur}")
        finie = PAQUET.fin is not None
        statut(f"La copie n'a pas pu être envoyée ({erreur}) : nouvel essai dans un instant."
               + (" En attendant, téléchargez-la et remettez-la au professeur." if finie else ""), True)
        if finie:
            telecharger(Path(CHEMIN).read_text(encoding="utf-8"))


class Remplacee(Exception):
    """La copie du professeur n'est plus celle que ce navigateur a déposée ou reprise en dernier (``deposer``)."""


async def deposer():
    """La copie à sa place chez le professeur, sauf si ce nom y est gardé par un autre mot de passe, ou si la copie déposée
    n'est plus celle que ce navigateur y a mise ou reprise en dernier (``|deposee``) : le professeur l'a réécrite (correction
    annulée, temps rendu), ou l'élève l'a continuée sur un autre appareil, et une page restée ouverte l'écrasait (18/10/2026).
    Celle qui ne se déchiffre pas est mise de côté (« … (illisible).qcm ») : elle était écrasée sans garde (18/10/2026)."""
    chemin = chemin_distant()
    trouvee, garde = await distante()
    if garde and garde != EMPREINTE:
        raise PermissionError(PROTEGEE.format(PAQUET.eleve))
    connue = float(stockage.lire(cle() + "|deposee") or 0)
    if trouvee and garde is None and await perimee(trouvee.copie):
        raise Remplacee(PERIMEE)
    if trouvee and garde is None:
        await service("deplacer")(chemin, chemin.removesuffix(".qcm") + " (illisible).qcm")
    elif trouvee and connue and trouvee.date != connue:
        raise Remplacee(REMPLACEE)
    retenir_depot(await service("ecrire")(chemin, Path(CHEMIN).read_text(encoding="utf-8")))


async def perimee(copie: str) -> bool:
    """Cette page sert-elle une version du sujet que le professeur a remplacée ? Vrai quand la copie déposée, illisible,
    porte un autre sel que le sujet de la page (une autre version, ``exporter_eleve.cle_neuve``) ET que le sujet déposé chez
    le professeur, relu, n'est plus celui de la page. Une page restée en V1 mettait de côté la copie portée en V2 et
    réécrivait une V1 que la V2 ne migre pas (TP01 Seconde sans IDE, 17/11/2026, W747). Faux (la mise de côté reste) pour
    une copie abîmée (même sel), une copie d'une version plus ancienne (page à jour) ou un sujet qui ne se relit pas."""
    sel, mien = codes.sel_du_fichier(copie.encode()), codes.sel_du_fichier(SUJET or b"")
    # un nom sans dossier est celui d'un fichier choisi à la main (page.html, ``files[0].name``), pas un chemin chez le
    # professeur : un homonyme de la racine n'y décide de rien
    if not sel or sel == mien or not (SOURCE and "/" in SOURCE and service("fichier")):
        return False
    try:
        depose = await service("fichier")(SOURCE)
    except Exception as erreur:  # noqa: BLE001 - le professeur injoignable : la règle d'avant
        print(f"sujet déposé non relu ({erreur})")
        return False
    return codes.sel_du_fichier(depose.to_bytes() if hasattr(depose, "to_bytes") else bytes(depose)) != mien


def retenir_depot(date):
    """La date de la copie du professeur que cette page vient de déposer ou de reprendre : en mémoire pour la garde
    (``distante``), dans le navigateur pour la prochaine reprise (``reprendre_puis_afficher``)."""
    global DEPOSEE
    DEPOSEE = date
    stockage.ecrire(cle() + "|deposee", str(date))


def statut(texte, erreur=False):
    if service("statut"):
        service("statut")(texte, erreur)


def signaler(etat):
    if service("etat"):
        service("etat")(etat)
