"""Le pont de la page PyQt6-WASM (page.html) : le lecteur natif tel quel dans le navigateur.

Le sujet arrive en octets ; l'élève passe par la boîte d'accueil du lecteur natif (``lecteur.Accueil`` : nom, prénom, code de
déverrouillage s'il en faut un), dans le canevas, puis la fenêtre de ``lecteur.py`` le remplit. La copie est le fichier que
``Lecteur.enregistrer`` réécrit : du texte, chiffrée comprise (l'armure ASCII d'age, ``modele.sauver``), rangée dans le
navigateur à chaque enregistrement (``qtpy6.web.stockage``, sous le titre et le nom, avec sa date) et reprise si la page se
recharge. Quand la page est reliée au professeur (son dossier Dropbox : ``DROPBOX`` de ``page.html``, ``dropbox.js``), la copie part aussi chez
lui, toutes les minutes tant que l'épreuve dure et cinq secondes après sa fin, et c'est la plus récente des deux copies,
celle du navigateur ou celle du professeur, qui est reprise, sur n'importe quel appareil ; sans professeur, elle est offerte
au téléchargement quand l'épreuve est finie.

Chez le professeur, la copie est le seul fichier (plus de fiche à côté, 27/09/2026) : ``codes.chemin_copie`` la range dans
le dossier du sujet, par classe et sujet, Dropbox la date (``server_modified``, l'heure de son serveur, pas celle de l'élève), et la garde du
code personnel se vérifie en la déchiffrant (``Paquet.empreinte``) — sauf quand elle est encore celle que cette page a
déposée ou reprise, reconnue à sa date."""

import asyncio
import hashlib
import json
import math
import time
from pathlib import Path

import codes
import horloge
import noyau
from js import document, window  # Pyodide : le titre de l'onglet, la sortie de la page (surveiller)
from pyodide.ffi import create_proxy, jsnull
from lecteur import Lecteur, accueillir, emplacements_du_cours
from modele import GardeCopie, application, charger
from qtpy6.web import stockage, tactile, travailleur

PARENTS = 8  # les dossiers parents du sujet où chercher un cours sous son nom (emplacements_du_cours)
CHEMIN = "/sujet.qcm"  # le sujet, puis la copie que le lecteur y réécrit
AUTRE = "/distante.qcm"  # une copie déposée chez le professeur, déchiffrée pour lire son empreinte
PROTEGEE = "{} a protégé sa copie par son code personnel : sans lui, ce nom n'est pas accepté."
CADENCE = 60, 5  # secondes entre deux envois au professeur : pendant l'épreuve, après sa fin
APP = application()  # charge aussi les polices de lecteur.zip
tactile.activer_au_doigt(APP)  # téléphone, tablette, portable tactile ; sinon au premier doigt posé, sur l'accueil
GardeCopie(APP)
SUJET = ACCUEIL = FENETRE = PAQUET = MOT = PAGE = ENVOIS = None
IDENTITE = "smartteacher-qt|identite"  # nom et prénom du dernier élève entré par l'accueil sur ce navigateur, proposés au suivant
PROFESSEUR = "smartteacher-qt|professeur"  # le mot de passe professeur tapé une fois dans ce navigateur : il ouvre tout sujet
EMPREINTE = ""  # celle du code personnel que l'élève a donné à l'accueil (son contrôle lent, codes.inscrire) : elle garde sa copie chez le professeur
CLASSE = LIMITE = None  # la classe du code donné à l'accueil (None : sans classe) et sa date limite (UTC), ou None
DEPOSEE = None  # la date (ms, Dropbox) de la dernière copie que cette page a déposée ou reprise : tant que c'est elle, elle est à l'élève
A_ENVOYER = False  # la copie a changé depuis le dernier envoi au professeur
DERNIER_ENVOI = float("-inf")  # time.monotonic() du début du dernier envoi : le premier part dès la première copie
PRESENCE, DERNIERE_PRESENCE = None, float("-inf")  # le dernier témoin de présence reçu par le professeur (``presence``), et l'heure de l'essai


ENFANT = ("console_enfant.py", "bac_a_sable.py", "verifier.py", "pyxel_factice.py")  # tout ce que les sous-processus
# importent du dossier du lecteur (console_enfant → bac_a_sable + verifier ; verifier → bac_a_sable + pyxel_factice par
# chemin et se relance en --enfant ; ses imports de codes, modele, exporter_eleve sont côté parent seulement)


def configurer(pyodide, roues=()):
    """Avant tout : les sous-processus des questions code (console_enfant.py de leur console, verifier.py de leur correction)
    tournent tels quels dans des Web Workers sous le Pyodide à ``pyodide`` (URL relative à la page, ou absolue — le même
    Pyodide-Qt que la page depuis le 05/10/2026 : un seul téléchargement) : ``QProcess`` et ``subprocess.run`` de qtpy6.web.
    ``roues`` : les .whl de ce qui manque à cette distribution (sqlite3), chargés au premier import (travailleur).
    Le filtre ne copie dans le worker, du dossier du lecteur (sous-dossiers compris : polices, sujet, copie), que les
    fichiers ``ENFANT`` ; tout le reste — le dossier temporaire où le parent dépose base sql et fichiers de la question —
    passe entier. Sans lui, chaque premier ▶ zippait ~6 Mo (mortel sur téléphone) pour ~100 Ko utiles."""
    dossier = str(Path(noyau.__file__).resolve().parent) + "/"
    utiles = {dossier + nom for nom in ENFANT}
    travailleur.configurer(pyodide, roues,
                           filtre=lambda chemin: not chemin.startswith(dossier) or chemin in utiles)


def service(nom):
    """Ce que la page a fourni sous ce nom (``demarrer``), ou None."""
    return getattr(PAGE, nom, None) if PAGE is not None else None


def cle():
    """La place de la copie dans le navigateur : le même élève qui rouvre le même sujet la retrouve."""
    return f"smartteacher-qt|{PAQUET.nom or PAQUET.titre}|{PAQUET.eleve.lower()}{codes.essai(PAQUET.essai)}"


def demarrer(contenu, eleve="", page=None, jeton=""):
    """Le ``.qcm`` (octets) : l'accueil, puis l'épreuve plein canevas. ``eleve`` : « Nom Prénom » déjà connu (la sonde,
    ``?eleve=``), l'accueil est sauté si le sujet s'ouvre sans code. ``jeton`` : le code de la classe tel que le lien le
    porte (``?code=``, ``codes.jeton``), déjà dans l'accueil : l'élève n'a que son nom à taper. ``page`` : ce que la page
    offre, un objet JS dont chaque membre est facultatif :
        lien                      l'élément <a> qui reçoit la copie à télécharger (sans lui, le téléchargement part tout seul)
        etat(e)                   prévenue de ce qui est à l'écran : "accueil", puis "epreuve"
        statut(texte, erreur)     une ligne pour l'élève quand sa copie est en échec (vide : rien à dire)
        lire(chemin)              Promise du fichier ``chemin`` du dossier du professeur, {copie (texte), date (ms)}, ou null
        ecrire(chemin, copie)     Promise de la date (ms) du fichier écrit ; sa présence fait partir la copie chez le
                                  professeur plutôt qu'au téléchargement
        presence(chemin, texte)   Promise : le témoin de présence ``texte`` (JSON) écrit à ``chemin`` (….etat.json), que le plan de
                                  classe du professeur lit sur son disque ; absente, aucun témoin n'est envoyé
        deplacer(de, vers)        Promise : ``de`` renommé ``vers`` (un numéro ajouté si ``vers`` existe), rien s'il n'existe pas
        cours(chemin)             Promise des octets (Uint8Array) d'un PDF du cours, ``chemin`` depuis le dossier du sujet
                                  (``Paquet.cours``), ou null
    Rend ``"accueil"`` ou ``"epreuve"`` : ce qui est à l'écran, ou va l'être dès la réponse du professeur."""
    global SUJET, ACCUEIL, PAGE, ENVOIS
    # un Uint8Array de la page : ``to_bytes`` le copie d'un bloc, ``bytes`` octet par octet (252 ms pour les 1,2 Mo de
    # python_tp, 02/10/2026)
    SUJET, PAGE = contenu.to_bytes() if hasattr(contenu, "to_bytes") else bytes(contenu), page
    Path(CHEMIN).write_bytes(SUJET)
    if ENVOIS is None and service("ecrire"):
        ENVOIS = asyncio.ensure_future(envoyer_regulierement())
    ACCUEIL = accueillir(CHEMIN, montrer, codes.phrase_du_jeton(jeton), eleve)
    if ACCUEIL:
        preremplir()
    if ACCUEIL and ACCUEIL.isVisible():  # pas le professeur entré par son mot de passe retenu (``preremplir``)
        signaler("accueil")
        return "accueil"
    return "epreuve"


def montrer(paquet, mot):
    """Après l'accueil : la copie la plus récente, s'il y en a une, reprend la place du sujet, et la fenêtre du lecteur remplit
    le canevas. L'accueil appelle sans attendre de retour ; la copie du professeur, elle, s'attend."""
    global PAQUET, MOT, EMPREINTE, CLASSE, LIMITE
    PAQUET, MOT = paquet, mot
    if paquet.surveillance and not maitre():  # tout de suite, pendant que le clic de l'accueil l'autorise ; afficher peut attendre le professeur
        agrandir()
    # posées par l'accueil (``Accueil.nommer``), même sauté : l'élève nommé par le lien, sur un code sans classe
    EMPREINTE, LIMITE, CLASSE = paquet.empreinte, paquet.limite, ACCUEIL and ACCUEIL.classe
    retenir_identite()
    if paquet.cours and service("cours"):
        asyncio.ensure_future(cours_du_professeur())
    if service("lire"):
        asyncio.ensure_future(reprendre_puis_afficher())
    else:
        afficher(locale()[0])


def cle_du_code():
    """Où le navigateur garde le code de déverrouillage tapé pour ce sujet : sous l'empreinte du fichier distribué."""
    return "smartteacher-qt|code|" + hashlib.sha256(SUJET).hexdigest()[:16]


def preremplir():
    """L'accueil rempli de ce que ce navigateur a retenu (``retenir_identite``) : nom et prénom du dernier élève, le code du
    sujet s'il l'a tapé lui-même. Rien ne commence seul pour un élève : il relit et valide (un poste partagé passe d'un élève à
    l'autre). Le code personnel n'est jamais retenu : il garde la copie contre qui utilise le même navigateur. Le mot de passe
    professeur, s'il a été tapé ici, passe avant tout : le professeur entre sous son nom sans voir l'accueil (l'utilisateur,
    02/10/2026 : « réouvert le lien, et la fenetre de login s'affiche toujours ») ; sans anti-triche pour lui, aucun clic
    n'est dû au plein écran."""
    mot = stockage.lire(PROFESSEUR)
    if mot and not ACCUEIL.maitre and ACCUEIL.professeur(mot):
        ACCUEIL.commencer()
        return
    try:
        nom, prenom = json.loads(stockage.lire(IDENTITE) or '["", ""]')
    except ValueError:
        nom = prenom = ""
    for champ, texte in ((ACCUEIL.nom, nom), (ACCUEIL.prenom, prenom)):
        if not champ.text().strip():
            champ.setText(texte)
    code = stockage.lire(cle_du_code())
    if code and ACCUEIL.paquet is None and not ACCUEIL.lien:
        ACCUEIL.code.blockSignals(True)  # un code complet commence tout seul (``Accueil._code_tape``) : pas ici
        ACCUEIL.code.setText(code)
        ACCUEIL.code.blockSignals(False)
        ACCUEIL.ouvrir(code)
    ACCUEIL.focaliser()


def retenir_identite():
    """Après l'accueil : nom et prénom tapés, et le code du sujet s'il ne venait pas du lien, retenus pour la prochaine
    ouverture dans ce navigateur (``preremplir``). Pour le professeur, son mot de passe (l'utilisateur, 02/10/2026 : « je ne
    le taperais jamais sur l'appareil d'un élève ») : son nom, que le mot de passe pose, ne servirait à rien seul."""
    if ACCUEIL is None:
        return
    if ACCUEIL.maitre:
        if ACCUEIL.mot_professeur:  # pas sur la machine du professeur, où son fichier de mot de passe l'ouvre sans rien taper
            stockage.ecrire(PROFESSEUR, ACCUEIL.mot_professeur)
        return
    identite = [ACCUEIL.nom.text().strip(), ACCUEIL.prenom.text().strip()]
    if all(identite):  # une copie rouverte entre sans eux
        stockage.ecrire(IDENTITE, json.dumps(identite))
    if ACCUEIL.code.text().strip() and not ACCUEIL.lien:
        stockage.ecrire(cle_du_code(), ACCUEIL.code.text().strip())


async def cours_du_professeur():
    """Les PDF du cours (``Paquet.cours``, que le .qcm n'embarque pas) lus chez le professeur, tous à la fois, chacun au premier
    de ses ``emplacements_du_cours``, puis posés à côté du sujet, où ``lecteur.cours_a_cote`` les trouve sous leur nom. En
    arrière-plan : l'épreuve ne les attend pas (le cours n'est lu qu'à l'ouverture de son panneau), et un panneau ouvert avant
    leur arrivée est refait (``Paquet.recharger_cours``)."""
    async def un(chemin):
        for c in emplacements_du_cours(chemin, PARENTS):
            try:
                if octets := await service("cours")(c):
                    (Path(CHEMIN).parent / Path(chemin).name).write_bytes(octets.to_bytes())
                    return True
            except Exception as erreur:  # noqa: BLE001 - hors du dossier du professeur, ou injoignable : son onglet le dira
                print(f"cours {c} : {erreur}")
                return False
        return False

    if any(await asyncio.gather(*map(un, [*PAQUET.cours, *map(noyau.cours_masque, PAQUET.cours_masques)]))):
        print("cours reçu")
        if FENETRE:
            FENETRE.paquet.recharger_cours()


def locale():
    """La copie rangée dans le navigateur et la date de son dernier enregistrement (ms), ou (None, 0)."""
    return stockage.lire(cle()), float(stockage.lire(cle() + "|date") or 0)


def chemin_distant():
    """Où va la copie dans le dossier du professeur : <dossier du sujet>/Copies/[<classe>/]<sujet>/<sujet> [<élève>].qcm, suivi
    de « (2ème essai) »… pour les essais suivants d'une révision."""
    return "/" + codes.chemin_copie(PAQUET.inscrits, CLASSE, PAQUET.nom or PAQUET.titre, PAQUET.eleve, PAQUET.dossier, PAQUET.essai)


async def distante():
    """La copie déposée chez le professeur sous ce nom : ``(objet JS {copie, date}, son empreinte)``, ou ``(None, "")``."""
    trouvee = await service("lire")(chemin_distant())
    if not trouvee:
        return None, ""
    if trouvee.date == DEPOSEE:
        return trouvee, EMPREINTE
    Path(AUTRE).write_text(trouvee.copie, encoding="utf-8")
    try:
        with noyau.en_donnees():  # l'empreinte seule : sans écran
            return trouvee, charger(AUTRE, MOT).empreinte
    except Exception as erreur:  # noqa: BLE001 - illisible (autre clé, fichier abîmé) : ni reprise, ni garde
        print(f"copie du professeur illisible ({erreur})")
        return None, ""


async def reprendre_puis_afficher():
    """La copie à reprendre, celle du navigateur ou celle déposée chez le professeur : l'élève reprend là où il en
    était, y compris sur un autre appareil. Celle du professeur n'est reprise que si ce navigateur n'en a pas, ou si elle n'est
    pas celle qu'il y a lui-même déposée ou reprise en dernier (``|deposee``) : un autre appareil a écrit depuis. Pas de
    comparaison de dates, qui viennent de deux horloges : une soumission faite pendant un envoi, ou une heure de la page en
    retard, faisait reprendre la copie d'avant et rouvrait la question soumise (01/10/2026). Sans cette trace (copie d'avant ce
    jour), les dates décident encore. Une copie gardée par un autre code personnel ferme l'épreuve ; une copie sans code
    n'est pas reprise par qui en donne un : elle peut être d'un autre."""
    copie, date = locale()
    connue = float(stockage.lire(cle() + "|deposee") or 0)
    try:
        trouvee, garde = await distante()
        if garde and garde != EMPREINTE:
            refus = PROTEGEE.format(PAQUET.eleve)
            statut(refus, True)
            if ACCUEIL:
                ACCUEIL.refuser(refus)
                signaler("accueil")
            return
        if trouvee and garde == EMPREINTE:
            if not copie or (trouvee.date != connue if connue else trouvee.date > date):
                copie = trouvee.copie
            retenir_depot(trouvee.date)
    except Exception as erreur:  # noqa: BLE001 - le professeur injoignable n'empêche pas l'épreuve
        print(f"copie du professeur injoignable ({erreur})")
    afficher(copie)


def afficher(copie):
    """La fenêtre du lecteur, sur la copie si elle se relit, sur le sujet sinon."""
    global FENETRE, PAQUET
    if copie:
        try:
            Path(CHEMIN).write_text(copie, encoding="utf-8")
            with noyau.en_donnees():  # l'écran, une fois, par ``Lecteur`` : lue avec le sien, la copie le construisait pour
                eleve, PAQUET = PAQUET.eleve, charger(CHEMIN, MOT)  # rien (python_tp : 4 s de plus que le sujet, 02/10/2026)
            PAQUET.eleve, PAQUET.empreinte = eleve, EMPREINTE
            PAQUET.limite = PAQUET.limite or LIMITE  # celle de la première ouverture ; une copie d'avant le 30/09/2026 ne l'a pas
            print("copie reprise")
        except Exception as erreur:  # noqa: BLE001 - une copie illisible ne doit pas empêcher l'épreuve
            print(f"copie illisible ({erreur}) : le sujet repart de zéro")
    document.title = PAQUET.titre.replace("\n", " ")
    FENETRE = Lecteur(CHEMIN, PAQUET, MOT, maitre=maitre())
    PAQUET = FENETRE.paquet  # l'écran du paquet en données de l'accueil (``Lecteur``)
    FENETRE.enregistree.connect(ranger)
    FENETRE.recommencer = lambda: asyncio.ensure_future(nouvel_essai())
    for cible, nom in ((window, "pagehide"), (document, "visibilitychange")):  # page fermée ou cachée : l'enregistrement
        cible.addEventListener(nom, create_proxy(lambda *_: FENETRE.differe.isActive() and FENETRE.enregistrer()))  # différé, tout de suite
    FENETRE.showFullScreen()  # tout le canevas, sans barre de titre : l'élève ne peut ni fermer ni réduire la fenêtre
    FENETRE.differe.start()  # la première sauvegarde (le paquet entier sérialisé, ≈ 50 ms) après la main rendue ; la page
    # qui se cache ou se ferme d'ici là la fait tout de suite (02/10/2026)
    if FENETRE.surveillee():
        surveiller()
    signaler("epreuve")


async def nouvel_essai():
    """« Nouvel essai » : la copie rendue part d'abord chez le professeur, sous son nom, puis l'essai suivant prend sa place
    (``Paquet.nouvel_essai_suivant``), sous le sien (``cle``, ``chemin_distant``) ; repris s'il a déjà été commencé, ici ou
    ailleurs. L'ancienne fenêtre n'écrit plus rien : sa fermeture réécrirait sa copie par-dessus la nouvelle."""
    global PAQUET
    ancienne = FENETRE
    ancienne.enregistrer()
    if A_ENVOYER:
        await envoyer()
    ancienne.chemin = None
    with noyau.en_donnees():
        PAQUET = ancienne.paquet.nouvel_essai_suivant()
    if service("lire"):
        await reprendre_puis_afficher()
    else:
        afficher(locale()[0])
    ancienne.close()


def maitre():
    """Le professeur, entré par son mot de passe : pas d'anti-triche pour lui (``Lecteur.surveillee``). Avant le 03/10/2026,
    sa copie d'élève rouverte tombait sous l'écran noir, qui inscrivait même une sortie dans la copie."""
    return bool(ACCUEIL and ACCUEIL.maitre)


def agrandir():
    """La page en plein écran ; le navigateur ne l'accorde que juste après un clic ou une touche, et le refus est sans suite.
    Chrome et Edge laissent aussi la page capter le clavier en plein écran (``navigator.keyboard.lock``, 29/09/2026) : Échap ne
    fait plus sortir qu'appuyée longuement, et Alt+Tab ou la touche Windows vont à la page quand le système le permet.
    Firefox et Safari ne l'ont pas : la sortie y reste possible, et c'est la surveillance qui la voit."""
    getattr(document.documentElement.requestFullscreen(), "catch")(create_proxy(lambda _: None))
    clavier = getattr(window.navigator, "keyboard", None)
    if clavier is not None:  # Chrome et Edge seuls ont navigator.keyboard, et lock avec
        getattr(clavier.lock(), "catch")(create_proxy(lambda _: None))


def present():
    """L'élève est sur l'épreuve : onglet visible, page active, en plein écran (le ``null`` de JS arrive en ``jsnull``, pas None)."""
    return document.visibilityState == "visible" and document.hasFocus() and document.fullscreenElement not in (None, jsnull)


def surveiller():
    """Un sujet sous ``surveillance`` : l'onglet caché (autre onglet, page fermée ou rechargée), la page qui perd le focus (autre
    application) ou la sortie du plein écran est une sortie (``Lecteur.juger``). Dans le navigateur, Qt ne dit rien de fiable
    là-dessus : ce sont les événements de la page qui le disent, et c'est elle qui passe en plein écran."""
    FENETRE.agrandir, FENETRE.present = agrandir, present
    for cible, nom in ((document, "visibilitychange"), (document, "fullscreenchange"), (window, "blur"), (window, "focus")):
        cible.addEventListener(nom, create_proxy(FENETRE.juger))
    FENETRE.surveiller()


def ranger():
    """Chaque enregistrement du lecteur : la copie dans le navigateur, datée ; puis chez le professeur (au prochain envoi), ou au
    téléchargement quand l'épreuve est finie."""
    global A_ENVOYER
    copie = Path(CHEMIN).read_text(encoding="utf-8")
    if not (stockage.ecrire(cle(), copie) and stockage.ecrire(cle() + "|date", str(horloge.secondes() * 1000))):
        print("copie non rangée dans le navigateur (stockage plein ou interdit)")
    if service("ecrire"):
        A_ENVOYER = True
    elif PAQUET.fin is not None:
        telecharger(copie)


def telecharger(copie):
    stockage.telecharger(chemin_distant().rpartition("/")[2], copie, lien=service("lien"))  # « <sujet> [<élève>].qcm »


async def envoyer_regulierement():
    """Tant que la page vit (``demarrer``) : la copie part dès qu'elle change, au plus une fois par minute pendant l'épreuve
    et cinq secondes après sa fin ; un échec se retente au même rythme."""
    while True:
        await asyncio.sleep(1)
        if A_ENVOYER and time.monotonic() - DERNIER_ENVOI > CADENCE[PAQUET.fin is not None]:
            await envoyer()
        if service("presence") and FENETRE is not None:
            await envoyer_presence()


def presence():
    """Où en est l'élève, pour le plan de classe du professeur : l'état (``epreuve``, ``dehors`` tant que l'écran noir de la
    surveillance le bloque, ``rendue``), les sorties inscrites et l'avancement en % (la jauge du lecteur, ``Paquet._rafraichir_vue``)."""
    feuilles = PAQUET.feuilles
    return {"eleve": PAQUET.eleve, "etat": "rendue" if PAQUET.fin is not None else "dehors" if FENETRE.leve == math.inf else "epreuve",
            "sorties": len(PAQUET.sorties), "avancement": round(100 * sum(f.avancement() for f in feuilles) / len(feuilles)) if feuilles else 0}


async def envoyer_presence():
    """Le témoin de présence à côté de la copie (``chemin_distant``, « .etat.json ») : une sortie ou un retour part dans les 2 s,
    un nouvel avancement au bout de 15 s (25 élèves partagent la limite d'appels du compte Dropbox du professeur), et le
    battement toutes les minutes dit au plan que l'élève est encore là. Un échec n'est pas dit à l'élève (le témoin est
    facultatif, et l'envoi de la copie le dit déjà) : le prochain tour le retente."""
    global PRESENCE, DERNIERE_PRESENCE
    etat, avant = presence(), PRESENCE
    delai = 60 if avant == etat else 2 if avant is None or avant["etat"] != etat["etat"] or avant["sorties"] != etat["sorties"] else 15
    if time.monotonic() - DERNIERE_PRESENCE < delai:
        return
    DERNIERE_PRESENCE = time.monotonic()
    try:
        await service("presence")(chemin_distant().removesuffix(".qcm") + ".etat.json", json.dumps(etat))
        PRESENCE = etat
    except Exception as erreur:  # noqa: BLE001 - réseau, quota : le témoin est facultatif
        print(f"témoin de présence non envoyé ({erreur})")


async def envoyer():
    """La copie chez le professeur ; la page dit à l'élève ce qu'il en est, et lui offre la copie si l'envoi échoue à la fin."""
    global A_ENVOYER, DERNIER_ENVOI
    A_ENVOYER, DERNIER_ENVOI = False, time.monotonic()
    try:
        await deposer()
        statut("")  # un envoi réussi ne se dit pas (l'utilisateur, 02/10/2026 : « il faut supprimer ce bandeau ») ; il efface l'échec
    except Exception as erreur:  # noqa: BLE001 - réseau, quota, script : on réessaie
        A_ENVOYER = True
        finie = PAQUET.fin is not None
        statut(f"La copie n'a pas pu être envoyée ({erreur}) : nouvel essai dans un instant."
               + (" En attendant, téléchargez-la et remettez-la au professeur." if finie else ""), True)
        if finie:
            telecharger(Path(CHEMIN).read_text(encoding="utf-8"))


async def deposer():
    """La copie à sa place chez le professeur, sauf si ce nom y est gardé par un autre code personnel ; celle qu'on avait
    déposée sous ce nom sans code, quand l'élève arrive avec le sien, est mise de côté (« … (sans code).qcm »)."""
    chemin = chemin_distant()
    trouvee, garde = await distante()
    if garde and garde != EMPREINTE:
        raise PermissionError(PROTEGEE.format(PAQUET.eleve))
    if trouvee and not garde and EMPREINTE:
        await service("deplacer")(chemin, chemin.removesuffix(".qcm") + " (sans code).qcm")
    retenir_depot(await service("ecrire")(chemin, Path(CHEMIN).read_text(encoding="utf-8")))


def retenir_depot(date):
    """La date de la copie du professeur que cette page vient de déposer ou de reprendre : en mémoire pour la garde
    (``distante``), dans le navigateur pour la prochaine reprise (``reprendre_puis_afficher``)."""
    global DEPOSEE
    DEPOSEE = date
    stockage.ecrire(cle() + "|deposee", str(date))


def statut(texte, erreur=False):
    if service("statut"):
        service("statut")(texte, erreur)


def signaler(etat):
    if service("etat"):
        service("etat")(etat)
