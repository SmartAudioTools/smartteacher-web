"""Le pont de la page PyQt6-WASM (page.html) : le lecteur natif tel quel dans le navigateur.

Le sujet arrive en octets ; l'élève passe par la boîte d'accueil du lecteur natif (``lecteur.Accueil`` : nom, prénom, code de
déverrouillage s'il en faut un), dans le canevas, puis la fenêtre de ``lecteur.py`` le remplit. La copie est le fichier que
``Lecteur.enregistrer`` réécrit : du texte, chiffrée comprise (l'armure ASCII d'age, ``modele.sauver``), rangée dans le
navigateur à chaque enregistrement (``qtpy6.web.stockage``, sous le titre et le nom, avec sa date) et reprise si la page se
recharge. Quand la page est reliée au professeur (son dossier Dropbox : ``DROPBOX`` de ``page.html``, ``dropbox.js``), la copie part aussi chez
lui, toutes les minutes tant que l'épreuve dure et cinq secondes après sa fin, et c'est la plus récente des deux copies,
celle du navigateur ou celle du professeur, qui est reprise, sur n'importe quel appareil ; sans professeur, elle est offerte
au téléchargement quand l'épreuve est finie.

Chez le professeur, la copie est le seul fichier (plus de fiche à côté, 27/09/2026) : ``codes.chemin_copie`` la range dans
le dossier du sujet, par classe et sujet, Dropbox la date (``server_modified``, l'heure de son serveur, pas celle de l'élève), et la garde du
code personnel se vérifie en la déchiffrant (``Paquet.empreinte``) — sauf quand elle est encore celle que cette page a
déposée ou reprise, reconnue à sa date."""

import asyncio
import time
from datetime import datetime, timezone
from pathlib import Path

import codes
import horloge
from js import document, window  # Pyodide : le titre de l'onglet, la sortie de la page (surveiller)
from pyodide.ffi import create_proxy, jsnull
from lecteur import Lecteur, accueillir, emplacements_du_cours
from modele import GardeCopie, application, charger
from qtpy6.web import stockage, tactile, travailleur

PARENTS = 8  # les dossiers parents du sujet où chercher un cours sous son nom (emplacements_du_cours)
CHEMIN = "/sujet.qcm"  # le sujet, puis la copie que le lecteur y réécrit
AUTRE = "/distante.qcm"  # une copie déposée chez le professeur, déchiffrée pour lire son empreinte
PROTEGEE = "{} a protégé sa copie par son code personnel : sans lui, ce nom n'est pas accepté."
CADENCE = 60, 5  # secondes entre deux envois au professeur : pendant l'épreuve, après sa fin
APP = application()  # charge aussi les polices de lecteur.zip
if tactile.detecte():  # un doigt parmi les pointeurs : téléphone, tablette, portable tactile
    tactile.activer(APP)
GardeCopie(APP)
SUJET = ACCUEIL = FENETRE = PAQUET = MOT = PAGE = ENVOIS = None
EMPREINTE = ""  # celle du code personnel que l'élève a donné à l'accueil (son contrôle lent, codes.inscrire) : elle garde sa copie chez le professeur
CLASSE = LIMITE = None  # la classe du code donné à l'accueil (None : sans classe) et sa date limite (UTC), ou None
DEPOSEE = None  # la date (ms, Dropbox) de la dernière copie que cette page a déposée ou reprise : tant que c'est elle, elle est à l'élève
A_ENVOYER = False  # la copie a changé depuis le dernier envoi au professeur
DERNIER_ENVOI = float("-inf")  # time.monotonic() du début du dernier envoi : le premier part dès la première copie


def configurer(pyodide):
    """Avant tout : les sous-processus des questions code (console_enfant.py de leur console, verifier.py de leur correction)
    tournent tels quels dans des Web Workers sous le Pyodide ORDINAIRE, à ``pyodide`` (URL relative à la page, ou absolue) :
    ``QProcess`` et ``subprocess.run`` de qtpy6.web."""
    travailleur.configurer(pyodide)


def service(nom):
    """Ce que la page a fourni sous ce nom (``demarrer``), ou None."""
    return getattr(PAGE, nom, None) if PAGE is not None else None


def cle():
    """La place de la copie dans le navigateur : le même élève qui rouvre le même sujet la retrouve."""
    return f"smartteacher-qt|{PAQUET.nom or PAQUET.titre}|{PAQUET.eleve.lower()}"


def demarrer(contenu, eleve="", page=None, jeton=""):
    """Le ``.qcm`` (octets) : l'accueil, puis l'épreuve plein canevas. ``eleve`` : « Nom Prénom » déjà connu (la sonde,
    ``?eleve=``), l'accueil est sauté si le sujet s'ouvre sans code. ``jeton`` : le code de la classe tel que le lien le
    porte (``?code=``, ``codes.jeton``), déjà dans l'accueil : l'élève n'a que son nom à taper. ``page`` : ce que la page
    offre, un objet JS dont chaque membre est facultatif :
        lien                      l'élément <a> qui reçoit la copie à télécharger (sans lui, le téléchargement part tout seul)
        etat(e)                   prévenue de ce qui est à l'écran : "accueil", puis "epreuve"
        statut(texte, erreur)     une ligne pour l'élève sur le sort de sa copie (envoyée, reprise, en échec)
        lire(chemin)              Promise du fichier ``chemin`` du dossier du professeur, {copie (texte), date (ms)}, ou null
        ecrire(chemin, copie)     Promise de la date (ms) du fichier écrit ; sa présence fait partir la copie chez le
                                  professeur plutôt qu'au téléchargement
        deplacer(de, vers)        Promise : ``de`` renommé ``vers`` (un numéro ajouté si ``vers`` existe), rien s'il n'existe pas
        cours(chemin)             Promise des octets (Uint8Array) d'un PDF du cours, ``chemin`` depuis le dossier du sujet
                                  (``Paquet.cours``), ou null
    Rend ``"accueil"`` ou ``"epreuve"`` : ce qui est à l'écran, ou va l'être dès la réponse du professeur."""
    global SUJET, ACCUEIL, PAGE, ENVOIS
    SUJET, PAGE = bytes(contenu), page
    Path(CHEMIN).write_bytes(SUJET)
    if ENVOIS is None and service("ecrire"):
        ENVOIS = asyncio.ensure_future(envoyer_regulierement())
    ACCUEIL = accueillir(CHEMIN, montrer, codes.phrase_du_jeton(jeton), eleve)
    if ACCUEIL:
        signaler("accueil")
    return "accueil" if ACCUEIL else "epreuve"


def montrer(paquet, mot):
    """Après l'accueil : la copie la plus récente, s'il y en a une, reprend la place du sujet, et la fenêtre du lecteur remplit
    le canevas. L'accueil appelle sans attendre de retour ; la copie du professeur, elle, s'attend."""
    global PAQUET, MOT, EMPREINTE, CLASSE, LIMITE
    PAQUET, MOT = paquet, mot
    if paquet.surveillance:  # tout de suite, pendant que le clic de l'accueil l'autorise ; afficher peut attendre le professeur
        agrandir()
    # posées par l'accueil (``Accueil.nommer``), même sauté : l'élève nommé par le lien, sur un code sans classe
    EMPREINTE, LIMITE, CLASSE = paquet.empreinte, paquet.limite, ACCUEIL and ACCUEIL.classe
    if service("lire") or (paquet.cours and service("cours")):
        asyncio.ensure_future(cours_puis_afficher())
    else:
        afficher(locale()[0])


async def cours_puis_afficher():
    """Les PDF du cours (``Paquet.cours``, que le .qcm n'embarque pas) lus chez le professeur, au premier de leurs
    ``emplacements_du_cours``, puis posés à côté du sujet, où ``lecteur.cours_a_cote`` les trouve sous leur nom ; puis la
    copie la plus récente, s'il faut la chercher chez lui."""
    for chemin in PAQUET.cours if service("cours") else []:
        for c in emplacements_du_cours(chemin, PARENTS):
            try:
                if octets := await service("cours")(c):
                    (Path(CHEMIN).parent / Path(chemin).name).write_bytes(octets.to_bytes())
                    break
            except Exception as erreur:  # noqa: BLE001 - hors du dossier du professeur, ou injoignable : son onglet le dira
                print(f"cours {c} : {erreur}")
                break
    if service("lire"):
        await reprendre_puis_afficher()
    else:
        afficher(locale()[0])


def locale():
    """La copie rangée dans le navigateur et la date de son dernier enregistrement (ms), ou (None, 0)."""
    return stockage.lire(cle()), float(stockage.lire(cle() + "|date") or 0)


def chemin_distant():
    """Où va la copie dans le dossier du professeur : <dossier du sujet>/Copies/[<classe>/]<sujet>/<sujet> [<élève>].qcm."""
    return "/" + codes.chemin_copie(PAQUET.inscrits, CLASSE, PAQUET.nom or PAQUET.titre, PAQUET.eleve, PAQUET.dossier)


async def distante():
    """La copie déposée chez le professeur sous ce nom : ``(objet JS {copie, date}, son empreinte)``, ou ``(None, "")``."""
    trouvee = await service("lire")(chemin_distant())
    if not trouvee:
        return None, ""
    if trouvee.date == DEPOSEE:
        return trouvee, EMPREINTE
    Path(AUTRE).write_text(trouvee.copie, encoding="utf-8")
    try:
        return trouvee, charger(AUTRE, MOT).empreinte
    except Exception as erreur:  # noqa: BLE001 - illisible (autre clé, fichier abîmé) : ni reprise, ni garde
        print(f"copie du professeur illisible ({erreur})")
        return None, ""


async def reprendre_puis_afficher():
    """La copie à reprendre, celle du navigateur ou celle déposée chez le professeur : l'élève reprend là où il en
    était, y compris sur un autre appareil. Celle du professeur n'est reprise que si ce navigateur n'en a pas, ou si elle n'est
    pas celle qu'il y a lui-même déposée ou reprise en dernier (``|deposee``) : un autre appareil a écrit depuis. Pas de
    comparaison de dates, qui viennent de deux horloges : une soumission faite pendant un envoi, ou une heure de la page en
    retard, faisait reprendre la copie d'avant et rouvrait la question soumise (01/10/2026). Sans cette trace (copie d'avant ce
    jour), les dates décident encore. Une copie gardée par un autre code personnel ferme l'épreuve ; une copie sans code
    n'est pas reprise par qui en donne un : elle peut être d'un autre."""
    copie, date = locale()
    connue = float(stockage.lire(cle() + "|deposee") or 0)
    statut("Recherche d'une copie déjà envoyée…")
    try:
        trouvee, garde = await distante()
        if garde and garde != EMPREINTE:
            refus = PROTEGEE.format(PAQUET.eleve)
            statut(refus, True)
            if ACCUEIL:
                ACCUEIL.refuser(refus)
                signaler("accueil")
            return
        if trouvee and garde == EMPREINTE:
            if not copie or (trouvee.date != connue if connue else trouvee.date > date):
                copie = trouvee.copie
                statut(f"Copie reprise depuis le professeur (envoyée le {quand(trouvee.date)}).")
            retenir_depot(trouvee.date)
    except Exception as erreur:  # noqa: BLE001 - le professeur injoignable n'empêche pas l'épreuve
        print(f"copie du professeur injoignable ({erreur})")
    afficher(copie)


def afficher(copie):
    """La fenêtre du lecteur, sur la copie si elle se relit, sur le sujet sinon."""
    global FENETRE, PAQUET
    if copie:
        try:
            Path(CHEMIN).write_text(copie, encoding="utf-8")
            eleve, PAQUET = PAQUET.eleve, charger(CHEMIN, MOT)
            PAQUET.eleve, PAQUET.empreinte = eleve, EMPREINTE
            PAQUET.limite = PAQUET.limite or LIMITE  # celle de la première ouverture ; une copie d'avant le 30/09/2026 ne l'a pas
            print("copie reprise")
        except Exception as erreur:  # noqa: BLE001 - une copie illisible ne doit pas empêcher l'épreuve
            print(f"copie illisible ({erreur}) : le sujet repart de zéro")
    document.title = PAQUET.titre.replace("\n", " ")
    FENETRE = Lecteur(CHEMIN, PAQUET, MOT)
    FENETRE.enregistree.connect(ranger)
    FENETRE.showFullScreen()  # tout le canevas, sans barre de titre : l'élève ne peut ni fermer ni réduire la fenêtre
    FENETRE.enregistrer()
    if PAQUET.surveillance:
        surveiller()
    signaler("epreuve")


def agrandir():
    """La page en plein écran ; le navigateur ne l'accorde que juste après un clic ou une touche, et le refus est sans suite.
    Chrome et Edge laissent aussi la page capter le clavier en plein écran (``navigator.keyboard.lock``, 29/09/2026) : Échap ne
    fait plus sortir qu'appuyée longuement, et Alt+Tab ou la touche Windows vont à la page quand le système le permet.
    Firefox et Safari ne l'ont pas : la sortie y reste possible, et c'est la surveillance qui la voit."""
    getattr(document.documentElement.requestFullscreen(), "catch")(create_proxy(lambda _: None))
    clavier = getattr(window.navigator, "keyboard", None)
    if clavier is not None:  # Chrome et Edge seuls ont navigator.keyboard, et lock avec
        getattr(clavier.lock(), "catch")(create_proxy(lambda _: None))


def present():
    """L'élève est sur l'épreuve : onglet visible, page active, en plein écran (le ``null`` de JS arrive en ``jsnull``, pas None)."""
    return document.visibilityState == "visible" and document.hasFocus() and document.fullscreenElement not in (None, jsnull)


def surveiller():
    """Un sujet sous ``surveillance`` : l'onglet caché (autre onglet, page fermée ou rechargée), la page qui perd le focus (autre
    application) ou la sortie du plein écran est une sortie (``Lecteur.juger``). Dans le navigateur, Qt ne dit rien de fiable
    là-dessus : ce sont les événements de la page qui le disent, et c'est elle qui passe en plein écran."""
    FENETRE.agrandir, FENETRE.present = agrandir, present
    for cible, nom in ((document, "visibilitychange"), (document, "fullscreenchange"), (window, "blur"), (window, "focus")):
        cible.addEventListener(nom, create_proxy(FENETRE.juger))
    FENETRE.surveiller()


def ranger():
    """Chaque enregistrement du lecteur : la copie dans le navigateur, datée ; puis chez le professeur (au prochain envoi), ou au
    téléchargement quand l'épreuve est finie."""
    global A_ENVOYER
    copie = Path(CHEMIN).read_text(encoding="utf-8")
    if not (stockage.ecrire(cle(), copie) and stockage.ecrire(cle() + "|date", str(horloge.secondes() * 1000))):
        print("copie non rangée dans le navigateur (stockage plein ou interdit)")
    if service("ecrire"):
        A_ENVOYER = True
    elif PAQUET.fin is not None:
        telecharger(copie)


def telecharger(copie):
    stockage.telecharger(chemin_distant().rpartition("/")[2], copie, lien=service("lien"))  # « <sujet> [<élève>].qcm »


async def envoyer_regulierement():
    """Tant que la page vit (``demarrer``) : la copie part dès qu'elle change, au plus une fois par minute pendant l'épreuve
    et cinq secondes après sa fin ; un échec se retente au même rythme."""
    while True:
        await asyncio.sleep(1)
        if A_ENVOYER and time.monotonic() - DERNIER_ENVOI > CADENCE[PAQUET.fin is not None]:
            await envoyer()


async def envoyer():
    """La copie chez le professeur ; la page dit à l'élève ce qu'il en est, et lui offre la copie si l'envoi échoue à la fin."""
    global A_ENVOYER, DERNIER_ENVOI
    A_ENVOYER, DERNIER_ENVOI = False, time.monotonic()
    try:
        await deposer()
        statut(f"Copie envoyée au professeur à {quand(horloge.secondes() * 1000)}.")
    except Exception as erreur:  # noqa: BLE001 - réseau, quota, script : on réessaie
        A_ENVOYER = True
        finie = PAQUET.fin is not None
        statut(f"La copie n'a pas pu être envoyée ({erreur}) : nouvel essai dans un instant."
               + (" En attendant, téléchargez-la et remettez-la au professeur." if finie else ""), True)
        if finie:
            telecharger(Path(CHEMIN).read_text(encoding="utf-8"))


async def deposer():
    """La copie à sa place chez le professeur, sauf si ce nom y est gardé par un autre code personnel ; celle qu'on avait
    déposée sous ce nom sans code, quand l'élève arrive avec le sien, est mise de côté (« … (sans code).qcm »)."""
    chemin = chemin_distant()
    trouvee, garde = await distante()
    if garde and garde != EMPREINTE:
        raise PermissionError(PROTEGEE.format(PAQUET.eleve))
    if trouvee and not garde and EMPREINTE:
        await service("deplacer")(chemin, chemin.removesuffix(".qcm") + " (sans code).qcm")
    retenir_depot(await service("ecrire")(chemin, Path(CHEMIN).read_text(encoding="utf-8")))


def retenir_depot(date):
    """La date de la copie du professeur que cette page vient de déposer ou de reprendre : en mémoire pour la garde
    (``distante``), dans le navigateur pour la prochaine reprise (``reprendre_puis_afficher``)."""
    global DEPOSEE
    DEPOSEE = date
    stockage.ecrire(cle() + "|deposee", str(date))


def quand(ms):
    return horloge.locale(datetime.fromtimestamp(ms / 1000, timezone.utc)).strftime("%d/%m/%Y à %H:%M")


def statut(texte, erreur=False):
    if service("statut"):
        service("statut")(texte, erreur)


def signaler(etat):
    if service("etat"):
        service("etat")(etat)
