"""Les deux éditeurs de code du lecteur : celui où l'élève écrit, et celui où il remet des lignes dans l'ordre.

``EditeurCode`` sert aux questions de type ``code`` : Tab et Maj+Tab y déplacent d'un niveau d'indentation les
lignes touchées, au lieu d'insérer une tabulation ; le code donné par la question s'y montre en bleu, ce que
l'élève tape au clavier en violet, pour qu'il voie d'un coup d'oeil ce qui est de lui, et les commentaires en gris. ``EditeurLignes`` sert aux questions
de type ``ordre`` écrites en Python : le texte ne s'y modifie pas, seuls l'ordre des lignes et leur indentation
changent, à la souris (ou Tab pour l'indentation) — l'élève voit le code tel qu'il s'exécutera, ce qu'une liste
d'éléments à côté du code ne montre pas.
"""

import re
from difflib import SequenceMatcher

from qtpy6.QtCore import QEvent, QObject, QPoint, QPointF, Qt, Signal
from qtpy6.QtGui import (QColor, QFontDatabase, QFontMetricsF, QKeySequence, QMouseEvent, QPainter, QPen, QTextCharFormat,
                         QTextCursor, QTextDocument)
from qtpy6.QtWidgets import QApplication, QPlainTextDocumentLayout, QPlainTextEdit, QTextEdit, QWidget
from qtpy6.web import tactile

from noyau import zones_du_gabarit
from texte_md import BLEU_CODE, GRIS, MONO, commentaires

PAS = 4  # un niveau d'indentation, en espaces
PRISE = "#dcf5d0"  # la ligne qu'on déplace, du premier au dernier caractère, tant que le clic est enfoncé : vert très clair (28/09/2026)
# Les deux couleurs du code se séparent par la teinte et la clarté (le violet, construit en 2026 contre un bleu
# #2d7dd2 plus sombre, l'est désormais nettement) ; il reste plus clair et moins saturé que le fuchsia de l'invite.
DONNE = BLEU_CODE  # le code donné par la question, tant qu'il est intact : le bleu du code des énoncés (28/09/2026)
ELEVE = "#7b5abe"  # ce que l'élève a écrit par-dessus : violet (L* 46, 5,2:1)
COMMENTAIRE = GRIS  # les commentaires, de qui qu'ils soient : le gris de ceux du cours (l'utilisateur, 03/10/2026)
RETRAIT_COLLE = re.compile(r"^\$+", re.M)  # l'indentation d'un code collé du cours, en « $ » (texte_md.indentation_visible)
GUIDE = "#e2e2e2"  # les repères d'indentation : gris très clair, présents sans se lire comme du texte
MARGE_FOND, MARGE_TEXTE = "#f0f0f0", "#909090"  # la colonne des numéros de ligne, discrète : elle se lit, elle ne s'impose pas
INTERLIGNE = 0.4  # d'une hauteur de ligne, ajouté sous chaque ligne du code : le code s'aère (l'utilisateur, 28/09/2026)
ZONE = "#fff4cc"  # le fond des lignes à compléter d'un code verrouillé : jaune très clair, là où l'élève écrit


class Disposition(QPlainTextDocumentLayout):
    """La mise en page de l'éditeur, qui aère les lignes. QPlainTextEdit ignore l'interligne d'un bloc (``lineHeight``
    comme les marges haute et basse : essayés, hauteur inchangée) ; il suit en revanche, pour peindre comme pour
    viser à la souris, la hauteur que sa disposition déclare pour chaque bloc : l'espace s'y ajoute, sous la ligne."""

    def ecart(self):
        return round(INTERLIGNE * QFontMetricsF(self.document().defaultFont()).lineSpacing())

    def blockBoundingRect(self, bloc):
        return super().blockBoundingRect(bloc).adjusted(0, 0, 0, self.ecart())


class Marge(QWidget):
    """La colonne des numéros de ligne, collée à gauche de l'éditeur : c'est ce qui le distingue de la console."""

    def __init__(self, editeur):
        super().__init__(editeur)
        self.editeur = editeur

    def paintEvent(self, evenement):
        self.editeur.peindre_marge(evenement)


class EditeurCode(QPlainTextEdit):
    """Un éditeur dans la police du code des énoncés (``MONO``), où Tab et Maj+Tab indentent, au lieu d'insérer une tabulation ou de changer de widget."""

    TEINTE = True  # chaque caractère garde la couleur de sa provenance ; EditeurLignes peint autrement
    annulation = Signal()  # ce qu'il y a à défaire a changé sans que le texte bouge : seul un rangement fait cela

    def __init__(self, texte="", fixes=None, premiere=1):
        super().__init__()
        # ``fixes`` : les parties du code donné que l'élève ne peut pas modifier (``Code.gabarit``), ``None`` si tout
        # s'écrit. Il écrit entre deux parties consécutives ; ce qui toucherait une partie fixe est refusé.
        self.fixes, self._retour = fixes, False
        self.repris = []  # dans les parties fixes, le code que l'élève a écrit à une autre question (``reprend``) : en violet
        self.premiere = premiere  # le numéro de la première ligne (``Code.premiere_ligne``) ; sous 1, pas de numéro
        self.disposition = Disposition(self.document())  # gardée : sous PySide6, l'objet Python ramassé laisse Qt sur
        self.document().setDocumentLayout(self.disposition)  # un pointeur mort (plantage) ; posée avant le texte
        self.donne = texte  # le code de la question, en bleu tant que l'élève n'y touche pas
        self.setPlainText(texte)
        self.marge = Marge(self)  # avant setFont, qui passe par changeEvent
        police = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        police.setFamily(MONO)  # celle du code des énoncés ; la taille reste celle de la zone qui défile
        self.setFont(police)
        self.blockCountChanged.connect(lambda _: self._poser_marge())
        self.updateRequest.connect(self._suivre_marge)
        self.textChanged.connect(self._garder)
        self.textChanged.connect(self._teinter)
        self._poser_marge()
        self._teinter()

    # Les numéros de ligne ---------------------------------------------------------------------------------

    def largeur_marge(self):
        return 10 + self.fontMetrics().horizontalAdvance("9") * len(str(max(1, self.blockCount() + self.premiere - 1)))

    def _poser_marge(self):
        self.setViewportMargins(self.largeur_marge(), 0, 0, 0)
        cadre = self.contentsRect()
        self.marge.setGeometry(cadre.x(), cadre.y(), self.largeur_marge(), cadre.height())

    def _suivre_marge(self, rectangle, dy):
        """La marge défile avec le texte, et se redessine quand une ligne apparaît ou disparaît."""
        if dy:
            self.marge.scroll(0, dy)
        else:
            self.marge.update(0, rectangle.y(), self.marge.width(), rectangle.height())

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self._poser_marge()

    def changeEvent(self, evenement):
        """La feuille de style du sujet agrandit la police une fois l'éditeur construit : la marge suit, sinon elle
        mord sur le début des lignes."""
        super().changeEvent(evenement)
        if evenement.type() == QEvent.Type.FontChange:
            self._poser_marge()

    def peindre_marge(self, evenement):
        peintre = QPainter(self.marge)
        peintre.fillRect(evenement.rect(), QColor(MARGE_FOND))
        peintre.setPen(QColor(MARGE_TEXTE))
        bloc = self.firstVisibleBlock()
        haut = self.blockBoundingGeometry(bloc).translated(self.contentOffset()).top()
        while bloc.isValid() and haut <= evenement.rect().bottom():
            bas = haut + self.blockBoundingRect(bloc).height()
            numero = bloc.blockNumber() + self.premiere
            if bas >= evenement.rect().top() and numero >= 1:
                peintre.drawText(0, int(haut), self.marge.width() - 5, self.fontMetrics().height(),
                                 Qt.AlignmentFlag.AlignRight, str(numero))
            bloc, haut = bloc.next(), bas

    # Les repères d'indentation ---------------------------------------------------------------------------

    def paintEvent(self, evenement):
        """Un pointillé vertical à chaque niveau d'indentation que la ligne a franchi, comme les lignes de la copie
        papier : on voit d'un coup d'oeil jusqu'où va un bloc. Une ligne vide prend le niveau le plus bas de ses
        voisines non vides, pour que le trait d'un bloc ne s'interrompe pas sur une ligne blanche en son milieu."""
        super().paintEvent(evenement)
        peintre = QPainter(self.viewport())
        stylo = QPen(QColor(GUIDE), 1, Qt.PenStyle.DotLine)
        peintre.setPen(stylo)
        colonne = self.fontMetrics().horizontalAdvance(" " * PAS)
        gauche = self.contentOffset().x() + self.document().documentMargin()
        bloc = self.firstVisibleBlock()
        haut = self.blockBoundingGeometry(bloc).translated(self.contentOffset()).top()
        while bloc.isValid() and haut <= evenement.rect().bottom():
            bas = haut + self.blockBoundingRect(bloc).height()
            for niveau in range(self._niveau(bloc)):
                x = int(gauche + niveau * colonne) + 1
                peintre.drawLine(x, int(haut), x, int(bas) - 1)
            bloc, haut = bloc.next(), bas

    @staticmethod
    def _niveau(bloc):
        texte = bloc.text()
        if texte.strip():
            return (len(texte) - len(texte.lstrip(" "))) // PAS
        voisins = []
        for pas in (lambda b: b.previous(), lambda b: b.next()):
            b = pas(bloc)
            while b.isValid() and not b.text().strip():
                b = pas(b)
            voisins.append(EditeurCode._niveau(b) if b.isValid() else 0)
        return min(voisins)

    # Le code donné par la question ------------------------------------------------------------------------

    @staticmethod
    def _couleur(couleur):
        marque = QTextCharFormat()
        marque.setForeground(QColor(couleur))
        return marque

    def setPlainText(self, texte):
        """Le texte remplacé d'un coup (question qui démarre, copie rechargée) : chaque caractère prend la couleur de
        sa provenance, dans le document lui-même, que Qt fait suivre aux frappes, aux collages et à l'annulation.

        Le code donné est bleu, le reste violet. Une copie rechargée n'a plus l'historique de ses frappes : y redevient
        bleu ce qui coïncide avec le code donné sur trois caractères au moins (en deçà, des lettres isolées du code
        tapé s'apparieraient au hasard)."""
        super().setPlainText(texte)
        if not self.TEINTE:
            return
        document = self.document()
        document.setUndoRedoEnabled(False)  # setPlainText vient de vider la pile : la couleur n'y entre pas
        try:
            curseur = QTextCursor(document)
            curseur.select(QTextCursor.SelectionType.Document)
            curseur.mergeCharFormat(self._couleur(ELEVE))
            if self.fixes:
                zones, debut = self.zones(), 0
                bleus = []
                for d, f in [*zones, (len(texte), len(texte))]:
                    bleus.append((debut, d - debut))
                    debut = f
            elif self.donne:
                bleus = [(b, n) for _, b, n in SequenceMatcher(None, self.donne, texte, autojunk=False).get_matching_blocks()
                         if n >= 3 or texte == self.donne]
            else:
                bleus = []
            for debut, taille in bleus:
                curseur.setPosition(debut)
                curseur.setPosition(debut + taille, QTextCursor.MoveMode.KeepAnchor)
                curseur.mergeCharFormat(self._couleur(DONNE))
        finally:
            document.setUndoRedoEnabled(True)

    def keyPressEvent_texte(self, evenement):
        """Ce que l'élève tape est violet, quelle que soit la couleur du caractère voisin (Qt prendrait la sienne) ;
        taper par-dessus un caractère le même caractère ne change rien, ni le texte ni sa couleur (l'utilisateur,
        03/10/2026)."""
        curseur = self.textCursor()
        if self.overwriteMode() and not curseur.hasSelection() and not curseur.atBlockEnd():
            curseur.setPosition(curseur.position() + 1, QTextCursor.MoveMode.KeepAnchor)
        if curseur.hasSelection() and curseur.selectedText() == evenement.text():
            curseur.setPosition(curseur.selectionEnd())
        else:  # inséré ici plutôt que par setCurrentCharFormat, qui teindrait d'abord la sélection : un pas d'annulation de plus
            curseur.insertText(evenement.text(), self._couleur(ELEVE))
        self.setTextCursor(curseur)
        self.ensureCursorVisible()
        return True

    def inputMethodEvent(self, evenement):
        if self.TEINTE and evenement.commitString():  # le clavier d'un téléphone, d'une tablette, du navigateur
            self.setCurrentCharFormat(self._couleur(ELEVE))
        super().inputMethodEvent(evenement)

    def createMimeDataFromSelection(self):
        """Copié d'ici, le code garde ses couleurs : recollé, il ne passe pas pour tapé ni pour donné."""
        donnees = super().createMimeDataFromSelection()
        donnees.setHtml(self.textCursor().selection().toHtml())
        return donnees

    def insertFromMimeData(self, source):
        """Collé d'un énoncé, des consignes ou de cet éditeur, chaque morceau garde sa couleur (le bleu et le turquoise
        du cours, le violet de l'élève) ; un texte sans couleur (le PDF du cours, un autre logiciel) est du code du cours,
        en bleu (l'utilisateur, 03/10/2026). L'indentation en « $ » du cours redevient des espaces."""
        if not self.TEINTE or self.isReadOnly() or not source.hasText():
            return super().insertFromMimeData(source)
        morceaux = []
        if source.hasHtml():
            document = QTextDocument()
            document.setHtml(source.html())
            bloc = document.begin()
            while bloc.isValid():
                if morceaux:
                    morceaux.append(("\n", DONNE))
                morceau = bloc.begin()
                while not morceau.atEnd():
                    fragment = morceau.fragment()
                    texte, couleur = fragment.text().replace("\u00a0", " ").replace("\u2028", "\n"), fragment.charFormat().foreground().color()
                    if not fragment.charFormat().hasProperty(QTextCharFormat.Property.ForegroundBrush) or couleur.alpha() == 0:
                        couleur = QColor(DONNE)  # sans couleur, ou le retrait transparent du cours (ses « $ » : plus bas)
                    morceaux.append((texte, DONNE if couleur == QColor("black") else couleur.name()))
                    morceau += 1
                bloc = bloc.next()
        if not "".join(t for t, _ in morceaux).strip():
            morceaux = [(source.text(), DONNE)]
        curseur = self.textCursor()
        curseur.beginEditBlock()
        for texte, couleur in morceaux:
            curseur.insertText(RETRAIT_COLLE.sub(lambda m: " " * len(m.group()), texte), self._couleur(couleur))
        curseur.endEditBlock()
        self.setTextCursor(curseur)
        self.ensureCursorVisible()

    def _gris(self):
        """Les commentaires en gris, par-dessus toute autre couleur."""
        selections, document = [], self.document()
        for ligne, colonne in commentaires(self.toPlainText(), "#").items():
            bloc = document.findBlockByNumber(ligne - 1)
            selection = QTextEdit.ExtraSelection()
            selection.cursor = QTextCursor(bloc)
            selection.cursor.setPosition(bloc.position() + colonne)
            selection.cursor.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
            selection.format = self._couleur(COMMENTAIRE)
            selections.append(selection)
        return selections

    def _teinter(self):
        """La couleur du texte est dans le document (``setPlainText``, ``keyPressEvent_texte``, ``insertFromMimeData``) :
        restent les commentaires en gris et, dans un code verrouillé, le fond des lignes à compléter. L'éditeur des
        questions « ordre » garde pour lui les surlignages de glissement, qui passent par le même mécanisme."""
        if not self.TEINTE:
            return
        if self.fixes:
            return self._teinter_zones()
        self.setExtraSelections(self._gris())

    # Le code verrouillé ----------------------------------------------------------------------------------

    def zones(self):
        """Les intervalles (début, fin) du texte où l'élève écrit ; vide si le texte ne suit plus le gabarit."""
        return zones_du_gabarit(self.fixes, self.toPlainText()) or []

    def _dans_zone(self, debut, fin):
        return any(d <= debut and fin <= f for d, f in self.zones())

    def _garder(self):
        """Le filet : une modification qui a touché une partie fixe (coller, glisser, couper, une touche que
        ``keyPressEvent`` ne prévoit pas) est défaite aussitôt."""
        if self.fixes and not self._retour and zones_du_gabarit(self.fixes, self.toPlainText()) is None:
            self._retour = True
            try:
                self.document().undo()
            finally:
                self._retour = False

    def _permise(self, evenement):
        """Une touche qui écrit ne s'accepte que si ce qu'elle remplace est dans une zone : la sélection, ou le
        caractère que Retour arrière ou Suppr effaceraient."""
        curseur = self.textCursor()
        debut, fin = curseur.selectionStart(), curseur.selectionEnd()
        if debut == fin and evenement.key() == Qt.Key.Key_Backspace:
            debut -= 1
        elif debut == fin and evenement.key() == Qt.Key.Key_Delete:
            fin += 1
        return self._dans_zone(debut, fin)

    def _teinter_zones(self):
        """Les lignes à compléter sur fond jaune clair, même vides : c'est là, et là seulement, que l'élève écrit ; le
        code qu'il a écrit à une autre question (``repris``) en violet dans les parties fixes, et les commentaires gris."""
        selections = []
        texte, zones = self.toPlainText(), self.zones()
        for repris in filter(None, self.repris):
            if (a := texte.find(repris)) >= 0:
                selection = QTextEdit.ExtraSelection()
                selection.cursor = QTextCursor(self.document())
                selection.cursor.setPosition(a)
                selection.cursor.setPosition(a + len(repris), QTextCursor.MoveMode.KeepAnchor)
                selection.format.setForeground(QColor(ELEVE))
                selections.insert(0, selection)  # devant le bleu du code donné : c'est la première qui l'emporte
        for d, f in zones:
            premier, dernier = self.document().findBlock(d), self.document().findBlock(f)
            bloc = premier
            while bloc.isValid():
                fond = QTextEdit.ExtraSelection()
                fond.cursor = QTextCursor(bloc)
                fond.format.setBackground(QColor(ZONE))
                fond.format.setProperty(QTextCharFormat.Property.FullWidthSelection, True)
                selections.insert(0, fond)  # dessous : la couleur du texte reste celle des sélections suivantes
                if bloc == dernier:
                    break
                bloc = bloc.next()
        self.setExtraSelections(self._gris() + selections)

    # L'annulation -----------------------------------------------------------------------------------------

    def annulable(self):
        """Ce que Qt sait défaire : la pile s'arrête au texte de départ, vide ou pré-rempli par la question."""
        return self.document().isUndoAvailable()

    def retablissable(self):
        return self.document().isRedoAvailable()

    # L'indentation ----------------------------------------------------------------------------------------

    def keyPressEvent(self, evenement):
        if evenement.key() in (Qt.Key.Key_Tab, Qt.Key.Key_Backtab) and not self.isReadOnly():
            self.indenter(1 if evenement.key() == Qt.Key.Key_Tab else -1)
        elif (self.fixes and not self.isReadOnly() and self._ecrit(evenement) and not self._permise(evenement)):
            return  # hors des lignes à compléter : la touche est ignorée
        elif not (self.TEINTE and not self.isReadOnly() and evenement.text() and evenement.text().isprintable()
                  and self.keyPressEvent_texte(evenement)):
            super().keyPressEvent(evenement)

    @staticmethod
    def _ecrit(evenement):
        """Vrai pour une touche qui modifierait le texte : un caractère, Entrée, Retour arrière, Suppr."""
        return (evenement.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Backspace, Qt.Key.Key_Delete)
                or (evenement.text() and evenement.text().isprintable()))

    def indenter(self, sens):
        """Chaque ligne touchée passe au niveau d'indentation voisin. Une indentation qui n'est pas un multiple de
        ``PAS`` n'est pas décalée de ``PAS`` : elle est complétée jusqu'au niveau au-dessus (Tab) ou tronquée au
        niveau en dessous (Maj+Tab), ce qui remet d'aplomb un code recopié à la main."""
        curseur, document = self.textCursor(), self.document()
        ancre, tete = curseur.anchor(), curseur.position()
        premier = document.findBlock(min(ancre, tete)).blockNumber()
        dernier = document.findBlock(max(ancre, tete)).blockNumber()
        ecart = 0
        if self.fixes:  # verrouillé : seules les lignes que l'élève a ajoutées dans une zone changent de niveau
            zones = self.zones()
            lignes = [n for n in range(premier, dernier + 1)
                      if any(d < document.findBlockByNumber(n).position() <= f for d, f in zones)]
            if not lignes:
                return
            premier, dernier = lignes[0], lignes[-1]
            if len(lignes) != dernier - premier + 1:
                return
        curseur.beginEditBlock()
        for n in range(premier, dernier + 1):
            bloc = document.findBlockByNumber(n)
            texte = bloc.text()
            avant = len(texte) - len(texte.lstrip(" "))
            apres = (avant // PAS + 1) * PAS if sens > 0 else max(0, -(-avant // PAS) - 1) * PAS
            curseur.setPosition(bloc.position())
            curseur.setPosition(bloc.position() + avant, QTextCursor.MoveMode.KeepAnchor)
            curseur.insertText(" " * apres)
            ecart = apres - avant
        curseur.endEditBlock()
        if ancre != tete:  # une sélection recouvre après coup les lignes entières qu'elle a fait bouger
            curseur.setPosition(document.findBlockByNumber(premier).position())
            fin = document.findBlockByNumber(dernier)
            curseur.setPosition(fin.position() + fin.length() - 1, QTextCursor.MoveMode.KeepAnchor)
        else:  # une seule ligne : le curseur garde sa colonne, décalée de ce que l'indentation a gagné ou perdu
            curseur.setPosition(max(document.findBlockByNumber(premier).position(), tete + ecart))
        self.setTextCursor(curseur)


class EditeurLignes(EditeurCode):
    """Des lignes de code à remettre dans l'ordre et au bon niveau d'indentation : on prend une ligne à la souris et
    on la fait glisser, verticalement pour la déplacer, horizontalement pour changer son niveau ; Tab et Maj+Tab
    changent le niveau de la dernière ligne prise. Avec ``retirable`` (lignes distractrices d'un ``Ordre``), la croix
    au bout de chaque ligne, une ligne lâchée hors de l'éditeur, un double-clic ou Suppr la sort du rangement, et
    ``ajouter`` l'y remet au bout.

    Au doigt (``tactile.ACTIF``), un glissé fait défiler la page comme partout ailleurs : une ligne se saisit d'un appui
    long (``tactile.AppuiLong``), puis se glisse jusqu'au lever (``_Suivi``), et la croix agit au lever d'un toucher. La
    convention des listes d'un ``Ordre`` (TODO Lecteur web, 11 et 12), la même en natif et dans le navigateur.

    ``lignes`` est le texte de chaque élément dans le BON ordre, indentation comprise ; ``ordre`` donne, pour chaque
    ligne affichée, l'indice de l'élément qui s'y trouve, et ``niveaux`` son niveau d'indentation (``None`` : celui
    du code juste). Ce sont eux que la question lit et écrit.

    Le texte n'étant pas modifiable, l'annulation de Qt n'a rien à défaire : c'est ``histoire`` qui garde les
    rangements successifs, pour que Ctrl+Z rende un déplacement malheureux."""

    TEINTE = False  # ses lignes gardent la couleur du texte : ses surlignages de glissement passent par les sélections
    NIVEAU_MAXI = 8  # au-delà, la ligne sortirait du cadre : aucun code d'élève n'en demande autant

    def __init__(self, lignes, ordre, niveaux=None):
        super().__init__()
        self.lignes = [l.lstrip(" ") for l in lignes]
        self.justes = [(len(l) - len(l.lstrip(" "))) // PAS for l in lignes]
        self.prise, self.courante = None, None  # ``self.ordre`` et ``self.niveaux`` sont posés par ``ranger``
        self.histoire, self.rang = [], -1
        self.retirable = False
        self.setReadOnly(True)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.viewport().setCursor(Qt.CursorShape.OpenHandCursor)
        self.toucher = tactile.Toucher()
        tactile.AppuiLong(self.viewport(), self._prendre_au_doigt)
        self.ranger(ordre, niveaux)

    def ranger(self, ordre, niveaux=None):
        self._poser(ordre, [self.justes[i] for i in ordre] if niveaux is None else niveaux)
        if self.prise is None:  # pendant un déplacement, l'étape d'annulation attend le lâcher : un pas, pas un pixel
            self._memoriser()

    def ajouter(self, i):
        self.ranger(self.ordre + [i], self.niveaux + [0])

    def retirer(self, ligne):
        self.courante = None
        self.ranger(self.ordre[:ligne] + self.ordre[ligne + 1:], self.niveaux[:ligne] + self.niveaux[ligne + 1:])

    def _poser(self, ordre, niveaux):
        self.ordre, self.niveaux = list(ordre), list(niveaux)
        self.setPlainText("\n".join(" " * PAS * n + self.lignes[i] for i, n in zip(self.ordre, self.niveaux)))
        self._surligner()  # le texte reposé a perdu ses sélections : le bleu comme la ligne prise

    # L'annulation -----------------------------------------------------------------------------------------

    def annulable(self):
        return self.rang > 0

    def retablissable(self):
        return self.rang < len(self.histoire) - 1

    def _memoriser(self):
        del self.histoire[self.rang + 1:]  # on repart d'ici : ce qui avait été rétabli n'a plus de suite
        self.histoire.append((list(self.ordre), list(self.niveaux)))
        self.rang = len(self.histoire) - 1
        self.annulation.emit()  # le lâcher ne change pas le texte : sans ce signal, le bouton resterait éteint

    def undo(self):
        self._rejouer(-1)

    def redo(self):
        self._rejouer(1)

    def _rejouer(self, sens):
        if 0 <= self.rang + sens < len(self.histoire):
            self.rang += sens
            self._poser(*self.histoire[self.rang])  # rejouer un rangement n'en fait pas une étape de plus

    def keyPressEvent(self, evenement):
        """Ctrl+Z, Ctrl+Maj+Z, Tab et Maj+Tab : un éditeur en lecture seule ne les traite pas, c'est donc ici qu'ils
        agissent."""
        if evenement.matches(QKeySequence.StandardKey.Undo):
            self.undo()
        elif evenement.matches(QKeySequence.StandardKey.Redo):
            self.redo()
        elif evenement.key() in (Qt.Key.Key_Tab, Qt.Key.Key_Backtab):
            if self.courante is not None:
                self._decaler(self.courante, self.niveaux[self.courante] + (1 if evenement.key() == Qt.Key.Key_Tab else -1))
                self._memoriser()
        elif evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace) and self.retirable and self.courante is not None:
            self.retirer(self.courante)
        else:
            super().keyPressEvent(evenement)

    def _decaler(self, ligne, niveau):
        niveaux = list(self.niveaux)
        niveaux[ligne] = max(0, min(self.NIVEAU_MAXI, niveau))
        if niveaux != self.niveaux:
            self._poser(self.ordre, niveaux)

    # La souris --------------------------------------------------------------------------------------------

    def _ligne(self, y):
        return min(self.cursorForPosition(QPoint(0, int(y))).blockNumber(), len(self.ordre) - 1)

    def mouseDoubleClickEvent(self, evenement):
        if self.retirable and self.ordre:
            self.retirer(self._ligne(evenement.position().y()))
        else:
            super().mouseDoubleClickEvent(evenement)

    def _sur_croix(self, position):
        bas = self.blockBoundingGeometry(self.document().lastBlock()).translated(self.contentOffset()).bottom()
        return self.retirable and position.x() >= self.viewport().width() - self.fontMetrics().height() and position.y() < bas

    def paintEvent(self, evenement):
        super().paintEvent(evenement)
        if not self.retirable:
            return
        peintre, cote = QPainter(self.viewport()), self.fontMetrics().height()
        peintre.setPen(QPen(QColor(GRIS), 1.5))
        bloc = self.firstVisibleBlock()
        haut = self.blockBoundingGeometry(bloc).translated(self.contentOffset()).top()
        while bloc.isValid() and bloc.blockNumber() < len(self.ordre):
            centre, r = QPoint(self.viewport().width() - cote // 2, int(haut + cote / 2)), cote // 5
            peintre.drawLine(centre + QPoint(-r, -r), centre + QPoint(r, r))
            peintre.drawLine(centre + QPoint(-r, r), centre + QPoint(r, -r))
            haut += self.blockBoundingRect(bloc).height()
            bloc = bloc.next()

    def mousePressEvent(self, evenement):
        if self.toucher.appui(evenement) or not self.ordre:  # au doigt, rien avant le lever ou l'appui long ; toutes
            return  # les lignes renvoyées dans la réserve : rien à prendre
        if self._sur_croix(evenement.position()):
            self.retirer(self._ligne(evenement.position().y()))
            return
        self._prendre(evenement.position())

    def _prendre(self, position):
        self.prise = self.courante = self._ligne(position.y())
        self.origine = position.x(), self.niveaux[self.prise]  # d'où part le glissement horizontal
        self.viewport().setCursor(Qt.CursorShape.ClosedHandCursor)
        self._surligner()

    def _prendre_au_doigt(self, position):
        if self.ordre and not self._sur_croix(position):  # la croix agit au lever, appui long ou pas
            self.toucher.point = None
            self._prendre(position)
            _Suivi(self)

    def mouseMoveEvent(self, evenement):
        self.toucher.bouge(evenement)
        if self.prise is None:
            return
        cible = self._ligne(evenement.position().y())
        if cible != self.prise:
            ordre, niveaux = list(self.ordre), list(self.niveaux)
            ordre.insert(cible, ordre.pop(self.prise))
            niveaux.insert(cible, niveaux.pop(self.prise))
            self.prise = self.courante = cible
            self.ranger(ordre, niveaux)
        x, niveau = self.origine  # un niveau tous les PAS caractères de glissement, arrondi au plus proche
        self._decaler(self.prise, niveau + round((evenement.position().x() - x) / (PAS * self.fontMetrics().horizontalAdvance(" "))))

    def mouseReleaseEvent(self, evenement):
        if self.toucher.leve(evenement) and self.ordre and self._sur_croix(evenement.position()):
            self.retirer(self._ligne(evenement.position().y()))
        if self.prise is None:
            return
        if self.retirable and not self.viewport().rect().contains(evenement.position().toPoint()):
            ligne, self.prise = self.prise, None
            self.retirer(ligne)  # une étape d'annulation, déplacement compris
            self.viewport().setCursor(Qt.CursorShape.OpenHandCursor)
            return
        self.prise = None
        if (self.ordre, self.niveaux) != self.histoire[self.rang]:  # le déplacement achevé fait UNE étape d'annulation
            self._memoriser()
        self.viewport().setCursor(Qt.CursorShape.OpenHandCursor)
        self._surligner()

    def _surligner(self):
        """Tout le code est dans le bleu des énoncés (il est donné, l'élève ne fait que le ranger) ; la ligne prise
        a un fond, de son premier à son dernier caractère, tant que le clic est enfoncé, et plus rien une fois lâchée
        (l'utilisateur, 28/09/2026 : le fond pleine largeur, puis sa trace plus claire après le lâcher, étaient de trop).
        Tab et Maj+Tab décalent toujours la dernière ligne prise, ``courante``."""
        bleu = QTextEdit.ExtraSelection()
        bleu.format.setForeground(QColor(DONNE))
        bleu.cursor = QTextCursor(self.document())
        bleu.cursor.movePosition(QTextCursor.MoveOperation.End, QTextCursor.MoveMode.KeepAnchor)
        selections = [bleu]
        if self.prise is not None:
            bloc = self.document().findBlockByNumber(self.prise)
            marque = QTextEdit.ExtraSelection()
            marque.format.setBackground(QColor(PRISE))
            marque.format.setForeground(QColor(DONNE))  # sinon la sélection du dessus rend le texte noir
            marque.cursor = QTextCursor(bloc)
            marque.cursor.setPosition(bloc.position() + len(bloc.text()) - len(bloc.text().lstrip(" ")))
            marque.cursor.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
            selections.append(marque)
        self.setExtraSelections(selections)


class _Suivi(QObject):
    """Une ligne saisie au doigt (``EditeurLignes._prendre_au_doigt``) : la souris que Qt tire du doigt, où qu'elle aille,
    est rendue aux gestionnaires de l'éditeur jusqu'au lever, comme le glisser des listes (``qtpy6.web.glisser``). Un appui
    est un lever perdu : il lâche la ligne là où elle est."""

    def __init__(self, editeur):
        super().__init__(editeur)
        self.editeur = editeur
        QApplication.instance().installEventFilter(self)

    def eventFilter(self, objet, evenement):
        genre = evenement.type()
        if genre not in (QEvent.Type.MouseMove, QEvent.Type.MouseButtonRelease, QEvent.Type.MouseButtonPress,
                         QEvent.Type.MouseButtonDblClick):
            return False
        e = self.editeur
        position = QPointF(e.viewport().mapFromGlobal(evenement.globalPosition()))
        if genre == QEvent.Type.MouseMove:
            e.mouseMoveEvent(QMouseEvent(genre, position, evenement.globalPosition(), Qt.MouseButton.NoButton,
                                         Qt.MouseButton.LeftButton, evenement.modifiers()))
            return True
        QApplication.instance().removeEventFilter(self)
        self.deleteLater()
        e.mouseReleaseEvent(QMouseEvent(QEvent.Type.MouseButtonRelease, position, evenement.globalPosition(),
                                        Qt.MouseButton.LeftButton, Qt.MouseButton.NoButton, evenement.modifiers()))
        return genre == QEvent.Type.MouseButtonRelease
