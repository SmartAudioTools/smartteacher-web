"""Les deux éditeurs de code du lecteur : celui où l'élève écrit, et celui où il remet des lignes dans l'ordre.

``EditeurCode`` sert aux questions de type ``code`` : Tab et Maj+Tab y déplacent d'un niveau d'indentation les
lignes touchées, au lieu d'insérer une tabulation ; le code donné par la question s'y montre en bleu, ce que
l'élève tape au clavier en violet, pour qu'il voie d'un coup d'oeil ce qui est de lui, et les commentaires en gris. ``EditeurLignes`` sert aux questions
de type ``ordre`` écrites en Python : le texte ne s'y modifie pas, seuls l'ordre des lignes et leur indentation
changent, à la souris (ou Tab pour l'indentation) — l'élève voit le code tel qu'il s'exécutera, ce qu'une liste
d'éléments à côté du code ne montre pas.
"""

import math
import re
from bisect import bisect_right
from difflib import SequenceMatcher

from qtpy6.QtCore import QEvent, QMimeData, QObject, QPoint, QPointF, QRectF, Qt, Signal
from qtpy6.QtGui import (QColor, QDrag, QDropEvent, QFont, QFontDatabase, QFontMetricsF, QKeyEvent, QKeySequence, QMouseEvent, QPainter, QPen,
                         QTextCharFormat, QTextCursor, QTextDocument)
from qtpy6.QtWidgets import QApplication, QLabel, QPlainTextDocumentLayout, QPlainTextEdit, QTextEdit, QToolTip, QWidget
from qtpy6.web import tactile

from noyau import zones_du_gabarit
from texte_md import BLEU_CODE, GRIS, MONO, commentaires

PAS = 4  # un niveau d'indentation, en espaces
RANG_GLISSE = "application/x-smartteacher-rang"  # le format où une étiquette glissée porte son rang (``Colonne.mimeData``)
# Les deux couleurs du code se séparent par la teinte et la clarté (le violet, construit en 2026 contre un bleu
# #2d7dd2 plus sombre, l'est désormais nettement) ; il reste plus clair et moins saturé que le fuchsia de l'invite.
DONNE = BLEU_CODE  # le code donné par la question, tant qu'il est intact : le bleu du code des énoncés (28/09/2026)
ELEVE = "#7b5abe"  # ce que l'élève a écrit par-dessus : violet (L* 46, 5,2:1)
COMMENTAIRE = GRIS  # les commentaires, de qui qu'ils soient : le gris de ceux du cours (l'utilisateur, 03/10/2026)
RETRAIT_COLLE = re.compile(r"^\$+", re.M)  # l'indentation d'un code collé du cours, en « $ » (texte_md.indentation_visible)
GUIDE = "#e2e2e2"  # les repères d'indentation : gris très clair, présents sans se lire comme du texte
MARGE_FOND, MARGE_TEXTE = "#f0f0f0", "#909090"  # la colonne des numéros de ligne, discrète : elle se lit, elle ne s'impose pas
INTERLIGNE = 0.4  # d'une hauteur de ligne, ajouté sous chaque ligne du code : le code s'aère (l'utilisateur, 28/09/2026)
ZONE = "#fff4cc"  # le fond des lignes à compléter d'un code verrouillé : jaune très clair, là où l'élève écrit
BARRE, CORRIGE = 1, 2  # l'état d'un bloc de la correction (``EditeurCorrection``) : ligne de l'élève barrée, ligne corrigée
EXPOSANTS = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")


def nombre(n: float) -> str:
    """Un compte de la marge du profileur : en entier jusqu'au million, au-delà « 5·10⁹ » (deux chiffres)."""
    if n < 10 ** 6:
        return f"{n:.1f}".rstrip("0").rstrip(".").replace(".", ",") if n != int(n) else str(int(n))
    puissance = math.floor(math.log10(n))
    mantisse = f"{n / 10 ** puissance:.1f}".rstrip("0").rstrip(".").replace(".", ",")
    return ("" if mantisse == "1" else mantisse + "·") + "10" + str(puissance).translate(EXPOSANTS)


def chaleur(operations: int, plus: int, vif: bool = False) -> QColor:
    """L'échelle thermique du profileur, logarithmique (les comptes vont de 1 à 10⁹) : jaune pâle pour une opération,
    rouge pour la ligne qui en fait le plus. Claire, pour que le code reste lisible dessus ; ``vif`` : plus saturée,
    pour l'instruction qui cache un coût, sur le fond de sa ligne."""
    t = math.log(operations) / math.log(plus) if plus > 1 and operations > 1 else 0.0
    if vif:
        return QColor.fromHsvF((50 - 50 * t) / 360, 0.85, 0.85)
    return QColor.fromHsvF((50 - 50 * t) / 360, 0.12 + 0.45 * t, 1.0)


def reindenter(texte: str, ecart: int) -> str:
    """``texte`` avec ``ecart`` espaces de plus devant (de moins s'il est négatif)."""
    return " " * ecart + texte if ecart >= 0 else texte[-ecart:]


class Disposition(QPlainTextDocumentLayout):
    """La mise en page de l'éditeur, qui aère les lignes. QPlainTextEdit ignore l'interligne d'un bloc (``lineHeight``
    comme les marges haute et basse : essayés, hauteur inchangée) ; il suit en revanche, pour peindre comme pour
    viser à la souris, la hauteur que sa disposition déclare pour chaque bloc : l'espace s'y ajoute, sous la ligne."""

    def ecart(self) -> int:
        return round(INTERLIGNE * QFontMetricsF(self.document().defaultFont()).lineSpacing())

    def blockBoundingRect(self, bloc):
        rectangle = super().blockBoundingRect(bloc)
        return rectangle if not bloc.isVisible() else rectangle.adjusted(0, 0, 0, self.ecart())  # un bloc caché : rien


class Marge(QWidget):
    """La colonne des numéros de ligne, collée à gauche de l'éditeur : c'est ce qui le distingue de la console."""

    def __init__(self, editeur):
        super().__init__(editeur)
        self.editeur = editeur

    def paintEvent(self, evenement):
        self.editeur.peindre_marge(evenement)


class MargeProfil(Marge):
    """La colonne de droite du profileur : les opérations élémentaires de chaque ligne (``EditeurCode.montrer_profil``)."""

    def paintEvent(self, evenement):
        self.editeur.peindre_profil(evenement)


def caractere(evenement) -> bool:
    """La touche écrit un caractère, et n'est pas un raccourci. Dans le navigateur, Ctrl+Z, Ctrl+C et Ctrl+V arrivent avec
    le texte de leur lettre (« z », pas le « \\x1a » du natif) : pris pour une frappe, ils écrivaient la lettre au lieu
    d'annuler, de copier ou de coller (TODO Corrections TPS, 09/10/2026). Ctrl+Alt reste une frappe : c'est AltGr sous
    Windows (« { », « [ », « # » d'un clavier français)."""
    mods = evenement.modifiers()
    raccourci = bool(mods & Qt.KeyboardModifier.MetaModifier) or (
        bool(mods & Qt.KeyboardModifier.ControlModifier) and not mods & Qt.KeyboardModifier.AltModifier)
    return bool(evenement.text()) and evenement.text().isprintable() and not raccourci


class EditeurCode(QPlainTextEdit):
    """Un éditeur dans la police du code des énoncés (``MONO``), où Tab et Maj+Tab indentent, au lieu d'insérer une tabulation ou de changer de widget."""

    TEINTE = True  # chaque caractère garde la couleur de sa provenance ; EditeurLignes peint autrement
    retraits: dict[int, int] = {}  # numéro de bloc → espaces à ajouter (ou retirer) devant pour l'exécuter (``EditeurCorrection``)
    annulation = Signal()  # ce qu'il y a à défaire a changé sans que le texte bouge : seul un rangement fait cela
    profil: dict[int, tuple[int, int]] = {}  # le profileur, avant ``__init__`` : ``setPlainText`` teinte déjà
    selections: list = []

    def __init__(self, texte="", fixes=None, premiere=1):
        super().__init__()
        # ``fixes`` : les parties du code donné que l'élève ne peut pas modifier (``Code.gabarit``), ``None`` si tout
        # s'écrit. Il écrit entre deux parties consécutives ; ce qui toucherait une partie fixe est refusé.
        self.fixes, self._retour = fixes, False
        self.repris = []  # dans les parties fixes, le code que l'élève a écrit à une autre question (``reprend``) : en violet
        self.premiere = premiere  # le numéro de la première ligne (``Code.premiere_ligne``) ; sous 1, pas de numéro
        self.disposition = Disposition(self.document())  # gardée : sous PySide6, l'objet Python ramassé laisse Qt sur
        self.document().setDocumentLayout(self.disposition)  # un pointeur mort (plantage) ; posée avant le texte
        self.donne = texte  # le code de la question, en bleu tant que l'élève n'y touche pas
        self.setPlainText(texte)
        self.marge = Marge(self)  # avant setFont, qui passe par changeEvent
        # le profileur (``montrer_profil``) : numéro de bloc → (passages, opérations), les instructions qui cachent un
        # coût, et le TOTAL sous la dernière ligne ; rien tant que Σ n'a pas tourné
        self.profil, self.caches, self.plus = {}, [], 1
        self.marge_profil, self.total = MargeProfil(self), QLabel(self)
        self.total.hide()
        police = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        police.setFamily(MONO)  # celle du code des énoncés ; la taille reste celle de la zone qui défile
        self.setFont(police)
        self.blockCountChanged.connect(lambda _: self._poser_marge())
        self.updateRequest.connect(self._suivre_marge)
        self.textChanged.connect(self._garder)
        self.textChanged.connect(self.effacer_profil)  # les comptes ne valent que pour le code qui a tourné
        self.textChanged.connect(self._teinter)
        self._poser_marge()
        self._teinter()

    # Les numéros de ligne ---------------------------------------------------------------------------------

    def largeur_marge(self):
        return 10 + self.fontMetrics().horizontalAdvance("9") * len(str(max(1, self.blockCount() + self.premiere - 1)))

    def _poser_marge(self):
        droite, bas = self.largeur_profil(), self.total.sizeHint().height() if self.total.isVisibleTo(self) else 0
        self.setViewportMargins(self.largeur_marge(), 0, droite, bas)
        cadre = self.contentsRect()
        self.marge.setGeometry(cadre.x(), cadre.y(), self.largeur_marge(), cadre.height() - bas)
        vue = self.viewport().geometry()  # à droite de la vue, pas sous la barre de défilement
        self.marge_profil.setGeometry(vue.right() + 1, cadre.y(), droite, cadre.height() - bas)
        self.total.setGeometry(cadre.x(), cadre.bottom() + 1 - bas, vue.right() + droite - cadre.x() - 5, bas)

    def _suivre_marge(self, rectangle, dy):
        """La marge défile avec le texte, et se redessine quand une ligne apparaît ou disparaît."""
        for marge in (self.marge, self.marge_profil):
            if dy:
                marge.scroll(0, dy)
            else:
                marge.update(0, rectangle.y(), marge.width(), rectangle.height())

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self._poser_marge()

    def changeEvent(self, evenement):
        """La feuille de style du sujet agrandit la police une fois l'éditeur construit : la marge suit, sinon elle
        mord sur le début des lignes."""
        super().changeEvent(evenement)
        if evenement.type() == QEvent.Type.FontChange:
            self._poser_marge()

    def numeros(self) -> list[int | None]:
        """Le numéro affiché devant chaque bloc : consécutifs depuis ``premiere`` sur les blocs non barrés, ceux du code
        exécuté (``texte_execute``). Un bloc barré que sa correction suit porte, rayé, le numéro de celle-ci : une marque
        de remplacement, pas un numéro de plus (l'utilisateur, 14/10/2026 : « en barrant le numéro de la ligne dans la
        marge et remettant le même numéro de ligne pour la correction ») ; une ligne en trop, que rien ne remplace,
        n'en a aucun (``None``). Dans un éditeur ordinaire, ``premiere + rang``."""
        numeros, n = [], self.premiere
        bloc = self.document().begin()
        while bloc.isValid():
            if bloc.userState() != BARRE:
                numeros.append(n)
                n += 1
            else:
                numeros.append(n if bloc.next().isValid() and bloc.next().userState() == CORRIGE else None)
            bloc = bloc.next()
        return numeros

    def texte_execute(self) -> str:
        """Le texte à exécuter : sans les blocs barrés (dans la correction, la variante corrigée de la réponse)."""
        blocs, bloc = [], self.document().begin()
        while bloc.isValid():
            if bloc.userState() != BARRE:
                blocs.append(self.ligne_executee(bloc))
            bloc = bloc.next()
        return "\n".join(blocs)

    def ligne_executee(self, bloc) -> str:
        """Le texte du bloc tel qu'il s'exécute : à l'indentation corrigée s'il en a une (``retraits``)."""
        return reindenter(bloc.text(), self.retraits.get(bloc.blockNumber(), 0))

    def largeur_texte(self, bloc) -> float:
        """Jusqu'où s'écrit la ligne, depuis le bord gauche du texte : où une accolade peut se poser à sa droite."""
        return self.fontMetrics().horizontalAdvance(bloc.text())

    def peindre_marge(self, evenement):
        peintre = QPainter(self.marge)
        peintre.fillRect(evenement.rect(), QColor(MARGE_FOND))
        peintre.setPen(QColor(MARGE_TEXTE))
        bloc, numeros = self.firstVisibleBlock(), self.numeros()
        haut = self.blockBoundingGeometry(bloc).translated(self.contentOffset()).top()
        while bloc.isValid() and haut <= evenement.rect().bottom():
            bas = haut + self.blockBoundingRect(bloc).height()
            numero = numeros[bloc.blockNumber()]
            if bas >= evenement.rect().top() and numero is not None and numero >= 1 and bloc.isVisible():
                hauteur, droite = self.fontMetrics().height(), self.marge.width() - 5
                peintre.drawText(0, int(haut), droite, hauteur, Qt.AlignmentFlag.AlignRight, str(numero))
                if bloc.userState() == BARRE:  # le numéro rayé, dans le rouge de la correction
                    peintre.save()
                    peintre.setPen(QPen(QColor(self.rouge), 1.5))
                    y = haut + hauteur / 2
                    peintre.drawLine(QPointF(droite - self.fontMetrics().horizontalAdvance(str(numero)) - 1, y), QPointF(droite + 1, y))
                    peintre.restore()
            bloc, haut = bloc.next(), bas

    # Le profileur de complexité --------------------------------------------------------------------------

    def _blocs_executes(self) -> list:
        """Les blocs du texte exécuté (``texte_execute``), dans l'ordre : la ligne n du programme est le n-ième."""
        blocs, bloc = [], self.document().begin()
        while bloc.isValid():
            if bloc.userState() != BARRE:
                blocs.append(bloc)
            bloc = bloc.next()
        return blocs

    def montrer_profil(self, profil: dict) -> None:
        """Les comptes de ``complexity_profiler`` (``Resultats.vers_dict``) : dans la marge droite, les opérations
        élémentaires de chaque ligne, « passages × moyenne par passage = total », ou les passages seuls quand la ligne
        n'en fait qu'une par passage ; le fond de la ligne dans l'échelle thermique de son total, l'instruction qui
        cache un coût plus vive sur son étendue, son infobulle dit ce qu'elle cache ; le TOTAL sous la dernière ligne,
        chaque opération comptée une fois (un appel porte le coût de la fonction : la colonne ne s'additionne pas)."""
        blocs = self._blocs_executes()
        self.profil = {blocs[int(n) - 1].blockNumber(): (p, o) for n, (p, o) in profil["lignes"].items()
                       if 0 < int(n) <= len(blocs)}
        self.plus = max((o for _, o in self.profil.values()), default=1)
        self.caches = []
        for ligne, colonne, fin_ligne, fin_colonne, texte, passages, operations, nature in profil["caches"]:
            if 0 < ligne <= len(blocs) and 0 < fin_ligne <= len(blocs):
                debut, fin = blocs[ligne - 1], blocs[fin_ligne - 1]  # les colonnes sont celles du texte exécuté
                self.caches.append((debut.position() + max(0, colonne - self.retraits.get(debut.blockNumber(), 0)),
                                    fin.position() + max(0, fin_colonne - self.retraits.get(fin.blockNumber(), 0)),
                                    texte, passages, operations, nature))
        self.total.setText(f"TOTAL : {nombre(profil['total'])} opération{'s' if profil['total'] > 1 else ''} "
                           "élémentaire" + ("s" if profil["total"] > 1 else ""))
        self.total.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.total.show()
        self._poser_marge()
        self.setExtraSelections(self.selections)
        self.marge_profil.update()

    def effacer_profil(self) -> None:
        if self.profil or self.total.isVisibleTo(self):
            self.profil, self.caches, self.plus = {}, [], 1
            self.total.hide()
            self._poser_marge()
            self.setExtraSelections(self.selections)

    @staticmethod
    def etiquette(passages: int, operations: int) -> str:
        if not passages:  # un appel qui a levé dans l'en-tête d'un for ou d'un while : coûté, jamais passé
            return f"0 × … = {nombre(operations)}"
        if operations == passages:
            return nombre(passages)
        # la moyenne exacte quand elle tient en trois décimales, pour que le produit se vérifie à l'œil (« 1000 × 499,501
        # = 499501 », et non « 1000 × 499,5 = 499501 ») ; sinon arrondie, et dite telle (« ≈ »)
        decimales = next((d for d in range(4) if operations * 10 ** d % passages == 0), None)
        moyenne = operations / passages
        if moyenne >= 10 ** 6:
            texte = nombre(moyenne)
        elif decimales is None:
            texte = "≈" + nombre(moyenne)
        else:
            texte = f"{moyenne:.{decimales}f}".replace(".", ",")
        return f"{nombre(passages)} × {texte} = {nombre(operations)}"

    def largeur_profil(self) -> int:
        if not self.profil:
            return 0
        return 12 + max(self.fontMetrics().horizontalAdvance(self.etiquette(p, o)) for p, o in self.profil.values())

    def peindre_profil(self, evenement):
        peintre = QPainter(self.marge_profil)
        peintre.fillRect(evenement.rect(), QColor(MARGE_FOND))
        peintre.setPen(QColor(MARGE_TEXTE))
        bloc = self.firstVisibleBlock()
        haut = self.blockBoundingGeometry(bloc).translated(self.contentOffset()).top()
        while bloc.isValid() and haut <= evenement.rect().bottom():
            bas = haut + self.blockBoundingRect(bloc).height()
            if bas >= evenement.rect().top() and bloc.isVisible() and bloc.blockNumber() in self.profil:
                peintre.drawText(0, int(haut), self.marge_profil.width() - 6, self.fontMetrics().height(),
                                 Qt.AlignmentFlag.AlignRight, self.etiquette(*self.profil[bloc.blockNumber()]))
            bloc, haut = bloc.next(), bas

    def _selections_profil(self) -> list:
        """Le fond des lignes comptées ; les instructions qui cachent un coût sont soulignées (``souligner_caches``)."""
        selections = []
        for numero, (_, operations) in self.profil.items():
            fond = QTextEdit.ExtraSelection()
            fond.cursor = QTextCursor(self.document().findBlockByNumber(numero))
            fond.format.setBackground(chaleur(operations, self.plus))
            fond.format.setProperty(QTextCharFormat.Property.FullWidthSelection, True)
            selections.append(fond)
        return selections

    def souligner_caches(self, peintre: QPainter) -> None:
        """Sous l'étendue de chaque instruction qui cache un coût, un trait épais dans l'échelle thermique de ce qu'elle
        a fait exécuter : un fond plus vif rendait le code illisible sur le rouge (capture du 30/10/2026)."""
        for debut, fin, *_, operations, _ in self.caches:
            curseur = QTextCursor(self.document())
            curseur.setPosition(debut)
            while curseur.position() < fin:
                a = self.cursorRect(curseur)
                curseur.movePosition(QTextCursor.MoveOperation.EndOfLine, QTextCursor.MoveMode.MoveAnchor)
                curseur.setPosition(min(fin, curseur.position()))
                b = self.cursorRect(curseur)
                y = a.top() + self.fontMetrics().ascent() + 3
                peintre.setPen(QPen(chaleur(operations, self.plus, vif=True), 3))
                peintre.drawLine(a.left(), y, b.left(), y)
                if not curseur.movePosition(QTextCursor.MoveOperation.NextBlock):
                    break

    def setExtraSelections(self, selections):
        """Les sélections de l'éditeur (gris, zones…), gardées pour que le profil se pose et s'efface par-dessus."""
        self.selections = list(selections)
        super().setExtraSelections(self.selections + (self._selections_profil() if self.profil else []))

    def viewportEvent(self, evenement):
        """L'infobulle d'une instruction qui cache un coût : ce qu'elle cache, et combien."""
        if evenement.type() == QEvent.Type.ToolTip and self.caches:
            position = self.cursorForPosition(evenement.pos()).position()
            for debut, fin, texte, passages, operations, nature in self.caches:
                if debut <= position < fin:
                    fois = f", sur {nombre(passages)} passages" if passages > 1 else ""
                    QToolTip.showText(evenement.globalPos(),
                                      f"{texte} : {nature}\n{nombre(operations)} opérations élémentaires{fois}", self)
                    return True
            QToolTip.hideText()
        return super().viewportEvent(evenement)

    # Les repères d'indentation ---------------------------------------------------------------------------

    def paintEvent(self, evenement):
        """Un pointillé vertical à chaque niveau d'indentation que la ligne a franchi, comme les lignes de la copie
        papier : on voit d'un coup d'oeil jusqu'où va un bloc. Une ligne vide prend le niveau le plus bas de ses
        voisines non vides, pour que le trait d'un bloc ne s'interrompe pas sur une ligne blanche en son milieu."""
        super().paintEvent(evenement)
        peintre = QPainter(self.viewport())
        self.souligner_caches(peintre)
        stylo = QPen(QColor(GUIDE), 1, Qt.PenStyle.DotLine)
        peintre.setPen(stylo)
        colonne = self.fontMetrics().horizontalAdvance(" " * PAS)
        gauche = self.contentOffset().x() + self.document().documentMargin()
        bloc = self.firstVisibleBlock()
        haut = self.blockBoundingGeometry(bloc).translated(self.contentOffset()).top()
        while bloc.isValid() and haut <= evenement.rect().bottom():
            bas = haut + self.blockBoundingRect(bloc).height()
            for niveau in range(self._niveau(bloc) if bloc.isVisible() else 0):
                x = int(gauche + niveau * colonne) + 1
                peintre.drawLine(x, int(haut), x, int(bas) - 1)
            bloc, haut = bloc.next(), bas

    @staticmethod
    def _niveau(bloc):
        texte = bloc.text()
        if texte.strip():
            return (len(texte) - len(texte.lstrip(" "))) // PAS
        voisins = []
        for pas in (lambda b: b.previous(), lambda b: b.next()):
            b = pas(bloc)
            while b.isValid() and not b.text().strip():
                b = pas(b)
            voisins.append(EditeurCode._niveau(b) if b.isValid() else 0)
        return min(voisins)

    # Le code donné par la question ------------------------------------------------------------------------

    @staticmethod
    def _couleur(couleur):
        marque = QTextCharFormat()
        marque.setForeground(QColor(couleur))
        return marque

    def setPlainText(self, texte):
        """Le texte remplacé d'un coup (question qui démarre, copie rechargée) : chaque caractère prend la couleur de
        sa provenance, dans le document lui-même, que Qt fait suivre aux frappes, aux collages et à l'annulation.

        Le code donné est bleu, le reste violet. Une copie rechargée n'a plus l'historique de ses frappes : y redevient
        bleu ce qui coïncide avec le code donné sur trois caractères au moins (en deçà, des lettres isolées du code
        tapé s'apparieraient au hasard)."""
        super().setPlainText(texte)
        if not self.TEINTE:
            return
        document = self.document()
        document.setUndoRedoEnabled(False)  # setPlainText vient de vider la pile : la couleur n'y entre pas
        try:
            curseur = QTextCursor(document)
            curseur.select(QTextCursor.SelectionType.Document)
            curseur.mergeCharFormat(self._couleur(ELEVE))
            if self.fixes:
                zones, debut = self.zones(), 0
                bleus = []
                for d, f in [*zones, (len(texte), len(texte))]:
                    bleus.append((debut, d - debut))
                    debut = f
            elif self.donne:
                bleus = [(b, n) for _, b, n in SequenceMatcher(None, self.donne, texte, autojunk=False).get_matching_blocks()
                         if n >= 3 or texte == self.donne]
            else:
                bleus = []
            for debut, taille in bleus:
                curseur.setPosition(debut)
                curseur.setPosition(debut + taille, QTextCursor.MoveMode.KeepAnchor)
                curseur.mergeCharFormat(self._couleur(DONNE))
        finally:
            document.setUndoRedoEnabled(True)

    def keyPressEvent_texte(self, evenement):
        """Ce que l'élève tape est violet, quelle que soit la couleur du caractère voisin (Qt prendrait la sienne) ;
        taper par-dessus un caractère le même caractère ne change rien, ni le texte ni sa couleur (l'utilisateur,
        03/10/2026)."""
        curseur = self.textCursor()
        if self.overwriteMode() and not curseur.hasSelection() and not curseur.atBlockEnd():
            curseur.setPosition(curseur.position() + 1, QTextCursor.MoveMode.KeepAnchor)
        if curseur.hasSelection() and curseur.selectedText() == evenement.text():
            curseur.setPosition(curseur.selectionEnd())
        else:  # inséré ici plutôt que par setCurrentCharFormat, qui teindrait d'abord la sélection : un pas d'annulation de plus
            curseur.insertText(evenement.text(), self._couleur(ELEVE))
        self.setTextCursor(curseur)
        self.ensureCursorVisible()
        return True

    def inputMethodEvent(self, evenement):
        if self.TEINTE and evenement.commitString():  # le clavier d'un téléphone, d'une tablette, du navigateur
            self.setCurrentCharFormat(self._couleur(ELEVE))
        super().inputMethodEvent(evenement)

    def createMimeDataFromSelection(self):
        """Copié d'ici, le code garde ses couleurs : recollé, il ne passe pas pour tapé ni pour donné."""
        donnees = super().createMimeDataFromSelection()
        curseur, document = self.textCursor(), self.document()
        a, b = curseur.selectionStart(), curseur.selectionEnd()
        if not self.retraits and not any(bloc.userState() == BARRE for bloc in self._blocs()):
            donnees.setHtml(curseur.selection().toHtml())
            return donnees
        # la correction : les blocs barrés ne se copient pas (ce n'est plus du code), les lignes corrigées passent en bleu
        gardes, bloc = [], document.findBlock(a)
        while bloc.isValid() and bloc.position() <= b:
            if bloc.userState() != BARRE:
                gardes.append((bloc, max(a, bloc.position()), min(b, bloc.position() + bloc.length() - 1)))
            bloc = bloc.next()
        donnees = QMimeData()  # pas celui de Qt : son texte brut se relit dans la sélection entière, blocs barrés compris
        donnees.setText("\n".join(reindenter(bloc.text()[d - bloc.position():f - bloc.position()],
                                              self.retraits.get(bloc.blockNumber(), 0) if d == bloc.position() else 0)
                                   for bloc, d, f in gardes))
        copie = QTextDocument()
        ecrit = QTextCursor(copie)
        for i, (bloc, d, f) in enumerate(gardes):
            if i:
                ecrit.insertBlock()
            debut = ecrit.position()
            source = QTextCursor(document)
            source.setPosition(d)
            source.setPosition(f, QTextCursor.MoveMode.KeepAnchor)
            ecrit.insertFragment(source.selection())
            if bloc.userState() == CORRIGE:
                ecrit.setPosition(debut)
                ecrit.setPosition(debut + f - d, QTextCursor.MoveMode.KeepAnchor)
                ecrit.mergeCharFormat(self._couleur(DONNE))
                ecrit.setPosition(debut + f - d)
            ecart = self.retraits.get(bloc.blockNumber(), 0) if d == bloc.position() else 0
            if ecart:  # une ligne mal indentée se copie à sa bonne indentation, comme elle s'exécute
                fin = ecrit.position()
                ecrit.setPosition(debut)
                if ecart > 0:
                    ecrit.insertText(" " * ecart)
                else:
                    ecrit.setPosition(debut - ecart, QTextCursor.MoveMode.KeepAnchor)
                    ecrit.removeSelectedText()
                ecrit.setPosition(fin + ecart)
        donnees.setHtml(copie.toHtml())
        return donnees

    def _blocs(self):
        bloc = self.document().begin()
        while bloc.isValid():
            yield bloc
            bloc = bloc.next()

    def insertFromMimeData(self, source):
        """Collé d'un énoncé, des consignes ou de cet éditeur, chaque morceau garde sa couleur (le bleu et le turquoise
        du cours, le violet de l'élève) ; un texte sans couleur (le PDF du cours, un autre logiciel) est du code du cours,
        en bleu (l'utilisateur, 03/10/2026). L'indentation en « $ » du cours redevient des espaces."""
        if not self.TEINTE or self.isReadOnly() or not source.hasText():
            return super().insertFromMimeData(source)
        morceaux = []
        if source.hasHtml():
            document = QTextDocument()
            document.setHtml(source.html())
            bloc = document.begin()
            while bloc.isValid():
                if morceaux:
                    morceaux.append(("\n", DONNE))
                morceau = bloc.begin()
                while not morceau.atEnd():
                    fragment = morceau.fragment()
                    texte, couleur = fragment.text().replace("\u00a0", " ").replace("\u2028", "\n"), fragment.charFormat().foreground().color()
                    if not fragment.charFormat().hasProperty(QTextCharFormat.Property.ForegroundBrush) or couleur.alpha() == 0:
                        couleur = QColor(DONNE)  # sans couleur, ou le retrait transparent du cours (ses « $ » : plus bas)
                    morceaux.append((texte, DONNE if couleur == QColor("black") else couleur.name()))
                    morceau += 1
                bloc = bloc.next()
        if not "".join(t for t, _ in morceaux).strip():
            morceaux = [(source.text(), DONNE)]
        curseur = self.textCursor()
        curseur.beginEditBlock()
        for texte, couleur in morceaux:
            curseur.insertText(RETRAIT_COLLE.sub(lambda m: " " * len(m.group()), texte), self._couleur(couleur))
        curseur.endEditBlock()
        self.setTextCursor(curseur)
        self.ensureCursorVisible()

    def _gris(self):
        """Les commentaires en gris, par-dessus toute autre couleur."""
        selections, document = [], self.document()
        for ligne, colonne in commentaires(self.toPlainText(), "#").items():
            bloc = document.findBlockByNumber(ligne - 1)
            selection = QTextEdit.ExtraSelection()
            selection.cursor = QTextCursor(bloc)
            selection.cursor.setPosition(bloc.position() + colonne)
            selection.cursor.movePosition(QTextCursor.MoveOperation.EndOfBlock, QTextCursor.MoveMode.KeepAnchor)
            selection.format = self._couleur(COMMENTAIRE)
            selections.append(selection)
        return selections

    def _teinter(self):
        """La couleur du texte est dans le document (``setPlainText``, ``keyPressEvent_texte``, ``insertFromMimeData``) :
        restent les commentaires en gris et, dans un code verrouillé, le fond des lignes à compléter. L'éditeur des
        questions « ordre » garde pour lui les surlignages de glissement, qui passent par le même mécanisme."""
        if not self.TEINTE:
            return
        if self.fixes:
            return self._teinter_zones()
        self.setExtraSelections(self._gris())

    # Le code verrouillé ----------------------------------------------------------------------------------

    def zones(self):
        """Les intervalles (début, fin) du texte où l'élève écrit ; vide si le texte ne suit plus le gabarit."""
        return zones_du_gabarit(self.fixes, self.toPlainText()) or []

    def _dans_zone(self, debut, fin):
        return any(d <= debut and fin <= f for d, f in self.zones())

    def _garder(self):
        """Le filet : une modification qui a touché une partie fixe (coller, glisser, couper, une touche que
        ``keyPressEvent`` ne prévoit pas) est défaite aussitôt."""
        if self.fixes and not self._retour and zones_du_gabarit(self.fixes, self.toPlainText()) is None:
            self._retour = True
            try:
                self.document().undo()
            finally:
                self._retour = False

    def _permise(self, evenement):
        """Une touche qui écrit ne s'accepte que si ce qu'elle remplace est dans une zone : la sélection, ou le
        caractère que Retour arrière ou Suppr effaceraient."""
        curseur = self.textCursor()
        debut, fin = curseur.selectionStart(), curseur.selectionEnd()
        if debut == fin and evenement.key() == Qt.Key.Key_Backspace:
            debut -= 1
        elif debut == fin and evenement.key() == Qt.Key.Key_Delete:
            fin += 1
        return self._dans_zone(debut, fin)

    def _teinter_zones(self):
        """Les lignes à compléter sur fond jaune clair, même vides : c'est là, et là seulement, que l'élève écrit ; le
        code qu'il a écrit à une autre question (``repris``) en violet dans les parties fixes, et les commentaires gris."""
        selections = []
        texte, zones = self.toPlainText(), self.zones()
        for repris in filter(None, self.repris):
            if (a := texte.find(repris)) >= 0:
                selection = QTextEdit.ExtraSelection()
                selection.cursor = QTextCursor(self.document())
                selection.cursor.setPosition(a)
                selection.cursor.setPosition(a + len(repris), QTextCursor.MoveMode.KeepAnchor)
                selection.format.setForeground(QColor(ELEVE))
                selections.insert(0, selection)  # devant le bleu du code donné : c'est la première qui l'emporte
        for d, f in zones:
            premier, dernier = self.document().findBlock(d), self.document().findBlock(f)
            bloc = premier
            while bloc.isValid():
                fond = QTextEdit.ExtraSelection()
                fond.cursor = QTextCursor(bloc)
                fond.format.setBackground(QColor(ZONE))
                fond.format.setProperty(QTextCharFormat.Property.FullWidthSelection, True)
                selections.insert(0, fond)  # dessous : la couleur du texte reste celle des sélections suivantes
                if bloc == dernier:
                    break
                bloc = bloc.next()
        self.setExtraSelections(self._gris() + selections)

    # L'annulation -----------------------------------------------------------------------------------------

    def annulable(self):
        """Ce que Qt sait défaire : la pile s'arrête au texte de départ, vide ou pré-rempli par la question."""
        return self.document().isUndoAvailable()

    def retablissable(self):
        return self.document().isRedoAvailable()

    # L'indentation ----------------------------------------------------------------------------------------

    def keyPressEvent(self, evenement):
        if evenement.key() in (Qt.Key.Key_Tab, Qt.Key.Key_Backtab) and not self.isReadOnly():
            self.indenter(1 if evenement.key() == Qt.Key.Key_Tab else -1)
        elif self._dans_retrait(evenement):
            self.indenter(-1)
        elif (self.fixes and not self.isReadOnly() and self._ecrit(evenement) and not self._permise(evenement)):
            return  # hors des lignes à compléter : la touche est ignorée
        elif not (self.TEINTE and not self.isReadOnly() and caractere(evenement) and self.keyPressEvent_texte(evenement)):
            super().keyPressEvent(evenement)

    def _dans_retrait(self, evenement: QKeyEvent) -> bool:
        """Retour arrière ou Suppr, le curseur dans les espaces de tête de sa ligne : la ligne descend au niveau
        d'indentation inférieur, comme par Maj+Tab, au lieu de perdre un espace (16/10/2026 : « la touche suprimer dans
        la zone gauche d'indentation, doit enlever jusqu'a niveau d'indentation inférieur »)."""
        curseur = self.textCursor()
        if (self.isReadOnly() or curseur.hasSelection() or evenement.modifiers() != Qt.KeyboardModifier.NoModifier
                or evenement.key() not in (Qt.Key.Key_Backspace, Qt.Key.Key_Delete)):
            return False
        texte, colonne = curseur.block().text(), curseur.positionInBlock()
        retrait = len(texte) - len(texte.lstrip(" "))
        if evenement.key() == Qt.Key.Key_Backspace:
            return 0 < colonne <= retrait
        return colonne < retrait

    @staticmethod
    def _ecrit(evenement):
        """Vrai pour une touche qui modifierait le texte : un caractère, Entrée, Retour arrière, Suppr."""
        return (evenement.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Backspace, Qt.Key.Key_Delete)
                or caractere(evenement))

    def indenter(self, sens):
        """Chaque ligne touchée passe au niveau d'indentation voisin. Une indentation qui n'est pas un multiple de
        ``PAS`` n'est pas décalée de ``PAS`` : elle est complétée jusqu'au niveau au-dessus (Tab) ou tronquée au
        niveau en dessous (Maj+Tab), ce qui remet d'aplomb un code recopié à la main."""
        curseur, document = self.textCursor(), self.document()
        ancre, tete = curseur.anchor(), curseur.position()
        premier = document.findBlock(min(ancre, tete)).blockNumber()
        dernier = document.findBlock(max(ancre, tete)).blockNumber()
        ecart = 0
        if self.fixes:  # verrouillé : seules les lignes que l'élève a ajoutées dans une zone changent de niveau
            zones = self.zones()
            lignes = [n for n in range(premier, dernier + 1)
                      if any(d < document.findBlockByNumber(n).position() <= f for d, f in zones)]
            if not lignes:
                return
            premier, dernier = lignes[0], lignes[-1]
            if len(lignes) != dernier - premier + 1:
                return
        curseur.beginEditBlock()
        for n in range(premier, dernier + 1):
            bloc = document.findBlockByNumber(n)
            texte = bloc.text()
            avant = len(texte) - len(texte.lstrip(" "))
            apres = (avant // PAS + 1) * PAS if sens > 0 else max(0, -(-avant // PAS) - 1) * PAS
            curseur.setPosition(bloc.position())
            curseur.setPosition(bloc.position() + avant, QTextCursor.MoveMode.KeepAnchor)
            curseur.insertText(" " * apres)
            ecart = apres - avant
        curseur.endEditBlock()
        if ancre != tete:  # une sélection recouvre après coup les lignes entières qu'elle a fait bouger
            curseur.setPosition(document.findBlockByNumber(premier).position())
            fin = document.findBlockByNumber(dernier)
            curseur.setPosition(fin.position() + fin.length() - 1, QTextCursor.MoveMode.KeepAnchor)
        else:  # une seule ligne : le curseur garde sa colonne, décalée de ce que l'indentation a gagné ou perdu
            curseur.setPosition(max(document.findBlockByNumber(premier).position(), tete + ecart))
        self.setTextCursor(curseur)


def lignes_barrees(texte: str, corrections: list[tuple[int, str]], fautes: list[tuple[int, int]]) -> set[int]:
    """Les lignes (base 0) de ``texte`` que la correction barre, d'après les ``corrections`` et ``fautes`` de
    ``verifier.variantes_lignes`` : une ligne qui porte des caractères fautifs ; ou, pour une partie manquante (p, p), la
    ligne qui n'est qu'une version amputée de sa correction (insertion dans la ligne). Une ligne que seule précède une
    ligne ajoutée, ou une insertion en fin de texte, reste juste."""
    debuts, p = [], 0
    for ligne in texte.split("\n"):
        debuts.append(p)
        p += len(ligne) + 1
    lignes, barrees = texte.split("\n"), set()
    for a, b in fautes:
        i = bisect_right(debuts, a) - 1
        if a < b:
            barrees.update(range(i, bisect_right(debuts, b - 1)))
            continue
        voulues = [c.strip() for n, c in corrections if n == i + 1 and c.strip()]
        reste = iter(voulues[0]) if voulues else iter("")
        ecrite = lignes[i].strip()
        if voulues and len(ecrite) < len(voulues[0]) and all(c in reste for c in ecrite):  # sous-suite stricte
            barrees.add(i)
    return barrees


class EditeurCorrection(EditeurCode):
    """La correction d'un programme jugé ligne à ligne, en lecture seule, À LA PLACE de l'éditeur de l'élève (que rien
    n'écrit jamais : l'utilisateur, 15/10/2026). Un second contenu, qui a l'allure d'un code : chaque ligne de l'élève
    telle quelle, sans un caractère de plus (les caractères fautifs restent là où ils sont, la rature à la main les
    barre), et sous elle les lignes corrigées, à l'indentation de la solution, en ``main`` rouge. Un bloc barré
    (ligne remplacée ou en trop) est marqué ``BARRE``, une ligne corrigée ``CORRIGE`` : la marge ne numérote que les
    autres (un bloc barré que sa correction suit porte, rayé, le numéro de celle-ci : ``numeros``), la copie et
    l'exécution (``texte_execute``) les sautent. ``vers_correction`` convertit une position du texte de l'élève en
    position ici, pour que ``SurimpressionCode`` y trace ses ratures.

    Deux allègements (l'utilisateur, 14/10/2026 : « la correction à droite de la ligne quand elle y tient, une flèche pour
    une indentation manquante ou en trop ») : la ligne corrigée qui remplace seule une ligne barrée s'écrit à droite de
    celle-ci quand la largeur de l'éditeur le permet (son bloc, caché, reste dans le texte : positions, numéros, copie et
    exécution n'en dépendent pas ; ``_placer``, refait quand la largeur change) ; une ligne fausse par sa seule indentation
    n'est ni barrée ni récrite, ``SurimpressionCode`` la flèche jusqu'à sa colonne (``retraits``, qui la réindentent aussi
    à l'exécution et à la copie)."""

    ECART_DROITE = 3  # en espaces : entre une ligne barrée et sa correction écrite à droite
    _largeur_placee = None  # la largeur à laquelle ``_placer`` a rangé les lignes corrigées ; None : à refaire

    def __init__(self, source: EditeurCode, corrections: list[tuple[int, str]], fautes: list[tuple[int, int]],
                 main: QFont, rouge: str) -> None:
        super().__init__("", None, source.premiere)
        self.setReadOnly(True)
        self.setFont(source.font())
        self.setLineWrapMode(source.lineWrapMode())
        self.rouge = rouge  # aussi celui qui raye le numéro d'une ligne barrée (``peindre_marge``)
        texte = source.toPlainText()
        ajoutees: dict[int, list[str]] = {}
        for n, ligne in corrections:
            if ligne.strip():
                ajoutees.setdefault(n - 1, []).append(ligne)
        lignes, decales = texte.split("\n"), {}  # ligne de l'élève (base 0) → espaces qui lui manquent devant
        for i, voulues in ajoutees.items():
            if 0 <= i < len(lignes) and len(voulues) == 1 and voulues[0].strip() == lignes[i].strip() != "":
                decales[i] = len(voulues[0]) - len(voulues[0].lstrip(" ")) - (len(lignes[i]) - len(lignes[i].lstrip(" ")))
        for i in decales:
            del ajoutees[i]
        self.barrees = lignes_barrees(texte, corrections, fautes) - set(decales)
        self.retraits = {}
        document, origine = self.document(), source.document()
        document.setUndoRedoEnabled(False)
        self.blockSignals(True)  # un seul rangement à la fin, pas un par fragment
        curseur, etats = QTextCursor(document), []
        self._debuts_texte, self._debuts_correction = [], []
        premier = True
        for ligne in ajoutees.get(-1, []):  # avant la première ligne (n = 0) : une ligne d'un rangement remise en tête (``Ordre``)
            self._ecrire_rouge(curseur, "", ligne, False, main, rouge)
            curseur.insertBlock()
            etats.append(CORRIGE)
        for i in range(origine.blockCount()):
            bloc = origine.findBlockByNumber(i)
            if not premier:  # au format du bloc d'origine : sinon une ligne vide sous une ligne rouge prend sa police manuscrite, plus haute
                curseur.insertBlock(bloc.blockFormat(), bloc.charFormat())
            premier = False
            self._debuts_texte.append(bloc.position())
            self._debuts_correction.append(curseur.position())
            morceau = bloc.begin()
            while not morceau.atEnd():
                fragment = morceau.fragment()
                curseur.insertText(fragment.text(), fragment.charFormat())
                morceau += 1
            if i in decales:
                self.retraits[len(etats)] = decales[i]
            etats.append(BARRE if i in self.barrees else -1)
            for ligne in ajoutees.get(i, []):
                curseur.insertBlock()
                self._ecrire_rouge(curseur, bloc.text(), ligne, i in self.barrees and len(ajoutees[i]) == 1, main, rouge)
                etats.append(CORRIGE)
        for k, etat in enumerate(etats):
            document.findBlockByNumber(k).setUserState(etat)
        self.blockSignals(False)
        document.setModified(False)
        self._poser_marge()
        self._teinter()
        self._largeur_placee = None  # rangé à vide par les changements de police de la construction
        self._placer()

    def a_droite(self, bloc) -> bool:
        """La ligne corrigée ``bloc`` peut s'écrire à droite de la ligne barrée qu'elle remplace seule."""
        avant, apres = bloc.previous(), bloc.next()
        return bloc.userState() == CORRIGE and avant.userState() == BARRE and apres.userState() != CORRIGE

    @staticmethod
    def _fragments_rouges(bloc) -> list[tuple[str, QTextCharFormat]]:
        """Les morceaux de la ligne corrigée ``bloc``, sans son retrait (le premier, d'espaces seuls : ``_ecrire_rouge``)."""
        fragments, morceau = [], bloc.begin()
        while not morceau.atEnd():
            fragment = morceau.fragment()
            if fragments or fragment.text().strip():
                fragments.append((fragment.text(), fragment.charFormat()))
            morceau += 1
        return fragments

    def _largeur_rouge(self, bloc) -> float:
        """La largeur de la ligne corrigée ``bloc`` sans son retrait, dans ses polices."""
        return sum(QFontMetricsF(marque.font()).horizontalAdvance(texte) for texte, marque in self._fragments_rouges(bloc))

    def _gauche_rouge(self, bloc) -> float:
        """Où commence, depuis le bord gauche du texte, la correction écrite à droite de la ligne barrée avant ``bloc``."""
        metrique = self.fontMetrics()
        return metrique.horizontalAdvance(bloc.previous().text()) + metrique.horizontalAdvance(" " * self.ECART_DROITE)

    def _placer(self) -> None:
        """Chaque ligne corrigée qui le peut va à droite de sa ligne barrée si elle y tient à la largeur actuelle, dessous
        sinon (bloc montré) ; refait seulement quand la largeur change."""
        largeur = self.viewport().width() - 2 * self.document().documentMargin()
        if largeur == self._largeur_placee:
            return
        self._largeur_placee = largeur
        for bloc in self._blocs():
            if self.a_droite(bloc):
                cache = self._gauche_rouge(bloc) + self._largeur_rouge(bloc) <= largeur
                if cache == bloc.isVisible():
                    bloc.setVisible(not cache)
                    self.document().markContentsDirty(bloc.position(), bloc.length())

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self._placer()

    def changeEvent(self, evenement):
        super().changeEvent(evenement)
        if evenement.type() == QEvent.Type.FontChange:
            self._largeur_placee = None
            self._placer()

    def largeur_texte(self, bloc) -> float:
        suivant = bloc.next()
        if not bloc.isVisible():
            return 0.0
        if suivant.isValid() and not suivant.isVisible():
            return self._gauche_rouge(suivant) + self._largeur_rouge(suivant)
        return super().largeur_texte(bloc)

    def paintEvent(self, evenement):
        """Les lignes corrigées cachées, écrites à droite de leur ligne barrée, dans leurs polices et leurs soulignés."""
        super().paintEvent(evenement)
        peintre, gauche = QPainter(self.viewport()), self.contentOffset().x() + self.document().documentMargin()
        for bloc in self._blocs():
            if bloc.isVisible() or bloc.userState() != CORRIGE:
                continue
            barree = bloc.previous()
            ligne = barree.layout().lineAt(0)
            base = self.blockBoundingGeometry(barree).translated(self.contentOffset()).top() + ligne.y() + ligne.ascent()
            x = gauche + self._gauche_rouge(bloc)
            for texte, marque in self._fragments_rouges(bloc):
                peintre.setFont(marque.font())
                peintre.setPen(marque.foreground().color())
                peintre.drawText(QPointF(x, base), texte)
                x += QFontMetricsF(marque.font()).horizontalAdvance(texte)

    def _ecrire_rouge(self, curseur: QTextCursor, ecrite: str, ligne: str, comparer: bool, main: QFont, rouge: str) -> None:
        """Écrit au ``curseur`` la ligne corrigée ``ligne`` : son retrait, puis son texte en ``main`` rouge (``_morceaux``)."""
        retrait = len(ligne) - len(ligne.lstrip(" "))
        marque = QTextCharFormat()
        marque.setForeground(QColor(rouge))
        curseur.insertText(" " * retrait, marque)
        marque.setFont(main)
        for morceau_rouge, change in self._morceaux(ecrite, ligne, comparer):
            marque.setFontUnderline(change)
            curseur.insertText(morceau_rouge, marque)

    @staticmethod
    def _morceaux(ecrite: str, voulue: str, comparer: bool) -> list[tuple[str, bool]]:
        """La ligne corrigée ``voulue`` découpée en ``(texte, changé)`` : sous une ligne barrée qu'elle remplace seule
        (``comparer``), les caractères qu'elle ajoute ou change par rapport à ``ecrite`` sont soulignés, pour qu'on
        voie la faute sans comparer les deux lignes à l'œil (l'utilisateur, 16/10/2026 : « je veux un localisation au
        caractère ») ; sinon, ou si les deux lignes ont moins de la moitié en commun (Superviseur), tout d'un morceau."""
        voulue = voulue.strip()
        comparaison = SequenceMatcher(None, ecrite.strip(), voulue, autojunk=False)
        if not comparer or comparaison.ratio() < 0.5:  # une ligne récrite de bout en bout : pas une pluie de petits traits
            return [(voulue, False)]
        morceaux = []
        for o, _, _, j1, j2 in comparaison.get_opcodes():
            texte = voulue[j1:j2]
            coeur = texte.strip() if o != "equal" else ""
            if coeur:  # les blancs de bord d'un ajout ne se soulignent pas (« n_+ 1 », capture du 16/10/2026)
                g = texte.index(coeur)
                morceaux += [(texte[:g], False), (coeur, True), (texte[g + len(coeur):], False)]
            else:
                morceaux.append((texte, False))
        return [m for m in morceaux if m[0]]

    def vers_correction(self, position: int) -> int:
        """La position ici du caractère ``position`` du texte de l'élève."""
        i = max(0, bisect_right(self._debuts_texte, position) - 1)
        return self._debuts_correction[i] + position - self._debuts_texte[i]


class EditeurLignes(EditeurCode):
    """Des lignes de code à remettre dans l'ordre et au bon niveau d'indentation : on prend une ligne à la souris et
    on la fait glisser, verticalement pour la déplacer, horizontalement pour changer son niveau ; Tab et Maj+Tab
    changent le niveau de la dernière ligne prise. Avec ``retirable`` (lignes distractrices d'un ``Ordre``), un double-clic
    ou Suppr sort une ligne du rangement, le geste qui renvoie une étiquette dans toutes les questions à glisser
    (l'utilisateur, 14/10/2026 : « je ne veux garder que le double clic », la croix au bout de la ligne et le lâcher hors
    de l'éditeur retirés), ainsi qu'une ligne lâchée sur les lignes proposées (``renvoi``, 16/10/2026 : « il faudrait
    pouvoir sortir un ligne de l'editeur avec un glissé-deposé vers les "Lignes proposées" ») ; ``ajouter`` l'y remet au
    bout.

    Au doigt (``tactile.ACTIF``), un glissé fait défiler la page comme partout ailleurs : une ligne se saisit d'un appui
    long (``tactile.AppuiLong``), puis se glisse jusqu'au lever (``_Suivi``). La
    convention des listes d'un ``Ordre`` (TODO Lecteur web, 11 et 12), la même en natif et dans le navigateur.

    ``lignes`` est le texte de chaque élément dans le BON ordre, indentation comprise ; ``ordre`` donne, pour chaque
    ligne affichée, l'indice de l'élément qui s'y trouve, et ``niveaux`` son niveau d'indentation (``None`` : celui
    du code juste). Ce sont eux que la question lit et écrit.

    Le texte n'étant pas modifiable, l'annulation de Qt n'a rien à défaire : c'est ``histoire`` qui garde les
    rangements successifs, pour que Ctrl+Z rende un déplacement malheureux."""

    TEINTE = False  # ses lignes gardent la couleur du texte : ses surlignages de glissement passent par les sélections
    NIVEAU_MAXI = 8  # au-delà, la ligne sortirait du cadre : aucun code d'élève n'en demande autant

    def __init__(self, lignes, ordre, niveaux=None):
        super().__init__()
        self.lignes = [l.lstrip(" ") for l in lignes]
        self.justes = [(len(l) - len(l.lstrip(" "))) // PAS for l in lignes]
        self.prise, self.courante = None, None  # ``self.ordre`` et ``self.niveaux`` sont posés par ``ranger``
        self.histoire, self.rang = [], -1
        self.retirable = False
        self.depot = None  # pendant le glisser d'une ligne proposée au-dessus de l'éditeur, son rang, où elle est déjà entrée
        self.renvoi = None  # posé par ``Ordre`` : (point global, élément) -> vrai au-dessus des lignes proposées
        self.setReadOnly(True)
        self.setAcceptDrops(True)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.viewport().setCursor(Qt.CursorShape.OpenHandCursor)
        self.toucher = tactile.Toucher()
        tactile.AppuiLong(self.viewport(), self._prendre_au_doigt)
        self.ranger(ordre, niveaux)

    def ranger(self, ordre, niveaux=None):
        self._poser(ordre, [self.justes[i] for i in ordre] if niveaux is None else niveaux)
        if self.prise is None:  # pendant un déplacement, l'étape d'annulation attend le lâcher : un pas, pas un pixel
            self._memoriser()

    def ajouter(self, i):
        self.ranger(self.ordre + [i], self.niveaux + [0])

    def retirer(self, ligne):
        self.courante = None
        self.ranger(self.ordre[:ligne] + self.ordre[ligne + 1:], self.niveaux[:ligne] + self.niveaux[ligne + 1:])

    def _poser(self, ordre, niveaux):
        self.ordre, self.niveaux = list(ordre), list(niveaux)
        self.setPlainText("\n".join(" " * PAS * n + self.lignes[i] for i, n in zip(self.ordre, self.niveaux)))
        self._surligner()  # le texte reposé a perdu ses sélections : le bleu comme la ligne prise

    # L'annulation -----------------------------------------------------------------------------------------

    def annulable(self):
        return self.rang > 0

    def retablissable(self):
        return self.rang < len(self.histoire) - 1

    def _memoriser(self):
        del self.histoire[self.rang + 1:]  # on repart d'ici : ce qui avait été rétabli n'a plus de suite
        self.histoire.append((list(self.ordre), list(self.niveaux)))
        self.rang = len(self.histoire) - 1
        self.annulation.emit()  # le lâcher ne change pas le texte : sans ce signal, le bouton resterait éteint

    def undo(self):
        self._rejouer(-1)

    def redo(self):
        self._rejouer(1)

    def _rejouer(self, sens):
        if 0 <= self.rang + sens < len(self.histoire):
            self.rang += sens
            self._poser(*self.histoire[self.rang])  # rejouer un rangement n'en fait pas une étape de plus

    def keyPressEvent(self, evenement):
        """Ctrl+Z, Ctrl+Maj+Z, Tab et Maj+Tab : un éditeur en lecture seule ne les traite pas, c'est donc ici qu'ils
        agissent."""
        if evenement.matches(QKeySequence.StandardKey.Undo):
            self.undo()
        elif evenement.matches(QKeySequence.StandardKey.Redo):
            self.redo()
        elif evenement.key() in (Qt.Key.Key_Tab, Qt.Key.Key_Backtab):
            if self.courante is not None:
                self._decaler(self.courante, self.niveaux[self.courante] + (1 if evenement.key() == Qt.Key.Key_Tab else -1))
                self._memoriser()
        elif evenement.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace) and self.retirable and self.courante is not None:
            self.retirer(self.courante)
        else:
            super().keyPressEvent(evenement)

    # Le glisser depuis la réserve ------------------------------------------------------------------------

    def _rang_de_depot(self, y):
        """La ligne devant laquelle ira une ligne proposée lâchée à la hauteur ``y`` : l'écart le plus proche, comme dans
        les listes d'un ``Ordre`` ; le bout du code sous la dernière ligne."""
        rang, bloc = 0, self.firstVisibleBlock()
        while bloc.isValid() and bloc.blockNumber() < len(self.ordre):
            if self.blockBoundingGeometry(bloc).translated(self.contentOffset()).center().y() <= y:
                rang = bloc.blockNumber() + 1
            bloc = bloc.next()
        return rang

    def dragEnterEvent(self, evenement):
        self.dragMoveEvent(evenement)

    def dragMoveEvent(self, evenement):
        """Une ligne proposée glissée au-dessus de l'éditeur (14/10/2026, TP SNT : « je n'arrive pas à glisser des phrases
        depuis les lignes proposées dans l'éditeur ») : elle y entre aussitôt, à l'écart le plus proche, et suit le
        pointeur en écartant complètement les autres lignes, comme une ligne prise dans l'éditeur (l'utilisateur : « les
        lignes de code ne doivent pas juste s'écarter un peu, mais complètement se décaler »). ``depot`` est son rang tant
        que dure le glisser ; la réserve attend le lâcher pour se recomposer (``Ordre._garnir_reserve``). Le dépôt est une
        copie : un déplacement ferait retirer à la réserve une étiquette de trop au retour du glisser."""
        if not (self.retirable and evenement.mimeData().hasFormat(RANG_GLISSE)):
            return evenement.ignore()
        evenement.setDropAction(Qt.DropAction.CopyAction)
        evenement.accept()
        y, niveau = evenement.position().y(), self._niveau_de_depot(evenement)
        if self.depot is None:
            i, rang = int(bytes(evenement.mimeData().data(RANG_GLISSE)).decode()), self._rang_de_depot(y)
            if i in self.ordre:
                return
            self.depot = self.courante = rang
            self._poser(self.ordre[:rang] + [i] + self.ordre[rang:], self.niveaux[:rang] + [niveau] + self.niveaux[rang:])
            return
        if (cible := self._ligne(y)) != self.depot:
            ordre, niveaux = list(self.ordre), list(self.niveaux)
            ordre.insert(cible, ordre.pop(self.depot))
            niveaux.insert(cible, niveaux.pop(self.depot))
            self.depot = self.courante = cible
            self._poser(ordre, niveaux)
        self._decaler(self.depot, niveau)

    def _niveau_de_depot(self, evenement: QDropEvent) -> int:
        """Le niveau d'indentation où tombe le bord gauche de l'étiquette glissée, celui que montre l'image qui suit le
        pointeur, arrondi au plus proche (14/10/2026 : « le glissé à partir de "Lignes proposées" doit aussi permetre le
        choix de l'indentation de la ligne déposée »). Le pointeur tient l'image à ``hotSpot`` de son bord gauche ; le
        ``QDrag`` est un enfant de la liste d'où il part, le temps du glisser."""
        source = evenement.source()
        drags = source.findChildren(QDrag) if source is not None else []
        prise = drags[-1].hotSpot().x() if drags else 0
        gauche = evenement.position().x() - prise - self.contentOffset().x() - self.document().documentMargin()
        return max(0, min(self.NIVEAU_MAXI, round(gauche / (PAS * self.fontMetrics().horizontalAdvance(" ")))))

    def dragLeaveEvent(self, evenement):
        """Ressortie de l'éditeur sans être lâchée : la ligne en repart."""
        if self.depot is not None:
            rang, self.depot, self.courante = self.depot, None, None
            self._poser(self.ordre[:rang] + self.ordre[rang + 1:], self.niveaux[:rang] + self.niveaux[rang + 1:])

    def dropEvent(self, evenement):
        if self.depot is None:
            return evenement.ignore()
        evenement.setDropAction(Qt.DropAction.CopyAction)
        evenement.accept()
        self.depot = None
        self.ranger(self.ordre, self.niveaux)  # une étape d'annulation, et la réserve qui se recompose

    def _decaler(self, ligne, niveau):
        niveaux = list(self.niveaux)
        niveaux[ligne] = max(0, min(self.NIVEAU_MAXI, niveau))
        if niveaux != self.niveaux:
            self._poser(self.ordre, niveaux)

    # La souris --------------------------------------------------------------------------------------------

    def _ligne(self, y):
        return min(self.cursorForPosition(QPoint(0, int(y))).blockNumber(), len(self.ordre) - 1)

    def mouseDoubleClickEvent(self, evenement):
        if self.retirable and self.ordre:
            self.retirer(self._ligne(evenement.position().y()))
        else:
            super().mouseDoubleClickEvent(evenement)

    def paintEvent(self, evenement):
        super().paintEvent(evenement)
        self._peindre_prise()

    def _peindre_prise(self):
        """La ligne prise, ou la ligne proposée qui entre, entourée du liseré bleu d'une étiquette saisie, de son premier à
        son dernier caractère, comme dans les listes d'un ``Ordre`` (14/10/2026 : « au lieu d'avoir un cadre bleu, j'ai un
        fond vert, ce n'est pas harmonisé avec les autres types de questions »)."""
        ligne = self.prise if self.prise is not None else self.depot
        if ligne is None:
            return
        peintre = QPainter(self.viewport())
        peintre.setRenderHint(QPainter.RenderHint.Antialiasing)
        bloc = self.document().findBlockByNumber(ligne)
        debut, fin = QTextCursor(bloc), QTextCursor(bloc)
        debut.setPosition(bloc.position() + len(bloc.text()) - len(bloc.text().lstrip(" ")))
        fin.movePosition(QTextCursor.MoveOperation.EndOfBlock)
        gauche, droite = self.cursorRect(debut).left(), self.cursorRect(fin).right()
        # centré sur le texte, du haut des majuscules au bas des jambages, et non sur le bloc, dont l'interligne est
        # tout en bas (14/10/2026 : « trop bas. il touche les caractères du haut, et il y a trop de marge en bas »)
        police, ligne = self.fontMetrics(), self.cursorRect(debut).top()
        haut, bas = ligne + police.ascent() - police.capHeight() - 4.5, ligne + police.ascent() + police.descent() + 3
        peintre.setPen(QPen(self.palette().highlight().color(), 3))
        peintre.drawRoundedRect(QRectF(gauche - 4, haut, droite - gauche + 8, bas - haut), 4, 4)
        peintre.end()

    def mousePressEvent(self, evenement):
        if self.toucher.appui(evenement) or not self.ordre:  # au doigt, rien avant le lever ou l'appui long ; toutes
            return  # les lignes renvoyées dans la réserve : rien à prendre
        self._prendre(evenement.position())

    def _prendre(self, position):
        self.prise = self.courante = self._ligne(position.y())
        self.origine = position.x(), self.niveaux[self.prise]  # d'où part le glissement horizontal
        self.viewport().setCursor(Qt.CursorShape.ClosedHandCursor)
        self._surligner()

    def _prendre_au_doigt(self, position):
        if self.ordre:
            self.toucher.point = None
            self._prendre(position)
            _Suivi(self)

    def mouseMoveEvent(self, evenement):
        self.toucher.bouge(evenement)
        if self.prise is None:
            return
        cible = self._ligne(evenement.position().y())
        if cible != self.prise:
            ordre, niveaux = list(self.ordre), list(self.niveaux)
            ordre.insert(cible, ordre.pop(self.prise))
            niveaux.insert(cible, niveaux.pop(self.prise))
            self.prise = self.courante = cible
            self.ranger(ordre, niveaux)
        x, niveau = self.origine  # un niveau tous les PAS caractères de glissement, arrondi au plus proche
        self._decaler(self.prise, niveau + round((evenement.position().x() - x) / (PAS * self.fontMetrics().horizontalAdvance(" "))))
        if self.retirable and self.renvoi:  # au-dessus des lignes proposées, le trait de la place où elle y retournera
            self.renvoi(evenement.globalPosition(), self.ordre[self.prise])

    def mouseReleaseEvent(self, evenement):
        self.toucher.leve(evenement)
        if self.prise is None:
            return
        ligne, self.prise = self.prise, None
        self.viewport().setCursor(Qt.CursorShape.OpenHandCursor)
        if self.retirable and self.renvoi and self.renvoi(evenement.globalPosition(), None):
            return self.retirer(ligne)  # lâchée sur les lignes proposées : une seule étape d'annulation, depuis avant la prise
        if (self.ordre, self.niveaux) != self.histoire[self.rang]:  # le déplacement achevé fait UNE étape d'annulation
            self._memoriser()
        self._surligner()

    def _surligner(self):
        """Tout le code est dans le bleu des énoncés (il est donné, l'élève ne fait que le ranger) ; la ligne prise
        est entourée tant que le clic est enfoncé (``_peindre_prise``), et plus rien une fois lâchée
        (l'utilisateur, 28/09/2026 : le fond pleine largeur, puis sa trace plus claire après le lâcher, étaient de trop).
        Tab et Maj+Tab décalent toujours la dernière ligne prise, ``courante``."""
        bleu = QTextEdit.ExtraSelection()
        bleu.format.setForeground(QColor(DONNE))
        bleu.cursor = QTextCursor(self.document())
        bleu.cursor.movePosition(QTextCursor.MoveOperation.End, QTextCursor.MoveMode.KeepAnchor)
        self.setExtraSelections([bleu])
        self.viewport().update()  # le liseré de la ligne prise, posé ou ôté


class _Suivi(QObject):
    """Une ligne saisie au doigt (``EditeurLignes._prendre_au_doigt``) : la souris que Qt tire du doigt, où qu'elle aille,
    est rendue aux gestionnaires de l'éditeur jusqu'au lever. Un appui est un lever perdu : il lâche la ligne là où elle est."""

    def __init__(self, editeur):
        super().__init__(editeur)
        self.editeur = editeur
        QApplication.instance().installEventFilter(self)

    def eventFilter(self, objet, evenement):
        genre = evenement.type()
        if genre not in (QEvent.Type.MouseMove, QEvent.Type.MouseButtonRelease, QEvent.Type.MouseButtonPress,
                         QEvent.Type.MouseButtonDblClick):
            return False
        e = self.editeur
        position = QPointF(e.viewport().mapFromGlobal(evenement.globalPosition()))
        if genre == QEvent.Type.MouseMove:
            e.mouseMoveEvent(QMouseEvent(genre, position, evenement.globalPosition(), Qt.MouseButton.NoButton,
                                         Qt.MouseButton.LeftButton, evenement.modifiers()))
            return True
        QApplication.instance().removeEventFilter(self)
        self.deleteLater()
        e.mouseReleaseEvent(QMouseEvent(QEvent.Type.MouseButtonRelease, position, evenement.globalPosition(),
                                        Qt.MouseButton.LeftButton, Qt.MouseButton.NoButton, evenement.modifiers()))
        return genre == QEvent.Type.MouseButtonRelease
