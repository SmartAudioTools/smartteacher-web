"""Le bilan d'un élève, à part de ses copies : un widget qtpy6 que ``serializejson`` écrit et relit tel quel. Il est chiffré
pour l'élève et le professeur seuls (``codes.cle_bilan``) dès que l'élève a un mot de passe ; EN CLAIR tant qu'il n'en a pas
choisi : il doit pouvoir le lire sans (l'utilisateur, 03/11/2026 : « je veux qu'un élève puisse voir son bilan meme sans mot
de passe », « le bilan ne continent aucunes réponses »). Un camarade qui devine le lien le lit alors : risque accepté.

Le fichier, « Bilan [Nom Prénom].report », est écrit par l'outil du professeur (``bilans.py fichiers``), recalculé à chaque
passage ; le lecteur l'ouvre comme une copie (``lecteur.py``, ``montrer``). Ce module tourne aussi dans le navigateur
(``web/construire.py``, ``FICHIERS_QT``) : il n'importe que ce que le lecteur web embarque.
"""

from __future__ import annotations

from datetime import datetime
from html import escape
from typing import Any

from qtpy6.QtCore import Qt
from qtpy6.QtWidgets import QDialog, QFormLayout, QLabel, QLineEdit, QScrollArea, QVBoxLayout, QWidget

import codes
import noyau
from modele import application, charger

EXTENSION = ".report"
ROUGE = "#c0392b"
REFUS = "Ce mot de passe n'ouvre pas ce bilan : s'il vient d'être réinitialisé, le bilan sera remis à jour au prochain passage du professeur."
DANS_L_ARBRE = ("Thèmes", "Capacités du programme")  # des axes que l'arbre (``bilans.arbre``) montre déjà, rangés


def nom_du_fichier(eleve: str) -> str:
    return codes.nom_de_fichier(f"Bilan [{eleve}]") + EXTENSION


def eleve_du_fichier(chemin: str, identites: dict[str, Any]) -> str:
    """« Nom Prénom » de l'élève déposé dans ``identites`` dont ``chemin`` est le bilan, vide s'il n'y est pas : par le nom
    du fichier refait, qui a pu perdre des caractères de son nom, et le secret d'un élève tient à son nom exact."""
    fichier = chemin.rpartition("/")[2]
    noms = (f"{e['nom']} {e['prenom']}" for e in identites.get("eleves", {}).values())
    return next((nom for nom in noms if nom_du_fichier(nom) == fichier), "")


def couleur(taux: float | None) -> str:
    if taux is None:
        return "gray"
    return noyau.VERT if taux >= noyau.SEUIL_FORT else ROUGE if taux < noyau.SEUIL_FAIBLE else "black"


def _pc(taux: float | None) -> str:
    return f'<span style="color:{couleur(taux)}">{"en attente" if taux is None else f"{taux:.0%}"}</span>'


def _note(p: dict[str, Any]) -> str:
    """La note, et à part les questions que le temps n'a pas laissé aborder (``bilans.releve_paquet``)."""
    if p["taux"] is None:
        return "—"
    n, s = p.get("non_abordees", 0), "s" * (p.get("non_abordees", 0) > 1)
    return f"{p['obtenu']:g} / {p['total']:g}" + (f" ({n} question{s} non abordée{s})" if n else "")


def _date(fin: float | None) -> str:
    return "pas encore rendue" if fin is None else datetime.fromtimestamp(fin).strftime("%d/%m/%Y")


def _branches(noeuds: list[list[Any]]) -> str:
    return "<ul>" + "".join(f"<li>{escape(l)} : {_pc(t)}{_branches(e) if e else ''}</li>" for l, _, _, t, e in noeuds) + "</ul>"


class Bilan(noyau.Objet, QWidget):
    """``parcours`` : ses copies dans l'ordre de leur rendu, ``{"epreuve", "fin", "etat", "obtenu", "total", "taux"}``
    (``taux`` ``None`` en attente : jamais compté 0) ; ``conseils`` : des phrases à l'élève ; ``axes`` :
    ``[[axe, [[libellé, gagné, noté, taux], …]], …]`` sur les seules copies corrigées (``bilans.bilan_eleve``) ;
    ``appreciations`` : ``[[titre, texte], …]``, celle du bulletin s'il continue ainsi (``bilans.appreciations``) ;
    ``annee`` : sa moyenne sur 20 à ce jour, de la ``periode`` (« de l'année », « du 1er trimestre » :
    ``bilans.moyenne_affichee``), rien en tête sans copie notée ; ``arbre`` : ``[[libellé, gagné, noté, taux, enfants],
    …]``, thème, section du cours ou contenu du BO, capacité (``bilans.arbre``), qui remplace ``DANS_L_ARBRE``."""

    def __init__(self, eleve: str, parcours: list[dict[str, Any]], axes: list[list[Any]] = (), genere: str = "",
                 conseils: list[str] = (),
                 appreciations: list[list[str]] = (), annee: float | None = None,
                 periode: str = "de l'année", arbre: list[list[Any]] = ()) -> None:
        application()
        QWidget.__init__(self)
        self.eleve, self.parcours, self.axes = eleve, parcours, list(axes)
        self.genere, self.annee, self.periode = genere, annee, periode
        self.conseils, self.appreciations, self.arbre = list(conseils), [list(a) for a in appreciations], list(arbre)
        self.setWindowTitle(f"Bilan de {eleve}")
        d = QVBoxLayout(self)
        for texte in self._sections():
            etiquette = QLabel(texte)
            etiquette.setWordWrap(True)
            etiquette.setTextFormat(Qt.TextFormat.RichText)
            etiquette.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            d.addWidget(etiquette)
        d.addStretch()

    def _sections(self) -> list[str]:
        statistiques = [(axe, [(l, g, n) for l, g, n, _ in lignes]) for axe, lignes in self.axes]
        forts, faibles = noyau.ressorts(statistiques, 5)
        tete = [f"Moyenne {self.periode} à ce jour : <b>{f'{round(self.annee, 1):g}'.replace('.', ',')} / 20</b>"
                ] if self.annee is not None else []
        tete += [f"établi le {self.genere}"] if self.genere else []
        sections = [f"<h2>Bilan de {escape(self.eleve)}</h2>" + (f"<p>{' — '.join(tete)}</p>" if tete else "")]
        if self.appreciations:
            sections.append("<h3>Votre appréciation</h3>" + "".join(
                f"<p><b>{escape(titre)}</b> : {escape(texte)}</p>" for titre, texte in self.appreciations))
        if forts or faibles:
            sections.append("".join(f"<p><b>{titre}</b> : {escape(', '.join(libelles))}</p>" for titre, libelles in
                                    (("Points solides", forts), ("À retravailler", faibles)) if libelles))
        lignes = "".join(
            f"<tr><td>{escape(p['epreuve'])}</td><td>{_date(p['fin'])}</td>"
            f"<td align=right>{_note(p)}</td>"
            f"<td align=right>{_pc(p['taux'])}</td></tr>" for p in self.parcours)
        sections.append("<h3>Copie après copie</h3><table cellspacing=0 cellpadding=4>"
                        "<tr><th align=left>Épreuve</th><th align=left>Rendue le</th><th>Note</th><th>Réussite</th></tr>"
                        f"{lignes}</table>")
        if self.conseils:
            sections.append("<h3>Conseils</h3><ul>" + "".join(f"<li>{escape(c)}</li>" for c in self.conseils) + "</ul>")
        if self.arbre:
            sections.append("<h3>Thème par thème</h3>" + _branches(self.arbre))
        for axe, detail in self.axes:
            if self.arbre and axe in DANS_L_ARBRE:
                continue
            sections.append(f"<h3>{axe}</h3><table cellspacing=0 cellpadding=2>" + "".join(
                f"<tr><td>{escape(l)}</td><td align=right>{_pc(t)}</td></tr>" for l, _, _, t in detail) + "</table>")
        return sections


def ouvrir_bilan(chemin: str, cle: str | None = None) -> Bilan | None:
    """Le bilan ``chemin``, en clair ou ouvert par ``cle``, ou ``None`` s'il est chiffré pour une autre clé. Le clair d'abord :
    serializejson refuse une clé sur un fichier qui n'est pas chiffré."""
    for essai in (None, cle) if cle else (None,):
        try:
            bilan = charger(chemin, essai)
        except ValueError as erreur:  # serializejson : DecryptionError (autre clé), ou chiffré sans mot de passe
            if "password" in str(erreur) or "decryption" in str(erreur):
                continue
            raise
        if not isinstance(bilan, Bilan):
            raise ValueError(f"{chemin} : pas un bilan d'élève")
        return bilan
    return None


def cle_du_secret(secret: bytes | None, identites: dict[str, Any]) -> str | None:
    """La clé du bilan de l'élève de ce ``secret`` (entré par son mot de passe, ou gardé sur ce poste), si on la connaît."""
    return codes.cle_bilan(secret, identites["professeur"]) if secret and identites.get("professeur") else None


def ouvrir_par_mot_de_passe(chemin: str, eleve: str, tape: str, identites: dict[str, Any]) -> Bilan | None:
    """Le bilan de ``eleve`` ouvert par le mot de passe ``tape``, le sien ou celui du professeur, ou ``None``."""
    if eleve and (bilan := ouvrir_bilan(chemin, cle_du_secret(codes.secret_eleve(eleve, "", tape), identites))):
        return bilan
    deposee = codes.entree_deposee(identites, eleve, "") if eleve else None
    return ouvrir_bilan(chemin, codes.cle_bilan(codes._secret_professeur(tape), deposee["publique"])) if deposee else None  # noqa: SLF001


class AccueilBilan(QDialog):
    """Le mot de passe, seul champ, pour un bilan chiffré que rien d'autre n'a ouvert (``montrer``) ; Entrée ouvre. Ne bloque
    pas (``open``, comme ``lecteur.Accueil``) : ``ouvert`` reçoit la fenêtre du bilan."""

    def __init__(self, chemin: str, ouvert: Any, eleve: str, identites: dict[str, Any]) -> None:
        super().__init__()
        self.chemin, self.ouvert, self.eleve, self.identites = chemin, ouvert, eleve, identites
        self.setWindowTitle("Bilan")
        self.mot_de_passe = QLineEdit()
        self.mot_de_passe.setEchoMode(QLineEdit.EchoMode.Password)
        self.mot_de_passe.returnPressed.connect(self.essayer)
        self.message = QLabel("Tapez votre mot de passe, puis Entrée.")
        self.message.setWordWrap(True)
        formulaire = QFormLayout(self)
        formulaire.addRow("Mot de passe", self.mot_de_passe)
        formulaire.addRow(self.message)
        self.setMinimumWidth(360)

    def essayer(self) -> None:
        bilan = ouvrir_par_mot_de_passe(self.chemin, self.eleve, self.mot_de_passe.text(), self.identites)
        if bilan is None:
            self.message.setText(REFUS)
            return
        self.accept()
        self.ouvert(fenetre(bilan))


def montrer(chemin: str, ouvert: Any, eleve: str, identites: dict[str, Any], garde: bytes | None = None) -> AccueilBilan | None:
    """Le bilan ``chemin`` à l'écran, sans rien demander s'il est en clair ou si le secret ``garde`` de ce poste l'ouvre :
    ``ouvert`` reçoit sa fenêtre. Sinon rend la boîte du mot de passe, ouverte, à garder tant qu'elle sert."""
    bilan = ouvrir_bilan(chemin, cle_du_secret(garde, identites))
    if bilan is not None:
        ouvert(fenetre(bilan))
        return None
    boite = AccueilBilan(chemin, ouvert, eleve, identites)
    boite.open()
    return boite


def fenetre(bilan: Bilan) -> QScrollArea:
    """Le bilan dans une zone défilante, à garder tant qu'elle est ouverte."""
    zone = QScrollArea()
    zone.setWidget(bilan)
    zone.setWidgetResizable(True)
    zone.setWindowTitle(bilan.windowTitle())
    zone.resize(720, 800)
    zone.show()
    return zone
