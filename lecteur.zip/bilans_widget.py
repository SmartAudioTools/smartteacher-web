"""Le bilan d'un élève, à part de ses copies : un widget qtpy6 que ``serializejson`` écrit et relit tel quel. Il est chiffré
par la clé tirée de l'empreinte de l'élève (``codes.cle_bilan``) dès qu'il a un mot de passe : lui l'obtient de son mot de
passe, le professeur de l'empreinte déposée (``identites.json``), sans le sien ; EN CLAIR tant qu'il n'en a pas
choisi : il doit pouvoir le lire sans (l'utilisateur, 03/11/2026 : « je veux qu'un élève puisse voir son bilan meme sans mot
de passe », « le bilan ne continent aucunes réponses »). Un camarade qui devine le lien le lit alors : risque accepté.

Le fichier, « Bilan [Nom Prénom].report », est écrit par l'outil du professeur (``bilans.py fichiers``), recalculé à chaque
passage ; le lecteur l'ouvre comme une copie (``lecteur.py``, ``montrer``). Ce module tourne aussi dans le navigateur
(``web/construire.py``, ``FICHIERS_QT``) : il n'importe que ce que le lecteur web embarque.
"""

from __future__ import annotations

import hmac
from datetime import datetime
from html import escape
from typing import Any, Callable

import re
from pathlib import Path

from qtpy6.QtCore import Qt
from qtpy6.QtGui import QFontDatabase
from qtpy6.QtWidgets import QDialog, QFormLayout, QLabel, QLineEdit, QScrollArea, QVBoxLayout, QWidget

import codes
import noyau
from modele import application, charger

EXTENSION = ".report"
ROUGE = "#c0392b"
REFUS = "Ce mot de passe n'ouvre pas ce bilan : s'il vient d'être réinitialisé, le bilan sera remis à jour au prochain passage du professeur."
# l'état des notions que le lecteur de l'élève a rangé après sa dernière révision rendue (``revision.apres_copie``) :
# ``ETATS_LOCAUX(eleve)`` rend ``(lignes de revision.en_bilan, instant du calcul)`` ou None ; posé par le navigateur
# (``pont_qt``), où l'élève s'entraîne et revient à sa page ; None ailleurs (W457, 08/11/2026)
ETATS_LOCAUX: Callable[[str], tuple[list[list[Any]], float] | None] | None = None
PROVISOIRE = ("Jauges provisoires : vos révisions depuis le dernier bilan du professeur y sont comptées ; "
              "elles seront recalculées à son prochain passage.")
DANS_L_ARBRE = ("Thèmes", "Capacités du programme")  # des axes que l'arbre (``bilans.arbre``) montre déjà, rangés


def nom_du_fichier(eleve: str) -> str:
    return codes.nom_de_fichier(f"Bilan [{eleve}]") + EXTENSION


def eleve_du_fichier(chemin: str, identites: dict[str, Any]) -> str:
    """« Nom Prénom » de l'élève déposé dans ``identites`` dont ``chemin`` est le bilan, vide s'il n'y est pas : par le nom
    du fichier refait, qui a pu perdre des caractères de son nom, et le secret d'un élève tient à son nom exact."""
    fichier = chemin.rpartition("/")[2]
    noms = (f"{e['nom']} {e['prenom']}" for e in identites.get("eleves", {}).values())
    return next((nom for nom in noms if nom_du_fichier(nom) == fichier), "")


def couleur(taux: float | None) -> str:
    if taux is None:
        return "gray"
    return noyau.VERT if taux >= noyau.SEUIL_FORT else ROUGE if taux < noyau.SEUIL_FAIBLE else "black"


def _pc(taux: float | None) -> str:
    return f'<span style="color:{couleur(taux)}">{"en attente" if taux is None else f"{taux:.0%}"}</span>'


def _note(p: dict[str, Any]) -> str:
    """La note, et à part les questions que le temps n'a pas laissé aborder (``bilans.releve_paquet``)."""
    if p["taux"] is None:
        return "—"
    n, s = p.get("non_abordees", 0), "s" * (p.get("non_abordees", 0) > 1)
    return f"{p['obtenu']:g} / {p['total']:g}" + (f" ({n} question{s} non abordée{s})" if n else "")


def _date(fin: float | None) -> str:
    return "pas encore rendue" if fin is None else datetime.fromtimestamp(fin).strftime("%d/%m/%Y")


# l'écriture du professeur, pour les moyennes du bilan (l'utilisateur, 06/11/2026 : « les notes en manuscrit avec ma police
# d'écriture ») : BaptisteDLG, la famille de la correction papier (``correction/imprimer_correction.BAPTISTE``), mais sa
# graisse Bold, la note étant en gras (06/11/2026) : la Regular chargée seule laissait le gras sans effet, et la « Pression »
# de l'impression imite l'encre et sortait grise et pâle à l'écran ; sur le web,
# livrée réduite dans polices/ par ``web/construire.POLICES``. Repli : ``noyau.POLICE_MAIN``.
ECRITURE = Path("/DATA/Python/SmartTeacher_essais/ecriture_professeur/police/BaptisteDLG-Bold.ttf")


def police_manuscrite() -> str:
    """La famille de l'écriture du professeur, chargée une fois si le fichier est là (poste du professeur), déjà chargée
    depuis polices/ sur le web ; sinon Kalam, l'écriture de la correction."""
    if ECRITURE.exists() and "BaptisteDLG" not in QFontDatabase.families():
        QFontDatabase.addApplicationFont(str(ECRITURE))
    return "BaptisteDLG" if "BaptisteDLG" in QFontDatabase.families() else noyau.POLICE_MAIN


VERT_ECRITURE = "#008c40"  # noyau.VERT (#00b050) assombri d'un cinquième


def a_la_main(texte: str) -> str:
    """Un texte du professeur (appréciation, conseil) dans son écriture (l'utilisateur, 06/11/2026 : « l'appréciation avec
    mon écriture manuscrite », « Conseil : l'écrire avec mon écriture manuscrite »), un peu plus grand que le texte autour, en vert (« écrire avec mon écriture en vert, sauf pour
    la note »), le vert des corrections un peu foncé : ``noyau.VERT`` paraissait pâle sur le fond gris de la page
    (l'utilisateur, 06/11/2026 : « c'est surtout le fond gris qui le fait passer pour pâle, fonce-le légèrement »)."""
    return f"<span style=\"font-family:'{police_manuscrite()}'; font-size:large; color:{VERT_ECRITURE}\">{escape(texte)}</span>"


def manuscrit(note: str) -> str:
    """Une note sur 20 (« 12,5 ») à la main, « /20 » compris et sans espace, en gras, un peu plus grande que le texte
    autour et à la couleur de la jauge de même taux (l'utilisateur, 06/11/2026 : « passe la moyenne manuscrite en gras
    avec une couleur correspondant à la note, et sans espace autour du "/" qui doit être aussi écrit "à la main" »)."""
    couleur_note = teinte(float(note.replace(",", ".")) / 20)
    return (f"<span style=\"font-family:'{police_manuscrite()}'; font-size:x-large; font-weight:bold; color:{couleur_note}\">"
            f"{escape(note)}/20</span>")


JAUGE, PALIER, LIBELLES = 120, 16, 300  # largeur d'une jauge ; retrait d'un niveau de l'arbre ; colonne des libellés (px)
# une colonne de libellés de même largeur dans chaque thème : leurs jauges tombent toutes au même bord


def _jauge(taux: float | None) -> str:
    """La réussite en jauge (l'utilisateur, 06/11/2026 : « plutôt que des pourcentages, est-il possible d'avoir des jauges
    toutes alignées ? ») : la part remplie à la couleur du taux (orange entre les deux seuils, le noir ne se lit pas en
    barre), le reste en gris ; la jauge remplace le pourcentage."""
    if taux is None:
        return _pc(None)
    plein = round(JAUGE * max(0.0, min(1.0, taux)))
    cases = (f"<td width={plein} bgcolor='{teinte(taux)}'></td>" if plein else "") + (
        f"<td width={JAUGE - plein} bgcolor='{GRIS_JAUGE}'></td>" if plein < JAUGE else "")
    return f"<table width={JAUGE} height=10 cellspacing=0 cellpadding=0><tr>{cases}</tr></table>"


def teinte(taux: float) -> str:
    """La couleur d'une jauge remplie à ``taux`` : celle du taux, orange entre les deux seuils (le noir ne se lit pas en
    barre)."""
    return {"black": "#e67e22"}.get(couleur(taux), couleur(taux))


GRIS_JAUGE = "#d5d8dc"  # la part vide d'une jauge


def _lignes(noeuds: list[list[Any]], niveau: int = 0) -> str:
    return "".join(f"<tr><td width={LIBELLES} style='padding-left:{niveau * PALIER}px; padding-right:12px'>{escape(l)}</td>"
                   f"<td valign=middle>{_jauge(t)}</td></tr>" + (_lignes(e, niveau + 1) if e else "")
                   for l, _, _, t, e in noeuds)


def _branches(noeuds: list[list[Any]], tete: str = "") -> str:
    """Un arbre de réussite en un seul tableau : les libellés en retrait selon leur niveau, toutes les jauges dans la même
    colonne ; ``tete`` : une première ligne déjà écrite (la réussite du thème)."""
    return f"<table cellspacing=0 cellpadding=2 style='margin-left:{PALIER}px'>{tete}{_lignes(noeuds, 1 if tete else 0)}</table>"


# l'écart de réussite d'un thème sous lequel il est dit stable (« → ») : une question de 1 point sur 20 en vaut 5 %
STABLE = 0.05


def _fleche(avant: float, apres: float) -> str:
    ecart = round(apres - avant, 9)  # 0.30 - 0.25 vaut 0.0499… en flottants : arrondi, sinon 5 points tout juste seraient « → »
    return "↗" if ecart >= STABLE else "↘" if -ecart >= STABLE else "→"


def _meme_copie(a: float | None, b: float | None) -> bool:
    """Deux dates de rendu (``Paquet.fin``, ``time.time()``) de la même copie, relues d'un JSON : à la seconde près."""
    return a is not None and b is not None and abs(a - b) < 1


def evolution(themes_par_copie: list[list[Any]], fin: float | None) -> list[tuple[str, float, float | None, int]]:
    """Pour la copie rendue à ``fin``, chacun de ses thèmes (``bilans.themes_par_copie``) : ``(thème, taux de cette copie,
    taux des copies rendues avant elle sur ce thème ou None, nombre de ces copies)`` ; rien si la copie n'est pas dans le
    bilan (rendue après son dernier calcul, ou un ``.report`` d'avant le 06/11/2026, sans ce champ)."""
    ici: dict[str, list[float]] = {}
    for _, f, theme, g, n in themes_par_copie:
        if _meme_copie(f, fin):
            cumul = ici.setdefault(theme, [0, 0])
            cumul[0], cumul[1] = cumul[0] + g, cumul[1] + n
    resultat = []
    for theme, (g, n) in ici.items():
        avant = [(f, ga, na) for _, f, t, ga, na in themes_par_copie
                 if t == theme and f is not None and f < fin and not _meme_copie(f, fin)]
        notes = sum(na for _, _, na in avant)
        resultat.append((theme, g / n, sum(ga for _, ga, _ in avant) / notes if notes else None, len({f for f, _, _ in avant})))
    return resultat


def evolution_de_la_copie(themes_par_copie: list[list[Any]], fin: float | None) -> str:
    """Le bloc « Évolution » sous le bilan d'une copie rendue (``modele.Paquet.poser_bilan``), une ligne par thème de la
    copie : « Localisation : 62 % ici, 48 % avant (3 copies) ↗ » ; vide si ``evolution`` n'a rien."""
    lignes = []
    for theme, ici, avant, copies in evolution(themes_par_copie, fin):
        s = "s" * (copies > 1)
        suite = (f", {_pc(avant)} avant ({copies} copie{s}) {_fleche(avant, ici)}" if avant is not None
                 else ", première copie sur ce thème")
        lignes.append(f"{escape(theme)} : {_pc(ici)} ici{suite}")
    return "<b>Évolution</b><br>" + "<br>".join(lignes) if lignes else ""


RETRAIT = 24  # le retrait d'un sous-titre du bilan de l'année, puis de son contenu (celui des thèmes de la page)


class Bilan(noyau.Objet, QWidget):
    """``parcours`` : ses copies dans l'ordre de leur rendu, ``{"epreuve", "fin", "etat", "obtenu", "total", "taux"}``
    (``taux`` ``None`` en attente : jamais compté 0) ; ``conseils`` : des phrases à l'élève ; ``axes`` :
    ``[[axe, [[libellé, gagné, noté, taux], …]], …]`` sur les seules copies corrigées (``bilans.bilan_eleve``) ;
    ``appreciations`` : ``[[titre, texte], …]``, celle du bulletin s'il continue ainsi (``bilans.appreciations``) ;
    ``annee`` : sa moyenne sur 20 à ce jour, de la ``periode`` (« de l'année », « du 1er trimestre » :
    ``bilans.moyenne_affichee``), rien en tête sans copie notée ; ``arbre`` : ``[[libellé, gagné, noté, taux, enfants],
    …]``, thème, section du cours ou contenu du BO, capacité (``bilans.arbre``), qui remplace ``DANS_L_ARBRE`` ;
    ``themes_par_copie`` : ``[[épreuve, fin, thème, gagné, noté], …]`` (``bilans.themes_par_copie``), absent d'un bilan
    écrit avant le 06/11/2026 ; ``etat_notions`` : l'état de ses notions (``revision.en_bilan``), calculé à
    ``notions_le`` (``time.time()``), absents d'un bilan écrit avant le 07/11/2026 (``etats``). Trois bilans (l'utilisateur, 06/11/2026 : « les bilans (copie, thème, année) doivent être sur
    la page d'accueil ») : celui des copies (leur liste, note, date et thèmes), celui par thème (l'arbre des thèmes ; le détail par thème d'une copie, dans le premier, pour un DS à plusieurs
    thèmes), celui
    de l'année (moyenne, appréciation, points solides, conseils, autres axes)."""

    def __init__(self, eleve: str, parcours: list[dict[str, Any]], axes: list[list[Any]] = (), genere: str = "",
                 conseils: list[str] = (),
                 appreciations: list[list[str]] = (), annee: float | None = None,
                 periode: str = "de l'année", arbre: list[list[Any]] = (), themes_par_copie: list[list[Any]] = (),
                 etat_notions: list[list[Any]] = (), notions_le: float | None = None) -> None:
        application()
        QWidget.__init__(self)
        self.eleve, self.parcours, self.axes = eleve, parcours, list(axes)
        self.genere, self.annee, self.periode = genere, annee, periode
        self.conseils, self.appreciations, self.arbre = list(conseils), [list(a) for a in appreciations], list(arbre)
        self.themes_par_copie = [list(t) for t in themes_par_copie]
        self.etat_notions, self.notions_le = [list(e) for e in etat_notions], notions_le
        self.setWindowTitle(f"Bilan de {eleve}")
        d = QVBoxLayout(self)
        for texte in self._sections():
            etiquette = QLabel(texte)
            etiquette.setWordWrap(True)
            etiquette.setTextFormat(Qt.TextFormat.RichText)
            etiquette.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            d.addWidget(etiquette)
            if texte.startswith(("<h2>", "<h3")):  # de l'espace au-dessus d'une section, comme les titres de la page
                etiquette.setContentsMargins(0, 18 if texte.startswith("<h2>") else 8, 0, 0)  # d'accueil (06/11/2026)
            if texte.startswith("<h2>Bilan des copies"):
                etiquette.setObjectName("copies")
            elif texte.startswith("<h2>Bilan par thème"):
                etiquette.setObjectName("themes")
            elif texte.startswith(f"<h2>Bilan de {escape(self.eleve)}</h2>"):
                etiquette.setObjectName("entete")
        d.addStretch()

    def etats(self, maintenant: float | None = None) -> dict[tuple[str, ...], dict[str, Any]]:
        """L'état de ses notions, {notion : état} comme ``revision.etat_notions`` le rend, à ``maintenant`` (l'heure par
        défaut) ; vide pour un bilan qui ne le porte pas : tout est neuf."""
        import time  # noqa: PLC0415
        from revision import depuis_bilan  # noqa: PLC0415 - revision importe noyau et bilans
        return depuis_bilan(self.etat_notions, time.time() if maintenant is None else maintenant)

    provisoire = False  # ses jauges comptent des révisions faites depuis le calcul du professeur (``poser_etats``)

    def poser_etats(self, etats: dict[tuple[str, ...], dict[str, Any]], instant: float) -> None:
        """Les jauges refaites sur ``etats`` (l'état des notions calculé à ``instant`` chez l'élève, ``revision.apres_copie``),
        sans la banque, que le lecteur n'a pas : l'arbre du professeur garde ses nœuds, seules leurs jauges changent
        (``revision.jauges``) ; l'essai « Réviser » suivant part aussi de cet état. Marqué ``provisoire`` : le bilan suivant
        du professeur le remplace (demande du professeur, 08/11/2026 : « pour pouvoir s'entraîner en boucle »)."""
        from revision import en_bilan, jauges  # noqa: PLC0415 - revision importe noyau et bilans
        self.arbre = jauges(self.arbre, etats)
        self.etat_notions, self.notions_le, self.provisoire = en_bilan(etats), instant, True
        if (etiquette := self.findChild(QLabel, "themes")) is not None:
            etiquette.setText(f"<h2>Bilan par thème</h2>{_branches(self.arbre)}<p><i>{PROVISOIRE}</i></p>")

    def evolution(self, fin: float | None) -> str:
        """Le bloc « Évolution » de la copie rendue à ``fin`` (``evolution_de_la_copie``)."""
        return evolution_de_la_copie(self.themes_par_copie, fin)

    def _themes_de(self, p: dict[str, Any]) -> str:
        """Le détail par thème de la copie ``p`` (« Localisation 25%, Réseaux 75% »), vide si elle n'en touche qu'un."""
        themes = [(t, g, n) for e, f, t, g, n in self.themes_par_copie
                  if e == p["epreuve"] and (f == p["fin"] or _meme_copie(f, p["fin"])) and n]
        return ", ".join(f"{escape(t)} {_pc(g / n)}" for t, g, n in themes) if len(themes) > 1 else ""

    def _copies(self, parcours: list[dict[str, Any]]) -> str:
        """Le bilan des copies ``parcours`` ; le détail par thème, pour la seule copie qui en touche plusieurs (un DS, l'utilisateur,
        06/11/2026 : « Le bilan par copie ne sert que pour les DS, qui peuvent avoir plusieurs thèmes »)."""
        detail = [self._themes_de(p) for p in parcours]
        themes = any(detail)
        lignes = "".join(
            f"<tr><td>{escape(p['epreuve'])}</td><td>{_date(p['fin'])}</td>"
            f"<td align=right>{_note(p)}</td>"
            f"<td align=right>{_pc(p['taux'])}</td>" + (f"<td>{d}</td>" if themes else "") + "</tr>"
            for p, d in zip(parcours, detail))
        return ("<h2>Bilan des copies</h2><table cellspacing=0 cellpadding=4>"
                "<tr><th align=left>Épreuve</th><th align=left>Rendue le</th><th>Note</th><th>Réussite</th>"
                + ("<th align=left>Thèmes</th>" if themes else "") + f"</tr>{lignes}</table>")

    def note_de_copie(self, p: dict[str, Any]) -> str:
        """Ce que le bouton du sujet de la copie ``p`` dit d'elle sur la page d'accueil : « Note : 14,5/20 », puis, pour un DS à
        plusieurs thèmes, le taux de chaque thème (l'utilisateur, 06/11/2026 : « avec les notes dans le bouton de chaque copie
        rendue »)."""
        if p["taux"] is None:
            return "Note : en attente de correction"
        note = f"{p['obtenu']:g}/{p['total']:g}".replace(".", ",")
        detail = self._themes_de(p)
        return f"Note : {note}" + (f" ({detail})" if detail else "")

    def garder_copies(self, gardees: list[dict[str, Any]]) -> None:
        """Sur la page d'accueil, où les notes sont dans les boutons des sujets : le bilan des copies ne garde que celles sans
        bouton (``gardees``) ; aucune : la section disparaît."""
        etiquette = self.findChild(QLabel, "copies")
        if etiquette is None:
            return
        etiquette.setText(self._copies(gardees))
        etiquette.setVisible(bool(gardees))

    def sans_entete(self) -> None:
        """Sur la page d'accueil, qui dit déjà la classe et l'élève : ni « Bilan de <élève> » ni « établi le … »."""
        etiquette = self.findChild(QLabel, "entete")
        if etiquette is not None:
            etiquette.hide()
        self.layout().setContentsMargins(0, 0, 0, 0)  # « Bilan de l'année » aligné sur les titres des thèmes

    def branche(self, noeud: list[Any]) -> str:
        """Le bilan d'un thème (``noeud`` de ``arbre``) : son taux et son sous-arbre, du rendu de « Bilan par thème »."""
        if noeud[4]:  # le détail seul : la ligne « Réussite » du thème entier retirée (l'utilisateur, 06/11/2026)
            return _branches(noeud[4])
        return _branches([[noeud[0], None, None, noeud[3], []]])  # un thème sans détail : sa seule jauge, sous son nom

    @staticmethod
    def rangs(noeud: list[Any]) -> list[tuple[int, str, float | None]]:
        """Les lignes du bilan d'un thème, celles de ``branche`` : ``(niveau, libellé, taux)``, le détail seul, ou la seule
        ligne du thème sans détail."""
        def parcourir(noeuds: list[list[Any]], niveau: int) -> list[tuple[int, str, float | None]]:
            return [r for l, _, _, t, e in noeuds for r in [(niveau, l, t), *parcourir(e or [], niveau + 1)]]
        return parcourir(noeud[4] or [[noeud[0], None, None, noeud[3], []]], 0)

    def garder_themes(self, gardes: list[list[Any]]) -> None:
        """Sur la page d'accueil, où chaque section de thème porte son bilan : « Bilan par thème » ne garde que les thèmes
        sans section (``gardes``) ; aucun : la section disparaît."""
        etiquette = self.findChild(QLabel, "themes")
        if etiquette is None:
            return
        etiquette.setText("<h2>Bilan par thème</h2>" + _branches(gardes))
        etiquette.setVisible(bool(gardes))

    def _sections(self) -> list[str]:
        statistiques = [(axe, [(l, g, n) for l, g, n, _ in lignes]) for axe, lignes in self.axes]
        forts, faibles = noyau.ressorts(statistiques, 5)
        sections = [f"<h2>Bilan de {escape(self.eleve)}</h2>" + (f"<p>établi le {self.genere}</p>" if self.genere else "")]
        sections.append(self._copies(self.parcours))
        # le bilan par thème : l'arbre des thèmes, directement (les TP sont par thème)
        if self.arbre:
            sections.append("<h2>Bilan par thème</h2>" + _branches(self.arbre))
        # le bilan de l'année : une sous-section par trimestre, et tout en retrait, sous-titres comme contenus, comme dans
        # un thème de la page (l'utilisateur, 06/11/2026 : « pour le Bilan de l'année, il faut une section par trimestre et
        # des indentation, c'est pas propre »)
        titre = lambda texte: f"<h3 style='margin-left:{RETRAIT}px'>{texte}</h3>"
        para = lambda texte: f"<p style='margin-left:{2 * RETRAIT}px'>{texte}</p>"
        # « Appréciation : » ou « Conseil : » puis l'écriture du professeur, dont les lignes suivantes repartent sous le début
        # de la première et non sous l'étiquette (l'utilisateur, 06/11/2026 : « le retour à la ligne de l'écriture manuscrite
        # doit être aligné à gauche avec le début de l'écriture manuscrite de la première ligne ») : deux cellules
        etiquette = lambda libelle, texte: (f"<table style='margin-left:{2 * RETRAIT}px; margin-top:6px; margin-bottom:6px' "
                                            f"cellspacing=0 cellpadding=0><tr><td valign=top style='white-space:nowrap'>"
                                            f"<b>{libelle}</b> :&nbsp;</td><td valign=top>{a_la_main(texte)}</td></tr></table>")
        # la moyenne et les conseils vont dans la sous-section de la période en cours, la dernière (l'utilisateur,
        # 06/11/2026 : « je ne comprends pas pourquoi tu n'as pas mis la moyenne du trimestre et les conseils dans la
        # section du premier trimestre »)
        # « Moyenne du 1er trimestre à ce jour : » en gras et la note à la main (l'utilisateur, 06/11/2026)
        moyenne = (f"<b>Moyenne {self.periode} à ce jour :</b> "
                   + manuscrit(f"{round(self.annee, 1):g}".replace(".", ","))
                   if self.annee is not None else "Pas encore de copie notée.")
        # un conseil seul suit « Conseil : » sur la même ligne (l'utilisateur, 06/11/2026 : « je veux le conseil juste après
        # "Conseil : " plutôt qu'à la ligne ») ; plusieurs restent en liste sous « Conseils : »
        conseils = (etiquette("Conseil", self.conseils[0]) if len(self.conseils) == 1 else
                    f"<p style='margin-left:{2 * RETRAIT}px'><b>Conseils</b> :</p><ul style='margin-left:{RETRAIT}px'>"
                    + "".join(f"<li>{a_la_main(c)}</li>" for c in self.conseils) + "</ul>") if self.conseils else ""
        sections.append("<h2>Bilan de l'année</h2>" + ("" if self.appreciations else para(moyenne)))
        for rang, (periode, texte) in enumerate(self.appreciations, 1):  # « 1er trimestre (moyenne 12 / 20) », « L'année à ce jour »
            nom, _, precision = periode.partition(" (")
            dernier = rang == len(self.appreciations)
            note = re.search(r"(\d+(?:,\d+)?) ?/ ?20", precision)  # « moyenne 12,5 / 20 » d'un trimestre passé
            passee = (f"<b>Moyenne du {escape(nom)} :</b> {manuscrit(note.group(1))}" if note
                      else escape(precision.removesuffix(")").capitalize()))
            sections.append(titre(escape(nom)) + para(moyenne if dernier else passee)
                            + etiquette(f"Appréciation{' temporaire' * dernier}", texte) + (conseils if dernier else ""))
        if forts or faibles:
            sections.append(titre("Points solides et à retravailler") + "".join(
                para(f"<b>{nom}</b> : {escape(', '.join(libelles))}") for nom, libelles in
                (("Points solides", forts), ("À retravailler", faibles)) if libelles))
        if conseils and not self.appreciations:
            sections.append(titre("Conseils") + conseils)
        for axe, detail in self.axes:
            if self.arbre and axe in DANS_L_ARBRE:
                continue
            sections.append(titre(axe) + f"<table cellspacing=0 cellpadding=2 style='margin-left:{2 * RETRAIT}px'>" + "".join(
                f"<tr><td style='padding-right:12px'>{escape(l)}</td><td>{_jauge(t)}</td></tr>" for l, _, _, t in detail) + "</table>")
        return sections


def ouvrir_bilan(chemin: str, cle: str | None = None) -> Bilan | None:
    """Le bilan ``chemin``, en clair ou ouvert par ``cle``, ou ``None`` s'il est chiffré pour une autre clé. Le clair d'abord :
    serializejson refuse une clé sur un fichier qui n'est pas chiffré."""
    for essai in (None, cle) if cle else (None,):
        try:
            bilan = charger(chemin, essai)
        except ValueError as erreur:  # serializejson : DecryptionError (autre clé), ou chiffré sans mot de passe
            if "password" in str(erreur) or "decryption" in str(erreur):
                continue
            raise
        if not isinstance(bilan, Bilan):
            raise ValueError(f"{chemin} : pas un bilan d'élève")
        # les révisions rendues chez l'élève depuis le calcul du professeur ; un bilan plus récent les a déjà comptées
        if ETATS_LOCAUX and (local := ETATS_LOCAUX(bilan.eleve)) and local[1] > (bilan.notions_le or 0):
            from revision import depuis_bilan  # noqa: PLC0415
            bilan.poser_etats(depuis_bilan(local[0], local[1]), local[1])
        return bilan
    return None


def cle_du_secret(secret: bytes | None) -> str | None:
    """La clé du bilan de l'élève de ce ``secret`` (entré par son mot de passe, ou gardé sur ce poste), ``None`` sans lui."""
    return codes.cle_bilan(codes.publique(secret)) if secret else None


def cle_deposee(eleve: str, identites: dict[str, Any]) -> str | None:
    """La clé du bilan de ``eleve`` tirée de l'empreinte qu'il a déposée (``identites``), celle du professeur ; ``None``
    s'il n'en a pas."""
    deposee = codes.entree_deposee(identites, eleve, "") if eleve else None
    return codes.cle_bilan(deposee["publique"]) if deposee else None


def ouvrir_par_mot_de_passe(chemin: str, eleve: str, tape: str, identites: dict[str, Any]) -> Bilan | None:
    """Le bilan de ``eleve`` ouvert par le mot de passe ``tape``, le sien ou, sur la machine du professeur (``codes.professeur``),
    celui du professeur ; ou ``None``."""
    if eleve and tape and (bilan := ouvrir_bilan(chemin, cle_du_secret(codes.secret_eleve(eleve, "", tape)))):
        return bilan
    mot = codes.professeur()
    if mot and tape and hmac.compare_digest(tape.encode(), mot.encode()):
        return ouvrir_bilan(chemin, cle_deposee(eleve, identites))
    return None


class AccueilBilan(QDialog):
    """Le mot de passe, seul champ, pour un bilan chiffré que rien d'autre n'a ouvert (``montrer``) ; Entrée ouvre. Ne bloque
    pas (``open``, comme ``lecteur.Accueil``) : ``ouvert`` reçoit la fenêtre du bilan."""

    def __init__(self, chemin: str, ouvert: Any, eleve: str, identites: dict[str, Any]) -> None:
        super().__init__()
        self.chemin, self.ouvert, self.eleve, self.identites = chemin, ouvert, eleve, identites
        self.setWindowTitle("Bilan")
        self.mot_de_passe = QLineEdit()
        self.mot_de_passe.setEchoMode(QLineEdit.EchoMode.Password)
        self.mot_de_passe.returnPressed.connect(self.essayer)
        self.message = QLabel("Tapez votre mot de passe, puis Entrée.")
        self.message.setWordWrap(True)
        formulaire = QFormLayout(self)
        formulaire.addRow("Mot de passe", self.mot_de_passe)
        formulaire.addRow(self.message)
        self.setMinimumWidth(360)

    def essayer(self) -> None:
        bilan = ouvrir_par_mot_de_passe(self.chemin, self.eleve, self.mot_de_passe.text(), self.identites)
        if bilan is None:
            self.message.setText(REFUS)
            return
        self.accept()
        self.ouvert(fenetre(bilan))


def montrer(chemin: str, ouvert: Any, eleve: str, identites: dict[str, Any], garde: bytes | None = None,
            professeur: bool = False) -> AccueilBilan | None:
    """Le bilan ``chemin`` à l'écran, sans rien demander s'il est en clair, si le secret ``garde`` de ce poste l'ouvre, ou
    chez le professeur (``professeur`` : son mot de passe retenu par le navigateur ; en natif, ``codes.professeur``), par
    l'empreinte déposée : ``ouvert`` reçoit sa fenêtre. Sinon rend la boîte du mot de passe, ouverte, à garder tant qu'elle sert."""
    bilan = ouvrir_bilan(chemin, cle_du_secret(garde))
    if bilan is None and (professeur or codes.professeur()):
        bilan = ouvrir_bilan(chemin, cle_deposee(eleve, identites))
    if bilan is not None:
        ouvert(fenetre(bilan))
        return None
    boite = AccueilBilan(chemin, ouvert, eleve, identites)
    boite.open()
    return boite


def fenetre(bilan: Bilan) -> QScrollArea:
    """Le bilan dans une zone défilante, à garder tant qu'elle est ouverte."""
    zone = QScrollArea()
    zone.setWidget(bilan)
    zone.setWidgetResizable(True)
    zone.setWindowTitle(bilan.windowTitle())
    zone.resize(720, 800)
    zone.show()
    return zone
