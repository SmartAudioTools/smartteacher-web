"""Le bilan d'un élève, à part de ses copies : un widget qtpy6 que ``serializejson`` écrit et relit tel quel. Il est chiffré
par la clé tirée de l'empreinte de l'élève (``codes.cle_bilan``) dès qu'il a un mot de passe : lui l'obtient de son mot de
passe, le professeur de l'empreinte déposée (``identites.json``), sans le sien ; EN CLAIR tant qu'il n'en a pas
choisi : il doit pouvoir le lire sans (l'utilisateur, 03/11/2026 : « je veux qu'un élève puisse voir son bilan meme sans mot
de passe », « le bilan ne continent aucunes réponses »). Un camarade qui devine le lien le lit alors : risque accepté.

Le fichier, « Bilan [Nom Prénom].report », est écrit par l'outil du professeur (``bilans.py fichiers``), recalculé à chaque
passage ; le lecteur l'ouvre comme une copie (``lecteur.py``, ``montrer``). Ce module tourne aussi dans le navigateur
(``web/construire.py``, ``FICHIERS_QT``) : il n'importe que ce que le lecteur web embarque.
"""

from __future__ import annotations

import hmac
from datetime import datetime
from html import escape
from typing import Any, Callable

import re
from pathlib import Path

from qtpy6.QtCore import Qt
from qtpy6.QtGui import QFontDatabase
from qtpy6.QtWidgets import (QDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QScrollArea, QToolButton, QVBoxLayout,
                             QWidget)

import codes
import noyau
from modele import application, charger

EXTENSION = ".report"
ROUGE = "#c0392b"
REFUS = "Ce mot de passe n'ouvre pas ce bilan : s'il vient d'être réinitialisé, le bilan sera remis à jour au prochain passage du professeur."
# l'état des notions que le lecteur de l'élève a rangé après sa dernière révision rendue (``revision.apres_copie``) :
# ``ETATS_LOCAUX(eleve)`` rend ``(lignes de revision.en_bilan, instant du calcul)`` ou None ; posé par le navigateur
# (``pont_qt``), où l'élève s'entraîne et revient à sa page ; None ailleurs (W457, 08/11/2026)
ETATS_LOCAUX: Callable[[str], tuple[list[list[Any]], float] | None] | None = None
PROVISOIRE = ("Jauges provisoires : vos révisions depuis le dernier bilan du professeur y sont comptées ; "
              "elles seront recalculées à son prochain passage.")
DANS_L_ARBRE = ("Thèmes", "Capacités du programme")  # des axes que l'arbre (``bilans.arbre``) montre déjà, rangés


def nom_du_fichier(eleve: str) -> str:
    return codes.nom_de_fichier(f"Bilan [{eleve}]") + EXTENSION


def eleve_du_fichier(chemin: str, identites: dict[str, Any]) -> str:
    """« Nom Prénom » de l'élève déposé dans ``identites`` dont ``chemin`` est le bilan, vide s'il n'y est pas : par le nom
    du fichier refait, qui a pu perdre des caractères de son nom, et le secret d'un élève tient à son nom exact."""
    fichier = chemin.rpartition("/")[2]
    noms = (f"{e['nom']} {e['prenom']}" for e in identites.get("eleves", {}).values())
    return next((nom for nom in noms if nom_du_fichier(nom) == fichier), "")


def couleur(taux: float | None) -> str:
    if taux is None:
        return "gray"
    return noyau.VERT if taux >= noyau.SEUIL_FORT else ROUGE if taux < noyau.SEUIL_FAIBLE else "black"


def _pc(taux: float | None) -> str:
    return f'<span style="color:{couleur(taux)}">{"en attente" if taux is None else f"{taux:.0%}"}</span>'


def _note(p: dict[str, Any]) -> str:
    """La note, et à part les questions que le temps n'a pas laissé aborder (``bilans.releve_paquet``)."""
    if p["taux"] is None:
        return "—"
    n, s = p.get("non_abordees", 0), "s" * (p.get("non_abordees", 0) > 1)
    return f"{p['obtenu']:g} / {p['total']:g}" + (f" ({n} question{s} non abordée{s})" if n else "")


def _date(fin: float | None) -> str:
    return "pas encore rendue" if fin is None else datetime.fromtimestamp(fin).strftime("%d/%m/%Y")


# l'écriture du professeur, pour les moyennes du bilan (l'utilisateur, 06/11/2026 : « les notes en manuscrit avec ma police
# d'écriture ») : BaptisteDLG, la famille de la correction papier (``correction/imprimer_correction.BAPTISTE``), mais sa
# graisse Bold, la note étant en gras (06/11/2026) : la Regular chargée seule laissait le gras sans effet, et la « Pression »
# de l'impression imite l'encre et sortait grise et pâle à l'écran ; sur le web,
# livrée réduite dans polices/ par ``web/construire.POLICES``. Repli : ``noyau.POLICE_MAIN``.
ECRITURE = Path("/DATA/Python/SmartTeacher_essais/ecriture_professeur/police/BaptisteDLG-Bold.ttf")


def police_manuscrite() -> str:
    """La famille de l'écriture du professeur, chargée une fois si le fichier est là (poste du professeur), déjà chargée
    depuis polices/ sur le web ; sinon Kalam, l'écriture de la correction."""
    if ECRITURE.exists() and "BaptisteDLG" not in QFontDatabase.families():
        QFontDatabase.addApplicationFont(str(ECRITURE))
    return "BaptisteDLG" if "BaptisteDLG" in QFontDatabase.families() else noyau.POLICE_MAIN


VERT_ECRITURE = "#008c40"  # noyau.VERT (#00b050) assombri d'un cinquième


def a_la_main(texte: str) -> str:
    """Un texte du professeur (appréciation, conseil) dans son écriture (l'utilisateur, 06/11/2026 : « l'appréciation avec
    mon écriture manuscrite », « Conseil : l'écrire avec mon écriture manuscrite »), un peu plus grand que le texte autour, en vert (« écrire avec mon écriture en vert, sauf pour
    la note »), le vert des corrections un peu foncé : ``noyau.VERT`` paraissait pâle sur le fond gris de la page
    (l'utilisateur, 06/11/2026 : « c'est surtout le fond gris qui le fait passer pour pâle, fonce-le légèrement »)."""
    return f"<span style=\"font-family:'{police_manuscrite()}'; font-size:large; color:{VERT_ECRITURE}\">{escape(texte)}</span>"


def manuscrit(note: str, sur: float | None = 20, taille: str = "x-large", taux: float | None = None) -> str:
    """Une note sur ``sur`` (« 12,5 ») à la main, « /20 » compris et sans espace, en gras, un peu plus grande que le texte
    autour et à la couleur de la jauge de même taux (l'utilisateur, 06/11/2026 : « passe la moyenne manuscrite en gras
    avec une couleur correspondant à la note, et sans espace autour du "/" qui doit être aussi écrit "à la main" »).
    ``sur`` None : la note seule, sans « /… » (le « +z » d'un bonus de projet), à la couleur de ``taux``."""
    couleur_note = teinte(float(note.replace(",", ".")) / sur if sur is not None else taux or 0)
    return (f"<span style=\"font-family:'{police_manuscrite()}'; font-size:{taille}; font-weight:bold; color:{couleur_note}\">"
            f"{escape(note)}{'' if sur is None else f'/{sur:g}'}".replace(".", ",") + "</span>")


def pli() -> QToolButton:
    """Le triangle qui plie ou déplie une section, sans contour ni fond, pointé vers le bas : déplié (comme celui d'un thème de
    la page d'accueil, ``tableau_eleves.Tableau._pli``, que ce module ne peut pas importer : il importe celui-ci)."""
    bouton = QToolButton()
    bouton.setArrowType(Qt.ArrowType.DownArrow)
    bouton.setCheckable(True)
    bouton.setStyleSheet("QToolButton { border: none; background: transparent; }")
    bouton.setCursor(Qt.CursorShape.PointingHandCursor)
    return bouton


def a_afficher(axes: list[Any]) -> list[Any]:
    """Les axes du bilan tels qu'on les montre (``[[axe, [[libellé, …], …]], …]`` comme ``Bilan.axes``, ou ``Paquet.statistiques``) :
    sans ceux de ``noyau.AXES_MASQUES`` (la pensée informatique charge trop la page : le professeur, 21/11/2026), les
    niveaux de Bloom (``noyau.niveaux_bloom``) et les compétences (``noyau.competences_livret`` ; le professeur, 21/11/2026,
    [COS-15] : « il faut trier les compétance de la moins dur à la plus dur ») de la moins dure à la plus dure, une
    inconnue à la fin ; le reste dans l'ordre reçu. Les données gardent tout."""
    ordres = {"Niveaux de Bloom": [niveau["libelle"] for niveau in noyau.niveaux_bloom().values()],
              "Compétences": noyau.competences_livret()}

    def rangees(axe: str, lignes: list[Any]) -> list[Any]:
        if (ordre := ordres.get(axe)) is None:
            return list(lignes)
        return sorted(lignes, key=lambda ligne: ordre.index(ligne[0]) if ligne[0] in ordre else len(ordre))

    return [[axe, rangees(axe, lignes)] for axe, lignes in axes if axe not in noyau.AXES_MASQUES]


JAUGE, PALIER, LIBELLES = 120, 16, 300  # largeur d'une jauge ; retrait d'un niveau de l'arbre ; colonne des libellés (px)
# une colonne de libellés de même largeur dans chaque thème : leurs jauges tombent toutes au même bord


def _jauge(taux: float | None) -> str:
    """La réussite en jauge (l'utilisateur, 06/11/2026 : « plutôt que des pourcentages, est-il possible d'avoir des jauges
    toutes alignées ? ») : la part remplie à la couleur du taux (orange entre les deux seuils, le noir ne se lit pas en
    barre), le reste en gris ; la jauge remplace le pourcentage."""
    if taux is None:
        return _pc(None)
    plein = round(JAUGE * max(0.0, min(1.0, taux)))
    cases = (f"<td width={plein} bgcolor='{teinte(taux)}'></td>" if plein else "") + (
        f"<td width={JAUGE - plein} bgcolor='{GRIS_JAUGE}'></td>" if plein < JAUGE else "")
    return f"<table width={JAUGE} height=10 cellspacing=0 cellpadding=0><tr>{cases}</tr></table>"


def teinte(taux: float) -> str:
    """La couleur d'une jauge remplie à ``taux`` : celle du taux, orange entre les deux seuils (le noir ne se lit pas en
    barre)."""
    return {"black": "#e67e22"}.get(couleur(taux), couleur(taux))


GRIS_JAUGE = "#d5d8dc"  # la part vide d'une jauge


def _lignes(noeuds: list[list[Any]], niveau: int = 0) -> str:
    return "".join(f"<tr><td width={LIBELLES} style='padding-left:{niveau * PALIER}px; padding-right:12px'>{escape(l)}</td>"
                   f"<td valign=middle>{_jauge(t)}</td></tr>" + (_lignes(e, niveau + 1) if e else "")
                   for l, _, _, t, e in noeuds)


def _branches(noeuds: list[list[Any]], tete: str = "") -> str:
    """Un arbre de réussite en un seul tableau : les libellés en retrait selon leur niveau, toutes les jauges dans la même
    colonne ; ``tete`` : une première ligne déjà écrite (la réussite du thème)."""
    return f"<table cellspacing=0 cellpadding=2 style='margin-left:{PALIER}px'>{tete}{_lignes(noeuds, 1 if tete else 0)}</table>"


# l'écart de réussite d'un thème sous lequel il est dit stable (« → ») : une question de 1 point sur 20 en vaut 5 %
STABLE = 0.05


def _fleche(avant: float, apres: float) -> str:
    ecart = round(apres - avant, 9)  # 0.30 - 0.25 vaut 0.0499… en flottants : arrondi, sinon 5 points tout juste seraient « → »
    return "↗" if ecart >= STABLE else "↘" if -ecart >= STABLE else "→"


def _meme_copie(a: float | None, b: float | None) -> bool:
    """Deux dates de rendu (``Paquet.fin``, ``time.time()``) de la même copie, relues d'un JSON : à la seconde près."""
    return a is not None and b is not None and abs(a - b) < 1


def evolution(themes_par_copie: list[list[Any]], fin: float | None) -> list[tuple[str, float, float | None, int]]:
    """Pour la copie rendue à ``fin``, chacun de ses thèmes (``bilans.themes_par_copie``) : ``(thème, taux de cette copie,
    taux des copies rendues avant elle sur ce thème ou None, nombre de ces copies)`` ; rien si la copie n'est pas dans le
    bilan (rendue après son dernier calcul, ou un ``.report`` d'avant le 06/11/2026, sans ce champ)."""
    ici: dict[str, list[float]] = {}
    for _, f, theme, g, n in themes_par_copie:
        if _meme_copie(f, fin):
            cumul = ici.setdefault(theme, [0, 0])
            cumul[0], cumul[1] = cumul[0] + g, cumul[1] + n
    resultat = []
    for theme, (g, n) in ici.items():
        avant = [(f, ga, na) for _, f, t, ga, na in themes_par_copie
                 if t == theme and f is not None and f < fin and not _meme_copie(f, fin)]
        notes = sum(na for _, _, na in avant)
        resultat.append((theme, g / n, sum(ga for _, ga, _ in avant) / notes if notes else None, len({f for f, _, _ in avant})))
    return resultat


def evolution_de_la_copie(themes_par_copie: list[list[Any]], fin: float | None) -> str:
    """Le bloc « Évolution » sous le bilan d'une copie rendue (``modele.Paquet.poser_bilan``), une ligne par thème de la
    copie : « Localisation : 62 % ici, 48 % avant (3 copies) ↗ » ; vide si ``evolution`` n'a rien."""
    lignes = []
    for theme, ici, avant, copies in evolution(themes_par_copie, fin):
        s = "s" * (copies > 1)
        suite = (f", {_pc(avant)} avant ({copies} copie{s}) {_fleche(avant, ici)}" if avant is not None
                 else ", première copie sur ce thème")
        lignes.append(f"{escape(theme)} : {_pc(ici)} ici{suite}")
    return "<b>Évolution</b><br>" + "<br>".join(lignes) if lignes else ""


ANNEE = "<h2>Bilan de l'année</h2>"
RETRAIT = 24  # le retrait d'un sous-titre du bilan de l'année, puis de son contenu (celui des thèmes de la page)


class Bilan(noyau.Objet, QWidget):
    """``parcours`` : ses copies dans l'ordre de leur rendu, ``{"epreuve", "fin", "etat", "obtenu", "total", "avancements", "taux"}``
    (``taux`` ``None`` en attente : jamais compté 0) ; ``conseils`` : des phrases à l'élève ; ``axes`` :
    ``[[axe, [[libellé, gagné, noté, taux], …]], …]`` sur les seules copies corrigées (``bilans.bilan_eleve``) ;
    ``appreciations`` : ``[[titre, texte], …]``, celle du bulletin s'il continue ainsi (``bilans.appreciations``) ;
    ``annee`` : sa moyenne sur 20 à ce jour, de la ``periode`` (« de l'année », « du 1er trimestre » :
    ``bilans.moyenne_affichee``), rien en tête sans copie notée ; ``arbre`` : ``[[libellé, gagné, noté, taux, enfants],
    …]``, thème, section du cours ou contenu du BO, capacité (``bilans.arbre``), qui remplace ``DANS_L_ARBRE`` ;
    ``themes_par_copie`` : ``[[épreuve, fin, thème, gagné, noté], …]`` (``bilans.themes_par_copie``), absent d'un bilan
    écrit avant le 06/11/2026 ; ``etat_notions`` : l'état de ses notions (``revision.en_bilan``), calculé à
    ``notions_le`` (``time.time()``), absents d'un bilan écrit avant le 07/11/2026 (``etats``). Trois bilans (l'utilisateur, 06/11/2026 : « les bilans (copie, thème, année) doivent être sur
    la page d'accueil ») : celui des copies (leur liste, note, date et thèmes), celui par thème (l'arbre des thèmes ; le détail par thème d'une copie, dans le premier, pour un DS à plusieurs
    thèmes), celui
    de l'année (moyenne, appréciation, points solides, conseils, autres axes)."""

    def __init__(self, eleve: str, parcours: list[dict[str, Any]], axes: list[list[Any]] = (), genere: str = "",
                 conseils: list[str] = (),
                 appreciations: list[list[str]] = (), annee: float | None = None,
                 periode: str = "de l'année", arbre: list[list[Any]] = (), themes_par_copie: list[list[Any]] = (),
                 etat_notions: list[list[Any]] = (), notions_le: float | None = None,
                 calcule_le: float | None = None) -> None:
        application()
        QWidget.__init__(self)
        self.eleve, self.parcours, self.axes = eleve, parcours, list(axes)
        self.genere, self.annee, self.periode = genere, annee, periode
        self.conseils, self.appreciations, self.arbre = list(conseils), [list(a) for a in appreciations], list(arbre)
        self.themes_par_copie = [list(t) for t in themes_par_copie]
        self.etat_notions, self.notions_le = [list(e) for e in etat_notions], notions_le
        self.calcule_le = calcule_le  # l'instant du calcul chez le professeur ; None : bilan d'avant [BEC-14]
        self.setWindowTitle(f"Bilan de {eleve}")
        d = QVBoxLayout(self)
        for texte in self._sections():
            if not isinstance(texte, str):  # des conseils : un triangle, plié, devant leur titre
                d.addLayout(self._pliable(*texte))
                continue
            etiquette = QLabel(texte)
            etiquette.setWordWrap(True)
            etiquette.setTextFormat(Qt.TextFormat.RichText)
            etiquette.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            d.addWidget(etiquette)
            if texte.startswith(("<h2>", "<h3")):  # de l'espace au-dessus d'une section, comme les titres de la page
                etiquette.setContentsMargins(0, 18 if texte.startswith("<h2>") else 8, 0, 0)  # d'accueil (06/11/2026)
            if texte.startswith("<h2>Bilan des copies"):
                etiquette.setObjectName("copies")
            elif texte.startswith("<h2>Bilan par thème"):
                etiquette.setObjectName("themes")
            elif texte.startswith(f"<h2>Bilan de {escape(self.eleve)}</h2>"):
                etiquette.setObjectName("entete")
            elif texte.startswith(ANNEE):
                etiquette.setObjectName("annee")
        d.addStretch()

    @staticmethod
    def _pliable(titre: str, corps: str, marge: int) -> QVBoxLayout:
        """Le ``titre`` (HTML) précédé d'un triangle, et ``corps`` dessous, caché tant que le triangle est plié (le professeur, 21/11/2026 :
        « il faut un triang pour plier / deplier les conseils et plier par defaut ») ; ``marge`` : où le titre commence."""
        def etiquette(texte: str) -> QLabel:
            e = QLabel(texte, wordWrap=True, textFormat=Qt.TextFormat.RichText)
            e.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            return e
        bouton, entete, pile = pli(), QHBoxLayout(), QVBoxLayout()
        entete.setContentsMargins(max(0, marge - bouton.sizeHint().width()), 0, 0, 0)
        entete.setSpacing(0)
        entete.addWidget(bouton)
        entete.addWidget(etiquette(titre), 1)
        detail = etiquette(corps)
        pile.addLayout(entete)
        pile.addWidget(detail)
        bouton.toggled.connect(lambda plie: (detail.setVisible(not plie), bouton.setArrowType(
            Qt.ArrowType.RightArrow if plie else Qt.ArrowType.DownArrow)))
        bouton.setChecked(True)  # plié par défaut
        return pile

    def etats(self, maintenant: float | None = None) -> dict[tuple[str, ...], dict[str, Any]]:
        """L'état de ses notions, {notion : état} comme ``revision.etat_notions`` le rend, à ``maintenant`` (l'heure par
        défaut) ; vide pour un bilan qui ne le porte pas : tout est neuf."""
        import time  # noqa: PLC0415
        from revision import depuis_bilan  # noqa: PLC0415 - revision importe noyau et bilans
        return depuis_bilan(self.etat_notions, time.time() if maintenant is None else maintenant)

    provisoire = False  # ses jauges comptent des révisions faites depuis le calcul du professeur (``poser_etats``)

    def replier(self, releves: list[dict[str, Any]]) -> None:
        """Les copies ``releves`` (``bilans.releve_paquet``, lus dans leur témoin de présence) à la place de leur ligne du
        parcours, ou ajoutées : la note et l'état d'une copie à l'instant, chez l'élève, sans attendre le calcul du
        professeur ([BEC-14]), qui reste le garde-fou (``bilans.ecarts_du_temoin``)."""
        from bilans import bilan_eleve, entree_du_bilan, principale_du_bonus  # noqa: PLC0415 - bilans importe noyau
        for releve in releves:
            entree = entree_du_bilan(bilan_eleve([releve])["parcours"][0])
            # le « +z » d'un bonus de projet (``bilans.bilan_fichier``) se calcule chez le professeur : gardé tant que ses
            # points ne bougent pas, retiré si le barème ou l'état de son projet bouge ; x/y jusqu'au calcul suivant (W1007)
            avant = next((p for p in self.parcours if p.get("sujet", p["epreuve"]) == entree["sujet"]), None)
            if avant is not None and "ajout" in avant and (avant["etat"], avant["obtenu"], avant["total"]) \
                    == (entree["etat"], entree["obtenu"], entree["total"]):
                entree["ajout"] = avant["ajout"]
            if avant is not None and (avant["etat"], avant["total"]) != (entree["etat"], entree["total"]):
                for p in self.parcours:
                    if principale_du_bonus({p["epreuve"]: p["epreuve"], entree["epreuve"]: entree["epreuve"]}).get(p["epreuve"]) == entree["epreuve"]:
                        p.pop("ajout", None)
            self.parcours = [p for p in self.parcours if p.get("sujet", p["epreuve"]) != entree["sujet"]] + [entree]
        self.parcours.sort(key=lambda p: (p["fin"] is None, p["fin"] or 0, p["epreuve"]))

    def poser_etats(self, etats: dict[tuple[str, ...], dict[str, Any]], instant: float) -> None:
        """Les jauges refaites sur ``etats`` (l'état des notions calculé à ``instant`` chez l'élève, ``revision.apres_copie``),
        sans la banque, que le lecteur n'a pas : l'arbre du professeur garde ses nœuds, seules leurs jauges changent
        (``revision.jauges``) ; l'essai « Réviser » suivant part aussi de cet état. Marqué ``provisoire`` : le bilan suivant
        du professeur le remplace (demande du professeur, 08/11/2026 : « pour pouvoir s'entraîner en boucle »)."""
        from revision import en_bilan, jauges  # noqa: PLC0415 - revision importe noyau et bilans
        self.arbre = jauges(self.arbre, etats)
        self.etat_notions, self.notions_le, self.provisoire = en_bilan(etats), instant, True
        if (etiquette := self.findChild(QLabel, "themes")) is not None:
            etiquette.setText(f"<h2>Bilan par thème</h2>{_branches(self.arbre)}<p><i>{PROVISOIRE}</i></p>")

    def evolution(self, fin: float | None) -> str:
        """Le bloc « Évolution » de la copie rendue à ``fin`` (``evolution_de_la_copie``)."""
        return evolution_de_la_copie(self.themes_par_copie, fin)

    def _themes_de(self, p: dict[str, Any]) -> str:
        """Le détail par thème de la copie ``p`` (« Localisation 25%, Réseaux 75% »), vide si elle n'en touche qu'un."""
        themes = self._themes(p)
        return ", ".join(f"{escape(t)} {_pc(g / n)}" for t, g, n in themes) if len(themes) > 1 else ""

    def _themes(self, p: dict[str, Any]) -> list[tuple[str, float, float]]:
        """Les ``(thème, gagné, noté)`` de la copie ``p`` (``bilans.themes_par_copie``)."""
        return [(t, g, n) for e, f, t, g, n in self.themes_par_copie
                if e == p["epreuve"] and (f == p["fin"] or _meme_copie(f, p["fin"])) and n]

    def note_du_theme(self, p: dict[str, Any], theme: str) -> str:
        """Après la note de la copie ``p`` d'un DS de plusieurs thèmes, ses points sur ``theme`` (le professeur, 22/11/2026,
        [APE-20] : « 14/20, dont 7/10 sur ce thème »), vide pour une copie d'un seul thème ou pas encore corrigée. « , dont »
        et « sur ce thème » à la main, à la couleur de la note du thème (le professeur, 25/11/2026 00:39, W1019 : « peut tu
        mettre ", dont" et "sur ce thème" en ecriture manuscrite dans les meme couleur que la note pour le thème ? »)."""
        themes = self._themes(p) if p["taux"] is not None else []
        points = next(((g, n) for t, g, n in themes if t == theme), None) if len(themes) > 1 else None
        if points is None:
            return ""
        note = manuscrit(f"{points[0]:g}".replace(".", ","), points[1], "large")
        return (f"<span style=\"font-family:'{police_manuscrite()}'; color:{teinte(points[0] / points[1])}\">, dont {note} "
                "sur ce thème</span>")

    def _copies(self, parcours: list[dict[str, Any]]) -> str:
        """Le bilan des copies ``parcours`` ; le détail par thème, pour la seule copie qui en touche plusieurs (un DS, l'utilisateur,
        06/11/2026 : « Le bilan par copie ne sert que pour les DS, qui peuvent avoir plusieurs thèmes »)."""
        detail = [self._themes_de(p) for p in parcours]
        themes = any(detail)
        lignes = "".join(
            f"<tr><td>{escape(p['epreuve'])}</td><td>{_date(p['fin'])}</td>"
            f"<td align=right>{_note(p)}</td>"
            f"<td align=right>{_pc(p['taux'])}</td>" + (f"<td>{d}</td>" if themes else "") + "</tr>"
            for p, d in zip(parcours, detail))
        return ("<h2>Bilan des copies</h2><table cellspacing=0 cellpadding=4>"
                "<tr><th align=left>Épreuve</th><th align=left>Rendue le</th><th>Note</th><th>Réussite</th>"
                + ("<th align=left>Thèmes</th>" if themes else "") + f"</tr>{lignes}</table>")

    def note_de_copie(self, p: dict[str, Any]) -> str:
        """Ce que le bouton du sujet de la copie ``p`` dit d'elle sur la page d'accueil : sa note (l'utilisateur, 06/11/2026 :
        « avec les notes dans le bouton de chaque copie rendue »). Une copie pas encore rendue (``fin`` vide, TP en cours) : aucune note, « en attente de correction » la
        disait à tort à corriger (W750, 17/11/2026 : 211 copies de Seconde sur 228 « en attente » ; le professeur : « aucune
        note dans le bouton »)."""
        if p["taux"] is None:
            return "" if p.get("fin") is None else "en attente de correction"
        # la note à la main, en gras, sans « Note : » (le professeur, 21/11/2026, [COS-5] : « la note dans le bouton d'un
        # sujet doit etre avec mon ecritur manuscrite en gras , il n'est pas necessaire d'ecrire "Note : " »)
        # la note seule, sans le taux de chaque thème d'un DS (le professeur, 22/11/2026, [APE-11] : « la note affiché dans
        # le bouton du DS n'a pas à préiser la repartieion sur les deux parties »)
        if p.get("ajout") is not None:  # les questions bonus d'un projet : « +z », ce qu'elles ajoutent à sa note (W1007)
            return manuscrit(f"+{p['ajout']:g}".replace(".", ","), None, "large", p["taux"])
        return manuscrit(f"{p['obtenu']:g}".replace(".", ","), p["total"], "large")

    def garder_copies(self, gardees: list[dict[str, Any]]) -> None:
        """Sur la page d'accueil, où les notes sont dans les boutons des sujets : le bilan des copies ne garde que celles sans
        bouton (``gardees``) ; aucune : la section disparaît."""
        etiquette = self.findChild(QLabel, "copies")
        if etiquette is None:
            return
        etiquette.setText(self._copies(gardees))
        etiquette.setVisible(bool(gardees))

    def sans_entete(self, titre: Callable[[str, int], str] | None = None) -> None:
        """Sur la page d'accueil, qui dit déjà la classe et l'élève : ni « Bilan de <élève> » ni « établi le … ». ``titre`` :
        le titre de la page à ``texte`` et au niveau 2 ou 3, à la place des <h2>, <h3> du bilan de l'année (le professeur,
        25/11/2026, W1019 : « "Bilan de l'année" devrait être à la meme taille que "A faire" et "Thématiques" », « ses
        section devraient être à la meme taille que "cours" et "réviser" »)."""
        etiquette = self.findChild(QLabel, "entete")
        if etiquette is not None:
            etiquette.hide()
        annee = self.findChild(QLabel, "annee")
        if titre is not None and annee is not None:
            annee.setText(titre("Bilan de l'année", 2) + annee.text()[len(ANNEE):])
            sous_titre = re.compile(r"<h3(?: style='([^']*)')?>(.*?)</h3>")
            for e in self.findChildren(QLabel):
                if "<h3" in e.text():  # « 1er trimestre », « Conseils », « Points solides et à retravailler »…
                    e.setText(sous_titre.sub(lambda m: titre(m.group(2), 3).replace(
                        "<p style='", f"<p style='{m.group(1) or ''}; ", 1), e.text()))
        self.layout().setContentsMargins(0, 0, 0, 0)  # « Bilan de l'année » aligné sur les titres des thèmes

    def branche(self, noeud: list[Any]) -> str:
        """Le bilan d'un thème (``noeud`` de ``arbre``) : son taux et son sous-arbre, du rendu de « Bilan par thème »."""
        if noeud[4]:  # le détail seul : la ligne « Réussite » du thème entier retirée (l'utilisateur, 06/11/2026)
            return _branches(noeud[4])
        return _branches([[noeud[0], None, None, noeud[3], []]])  # un thème sans détail : sa seule jauge, sous son nom

    @staticmethod
    def rangs(noeud: list[Any]) -> list[tuple[int, str, float | None]]:
        """Les lignes du bilan d'un thème, celles de ``branche`` : ``(niveau, libellé, taux)``, le détail seul, ou la seule
        ligne du thème sans détail."""
        def parcourir(noeuds: list[list[Any]], niveau: int) -> list[tuple[int, str, float | None]]:
            return [r for l, _, _, t, e in noeuds for r in [(niveau, l, t), *parcourir(e or [], niveau + 1)]]
        return parcourir(noeud[4] or [[noeud[0], None, None, noeud[3], []]], 0)

    def garder_themes(self, gardes: list[list[Any]]) -> None:
        """Sur la page d'accueil, où chaque section de thème porte son bilan : « Bilan par thème » ne garde que les thèmes
        sans section (``gardes``) ; aucun : la section disparaît."""
        etiquette = self.findChild(QLabel, "themes")
        if etiquette is None:
            return
        etiquette.setText("<h2>Bilan par thème</h2>" + _branches(gardes))
        etiquette.setVisible(bool(gardes))

    def _sections(self) -> list[str | tuple[str, str, int]]:
        axes = a_afficher(self.axes)
        statistiques = [(axe, [(l, g, n) for l, g, n, _ in lignes]) for axe, lignes in axes]
        forts, faibles = noyau.ressorts(statistiques, 5)
        sections = [f"<h2>Bilan de {escape(self.eleve)}</h2>" + (f"<p>établi le {self.genere}</p>" if self.genere else "")]
        sections.append(self._copies(self.parcours))
        # le bilan par thème : l'arbre des thèmes, directement (les TP sont par thème)
        if self.arbre:
            sections.append("<h2>Bilan par thème</h2>" + _branches(self.arbre))
        # le bilan de l'année : une sous-section par trimestre, et tout en retrait, sous-titres comme contenus, comme dans
        # un thème de la page (l'utilisateur, 06/11/2026 : « pour le Bilan de l'année, il faut une section par trimestre et
        # des indentation, c'est pas propre »)
        titre = lambda texte: f"<h3 style='margin-left:{RETRAIT}px'>{texte}</h3>"
        para = lambda texte: f"<p style='margin-left:{2 * RETRAIT}px'>{texte}</p>"
        # « Appréciation : » ou « Conseil : » puis l'écriture du professeur, dont les lignes suivantes repartent sous le début
        # de la première et non sous l'étiquette (l'utilisateur, 06/11/2026 : « le retour à la ligne de l'écriture manuscrite
        # doit être aligné à gauche avec le début de l'écriture manuscrite de la première ligne ») : deux cellules
        # le zéro-largeur à la main devant l'étiquette lui donne la hauteur de ligne de l'écriture : leurs lignes de base s'alignent
        etiquette = lambda libelle, texte: (f"<table style='margin-left:{2 * RETRAIT}px; margin-top:6px; margin-bottom:6px' "
                                            f"cellspacing=0 cellpadding=0><tr><td valign=top style='white-space:nowrap'>"
                                            f"{a_la_main('\u200b')}<b>{libelle}</b> :&nbsp;</td><td valign=top>{a_la_main(texte)}</td></tr></table>")
        # la moyenne et les conseils vont dans la sous-section de la période en cours, la dernière (l'utilisateur,
        # 06/11/2026 : « je ne comprends pas pourquoi tu n'as pas mis la moyenne du trimestre et les conseils dans la
        # section du premier trimestre »)
        # « Moyenne du 1er trimestre à ce jour : » en gras et la note à la main (l'utilisateur, 06/11/2026)
        moyenne = (f"<b>Moyenne {self.periode} à ce jour :</b> "
                   + manuscrit(f"{round(self.annee, 1):g}".replace(".", ","))
                   if self.annee is not None else "Pas encore de copie notée.")
        # un conseil seul suit « Conseil : » sur la même ligne (l'utilisateur, 06/11/2026 : « je veux le conseil juste après
        # "Conseil : " plutôt qu'à la ligne ») ; plusieurs restent en liste sous « Conseils : »
        # des tirets verts à la main, à la place des puces, dans une section qui se plie (21/11/2026)
        tirets = (f"<table style='margin-left:{2 * RETRAIT}px; margin-top:6px; margin-bottom:6px' cellspacing=0 cellpadding=0>"
                  + "".join(f"<tr><td valign=top>{a_la_main('–')}&nbsp;</td><td valign=top>{a_la_main(c)}</td></tr>"
                            for c in self.conseils) + "</table>")
        sections.append(ANNEE + ("" if self.appreciations else para(moyenne)))
        for rang, (periode, texte) in enumerate(self.appreciations, 1):  # « 1er trimestre (moyenne 12 / 20) », « L'année à ce jour »
            nom, _, precision = periode.partition(" (")
            dernier = rang == len(self.appreciations)
            note = re.search(r"(\d+(?:,\d+)?) ?/ ?20", precision)  # « moyenne 12,5 / 20 » d'un trimestre passé
            passee = (f"<b>Moyenne du {escape(nom)} :</b> {manuscrit(note.group(1))}" if note
                      else escape(precision.removesuffix(")").capitalize()))
            sections.append(titre(escape(nom)) + para(moyenne if dernier else passee)
                            + etiquette(f"Appréciation{' temporaire' * dernier}", texte))
            if dernier and self.conseils:
                sections.append((f"<b>Conseil{'s' * (len(self.conseils) > 1)}</b> :", tirets, 2 * RETRAIT))
        if forts or faibles:
            sections.append(titre("Points solides et à retravailler") + "".join(
                para(f"<b>{nom}</b> : {escape(', '.join(libelles))}") for nom, libelles in
                (("Points solides", forts), ("À retravailler", faibles)) if libelles))
        if self.conseils and not self.appreciations:
            sections.append(("<h3>Conseils</h3>", tirets, RETRAIT))
        for axe, detail in axes:
            if self.arbre and axe in DANS_L_ARBRE:
                continue
            sections.append(titre(axe) + f"<table cellspacing=0 cellpadding=2 style='margin-left:{2 * RETRAIT}px'>" + "".join(
                f"<tr><td style='padding-right:12px'>{_jauge(t)}</td><td>{escape(l)}</td></tr>" for l, _, _, t in detail) + "</table>")
        return sections


def ouvrir_bilan(chemin: str, cle: str | list[str] | None = None) -> Bilan | None:
    """Le bilan ``chemin``, en clair ou ouvert par ``cle`` (ou l'une des clés de la liste, ``cle_du_secret``), ou ``None``
    s'il est chiffré pour une autre clé. Le clair d'abord : serializejson refuse une clé sur un fichier qui n'est pas chiffré."""
    for essai in (None, *([cle] if isinstance(cle, str) else cle or [])):
        try:
            bilan = charger(chemin, essai)
        except ValueError as erreur:  # serializejson : DecryptionError (autre clé), ou chiffré sans mot de passe
            if "password" in str(erreur) or "decryption" in str(erreur):
                continue
            raise
        if not isinstance(bilan, Bilan):
            raise ValueError(f"{chemin} : pas un bilan d'élève")
        # les révisions rendues chez l'élève depuis le calcul du professeur ; un bilan plus récent les a déjà comptées
        if ETATS_LOCAUX and (local := ETATS_LOCAUX(bilan.eleve)) and local[1] > (bilan.notions_le or 0):
            from revision import depuis_bilan  # noqa: PLC0415
            bilan.poser_etats(depuis_bilan(local[0], local[1]), local[1])
        return bilan
    return None


def cle_du_secret(secret: bytes | None, identites: dict[str, Any] | None = None) -> list[str] | None:
    """Les clés du bilan de l'élève de ce ``secret`` (entré par son mot de passe, ou gardé sur ce poste), ``None`` sans lui :
    celle de son empreinte, puis celles des empreintes qu'il a eues avant (``codes.publiques_de``, d'après ``identites``) ;
    son bilan écrit avant un passage au nouveau coût reste lisible sans attendre que le professeur le régénère."""
    return [codes.cle_bilan(p) for p in codes.publiques_de(identites or {}, codes.publique(secret))] if secret else None


def cle_deposee(eleve: str, identites: dict[str, Any]) -> list[str] | None:
    """Les clés du bilan de ``eleve`` tirées de l'empreinte qu'il a déposée (``identites``), celles du professeur : la
    courante, puis celles qu'il a eues avant (``codes.publiques_de``), comme ``cle_du_secret`` ; ``None`` s'il n'en a pas.
    Un bilan calculé avant qu'il redépose une empreinte reste lisible jusqu'au prochain calcul (le professeur, 25/11/2026,
    W1028 : des notes absentes des boutons, « il faut le faire pour tous les élève de toutes les classes »)."""
    deposee = codes.entree_deposee(identites, eleve, "") if eleve else None
    return [codes.cle_bilan(p) for p in codes.publiques_de(identites, deposee["publique"])] if deposee else None


def ouvrir_par_mot_de_passe(chemin: str, eleve: str, tape: str, identites: dict[str, Any]) -> Bilan | None:
    """Le bilan de ``eleve`` ouvert par le mot de passe ``tape``, le sien ou, sur la machine du professeur (``codes.professeur``),
    celui du professeur ; ou ``None``."""
    cout = codes.cout_depose(codes.entree_deposee(identites, eleve, "") if eleve else None)
    if eleve and tape and (bilan := ouvrir_bilan(chemin, cle_du_secret(codes.secret_eleve(eleve, "", tape, cout), identites))):
        return bilan
    mot = codes.professeur()
    if mot and tape and hmac.compare_digest(tape.encode(), mot.encode()):
        return ouvrir_bilan(chemin, cle_deposee(eleve, identites))
    return None


class AccueilBilan(QDialog):
    """Le mot de passe, seul champ, pour un bilan chiffré que rien d'autre n'a ouvert (``montrer``) ; Entrée ouvre. Ne bloque
    pas (``open``, comme ``lecteur.Accueil``) : ``ouvert`` reçoit la fenêtre du bilan."""

    def __init__(self, chemin: str, ouvert: Any, eleve: str, identites: dict[str, Any]) -> None:
        super().__init__()
        self.chemin, self.ouvert, self.eleve, self.identites = chemin, ouvert, eleve, identites
        self.setWindowTitle("Bilan")
        self.mot_de_passe = QLineEdit()
        self.mot_de_passe.setEchoMode(QLineEdit.EchoMode.Password)
        self.mot_de_passe.returnPressed.connect(self.essayer)
        self.message = QLabel("Tapez votre mot de passe, puis Entrée.")
        self.message.setWordWrap(True)
        formulaire = QFormLayout(self)
        formulaire.addRow("Mot de passe", self.mot_de_passe)
        formulaire.addRow(self.message)
        self.setMinimumWidth(360)

    def essayer(self) -> None:
        bilan = ouvrir_par_mot_de_passe(self.chemin, self.eleve, self.mot_de_passe.text(), self.identites)
        if bilan is None:
            self.message.setText(REFUS)
            return
        self.accept()
        self.ouvert(fenetre(bilan))


def montrer(chemin: str, ouvert: Any, eleve: str, identites: dict[str, Any], garde: bytes | None = None,
            professeur: bool = False) -> AccueilBilan | None:
    """Le bilan ``chemin`` à l'écran, sans rien demander s'il est en clair, si le secret ``garde`` de ce poste l'ouvre, ou
    chez le professeur (``professeur`` : son mot de passe retenu par le navigateur ; en natif, ``codes.professeur``), par
    l'empreinte déposée : ``ouvert`` reçoit sa fenêtre. Sinon rend la boîte du mot de passe, ouverte, à garder tant qu'elle sert."""
    bilan = ouvrir_bilan(chemin, cle_du_secret(garde, identites))
    if bilan is None and (professeur or codes.professeur()):
        bilan = ouvrir_bilan(chemin, cle_deposee(eleve, identites))
    if bilan is not None:
        ouvert(fenetre(bilan))
        return None
    boite = AccueilBilan(chemin, ouvert, eleve, identites)
    boite.open()
    return boite


def fenetre(bilan: Bilan) -> QScrollArea:
    """Le bilan dans une zone défilante, à garder tant qu'elle est ouverte."""
    zone = QScrollArea()
    zone.setWidget(bilan)
    zone.setWidgetResizable(True)
    zone.setWindowTitle(bilan.windowTitle())
    zone.resize(720, 800)
    zone.show()
    return zone
