"""Le bilan d'un élève, à part de ses copies : un widget qtpy6 que ``serializejson`` écrit et relit tel quel, chiffré par le
code PERSONNEL de l'élève (``codes.code_personnel``, ou celui que sa liste a distribué), le même pour tous les sujets de
l'année : la clé d'une copie change avec chaque sujet, un bilan qui les traverse toutes ne peut pas la reprendre.

Le fichier, « Bilan [Nom Prénom].report », est écrit par l'outil du professeur (``bilans.py fichiers``), recalculé à chaque
passage ; le lecteur l'ouvre comme une copie (``lecteur.py``, ``AccueilBilan`` : le code personnel seul). Ce module tourne
aussi dans le navigateur (``web/construire.py``, ``FICHIERS_QT``) : il n'importe que ce que le lecteur web embarque.
"""

from __future__ import annotations

from datetime import datetime
from html import escape
from typing import Any

from qtpy6.QtCore import Qt
from qtpy6.QtWidgets import QDialog, QFormLayout, QLabel, QLineEdit, QScrollArea, QVBoxLayout, QWidget

import codes
import noyau
from modele import application, charger

EXTENSION = ".report"
ROUGE = "#c0392b"
DANS_L_ARBRE = ("Thèmes", "Capacités du programme")  # des axes que l'arbre (``bilans.arbre``) montre déjà, rangés


def cle(code: str) -> str:
    """La clé du fichier tirée du code personnel tapé, sous la forme que le contrôle d'une copie en lit
    (``codes.verifier_personnel``) : déterminant et accord de l'adjectif n'y comptent pas, comme pour la copie."""
    return codes._propre(code)  # noqa: SLF001 - la règle du code personnel, pas une seconde


def nom_du_fichier(eleve: str) -> str:
    return codes.nom_de_fichier(f"Bilan [{eleve}]") + EXTENSION


def couleur(taux: float | None) -> str:
    if taux is None:
        return "gray"
    return noyau.VERT if taux >= noyau.SEUIL_FORT else ROUGE if taux < noyau.SEUIL_FAIBLE else "black"


def _pc(taux: float | None) -> str:
    return f'<span style="color:{couleur(taux)}">{"en attente" if taux is None else f"{taux:.0%}"}</span>'


def _note(p: dict[str, Any]) -> str:
    """La note, et à part les questions que le temps n'a pas laissé aborder (``bilans.releve_paquet``)."""
    if p["taux"] is None:
        return "—"
    n, s = p.get("non_abordees", 0), "s" * (p.get("non_abordees", 0) > 1)
    return f"{p['obtenu']:g} / {p['total']:g}" + (f" ({n} question{s} non abordée{s})" if n else "")


def _date(fin: float | None) -> str:
    return "pas encore rendue" if fin is None else datetime.fromtimestamp(fin).strftime("%d/%m/%Y")


def _uniques(libelles: list[str], maximum: int) -> list[str]:
    """Un libellé vu sur deux axes à une majuscule près (« Confidentialité de la position », thème, et « confidentialité
    de la position », capacité) une seule fois."""
    vus: dict[str, str] = {}
    for l in libelles:
        vus.setdefault(l.casefold(), l)
    return list(vus.values())[:maximum]


def _branches(noeuds: list[list[Any]]) -> str:
    return "<ul>" + "".join(f"<li>{escape(l)} : {_pc(t)}{_branches(e) if e else ''}</li>" for l, _, _, t, e in noeuds) + "</ul>"


class Bilan(noyau.Objet, QWidget):
    """``parcours`` : ses copies dans l'ordre de leur rendu, ``{"epreuve", "fin", "etat", "obtenu", "total", "taux"}``
    (``taux`` ``None`` en attente : jamais compté 0) ; ``conseils`` : des phrases à l'élève ; ``axes`` :
    ``[[axe, [[libellé, gagné, noté, taux], …]], …]`` sur les seules copies corrigées (``bilans.bilan_eleve``) ;
    ``appreciations`` : ``[[titre, texte], …]``, celle du bulletin s'il continue ainsi (``bilans.appreciations``) ;
    ``annee`` : sa moyenne sur 20 à ce jour, de la ``periode`` (« de l'année », « du 1er trimestre » :
    ``bilans.moyenne_affichee``), rien en tête sans copie notée ; ``arbre`` : ``[[libellé, gagné, noté, taux, enfants],
    …]``, thème, section du cours ou contenu du BO, capacité (``bilans.arbre``), qui remplace ``DANS_L_ARBRE``."""

    def __init__(self, eleve: str, parcours: list[dict[str, Any]], axes: list[list[Any]] = (), genere: str = "",
                 conseils: list[str] = (),
                 appreciations: list[list[str]] = (), annee: float | None = None,
                 periode: str = "de l'année", arbre: list[list[Any]] = ()) -> None:
        application()
        QWidget.__init__(self)
        self.eleve, self.parcours, self.axes = eleve, parcours, list(axes)
        self.genere, self.annee, self.periode = genere, annee, periode
        self.conseils, self.appreciations, self.arbre = list(conseils), [list(a) for a in appreciations], list(arbre)
        self.setWindowTitle(f"Bilan de {eleve}")
        d = QVBoxLayout(self)
        for texte in self._sections():
            etiquette = QLabel(texte)
            etiquette.setWordWrap(True)
            etiquette.setTextFormat(Qt.TextFormat.RichText)
            etiquette.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            d.addWidget(etiquette)
        d.addStretch()

    def _sections(self) -> list[str]:
        statistiques = [(axe, [(l, g, n) for l, g, n, _ in lignes]) for axe, lignes in self.axes]
        forts, faibles = (_uniques(l, 5) for l in noyau.ressorts(statistiques, sum(len(d) for _, d in statistiques)))
        tete = [f"Moyenne {self.periode} à ce jour : <b>{f'{round(self.annee, 1):g}'.replace('.', ',')} / 20</b>"
                ] if self.annee is not None else []
        tete += [f"établi le {self.genere}"] if self.genere else []
        sections = [f"<h2>Bilan de {escape(self.eleve)}</h2>" + (f"<p>{' — '.join(tete)}</p>" if tete else "")]
        if self.appreciations:
            sections.append("<h3>Votre appréciation</h3>" + "".join(
                f"<p><b>{escape(titre)}</b> : {escape(texte)}</p>" for titre, texte in self.appreciations))
        if forts or faibles:
            sections.append("".join(f"<p><b>{titre}</b> : {escape(', '.join(libelles))}</p>" for titre, libelles in
                                    (("Points solides", forts), ("À retravailler", faibles)) if libelles))
        lignes = "".join(
            f"<tr><td>{escape(p['epreuve'])}</td><td>{_date(p['fin'])}</td>"
            f"<td align=right>{_note(p)}</td>"
            f"<td align=right>{_pc(p['taux'])}</td></tr>" for p in self.parcours)
        sections.append("<h3>Copie après copie</h3><table cellspacing=0 cellpadding=4>"
                        "<tr><th align=left>Épreuve</th><th align=left>Rendue le</th><th>Note</th><th>Réussite</th></tr>"
                        f"{lignes}</table>")
        if self.conseils:
            sections.append("<h3>Conseils</h3><ul>" + "".join(f"<li>{escape(c)}</li>" for c in self.conseils) + "</ul>")
        if self.arbre:
            sections.append("<h3>Thème par thème</h3>" + _branches(self.arbre))
        for axe, detail in self.axes:
            if self.arbre and axe in DANS_L_ARBRE:
                continue
            sections.append(f"<h3>{axe}</h3><table cellspacing=0 cellpadding=2>" + "".join(
                f"<tr><td>{escape(l)}</td><td align=right>{_pc(t)}</td></tr>" for l, _, _, t in detail) + "</table>")
        return sections


def ouvrir_bilan(chemin: str, code: str) -> Bilan | None:
    """Le bilan ``chemin`` ouvert par le code personnel ``code``, ou ``None`` si ce code ne l'ouvre pas."""
    try:
        bilan = charger(chemin, cle(code))
    except ValueError as erreur:  # serializejson : DecryptionError (code faux), ou chiffré sans mot de passe
        if "password" in str(erreur) or "decryption" in str(erreur):
            return None
        raise
    if not isinstance(bilan, Bilan):
        raise ValueError(f"{chemin} : pas un bilan d'élève")
    return bilan


class AccueilBilan(QDialog):
    """Le code personnel, seul champ ; Entrée ouvre. Ne bloque pas (``open``, comme ``lecteur.Accueil``) : ``ouvert`` reçoit
    la fenêtre du bilan."""

    def __init__(self, chemin: str, ouvert: Any) -> None:
        super().__init__()
        self.chemin, self.ouvert = chemin, ouvert
        self.setWindowTitle("Bilan")
        self.code = QLineEdit()
        self.code.setEchoMode(QLineEdit.EchoMode.Password)
        self.code.returnPressed.connect(self.essayer)
        self.message = QLabel("Tapez votre code personnel, puis Entrée.")
        self.message.setWordWrap(True)
        formulaire = QFormLayout(self)
        formulaire.addRow("Code personnel", self.code)
        formulaire.addRow(self.message)
        self.setMinimumWidth(360)

    def essayer(self) -> None:
        bilan = ouvrir_bilan(self.chemin, self.code.text())
        if bilan is None:
            self.message.setText("Code incorrect.")
            return
        self.accept()
        self.ouvert(fenetre(bilan))


def fenetre(bilan: Bilan) -> QScrollArea:
    """Le bilan dans une zone défilante, à garder tant qu'elle est ouverte."""
    zone = QScrollArea()
    zone.setWidget(bilan)
    zone.setWidgetResizable(True)
    zone.setWindowTitle(bilan.windowTitle())
    zone.resize(720, 800)
    zone.show()
    return zone
