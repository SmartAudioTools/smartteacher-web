"""Les aménagements de chaque élève, pour ses copies papier : tirés du classeur des aménagements
(``plan_de_classe/amenagements/amenagements_<année>.json``, fait par ``plan_de_classe/amenagements_json.py``), hors hg et
illisible des sessions Claude dès qu'il porte les vrais noms (décision du professeur, 09/11/2026 : « commencer par mettre
les vrais noms dans le json d'aménagement et t'en couper les permissions »). Rien ici n'écrit ni n'affiche un nom : les
appelants ne rendent que des comptes.

Le classeur : ``{classe: {"Nom Prénom": {"amenagements": [libellé, …], "profil": […], …}, …}}`` (format choisi par le
professeur le 10/11/2026 : les classes à la racine, sans la page DS, une fiche par élève ; ``plan_de_classe/
amenagements_par_eleve.py`` y passe l'ancien). Un élève est retrouvé par son nom et son prénom, dans n'importe
quel ordre, sans accents ni casse, quel que soit le séparateur (``cle``). Il compose sur ordinateur, donc n'a pas de copie
papier aménagée, dès qu'un de ses libellés cite un ordinateur.
"""
from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path
from typing import Any

DOSSIER = Path(__file__).resolve().parent.parent / "plan_de_classe" / "amenagements"

# Libellé harmonisé du classeur (avant toute parenthèse) → aménagement du générateur (exporter_pdf.AMENAGEMENTS) ;
# correspondance de « TODO - Aménagements des sujets ». Les consignes séquencées attendent la décision du professeur.
# « Police sans empattement » (élève dys) est séparable d'« agrandi » : un libellé à porter au classeur, sans taille.
CORRESPONDANCE = {"tiers-temps": "tiers_temps", "temps compensatoire": "tiers_temps",
                  "consignes reformulées": "simplifie", "police / mise en page adaptée": "agrandi",
                  "police sans empattement": "sans_empattement"}
ORDINATEUR = re.compile(r"\bordinateur", re.I)


def cle(*morceaux: str) -> tuple[str, ...]:
    """Les mots d'un nom, sans accents, en minuscules, triés : « DUPONT Élise » et « Elise Dupont » se rejoignent."""
    texte = unicodedata.normalize("NFKD", " ".join(morceaux)).encode("ascii", "ignore").decode().lower()
    return tuple(sorted(re.findall(r"[a-z]+", texte)))


def classeur(dossier: Path = DOSSIER) -> dict[str, Any] | None:
    """Le classeur le plus récent (``amenagements_*.json``, l'année dans le nom), ``None`` s'il n'y en a pas."""
    fichiers = sorted(dossier.glob("amenagements_*.json"))
    return json.loads(fichiers[-1].read_text(encoding="utf-8")) if fichiers else None


def profil(libelles: list[str]) -> frozenset[str]:
    """Les aménagements du générateur que portent ces libellés (les autres, salle, calculatrice…, ne changent pas le PDF)."""
    return frozenset(CORRESPONDANCE[cle_libelle] for libelle in libelles
                     if (cle_libelle := libelle.split("(")[0].strip().lower()) in CORRESPONDANCE)


def libelles(donnees: dict[str, Any]) -> dict[tuple[str, ...], list[str]]:
    """{clé du nom: libellés du classeur}, toutes classes confondues."""
    tous: dict[tuple[str, ...], list[str]] = {}
    for classe in donnees.values():
        for eleve, fiche in classe.items():
            tous.setdefault(cle(eleve), []).extend(fiche.get("amenagements") or [])
    return tous


def eleves(donnees: dict[str, Any]) -> dict[tuple[str, ...], frozenset[str] | None]:
    """{clé du nom: aménagements du générateur, ou ``None`` pour l'élève qui compose sur ordinateur}."""
    return {nom: None if any(ORDINATEUR.search(l) for l in liste) else profil(liste)
            for nom, liste in libelles(donnees).items()}


def sur_ordinateur(inscrits: dict[str, list], donnees: dict[str, Any]) -> list[dict[str, Any]]:
    """Les élèves inscrits au sujet qui composent sur ordinateur (``{"nom", "prenom", "classe", "amenagements"}``), avec
    les aménagements du générateur que portent leurs autres libellés (``eleves`` les tait : pas de copie papier). Pour
    leur sujet Word de secours (``pdf_qcm.sujets_word``)."""
    connus = libelles(donnees)
    return [{"nom": nom, "prenom": prenom, "classe": classe, "amenagements": profil(liste)}
            for classe in sorted(inscrits) for nom, prenom, *_ in inscrits[classe]
            for liste in [connus.get(cle(nom, prenom), [])] if any(ORDINATEUR.search(l) for l in liste)]


def copies_amenagees(inscrits: dict[str, list], donnees: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, int]]:
    """Les élèves inscrits au sujet qui ont une copie papier aménagée (``{"nom", "prenom", "classe", "amenagements"}``,
    l'élève tel qu'``exporter_pdf.exporter`` le prend), et les comptes : aménagés, sur ordinateur, au classeur sans effet
    sur le PDF."""
    connus = eleves(donnees)
    copies, comptes = [], {"amenages": 0, "ordinateur": 0, "sans_effet": 0}
    for classe in sorted(inscrits):
        for nom, prenom, *_ in inscrits[classe]:
            if (amenagements := connus.get(cle(nom, prenom), frozenset())) is None:
                comptes["ordinateur"] += 1
            elif amenagements:
                comptes["amenages"] += 1
                copies.append({"nom": nom, "prenom": prenom, "classe": classe, "amenagements": amenagements})
            elif cle(nom, prenom) in connus:
                comptes["sans_effet"] += 1
    return copies, comptes
