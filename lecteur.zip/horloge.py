"""L'heure d'une épreuve, prise en ligne plutôt que sur l'ordinateur de l'élève, qui peut régler son horloge à sa guise.

L'heure d'un serveur est lue une fois (l'en-tête ``Date`` d'une réponse HTTP, à la seconde), puis avancée avec
``time.monotonic()``, que le réglage de l'horloge système ne touche pas : le réseau ne sert qu'au début. Sur un ordinateur,
une requête HTTPS vers un grand site (le NTP, en UDP, est souvent bloqué au lycée) ; dans le navigateur, une requête HEAD
vers la page elle-même : même origine, donc l'en-tête ``Date`` y est lisible, ce que Dropbox n'expose pas.

Sans réseau (coupure au lycée), l'horloge de l'ordinateur sert, faute de mieux — décision de l'utilisateur, 27/09/2026 :
« se fier à l'horloge de l'ordinateur, uniquement s'il n'y a pas internet » — et l'heure en ligne est retentée toutes les
trente secondes tant qu'on la demande : dès qu'elle revient, elle reprend la main. ``en_ligne()`` dit laquelle sert, pour
que la copie retienne qu'elle a été composée à l'heure locale (``Paquet.heure_locale``).

Le même code tourne dans le navigateur (Pyodide) : seules l'adresse interrogée (``_adresses``) et ``locale`` y diffèrent.
"""

from __future__ import annotations

import sys
import time
from collections.abc import Callable
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

from qtpy6.QtCore import QCoreApplication, QEventLoop, QUrl
from qtpy6.QtNetwork import QNetworkAccessManager, QNetworkRequest  # au chargement : dans le navigateur, un module Qt chargé à la demande
# ne peut l'être que d'où Python suspend ; à la première requête, depuis un slot de la pompe, il tuait Pyodide (11/10/2026)

SERVEURS = "https://www.google.com", "https://www.cloudflare.com", "https://www.wikipedia.org"
DELAI = 3  # secondes d'attente d'un serveur
REESSAI = 30  # secondes entre deux essais sans réseau
NAVIGATEUR = sys.platform == "emscripten"

_ecart = None  # heure en ligne (s depuis 1970, UTC) moins time.monotonic(), connue depuis la dernière réponse d'un serveur
_essai = float("-inf")  # time.monotonic() du dernier essai
_en_vol = False  # un essai attend sa réponse
_gestionnaire = None  # le QNetworkAccessManager, créé au premier essai


def _adresses():
    """Dans le navigateur, la page même : même origine, donc l'en-tête ``Date`` lisible. Une adresse neuve à chaque fois, sinon
    le navigateur sert le HEAD depuis son cache, avec le Date de la page déjà chargée (GitHub Pages : max-age=600) : l'heure
    retardait jusqu'à 10 min sur un lien relancé, et la copie du professeur, d'avant la dernière soumission, passait pour la
    plus récente (pont_qt.reprendre_puis_afficher, 01/10/2026)."""
    if NAVIGATEUR:
        from js import location  # noqa: PLC0415 - Pyodide seulement
        return [f"{location.origin}{location.pathname}?horloge={time.time_ns()}"]
    return list(SERVEURS)


def _poser(date: float, avant: float) -> None:
    """L'écart à ``time.monotonic()`` d'après l'en-tête ``Date`` d'une requête partie à ``avant`` : tronqué à la seconde, il
    retarde de 0,5 s en moyenne, et de la moitié de l'aller-retour."""
    global _ecart
    _ecart = date + 0.5 + (time.monotonic() - avant) / 2 - time.monotonic()


def _interroger(adresses: list[str], fini: Callable[[], None]) -> None:
    """Un HEAD au premier serveur de ``adresses``, au suivant s'il ne donne pas de ``Date`` ; ``fini`` à la fin, heure lue ou
    non. Sans attendre : ``QNetworkAccessManager`` rend la main, la même ligne en natif et dans le navigateur (QtNetwork y
    est un module chargé à la demande, à l'import de ce module)."""
    global _gestionnaire

    if _gestionnaire is None:
        _gestionnaire = QNetworkAccessManager()
        _gestionnaire.setTransferTimeout(DELAI * 1000)
    avant = time.monotonic()
    reponse = _gestionnaire.head(QNetworkRequest(QUrl(adresses[0])))

    def lue() -> None:
        date = bytes(reponse.rawHeader("Date")).decode()  # une réponse d'erreur HTTP porte aussi l'heure du serveur
        reponse.deleteLater()
        if date:
            _poser(parsedate_to_datetime(date).timestamp(), avant)
        if date or len(adresses) == 1:
            fini()
        else:
            _interroger(adresses[1:], fini)
    reponse.finished.connect(lue)


def _essayer(fini: Callable[[], None] = lambda: None) -> bool:
    """Lance un essai de l'heure en ligne, sauf s'il en part déjà un ; rend True s'il en est parti un. Sans application Qt
    (un outil en ligne de commande), rien ne part : il n'y aurait pas de boucle pour recevoir la réponse."""
    global _essai, _en_vol
    if _en_vol or QCoreApplication.instance() is None:
        return False
    _essai, _en_vol = time.monotonic(), True

    def termine() -> None:
        global _en_vol
        _en_vol = False
        fini()
    _interroger(_adresses(), termine)
    return True


def demarrer() -> None:
    """Le premier essai, en attendant sa réponse (quelques secondes au pire hors ligne) : avant de juger la date d'un code, pas
    avant de savoir l'heure. Les suivants partent seuls (``secondes``)."""
    if _essai == float("-inf"):
        boucle = QEventLoop()
        if _essayer(boucle.quit) and _en_vol:
            boucle.exec()


def en_ligne():
    return _ecart is not None


def secondes():
    """L'heure (secondes UTC depuis 1970) : en ligne si elle a pu être lue, celle de l'ordinateur sinon. Sans heure en ligne,
    un nouvel essai part toutes les ``REESSAI`` secondes, sans attendre sa réponse."""
    if _ecart is None and time.monotonic() - _essai > REESSAI:
        _essayer()
    return time.time() if _ecart is None else time.monotonic() + _ecart


def maintenant():
    """``secondes()`` en ``datetime`` UTC."""
    return datetime.fromtimestamp(secondes(), timezone.utc)


def locale(date):
    """Une date UTC à l'heure de l'élève, pour l'afficher : dans le navigateur, Python ignore le fuseau (UTC), le JavaScript
    le connaît."""
    if NAVIGATEUR:
        from js import Date  # noqa: PLC0415
        decalage = Date.new(date.timestamp() * 1000).getTimezoneOffset()  # minutes, UTC moins l'heure locale
        return datetime.fromtimestamp(date.timestamp() - decalage * 60, timezone.utc).replace(tzinfo=None)
    return date.astimezone().replace(tzinfo=None)
