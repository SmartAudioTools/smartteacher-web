"""L'heure d'une épreuve, prise en ligne plutôt que sur l'ordinateur de l'élève, qui peut régler son horloge à sa guise.

L'heure d'un serveur est lue une fois (l'en-tête ``Date`` d'une réponse HTTP, à la seconde), puis avancée avec
``time.monotonic()``, que le réglage de l'horloge système ne touche pas : le réseau ne sert qu'au début. Sur un ordinateur,
une requête HTTPS vers un grand site (le NTP, en UDP, est souvent bloqué au lycée) ; dans le navigateur, une requête HEAD
vers la page elle-même : même origine, donc l'en-tête ``Date`` y est lisible, ce que Dropbox n'expose pas.

Sans réseau (coupure au lycée), l'horloge de l'ordinateur sert, faute de mieux — décision de l'utilisateur, 27/09/2026 :
« se fier à l'horloge de l'ordinateur, uniquement s'il n'y a pas internet » — et l'heure en ligne est retentée toutes les
trente secondes tant qu'on la demande : dès qu'elle revient, elle reprend la main. ``en_ligne()`` dit laquelle sert, pour
que la copie retienne qu'elle a été composée à l'heure locale (``Paquet.heure_locale``).

Module pur Python : il tourne aussi dans le navigateur (Pyodide).
"""

import asyncio
import sys
import threading
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

SERVEURS = "https://www.google.com", "https://www.cloudflare.com", "https://www.wikipedia.org"
DELAI = 3  # secondes d'attente d'un serveur
REESSAI = 30  # secondes entre deux essais sans réseau
NAVIGATEUR = sys.platform == "emscripten"

_ecart = None  # heure en ligne (s depuis 1970, UTC) moins time.monotonic(), connue depuis la dernière réponse d'un serveur
_essai = float("-inf")  # time.monotonic() du dernier essai
_verrou = threading.Lock()


def _adresse():
    """Dans le navigateur, la page même : même origine, donc l'en-tête ``Date`` lisible. Une adresse neuve à chaque fois, sinon
    le navigateur sert le HEAD depuis son cache, avec le Date de la page déjà chargée (GitHub Pages : max-age=600) : l'heure
    retardait jusqu'à 10 min sur un lien relancé, et la copie du professeur, d'avant la dernière soumission, passait pour la
    plus récente (pont_qt.reprendre_puis_afficher, 01/10/2026)."""
    from js import location  # noqa: PLC0415 - Pyodide seulement
    return f"{location.pathname}?horloge={time.time_ns()}"


def _poser(date, avant):
    """L'écart à ``time.monotonic()`` d'après l'en-tête ``Date`` d'une requête partie à ``avant`` : tronqué à la seconde, il
    retarde de 0,5 s en moyenne, et de la moitié de l'aller-retour."""
    global _ecart
    _ecart = date + 0.5 + (time.monotonic() - avant) / 2 - time.monotonic()


def _date_du_serveur():
    """Les secondes UTC que donne l'en-tête ``Date`` d'un serveur, ou None."""
    if NAVIGATEUR:
        from js import XMLHttpRequest  # noqa: PLC0415 - Pyodide seulement
        try:
            requete = XMLHttpRequest.new()
            requete.open("HEAD", _adresse(), False)  # synchrone : le premier essai seulement (``demarrer``)
            requete.send()
            date = requete.getResponseHeader("Date")
        except Exception:  # noqa: BLE001 - hors ligne : l'appel lève une NetworkError
            return None
        return parsedate_to_datetime(date).timestamp() if date else None
    import urllib.request  # noqa: PLC0415
    for url in SERVEURS:
        try:
            with urllib.request.urlopen(urllib.request.Request(url, method="HEAD"), timeout=DELAI) as reponse:
                date = reponse.headers.get("Date")
        except OSError:
            continue
        if date:
            return parsedate_to_datetime(date).timestamp()
    return None


def synchroniser():
    """Lit l'heure en ligne ; rend True si elle est connue. Bloquant (quelques secondes au pire hors ligne)."""
    global _essai
    with _verrou:
        _essai = avant = time.monotonic()
        date = _date_du_serveur()
        if date is not None:
            _poser(date, avant)
    return _ecart is not None


async def _reessayer_dans_le_navigateur():
    """Les essais suivants, dans le navigateur, sans attendre la réponse : synchrone, une requête que le réseau perd sans la
    refuser (Wi-Fi associé, sortie coupée) figerait la page jusqu'à son expiration, une minute et plus, toutes les
    ``REESSAI`` secondes (réactivité, 02/10/2026)."""
    from pyodide.http import pyfetch  # noqa: PLC0415 - Pyodide seulement
    avant = time.monotonic()
    try:
        reponse = await pyfetch(_adresse(), method="HEAD", cache="no-store")
    except Exception:  # noqa: BLE001 - hors ligne : la promesse est rejetée
        return
    date = reponse.js_response.headers.get("Date")
    if date:
        _poser(parsedate_to_datetime(date).timestamp(), avant)


def demarrer():
    """Le premier essai, en attendant sa réponse : avant de juger la date d'un code, pas avant de savoir l'heure. Les
    suivants partent seuls (``secondes``)."""
    if _essai == float("-inf"):
        synchroniser()


def en_ligne():
    return _ecart is not None


def secondes():
    """L'heure (secondes UTC depuis 1970) : en ligne si elle a pu être lue, celle de l'ordinateur sinon. Sans heure en ligne,
    un nouvel essai part toutes les ``REESSAI`` secondes, en tâche de fond sur un ordinateur."""
    global _essai
    if _ecart is None and time.monotonic() - _essai > REESSAI and not _verrou.locked():
        if NAVIGATEUR:
            _essai = time.monotonic()
            asyncio.ensure_future(_reessayer_dans_le_navigateur())
        else:
            threading.Thread(target=synchroniser, daemon=True).start()
    return time.time() if _ecart is None else time.monotonic() + _ecart


def maintenant():
    """``secondes()`` en ``datetime`` UTC."""
    return datetime.fromtimestamp(secondes(), timezone.utc)


def locale(date):
    """Une date UTC à l'heure de l'élève, pour l'afficher : dans le navigateur, Python ignore le fuseau (UTC), le JavaScript
    le connaît."""
    if NAVIGATEUR:
        from js import Date  # noqa: PLC0415
        decalage = Date.new(date.timestamp() * 1000).getTimezoneOffset()  # minutes, UTC moins l'heure locale
        return datetime.fromtimestamp(date.timestamp() - decalage * 60, timezone.utc).replace(tzinfo=None)
    return date.astimezone().replace(tzinfo=None)
