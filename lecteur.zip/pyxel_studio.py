"""Le code d'un projet Pyxel Studio, lu à son lien : ce que l'élève a écrit hors du lecteur (question ``code`` à
``editeur_externe``), pour que sa question soit corrigée sur son vrai programme. Même chemin que
``update_repositories.py`` du projet Monkey : la page du projet (lien privé ``/studio/<id>`` ou public ``/<id>``) donne
l'identifiant de STOCKAGE, qui n'est pas celui du lien, et le fichier se lit sous ``/storage/projects/<stockage>/``.
pyxelstudio.net répond ``Access-Control-Allow-Origin: *`` à l'un comme à l'autre (vérifié le 01/10/2026) : la version
web du lecteur les lit aussi."""

import re

from qtpy6.QtCore import QEventLoop, QUrl

SITE = "https://www.pyxelstudio.net"
FICHIER = "app.py"  # le programme principal d'un projet Pyxel Studio
DELAI = 15  # secondes


def lire(url):
    """Le texte à ``url`` : ``QNetworkAccessManager`` attendu dans une boucle locale, la même ligne en natif et dans le
    navigateur (QtNetwork y est un module chargé à la demande, sa boucle une suspension JSPI de qtpy6)."""
    from qtpy6.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest  # noqa: PLC0415 - au premier lien, pas au chargement de la page

    gestionnaire = QNetworkAccessManager()
    gestionnaire.setTransferTimeout(DELAI * 1000)
    reponse = gestionnaire.get(QNetworkRequest(QUrl(url)))
    boucle = QEventLoop()
    reponse.finished.connect(boucle.quit)
    boucle.exec()
    if reponse.error() != QNetworkReply.NetworkError.NoError:
        code = reponse.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        raise OSError(f"HTTP {code}" if code else reponse.errorString())
    type_contenu = str(reponse.header(QNetworkRequest.KnownHeaders.ContentTypeHeader) or "")
    jeu = re.search(r"charset=([\w-]+)", type_contenu)
    return bytes(reponse.readAll()).decode(jeu.group(1) if jeu else "utf-8", errors="replace")


def identifiant(lien):
    """L'identifiant du projet dans ce que l'élève a collé : le lien entier, privé ou public, ou l'identifiant seul."""
    lien = lien.strip().rstrip("/")
    return re.sub(r"^.*pyxelstudio\.net/(studio/)?", "", lien).split("?")[0].split("#")[0]


def code(lien, fichier=FICHIER):
    """Le contenu de ``fichier`` dans le projet de ``lien`` ; ``ValueError`` avec un message pour l'élève sinon."""
    projet = identifiant(lien)
    if not re.fullmatch(r"[A-Za-z0-9_-]+", projet):
        raise ValueError("ce n'est pas un lien de projet Pyxel Studio")
    for page in (f"{SITE}/studio/{projet}", f"{SITE}/{projet}"):
        try:
            stockage = re.search(r"/storage/projects/([^/\"']+)/", lire(page))
        except Exception:  # noqa: BLE001 - 404 d'un lien qui n'est pas de ce genre, ou réseau absent : l'autre page
            continue
        if stockage:
            try:
                return lire(f"{SITE}/storage/projects/{stockage.group(1)}/{fichier}")
            except Exception as erreur:  # noqa: BLE001
                raise ValueError(f"{fichier} est introuvable dans le projet ({erreur})") from None
    raise ValueError("projet introuvable : vérifie le lien, et ta connexion")
