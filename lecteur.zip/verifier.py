"""Vérifie le travail d'un élève : exécute les tests des questions « code » sur ses fichiers.

    python verifier.py SUJET DOSSIER          tableau ✔ / ✘ par exercice, pour un élève
    python verifier.py SUJET --lot RENDUS     un sous-dossier par élève -> CSV eleve;exercice;points
    python verifier.py --solutions BANQUE     chaque solution de la banque contre ses propres tests

SUJET est un paquet élève (exporter_eleve.py) ou, chez le professeur, un sujet de sujets/. Chaque question
s'exécute dans son propre processus, sous délai de garde : une boucle infinie ou un input() de l'élève ne
bloque rien, et son code ne tourne jamais dans le programme appelant (éditeur, application). Le fichier
testé est le ``fichier`` de la question (``exercice_03.py``), à défaut celui du sujet (``tp.py``).

Le côté enfant n'utilise que la bibliothèque standard ; le côté parent lit le paquet avec modele.py (serializejson).
"""

import argparse
import ast
import builtins
import contextlib
import importlib.util
import io
import json
import os
import posixpath
import re
import subprocess
import sys
import tempfile
import time
import traceback
import types
from pathlib import Path

import bac_a_sable

ICI = Path(__file__).resolve().parent
DELAI = 10  # secondes par question
MARQUE = "\x1eRESULTAT "  # préfixe de la ligne de résultat de l'enfant, que l'élève n'imprimera pas par hasard
SYMBOLES = {"reussi": "✔", "echec": "✘", "erreur": "✘", "absent": "·"}


# CÔTÉ ENFANT : un processus par question -------------------------------------------------------------------

def _ligne_eleve(exc, fichier, premiere=1):
    """« ligne 12 : » de la dernière trame qui est dans le fichier de l'élève, ou rien ; numérotée comme l'éditeur,
    dont la première ligne porte ``premiere`` (``Code.premiere_ligne``)."""
    trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == fichier]
    return f"ligne {trames[-1].lineno + premiere - 1} : " if trames else ""


def _decrire(exc):
    return f"{type(exc).__name__} : {exc}" if str(exc) else type(exc).__name__


class _FauxPyxel:
    """« import pyxel » charge pyxel_factice.py, même si le vrai est installé : pas de fenêtre, run() rend la main."""

    def find_spec(self, nom, chemin=None, cible=None):
        return importlib.util.spec_from_file_location("pyxel", ICI / "pyxel_factice.py") if nom == "pyxel" else None


def _arite(definition):
    """Le nombre de paramètres positionnels qu'accepte une ``def`` : (minimum, maximum), maximum infini avec ``*args``."""
    a = definition.args
    positionnels = len(a.posonlyargs) + len(a.args)
    return positionnels - len(a.defaults), float("inf") if a.vararg else positionnels


def fonction_choisie(source, solution, nom):
    """« Écrire une fonction qui… » sans nom imposé (``Code.fonction``) : le nom de la fonction de l'élève que les tests
    appellent sous ``nom``, celui de la solution. ``nom`` lui-même si l'élève l'a défini ; sinon, parmi ses fonctions de
    premier niveau qui acceptent autant d'arguments que celle de la solution, celle qu'aucune autre n'appelle (une
    auxiliaire est appelée par la fonction principale), la dernière écrite s'il en reste plusieurs. ``None`` sans
    candidate."""
    def definitions(code):
        return [n for n in ast.parse(code).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]

    eleve = definitions(source)
    if any(d.name == nom for d in eleve):
        return nom
    attendue = next(len(d.args.posonlyargs) + len(d.args.args) for d in definitions(solution) if d.name == nom)
    candidates = [d for d in eleve if _arite(d)[0] <= attendue <= _arite(d)[1]]
    appelees = {n.id for d in eleve for n in ast.walk(d) if isinstance(n, ast.Name) and n.id != d.name}
    racines = [d for d in candidates if d.name not in appelees] or candidates
    return racines[-1].name if racines else None


def _absent(exc, fichier, resultat):
    """Un nom cité par le test que l'élève n'a pas encore écrit : « pas commencé », pas une erreur.
    Un NameError levé dans SON code (variable mal orthographiée) reste une erreur."""
    if isinstance(exc, NameError) and not _ligne_eleve(exc, fichier):
        resultat["absents"] += 1
        resultat["messages"].append(f"{exc.name} n'est pas encore défini")
        return True
    return False


def _non_simule(module, nom):
    raise AttributeError(nom if nom.startswith("__") else
                         f"{module}.{nom} n'est pas disponible dans cet exercice, dont le système de fichiers est simulé")


class SystemeSimule:
    """Un système de fichiers en mémoire et le faux module ``os`` qui agit dessus (``Code.arborescence``, 1.61 des
    widgets de bac : « os.mkdir », « os.chmod »). Le crochet d'audit interdit d'écrire sur le disque, et un test doit juger
    l'état final : l'arbre est donc un dictionnaire {chemin relatif: mode}, remis à son état initial par ``raz``. Un chemin
    fini par « / » dans ``arborescence`` est un dossier ; ``mkdir`` applique le masque 022 de Linux (0o777 → 755)."""

    def __init__(self, arborescence):
        self.initial = {posixpath.normpath(c): (c.endswith("/"), int(m, 8)) for c, m in arborescence.items()}
        self.raz()
        os_ = types.ModuleType("os", "Doublure du module os : un système de fichiers simulé.")
        chemin = types.ModuleType("os.path")
        for nom in ("join", "basename", "dirname", "split", "splitext", "normpath", "sep"):
            setattr(chemin, nom, getattr(posixpath, nom))
        chemin.exists = lambda c: self._norme(c) in self.arbre or self._norme(c) == "."
        chemin.isdir = lambda c: self._norme(c) == "." or self.arbre.get(self._norme(c), (False,))[0]
        chemin.isfile = lambda c: self._norme(c) in self.arbre and not self.arbre[self._norme(c)][0]
        for nom in ("mkdir", "makedirs", "chmod", "listdir", "rmdir", "remove", "rename", "getcwd"):
            setattr(os_, nom, getattr(self, nom))
        os_.unlink, os_.path, os_.sep = self.remove, chemin, "/"
        for module in (os_, chemin):  # « os.walk » : le dire, plutôt qu'un AttributeError qui ferait croire à une faute de frappe
            module.__getattr__ = lambda nom, m=module.__name__: _non_simule(m, nom)
        self.modules = {"os": os_, "os.path": chemin}

    def permettre(self, permis):
        """``permis`` (``bac_a_sable``) où « os » est importable, et doublé."""
        return {**permis, "modules": permis["modules"] | {"os"}, "doublures": self.modules}

    def raz(self):
        self.arbre = dict(self.initial)

    @staticmethod
    def _norme(c):
        return posixpath.normpath(str(c)).lstrip("/") or "."

    def _dossier(self, c, exc=FileNotFoundError):
        if c != "." and not self.arbre.get(c, (False,))[0]:
            raise (NotADirectoryError(f"ce n'est pas un dossier : '{c}'") if c in self.arbre
                   else exc(f"aucun fichier ou dossier de ce nom : '{c}'"))

    def mkdir(self, c, mode=0o777):
        c = self._norme(c)
        if c in self.arbre or c == ".":
            raise FileExistsError(f"le fichier existe déjà : '{c}'")
        self._dossier(c.rpartition("/")[0] or ".")
        self.arbre[c] = (True, mode & 0o755)

    def makedirs(self, c, mode=0o777, exist_ok=False):
        c = self._norme(c)
        if exist_ok and self.arbre.get(c, (False,))[0]:
            return
        parent = c.rpartition("/")[0]
        if parent and parent not in self.arbre:
            self.makedirs(parent, mode, exist_ok=True)
        self.mkdir(c, mode)

    def chmod(self, c, mode):
        c = self._norme(c)
        if c not in self.arbre:
            raise FileNotFoundError(f"aucun fichier ou dossier de ce nom : '{c}'")
        self.arbre[c] = (self.arbre[c][0], mode & 0o777)

    def listdir(self, c="."):
        c = self._norme(c)
        self._dossier(c)
        return sorted(n.rpartition("/")[2] for n in self.arbre if (n.rpartition("/")[0] or ".") == c)

    def rmdir(self, c):
        c = self._norme(c)
        self._dossier(c)
        if self.listdir(c):
            raise OSError(f"le dossier n'est pas vide : '{c}'")
        del self.arbre[c]

    def remove(self, c):
        c = self._norme(c)
        if c not in self.arbre:
            raise FileNotFoundError(f"aucun fichier ou dossier de ce nom : '{c}'")
        if self.arbre[c][0]:
            raise IsADirectoryError(f"c'est un dossier : '{c}'")
        del self.arbre[c]

    def rename(self, source, cible):
        source, cible = self._norme(source), self._norme(cible)
        if source not in self.arbre:
            raise FileNotFoundError(f"aucun fichier ou dossier de ce nom : '{source}'")
        self._dossier(cible.rpartition("/")[0] or ".")
        for n in [n for n in self.arbre if n == source or n.startswith(source + "/")]:
            self.arbre[cible + n[len(source):]] = self.arbre.pop(n)

    @staticmethod
    def getcwd():
        return "/"

    def lignes(self):
        """L'état de l'arbre pour un test (« arborescence() ») : « chemin/ rwxrwxr-- » par dossier, « chemin rw-r--r-- »
        par fichier, dans l'ordre alphabétique."""
        return [f"{c}{'/' if d else ''} {self._droits(m)}" for c, (d, m) in sorted(self.arbre.items())]

    @staticmethod
    def _droits(mode):
        return "".join(l if mode >> (8 - i) & 1 else "-" for i, l in enumerate("rwxrwxrwx"))

    def dessin(self):
        """L'arbre tel que la console l'affiche après une commande qui l'a changé : indenté comme ``tree``, droits en tête
        comme ``ls -l``."""
        return "\n".join(f"{'d' if d else '-'}{self._droits(m)}  {'    ' * c.count('/')}{c.rpartition('/')[2]}{'/' if d else ''}"
                         for c, (d, m) in sorted(self.arbre.items()))


PRELUDE = "<prelude>"


def deposer(dossier, fichiers, permis):
    """Les fichiers de données du sujet (``Code.fichiers``, 1.55 des widgets de bac : le csv que le programme lit),
    écrits dans le dossier où il s'exécute AVANT le crochet d'audit, qui interdit ensuite d'écrire. Renvoie ``permis``
    élargi des modules que le sujet fournit (un ``outils.py`` : ``import outils``, 1.24). Un ``.db`` est une base SQLite
    donnée par son script (CREATE/INSERT), rejoué dans une base neuve à ce nom (1.34)."""
    for nom, contenu in (fichiers or {}).items():
        if nom.endswith(".db"):
            try:
                import sqlite3  # noqa: PLC0415 - comme base_sql
            except ImportError as exc:  # le lecteur du navigateur (Pyodide-Qt) n'a pas sqlite3
                raise ErreurPrelude(f"cette question a besoin de la base « {nom} », que ce lecteur ne sait pas "
                                    "ouvrir : faites-la dans le lecteur de l'ordinateur") from exc
            (Path(dossier) / nom).unlink(missing_ok=True)
            with contextlib.closing(sqlite3.connect(Path(dossier) / nom)) as base:
                base.executescript(contenu)
                base.commit()
        else:
            (Path(dossier) / nom).write_text(contenu, encoding="utf-8")
    return {**permis, "modules": permis["modules"] | {nom[:-3] for nom in fichiers or {} if nom.endswith(".py")}}


def preluder(prelude, espace):
    """Exécute le code supposé disponible (``Code.prelude``, celui du professeur) dans l'espace de l'élève, AVANT le
    sien, et rend les noms qu'il y a posés : ``analyser`` les tient pour définis. Compilé à part, il ne décale pas les
    numéros de ligne de l'élève, et n'est pas analysé ; ses ``import`` ne sont pas bornés au programme de la classe.
    Une erreur y est celle du sujet : ``ErreurPrelude``."""
    if not prelude.strip():
        return set()
    avant, importer = set(espace), espace["__builtins__"]["__import__"]
    espace["__builtins__"]["__import__"] = builtins.__import__
    try:
        exec(compile(prelude, PRELUDE, "exec"), espace)  # noqa: S102 - le code du professeur
    except BaseException as exc:  # noqa: BLE001
        raise ErreurPrelude(f"le code fourni par le sujet échoue : {_decrire(exc)}") from exc
    finally:
        espace["__builtins__"]["__import__"] = importer
    return set(espace) - avant


class ErreurPrelude(Exception):
    """Le prélude d'une question ne s'exécute pas : la faute du sujet, pas de l'élève."""


class ErreurObserve(Exception):
    pass


VALEUR = "_valeur_"  # où l'exécution « par effet » garde la valeur de la dernière expression


def _compiler(source, fichier, effet):
    """``effet`` : la dernière instruction, si c'est une expression, est gardée dans ``VALEUR`` — ce que la console
    afficherait ; les numéros de ligne ne bougent pas."""
    arbre = ast.parse(source, fichier)
    if effet and arbre.body and isinstance(arbre.body[-1], ast.Expr):
        dernier = arbre.body[-1]
        arbre.body[-1] = ast.copy_location(ast.Assign([ast.Name(VALEUR, ast.Store())], dernier.value), dernier)
        ast.fix_missing_locations(arbre)
    return compile(arbre, fichier, "exec")


def _effet(espace, sortie, observe):
    """Ce qu'un code a produit : ce qu'il affiche, ou à défaut la valeur de sa dernière expression (``print(x)`` et
    ``x`` se valent), puis le ``repr`` de chaque expression d'``observe``, évaluée après lui."""
    valeur, vus = espace.pop(VALEUR, None), []
    for e in observe:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                vus.append(repr(eval(e, espace)))  # noqa: S307
        except BaseException as exc:  # noqa: BLE001
            raise ErreurObserve(f"{e} provoque une erreur : {_decrire(exc)}") from exc
    return [sortie.strip() or ("" if valeur is None else str(valeur)), *vus]


def _effet_solution(solution, prelude, observe):
    """L'effet de la solution du sujet, exécutée après le prélude dans un espace à elle (code du professeur, non borné)."""
    espace, sortie = {"__builtins__": dict(vars(builtins)), "__name__": "__eleve__"}, io.StringIO()
    preluder(prelude, espace)
    try:
        with contextlib.redirect_stdout(sortie):
            exec(_compiler(solution, "<solution>", True), espace)  # noqa: S102
        return _effet(espace, sortie.getvalue(), observe)
    except BaseException as exc:  # noqa: BLE001
        raise ErreurPrelude(f"la solution du sujet échoue : {_decrire(exc)}") from exc


def _lus(source):
    """Les noms que le code lit."""
    return {n.id for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}


def _ecart(obtenu, attendu, observe):
    """Le message du premier écart, sans la valeur attendue (ce serait donner la réponse) ; None s'il n'y en a pas."""
    if obtenu[0] != attendu[0]:
        return f"ton code affiche « {obtenu[0]} »" if obtenu[0] else "ton code n'affiche rien et ne donne aucune valeur"
    return next((f"après ton code, {e} vaut {o}" for e, o, a in zip(observe, obtenu[1:], attendu[1:]) if o != a), None)


# les mots de ``sans:`` et ``avec:`` qui ne sont pas des noms : boucles et opérateurs
SYNTAXE = {"for": ast.For, "while": ast.While, "//": ast.FloorDiv, "%": ast.Mod, "**": ast.Pow}


def forme_manquee(source, regle):
    """Le message d'une contrainte de FORME (``Code.forme``) que le code ne respecte pas, ``None`` s'il la respecte :
    « comprehension » (une liste, un ensemble ou un dictionnaire en compréhension), « recursive:f » (f s'appelle
    elle-même), « iterative:f » (f ne s'appelle pas), « sans:x » et « avec:x » (le nom, la méthode, la boucle for ou
    while, l'opérateur //, % ou ** x, absent ou présent). Le
    message redit la contrainte de l'énoncé, jamais comment la respecter."""
    noeuds = list(ast.walk(ast.parse(source)))
    genre, _, nom = regle.partition(":")

    def emploie(x):
        if x in SYNTAXE:
            return any(isinstance(n, SYNTAXE[x]) for n in noeuds)
        return any(isinstance(n, ast.Name) and n.id == x or isinstance(n, ast.Attribute) and n.attr == x for n in noeuds)

    if genre == "comprehension":
        if not any(isinstance(n, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)) for n in noeuds):
            return "l'énoncé demande une écriture en compréhension, ton code n'en contient aucune"
    elif genre in ("recursive", "iterative"):
        definitions = [n for n in noeuds if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == nom]
        recursive = any(isinstance(n, ast.Call) and nom in (getattr(n.func, "id", None), getattr(n.func, "attr", None))
                        for d in definitions for n in ast.walk(d))
        if genre == "recursive" and not recursive:
            return f"l'énoncé demande une fonction {nom} récursive : elle doit s'appeler elle-même"
        if genre == "iterative" and recursive:
            return f"l'énoncé demande une fonction {nom} itérative : elle ne doit pas s'appeler elle-même"
    elif genre == "sans" and emploie(nom):
        return f"l'énoncé interdit d'utiliser {nom}, que ton code emploie"
    elif genre == "avec" and not emploie(nom):
        return f"l'énoncé demande d'utiliser {nom}, que ton code n'emploie pas"
    return None


class _Delai(BaseException):  # pas une Exception : un ``except Exception`` de l'élève ne l'arrête pas
    pass


def termine(appel, secondes=1):
    """Pour ``tests_code`` (problème de l'arrêt, 1.40 des widgets de bac) : vrai si ``appel()`` rend la main en moins de
    ``secondes``, faux s'il tourne encore — il est alors interrompu, sans erreur ni message qui dévoile le dispositif.
    Une trace plutôt qu'un fil ou un signal : elle marche aussi dans le Web Worker du navigateur, et une boucle sans fin
    écrite par l'élève est vue comme un appel à la fonction donnée qui ne termine pas."""
    fin = time.monotonic() + secondes

    def trace(_cadre, _evenement, _argument):
        if time.monotonic() > fin:
            raise _Delai
        return trace
    ancienne = sys.gettrace()
    sys.settrace(trace)
    try:
        appel()
    except _Delai:
        return False
    finally:
        sys.settrace(ancienne)
    return True


def mutant_survit(source, fichier, mutant, prelude, permis):
    """Vrai si les ``assert`` de l'élève ne voient pas ``mutant``, le code d'une version fausse (``Code.mutants``). Son
    code est rejoué dans un espace neuf, après le prélude, et le mutant exécuté juste après chaque définition (def, class)
    de l'élève qu'il remplace, ou après le prélude si l'élève n'en écrit aucune : « class File(File): » y hérite de la
    vraie. Seule une AssertionError levée dans le code de l'élève tue le mutant (trame la plus interne, hors des
    définitions que le mutant remplace) ; une autre erreur (IndexError d'un défilement de trop), un assert du code donné
    (même recopié dans le fichier de l'élève, comme une classe verrouillée), ou un code qui ne rend pas la main en une seconde le laissent vivre.
    Le prélude et le mutant, code du professeur, importent sans borne ; le code de l'élève garde les siennes."""
    espace = bac_a_sable.espace(permis, __name__="__eleve__", __file__=fichier)
    preluder(prelude, espace)
    remplaces = {n.name for n in ast.parse(mutant).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    noeuds = ast.parse(source, fichier).body
    coupes = [i + 1 for i, n in enumerate(noeuds) if getattr(n, "name", None) in remplaces] or [0]
    tranches = [ast.Module(noeuds[a:b], []) for a, b in zip([0, *coupes], [*coupes, len(noeuds)])]

    def derouler():
        for i, tranche in enumerate(tranches):
            if i:
                preluder(mutant, espace)
            exec(compile(tranche, fichier, "exec"), espace)  # noqa: S102 - le programme de l'élève, comme dans executer
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            termine(derouler)
    except ErreurPrelude:
        raise
    except AssertionError as exc:
        trame = exc.__traceback__
        while trame.tb_next:
            trame = trame.tb_next
        code = trame.tb_frame.f_code
        return code.co_filename != fichier or code.co_qualname.split(".")[0] in remplaces
    except BaseException:  # noqa: BLE001, S110 - toute autre erreur laisse vivre le mutant
        pass
    return True


def executer(fichier, tests, tests_code, classe="", autorises=None, prelude="", premiere=1, effet=False, observe=(),
             solution="", forme=(), fonction="", fichiers=None, mutants=(), arborescence=None):
    """Charge le fichier de l'élève et passe les tests ; renvoie {reussis, total, absents, messages, erreur}.
    Le programme de l'élève est borné par bac_a_sable ; ``tests``, ``tests_code`` et ``prelude`` (le code du
    professeur) ne le sont pas. ``effet`` : un test de plus, l'effet du code comparé à celui de ``solution``
    (``Code.effet``). Chaque règle de ``forme`` est un test de plus, sur le texte du code (``forme_manquee``).
    ``fonction`` : le nom libre (``fonction_choisie``), la fonction de l'élève est aussi nommée ainsi pour les tests.
    ``fichiers`` : ceux du sujet (``Code.fichiers``), déposés à côté du programme (``deposer``). Chaque mutant
    ({code, message}) est un test de plus, réussi si les assert de l'élève le font échouer (``mutant_survit``) ; il ne
    compte qu'une fois le code passé sans erreur sur la vraie version. ``arborescence`` : un système de fichiers simulé
    (``SystemeSimule``), « os » déjà là et importable, remis à son état initial avant chaque test ; ``arborescence()``
    rend son état aux tests."""
    sys.meta_path.insert(0, _FauxPyxel())
    fichier = str(Path(fichier).resolve())
    os.chdir(Path(fichier).parent)
    sys.path.insert(0, str(Path(fichier).parent))
    total = len(tests) + bool(tests_code) + bool(effet) + len(forme) + len(mutants)
    resultat = {"reussis": 0, "total": total, "absents": 0, "messages": [], "erreur": None}
    try:
        permis = deposer(Path(fichier).parent, fichiers, bac_a_sable.programme(classe, autorises))  # avant l'effet de la solution
    except ErreurPrelude as exc:
        resultat["erreur"] = str(exc)
        return resultat
    if effet:  # avant le programme de l'élève, qui pose le crochet d'audit
        try:
            attendu = _effet_solution(solution, prelude, observe)
        except ErreurPrelude as exc:
            resultat["erreur"] = str(exc)
            return resultat
    sortie = io.StringIO()
    systeme = arborescence and SystemeSimule(arborescence)
    simule = systeme.permettre(permis) if systeme else permis  # pas pour les mutants : valider les refuse ensemble
    espace = bac_a_sable.espace(simule, __name__="__eleve__", __file__=fichier)
    try:
        source = Path(fichier).read_text(encoding="utf-8")
        code = _compiler(source, fichier, effet)
        connus = preluder(prelude, espace)
        bac_a_sable.analyser(source, simule, fichier, connus, premiere)
        bac_a_sable.poser(Path(fichier).parent, (str(ICI / "pyxel_factice.py"),), "sqlite3" in simule["modules"])  # le faux pyxel, seul fichier du projet lisible
        with contextlib.redirect_stdout(sortie):
            exec(code, espace)  # noqa: S102 - c'est le principe : exécuter le programme de l'élève
    except SyntaxError as exc:
        resultat["erreur"] = f"ligne {exc.lineno + premiere - 1} : erreur de syntaxe ({exc.msg})"
        return resultat
    except ErreurPrelude as exc:
        resultat["erreur"] = str(exc)
        return resultat
    except EOFError:
        resultat["erreur"] = "le programme attend une saisie au clavier (input) : impossible à vérifier automatiquement"
        return resultat
    except BaseException as exc:  # noqa: BLE001 - toute erreur de l'élève, SystemExit compris
        resultat["erreur"] = f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}"
        return resultat
    espace["__builtins__"] = builtins  # les tests du professeur ne sont pas bornés ; les fonctions de l'élève gardent les leurs
    if fonction:
        choisie = fonction_choisie(source, solution, fonction)
        if choisie is None:
            resultat["messages"].append("ton code ne définit aucune fonction qui prenne les paramètres demandés")
            return resultat
        espace[fonction] = espace[choisie]
    if effet:
        try:
            # « l'instruction qui donne 65.1 » : taper 65.1 aurait le même effet ; la réponse doit lire les données de
            # l'exercice dès que la solution le fait
            ecart = ("ton code n'utilise aucune donnée de l'exercice : il doit les lire, pas recopier le résultat"
                     if _lus(solution) & connus and not _lus(source) & connus
                     else _ecart(_effet(espace, sortie.getvalue(), observe), attendu, observe))
        except ErreurObserve as exc:  # une expression d'observe que le code de l'élève a rendue impossible
            ecart = f"après ton code, {exc}"
        if ecart:
            resultat["messages"].append(ecart)
        else:
            resultat["reussis"] += 1
    for regle in forme:
        manque = forme_manquee(source, regle)
        if manque:
            resultat["messages"].append(manque)
        else:
            resultat["reussis"] += 1
    for mutant in mutants:
        try:
            survit = mutant_survit(source, fichier, mutant["code"], prelude, permis)
        except (ErreurPrelude, SyntaxError) as exc:
            resultat["erreur"] = f"un mutant du sujet : {exc}"
            return resultat
        if survit:
            resultat["messages"].append(mutant.get("message") or "tes tests ne détectent pas une des versions fausses du code")
        else:
            resultat["reussis"] += 1
    espace["sortie"], espace["termine"] = sortie.getvalue(), termine
    if "pyxel" in sys.modules:
        espace.update(sys.modules["pyxel"].AIDES)
    if systeme:
        espace["arborescence"] = systeme.lignes
    for test in tests:
        if systeme:
            systeme.raz()
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                obtenu = repr(eval(test["appel"], espace))  # noqa: S307
        except BaseException as exc:  # noqa: BLE001
            if not _absent(exc, fichier, resultat):
                resultat["messages"].append(test.get("message") or f"{test['appel']} provoque une erreur : "
                                            f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}")
            continue
        if obtenu == test["attendu"]:
            resultat["reussis"] += 1
        else:
            resultat["messages"].append(test.get("message") or f"{test['appel']} devrait valoir {test['attendu']}, ton code donne {obtenu}")
    if tests_code:
        if systeme:
            systeme.raz()
        lignes = tests_code.splitlines()
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                exec(compile(tests_code, "<tests>", "exec"), espace)  # noqa: S102
            resultat["reussis"] += 1
        except BaseException as exc:  # noqa: BLE001
            if _absent(exc, fichier, resultat):
                return resultat
            trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == "<tests>"]
            ligne = lignes[trames[-1].lineno - 1].strip() if trames else ""
            if isinstance(exc, AssertionError):
                resultat["messages"].append(str(exc) or f"test non passé : {ligne}")
            else:
                resultat["messages"].append(f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}" + (f" (pendant le test : {ligne})" if ligne else ""))
    return resultat


def _autoriseur(action, *_):
    """Le pendant SQL de bac_a_sable : le crochet d'audit de Python ne voit pas sqlite3, qui ouvrirait un fichier
    par son propre code C. Refuser ATTACH, DETACH et PRAGMA enferme la requête dans la base en mémoire."""
    import sqlite3  # noqa: PLC0415 - ici et dans les deux suivantes : le lecteur du navigateur (Pyodide-Qt, sans sqlite3) importe ce module pour lancer l'enfant

    return sqlite3.SQLITE_DENY if action in (sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH, sqlite3.SQLITE_PRAGMA) else sqlite3.SQLITE_OK


def jeu_sql(base, prelude=""):
    """Le script du jeu de données d'une question sql : sa ``base``, puis son ``prelude`` (vues, lignes ajoutées…)."""
    return base + ("\n" + prelude if prelude.strip() else "")


def base_sql(base):
    """Une base ``:memory:`` neuve où le script ``base`` (CREATE/INSERT) a été rejoué, l'autoriseur posé APRÈS lui :
    c'est la requête de l'élève qu'on borne, pas le jeu de données du sujet. Partagée avec la console du lecteur."""
    import sqlite3  # noqa: PLC0415

    connexion = sqlite3.connect(":memory:")
    connexion.executescript(base)
    connexion.set_authorizer(_autoriseur)
    return connexion


def decouper_sql(texte):
    """Les requêtes d'un texte, découpées comme SQLite les découpe : un ``;`` dans une chaîne ne coupe pas."""
    import sqlite3  # noqa: PLC0415

    requetes, courante = [], ""
    for ligne in texte.splitlines(keepends=True):
        courante += ligne
        if sqlite3.complete_statement(courante):
            requetes.append(courante)
            courante = ""
    return requetes + ([courante] if courante.strip() else [])


def _projections(obtenu, attendu):
    """Les lignes d'``obtenu`` ramenées aux colonnes d'``attendu``, dans son ordre (``colonnes_libres``, 1.10 des widgets
    de bac) : chaque colonne attendue est cherchée parmi celles qui portent les mêmes valeurs, une colonne ne sert qu'une
    fois. Rien si les nombres de lignes diffèrent : la comparaison échouera de toute façon."""
    import itertools  # noqa: PLC0415

    if not obtenu or not attendu or len(obtenu) != len(attendu):
        return
    def valeurs(lignes, j):
        return sorted((ligne[j] for ligne in lignes), key=repr)
    candidates = [[i for i in range(len(obtenu[0])) if valeurs(obtenu, i) == valeurs(attendu, j)] for j in range(len(attendu[0]))]
    for choix in itertools.product(*candidates):
        if len(set(choix)) == len(choix):
            yield [tuple(ligne[i] for i in choix) for ligne in obtenu]


CLAUSES = ("select", "from", "where", "group by", "having", "order by", "limit")
MOTS_CLES = re.compile(r"(?i)\b(select|from|where|group\s+by|having|order\s+by|limit|union|intersect|except|with|window)\b")


def _masque(requete):
    """``requete`` où chaînes, commentaires et contenu des parenthèses sont remplacés par des espaces, positions gardées :
    un mot-clé y trouvé est au premier niveau de la requête (une sous-requête reste dans sa clause)."""
    morceaux, profondeur = [], 0
    for m in re.finditer(r"'[^']*'?|\"[^\"]*\"?|`[^`]*`?|\[[^\]]*\]?|--[^\n]*|/\*.*?(?:\*/|$)|[()]|[^'\"`\[()/-]+|.", requete, re.S):
        texte = m.group()
        profondeur += {"(": 1, ")": -1}.get(texte, 0)
        cache = profondeur > 0 or texte[0] in "'\"`[" or texte.startswith(("--", "/*"))
        morceaux.append(re.sub(r"[^\n]", " ", texte) if cache and texte not in "()" else texte)
    return "".join(morceaux)


def clauses_sql(requete):
    """{clause: (début, fin)} d'une requête SELECT simple, positions dans ``requete`` (``from`` garde ses JOIN) ; None
    pour tout le reste (WITH, UNION, INSERT…), qu'on ne découpe pas."""
    debuts = [(" ".join(m.group(1).lower().split()), m.start()) for m in MOTS_CLES.finditer(_masque(requete))]
    noms = [nom for nom, _ in debuts]
    if not noms or requete[:debuts[0][1]].strip() or not set(noms) <= set(CLAUSES) or len(set(noms)) < len(noms) \
            or noms != sorted(noms, key=CLAUSES.index) or noms[0] != "select":
        return None
    fins = [a for _, a in debuts[1:]] + [len(requete.rstrip().rstrip(";"))]
    return {nom: (a, a + len(requete[a:b].rstrip())) for (nom, a), b in zip(debuts, fins)}


def conditions_sql(clause):
    """Les (début, fin) des conditions qu'un WHERE ou un HAVING relie par AND au premier niveau, mot-clé exclu."""
    masque = _masque(clause)  # ses espaces cachent des chaînes : on y coupe, mais on ne rogne que le vrai texte
    coupures = [m.span() for m in re.finditer(r"(?i)\b(?:where|having|and)\b", masque)]
    morceaux = zip([b for _, b in coupures], [a for a, _ in coupures[1:]] + [len(clause)])
    return [(a + len(clause[a:b]) - len(clause[a:b].lstrip()), a + len(clause[a:b].rstrip())) for a, b in morceaux]


def localiser_sql(requete, solution, passe):
    """La partie fausse de ``requete`` : le plus petit ensemble de clauses (requête simple) ou de requêtes (une réponse
    qui en enchaîne autant que ``solution``) qu'il suffit de remplacer par celles de ``solution`` pour que ``passe(texte)``
    (tous les tests réussis) ; une partie, puis deux, jamais tout ce que l'élève a écrit, qui ne localiserait rien.

    Renvoie ``(fautes, partiel)`` ou None. ``fautes`` : les (début, fin) à barrer dans ``requete``, vides pour une
    clause MANQUANTE (à l'endroit où elle devait s'écrire). ``partiel`` : la part juste, comptée sur les parties de la
    solution que l'élève a écrites ou qu'il fallait écrire - sauf un FROM d'une seule table, que l'énoncé donne en la
    nommant -, plus les parties en trop. Le remplacement
    est jugé sur l'exécution, comme la réponse : si remettre une clause rend juste tout le reste, ce reste fait déjà son
    travail, il est « pertinent en lui-même » et il compte."""
    import itertools  # noqa: PLC0415

    eleve, attendue = decouper_sql(requete), decouper_sql(solution)
    if len(eleve) > 1 and len(eleve) == len(attendue):  # plusieurs requêtes : chacune est une partie
        parties, debut = {}, 0
        for n, (e, a) in enumerate(zip(eleve, attendue)):
            parties[n] = (e, a, (debut + len(e) - len(e.lstrip()), debut + len(e.rstrip())))
            debut += len(e)
        comptees = set(parties)
        separateur = ""
    elif len(eleve) == len(attendue) == 1 and (ce := clauses_sql(eleve[0])) and (ca := clauses_sql(attendue[0])):
        parties = {}
        for nom in CLAUSES:
            if nom in ce or nom in ca:  # une clause manquante se place à la fin de celle de l'élève qui la précède
                place = ce.get(nom) or (p := max(b for k, (_, b) in ce.items() if CLAUSES.index(k) < CLAUSES.index(nom)), p)
                parties[nom] = (eleve[0][slice(*ce[nom])] if nom in ce else "",
                                attendue[0][slice(*ca[nom])] if nom in ca else "", place)
        comptees = {nom for nom in ca if nom != "from" or re.search(r"(?i)\bjoin\b|,", parties[nom][1])}
        separateur = "\n"
    else:
        return None
    comparable = lambda t: " ".join(t.split()).rstrip(";").lower()  # noqa: E731
    candidates = [k for k, (e, a, _) in parties.items() if comparable(e) != comparable(a)]
    ecrites = {k for k, (e, _, _) in parties.items() if e.strip()}
    def assembler(choix, *remplacee):
        return separateur.join(t for k, (e, a, _) in parties.items()
                               if (t := remplacee[1] if remplacee and k == remplacee[0] else a if k in choix else e))

    for taille in (1, 2):
        for choix in itertools.combinations(candidates, taille):
            if ecrites <= set(choix) or not passe(assembler(choix)):
                continue
            # une clause de la solution que l'élève n'a pas écrite et dont le résultat se passe (ORDER BY d'un
            # résultat non ordonné) ne compte ni pour ni contre lui
            comptees = (comptees & ecrites) | set(choix)
            return [_condition_fausse(k, parties[k], choix, assembler, passe) for k in choix], \
                len(comptees - set(choix)) / len(comptees)
    return None


def _condition_fausse(cle, partie, choix, assembler, passe):
    """Dans un WHERE ou un HAVING faux, la seule condition (reliée par AND) qu'il suffit de remplacer par l'une de celles de
    la solution, s'il y en a une : c'est elle qu'on barre, pas toute la clause ni son mot-clé, qui est juste."""
    eleve, attendue, (debut, fin) = partie
    if cle not in ("where", "having") or not eleve:
        return debut, fin
    for a, b in conditions_sql(eleve):
        for c, d in conditions_sql(attendue):
            if passe(assembler(choix, cle, eleve[:a] + attendue[c:d] + eleve[b:])):
                return debut + a, debut + b
    return debut, fin


def executer_sql(requete, base, tests, ordonne=False, colonnes_libres=False, doublons_libres=False, controle="", solution=""):
    """Exécute la requête de l'élève sur ``base`` et compare les LIGNES du résultat, jamais le texte de la requête.

    ``base`` est un script ``CREATE TABLE … ; INSERT …`` rejoué dans une base ``:memory:`` NEUVE à chaque test, si
    bien qu'un test ne subit pas l'état laissé par le précédent. Un test dont l'``appel`` est vide juge le résultat
    de la requête de l'élève ; sinon ``appel`` est une requête de contrôle jouée APRÈS elle, ce qui couvre les
    INSERT, UPDATE et DELETE, qui ne rendent rien mais laissent une trace. ``attendu`` est le ``repr()`` de la liste
    de tuples attendue ; l'ordre des lignes est indifférent sauf si ``ordonne``.

    La réponse peut enchaîner plusieurs requêtes (1.2 des widgets de bac : « écrire, dans le bon ordre, les requêtes… ») :
    elles sont jouées dans l'ordre, la première erreur arrête tout (une clé étrangère violée, si la base pose
    ``PRAGMA foreign_keys = ON``), et le résultat jugé est celui de la dernière qui rend des lignes.

    ``colonnes_libres`` : le résultat de l'élève peut porter d'autres colonnes que celles d'``attendu``, dans un autre
    ordre (« la liste des trajets… », où choisir ses colonnes est légitime) ; une requête de contrôle, elle, reste
    comparée telle quelle.

    ``doublons_libres`` : une ligne répétée compte pour une (avec ou sans DISTINCT, 1.49 des widgets de bac). ``controle`` :
    des INSERT CACHÉS ajoutés à la base pour un test de plus, dont l'attendu est le résultat de ``solution`` : la base du
    sujet ne discrimine pas toujours (toutes ses lignes passent le WHERE), et l'élève ne voit qu'elle."""
    resultat = {"reussis": 0, "total": len(tests) + bool(controle), "absents": 0, "messages": [], "erreur": None}
    if not requete.strip():
        resultat["erreur"] = "aucune requête écrite"
        return resultat
    import sqlite3  # noqa: PLC0415

    try:
        base_sql(base).close()  # d'abord le jeu de données : sinon son erreur serait imputée à l'élève
    except sqlite3.Error as exc:
        resultat["erreur"] = f"le jeu de données du sujet est refusé par SQLite : {_decrire(exc)}"
        return resultat

    def jouer(script, requetes, appel=""):
        connexion = base_sql(script)
        try:
            obtenu = []
            for instruction in decouper_sql(requetes):
                curseur = connexion.execute(instruction)
                if curseur.description:
                    obtenu = curseur.fetchall()
            return connexion.execute(appel).fetchall() if appel.strip() else obtenu
        finally:
            connexion.close()

    def egal(lignes, attendu):
        if doublons_libres:
            lignes, attendu = list(dict.fromkeys(lignes)), list(dict.fromkeys(attendu))
        return (lignes == attendu) if ordonne else (sorted(lignes, key=repr) == sorted(attendu, key=repr))

    def juste(obtenu, attendu, appel=""):
        return egal(obtenu, attendu) or (colonnes_libres and not appel.strip()
                                         and any(egal(p, attendu) for p in _projections(obtenu, attendu)))

    def evaluer(texte):
        reussis, messages = 0, []
        for test in tests:
            try:
                obtenu = jouer(base, texte, test["appel"])
            except sqlite3.Error as exc:
                messages.append(test.get("message") or f"ta requête provoque une erreur SQL : {_decrire(exc)}")
                continue
            try:
                attendu = [tuple(ligne) for ligne in ast.literal_eval(test["attendu"])]
            except (ValueError, SyntaxError):
                messages.append(f"attendu illisible dans le sujet : {test['attendu']}")
                continue
            if juste(obtenu, attendu, test["appel"]):
                reussis += 1
            else:
                quoi = f"la requête de contrôle « {test['appel']} » donne" if test["appel"].strip() else "ta requête donne"
                messages.append(test.get("message") or f"{quoi} {obtenu}, on attendait {attendu}")
        if controle:
            try:
                attendu = jouer(base + "\n" + controle, solution)
            except sqlite3.Error as exc:
                messages.append(f"la solution du sujet échoue sur les lignes de contrôle : {_decrire(exc)}")
                return reussis, messages
            try:
                ok = juste(jouer(base + "\n" + controle, texte), attendu)
            except sqlite3.Error:
                ok = False
            if ok:
                reussis += 1
            else:  # sans les lignes ni le résultat : ce serait donner la réponse
                messages.append("sur d'autres lignes que celles du sujet, ta requête ne donne pas le bon résultat : "
                                "vérifie qu'elle filtre bien selon la condition demandée")
        return reussis, messages

    resultat["reussis"], resultat["messages"] = evaluer(requete)
    if resultat["reussis"] < resultat["total"] and solution.strip():  # la partie fausse, et ce que vaut le reste
        trouve = localiser_sql(requete, solution, lambda texte: evaluer(texte)[0] == resultat["total"])
        if trouve:
            resultat["fautes"], resultat["partiel"] = trouve
    return resultat


# L'assembleur (1.25 des widgets de bac) : l'extrait RISC-V 32 bits des sujets, nom -> genre des trois opérandes
# (r : registre, v : valeur, e : étiquette) ; un sujet qui en cite une autre l'ajoute ici et dans ``derouler``
INSTRUCTIONS = {"addi": "rrv", "add": "rrr", "sub": "rrr", "beq": "rre", "bne": "rre", "bgt": "rre", "ble": "rre"}
REGISTRES = 8  # « l'unité de contrôle dispose de 8 registres notés r1 à r8 »
PAS_MAX = 10_000  # au-delà, une boucle qui ne s'arrête pas


class ErreurAssembleur(Exception):
    """Une ligne refusée, ou un programme qui ne s'arrête pas : le message le dit à l'élève."""


def assembler(source):
    """(instructions, etiquettes) : chaque instruction (numéro de ligne, nom, opérandes), chaque étiquette -> l'indice de
    l'instruction qui la suit. Virgules facultatives, casse indifférente,
    commentaire derrière ``#``, étiquette seule sur sa ligne ou devant une instruction."""
    instructions, etiquettes = [], {}
    for numero, ligne in enumerate(source.split("\n"), 1):
        ligne = ligne.split("#", 1)[0].strip()
        if m := re.match(r"(\w+)\s*:", ligne):
            if m[1].upper() in etiquettes:
                raise ErreurAssembleur(f"ligne {numero} : l'étiquette {m[1]} est déjà posée plus haut")
            etiquettes[m[1].upper()] = len(instructions)
            ligne = ligne[m.end():].strip()
        if not ligne:
            continue
        nom, *operandes = ligne.replace(",", " ").split()
        genre = INSTRUCTIONS.get(nom.lower())
        if genre is None:
            raise ErreurAssembleur(f"ligne {numero} : « {nom} » n'est pas une instruction connue ({', '.join(INSTRUCTIONS)})")
        if len(operandes) != 3:
            raise ErreurAssembleur(f"ligne {numero} : {nom.lower()} attend trois opérandes, pas {len(operandes)}")
        lus = []
        for g, o in zip(genre, operandes):
            if g == "r" and not (re.fullmatch(r"[rR][1-9]\d*", o) and int(o[1:]) <= REGISTRES):
                raise ErreurAssembleur(f"ligne {numero} : « {o} » n'est pas un registre (r1 à r{REGISTRES})")
            if g == "v" and not re.fullmatch(r"[+-]?\d+", o):
                raise ErreurAssembleur(f"ligne {numero} : « {o} » n'est pas un nombre entier")
            lus.append(int(o[1:]) if g == "r" else int(o) if g == "v" else o.upper())
        instructions.append((numero, nom.lower(), lus))
    for numero, nom, lus in instructions:
        if INSTRUCTIONS[nom][2] == "e" and lus[2] not in etiquettes:
            raise ErreurAssembleur(f"ligne {numero} : l'étiquette {lus[2]} n'est posée nulle part")
    return instructions, etiquettes


def derouler(programme, registres):
    """Exécute ``programme`` (``assembler``) sur ``registres`` (numéro -> valeur), qu'il modifie et rend."""
    instructions, etiquettes = programme
    i = pas = 0
    while i < len(instructions):
        if (pas := pas + 1) > PAS_MAX:
            raise ErreurAssembleur(f"le programme ne s'arrête pas : plus de {PAS_MAX} instructions exécutées "
                                   "(un saut qui revient toujours en arrière ?)")
        _, nom, (a, b, c) = instructions[i]
        i += 1
        if nom == "addi":
            registres[a] = registres[b] + c
        elif nom in ("add", "sub"):
            registres[a] = registres[b] + (registres[c] if nom == "add" else -registres[c])
        elif {"beq": registres[a] == registres[b], "bne": registres[a] != registres[b],
              "bgt": registres[a] > registres[b], "ble": registres[a] <= registres[b]}[nom]:
            i = etiquettes[c]
    return registres


def lire_registres(texte):
    """« r1 = 5, r2 = -7 » -> {1: 5, 2: -7} ; ValueError si le texte ne se lit pas ainsi."""
    paires = re.findall(r"[rR](\d+)\s*=\s*([+-]?\d+)", texte)
    if re.sub(r"[rR]\d+\s*=\s*[+-]?\d+|[\s,;]", "", texte) or any(not 1 <= int(n) <= REGISTRES for n, _ in paires):
        raise ValueError(f"« {texte} » : des registres r1 à r{REGISTRES} et leur valeur, « r1 = 5, r2 = 7 »")
    return {int(n): int(v) for n, v in paires}


def ecrire_registres(registres):
    return ", ".join(f"r{n} = {v}" for n, v in sorted(registres.items()))


def executer_assembleur(source, tests):
    """Chaque test part de registres à 0 sauf ceux de son ``appel`` (« r1 = 5, r2 = 7 »), déroule le programme de
    l'élève, et compare les registres que nomme ``attendu`` (« r1 = 7, r2 = 5 ») : les autres sont libres (un registre
    de travail comme r3). Un programme refusé à l'assemblage est une erreur, comme un SyntaxError en Python."""
    resultat = {"reussis": 0, "total": len(tests), "absents": 0, "messages": [], "erreur": None}
    if not source.strip():
        resultat["erreur"] = "aucune instruction écrite"
        return resultat
    try:
        programme = assembler(source)
    except ErreurAssembleur as exc:
        resultat["erreur"] = str(exc)
        return resultat
    for test in tests:
        try:
            depart, attendu = lire_registres(test["appel"]), lire_registres(test["attendu"])
        except ValueError as exc:
            resultat["messages"].append(f"test illisible dans le sujet : {exc}")
            continue
        try:
            fin = derouler(programme, {n: depart.get(n, 0) for n in range(1, REGISTRES + 1)})
        except ErreurAssembleur as exc:
            resultat["messages"].append(str(exc))
            continue
        fausses = {n: v for n, v in attendu.items() if fin[n] != v}
        if not fausses:
            resultat["reussis"] += 1
        else:
            resultat["messages"].append(test.get("message") or (
                f"en partant de {ecrire_registres(depart) or 'registres à 0'}, ton programme finit avec "
                f"{ecrire_registres({n: fin[n] for n in fausses})}, on attendait {ecrire_registres(fausses)}"))
    return resultat


def enfant():
    demande = json.loads(sys.stdin.read())
    sys.stdin = io.StringIO()  # un input() de l'élève lève EOFError au lieu d'attendre
    if demande.get("langage") == "sql":
        resultat = executer_sql(Path(demande["fichier"]).read_text(encoding="utf-8"),
                                jeu_sql(demande.get("base", ""), demande.get("prelude", "")),
                                demande.get("tests", []), demande.get("ordonne", False),
                                demande.get("colonnes_libres", False), demande.get("doublons_libres", False),
                                demande.get("controle", ""), demande.get("solution", ""))
    elif demande.get("langage") == "assembleur":
        resultat = executer_assembleur(Path(demande["fichier"]).read_text(encoding="utf-8"), demande.get("tests", []))
    else:
        resultat = executer(demande["fichier"], demande.get("tests", []), demande.get("tests_code", ""),
                            demande.get("classe", ""), demande.get("autorises"), demande.get("prelude", ""),
                            demande.get("premiere_ligne", 1), demande.get("effet", False), demande.get("observe", []),
                            demande.get("solution", ""), demande.get("forme", []), demande.get("fonction", ""),
                            demande.get("fichiers"), demande.get("mutants", []), demande.get("arborescence"))
    sys.__stdout__.write("\n" + MARQUE + json.dumps(resultat) + "\n")


# CÔTÉ PARENT -----------------------------------------------------------------------------------------------

def a_verifier(questions):
    """Les questions « code » et « sql » qui ont des tests, sous-questions de groupe comprises (``questions`` :
    celles d'un paquet élève ou d'une banque)."""
    return [f for q in questions for f in q.feuilles() if f.type in ("code", "sql") and f.testee()]


def verifier_question(q, dossier, fichier_defaut, python=sys.executable, classe=""):
    """{id, fichier, etat, points, obtenus, messages} ; etat : reussi, echec, erreur ou absent. ``classe`` fixe ce
    que le programme a le droit d'employer (bac_a_sable.programme), sauf si la question a sa propre liste."""
    return verifier_questions([(q, dossier, fichier_defaut, classe)], python)[0]


def variantes_python(texte, solution, donne=""):
    """Le pendant de ``localiser_sql`` pour un programme, côté parent (l'enfant ne s'exécute qu'une fois : bac_a_sable
    pose un crochet d'audit qu'on ne retire pas) : chaque façon de remplacer une ou deux fonctions de ``texte`` par celles
    de même nom de ``solution``, ``(n, [(noms, fautes, variante)])``, une partie avant deux, ``n`` le nombre de
    fonctions de ``texte`` que la solution définit aussi, hors celles que ``donne`` (le code de départ) fournit déjà
    telles quelles : comme un FROM d'une table que l'énoncé nomme, les recopier ne rapporte rien. Rien si ``texte`` a moins de deux
    fonctions communes avec la solution : remplacer l'unique fonction ne localiserait rien. ``fautes`` : les (début, fin)
    des fonctions remplacées, décorateurs compris, dans ``texte``."""
    import itertools  # noqa: PLC0415

    def fonctions(source):
        try:
            arbre = ast.parse(source)
        except SyntaxError:
            return {}
        debuts = [0, *itertools.accumulate(len(ligne) for ligne in source.splitlines(keepends=True))]
        return {n.name: (debuts[min(d.lineno for d in [n, *n.decorator_list]) - 1], debuts[n.end_lineno])
                for n in arbre.body if isinstance(n, ast.FunctionDef | ast.AsyncFunctionDef)}

    eleve, attendue, fournies = fonctions(texte), fonctions(solution), fonctions(donne)
    communes = [nom for nom in eleve if nom in attendue
                and texte[slice(*eleve[nom])].strip() != solution[slice(*attendue[nom])].strip()]
    if len(set(eleve) & set(attendue)) < 2:
        return 0, []
    variantes = []
    for taille in (1, 2):
        for noms in itertools.combinations(communes, taille):
            if len(noms) < len(eleve):
                variante = texte
                for nom in sorted(noms, key=lambda n: -eleve[n][0]):  # de la fin vers le début : les positions tiennent
                    a, b = eleve[nom]
                    variante = variante[:a] + solution[slice(*attendue[nom])].rstrip("\n") + "\n" + variante[b:]
                fautes = [(eleve[n][0], eleve[n][0] + len(texte[slice(*eleve[n])].rstrip())) for n in noms]
                variantes.append((noms, fautes, variante))
    return len({nom for nom in set(eleve) & set(attendue)
                if nom not in fournies or texte[slice(*eleve[nom])].strip() != donne[slice(*fournies[nom])].strip()}), variantes


def verifier_questions(travaux, python=sys.executable):
    """``verifier_question`` sur chaque ``(q, dossier, fichier_defaut, classe)`` de ``travaux``, résultats dans l'ordre.
    Toujours un sous-processus par question, mais lancés en même temps, un par cœur : 66 ms chacun, surtout le démarrage
    de Python, et 130 questions de code à la fin d'un TP (8,6 s l'une après l'autre). Les questions sont lues ici, dans
    le fil appelant : une question paresseuse se bâtit (des widgets) à la lecture d'un attribut. Dans le navigateur, sans
    fils, l'un après l'autre."""
    prepares = [_preparer(*travail) for travail in travaux]
    lancer = lambda p: p[2] and _lancer(p[2], python)  # noqa: E731
    if sys.platform == "emscripten" or len(prepares) < 2:
        finis = [lancer(p) for p in prepares]
    else:
        from concurrent.futures import ThreadPoolExecutor  # noqa: PLC0415
        with ThreadPoolExecutor(os.cpu_count()) as fils:
            finis = list(fils.map(lancer, prepares))
    return [_interpreter(q, *p, fini) for (q, *_), p, fini in zip(travaux, prepares, finis)]


def _preparer(q, dossier, fichier_defaut, classe):
    """(base, fichier, demande) ; demande None si le fichier de l'élève n'existe pas."""
    nom = q.fichier or fichier_defaut
    fichier = Path(dossier) / nom
    base = {"id": q.id, "fichier": nom, "points": q.points, "obtenus": 0}
    if not fichier.is_file():
        return base, fichier, None
    return base, fichier, json.dumps({
        "fichier": str(fichier), "tests": [vars(t) for t in q.tests], "tests_code": q.tests_code,
        "classe": classe, "autorises": q.autorises, "langage": q.langage,
        "base": q.script_base(), "ordonne": getattr(q, "ordonne", False), "colonnes_libres": getattr(q, "colonnes_libres", False),
        "doublons_libres": getattr(q, "doublons_libres", False), "controle": getattr(q, "controle", ""),
        "prelude": q.prelude_source(), "premiere_ligne": q.premiere_ligne,
        "effet": q.effet, "observe": q.observe, "forme": q.forme, "fonction": q.fonction,
        "fichiers": q.fichiers_deposes(), "mutants": [vars(m) for m in q.mutants], "arborescence": q.arborescence,
        "solution": q.solution if q.effet or q.fonction or q.langage == "sql" else ""})


def _lancer(demande, python):
    """Le processus fini, ou None s'il a dépassé ``DELAI``."""
    try:
        return subprocess.run([python, str(ICI / "verifier.py"), "--enfant"], input=demande, capture_output=True,
                              text=True, encoding="utf-8", timeout=DELAI)
    except subprocess.TimeoutExpired:
        return None


def _interpreter(q, base, fichier, demande, fini):
    if demande is None:
        return {**base, "etat": "absent", "messages": [f"{base['fichier']} n'existe pas encore"]}
    if fini is None:
        return {**base, "etat": "erreur", "messages": [f"le programme ne s'est pas terminé en {DELAI} s : boucle infinie ?"]}
    lignes = [ligne for ligne in fini.stdout.split("\n") if ligne.startswith(MARQUE)]
    if not lignes:  # l'enfant est mort sans répondre : sortie brutale (os._exit), plantage de Python…
        return {**base, "etat": "erreur", "messages": [f"le programme s'est arrêté brutalement (code {fini.returncode})"
                                                       + (f" : {fini.stderr.strip().splitlines()[-1]}" if fini.stderr.strip() else "")]}
    r = json.loads(lignes[-1][len(MARQUE):])
    if r["erreur"]:
        return {**base, "etat": "erreur", "messages": [r["erreur"]]}
    if getattr(q, "commentaires", None):  # une note par commentaire attendu, lue dans le texte et non à l'exécution
        manques = q.commentaires_manques(fichier.read_text(encoding="utf-8"))
        r = {**r, "reussis": r["reussis"] + len(q.commentaires) - len(manques), "total": r["total"] + len(q.commentaires),
             "messages": r["messages"] + manques}
    etat = ("reussi" if r["reussis"] == r["total"] else "absent" if r["absents"] == r["total"] else "echec")
    # ``partiel`` : la part juste d'une réponse dont la partie fausse est localisée (localiser_sql) ; ``fautes`` : cette partie
    fraction = max(r["reussis"] / r["total"], r.get("partiel", 0))
    return {**base, "etat": etat, "obtenus": round(base["points"] * fraction, 2), "messages": r["messages"],
            "fautes": r.get("fautes", [])}


def verifier(paquet, dossier, python=sys.executable):
    return verifier_questions([(q, dossier, paquet.fichier, paquet.classe) for q in a_verifier(paquet.questions())], python)


def charger(chemin, mot_de_passe=None):
    """Un paquet élève (chiffré : ``mot_de_passe``), ou un sujet de sujets/ (chez le professeur, qui a les banques) converti en paquet."""
    import codes  # noqa: PLC0415
    from modele import Paquet  # noqa: PLC0415 - seulement côté parent : l'enfant n'importe pas Qt
    from modele import charger as charger_objet  # noqa: PLC0415
    cle = str(chemin).endswith(".qcm") and (mot_de_passe or codes.cle_du_fichier(chemin))
    objet = charger_objet(chemin, cle or None)
    if isinstance(objet, Paquet):
        return objet
    from exporter_eleve import paquet  # noqa: PLC0415 - seulement chez le professeur
    from sujet import Sujet  # noqa: PLC0415
    return paquet(Sujet(chemin)).nommer("")  # préparé comme pour un élève, variables tirées


def afficher(resultats):
    for r in resultats:
        print(f"{SYMBOLES[r['etat']]} {r['id']:<40} {r['obtenus']:>5g} / {r['points']:<3g} {r['fichier']}")
        for message in r["messages"]:
            print(f"      {message}")
    print(f"total : {sum(r['obtenus'] for r in resultats):g} / {sum(r['points'] for r in resultats):g}")


def solutions(banque, python=sys.executable):
    """Chaque solution de la banque (objet ``Banque``, déjà chargée) contre ses propres tests ; renvoie
    [(id, messages)] de celles qui échouent."""
    questions = a_verifier(banque.questions)
    with tempfile.TemporaryDirectory() as racine:
        travaux = []
        for n, q in enumerate(questions):
            (dossier := Path(racine) / str(n)).mkdir()
            (dossier / (q.fichier or "tp.py")).write_text(q.solution, encoding="utf-8")
            travaux.append((q, dossier, "tp.py", banque.niveau))
        return [(r["id"], r["messages"]) for r in verifier_questions(travaux, python) if r["etat"] != "reussi"]


def main():
    if sys.argv[1:] == ["--enfant"]:
        return enfant()
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujet", nargs="?", type=Path, help="paquet élève ou sujet")
    analyseur.add_argument("dossier", nargs="?", type=Path, help="dossier des fichiers de l'élève")
    analyseur.add_argument("--lot", type=Path, help="dossier des rendus : un sous-dossier par élève")
    analyseur.add_argument("--solutions", type=Path, nargs="+", help="banques dont vérifier les solutions")
    analyseur.add_argument("--mot-de-passe", help="mot de passe du paquet .qcm (défaut : celui des sujets d'entraînement)")
    analyseur.add_argument("--python", default=sys.executable, help="interpréteur de l'élève (défaut : celui-ci)")
    a = analyseur.parse_args()
    if a.solutions:
        from modele import charger as charger_objet  # noqa: PLC0415 - import tardif : modele importe verifier
        echecs = [(b, *e) for b in a.solutions for e in solutions(charger_objet(b), a.python)]
        for banque, qid, messages in echecs:
            print(f"✘ {banque.name} {qid} : " + " ; ".join(messages))
        return 1 if echecs else 0
    if not a.sujet or not (a.dossier or a.lot):
        analyseur.error("il faut un sujet, et un dossier ou --lot")
    paquet = charger(a.sujet, a.mot_de_passe)
    if a.lot:
        print("eleve;exercice;points;sur")
        for eleve in sorted(p for p in a.lot.iterdir() if p.is_dir()):
            resultats = verifier(paquet, eleve, a.python)
            for r in resultats:
                print(f"{eleve.name};{r['id']};{r['obtenus']:g};{r['points']:g}")
            print(f"{eleve.name};total;{sum(r['obtenus'] for r in resultats):g};{sum(r['points'] for r in resultats):g}")
    else:
        afficher(verifier(paquet, a.dossier, a.python))
    return 0


if __name__ == "__main__":
    sys.exit(main())
