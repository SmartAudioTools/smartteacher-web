"""Vérifie le travail d'un élève : exécute les tests des questions « code » sur ses fichiers.

    python verifier.py SUJET DOSSIER          tableau ✔ / ✘ par exercice, pour un élève
    python verifier.py SUJET --lot RENDUS     un sous-dossier par élève -> CSV eleve;exercice;points
    python verifier.py --solutions BANQUE     chaque solution de la banque contre ses propres tests

SUJET est un paquet élève (exporter_eleve.py) ou, chez le professeur, un sujet de sujets/. Chaque question
s'exécute dans son propre processus, sous délai de garde : une boucle infinie ou un input() de l'élève ne
bloque rien, et son code ne tourne jamais dans le programme appelant (éditeur, application). Le fichier
testé est le ``fichier`` de la question (``exercice_03.py``), à défaut celui du sujet (``tp.py``).

Le côté enfant n'utilise que la bibliothèque standard ; le côté parent lit le paquet avec modele.py (serializejson).
"""

import argparse
import ast
import builtins
import contextlib
import difflib
import functools
import importlib.util
import io
import json
import keyword
import operator
import os
import posixpath
import re
import subprocess
import sys
import tempfile
import time
import traceback
import types
import warnings
from collections.abc import Iterable, Mapping
from pathlib import Path

import bac_a_sable

ICI = Path(__file__).resolve().parent
DELAI = 10  # secondes par question
MARQUE = "\x1eRESULTAT "  # préfixe de la ligne de résultat de l'enfant, que l'élève n'imprimera pas par hasard
SYMBOLES = {"reussi": "✔", "echec": "✘", "erreur": "✘", "absent": "·"}


# CÔTÉ ENFANT : un processus par question -------------------------------------------------------------------

def _ligne_eleve(exc, fichier, premiere=1):
    """« ligne 12 : » de la dernière trame qui est dans le fichier de l'élève, ou rien ; numérotée comme l'éditeur,
    dont la première ligne porte ``premiere`` (``Code.premiere_ligne``)."""
    trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == fichier]
    return f"ligne {trames[-1].lineno + premiere - 1} : " if trames else ""


def _signaler(resultat: dict, exc: BaseException, fichier: str) -> None:
    """Range dans ``resultat["lignes_exception"]`` la ligne (base 1, celle du fichier) de la dernière trame de ``exc``
    qui est dans le fichier de l'élève, avec le nom de l'exception, ``[ligne, nom]`` : une faute que Python a affichée à
    l'exécution (``part_lignes``), et sa famille (``famille_faute``)."""
    trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == fichier]
    if trames:
        resultat.setdefault("lignes_exception", []).append([trames[-1].lineno, type(exc).__name__])


def _decrire(exc):
    return f"{type(exc).__name__} : {exc}" if str(exc) else type(exc).__name__


class _FauxPyxel:
    """« import pyxel » charge pyxel_factice.py, même si le vrai est installé : pas de fenêtre, run() rend la main."""

    def find_spec(self, nom, chemin=None, cible=None):
        return importlib.util.spec_from_file_location("pyxel", ICI / "pyxel_factice.py") if nom == "pyxel" else None


def _arite(definition):
    """Le nombre de paramètres positionnels qu'accepte une ``def`` : (minimum, maximum), maximum infini avec ``*args``."""
    a = definition.args
    positionnels = len(a.posonlyargs) + len(a.args)
    return positionnels - len(a.defaults), float("inf") if a.vararg else positionnels


def fonction_choisie(source, solution, nom):
    """« Écrire une fonction qui… » sans nom imposé (``Code.fonction``) : le nom de la fonction de l'élève que les tests
    appellent sous ``nom``, celui de la solution. ``nom`` lui-même si l'élève l'a défini ; sinon, parmi ses fonctions de
    premier niveau qui acceptent autant d'arguments que celle de la solution, celle qu'aucune autre n'appelle (une
    auxiliaire est appelée par la fonction principale), la dernière écrite s'il en reste plusieurs. ``None`` sans
    candidate."""
    def definitions(code):
        return [n for n in ast.parse(code).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]

    eleve = definitions(source)
    if any(d.name == nom for d in eleve):
        return nom
    attendue = next(len(d.args.posonlyargs) + len(d.args.args) for d in definitions(solution) if d.name == nom)
    candidates = [d for d in eleve if _arite(d)[0] <= attendue <= _arite(d)[1]]
    appelees = {n.id for d in eleve for n in ast.walk(d) if isinstance(n, ast.Name) and n.id != d.name}
    racines = [d for d in candidates if d.name not in appelees] or candidates
    return racines[-1].name if racines else None


def _definitions(code: str) -> list[tuple[str, str, ast.AST]]:
    """Les noms posés au premier niveau de ``code``, dans l'ordre : (nom, genre, nœud), genre « fonction », « classe »
    ou « variable » (affectation simple ``nom = …``, la première seule). [] si ``code`` ne s'analyse pas."""
    try:
        corps = ast.parse(code).body
    except SyntaxError:
        return []
    vus, definitions = set(), []
    for n in corps:
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            noms = [(n.name, "classe" if isinstance(n, ast.ClassDef) else "fonction")]
        elif isinstance(n, (ast.Assign, ast.AnnAssign)):
            cibles = n.targets if isinstance(n, ast.Assign) else [n.target]
            noms = [(c.id, "variable") for c in cibles if isinstance(c, ast.Name)]
        else:
            continue
        definitions += [(nom, genre, n) for nom, genre in noms if nom not in vus]
        vus.update(nom for nom, _ in noms)
    return definitions


def noms_repris(source: str, solution: str, definis: set[str]) -> dict[str, str]:
    """Les noms de la solution que les tests citent et que l'élève a écrits autrement : {nom de la solution: nom de
    l'élève}. L'élève reprend ses propres noms d'une étape à l'autre (l'utilisateur, 12/10/2026 : « il faut reconnaître
    le nom qui a été utilisé par l'élève avant de lancer les tests ») ; la notation ne doit pas exiger ceux du corrigé.
    Seuls les noms de premier niveau de la solution absents de ``definis`` (l'espace après son programme et le prélude)
    sont cherchés, parmi les noms de l'élève que la solution ne pose pas, du même genre et dans l'ordre d'écriture : une
    fonction d'une arité compatible, de préférence une qu'aucune autre n'appelle (``fonction_choisie``), une classe, une
    variable seulement quand il en manque autant qu'il en reste (sinon l'ordre seul ne les apparie pas sûrement).
    Un nom bien écrit n'est jamais touché, et un nom mal apparié échoue aux tests comme il aurait échoué absent."""
    attendues = _definitions(solution)
    poses = {nom for nom, _, _ in attendues}
    manquants = [(nom, genre, n) for nom, genre, n in attendues if nom not in definis]
    libres = [(nom, genre, n) for nom, genre, n in _definitions(source) if nom not in poses and nom in definis]
    repris = {}
    for genre in ("fonction", "classe", "variable"):
        voulus = [(nom, n) for nom, g, n in manquants if g == genre]
        internes = {x.id for a, _, n in attendues for x in ast.walk(n) if isinstance(x, ast.Name) and x.id != a}
        voulus.sort(key=lambda v: v[0] in internes)  # les fonctions que les tests appellent avant leurs auxiliaires
        offerts = [(nom, n) for nom, g, n in libres if g == genre]
        if genre == "variable" and len(voulus) != len(offerts):
            continue
        appelees = {x.id for a, n in offerts for x in ast.walk(n) if isinstance(x, ast.Name) and x.id != a} if genre == "fonction" else set()
        for nom, n in voulus:
            if genre == "fonction":
                arite = len(n.args.posonlyargs) + len(n.args.args)
                compatibles = [o for o in offerts if _arite(o[1])[0] <= arite <= _arite(o[1])[1]]
                choix = next((o for o in compatibles if o[0] not in appelees), compatibles[0] if compatibles else None)
            else:
                choix = offerts[0] if offerts else None
            if choix is not None:
                repris[nom] = choix[0]
                offerts.remove(choix)
    return repris


def renommer(source: str, noms: dict[str, str]) -> str:
    """``source`` où chaque nom (jeton NAME) de ``noms`` est remplacé par sa valeur, lignes et commentaires gardés."""
    import tokenize  # noqa: PLC0415
    lignes = source.splitlines(keepends=True)
    try:
        jetons = [j for j in tokenize.generate_tokens(io.StringIO(source).readline) if j.type == tokenize.NAME and j.string in noms]
    except (tokenize.TokenError, SyntaxError):
        return source
    for j in reversed(jetons):  # de la fin vers le début : les colonnes tiennent
        (ligne, debut), (_, fin) = j.start, j.end
        lignes[ligne - 1] = lignes[ligne - 1][:debut] + noms[j.string] + lignes[ligne - 1][fin:]
    return "".join(lignes)


def _ouvrir_renomme(fichier, texte):
    """``open`` qui rend ``texte`` pour une lecture de ``fichier`` (le crochet d'audit interdit d'écrire une copie)."""
    def ouvrir(chemin, mode="r", *args, **kwargs):
        if isinstance(chemin, (str, Path)) and str(Path(chemin).resolve()) == fichier and not set(mode) & set("wxab+"):
            return io.StringIO(texte)
        return builtins.open(chemin, mode, *args, **kwargs)
    return ouvrir


def _absent(exc, fichier, resultat):
    """Un nom cité par le test que l'élève n'a pas encore écrit : « pas commencé », pas une erreur.
    Un NameError levé dans SON code (variable mal orthographiée) reste une erreur."""
    if isinstance(exc, NameError) and not _ligne_eleve(exc, fichier):
        resultat["absents"] += 1
        resultat["messages"].append(f"{exc.name} n'est pas encore défini")
        return True
    return False


def _non_simule(module, nom):
    raise AttributeError(nom if nom.startswith("__") else
                         f"{module}.{nom} n'est pas disponible dans cet exercice, dont le système de fichiers est simulé")


class SystemeSimule:
    """Un système de fichiers en mémoire et le faux module ``os`` qui agit dessus (``Code.arborescence``, 1.61 des
    widgets de bac : « os.mkdir », « os.chmod »). Le crochet d'audit interdit d'écrire sur le disque, et un test doit juger
    l'état final : l'arbre est donc un dictionnaire {chemin relatif: mode}, remis à son état initial par ``raz``. Un chemin
    fini par « / » dans ``arborescence`` est un dossier ; ``mkdir`` applique le masque 022 de Linux (0o777 → 755)."""

    def __init__(self, arborescence):
        self.initial = {posixpath.normpath(c): (c.endswith("/"), int(m, 8)) for c, m in arborescence.items()}
        self.raz()
        os_ = types.ModuleType("os", "Doublure du module os : un système de fichiers simulé.")
        chemin = types.ModuleType("os.path")
        for nom in ("join", "basename", "dirname", "split", "splitext", "normpath", "sep"):
            setattr(chemin, nom, getattr(posixpath, nom))
        chemin.exists = lambda c: self._norme(c) in self.arbre or self._norme(c) == "."
        chemin.isdir = lambda c: self._norme(c) == "." or self.arbre.get(self._norme(c), (False,))[0]
        chemin.isfile = lambda c: self._norme(c) in self.arbre and not self.arbre[self._norme(c)][0]
        for nom in ("mkdir", "makedirs", "chmod", "listdir", "rmdir", "remove", "rename", "getcwd"):
            setattr(os_, nom, getattr(self, nom))
        os_.unlink, os_.path, os_.sep = self.remove, chemin, "/"
        for module in (os_, chemin):  # « os.walk » : le dire, plutôt qu'un AttributeError qui ferait croire à une faute de frappe
            module.__getattr__ = lambda nom, m=module.__name__: _non_simule(m, nom)
        self.modules = {"os": os_, "os.path": chemin}

    def permettre(self, permis):
        """``permis`` (``bac_a_sable``) où « os » est importable, et doublé."""
        return {**permis, "modules": permis["modules"] | {"os"}, "doublures": self.modules}

    def raz(self):
        self.arbre = dict(self.initial)

    @staticmethod
    def _norme(c):
        return posixpath.normpath(str(c)).lstrip("/") or "."

    def _dossier(self, c, exc=FileNotFoundError):
        if c != "." and not self.arbre.get(c, (False,))[0]:
            raise (NotADirectoryError(f"ce n'est pas un dossier : '{c}'") if c in self.arbre
                   else exc(f"aucun fichier ou dossier de ce nom : '{c}'"))

    def mkdir(self, c, mode=0o777):
        c = self._norme(c)
        if c in self.arbre or c == ".":
            raise FileExistsError(f"le fichier existe déjà : '{c}'")
        self._dossier(c.rpartition("/")[0] or ".")
        self.arbre[c] = (True, mode & 0o755)

    def makedirs(self, c, mode=0o777, exist_ok=False):
        c = self._norme(c)
        if exist_ok and self.arbre.get(c, (False,))[0]:
            return
        parent = c.rpartition("/")[0]
        if parent and parent not in self.arbre:
            self.makedirs(parent, mode, exist_ok=True)
        self.mkdir(c, mode)

    def chmod(self, c, mode):
        c = self._norme(c)
        if c not in self.arbre:
            raise FileNotFoundError(f"aucun fichier ou dossier de ce nom : '{c}'")
        self.arbre[c] = (self.arbre[c][0], mode & 0o777)

    def listdir(self, c="."):
        c = self._norme(c)
        self._dossier(c)
        return sorted(n.rpartition("/")[2] for n in self.arbre if (n.rpartition("/")[0] or ".") == c)

    def rmdir(self, c):
        c = self._norme(c)
        self._dossier(c)
        if self.listdir(c):
            raise OSError(f"le dossier n'est pas vide : '{c}'")
        del self.arbre[c]

    def remove(self, c):
        c = self._norme(c)
        if c not in self.arbre:
            raise FileNotFoundError(f"aucun fichier ou dossier de ce nom : '{c}'")
        if self.arbre[c][0]:
            raise IsADirectoryError(f"c'est un dossier : '{c}'")
        del self.arbre[c]

    def rename(self, source, cible):
        source, cible = self._norme(source), self._norme(cible)
        if source not in self.arbre:
            raise FileNotFoundError(f"aucun fichier ou dossier de ce nom : '{source}'")
        self._dossier(cible.rpartition("/")[0] or ".")
        for n in [n for n in self.arbre if n == source or n.startswith(source + "/")]:
            self.arbre[cible + n[len(source):]] = self.arbre.pop(n)

    @staticmethod
    def getcwd():
        return "/"

    def lignes(self):
        """L'état de l'arbre pour un test (« arborescence() ») : « chemin/ rwxrwxr-- » par dossier, « chemin rw-r--r-- »
        par fichier, dans l'ordre alphabétique."""
        return [f"{c}{'/' if d else ''} {self._droits(m)}" for c, (d, m) in sorted(self.arbre.items())]

    @staticmethod
    def _droits(mode):
        return "".join(l if mode >> (8 - i) & 1 else "-" for i, l in enumerate("rwxrwxrwx"))

    def dessin(self):
        """L'arbre tel que la console l'affiche après une commande qui l'a changé : indenté comme ``tree``, droits en tête
        comme ``ls -l``."""
        return "\n".join(f"{'d' if d else '-'}{self._droits(m)}  {'    ' * c.count('/')}{c.rpartition('/')[2]}{'/' if d else ''}"
                         for c, (d, m) in sorted(self.arbre.items()))


PRELUDE = "<prelude>"


def deposer(dossier, fichiers, permis):
    """Les fichiers de données du sujet (``Code.fichiers``, 1.55 des widgets de bac : le csv que le programme lit),
    écrits dans le dossier où il s'exécute AVANT le crochet d'audit, qui interdit ensuite d'écrire. Renvoie ``permis``
    élargi des modules que le sujet fournit (un ``outils.py`` : ``import outils``, 1.24). Un ``.db`` est une base SQLite
    donnée par son script (CREATE/INSERT), rejoué dans une base neuve à ce nom (1.34)."""
    for nom, contenu in (fichiers or {}).items():
        if nom.endswith(".db"):
            try:
                import sqlite3  # noqa: PLC0415 - comme base_sql
            except ImportError as exc:  # le lecteur du navigateur (Pyodide-Qt) n'a pas sqlite3
                raise ErreurPrelude(f"cette question a besoin de la base « {nom} », que ce lecteur ne sait pas "
                                    "ouvrir : faites-la dans le lecteur de l'ordinateur") from exc
            (Path(dossier) / nom).unlink(missing_ok=True)
            with contextlib.closing(sqlite3.connect(Path(dossier) / nom)) as base:
                base.executescript(contenu)
                base.commit()
        else:
            (Path(dossier) / nom).write_text(contenu, encoding="utf-8")
    return {**permis, "modules": permis["modules"] | {nom[:-3] for nom in fichiers or {} if nom.endswith(".py")}}


def preluder(prelude, espace):
    """Exécute le code supposé disponible (``Code.prelude``, celui du professeur) dans l'espace de l'élève, AVANT le
    sien, et rend les noms qu'il y a posés : ``analyser`` les tient pour définis. Compilé à part, il ne décale pas les
    numéros de ligne de l'élève, et n'est pas analysé ; ses ``import`` ne sont pas bornés au programme de la classe.
    Une erreur y est celle du sujet : ``ErreurPrelude``."""
    if not prelude.strip():
        return set()
    avant, importer = set(espace), espace["__builtins__"]["__import__"]
    espace["__builtins__"]["__import__"] = builtins.__import__
    try:
        exec(compile(prelude, PRELUDE, "exec"), espace)  # noqa: S102 - le code du professeur
    except BaseException as exc:  # noqa: BLE001
        raise ErreurPrelude(f"le code fourni par le sujet échoue : {_decrire(exc)}") from exc
    finally:
        espace["__builtins__"]["__import__"] = importer
    return set(espace) - avant


class ErreurPrelude(Exception):
    """Le prélude d'une question ne s'exécute pas : la faute du sujet, pas de l'élève."""


class ErreurObserve(Exception):
    pass


VALEUR = "_valeur_"  # où l'exécution « par effet » garde la valeur de la dernière expression


def _compiler(source, fichier, effet):
    """``effet`` : la dernière instruction, si c'est une expression, est gardée dans ``VALEUR`` — ce que la console
    afficherait ; les numéros de ligne ne bougent pas."""
    arbre = ast.parse(source, fichier)
    if effet and arbre.body and isinstance(arbre.body[-1], ast.Expr):
        dernier = arbre.body[-1]
        arbre.body[-1] = ast.copy_location(ast.Assign([ast.Name(VALEUR, ast.Store())], dernier.value), dernier)
        ast.fix_missing_locations(arbre)
    return compile(arbre, fichier, "exec")


def _effet(espace, sortie, observe):
    """Ce qu'un code a produit : ce qu'il affiche, ou à défaut la valeur de sa dernière expression (``print(x)`` et
    ``x`` se valent), puis le ``repr`` de chaque expression d'``observe``, évaluée après lui."""
    valeur, vus = espace.pop(VALEUR, None), []
    for e in observe:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                vus.append(repr(eval(e, espace)))  # noqa: S307
        except BaseException as exc:  # noqa: BLE001
            raise ErreurObserve(f"{e} provoque une erreur : {_decrire(exc)}") from exc
    return [sortie.strip() or ("" if valeur is None else str(valeur)), *vus]


def _lire(invite=""):  # noqa: ARG001 - l'invite n'est pas affichée : la sortie comparée est celle des print
    ligne = sys.stdin.readline()
    if not ligne:
        raise EOFError
    return ligne.removesuffix("\n")


def _clavier(saisies, espace):
    """Les ``input()`` d'un programme lisent les lignes de ``saisies`` (``Code.saisies``), dans l'ordre, sans afficher
    leur invite : une faute de frappe dans l'invite ne change pas ce que le programme produit."""
    sys.stdin = io.StringIO("".join(s + "\n" for s in saisies))
    if saisies:
        espace["__builtins__"]["input"] = _lire


def _attendue(exc, erreur_attendue):
    """Vrai si ``exc`` est l'erreur par laquelle le programme doit finir (``Code.erreur_attendue``)."""
    return bool(erreur_attendue) and type(exc).__name__ == erreur_attendue


def _effet_solution(solution, prelude, observe, saisies=(), erreur_attendue=""):
    """L'effet de la solution du sujet, exécutée après le prélude dans un espace à elle (code du professeur, non borné)."""
    espace, sortie = {"__builtins__": dict(vars(builtins)), "__name__": "__eleve__"}, io.StringIO()
    preluder(prelude, espace)
    _clavier(saisies, espace)
    try:
        with contextlib.redirect_stdout(sortie):
            try:
                exec(_compiler(solution, "<solution>", True), espace)  # noqa: S102
            except BaseException as exc:
                if not _attendue(exc, erreur_attendue):
                    raise
        return _effet(espace, sortie.getvalue(), observe)
    except BaseException as exc:  # noqa: BLE001
        raise ErreurPrelude(f"la solution du sujet échoue : {_decrire(exc)}") from exc


def _lus(source):
    """Les noms que le code lit."""
    return {n.id for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}


EXACTS = "# espaces exacts"  # dans tests_code : la question porte sur les espaces, aucune tolérance (``souple``)


def sans_espaces_superflus(valeur):
    """``valeur`` où chaque texte, même dans une liste, un tuple, un ensemble ou un dictionnaire, a perdu ses espaces
    de début et de fin de ligne et ses espaces multiples. Les sauts de ligne restent : ils changent ce qui s'affiche."""
    if isinstance(valeur, str):
        return "\n".join(" ".join(ligne.split()) for ligne in valeur.strip().splitlines())
    if isinstance(valeur, dict):
        return {sans_espaces_superflus(k): sans_espaces_superflus(v) for k, v in valeur.items()}
    for genre in (list, tuple, set, frozenset):
        if isinstance(valeur, genre):
            return genre(map(sans_espaces_superflus, valeur))
    return valeur


def egal_souple(obtenu, attendu):
    """``==``, aux espaces superflus près (consigne de l'utilisateur, 14/10/2026 : « une tolérance sur les espaces en
    début, fin et double dans les chaînes de caractère, si la question ne porte pas sur une exactitude au caractère
    près ») : « Zoé : 12 € » avec un espace final vaut « Zoé : 12 € »."""
    return obtenu == attendu or sans_espaces_superflus(obtenu) == sans_espaces_superflus(attendu)


class _AssertSouple(ast.NodeTransformer):
    """Dans les ``assert`` des tests, ``a == b`` devient ``__egal__(a, b)`` et ``a != b``, ``not __egal__(a, b)`` ;
    le reste du code des tests, et les comparaisons en chaîne, ne changent pas."""

    def visit_Assert(self, noeud):
        return self.generic_visit(_Souple().visit(noeud))


class _Souple(ast.NodeTransformer):
    def visit_Compare(self, noeud):
        self.generic_visit(noeud)
        if len(noeud.ops) != 1 or not isinstance(noeud.ops[0], (ast.Eq, ast.NotEq)):
            return noeud
        appel = ast.Call(ast.Name("__egal__", ast.Load()), [noeud.left, noeud.comparators[0]], [])
        return ast.copy_location(appel if isinstance(noeud.ops[0], ast.Eq) else ast.UnaryOp(ast.Not(), appel), noeud)


def _ecart(obtenu, attendu, observe, souple=False):
    """Le message du premier écart, sans la valeur attendue (ce serait donner la réponse) ; None s'il n'y en a pas.
    ``souple`` : l'affichage est comparé aux espaces superflus près (``egal_souple``)."""
    if not (egal_souple if souple else operator.eq)(obtenu[0], attendu[0]):
        return f"ton code affiche « {obtenu[0]} »" if obtenu[0] else "ton code n'affiche rien et ne donne aucune valeur"
    return next((f"après ton code, {e} vaut {o}" for e, o, a in zip(observe, obtenu[1:], attendu[1:]) if o != a), None)


# les mots de ``sans:`` et ``avec:`` qui ne sont pas des noms : boucles et opérateurs
SYNTAXE = {"for": ast.For, "while": ast.While, "//": ast.FloorDiv, "%": ast.Mod, "**": ast.Pow}


def forme_manquee(source, regle):
    """Le message d'une contrainte de FORME (``Code.forme``) que le code ne respecte pas, ``None`` s'il la respecte :
    « comprehension » (une liste, un ensemble ou un dictionnaire en compréhension), « recursive:f » (f s'appelle
    elle-même), « iterative:f » (f ne s'appelle pas), « sans:x » et « avec:x » (le nom, la méthode, la boucle for ou
    while, l'opérateur //, % ou ** x, absent ou présent). Le
    message redit la contrainte de l'énoncé, jamais comment la respecter."""
    noeuds = list(ast.walk(ast.parse(source)))
    genre, _, nom = regle.partition(":")

    def emploie(x):
        if x in SYNTAXE:
            return any(isinstance(n, SYNTAXE[x]) for n in noeuds)
        return any(isinstance(n, ast.Name) and n.id == x or isinstance(n, ast.Attribute) and n.attr == x for n in noeuds)

    if genre == "comprehension":
        if not any(isinstance(n, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)) for n in noeuds):
            return "l'énoncé demande une écriture en compréhension, ton code n'en contient aucune"
    elif genre in ("recursive", "iterative"):
        definitions = [n for n in noeuds if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == nom]
        recursive = any(isinstance(n, ast.Call) and nom in (getattr(n.func, "id", None), getattr(n.func, "attr", None))
                        for d in definitions for n in ast.walk(d))
        if genre == "recursive" and not recursive:
            return f"l'énoncé demande une fonction {nom} récursive : elle doit s'appeler elle-même"
        if genre == "iterative" and recursive:
            return f"l'énoncé demande une fonction {nom} itérative : elle ne doit pas s'appeler elle-même"
    elif genre == "sans" and emploie(nom):
        return f"l'énoncé interdit d'utiliser {nom}, que ton code emploie"
    elif genre == "avec" and not emploie(nom):
        return f"l'énoncé demande d'utiliser {nom}, que ton code n'emploie pas"
    return None


class _Delai(BaseException):  # pas une Exception : un ``except Exception`` de l'élève ne l'arrête pas
    pass


def termine(appel, secondes=1):
    """Pour ``tests_code`` (problème de l'arrêt, 1.40 des widgets de bac) : vrai si ``appel()`` rend la main en moins de
    ``secondes``, faux s'il tourne encore — il est alors interrompu, sans erreur ni message qui dévoile le dispositif.
    Une trace plutôt qu'un fil ou un signal : elle marche aussi dans le Web Worker du navigateur, et une boucle sans fin
    écrite par l'élève est vue comme un appel à la fonction donnée qui ne termine pas."""
    fin = time.monotonic() + secondes

    def trace(_cadre, _evenement, _argument):
        if time.monotonic() > fin:
            raise _Delai
        return trace
    ancienne = sys.gettrace()
    sys.settrace(trace)
    try:
        appel()
    except _Delai:
        return False
    finally:
        sys.settrace(ancienne)
    return True


def mutant_survit(source, fichier, mutant, prelude, permis):
    """Vrai si les ``assert`` de l'élève ne voient pas ``mutant``, le code d'une version fausse (``Code.mutants``). Son
    code est rejoué dans un espace neuf, après le prélude, et le mutant exécuté juste après chaque définition (def, class)
    de l'élève qu'il remplace, ou après le prélude si l'élève n'en écrit aucune : « class File(File): » y hérite de la
    vraie. Seule une AssertionError levée dans le code de l'élève tue le mutant (trame la plus interne, hors des
    définitions que le mutant remplace) ; une autre erreur (IndexError d'un défilement de trop), un assert du code donné
    (même recopié dans le fichier de l'élève, comme une classe verrouillée), ou un code qui ne rend pas la main en une seconde le laissent vivre.
    Le prélude et le mutant, code du professeur, importent sans borne ; le code de l'élève garde les siennes."""
    espace = bac_a_sable.espace(permis, __name__="__eleve__", __file__=fichier)
    preluder(prelude, espace)
    remplaces = {n.name for n in ast.parse(mutant).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}
    noeuds = ast.parse(source, fichier).body
    coupes = [i + 1 for i, n in enumerate(noeuds) if getattr(n, "name", None) in remplaces] or [0]
    tranches = [ast.Module(noeuds[a:b], []) for a, b in zip([0, *coupes], [*coupes, len(noeuds)])]

    def derouler():
        for i, tranche in enumerate(tranches):
            if i:
                preluder(mutant, espace)
            exec(compile(tranche, fichier, "exec"), espace)  # noqa: S102 - le programme de l'élève, comme dans executer
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            termine(derouler)
    except ErreurPrelude:
        raise
    except AssertionError as exc:
        trame = exc.__traceback__
        while trame.tb_next:
            trame = trame.tb_next
        code = trame.tb_frame.f_code
        return code.co_filename != fichier or code.co_qualname.split(".")[0] in remplaces
    except BaseException:  # noqa: BLE001, S110 - toute autre erreur laisse vivre le mutant
        pass
    return True


MORCEAUX = 6  # au plus, par exercice d'un fichier rendu : chacun coûte une exécution


def morceaux_rendu(instantane: str, texte: str, base: tuple[int, int] | None = None, avant: str | None = None) -> list[tuple[int, int]]:
    """Les lignes [a, b[ de ``texte`` (le fichier rendu, ``FichierRendu``) où chercher l'exercice en cours, la plus
    probable d'abord : ce que l'élève a écrit depuis ``instantane`` (le fichier à la validation de l'exercice
    précédent). ``base`` : les lignes [a, b[ de l'exercice précédent dans ``avant`` (``instantane`` par défaut) ; un
    exercice qui le modifie sur place (« commente ces lignes ») se juge sur elles, retouches comprises. Puis chaque
    ajout seul (un exercice antérieur retouché en même temps, des exercices écrits dans le désordre), le fichier entier
    en dernier ; sans instantané, le fichier entier."""
    lignes = texte.split("\n")
    entier = (0, len(lignes))
    if not instantane:
        return [entier]

    def ajouts(depuis):
        resultat = []
        for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, depuis, lignes, autojunk=False).get_opcodes():
            if tag == "replace" and i2 - i1 < j2 - j1:
                # des lignes retouchées et d'autres écrites à côté (un exercice cassé, le suivant écrit dessous) : les
                # retouchées là où elles ressemblent le plus aux anciennes, le reste en ajout
                k = i2 - i1
                o = max(range(j2 - j1 - k + 1), key=lambda o: sum(difflib.SequenceMatcher(None, depuis[i1 + n], lignes[j1 + o + n]).ratio()
                                                                     for n in range(k)))
                resultat += [x for x in ((j1, j1 + o, i1, i1), (j1 + o, j1 + o + k, i1, i2), (j1 + o + k, j2, i2, i2)) if x[1] > x[0]]
            elif tag != "equal":
                resultat.append((j1, j2, i1, i2))
        return resultat

    # les blocs écrits ou retouchés depuis l'instantané (une ligne retirée seule n'en est pas un)
    blocs = []
    for j1, j2, _, _ in ajouts(instantane.split("\n")):
        if any(l.strip() for l in lignes[j1:j2]):
            while not lignes[j1].strip():
                j1 += 1
            while not lignes[j2 - 1].strip():
                j2 -= 1
            # une ligne retouchée dans un corps (une méthode d'une classe) : toute l'instruction de premier niveau
            while j1 > 0 and _suite(lignes[j1]):
                j1 -= 1
            while j2 < len(lignes) and _suite(lignes[j2]):
                j2 += 1
            while not lignes[j2 - 1].strip():
                j2 -= 1
            if blocs and j1 < blocs[-1][1]:
                j1 = blocs.pop()[0]
            blocs.append((j1, j2))
    touches, fondu = [], None
    if base is not None:
        # l'exercice précédent reporté dans ``texte`` ; un bloc qui le chevauche le retouche
        (a, b), retouche, anciennes = base, False, (instantane if avant is None else avant).split("\n")
        while b > a and not anciennes[min(b, len(anciennes)) - 1].strip():  # ses lignes vides de bord
            b -= 1
        for j1, j2, i1, i2 in ajouts(anciennes):
            retouche |= i1 < base[1] and i2 > base[0]
            decalage = (j2 - j1) - (i2 - i1)
            if i2 <= a:
                a, b = a + decalage, b + decalage
            elif i1 < b:
                b += decalage
        a, b = max(0, min(a, len(lignes))), max(0, min(b, len(lignes)))
        while b > a and not lignes[b - 1].strip():  # ses lignes vides de bord (le fichier entier en a une à la fin)
            b -= 1
        while a < b and not lignes[a].strip():
            a += 1
        # un bloc écrit juste au-dessus le retouche aussi (un commentaire d'en-tête), pas un bloc écrit juste en dessous
        touches = [x for x in blocs if x[0] < b and x[1] >= a]
        if (touches or retouche) and b > a:
            fondu = (min([a, *(j1 for j1, _ in touches)]), max([b, *(j2 for _, j2 in touches)]))
    autres = [x for x in blocs if x not in touches]
    candidats = [(autres[0][0], autres[-1][1])] if autres else []
    # un bloc qui retouche l'exercice précédent et continue en dessous (l'exercice en cours écrit à la suite) : sa suite
    candidats += [(b, x[1]) for x in touches if x[1] > b]
    candidats += [fondu] if fondu else []
    # l'exercice précédent prolongé par un bloc écrit juste en dessous (« complétez votre programme » : les tests rejouent
    # le programme entier, ses input() compris)
    if base is not None:
        suite = next((x for x in blocs if x[0] >= b), None)
        if suite and b > a and not any(l.strip() for l in lignes[b:suite[0]]):
            candidats.append((a, suite[1]))
    candidats += [*reversed(blocs), entier]
    return [*[x for x in dict.fromkeys(candidats) if x != entier][:MORCEAUX - 1], entier]


def _suite(ligne):
    """Vrai si ``ligne`` continue l'instruction de premier niveau qui la précède : corps indenté, ligne vide,
    parenthèse fermante, ``else``/``elif``/``except``/``finally``."""
    return not ligne[:1].strip() or ligne.startswith((")", "]", "}")) or bool(re.match(r"(else|elif|except|finally)\b", ligne))


def _executer_contexte(contexte, fichier, espace, permis, connus):
    """Les exercices d'avant l'exercice en cours, dans le fichier rendu (``FichierRendu``) : chaque instruction de
    premier niveau compilée et exécutée à part, dans le bac à sable, ce qu'elle affiche jeté ; ses fautes ignorées (une
    erreur de syntaxe, une exception, un nom hors programme : l'exercice en cours se juge même si un précédent est faux).
    Seule une sortie du bac à sable arrête tout. Rend les noms posés, que ``analyser`` tient pour définis."""
    blocs, avant = [], set(espace)
    for n, ligne in enumerate(contexte.split("\n")):
        if blocs and (_suite(ligne) or blocs[-1][1][-1].startswith("@")):
            blocs[-1][1].append(ligne)
        else:
            blocs.append((n, [ligne]))
    for n, bloc in blocs:
        source = "\n" * n + "\n".join(bloc)
        try:
            bac_a_sable.analyser(source, permis, fichier, connus | set(espace) - avant)
            code = compile(source, fichier, "exec")
        except (SyntaxError, bac_a_sable.HorsProgramme):
            continue
        with contextlib.redirect_stdout(io.StringIO()):
            try:
                exec(code, espace)  # noqa: S102 - le programme de l'élève, borné comme le reste
            except bac_a_sable.Interdit as exc:
                if not isinstance(exc, bac_a_sable.HorsProgramme):
                    raise
            except BaseException:  # noqa: BLE001, S110 - SystemExit compris : l'exercice d'avant est faux, pas celui-ci
                pass
    return set(espace) - avant


def executer(fichier, tests, tests_code, classe="", autorises=None, prelude="", premiere=1, effet=False, observe=(),
             solution="", forme=(), fonction="", fichiers=None, mutants=(), arborescence=None, saisies=(), erreur_attendue="",
             contexte=""):
    """Charge le fichier de l'élève et passe les tests ; renvoie {reussis, total, absents, messages, erreur}.
    Le programme de l'élève est borné par bac_a_sable ; ``tests``, ``tests_code`` et ``prelude`` (le code du
    professeur) ne le sont pas. ``effet`` : un test de plus, l'effet du code comparé à celui de ``solution``
    (``Code.effet``). Chaque règle de ``forme`` est un test de plus, sur le texte du code (``forme_manquee``).
    ``fonction`` : le nom libre (``fonction_choisie``), la fonction de l'élève est aussi nommée ainsi pour les tests.
    ``fichiers`` : ceux du sujet (``Code.fichiers``), déposés à côté du programme (``deposer``). Chaque mutant
    ({code, message}) est un test de plus, réussi si les assert de l'élève le font échouer (``mutant_survit``) ; il ne
    compte qu'une fois le code passé sans erreur sur la vraie version. ``arborescence`` : un système de fichiers simulé
    (``SystemeSimule``), « os » déjà là et importable, remis à son état initial avant chaque test ; ``arborescence()``
    rend son état aux tests. ``saisies`` : ce que les ``input()`` lisent (``Code.saisies``), solution comprise ;
    ``erreur_attendue`` : le nom de l'exception par laquelle le programme doit finir (``Code.erreur_attendue``).
    ``contexte`` : ce qui précède l'exercice dans un fichier rendu (``FichierRendu``), exécuté avant lui sans être jugé
    (``_executer_contexte``) ; le fichier ne contient alors que l'exercice, et ``premiere`` est sa ligne dans le rendu."""
    sys.meta_path.insert(0, _FauxPyxel())
    fichier = str(Path(fichier).resolve())
    os.chdir(Path(fichier).parent)
    sys.path.insert(0, str(Path(fichier).parent))
    total = len(tests) + bool(tests_code) + bool(effet) + len(forme) + len(mutants)
    souple = EXACTS not in tests_code
    resultat = {"reussis": 0, "total": total, "absents": 0, "messages": [], "erreur": None}
    try:
        permis = deposer(Path(fichier).parent, fichiers, bac_a_sable.programme(classe, autorises))  # avant l'effet de la solution
    except ErreurPrelude as exc:
        resultat["erreur"] = str(exc)
        return resultat
    if effet:  # avant le programme de l'élève, qui pose le crochet d'audit
        try:
            attendu = _effet_solution(solution, prelude, observe, saisies, erreur_attendue)
        except ErreurPrelude as exc:
            resultat["erreur"] = str(exc)
            return resultat
    sortie = io.StringIO()
    systeme = arborescence and SystemeSimule(arborescence)
    simule = systeme.permettre(permis) if systeme else permis  # pas pour les mutants : valider les refuse ensemble
    espace = bac_a_sable.espace(simule, __name__="__eleve__", __file__=fichier)
    try:
        source = Path(fichier).read_text(encoding="utf-8")
        code = _compiler(source, fichier, effet)
        connus = preluder(prelude, espace)
        bac_a_sable.poser(Path(fichier).parent, (str(ICI / "pyxel_factice.py"),), "sqlite3" in simule["modules"])  # le faux pyxel, seul fichier du projet lisible
        if contexte:  # après le crochet d'audit ; ses input() lèvent EOFError (stdin vide), les saisies sont pour l'exercice
            connus |= _executer_contexte(contexte, fichier, espace, simule, connus)
        bac_a_sable.analyser(source, simule, fichier, connus, premiere)
        _clavier(saisies, espace)
        with contextlib.redirect_stdout(sortie):
            try:
                exec(code, espace)  # noqa: S102 - c'est le principe : exécuter le programme de l'élève
            except BaseException as exc:
                if not _attendue(exc, erreur_attendue):
                    raise
    except SyntaxError as exc:
        resultat["erreur"] = f"ligne {exc.lineno + premiere - 1} : erreur de syntaxe ({exc.msg})"
        return resultat
    except ErreurPrelude as exc:
        resultat["erreur"] = str(exc)
        return resultat
    except EOFError:
        resultat["erreur"] = ("le programme demande plus de saisies au clavier (input) que la correction n'en prévoit" if saisies
                              else "le programme attend une saisie au clavier (input) : impossible à vérifier automatiquement")
        return resultat
    except BaseException as exc:  # noqa: BLE001 - toute erreur de l'élève, SystemExit compris
        resultat["erreur"] = f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}"
        _signaler(resultat, exc, fichier)
        # une sortie du bac à sable, ou ce que refuse l'autoriseur de sqlite (ATTACH, VACUUM INTO : « not authorized »,
        # « authorization denied ») : jamais de part des points (noyau._verifier_ensemble)
        resultat["interdit"] = isinstance(exc, bac_a_sable.Interdit) or (type(exc).__name__ == "DatabaseError" and "authoriz" in str(exc))
        return resultat
    espace["__builtins__"] = builtins  # les tests du professeur ne sont pas bornés ; les fonctions de l'élève gardent les leurs
    if fonction:
        choisie = fonction_choisie(source, solution, fonction)
        if choisie is None:
            resultat["messages"].append("ton code ne définit aucune fonction qui prenne les paramètres demandés")
            return resultat
        espace[fonction] = espace[choisie]
    repris = noms_repris(source, solution, set(espace))
    for nom, eleve in repris.items():
        espace[nom] = espace[eleve]
    if repris and "open" not in espace:  # les tests qui relisent le fichier (``open(__file__)``, ast) y voient les noms de la solution
        espace["open"] = _ouvrir_renomme(fichier, renommer(source, {e: n for n, e in repris.items()}))
    if effet:
        try:
            # « l'instruction qui donne 65.1 » : taper 65.1 aurait le même effet ; la réponse doit lire les données de
            # l'exercice dès que la solution le fait
            ecart = ("ton code n'utilise aucune donnée de l'exercice : il doit les lire, pas recopier le résultat"
                     if _lus(solution) & connus and not _lus(source) & connus
                     else _ecart(_effet(espace, sortie.getvalue(), observe), attendu, observe, souple))
        except ErreurObserve as exc:  # une expression d'observe que le code de l'élève a rendue impossible
            ecart = f"après ton code, {exc}"
        if ecart:
            resultat["messages"].append(ecart)
        else:
            resultat["reussis"] += 1
    for regle in forme:
        manque = forme_manquee(source, regle)
        if manque:
            resultat["messages"].append(manque)
        else:
            resultat["reussis"] += 1
    for mutant in mutants:
        try:
            survit = mutant_survit(source, fichier, mutant["code"], prelude, permis)
        except (ErreurPrelude, SyntaxError) as exc:
            resultat["erreur"] = f"un mutant du sujet : {exc}"
            return resultat
        if survit:
            resultat["messages"].append(mutant.get("message") or "tes tests ne détectent pas une des versions fausses du code")
        else:
            resultat["reussis"] += 1
    espace["sortie"], espace["termine"] = sortie.getvalue(), termine
    if "pyxel" in sys.modules:
        espace.update(sys.modules["pyxel"].AIDES)
    if systeme:
        espace["arborescence"] = systeme.lignes
    for test in tests:
        if systeme:
            systeme.raz()
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                valeur = eval(test["appel"], espace)  # noqa: S307
                obtenu = repr(valeur)
        except BaseException as exc:  # noqa: BLE001
            if not _absent(exc, fichier, resultat):
                _signaler(resultat, exc, fichier)
                resultat["messages"].append(test.get("message") or f"{test['appel']} provoque une erreur : "
                                            f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}")
            continue
        if obtenu == test["attendu"] or souple and _litteral_egal(valeur, test["attendu"]):
            resultat["reussis"] += 1
        else:
            resultat["messages"].append(test.get("message") or f"{test['appel']} devrait valoir {test['attendu']}, ton code donne {obtenu}")
    if tests_code:
        if systeme:
            systeme.raz()
        lignes = tests_code.splitlines()
        espace["__egal__"] = egal_souple
        try:
            arbre = ast.parse(tests_code, "<tests>")
            if souple:
                arbre = ast.fix_missing_locations(_AssertSouple().visit(arbre))
            with contextlib.redirect_stdout(io.StringIO()):
                exec(compile(arbre, "<tests>", "exec"), espace)  # noqa: S102
            resultat["reussis"] += 1
        except BaseException as exc:  # noqa: BLE001
            if _absent(exc, fichier, resultat):
                return resultat
            trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == "<tests>"]
            ligne = lignes[trames[-1].lineno - 1].strip() if trames else ""
            if isinstance(exc, AssertionError):
                resultat["messages"].append(str(exc) or f"test non passé : {ligne}")
            else:
                _signaler(resultat, exc, fichier)
                resultat["messages"].append(f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}" + (f" (pendant le test : {ligne})" if ligne else ""))
    return resultat


def _litteral_egal(valeur, attendu):
    """``valeur`` égale, aux espaces superflus près, au littéral ``attendu`` d'un test (son ``repr``). Un littéral qui
    porte lui-même des espaces superflus (``[(' ', 3), …]``, un texte justifié) demande l'égalité exacte."""
    try:
        attendu = ast.literal_eval(attendu)
    except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
        return False
    return sans_espaces_superflus(attendu) == attendu and egal_souple(valeur, attendu)


def _autoriseur(action, *_):
    """Le pendant SQL de bac_a_sable : le crochet d'audit de Python ne voit pas sqlite3, qui ouvrirait un fichier
    par son propre code C. Refuser ATTACH, DETACH et PRAGMA enferme la requête dans la base en mémoire."""
    import sqlite3  # noqa: PLC0415 - ici et dans les deux suivantes : le lecteur du navigateur (Pyodide-Qt, sans sqlite3) importe ce module pour lancer l'enfant

    return sqlite3.SQLITE_DENY if action in (sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH, sqlite3.SQLITE_PRAGMA) else sqlite3.SQLITE_OK


def jeu_sql(base, prelude=""):
    """Le script du jeu de données d'une question sql : sa ``base``, puis son ``prelude`` (vues, lignes ajoutées…)."""
    return base + ("\n" + prelude if prelude.strip() else "")


def base_sql(base):
    """Une base ``:memory:`` neuve où le script ``base`` (CREATE/INSERT) a été rejoué, l'autoriseur posé APRÈS lui :
    c'est la requête de l'élève qu'on borne, pas le jeu de données du sujet. Partagée avec la console du lecteur."""
    import sqlite3  # noqa: PLC0415

    connexion = sqlite3.connect(":memory:")
    connexion.executescript(base)
    connexion.set_authorizer(_autoriseur)
    return connexion


def decouper_sql(texte):
    """Les requêtes d'un texte, découpées comme SQLite les découpe : un ``;`` dans une chaîne ne coupe pas."""
    import sqlite3  # noqa: PLC0415

    requetes, courante = [], ""
    for ligne in texte.splitlines(keepends=True):
        courante += ligne
        if sqlite3.complete_statement(courante):
            requetes.append(courante)
            courante = ""
    return requetes + ([courante] if courante.strip() else [])


def _projections(obtenu, attendu):
    """Les lignes d'``obtenu`` ramenées aux colonnes d'``attendu``, dans son ordre (``colonnes_libres``, 1.10 des widgets
    de bac) : chaque colonne attendue est cherchée parmi celles qui portent les mêmes valeurs, une colonne ne sert qu'une
    fois. Rien si les nombres de lignes diffèrent : la comparaison échouera de toute façon."""
    import itertools  # noqa: PLC0415

    if not obtenu or not attendu or len(obtenu) != len(attendu):
        return
    def valeurs(lignes, j):
        return sorted((ligne[j] for ligne in lignes), key=repr)
    candidates = [[i for i in range(len(obtenu[0])) if valeurs(obtenu, i) == valeurs(attendu, j)] for j in range(len(attendu[0]))]
    for choix in itertools.product(*candidates):
        if len(set(choix)) == len(choix):
            yield [tuple(ligne[i] for i in choix) for ligne in obtenu]


CLAUSES = ("select", "from", "where", "group by", "having", "order by", "limit")
MOTS_CLES = re.compile(r"(?i)\b(select|from|where|group\s+by|having|order\s+by|limit|union|intersect|except|with|window)\b")


def _masque(requete):
    """``requete`` où chaînes, commentaires et contenu des parenthèses sont remplacés par des espaces, positions gardées :
    un mot-clé y trouvé est au premier niveau de la requête (une sous-requête reste dans sa clause)."""
    morceaux, profondeur = [], 0
    for m in re.finditer(r"'[^']*'?|\"[^\"]*\"?|`[^`]*`?|\[[^\]]*\]?|--[^\n]*|/\*.*?(?:\*/|$)|[()]|[^'\"`\[()/-]+|.", requete, re.S):
        texte = m.group()
        profondeur += {"(": 1, ")": -1}.get(texte, 0)
        cache = profondeur > 0 or texte[0] in "'\"`[" or texte.startswith(("--", "/*"))
        morceaux.append(re.sub(r"[^\n]", " ", texte) if cache and texte not in "()" else texte)
    return "".join(morceaux)


def clauses_sql(requete):
    """{clause: (début, fin)} d'une requête SELECT simple, positions dans ``requete`` (``from`` garde ses JOIN) ; None
    pour tout le reste (WITH, UNION, INSERT…), qu'on ne découpe pas."""
    debuts = [(" ".join(m.group(1).lower().split()), m.start()) for m in MOTS_CLES.finditer(_masque(requete))]
    noms = [nom for nom, _ in debuts]
    if not noms or requete[:debuts[0][1]].strip() or not set(noms) <= set(CLAUSES) or len(set(noms)) < len(noms) \
            or noms != sorted(noms, key=CLAUSES.index) or noms[0] != "select":
        return None
    fins = [a for _, a in debuts[1:]] + [len(requete.rstrip().rstrip(";"))]
    return {nom: (a, a + len(requete[a:b].rstrip())) for (nom, a), b in zip(debuts, fins)}


def conditions_sql(clause):
    """Les (début, fin) des conditions qu'un WHERE ou un HAVING relie par AND au premier niveau, mot-clé exclu."""
    masque = _masque(clause)  # ses espaces cachent des chaînes : on y coupe, mais on ne rogne que le vrai texte
    coupures = [m.span() for m in re.finditer(r"(?i)\b(?:where|having|and)\b", masque)]
    morceaux = zip([b for _, b in coupures], [a for a, _ in coupures[1:]] + [len(clause)])
    return [(a + len(clause[a:b]) - len(clause[a:b].lstrip()), a + len(clause[a:b].rstrip())) for a, b in morceaux]


def localiser_sql(requete, solution, passe):
    """La partie fausse de ``requete`` : le plus petit ensemble de clauses (requête simple) ou de requêtes (une réponse
    qui en enchaîne autant que ``solution``) qu'il suffit de remplacer par celles de ``solution`` pour que ``passe(texte)``
    (tous les tests réussis) ; une partie, puis deux, jamais tout ce que l'élève a écrit, qui ne localiserait rien.

    Renvoie ``(fautes, partiel)`` ou None. ``fautes`` : les (début, fin) à barrer dans ``requete``, vides pour une
    clause MANQUANTE (à l'endroit où elle devait s'écrire). ``partiel`` : la part juste, comptée sur les parties de la
    solution que l'élève a écrites ou qu'il fallait écrire - sauf un FROM d'une seule table, que l'énoncé donne en la
    nommant -, plus les parties en trop. Le remplacement
    est jugé sur l'exécution, comme la réponse : si remettre une clause rend juste tout le reste, ce reste fait déjà son
    travail, il est « pertinent en lui-même » et il compte."""
    import itertools  # noqa: PLC0415

    eleve, attendue = decouper_sql(requete), decouper_sql(solution)
    if len(eleve) > 1 and len(eleve) == len(attendue):  # plusieurs requêtes : chacune est une partie
        parties, debut = {}, 0
        for n, (e, a) in enumerate(zip(eleve, attendue)):
            parties[n] = (e, a, (debut + len(e) - len(e.lstrip()), debut + len(e.rstrip())))
            debut += len(e)
        comptees = set(parties)
        separateur = ""
    elif len(eleve) == len(attendue) == 1 and (ce := clauses_sql(eleve[0])) and (ca := clauses_sql(attendue[0])):
        parties = {}
        for nom in CLAUSES:
            if nom in ce or nom in ca:  # une clause manquante se place à la fin de celle de l'élève qui la précède
                place = ce.get(nom) or (p := max(b for k, (_, b) in ce.items() if CLAUSES.index(k) < CLAUSES.index(nom)), p)
                parties[nom] = (eleve[0][slice(*ce[nom])] if nom in ce else "",
                                attendue[0][slice(*ca[nom])] if nom in ca else "", place)
        comptees = {nom for nom in ca if nom != "from" or re.search(r"(?i)\bjoin\b|,", parties[nom][1])}
        separateur = "\n"
    else:
        return None
    comparable = lambda t: " ".join(t.split()).rstrip(";").lower()  # noqa: E731
    candidates = [k for k, (e, a, _) in parties.items() if comparable(e) != comparable(a)]
    ecrites = {k for k, (e, _, _) in parties.items() if e.strip()}
    def assembler(choix, *remplacee):
        return separateur.join(t for k, (e, a, _) in parties.items()
                               if (t := remplacee[1] if remplacee and k == remplacee[0] else a if k in choix else e))

    for taille in (1, 2):
        for choix in itertools.combinations(candidates, taille):
            if ecrites <= set(choix) or not passe(assembler(choix)):
                continue
            # une clause de la solution que l'élève n'a pas écrite et dont le résultat se passe (ORDER BY d'un
            # résultat non ordonné) ne compte ni pour ni contre lui
            comptees = (comptees & ecrites) | set(choix)
            return [_condition_fausse(k, parties[k], choix, assembler, passe) for k in choix], \
                len(comptees - set(choix)) / len(comptees)
    return None


def _condition_fausse(cle, partie, choix, assembler, passe):
    """Dans un WHERE ou un HAVING faux, la seule condition (reliée par AND) qu'il suffit de remplacer par l'une de celles de
    la solution, s'il y en a une : c'est elle qu'on barre, pas toute la clause ni son mot-clé, qui est juste."""
    eleve, attendue, (debut, fin) = partie
    if cle not in ("where", "having") or not eleve:
        return debut, fin
    for a, b in conditions_sql(eleve):
        for c, d in conditions_sql(attendue):
            if passe(assembler(choix, cle, eleve[:a] + attendue[c:d] + eleve[b:])):
                return debut + a, debut + b
    return debut, fin


def executer_sql(requete, base, tests, ordonne=False, colonnes_libres=False, doublons_libres=False, controle="", solution=""):
    """Exécute la requête de l'élève sur ``base`` et compare les LIGNES du résultat, jamais le texte de la requête.

    ``base`` est un script ``CREATE TABLE … ; INSERT …`` rejoué dans une base ``:memory:`` NEUVE à chaque test, si
    bien qu'un test ne subit pas l'état laissé par le précédent. Un test dont l'``appel`` est vide juge le résultat
    de la requête de l'élève ; sinon ``appel`` est une requête de contrôle jouée APRÈS elle, ce qui couvre les
    INSERT, UPDATE et DELETE, qui ne rendent rien mais laissent une trace. ``attendu`` est le ``repr()`` de la liste
    de tuples attendue ; l'ordre des lignes est indifférent sauf si ``ordonne``.

    La réponse peut enchaîner plusieurs requêtes (1.2 des widgets de bac : « écrire, dans le bon ordre, les requêtes… ») :
    elles sont jouées dans l'ordre, la première erreur arrête tout (une clé étrangère violée, si la base pose
    ``PRAGMA foreign_keys = ON``), et le résultat jugé est celui de la dernière qui rend des lignes.

    ``colonnes_libres`` : le résultat de l'élève peut porter d'autres colonnes que celles d'``attendu``, dans un autre
    ordre (« la liste des trajets… », où choisir ses colonnes est légitime) ; une requête de contrôle, elle, reste
    comparée telle quelle.

    ``doublons_libres`` : une ligne répétée compte pour une (avec ou sans DISTINCT, 1.49 des widgets de bac). ``controle`` :
    des INSERT CACHÉS ajoutés à la base pour un test de plus, dont l'attendu est le résultat de ``solution`` : la base du
    sujet ne discrimine pas toujours (toutes ses lignes passent le WHERE), et l'élève ne voit qu'elle."""
    resultat = {"reussis": 0, "total": len(tests) + bool(controle), "absents": 0, "messages": [], "erreur": None}
    if not requete.strip():
        resultat["erreur"] = "aucune requête écrite"
        return resultat
    import sqlite3  # noqa: PLC0415

    try:
        base_sql(base).close()  # d'abord le jeu de données : sinon son erreur serait imputée à l'élève
    except sqlite3.Error as exc:
        resultat["erreur"] = f"le jeu de données du sujet est refusé par SQLite : {_decrire(exc)}"
        return resultat

    def jouer(script, requetes, appel=""):
        connexion = base_sql(script)
        try:
            obtenu = []
            for instruction in decouper_sql(requetes):
                curseur = connexion.execute(instruction)
                if curseur.description:
                    obtenu = curseur.fetchall()
            return connexion.execute(appel).fetchall() if appel.strip() else obtenu
        finally:
            connexion.close()

    def egal(lignes, attendu):
        if doublons_libres:
            lignes, attendu = list(dict.fromkeys(lignes)), list(dict.fromkeys(attendu))
        return (lignes == attendu) if ordonne else (sorted(lignes, key=repr) == sorted(attendu, key=repr))

    def juste(obtenu, attendu, appel=""):
        return egal(obtenu, attendu) or (colonnes_libres and not appel.strip()
                                         and any(egal(p, attendu) for p in _projections(obtenu, attendu)))

    def evaluer(texte):
        reussis, messages = 0, []
        for test in tests:
            try:
                obtenu = jouer(base, texte, test["appel"])
            except sqlite3.Error as exc:
                messages.append(test.get("message") or f"ta requête provoque une erreur SQL : {_decrire(exc)}")
                continue
            try:
                attendu = [tuple(ligne) for ligne in ast.literal_eval(test["attendu"])]
            except (ValueError, SyntaxError):
                messages.append(f"attendu illisible dans le sujet : {test['attendu']}")
                continue
            if juste(obtenu, attendu, test["appel"]):
                reussis += 1
            else:
                quoi = f"la requête de contrôle « {test['appel']} » donne" if test["appel"].strip() else "ta requête donne"
                messages.append(test.get("message") or f"{quoi} {obtenu}, on attendait {attendu}")
        if controle:
            try:
                attendu = jouer(base + "\n" + controle, solution)
            except sqlite3.Error as exc:
                messages.append(f"la solution du sujet échoue sur les lignes de contrôle : {_decrire(exc)}")
                return reussis, messages
            try:
                ok = juste(jouer(base + "\n" + controle, texte), attendu)
            except sqlite3.Error:
                ok = False
            if ok:
                reussis += 1
            else:  # sans les lignes ni le résultat : ce serait donner la réponse
                messages.append("sur d'autres lignes que celles du sujet, ta requête ne donne pas le bon résultat : "
                                "vérifie qu'elle filtre bien selon la condition demandée")
        return reussis, messages

    resultat["reussis"], resultat["messages"] = evaluer(requete)
    if resultat["reussis"] < resultat["total"] and solution.strip():  # la partie fausse, et ce que vaut le reste
        trouve = localiser_sql(requete, solution, lambda texte: evaluer(texte)[0] == resultat["total"])
        if trouve:
            resultat["fautes"], resultat["partiel"] = trouve
    return resultat


# L'assembleur (1.25 des widgets de bac) : l'extrait RISC-V 32 bits des sujets, nom -> genre des trois opérandes
# (r : registre, v : valeur, e : étiquette) ; un sujet qui en cite une autre l'ajoute ici et dans ``derouler``
INSTRUCTIONS = {"addi": "rrv", "add": "rrr", "sub": "rrr", "beq": "rre", "bne": "rre", "bgt": "rre", "ble": "rre"}
REGISTRES = 8  # « l'unité de contrôle dispose de 8 registres notés r1 à r8 »
PAS_MAX = 10_000  # au-delà, une boucle qui ne s'arrête pas


class ErreurAssembleur(Exception):
    """Une ligne refusée, ou un programme qui ne s'arrête pas : le message le dit à l'élève."""


def assembler(source):
    """(instructions, etiquettes) : chaque instruction (numéro de ligne, nom, opérandes), chaque étiquette -> l'indice de
    l'instruction qui la suit. Virgules facultatives, casse indifférente,
    commentaire derrière ``#``, étiquette seule sur sa ligne ou devant une instruction."""
    instructions, etiquettes = [], {}
    for numero, ligne in enumerate(source.split("\n"), 1):
        ligne = ligne.split("#", 1)[0].strip()
        if m := re.match(r"(\w+)\s*:", ligne):
            if m[1].upper() in etiquettes:
                raise ErreurAssembleur(f"ligne {numero} : l'étiquette {m[1]} est déjà posée plus haut")
            etiquettes[m[1].upper()] = len(instructions)
            ligne = ligne[m.end():].strip()
        if not ligne:
            continue
        nom, *operandes = ligne.replace(",", " ").split()
        genre = INSTRUCTIONS.get(nom.lower())
        if genre is None:
            raise ErreurAssembleur(f"ligne {numero} : « {nom} » n'est pas une instruction connue ({', '.join(INSTRUCTIONS)})")
        if len(operandes) != 3:
            raise ErreurAssembleur(f"ligne {numero} : {nom.lower()} attend trois opérandes, pas {len(operandes)}")
        lus = []
        for g, o in zip(genre, operandes):
            if g == "r" and not (re.fullmatch(r"[rR][1-9]\d*", o) and int(o[1:]) <= REGISTRES):
                raise ErreurAssembleur(f"ligne {numero} : « {o} » n'est pas un registre (r1 à r{REGISTRES})")
            if g == "v" and not re.fullmatch(r"[+-]?\d+", o):
                raise ErreurAssembleur(f"ligne {numero} : « {o} » n'est pas un nombre entier")
            lus.append(int(o[1:]) if g == "r" else int(o) if g == "v" else o.upper())
        instructions.append((numero, nom.lower(), lus))
    for numero, nom, lus in instructions:
        if INSTRUCTIONS[nom][2] == "e" and lus[2] not in etiquettes:
            raise ErreurAssembleur(f"ligne {numero} : l'étiquette {lus[2]} n'est posée nulle part")
    return instructions, etiquettes


def derouler(programme, registres):
    """Exécute ``programme`` (``assembler``) sur ``registres`` (numéro -> valeur), qu'il modifie et rend."""
    instructions, etiquettes = programme
    i = pas = 0
    while i < len(instructions):
        if (pas := pas + 1) > PAS_MAX:
            raise ErreurAssembleur(f"le programme ne s'arrête pas : plus de {PAS_MAX} instructions exécutées "
                                   "(un saut qui revient toujours en arrière ?)")
        _, nom, (a, b, c) = instructions[i]
        i += 1
        if nom == "addi":
            registres[a] = registres[b] + c
        elif nom in ("add", "sub"):
            registres[a] = registres[b] + (registres[c] if nom == "add" else -registres[c])
        elif {"beq": registres[a] == registres[b], "bne": registres[a] != registres[b],
              "bgt": registres[a] > registres[b], "ble": registres[a] <= registres[b]}[nom]:
            i = etiquettes[c]
    return registres


def lire_registres(texte):
    """« r1 = 5, r2 = -7 » -> {1: 5, 2: -7} ; ValueError si le texte ne se lit pas ainsi."""
    paires = re.findall(r"[rR](\d+)\s*=\s*([+-]?\d+)", texte)
    if re.sub(r"[rR]\d+\s*=\s*[+-]?\d+|[\s,;]", "", texte) or any(not 1 <= int(n) <= REGISTRES for n, _ in paires):
        raise ValueError(f"« {texte} » : des registres r1 à r{REGISTRES} et leur valeur, « r1 = 5, r2 = 7 »")
    return {int(n): int(v) for n, v in paires}


def ecrire_registres(registres):
    return ", ".join(f"r{n} = {v}" for n, v in sorted(registres.items()))


def executer_assembleur(source, tests):
    """Chaque test part de registres à 0 sauf ceux de son ``appel`` (« r1 = 5, r2 = 7 »), déroule le programme de
    l'élève, et compare les registres que nomme ``attendu`` (« r1 = 7, r2 = 5 ») : les autres sont libres (un registre
    de travail comme r3). Un programme refusé à l'assemblage est une erreur, comme un SyntaxError en Python."""
    resultat = {"reussis": 0, "total": len(tests), "absents": 0, "messages": [], "erreur": None}
    if not source.strip():
        resultat["erreur"] = "aucune instruction écrite"
        return resultat
    try:
        programme = assembler(source)
    except ErreurAssembleur as exc:
        resultat["erreur"] = str(exc)
        return resultat
    for test in tests:
        try:
            depart, attendu = lire_registres(test["appel"]), lire_registres(test["attendu"])
        except ValueError as exc:
            resultat["messages"].append(f"test illisible dans le sujet : {exc}")
            continue
        try:
            fin = derouler(programme, {n: depart.get(n, 0) for n in range(1, REGISTRES + 1)})
        except ErreurAssembleur as exc:
            resultat["messages"].append(str(exc))
            continue
        fausses = {n: v for n, v in attendu.items() if fin[n] != v}
        if not fausses:
            resultat["reussis"] += 1
        else:
            resultat["messages"].append(test.get("message") or (
                f"en partant de {ecrire_registres(depart) or 'registres à 0'}, ton programme finit avec "
                f"{ecrire_registres({n: fin[n] for n in fausses})}, on attendait {ecrire_registres(fausses)}"))
    return resultat


def enfant():
    demande = json.loads(sys.stdin.read())
    sys.stdin = io.StringIO()  # un input() de l'élève lève EOFError au lieu d'attendre
    if demande.get("langage") == "sql":
        resultat = executer_sql(Path(demande["fichier"]).read_text(encoding="utf-8"),
                                jeu_sql(demande.get("base", ""), demande.get("prelude", "")),
                                demande.get("tests", []), demande.get("ordonne", False),
                                demande.get("colonnes_libres", False), demande.get("doublons_libres", False),
                                demande.get("controle", ""), demande.get("solution", ""))
    elif demande.get("langage") == "assembleur":
        resultat = executer_assembleur(Path(demande["fichier"]).read_text(encoding="utf-8"), demande.get("tests", []))
    else:
        resultat = executer(demande["fichier"], demande.get("tests", []), demande.get("tests_code", ""),
                            demande.get("classe", ""), demande.get("autorises"), demande.get("prelude", ""),
                            demande.get("premiere_ligne", 1), demande.get("effet", False), demande.get("observe", []),
                            demande.get("solution", ""), demande.get("forme", []), demande.get("fonction", ""),
                            demande.get("fichiers"), demande.get("mutants", []), demande.get("arborescence"),
                            demande.get("saisies", []), demande.get("erreur_attendue", ""), demande.get("contexte", ""))
    sys.__stdout__.write("\n" + MARQUE + json.dumps(resultat) + "\n")


# CÔTÉ PARENT -----------------------------------------------------------------------------------------------

def a_verifier(questions):
    """Les questions « code » et « sql » qui ont des tests, sous-questions de groupe comprises (``questions`` :
    celles d'un paquet élève ou d'une banque)."""
    return [f for q in questions for f in q.feuilles() if f.type in ("code", "sql") and f.testee()]


def verifier_question(q, dossier, fichier_defaut, python=sys.executable, classe=""):
    """{id, fichier, etat, points, obtenus, messages} ; etat : reussi, echec, erreur ou absent. ``classe`` fixe ce
    que le programme a le droit d'employer (bac_a_sable.programme), sauf si la question a sa propre liste."""
    return verifier_questions([(q, dossier, fichier_defaut, classe)], python)[0]


# Les messages de pyflakes que la correction traduit : (classe, gabarit) ; les autres restent en anglais
_PYFLAKES = {
    "UndefinedName": "le nom {0} n'est défini nulle part",
    "UndefinedLocal": "{0} est lu dans la fonction avant d'y recevoir une valeur",
    "UnusedVariable": "la variable {0} reçoit une valeur qui ne sert jamais",
    "UnusedImport": "{0} est importé mais ne sert jamais",
    "RedefinedWhileUnused": "{0} est redéfini (ligne {1}) avant d'avoir servi",
    "AssertTuple": "assert (condition, message) entre parenthèses est TOUJOURS vrai : écrire assert condition, message",
    "IsLiteral": "« is » compare des objets, pas des valeurs : écrire == pour comparer à une valeur",
    "ReturnOutsideFunction": "return hors d'une fonction",
    "FStringMissingPlaceholders": "f-string sans {{…}} : le f ne sert à rien",
    "DuplicateArgument": "le paramètre {0} est écrit deux fois",
}
_SNAKE = re.compile(r"_*[a-z][a-z0-9]*(?:_[a-z0-9]+)*_*")
_CONSTANTE = re.compile(r"_*[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)*")


def _noms_poses(code: str) -> set[str]:
    """Les noms que ``code`` (un prélude) pose au premier niveau : imports, fonctions, classes, cibles d'affectation."""
    try:
        corps = ast.parse(code).body
    except SyntaxError:
        return set()
    noms = set()
    for n in corps:
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            noms.update((a.asname or a.name).split(".")[0] for a in n.names)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            noms.add(n.name)
        else:
            noms.update(x.id for x in ast.walk(n) if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Store))
    return noms


def sans_lignes_fautives(source: str, maximum: int = 5) -> tuple[str, list[tuple[int, str]]]:
    """``source`` dont les lignes qui l'empêchent de compiler sont VIDÉES (les numéros de ligne restent ceux de l'élève),
    et [(ligne, message d'erreur)] de chaque ligne vidée. Un fichier de TP garde souvent l'erreur qu'un exercice
    demandait de provoquer (« print(hello world) ») : elle masquerait tout le reste. Au-delà de ``maximum`` lignes, ou
    sur une ligne vide (parenthèse jamais fermée plus haut…), ``source`` tel quel et []."""
    lignes, videes = source.splitlines(), []
    while True:
        try:
            with warnings.catch_warnings():  # « assert toujours vrai » : pyflakes le dit, en français
                warnings.simplefilter("ignore", SyntaxWarning)
                compile("\n".join(lignes), "<eleve>", "exec", dont_inherit=True)
            return ("\n".join(lignes) + "\n" if videes else source), videes
        except SyntaxError as exc:
            if not exc.lineno or exc.lineno > len(lignes) or not lignes[exc.lineno - 1].strip() or len(videes) >= maximum:
                return source, []
            videes.append((exc.lineno, exc.msg))
            lignes[exc.lineno - 1] = ""


def analyse_pyflakes(source: str, connus: set[str] = frozenset()) -> list[str]:
    """Ce que pyflakes trouve dans ``source`` sans l'exécuter, en français : nom jamais défini, variable inutile, assert
    toujours vrai… (l'utilisateur, 12/10/2026 : « utilise pyflakes ! »). ``connus`` : les noms que le prélude ou les tests
    fournissent, qui ne sont pas « jamais définis ». pyflakes est en Python pur (3.4, dans SmartPython) ; absent, rien.
    Les erreurs de syntaxe sont relevées ligne par ligne, et le reste du code analysé quand même (``sans_lignes_fautives``)."""
    try:
        from pyflakes import checker  # noqa: PLC0415
    except ImportError:
        return []
    texte, videes = sans_lignes_fautives(source)
    try:
        arbre = ast.parse(texte)
    except SyntaxError as exc:
        return [f"ligne {exc.lineno} : erreur de syntaxe ({exc.msg})"]
    remarques = [(ligne, f"erreur de syntaxe ({message})") for ligne, message in videes]
    for m in checker.Checker(arbre, builtins=set(connus)).messages:
        gabarit = _PYFLAKES.get(type(m).__name__)
        remarques.append((m.lineno, gabarit.format(*(m.message_args or ()), "", "") if gabarit else m.message % m.message_args))
    return [f"ligne {ligne} : {remarque}" for ligne, remarque in sorted(remarques, key=lambda r: r[0])]


def analyse_noms(source: str) -> list[str]:
    """Les noms de ``source`` contraires aux règles du cours (« Contraintes de nommage des variables », PEP 8,
    L'ESSENTIEL DU LANGAGE PYTHON, Première) que le texte seul permet de juger : lettres sans accents, snake_case pour
    les variables, fonctions et paramètres, MAJUSCULES réservées aux constantes (qui ne changent donc jamais de valeur),
    lettre seule réservée aux indices de boucle. « Un nom explicite, sans abréviation » demande de comprendre le code :
    c'est au conseil du modèle d'en juger (``contrat_jugement.SYSTEME_CONSEIL``, sans point). Une remarque par nom, à sa première apparition ; les classes, en
    CamelCase, et les noms imposés (« _ », __dunder__) ne sont pas jugés. Une ligne qui ne compile pas n'empêche pas
    de juger les autres."""
    return [f"ligne {ligne} : {genre} {nom} {faute}" for ligne, genre, nom, faute in _jugement_noms(source)[0] if faute]


def _jugement_noms(source: str) -> tuple[list[tuple[int, str, str, str]], set[str]]:
    """Les noms que pose ``source``, ``(ligne, genre, nom, faute)`` dans l'ordre des lignes, ``faute`` "" pour un nom
    conforme (``analyse_noms``), et ses indices de boucle (``noms_obscurs``)."""
    try:
        arbre = ast.parse(sans_lignes_fautives(source)[0])
    except SyntaxError:
        return [], set()
    poses, boucles, affectations = {}, set(), {}  # nom -> (ligne, genre) ; indices de boucle ; nom -> nombre d'écritures
    for n in ast.walk(arbre):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            poses.setdefault(n.name, (n.lineno, "la fonction"))
            for a in [*n.args.posonlyargs, *n.args.args, *n.args.kwonlyargs, n.args.vararg, n.args.kwarg]:
                if a is not None:
                    poses.setdefault(a.arg, (a.lineno, "le paramètre"))
        elif isinstance(n, (ast.For, ast.AsyncFor, ast.comprehension)):
            boucles.update(x.id for x in ast.walk(n.target) if isinstance(x, ast.Name))
        elif isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
            poses.setdefault(n.id, (n.lineno, "la variable"))
            affectations[n.id] = affectations.get(n.id, 0) + 1
        elif isinstance(n, ast.AugAssign) and isinstance(n.target, ast.Name):
            affectations[n.target.id] = affectations.get(n.target.id, 0) + 1
        elif isinstance(n, ast.Lambda):
            boucles.update(a.arg for a in n.args.args)  # « contextes très courts »
    noms = []
    for nom, (ligne, genre) in sorted(poses.items(), key=lambda p: p[1][0]):
        if nom == "_" or nom.startswith("__") and nom.endswith("__"):
            continue
        if not nom.isascii():
            faute = "contient un accent ou une lettre hors de a → z"
        elif _CONSTANTE.fullmatch(nom) and len(nom.strip("_")) > 1 and genre == "la variable":
            faute = ("est en MAJUSCULES, réservées aux constantes, mais change de valeur"
                     if affectations.get(nom, 0) > 1 or nom in boucles else "")
        elif not _SNAKE.fullmatch(nom):
            faute = "doit s'écrire en snake_case : tout en minuscules, mots séparés par _"
        elif len(nom.strip("_")) == 1 and nom not in boucles:
            faute = "est une lettre seule, réservée aux indices de boucle : un nom explicite dit ce qu'il contient"
        else:
            faute = ""
        noms.append((ligne, genre, nom, faute))
    return noms, boucles


# un nom que le modèle juge non explicite (``noyau.Code.noms_au_modele``, ``noms_obscurs``)
OBSCUR = "ne dit pas ce qu'il contient : un nom explicite, sans abréviation"


def noms_obscurs(source: str, obscurs: tuple[str, ...] | list[str], cites: str = "") -> list[str]:
    """Les remarques « ligne N : la variable x ne dit pas… » des noms d'``obscurs`` (ceux que le modèle juge non
    explicites, ``contrat_jugement.SYSTEME_CONSEIL_NOMS``) que l'algorithme retient : un nom que ``source`` pose, qui
    n'est ni un indice de boucle, ni déjà fautif pour ``analyse_noms`` (compté une fois), ni cité par ``cites`` (énoncé,
    tests, solution, code donné : l'élève devait le reprendre). Un nom absent du code, inventé par le modèle, n'est
    rien : le modèle ne fait que proposer (l'utilisateur, 18/10/2026 : noter « à partir d'un retour du modèle », par
    question)."""
    fixes = set(re.findall(r"[A-Za-z_]\w*", cites))
    voulus = {n for n in obscurs if isinstance(n, str)} - fixes
    poses, boucles = _jugement_noms(source)
    return [f"ligne {ligne} : {genre} {nom} {OBSCUR}" for ligne, genre, nom, faute in poses
            if nom in voulus and nom not in boucles and not faute]


# par faute de nommage nouvelle, la part des points retirée ; au plus, par question, sauf plafond du sujet
# (``DefinitionSujet.plafond_nommage``, un exercice qui exige PEP 8) : malus plafonné à 10 % (l'utilisateur, 16/10/2026)
PENALITE_NOM, PLAFOND_NOMS = 0.1, 0.1


@functools.lru_cache(1024)
def fautes_de_nommage(source: str) -> frozenset[str]:
    """Les fautes d'``analyse_noms`` sans leur ligne (« la variable Total doit… ») : la même d'une question à l'autre."""
    return frozenset(r.partition(" : ")[2] for r in analyse_noms(source))


@functools.lru_cache(256)
def relecture(source: str, connus: frozenset[str] = frozenset(), deja: frozenset[str] = frozenset(),
              imposes: tuple[str, ...] = (), plafond: float | None = None, obscurs: tuple[str, ...] = (),
              cites: str = "") -> tuple[float, list[str]]:
    """(pénalité, remarques) : la relecture de ``source`` (pyflakes, puis règles de nommage) et la part des points que
    ses fautes de nommage retirent. Seule la question où une faute apparaît la première fois la paie (``deja`` : celles
    des questions d'avant) ; celles du code donné (``imposes`` : solution, code initial) ne sont ni comptées ni dites
    (l'utilisateur, 12/10/2026 : « le respect des règles de nommage du cours doivent compter dans la note de la
    première question concernée (mais pas se recompter à chaque question) »). ``plafond`` : celui du sujet, None pour
    ``PLAFOND_NOMS``. ``obscurs`` : les noms que le modèle juge non explicites (``noms_obscurs``, ``cites`` et
    ``imposes`` les noms qu'il ne peut pas reprocher), comptés comme les autres fautes, sous le même plafond."""
    exclues = frozenset().union(*map(fautes_de_nommage, imposes))
    remarques, nouvelles = analyse_pyflakes(source, connus), 0
    for r in analyse_noms(source):
        faute = r.partition(" : ")[2]
        if faute not in exclues:
            nouvelles += faute not in deja
            remarques.append(r + (" (déjà compté plus haut)" if faute in deja else " (compté dans la note)"))
    for r in noms_obscurs(source, obscurs, "\n".join([cites, *imposes])) if obscurs else ():
        faute = r.partition(" : ")[2]
        nouvelles += faute not in deja
        remarques.append(r + (" (déjà compté plus haut)" if faute in deja else " (compté dans la note, avis du modèle)"))
    return min(PLAFOND_NOMS if plafond is None else plafond, PENALITE_NOM * nouvelles), remarques


def variantes_python(texte, solution, donne=""):
    """Le pendant de ``localiser_sql`` pour un programme, côté parent (l'enfant ne s'exécute qu'une fois : bac_a_sable
    pose un crochet d'audit qu'on ne retire pas) : chaque façon de remplacer une ou deux fonctions de ``texte`` par celles
    de même nom de ``solution``, ``(n, [(noms, fautes, variante)])``, une partie avant deux, ``n`` le nombre de
    fonctions de ``texte`` que la solution définit aussi, hors celles que ``donne`` (le code de départ) fournit déjà
    telles quelles : comme un FROM d'une table que l'énoncé nomme, les recopier ne rapporte rien. Rien si ``texte`` a moins de deux
    fonctions communes avec la solution : remplacer l'unique fonction ne localiserait rien. ``fautes`` : les (début, fin)
    des fonctions remplacées, décorateurs compris, dans ``texte``."""
    import itertools  # noqa: PLC0415

    def fonctions(source):
        try:
            arbre = ast.parse(source)
        except SyntaxError:
            return {}
        debuts = [0, *itertools.accumulate(len(ligne) for ligne in source.splitlines(keepends=True))]
        return {n.name: (debuts[min(d.lineno for d in [n, *n.decorator_list]) - 1], debuts[n.end_lineno])
                for n in arbre.body if isinstance(n, ast.FunctionDef | ast.AsyncFunctionDef)}

    eleve, attendue, fournies = fonctions(texte), fonctions(solution), fonctions(donne)
    communes = [nom for nom in eleve if nom in attendue
                and texte[slice(*eleve[nom])].strip() != solution[slice(*attendue[nom])].strip()]
    if len(set(eleve) & set(attendue)) < 2:
        return 0, []
    variantes = []
    for taille in (1, 2):
        for noms in itertools.combinations(communes, taille):
            if len(noms) < len(eleve):
                variante = texte
                for nom in sorted(noms, key=lambda n: -eleve[n][0]):  # de la fin vers le début : les positions tiennent
                    a, b = eleve[nom]
                    variante = variante[:a] + solution[slice(*attendue[nom])].rstrip("\n") + "\n" + variante[b:]
                fautes = [(eleve[n][0], eleve[n][0] + len(texte[slice(*eleve[n])].rstrip())) for n in noms]
                variantes.append((noms, fautes, variante))
    return len({nom for nom in set(eleve) & set(attendue)
                if nom not in fournies or texte[slice(*eleve[nom])].strip() != donne[slice(*fournies[nom])].strip()}), variantes


def _jetons_noms(code: str) -> "list[tuple[tokenize.TokenInfo, bool]] | None":
    """Les jetons de ``code`` (tokenize : noms, opérateurs, nombres, chaînes), chacun avec vrai s'il est un nom libre
    (ni mot clé, ni builtin, ni attribut après un point) ; None si ``code`` ne se découpe pas."""
    import keyword  # noqa: PLC0415
    import tokenize  # noqa: PLC0415

    fixes = set(dir(builtins)) | set(keyword.kwlist) | set(keyword.softkwlist)
    try:
        liste = [t for t in tokenize.generate_tokens(io.StringIO(code).readline) if t.type in (tokenize.NAME, tokenize.OP,
                 tokenize.NUMBER, tokenize.STRING)]
    except (tokenize.TokenError, SyntaxError):
        return None
    return [(t, t.type == tokenize.NAME and t.string not in fixes and (i == 0 or liste[i - 1].string != "."))
            for i, t in enumerate(liste)]


def table_des_noms(texte: str, solution: str, bijective: bool = False) -> dict[str, str]:
    """Les noms de ``solution`` que ``texte`` renomme, {nom du corrigé : nom de l'élève} : les deux programmes découpés
    (``_jetons_noms``), chaque nom libre ramené à un même jeton, alignés (difflib) ; deux noms alignés votent pour leur
    correspondance, la plus votée l'emporte, une par nom de chaque côté. ``bijective`` (Superviseur, 18/10/2026, pour
    ``contrat_jugement.ecart_noms``) : seulement les noms qui n'ont voté pour aucun autre, un élève qui écrit ``x`` à la
    place de ``total`` et de ``i`` n'a pas renommé, il a confondu."""
    import difflib  # noqa: PLC0415
    from collections import Counter  # noqa: PLC0415

    a, b = _jetons_noms(texte), _jetons_noms(solution)
    if not a or not b:
        return {}
    votes: Counter[tuple[str, str]] = Counter()
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, ["\0" if l else t.string for t, l in a],
                                                      ["\0" if l else t.string for t, l in b], autojunk=False).get_opcodes():
        if op == "equal" or (op == "replace" and i2 - i1 == j2 - j1):
            votes.update((tb.string, ta.string) for (ta, la), (tb, lb) in zip(a[i1:i2], b[j1:j2]) if la and lb)
    table: dict[str, str] = {}
    for (voulu, ecrit), _ in votes.most_common():
        if voulu not in table and ecrit not in table.values():
            table[voulu] = ecrit
    if bijective:
        table = {v: e for v, e in table.items() if all((w == v) == (f == e) for w, f in votes)}
    libres = {t.string for t, l in b if l}
    return {v: e for v, e in table.items() if v != e and (e not in libres or e in table)}  # sans confondre deux noms


def solution_aux_noms(texte: str, solution: str) -> str:
    """``solution`` récrite avec les noms de variables de ``texte`` (``table_des_noms`` ; l'utilisateur, 14/10/2026, d'un
    élève qui a ses propres noms et une seule ligne fausse, sans aucun point partiel : « ça ne va pas du tout »).
    ``solution`` telle quelle si rien ne se renomme ou si l'un des deux ne se découpe pas. Les tests restent seuls juges :
    un renommage faux ne rend qu'une variante de plus qui échoue."""
    table = table_des_noms(texte, solution)
    if not table:
        return solution
    lignes = solution.splitlines(keepends=True)
    for t, _ in sorted((j for j in _jetons_noms(solution) if j[1] and j[0].string in table), key=lambda j: j[0].start,
                       reverse=True):
        n, c = t.start
        lignes[n - 1] = lignes[n - 1][:c] + table[t.string] + lignes[n - 1][c + len(t.string):]
    return "".join(lignes)


def _compacte(ligne: str) -> str:
    """``ligne`` (sans son indentation) sans ses blancs hors chaîne, sauf entre deux caractères de mot : une différence
    d'espaces n'est pas une faute (Superviseur, 16/10/2026), « def__init__ » contre « def __init__ » en reste une."""
    sortie, guillemet = [], ""
    for n, c in enumerate(ligne):
        if guillemet:
            if c == guillemet and ligne[n - 1] != "\\":
                guillemet = ""
        elif c in "'\"":
            guillemet = c
        elif c in " \t":
            suite = ligne[n:].lstrip(" \t")[:1]
            if not (sortie and (sortie[-1].isalnum() or sortie[-1] == "_") and (suite.isalnum() or suite == "_")):
                continue
            if sortie[-1] == " ":
                continue
            c = " "
        sortie.append(c)
    return "".join(sortie)


def _entre_mots(ligne: str, a: int, b: int) -> bool:
    """``ligne[a:b]`` est bordé de deux caractères de mot : un blanc ôté ou ajouté là change le sens (``_compacte``)."""
    mot = lambda n: 0 <= n < len(ligne) and (ligne[n].isalnum() or ligne[n] == "_")  # noqa: E731
    return mot(a - 1) and mot(b)


def _niveaux(texte: str) -> dict[int, int] | None:
    """La profondeur de bloc de chaque ligne de ``texte`` (base 0) qui commence une instruction, au sens de Python
    (INDENT/DEDENT de tokenize) : le niveau compte, pas la largeur (cinq espaces au lieu de huit au même niveau ne sont
    pas une faute, un bloc imbriqué sous un ``if`` de trop en est une). None si ``texte`` ne se découpe pas."""
    import tokenize  # noqa: PLC0415

    niveaux, profondeur = {}, 0
    try:
        for t in tokenize.generate_tokens(io.StringIO(texte).readline):
            if t.type == tokenize.INDENT:
                profondeur += 1
            elif t.type == tokenize.DEDENT:
                profondeur -= 1
            elif t.type not in (tokenize.NL, tokenize.NEWLINE, tokenize.COMMENT, tokenize.ENDMARKER):
                niveaux.setdefault(t.start[0] - 1, profondeur)
    except (tokenize.TokenError, SyntaxError):
        return None
    return niveaux


def _retouches_lignes(texte: str, solution: str, commentaires: bool = False, rognees: list | None = None) -> list[tuple[int, int, list[str], list[tuple[int, int]], list[tuple[int, str]]]]:
    """Les retouches de ``variantes_lignes`` qui mènent de ``texte`` à ``solution``, commentaires compris quand
    ``commentaires`` (des tests qui lisent le source : une faute peut n'être que dans un commentaire). ``rognees`` : une
    liste à laquelle ajouter, pour chaque bloc qui remplace plus de lignes qu'il n'en met, ce bloc gardant une ou deux de
    ses lignes ; elles chevauchent les retouches rendues, à ne pas appliquer avec elles."""
    import difflib  # noqa: PLC0415
    import itertools  # noqa: PLC0415

    lignes, attendues = texte.splitlines(keepends=True), solution.splitlines()
    debuts = [0, *itertools.accumulate(len(ligne) for ligne in lignes)]
    nettoyer = (lambda ligne: ligne.rstrip("\n")) if commentaires else sans_commentaire
    # les commentaires (sauf ``commentaires``) et les lignes vides hors de l'alignement, des deux côtés : un commentaire
    # de l'élève n'est pas une faute, ni l'absence de ceux de la solution (l'utilisateur, 15/10/2026 : « pourquoi
    # barres-tu des commentaires ? »)
    code = [i for i, l in enumerate(lignes) if nettoyer(l).strip()]
    voulues = [j for j, l in enumerate(attendues) if nettoyer(l).strip()]
    attendues = [nettoyer(l).rstrip() for l in attendues]
    # l'alignement ignore les espaces (``_compacte``) mais pas l'indentation : son niveau (``_niveaux``), ou sa largeur si
    # l'un des deux programmes ne se découpe pas (une ligne sortie de sa boucle est une faute de logique)
    niveaux = (_niveaux(texte), _niveaux(solution))
    if None in niveaux:
        niveaux = [{n: len(l.expandtabs(4)) - len(l.expandtabs(4).lstrip()) for n, l in enumerate(t)} for t in (lignes, attendues)]
    retrait_e, retrait_v = (lambda i: niveaux[0].get(i, "")), (lambda j: niveaux[1].get(j, ""))
    ecrites = [f"{retrait_e(i)}|{_compacte(nettoyer(lignes[i]).strip())}" for i in code]
    operations = difflib.SequenceMatcher(None, ecrites, [f"{retrait_v(j)}|{_compacte(attendues[j].strip())}" for j in voulues],
                                         autojunk=False).get_opcodes()
    # une ligne écrite deux fois à la place d'une autre (retirer(20) deux fois, la solution retirer(100) puis retirer(20)) :
    # difflib l'aligne en insertion + égalité + suppression ; c'est un remplacement, à l'endroit où l'ordre le veut
    # (Superviseur, 16/10/2026, copies d'un TP), dès que le bloc égal se retrouve tel quel décalé d'autant. Le symétrique
    # (suppression, égalité, insertion) ne sort pas de difflib, qui prend le bloc égal le plus tôt dans ``ecrites``
    n = 0
    while n < len(operations) - 2:
        (o1, _, _, b1, b2), (o2, c1, c2, d1, d2), (o3, e1, e2, _, _) = operations[n:n + 3]
        taille = b2 - b1
        if (o1, o2, o3) == ("insert", "equal", "delete") and e2 - e1 == taille and ecrites[c1:c2] == ecrites[c1 + taille:e2]:
            operations[n:n + 3] = [("replace", c1, c1 + taille, b1, b2), ("equal", c1 + taille, e2, d1, d2)]
        n += 1

    def a_ecrire(j: int, remplacees: list[int], dessus: int) -> str:
        """La ligne voulue ``j`` dans la largeur de l'élève pour son niveau : celle d'une ligne remplacée de même niveau,
        sinon de la plus proche au-dessus, à défaut celle de la solution. Une ligne égale garde sa largeur : écrite dans
        celle de la solution à côté d'elle, la variante mêlait 12 et 8 espaces au même niveau (IndentationError, rien ne
        passait). Python n'exige l'égalité qu'au retour à un niveau déjà ouvert : un bloc neuf peut prendre toute largeur."""
        voulu = attendues[j]
        for i in (*remplacees, *range(dessus - 1, -1, -1)):
            if i in code and retrait_e(i) == retrait_v(j):
                return lignes[i][:len(lignes[i]) - len(lignes[i].lstrip(" \t"))] + voulu.lstrip(" \t")
        return voulu

    def ligne_a_ligne(i: int, j: int) -> tuple[int, int, list[str], list[tuple[int, int]], list[tuple[int, str]]]:
        """La ligne ``i`` de l'élève remplacée par la ligne voulue ``j`` : seuls les caractères qui diffèrent sont fautifs."""
        voulu = a_ecrire(j, [i], i)  # sa propre largeur d'abord, puis celle des lignes au-dessus
        ecrit = nettoyer(lignes[i]).rstrip()
        # le texte d'un commentaire ne se compare pas lettre à lettre (« #jsp » contre « # longueur… » rayait j et p,
        # pas s) : le code de la ligne lettre à lettre, puis son commentaire en entier s'il diffère
        e, v = (sans_commentaire(ecrit), sans_commentaire(voulu)) if commentaires else (ecrit, voulu)
        # un littéral faux se raye en entier, pas lettre à lettre (l'utilisateur, 16/10/2026 : « je ne veux pas que
        # tu corrige letre par lettre si l'élève s'est juste trompé de prenom ») ; opérateurs et noms, lettre à lettre
        # des blancs seuls ne sont pas une faute ; l'indentation, si son niveau diffère, en est une, à elle seule
        tete = len(ecrit) - len(ecrit.lstrip(" \t"))
        fautes = [(debuts[i], debuts[i] + tete)] * (retrait_e(i) != retrait_v(j))
        fautes += [(debuts[i] + a1, debuts[i] + a2) for a1, a2 in _fautes_texte(e, v)]
        if ecrit[len(e):].strip() != voulu[len(v):].strip():
            fautes.append((debuts[i] + len(e), debuts[i] + len(ecrit)))
        return i, i + 1, [voulu], fautes, [(i + 1, voulu)]

    def bloc(ks: list[int], m1: int, m2: int) -> tuple[int, int, list[str], list[tuple[int, int]], list[tuple[int, str]]]:
        """Les lignes de code ``ks`` de l'élève remplacées en bloc par les lignes voulues ``m1:m2`` : rayées en entier."""
        a_mettre = [a_ecrire(j, ks, ks[0]) for j in voulues[m1:m2]]
        i1, i2 = ks[0], ks[-1] + 1
        fautes = [(debuts[i] + len(lignes[i]) - len(lignes[i].lstrip()), debuts[i] + len(nettoyer(lignes[i]).rstrip())) for i in ks]
        return i1, i2, a_mettre, fautes, [(i2, l) for l in a_mettre] or [(i2, "")]

    retouches = []  # (première ligne remplacée, dernière exclue, lignes à mettre, fautes, corrections)
    for op, k1, k2, m1, m2 in operations:
        if op == "equal":
            continue
        if op == "replace" and k2 - k1 == m2 - m1:  # ligne à ligne : seuls les caractères qui diffèrent sont fautifs
            retouches.extend(ligne_a_ligne(i, j) for i, j in zip(code[k1:k2], voulues[m1:m2]))
            continue
        if k1 == k2:  # lignes manquantes : un signe d'insertion au début de la ligne de code qui aurait dû les suivre
            a_mettre = [a_ecrire(j, [], code[k1] if k1 < len(code) else len(lignes)) for j in voulues[m1:m2]]
            # en fin de programme : sous la dernière ligne de code, pas après les lignes vides finales (16/10/2026)
            i1 = code[k1] if k1 < len(code) else code[-1] + 1 if code else len(lignes)
            p = debuts[i1] + (len(lignes[i1]) - len(lignes[i1].lstrip(" \t")) if i1 < len(lignes) else 0)
            retouches.append((i1, i1, a_mettre, [(p, p)], [(max(i1, 1), l) for l in a_mettre]))
            continue
        retouches.append(bloc(code[k1:k2], m1, m2))
        # plus de lignes écrites que voulues : le même bloc qui garde une ou deux de ses lignes en tête ou en queue (la
        # ligne donnée par l'énoncé, que la ligne voulue remplaçait avec la ligne fausse, tp07_ex09), un remplacement
        # ligne à ligne s'il en reste autant que de voulues. Une ligne gardée n'est plus désignée : c'est aux tests de dire
        # si elle peut l'être (l'utilisateur, 19/10/2026 : « mais on devrait avoir zero lignes barrées à tord ! »)
        if rognees is not None and 0 < m2 - m1 < k2 - k1:
            en_trop = min(k2 - k1 - (m2 - m1), 2)
            for t, u in ((t, u) for t in range(en_trop + 1) for u in range(en_trop + 1 - t) if t + u):
                ks = code[k1 + t:k2 - u]
                if len(ks) != m2 - m1:
                    rognees.append(bloc(ks, m1, m2))
                    continue
                parts = {i: ligne_a_ligne(i, j) for i, j in zip(ks, voulues[m1:m2])}
                rognees.append((ks[0], ks[-1] + 1, [parts[i][2][0] if i in parts else lignes[i].rstrip("\n") for i in range(ks[0], ks[-1] + 1)],
                                [f for p in parts.values() for f in p[3]], [c for p in parts.values() for c in p[4]]))
    return retouches


def _litteraux(ligne: str) -> list[tuple[int, int]]:
    """Les (début, fin) des chaînes (guillemets compris, repérées comme dans ``sans_commentaire``) et des nombres de
    ``ligne`` : une ligne seule ne s'analyse pas toujours (``ast``), d'où ce repérage à la main."""
    bornes, guillemet, debut = [], "", 0
    for n, c in enumerate(ligne):
        if guillemet:
            if c == guillemet and ligne[n - 1] != "\\":
                guillemet = ""
                bornes.append((debut, n + 1))
        elif c in "'\"":
            guillemet, debut = c, n
        elif c == "#":
            break
    hors = "".join(" " if any(a <= n < b for a, b in bornes) else c for n, c in enumerate(ligne))
    bornes += [m.span() for m in re.finditer(r"(?<![\w.])(?:\d[\d_]*\.?\d*|\.\d+)(?:[eE][+-]?\d+)?j?(?![\w.])", hors.split("#")[0])]
    return sorted(bornes)


def _au_litteral_entier(ligne: str, fautes: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """``fautes``, des (début, fin) dans ``ligne``, chacune étendue au littéral qu'elle touche (``_litteraux``), sans
    doublon : « Grace » écrit « Alan » raye le mot, pas A et n."""
    etendues = []
    for a, b in fautes:
        for c, d in _litteraux(ligne):
            if (a < d and b > c) if a < b else c < a < d:
                a, b = min(a, c), max(b, d)
        if (a, b) not in etendues:
            etendues.append((a, b))
    return etendues


def sans_commentaire(ligne: str) -> str:
    """La ligne sans son commentaire : le ``#`` hors des chaînes et ce qui le suit (une chaîne sur plusieurs lignes n'est
    pas suivie : son ``#`` passe pour un commentaire, une ligne de plus ou de moins à aligner, sans plus)."""
    guillemet = ""
    for n, c in enumerate(ligne):
        if guillemet:
            if c == guillemet and ligne[n - 1] != "\\":
                guillemet = ""
        elif c in "'\"":
            guillemet = c
        elif c == "#":
            return ligne[:n]
    return ligne.rstrip("\n")


def _fautes_texte(e: str, v: str) -> list[tuple[int, int]]:
    """Les (début, fin) dans ``e`` des caractères qui diffèrent de ``v`` : des blancs seuls ne sont pas une faute, sauf entre
    deux caractères de mot ; un littéral faux se raye en entier (``_au_litteral_entier``)."""
    import difflib  # noqa: PLC0415

    return _au_litteral_entier(e, [(a1, a2) for o, a1, a2, b1, b2 in difflib.SequenceMatcher(None, e.rstrip(), v.rstrip(), autojunk=False).get_opcodes()
                                   if o != "equal" and (e[a1:a2].strip() or v[b1:b2].strip() or _entre_mots(e, a1, a2) or _entre_mots(v, b1, b2))])


_CORPS = ("body", "orelse", "handlers", "finalbody")
_COMPOSEES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.For, ast.AsyncFor, ast.While, ast.If, ast.With, ast.AsyncWith)


def _sans_corps(s: ast.stmt, corps: list[ast.stmt] | None = None) -> ast.stmt:
    """L'en-tête d'une instruction composée (``for … :``) : ``s`` sans ses corps, ``corps`` à la place du premier."""
    return ast.copy_location(type(s)(**{c: (corps or [] if c == "body" else [] if c in _CORPS else getattr(s, c)) for c in s._fields}), s)


def _fin_entete(s: ast.stmt) -> int:
    """La dernière ligne (base 1) de l'en-tête de ``s``, décorateurs exclus."""
    return max([s.lineno, *(n.end_lineno for c in s._fields if c not in _CORPS and c != "decorator_list"
                            for v in (getattr(s, c) if isinstance(getattr(s, c), list) else [getattr(s, c)]) if isinstance(v, ast.AST)
                            for n in ast.walk(v) if getattr(n, "end_lineno", None))])


def _cle(s: ast.stmt) -> str:
    """Le genre d'une instruction, pour apparier celles qui diffèrent : son type, et la fonction appelée d'un appel seul
    (un print ne s'apparie pas à un append)."""
    if isinstance(s, ast.Expr) and isinstance(s.value, ast.Call):
        return "Expr:" + ast.unparse(s.value.func)
    return type(s).__name__


def _ecarts_noeuds(a: ast.AST, b: ast.AST) -> list[tuple[ast.AST, ast.AST]]:
    """Les plus petits sous-nœuds de ``a`` qui diffèrent de ceux de ``b`` à la même place : tant que deux nœuds ont même
    type, mêmes champs simples (nom, valeur, opérateur) et listes de même longueur, on descend ; sinon c'est là."""
    if ast.dump(a) == ast.dump(b):
        return []
    if type(a) is not type(b):
        return [(a, b)]
    enfants = []
    for c in a._fields:
        x, y = getattr(a, c), getattr(b, c)
        if isinstance(x, ast.AST) and isinstance(y, ast.AST):
            if not hasattr(x, "lineno"):  # opérateur, contexte : un champ simple
                if ast.dump(x) != ast.dump(y):
                    return [(a, b)]
                continue
            enfants.append((x, y))
        elif isinstance(x, list) and isinstance(y, list):
            if len(x) != len(y):
                return [(a, b)]
            for u, w in zip(x, y):
                if isinstance(u, ast.AST) and isinstance(w, ast.AST) and hasattr(u, "lineno"):
                    enfants.append((u, w))
                elif (ast.dump(u) if isinstance(u, ast.AST) else u) != (ast.dump(w) if isinstance(w, ast.AST) else w):
                    return [(a, b)]
        elif x != y:
            return [(a, b)]
    return [p for u, w in enfants for p in _ecarts_noeuds(u, w)] or [(a, b)]


def _retouches_ast(texte: str, solution: str) -> list[tuple[int, int, list[str], list[tuple[int, int]], list[tuple[int, str]]]]:
    """Les retouches de ``_retouches_lignes``, alignées sur les instructions plutôt que sur les lignes (TODO « Correction du
    code ligne à ligne », A1) : ``texte`` et la solution dans ses noms (``solution_aux_noms``) relus par ``ast``, une
    instruction différente remplacée par celle de la solution, ses lignes prises de ``lineno``/``end_lineno``. Une
    instruction sur plusieurs lignes, des parenthèses ou des guillemets en plus ne sont donc pas des fautes, ni un
    commentaire ; d'une instruction composée (``if``, ``for``, ``def``…) seule la tête est remplacée, son corps aligné à
    son tour ; seuls les plus petits sous-nœuds qui diffèrent sont rayés (``_ecarts_noeuds``). Le texte mis est celui de la
    solution (ses guillemets, ses parenthèses), ``ast.unparse`` seulement s'il partage ses lignes avec une autre
    instruction : unparse rend ``if a > 0 and b > 0 and (c > 0):``. L'alignement ne juge rien : chaque variante passe
    les tests ou non. ``[]`` si l'un des deux ne se lit pas, ou si deux instructions partagent une ligne."""
    import difflib  # noqa: PLC0415
    import itertools  # noqa: PLC0415

    try:
        source = solution_aux_noms(texte, solution)
        arbre, voulu = ast.parse(texte), ast.parse(source)
    except SyntaxError:
        return []
    for n in ast.walk(arbre):  # deux instructions sur une ligne (« a = 1; b = 2 ») : les lignes ne les séparent pas
        for c in _CORPS:
            # le corps d'une lambda ou d'un ternaire (« 1 if a else 2 ») est une expression, pas une suite d'instructions
            suite = [s for s in x if isinstance(s, ast.stmt)] if isinstance(x := getattr(n, c, []), list) else []
            if any(s.lineno == r.end_lineno for r, s in zip(suite, suite[1:])):
                return []
    lignes, lignes_source = texte.splitlines(keepends=True), source.splitlines()
    debuts = [0, *itertools.accumulate(len(ligne) for ligne in lignes)]
    sans_docstring = lambda corps: [s for s in corps if not (isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant) and isinstance(s.value.value, str))]  # noqa: E731
    dumps = lambda noeuds: [ast.dump(x) for x in noeuds]  # noqa: E731

    def colonne(ligne: str, octets: int) -> int:  # ast compte les colonnes en octets UTF-8
        return len(ligne.encode()[:octets].decode(errors="ignore"))

    def retrait(s: ast.stmt) -> str:
        ligne = lignes[s.lineno - 1]
        return ligne[:len(ligne) - len(ligne.lstrip(" \t"))]

    def premiere(s: ast.stmt) -> int:  # base 0, décorateurs compris
        return min(d.lineno for d in [s, *getattr(s, "decorator_list", [])]) - 1

    def ecrit(t: ast.stmt, entete: bool = False) -> list[str]:
        """Les lignes de ``t`` telles que la solution les écrit, sans leur retrait ; ``ast.unparse`` en repli."""
        bloc = lignes_source[t.lineno - 1 if entete else premiere(t):_fin_entete(t) if entete else t.end_lineno]
        avant = lignes_source[t.lineno - 1][:colonne(lignes_source[t.lineno - 1], t.col_offset)]
        apres = sans_commentaire(lignes_source[t.end_lineno - 1][colonne(lignes_source[t.end_lineno - 1], t.end_col_offset):])
        if avant.strip() or (apres.strip() if not entete else not sans_commentaire(bloc[-1]).rstrip().endswith(":")):
            return (ast.unparse(_sans_corps(t, [ast.Pass()])).splitlines()[-2:-1] if entete else ast.unparse(t).splitlines())
        return [ligne[len(avant):] if not ligne[:len(avant)].strip() else ligne.lstrip() for ligne in bloc]

    def lignes_entieres(i1: int, i2: int) -> list[tuple[int, int]]:  # leurs commentaires exclus
        return [(debuts[i] + len(lignes[i]) - len(lignes[i].lstrip()), debuts[i] + len(sans_commentaire(lignes[i]).rstrip()))
                for i in range(i1, i2) if sans_commentaire(lignes[i]).strip()]

    def fautes_noeud(s: ast.AST, t: ast.AST) -> list[tuple[int, int]]:
        fautes = []
        for u, w in _ecarts_noeuds(s, t):
            if u.lineno != u.end_lineno:
                fautes += lignes_entieres(u.lineno - 1, u.end_lineno)
                continue
            d = debuts[u.lineno - 1] + colonne(lignes[u.lineno - 1], u.col_offset)
            ecrit_u = texte[d:debuts[u.lineno - 1] + colonne(lignes[u.lineno - 1], u.end_col_offset)]
            fautes += [(d + a, d + b) for a, b in _fautes_texte(ecrit_u, ast.get_source_segment(source, w) or ast.unparse(w))]
        return fautes

    retouches = []  # (première ligne remplacée, dernière exclue, lignes à mettre, fautes, corrections)

    def remplacer(s: ast.stmt, t: ast.stmt, entete: bool = False) -> None:
        i1, i2 = (s.lineno - 1, _fin_entete(s)) if entete else (premiere(s), s.end_lineno)
        mises = [retrait(s) + ligne for ligne in ecrit(t, entete)]
        if i2 - i1 == 1 and len(mises) == 1:
            fautes = fautes_noeud(_sans_corps(s), _sans_corps(t)) if entete else fautes_noeud(s, t)
            ligne = [(debuts[i1] + a, debuts[i1] + b) for a, b in _fautes_texte(lignes[i1].rstrip("\r\n"), mises[0])]
            # les sous-nœuds s'apparient mal quand l'un contient l'autre (« total + i » pour « total + i + 1 ») : le moins rayé
            fautes = min(fautes, ligne, key=lambda f: (sum(b - a for a, b in f), len(f)))
            retouches.append((i1, i2, mises, fautes, [(i1 + 1, mises[0])]))
        else:
            retouches.append((i1, i2, mises, lignes_entieres(i1, i2), [(i2, ligne) for ligne in mises]))

    def est_elif(n: ast.stmt, texte_lignes: list[str]) -> bool:
        return isinstance(n, ast.If) and len(n.orelse) == 1 and isinstance(n.orelse[0], ast.If) \
            and texte_lignes[n.orelse[0].lineno - 1].lstrip().startswith("elif")

    def modifier(s: ast.stmt, t: ast.stmt) -> None:
        sinon_s, sinon_t = getattr(s, "orelse", []), getattr(t, "orelse", [])
        if (not isinstance(s, _COMPOSEES) or not isinstance(t, _COMPOSEES)
                or _fin_entete(s) >= s.body[0].lineno or _fin_entete(t) >= t.body[0].lineno
                or dumps(getattr(s, "decorator_list", [])) != dumps(getattr(t, "decorator_list", []))
                or bool(sinon_s) != bool(sinon_t)
                or (dumps(sinon_s) != dumps(sinon_t) and (est_elif(s, lignes) or est_elif(t, lignes_source)))):
            remplacer(s, t)  # une ligne, un corps sur la ligne de sa tête, un elif qui diffère : en entier
            return
        if ast.dump(_sans_corps(s)) != ast.dump(_sans_corps(t)):
            remplacer(s, t, entete=True)
        aligner(s.body, t.body, s.body[-1].end_lineno)
        if dumps(sinon_s) != dumps(sinon_t):
            aligner(sinon_s, sinon_t, sinon_s[-1].end_lineno)

    def aligner(ecrits: list[ast.stmt], voulus: list[ast.stmt], fin: int) -> None:
        """Deux suites d'instructions : difflib sur leur ``ast.dump``, puis, dans un bloc qui diffère, sur leur genre
        (``_cle``) pour apparier celles à retoucher ; ``fin`` : la ligne (base 0) où insérer en fin de bloc."""
        ecrits, voulus = sans_docstring(ecrits), sans_docstring(voulus)
        for op, k1, k2, m1, m2 in difflib.SequenceMatcher(None, dumps(ecrits), dumps(voulus), autojunk=False).get_opcodes():
            if op == "equal":
                continue
            a, b = ecrits[k1:k2], voulus[m1:m2]
            for op2, x1, x2, y1, y2 in difflib.SequenceMatcher(None, [_cle(s) for s in a], [_cle(s) for s in b], autojunk=False).get_opcodes():
                if op2 == "equal" or (op2 == "replace" and x2 - x1 == y2 - y1):
                    for s, t in zip(a[x1:x2], b[y1:y2]):
                        modifier(s, t)
                elif x1 == x2:  # instructions manquantes : un signe d'insertion avant celle qui suit, ou en fin de bloc
                    suivante = a[x1] if x1 < len(a) else ecrits[k2] if k2 < len(ecrits) else None
                    precedente = a[x1 - 1] if x1 else ecrits[k1 - 1] if k1 else None  # en fin de bloc : sous elle, pas sous les lignes vides
                    i1 = premiere(suivante) if suivante else precedente.end_lineno if precedente else fin
                    gabarit = suivante or (a[-1] if a else ecrits[-1] if ecrits else None)
                    mises = [(retrait(gabarit) if gabarit else "") + ligne for t in b[y1:y2] for ligne in ecrit(t)]
                    p = debuts[i1] + (len(lignes[i1]) - len(lignes[i1].lstrip(" \t")) if i1 < len(lignes) else 0)
                    retouches.append((i1, i1, mises, [(p, p)], [(max(i1, 1), ligne) for ligne in mises]))
                else:  # en trop, ou autant qui ne s'apparient pas : remplacées en bloc
                    i1, i2 = premiere(a[x1]), a[x2 - 1].end_lineno
                    mises = [retrait(a[x1]) + ligne for t in b[y1:y2] for ligne in ecrit(t)]
                    retouches.append((i1, i2, mises, lignes_entieres(i1, i2), [(i2, ligne) for ligne in mises] or [(i2, "")]))

    aligner(arbre.body, voulu.body, len(lignes))
    return sorted(retouches, key=lambda r: r[0])


COMBINAISONS = 3  # jusqu'à ce nombre de retouches, ``variantes_lignes`` les essaie dans toutes leurs combinaisons ; au-delà, une ou deux à la fois


def _vivantes(lignes: list[str], gardees, lus: frozenset[str] = frozenset()) -> set[int]:
    """Les lignes de ``gardees`` (la ligne d'origine que porte chaque ligne de ``lignes``, ou None), sauf celles qui
    affectent, au premier niveau du programme ou d'une fonction, des noms que plus rien ne lit : chacun est réaffecté
    (une affectation, la variable d'un for) avant d'être lu, ou la suite n'en parle plus. Une ligne qui n'affecte rien
    (un print, un appel) ou dans un bloc ne se juge pas ici. Rien si ``lignes`` ne s'analyse pas. ``lus`` : les noms que
    les tests lisent une fois le programme fini ; une affectation de premier niveau que la suite ne relit pas reste vivante
    si elle en affecte un (« comptes = [...] » lu par les asserts, tp_poo_ex11, 19/10/2026)."""
    try:
        arbre = ast.parse("".join(lignes))
    except (SyntaxError, ValueError):
        return set()

    def noms(n: ast.AST, ctx: type) -> set[str]:
        lus = {x.id for x in ast.walk(n) if isinstance(x, ast.Name) and isinstance(x.ctx, ctx)}
        return lus | {x.target.id for x in ast.walk(n) if ctx is ast.Load and isinstance(x, ast.AugAssign) and isinstance(x.target, ast.Name)}

    simples = (ast.Assign, ast.AugAssign, ast.AnnAssign)
    corps = [arbre.body] + [n.body for n in ast.walk(arbre) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                            and not any(isinstance(x, (ast.Global, ast.Nonlocal)) for x in ast.walk(n))]
    mortes = set()
    for instructions in corps:
        for k, n in enumerate(instructions):
            if not isinstance(n, simples) or not (ecrits := noms(n, ast.Store)):
                continue
            for suite in instructions[k + 1:]:
                # la variable d'un for est affectée avant le corps, pas son itérable
                lues = noms(suite.iter, ast.Load) if isinstance(suite, (ast.For, ast.AsyncFor)) else noms(suite, ast.Load)
                if ecrits & lues:
                    break  # lue : vivante
                if isinstance(suite, (*simples, ast.For, ast.AsyncFor)):
                    ecrits -= noms(suite.target if isinstance(suite, (ast.For, ast.AsyncFor)) else suite, ast.Store)
                if isinstance(suite, (ast.For, ast.AsyncFor)) and ecrits & noms(suite, ast.Load):
                    break
                if not ecrits:
                    break
            else:
                ecrits = ecrits & lus if instructions is arbre.body else set()
            if not ecrits:
                mortes.update(range(n.lineno - 1, n.end_lineno))
    # ce qui suit un return, un raise, un break ou un continue du même bloc ne s'exécute jamais (« return x * x » mis
    # au-dessus de « y = y + 2 / return y », qui passaient alors : test_correction_sur_place, 19/10/2026)
    for n in ast.walk(arbre):
        for champ in ("body", "orelse", "finalbody"):
            bloc = getattr(n, champ, None)
            sorties = [k for k, x in enumerate(bloc if isinstance(bloc, list) else []) if isinstance(x, (ast.Return, ast.Raise, ast.Break, ast.Continue))]
            if sorties and sorties[0] + 1 < len(bloc):
                mortes.update(range(bloc[sorties[0] + 1].lineno - 1, bloc[-1].end_lineno))
    return {i for k, i in enumerate(gardees) if i is not None and k not in mortes}

def variantes_lignes(texte: str, solution: str, maximum: int = 8, commentaires: bool = False, lus: frozenset[str] = frozenset()) -> list[tuple[list[tuple[int, str]], list[tuple[int, int]], str]]:
    """Le pendant ligne à ligne de ``variantes_python``, pour un programme qui ne se découpe pas en fonctions
    (l'utilisateur, 14/10/2026 : « si dans le code python on a une seule ligne fausse, pourquoi tout est barré ? ») :
    chaque façon de corriger une ou deux des retouches qui mènent de ``texte`` à ``solution``, alignés ligne à ligne
    (difflib, blancs de bord ignorés), ``[(corrections, fautes, variante)]``, une retouche avant deux ; toutes leurs
    combinaisons pour au plus ``COMBINAISONS`` retouches (314 : trois lignes fausses sur trois, que seules les trois
    retouches ensemble corrigent), une variante de plus. Une retouche :
    une ligne remplacée par celle de la solution, une ligne en trop retirée, une ligne manquante ajoutée. La solution
    sert deux fois : récrite d'abord dans les noms de l'élève (``solution_aux_noms``), puis telle quelle.
    ``corrections`` : ``(n, ligne)``, la ligne de la solution à écrire sous la ligne ``n`` (base 1) de ``texte``, vide
    pour une ligne en trop ; ``fautes`` : les (début, fin) dans ``texte`` des seuls caractères qui diffèrent, (p, p)
    pour une partie manquante. Rien au-delà de ``maximum`` retouches : un programme si éloigné de la solution ne
    se localise pas, et les variantes à exécuter croîtraient comme son carré. ``commentaires`` : les aligner aussi, pour
    des tests qui lisent le source (``Code._verifier_ensemble``) ; un commentaire n'y devient une faute que si la
    variante qui le retouche passe les tests, comme toute retouche."""
    import itertools  # noqa: PLC0415

    lignes = texte.splitlines(keepends=True)
    de_code = {i for i, l in enumerate(lignes) if sans_commentaire(l).strip()}  # ni les lignes vides ni les commentaires
    vues, variantes = set(), []
    # l'alignement par instructions d'abord (``_retouches_ast`` : ni les commentaires ni la mise en page, d'où pas avec
    # ``commentaires``), puis ligne à ligne, dans les noms de l'élève puis tel quel
    jeux = [(r, r) for r in ([] if commentaires else [_retouches_ast(texte, solution)]) if r and len(r) <= maximum]
    for s in dict.fromkeys((solution_aux_noms(texte, solution), solution)):
        rognees = []  # (``_retouches_lignes``) essayées comme les autres, jamais avec la retouche qu'elles rognent
        if (r := _retouches_lignes(texte, s, commentaires, rognees)) and len(r) <= maximum:
            jeux.append((r, r + rognees))
    vivantes = _vivantes(lignes, range(len(lignes)), lus)
    for taille in range(1, COMBINAISONS + 1):
        lot = []
        for retouches in (tout for base, tout in jeux if taille <= 2 or len(base) <= COMBINAISONS):
            for choix in itertools.combinations(retouches, taille):
                if any(x[0] < y[1] and y[0] < x[1] for x, y in itertools.combinations(choix, 2)):
                    continue  # une retouche et sa rognée
                # au-delà de deux retouches, une variante qui ne garde AUCUNE ligne de code de l'élève n'est pas une
                # localisation : c'est la solution, et un programme sans rapport passerait (« x = 1 / y = 2 / print(y) »
                # pour « a = 3 / b = 4 / b = a + b », test_accolade_code_ok_par_fonction, rouge depuis COMBINAISONS = 3)
                if taille > 2 and de_code <= {i for r in choix for i in range(r[0], r[1])}:
                    continue
                variante = [l if l.endswith("\n") else l + "\n" for l in lignes]
                gardees = list(range(len(lignes)))  # la ligne de l'élève que porte chaque ligne de la variante, ou None
                for i1, i2, mises, _, _ in sorted(choix, key=lambda r: -r[0]):  # de la fin vers le début : les indices tiennent
                    variante[i1:i2] = [m + "\n" for m in mises]
                    gardees[i1:i2] = [None] * len(mises)
                # une ligne que plus rien ne lit passe les tests quelle qu'elle soit : la garder n'est pas la juger juste
                # (« v = a + b » quand la ligne voulue calcule a * b dans le print qui lisait v, tp16_ex08, 19/10/2026)
                if not vivantes <= _vivantes(variante, gardees, lus) | {i for r in choix for i in range(r[0], r[1])}:
                    continue
                lot.append((sum(max(r[1] - r[0], len(r[2])) for r in choix), "".join(variante), choix))
        # à nombre de retouches égal, celle qui touche le moins de lignes d'abord : la tête d'un if plutôt que tout le if
        for _, variante, choix in sorted(lot, key=lambda x: x[0]):
            if variante not in vues:
                vues.add(variante)
                variantes.append(([c for r in choix for c in r[4]], [f for r in choix for f in r[3]], variante))
    return variantes


def retrait_lignes(texte: str, solution: str, passe, maximum: int = 12, plafond: int = 5, lus: frozenset[str] = frozenset()) -> tuple[list[tuple[int, str]], list[tuple[int, int]], str] | None:
    """La localisation par retrait (l'utilisateur, 17/10/2026 : « Pourquoi ne modifie-tu pas directement les huit lignes et
    puis tu vois si ça passe […] si ça passe, tu essaies d'en enlever une à une ») : pour un programme que ``variantes_lignes``
    ne localise pas (plus de ``COMBINAISONS`` retouches à faire ensemble), toutes les retouches vers la solution appliquées
    d'un coup, puis chacune défaite à son tour tant que ``passe(variante)`` reste vrai : celles qui restent sont les fautes,
    à condition d'être les mêmes dans l'ordre du programme et dans l'ordre inverse (deux réponses : on ne sait pas laquelle
    est fausse, comme ``variantes_litteraux`` qui en refuse deux). ``(corrections, fautes, variante)`` au format de ``variantes_lignes``, ou None : plus de
    ``maximum`` retouches au départ, aucune variante complète qui passe, aucune ligne de code de l'élève gardée (c'est la
    solution, pas une localisation), ou plus de ``plafond`` retouches restantes (décision de l'utilisateur, 17/10/2026 :
    « plafond 5 et MAXI 12 »). ``passe`` exécute les tests, une variante à la fois : 2n + 1 exécutions au plus."""
    lignes = texte.splitlines(keepends=True)
    de_code = {i for i, l in enumerate(lignes) if sans_commentaire(l).strip()}

    def appliquer(choix, vivantes=None):
        variante = [l if l.endswith("\n") else l + "\n" for l in lignes]
        gardees = list(range(len(lignes)))
        for i1, i2, mises, _, _ in sorted(choix, key=lambda r: -r[0]):  # de la fin vers le début : les indices tiennent
            variante[i1:i2] = [m + "\n" for m in mises]
            gardees[i1:i2] = [None] * len(mises)
        # une ligne gardée que plus rien ne lit passe les tests quelle qu'elle soit (``variantes_lignes``)
        if vivantes is not None and not vivantes <= _vivantes(variante, gardees, lus) | {i for r in choix for i in range(r[0], r[1])}:
            return None
        return "".join(variante)

    vivantes = _vivantes(lignes, range(len(lignes)), lus)

    for s in dict.fromkeys((solution_aux_noms(texte, solution), solution)):
        retouches = _retouches_lignes(texte, s)
        if not retouches or len(retouches) > maximum or not passe(appliquer(retouches)):
            continue
        sens = []
        for ordre in (retouches, retouches[::-1]):  # « chercher dans les deux sens » : deux résultats, c'est ne pas savoir
            gardees = list(retouches)
            for r in ordre:
                essai = [x for x in gardees if x is not r]
                if essai and (v := appliquer(essai, vivantes)) is not None and passe(v):
                    gardees = essai
            sens.append({r[0] for r in gardees})
        if sens[0] != sens[1] or len(gardees) > plafond or de_code <= {i for r in gardees for i in range(r[0], r[1])}:
            continue  # la solution telle quelle peut encore localiser
        return [c for r in gardees for c in r[4]], [f for r in gardees for f in r[3]], appliquer(gardees)
    return None


def variantes_litteraux(texte: str, solution: str, maximum: int = 40) -> list[tuple[list[tuple[int, str]], list[tuple[int, int]], str]]:
    """Le dernier recours de la localisation, quand ni les fonctions ni les lignes n'ont rien trouvé (un programme trop
    éloigné de la solution pour ``variantes_lignes``, TP01 q12 : 12 retouches pour un seul « Alan » écrit à la place de
    « Grace ») : chaque littéral (chaîne, nombre) de ``texte`` remplacé par un littéral de même type de la solution
    absent de ``texte``, un seul à la fois, au même format que ``variantes_lignes``. Pas par position, la structure de
    l'élève n'étant pas celle de la solution, mais seulement sur une ligne qui diffère de la solution alignée : un
    littéral juste ne doit pas être retouché pour en rattraper une autre faute (300 → 301 pour compenser un « - 1 »).
    Rien au-delà de ``maximum`` substitutions (autant d'exécutions), ni si ``texte`` ne s'analyse pas. Les docstrings et
    les morceaux de f-chaîne n'en sont pas."""
    try:
        arbres = ast.parse(texte), ast.parse(solution)
    except SyntaxError:
        return []

    def litteraux(arbre):
        exclus = {id(n.value) for n in ast.walk(arbre) if isinstance(n, ast.Expr)}
        exclus |= {id(v) for n in ast.walk(arbre) if isinstance(n, ast.JoinedStr) for v in ast.walk(n)}
        return [n for n in ast.walk(arbre) if isinstance(n, ast.Constant) and id(n) not in exclus
                and type(n.value) in (str, int, float)]

    ecrits, voulus = litteraux(arbres[0]), litteraux(arbres[1])
    presents = {(type(n.value), n.value) for n in ecrits}
    candidats = list(dict.fromkeys((type(n.value), n.value) for n in voulus if (type(n.value), n.value) not in presents))
    retouchees = {i for i1, i2, _, _, _ in _retouches_lignes(texte, solution_aux_noms(texte, solution)) for i in range(i1, i2)}
    lignes = texte.splitlines(keepends=True)
    essais = []
    for n in ecrits:
        if n.lineno != n.end_lineno or n.lineno - 1 not in retouchees:
            continue
        ligne = lignes[n.lineno - 1]
        brut = ligne.encode()
        a, b = len(brut[:n.col_offset].decode()), len(brut[:n.end_col_offset].decode())
        guillemet = ligne[a] if isinstance(n.value, str) else ""
        if isinstance(n.value, str) and guillemet not in "'\"":  # préfixe (r, b…) : pas réécrit
            continue
        for genre, valeur in candidats:
            if genre is not type(n.value):
                continue
            if genre is str:
                if guillemet in valeur or "\\" in valeur or "\n" in valeur or ligne[a:a + 3] == guillemet * 3:
                    continue
                ecrit = guillemet + valeur + guillemet
            else:
                ecrit = repr(valeur)
            essais.append((n.lineno, a, b, ecrit))
    if len(essais) > maximum:
        return []
    debuts = [0]
    for ligne in lignes:
        debuts.append(debuts[-1] + len(ligne))
    variantes = []
    for numero, a, b, ecrit in essais:
        ligne, d = lignes[numero - 1], debuts[numero - 1] + a
        nouvelle = ligne[:a] + ecrit + ligne[b:]
        variante = "".join(lignes[:numero - 1]) + nouvelle + "".join(lignes[numero:])
        # le littéral entier, comme ``_retouches_lignes`` : « Alan » pour « Grace » raye le mot, pas A et n (l'utilisateur,
        # 16/10/2026 : « je ne veux pas que tu corrige letre par lettre si l'élève s'est juste trompé de prenom »)
        fautes = [(d, d + b - a)]
        variantes.append(([(numero, sans_commentaire(nouvelle).rstrip())], fautes, variante))
    return variantes


MUTATIONS = 60  # ``variantes_mutations`` : au-delà de ce nombre de mutants, aucun (autant d'exécutions au plus)
# l'opérateur écrit, et ceux qu'une mutation essaie à sa place (TODO « Correction du code ligne à ligne », A2)
OPERATEURS = {ast.Add: ("+", ["-", "*"]), ast.Sub: ("-", ["+"]), ast.Mult: ("*", ["/", "+"]), ast.Div: ("/", ["//", "*"]),
              ast.FloorDiv: ("//", ["/", "%"]), ast.Mod: ("%", ["//"]),
              ast.Lt: ("<", ["<=", ">"]), ast.LtE: ("<=", ["<", ">="]), ast.Gt: (">", [">=", "<"]), ast.GtE: (">=", [">", "<="]),
              ast.Eq: ("==", ["!="]), ast.NotEq: ("!=", ["=="]), ast.In: ("in", ["not in"]), ast.NotIn: ("not in", ["in"]),
              ast.Is: ("is", ["is not"]), ast.IsNot: ("is not", ["is"]), ast.And: ("and", ["or"]), ast.Or: ("or", ["and"])}


def variantes_mutations(texte: str, solution: str, maximum: int = MUTATIONS) -> list[tuple[list[tuple[int, str]], list[tuple[int, int]], str]]:
    """Les réparations qui ne viennent pas de la solution (TODO « Correction du code ligne à ligne », A2 : une autre démarche
    que le corrigé, « while i < n » pour « for i in range(n + 1) », n'a aucune ligne de la solution qui la répare) : une
    mutation de ``texte`` à la fois, au format de ``variantes_lignes``. Un opérateur (``OPERATEURS`` : + -, < <=, == !=,
    and or…, ``+=`` compris), une constante entière ±1, la borne d'un ``range`` non constante ±1, ``print(x)`` ↔ ``return x``,
    le retrait d'une ligne simple ou d'un bloc entier remplacé par celui d'une ligne de code qui le précède (tous abandonnés
    s'ils débordent ``maximum``) ; et, sur un budget à part de ``maximum`` (restreint aux noms proches, puis abandonné en
    bloc s'il déborde encore), un nom lu remplacé par un autre nom affecté du programme,
    deux instructions simples voisines d'un même bloc échangées (point C, familles « variable » et « échange »). Comme ``variantes_litteraux``,
    seulement sur une ligne qui diffère de la solution (alignée ligne à ligne ou par instructions) : une ligne juste ne se
    mute pas pour rattraper une autre faute. Un mutant qui ne se compile pas est écarté ; rien au-delà de ``maximum``
    mutants, ni si ``texte`` ne s'analyse pas. Les morceaux de f-chaîne n'en sont pas."""
    import bisect  # noqa: PLC0415
    import itertools  # noqa: PLC0415

    try:
        arbre = ast.parse(texte)
    except SyntaxError:
        return []
    lignes = texte.splitlines(keepends=True)
    debuts = [0, *itertools.accumulate(len(l) for l in lignes)]

    def position(n, colonne):  # (ligne base 1, colonne en octets) -> indice dans texte
        return debuts[n - 1] + len(lignes[n - 1].encode()[:colonne].decode(errors="ignore"))

    def etendue(n):
        return position(n.lineno, n.col_offset), position(n.end_lineno, n.end_col_offset)

    essais = []  # (début, fin, texte mis à la place) dans ``texte``
    ajustes = []  # ceux qui ajustent un nombre (constante ±1, borne de range ±1)
    blocs = []  # (première ligne, fin, retrait, nouveau retrait) des instructions à déplacer, base 0, fin exclue

    def operateur(gauche, droite, ecrit, autres):
        """L'opérateur ``ecrit`` entre ``gauche`` et ``droite`` (parenthèses, blancs et commentaires autour)."""
        d, f = etendue(gauche)[1], etendue(droite)[0]
        trou = re.sub(r"#[^\n]*", lambda m: " " * len(m.group()), texte[d:f])
        if re.sub(r"[()\s\\]", "", trou) == ecrit.replace(" ", ""):
            m = re.search(r"\s+".join(map(re.escape, ecrit.split())), trou)
            essais.extend((d + m.start(), d + m.end(), a) for a in autres)

    dans_fchaine = {id(v) for n in ast.walk(arbre) if isinstance(n, ast.JoinedStr) for v in ast.walk(n)}
    for n in ast.walk(arbre):
        if id(n) in dans_fchaine:
            continue
        if isinstance(n, ast.BinOp) and type(n.op) in OPERATEURS:
            operateur(n.left, n.right, *OPERATEURS[type(n.op)])
        elif isinstance(n, ast.AugAssign) and type(n.op) in OPERATEURS:
            ecrit, autres = OPERATEURS[type(n.op)]
            operateur(n.target, n.value, ecrit + "=", [a + "=" for a in autres])
        elif isinstance(n, ast.Compare):
            for g, op, dr in zip([n.left, *n.comparators], n.ops, n.comparators):
                operateur(g, dr, *OPERATEURS[type(op)])
        elif isinstance(n, ast.BoolOp):
            for g, dr in zip(n.values, n.values[1:]):
                operateur(g, dr, *OPERATEURS[type(n.op)])
        elif isinstance(n, ast.Constant) and type(n.value) is int:
            ajustes.extend((*etendue(n), str(n.value + k)) for k in (1, -1))
        elif isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "range" and 1 <= len(n.args) <= 3 and not n.keywords:
            borne = n.args[0 if len(n.args) == 1 else 1]
            # une borne constante, ou « n + 1 », a déjà sa constante ±1
            if not isinstance(borne, ast.Constant) and not (isinstance(borne, ast.BinOp) and isinstance(borne.right, ast.Constant)):
                f = etendue(borne)[1]
                ajustes.extend((f, f, a) for a in (" + 1", " - 1"))
        if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name) and n.value.func.id == "print" \
                and len(n.value.args) == 1 and not n.value.keywords:
            essais.append((*etendue(n.value), "return " + texte[slice(*etendue(n.value.args[0]))]))
        elif isinstance(n, ast.Return) and n.value:
            essais.append((*etendue(n), "print(" + texte[slice(*etendue(n.value))] + ")"))
        if isinstance(n, ast.stmt):
            i = n.lineno - 1
            retrait = lignes[i][:len(lignes[i]) - len(lignes[i].lstrip(" \t"))]
            precedents = dict.fromkeys(l[:len(l) - len(l.lstrip(" \t"))] for l in lignes[:i] if sans_commentaire(l).strip())
            precedents.pop(retrait, None)
            blocs.extend((i, n.end_lineno, retrait, r) for r in precedents)  # un bloc (if, for…) déplacé en entier
    # un nombre ajusté sur une ligne qui lit un nom calculé par une instruction absente de la solution peut compenser cette
    # instruction (« z = y - 2 » pour rattraper « y = x*3 ») : hors d'une fonction, les données sont fixes et un ±1 atteint
    # la valeur attendue par coïncidence, on ne sait pas si la faute est là ou en amont ; dans une fonction, les tests en
    # font varier les arguments (« return total - 1 » d'une autre démarche que « return sum(t) » reste ajusté)
    try:
        corrige = ast.parse(solution_aux_noms(texte, solution))
    except SyntaxError:
        corrige = ast.Module(body=[], type_ignores=[])

    def affectations(arbre):
        """(instruction, noms qu'elle affecte) ; d'un for, sa tête seule (cible et itérable)."""
        for s in ast.walk(arbre):
            if isinstance(s, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
                yield ast.dump(s), s.targets if isinstance(s, ast.Assign) else [s.target]
            elif isinstance(s, (ast.For, ast.AsyncFor)):
                yield ast.dump(s.target) + ast.dump(s.iter), [s.target]

    du_corrige = {cle for cle, _ in affectations(corrige)}
    derives = {m.id for cle, cibles in affectations(arbre) if cle not in du_corrige
               for c in cibles for m in ast.walk(c) if isinstance(m, ast.Name) and isinstance(m.ctx, ast.Store)}
    lus = {}
    for m in ast.walk(arbre):
        if isinstance(m, ast.Name) and isinstance(m.ctx, ast.Load):
            lus.setdefault(m.lineno, set()).add(m.id)
    dans_fonction = {i for s in ast.walk(arbre) if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda))
                     for i in range(s.lineno, s.end_lineno + 1)}
    essais += [(d, f, a) for d, f, a in ajustes if (n := bisect.bisect_right(debuts, d)) in dans_fonction
               or not lus.get(n, set()) & derives]
    retouchees ={i for r in (_retouches_lignes(texte, solution_aux_noms(texte, solution)), _retouches_ast(texte, solution))
                  for i1, i2, *_ in r for i in range(i1, i2)}
    essais = [(d, f, a) for d, f, a in dict.fromkeys(essais) if (i := bisect.bisect_right(debuts, d) - 1) in retouchees
              and bisect.bisect_right(debuts, max(d, f - 1)) - 1 == i]
    # un bloc dont une ligne du corps n'a pas le retrait de sa tête (chaîne sur plusieurs lignes) ne se déplace pas
    blocs = [b for b in blocs if b[0] in retouchees and all(l.startswith(b[2]) or not l.strip() for l in lignes[b[0]:b[1]])]
    if len(essais) + len(blocs) > maximum:
        essais, blocs = [], []  # trop de candidats (programme long) : les noms et les échanges, sur leur budget, restent essayés
    # un nom lu remplacé par un autre nom affecté du programme (paramètres compris), et deux instructions simples voisines
    # du même bloc échangées : sur un budget à part, pour qu'un programme long ne fasse pas tomber les mutants précédents
    affectes = sorted({m.id for m in ast.walk(arbre) if isinstance(m, ast.Name) and isinstance(m.ctx, ast.Store)}
                      | {a.arg for m in ast.walk(arbre) if isinstance(m, ast.arguments)
                         for a in (*m.posonlyargs, *m.args, *m.kwonlyargs)})
    noms = [(*etendue(m), a) for m in ast.walk(arbre) if isinstance(m, ast.Name) and isinstance(m.ctx, ast.Load)
            and id(m) not in dans_fchaine and m.lineno - 1 in retouchees and m.id in affectes for a in affectes if a != m.id]
    echanges = [s.lineno - 1 for n in ast.walk(arbre) for champ in ("body", "orelse", "finalbody")
                if isinstance(getattr(n, champ, None), list)
                for s, t in zip(getattr(n, champ), getattr(n, champ)[1:])
                if s.lineno == s.end_lineno and t.lineno == t.end_lineno == s.lineno + 1
                and not hasattr(s, "body") and not hasattr(t, "body") and {s.lineno - 1, t.lineno - 1} & retouchees]
    if len(noms) + len(echanges) > maximum:
        # programme long : pour chaque nom, seulement ceux indexés ailleurs par la même clé constante (``perso["x"]`` pour
        # ``ECRAN["x"]``) et les trois plus proches par l'orthographe (``comptes`` pour ``compte``)
        cles, par_cle = {}, {}
        for s in ast.walk(arbre):
            if isinstance(s, ast.Subscript) and isinstance(s.value, ast.Name) and isinstance(s.slice, ast.Constant):
                cles[id(s.value)] = repr(s.slice.value)
                par_cle.setdefault(repr(s.slice.value), set()).add(s.value.id)
        noms = [(*etendue(m), a) for m in ast.walk(arbre) if isinstance(m, ast.Name) and isinstance(m.ctx, ast.Load)
                and id(m) not in dans_fchaine and m.lineno - 1 in retouchees and m.id in affectes
                for a in sorted(par_cle.get(cles.get(id(m)), set()) & set(affectes)
                                | set(difflib.get_close_matches(m.id, affectes, 3, 0.6))) if a != m.id]
    if len(noms) + len(echanges) <= maximum:
        essais += noms
    else:
        echanges = []
    variantes = []

    def rayees(i, nouvelle):
        """Les fautes de la ligne ``i`` (base 0) devenue ``nouvelle`` ; un retrait seul changé, que ``_fautes_texte`` ne voit
        pas : les blancs en trop, ou la place vide où il en manque (la ligne compte, comme une ligne manquante)."""
        ancienne = lignes[i].rstrip("\r\n")
        if fautes := [(debuts[i] + x, debuts[i] + y) for x, y in _fautes_texte(ancienne, nouvelle)]:
            return fautes
        avant, apres = (len(t) - len(t.lstrip(" \t")) for t in (ancienne, nouvelle))
        return [(debuts[i] + min(avant, apres), debuts[i] + avant)] if avant != apres else []

    for d, f, a in essais:
        variante = texte[:d] + a + texte[f:]
        try:
            compile(variante, "<mutant>", "exec")
        except (SyntaxError, ValueError):
            continue
        i = bisect.bisect_right(debuts, d) - 1
        nouvelle = variante[debuts[i]:].splitlines()[0] if variante[debuts[i]:] else ""
        variantes.append(([(i + 1, sans_commentaire(nouvelle).rstrip())], rayees(i, nouvelle), variante))
    for i, fin, retrait, r in blocs:
        nouvelles = [r + l[len(retrait):] if l.strip() else l for l in lignes[i:fin]]
        variante = "".join(lignes[:i] + nouvelles + lignes[fin:])
        try:
            compile(variante, "<mutant>", "exec")
        except (SyntaxError, ValueError):
            continue
        variantes.append(([(i + 1 + k, sans_commentaire(l).rstrip()) for k, l in enumerate(nouvelles) if l.strip()],
                          [f for k, l in enumerate(nouvelles) if l.strip() for f in rayees(i + k, l.rstrip("\r\n"))], variante))
    for i in echanges:
        haut, bas = (l[len(l) - len(l.lstrip(" \t")):].rstrip("\r\n") for l in lignes[i:i + 2])
        retrait = lignes[i][:len(lignes[i]) - len(lignes[i].lstrip(" \t"))]
        nouvelles = [retrait + bas, retrait + haut]
        if nouvelles[0] == lignes[i].rstrip("\r\n"):
            continue
        fin = [l[len(l.rstrip("\r\n")):] for l in lignes[i:i + 2]]
        variante = "".join(lignes[:i] + [nouvelles[0] + fin[0], nouvelles[1] + fin[1]] + lignes[i + 2:])
        variantes.append(([(i + 1 + k, sans_commentaire(l).rstrip()) for k, l in enumerate(nouvelles)],
                          [f for k, l in enumerate(nouvelles) for f in rayees(i + k, l)], variante))
    return variantes


def _aligner(texte: str, variante: str, donne: str = "") -> tuple[list, list, list, int | None]:
    """Les lignes comptées de ``texte`` et de ``variante`` (``part_lignes``), ``[(n, ligne)]``, leur alignement
    (difflib) et la ligne de ``texte`` où la compilation échoue, celle que Python affiche, et elle seule : retirer les
    lignes fautives pour trouver les suivantes en signalerait d'autres par cascade (« unexpected indent » sous un ``if``
    retiré)."""
    import difflib  # noqa: PLC0415

    donnees = {l.strip() for l in donne.splitlines()}

    def comptees(source):
        return [(n, l.strip()) for n, l in enumerate(source.splitlines(), 1)
                if l.strip() and not l.strip().startswith("#") and l.strip() not in donnees]

    ecrites, voulues = comptees(texte), comptees(variante)
    try:
        compile(texte, "<eleve>", "exec", dont_inherit=True)
        syntaxe = None
    except SyntaxError as exc:
        syntaxe = exc.lineno
    return ecrites, voulues, difflib.SequenceMatcher(None, [l for _, l in ecrites], [l for _, l in voulues],
                                                     autojunk=False).get_opcodes(), syntaxe


def part_lignes(texte: str, variante: str, donne: str = "", passation: str = "numerique",
                exceptions: Iterable[int] = (), couvertes: Iterable[str] = frozenset(), solution: str = "") -> float:
    """La part des points d'un programme localisé ligne à ligne, ``variante`` étant la variante de ``variantes_lignes``
    qui passe les tests ; formule de l'utilisateur (14/10/2026) : « 0.5 x nombre_lignes_justes / (nombre_de_lignes - 1) »,
    pile 0,5 pour une seule ligne fausse - un écart reste avec une solution juste -, 0 sans aucune ligne juste. Une ligne
    juste est une ligne de ``texte`` que la variante n'a pas eu à retoucher : prouvée par l'exécution, pas par sa
    ressemblance avec la solution (« tu compte comme fausses les lignes qui n'utilisent pas exactement les meme valeurs,
    malgré qu'elle répondent à l'ennoncé ? », 14/10/2026). Le nombre de lignes : les justes, plus pour chaque retouche le
    plus grand de ses deux côtés (une ligne remplacée, en trop ou manquante compte une fois). Ne comptent ni les lignes
    vides, ni les commentaires (« mettre 99 lignes de commentaire […] ne doivent pas » rapporter), ni les lignes que
    ``donne`` (le code de départ) fournit déjà. Une signature écrite par l'élève compte (« je ne donne pas
    systématiquement la signature de la fonction et savoir déjà écrire les arguments vaut quelque chose », 14/10/2026) ;
    donnée par l'énoncé, elle est dans ``donne``. 0 s'il reste moins de deux lignes.

    Une ligne retouchée (remplacée une pour une) vaut une demi-ligne juste selon sa faute (``demi_ligne`` ; barème de
    l'utilisateur, 16/10/2026) : ``passation`` « numerique » ou « papier » (``Paquet.passation``), ``exceptions`` : les
    lignes de ``texte`` où l'exécution des tests a levé une exception (``_signaler`` ; les clés d'un dictionnaire
    ``{ligne: exception}``). Les demi-lignes ne font jamais dépasser 0,5, ni ne valent quelque chose sans aucune ligne
    entièrement juste.

    ``couvertes`` : les lignes de la solution (``cle_ligne``) que le commentaire de l'élève décrit (``Code.demarche``) ;
    une ligne que la variante a dû insérer ou remplacer, et que le commentaire décrit, vaut une demi-ligne quelle que
    soit sa faute (« une étape décrite par commentaire », 17/10/2026), et ces demi-lignes-là comptent même sans ligne
    entièrement juste : sinon des commentaires seuls ne rapporteraient rien.

    ``solution`` : la formule s'applique alors à chaque fonction que la solution définit (``_unites``), une fonction
    sans retouche valant 1, et la part est leur moyenne (TODO « Correction du code ligne à ligne », A1, l'utilisateur,
    19/10/2026 : « il faut appliquer cette formule , mais pour chaque fonction ») ; une retouche hors de ces fonctions,
    ou moins de deux fonctions, et c'est la formule sur le programme entier."""
    ecrites, voulues, alignement, syntaxe = _aligner(texte, variante, donne)
    couvertes = set(couvertes)
    signalees = set(exceptions) | {syntaxe}
    unites = _unites(texte, variante, solution, donne) if solution else None
    comptes = {}  # unité (None : le programme entier, "" : hors des fonctions de la solution) → [lignes, justes, entières, décrites, retouchée]

    def compter(unite, lignes, justes, entieres=0, decrites=0, retouche=False):
        for cle in {None, unite or ""} if unites else {None}:
            c = comptes.setdefault(cle, [0, 0, 0, 0, False])
            c[:] = c[0] + lignes, c[1] + justes, c[2] + entieres, c[3] + decrites, c[4] or retouche

    for op, i1, i2, j1, j2 in alignement:
        if op == "equal":
            for n, _ in ecrites[i1:i2]:
                compter(unites and unites[0].get(n), 1, 1, entieres=1)
            continue
        decrit = [cle_ligne(v) in couvertes for _, v in voulues[j1:j2]]
        if op == "replace" and i2 - i1 == j2 - j1:
            justes = sum(max(demi_ligne(e, v, n in signalees, passation), DEMI * d)
                         for (n, e), (_, v), d in zip(ecrites[i1:i2], voulues[j1:j2], decrit))
        else:
            justes = DEMI * sum(decrit)
        # une retouche de plusieurs lignes compte dans l'unité de sa première ligne, côté élève s'il en a une
        compter(unites and (unites[0].get(ecrites[i1][0]) if i1 < i2 else unites[1].get(voulues[j1][0])),
                max(i2 - i1, j2 - j1), justes, decrites=sum(decrit), retouche=True)

    def formule(lignes, justes, entieres, decrites, retouche):
        # des demi-lignes ne font ni passer un programme faux au-dessus de la moitié (barème validé, 16/10/2026), ni valoir
        # quelque chose à un programme dont aucune ligne n'est juste (« 0 sans aucune ligne juste »), sauf décrites
        return 0.0 if lignes < 2 or not (entieres or decrites) else min(PLAFOND_PARTIEL, 0.5 * justes / (lignes - 1))

    entier = formule(*comptes.get(None, [0, 0, 0, 0, False]))
    # une retouche hors des fonctions de la solution : pas une part à elle seule, que l'élève choisirait par ses propres
    # lignes, mais la formule sur le programme entier ; une fonction de la solution que l'élève n'a pas écrite vaut 0
    if not unites or comptes.get("", [0] * 5)[4]:
        return entier
    return sum(formule(*comptes[u]) if comptes.get(u, [0] * 5)[4] else float(u in comptes) for u in unites[2]) / len(unites[2])


def _unites(texte: str, variante: str, solution: str, donne: str = "") -> tuple[dict[int, str], dict[int, str], list[str]] | None:
    """Les unités du barème par fonction de ``part_lignes`` : pour ``texte`` et ``variante``, ``{ligne (base 1): nom}``
    de chaque ligne d'une fonction que ``solution`` définit, et la liste de ces noms, hors celles que ``donne`` fournit
    déjà telles quelles. Une fonction ajoutée par l'élève compte dans la première fonction de la solution qui l'appelle
    (l'utilisateur, 19/10/2026 : « oui, fais ainsi ») ; appelée par aucune, elle est hors des unités, comme le reste du
    module. None si ``texte`` ou ``variante`` ne s'analyse pas, ou si la solution a moins de deux fonctions."""
    def fonctions(source):
        return [n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef | ast.AsyncFunctionDef)]

    try:
        fournies = {ast.unparse(n) for n in fonctions(donne)} if donne else set()
        noms = [n.name for n in fonctions(solution) if ast.unparse(n) not in fournies]
        if len(noms) < 2:
            return None

        def lignes(source):
            definies = fonctions(source)
            unite = {n.name: n.name for n in definies if n.name in noms}
            for n in definies:
                if n.name not in unite:
                    unite[n.name] = next((d.name for d in definies if d.name in noms and any(
                        isinstance(x, ast.Name) and x.id == n.name for x in ast.walk(d))), None)
            return {i: unite[n.name] for n in definies if unite[n.name]
                    for i in range(min(d.lineno for d in [n, *n.decorator_list]), n.end_lineno + 1)}

        return lignes(texte), lignes(variante), noms
    except SyntaxError:
        return None


MOTS_RECOPIE = 6  # ``phrases_commentaire`` : un commentaire de l'énoncé, à partir de ce nombre de mots, est une recopie
DEMI, PLAFOND_PARTIEL = 0.5, 0.5  # une ligne décrite ou à faute silencieuse : la moitié d'une ligne juste ; un programme faux : au plus la moitié


def cle_ligne(ligne: str) -> str:
    """Une ligne de code sans son commentaire ni ses espaces : ce qui identifie une ligne de la solution dans
    ``couvertes``, que la variante la porte avec ses commentaires ou non."""
    return "".join(sans_commentaire(ligne).split())


def lignes_solution(solution: str, donne: str = "") -> list[str]:
    """Les lignes de la solution que ``part_lignes`` compte (ni vides, ni commentaires, ni données par l'énoncé),
    dans l'ordre : celles que le modèle numérote de 1 à n pour y apparier la démarche de l'élève (``Code.demarche``)."""
    donnees = {l.strip() for l in donne.splitlines()}
    return [l.rstrip() for l in solution.splitlines() if cle_ligne(l) and l.strip() not in donnees]


def part_commentaires(solution: str, donne: str = "", couvertes: Iterable[str] = ()) -> float:
    """La part d'un programme jugé sur sa seule démarche en commentaire : chaque ligne de la solution décrite vaut une
    demi-ligne juste, sur les n lignes de la solution, par la formule de ``part_lignes`` (≈ 25 % pour tout décrit).
    Le plancher de toute note de code dont le commentaire a été apparié : essayer de coder ce qu'on a décrit ne fait
    jamais perdre de points (l'utilisateur, 17/10/2026 : « je ne voudrais pas que le fait d'essayer de coder ses propres
    commentaires enlève des points par rapport aux commentaires seuls »), même quand des lignes en trop grossissent le
    nombre de lignes de ``part_lignes``."""
    lignes, couvertes = lignes_solution(solution, donne), set(couvertes)
    decrites = sum(cle_ligne(l) in couvertes for l in lignes)
    return 0.0 if len(lignes) < 2 else min(PLAFOND_PARTIEL, 0.5 * DEMI * decrites / (len(lignes) - 1))


def phrases_commentaire(texte: str, enonce: str = "") -> list[str]:
    """Les commentaires de l'élève, un par ligne (le ``#`` hors des chaînes et ce qui suit) : sans aucun, la démarche
    que le modèle apparie n'est pas gardée (``modele.Code._analyser``, ``Code.demarche``). Ne comptent ni un commentaire vide, ni un commentaire
    que l'énoncé contient déjà, d'au moins ``MOTS_RECOPIE`` mots (recopier la consigne n'est pas décrire une démarche ;
    plus court, c'est une étape nommée avec les mots de l'énoncé, « # renvoie la somme »)."""
    def serre(s):
        return " ".join(re.sub(r"[^\w]+", " ", s.lower()).split())

    dans_enonce = serre(enonce)
    phrases = []
    for ligne in texte.splitlines():
        code = sans_commentaire(ligne)
        phrase = ligne[len(code):].lstrip("#").strip() if len(code) < len(ligne.rstrip("\n")) else ""
        mots = serre(phrase)
        if mots and not (len(mots.split()) >= MOTS_RECOPIE and mots in dans_enonce):
            phrases.append(phrase)
    return phrases


def demi_ligne(ecrite: str, voulue: str, signalee: bool, passation: str = "numerique") -> float:
    """Ce que vaut, en lignes justes, une ligne ``ecrite`` que la correction remplace par ``voulue`` : 0 (la faute coûte
    la ligne) ou 0,5 (la moitié). Barème de l'utilisateur, 16/10/2026, sans aucun compte d'occurrences (« je ne veux pas
    d'histoires d'occurrences ») : « : » oublié, la moitié partout ; sur papier, tout la moitié ; à l'écran, « = » pour
    « == » coûte la ligne, et sinon une faute ``signalee`` (Python l'a affichée : la ligne ne compile pas, ou l'exécution
    y a levé une exception) coûte la ligne, une faute silencieuse la moitié."""
    serre = "".join(ecrite.split())
    if voulue.rstrip().endswith(":") and serre == "".join(voulue.rstrip()[:-1].split()):
        return 0.5
    if passation == "papier":
        return 0.5
    if "==" in voulue and serre == "".join(voulue.split()).replace("==", "="):
        return 0.0
    return 0.0 if signalee else 0.5


# Les familles de fautes du bilan de l'élève, dans l'ordre de priorité où ``famille_faute`` les essaie, avec ce qu'on lui
# dit de travailler (barème du Superviseur, section C, retenu par l'utilisateur le 16/10/2026) ; écrit au « vous »,
# tutoyé par ``adresse.dire`` quand le sujet le demande. La famille se décide sur la nature de la faute, jamais sur son
# nombre (« je ne veux pas d'histoires d'occurrences ») ; « Compréhension d'un concept » n'a aucun critère déterministe
# et n'est pas produite.
FAMILLES = {
    "ecriture": ("Écriture", "relisez chaque ligne : ponctuation, « : » en fin de ligne, « == » pour comparer."),
    "noms": ("Noms", "un nom est utilisé avant d'être défini : vérifiez son orthographe et l'endroit où il est créé (sa portée)."),
    "types": ("Types et valeur rendue", "vérifiez le type de chaque valeur (nombre, texte, liste) et qu'une fonction rend "
                                        "son résultat avec return."),
    "bornes": ("Bornes et indices", "comptez sur un exemple de deux éléments : le premier et le dernier indice."),
    "conditions": ("Conditions et boucles", "déroulez la condition ou la boucle à la main sur un petit cas."),
    "methode": ("Méthode", "écrivez en français les étapes avant de coder."),
}


def _arbre_ligne(ligne: str) -> ast.AST | None:
    """L'arbre d'une ligne seule : un en-tête (« for …: », « elif …: ») reçoit un corps, « elif » devient « if »."""
    ligne = re.sub(r"^elif\b", "if", ligne.strip())
    try:
        return ast.parse(ligne + (" pass" if ligne.endswith(":") else "")).body[0]
    except (SyntaxError, IndexError):
        return None


def _ecarts(a: object, b: object, borne: bool = False) -> set[bool]:
    """Les écarts entre deux arbres, chacun marqué selon qu'il est dans une borne : un argument de ``range()`` ou
    l'indice d'un ``Subscript``."""
    if type(a) is not type(b):
        return {borne}
    if isinstance(a, list):
        return {borne} if len(a) != len(b) else set().union(*(_ecarts(x, y, borne) for x, y in zip(a, b)))
    if not isinstance(a, ast.AST):
        return set() if a == b else {borne}
    plage = isinstance(a, ast.Call) and all(isinstance(c.func, ast.Name) and c.func.id == "range" for c in (a, b))
    return set().union(*(_ecarts(getattr(a, champ, None), getattr(b, champ, None),
                                 borne or plage and champ == "args" or isinstance(a, ast.Subscript) and champ == "slice")
                         for champ in a._fields))


def famille_faute(ecrite: str, voulue: str, exception: str | None = None, syntaxe: bool = False) -> str | None:
    """La famille (``FAMILLES``) d'une ligne ``ecrite`` que la correction remplace par ``voulue`` ; ``exception`` : le nom
    de celle que l'exécution y a levée, ``syntaxe`` : la compilation y échoue. Essayées dans cet ordre, la première
    l'emporte : écriture (la ligne ne compile pas, « : » oublié, « = » pour « == ») ; noms (NameError) ; types
    (TypeError, AttributeError, ValueError) ; bornes (IndexError, ou la ligne ne diffère de la voulue que dans les
    arguments d'un ``range()`` ou dans un indice) ; conditions et boucles (faute silencieuse sur un en-tête ``if``,
    ``elif``, ``while`` ou ``for``). None sinon : aucune famille plutôt qu'une famille devinée."""
    serre = "".join(ecrite.split())
    if (syntaxe or voulue.rstrip().endswith(":") and serre == "".join(voulue.rstrip()[:-1].split())
            or "==" in voulue and serre == "".join(voulue.split()).replace("==", "=")):
        return "ecriture"
    if exception in ("NameError", "UnboundLocalError"):
        return "noms"
    if exception in ("TypeError", "AttributeError", "ValueError"):
        return "types"
    a, b = _arbre_ligne(ecrite), _arbre_ligne(voulue)
    ecarts = _ecarts(a, b) if a is not None and b is not None else set()
    if exception == "IndexError" or ecarts and all(ecarts):
        return "bornes"
    if exception is None and isinstance(b, (ast.If, ast.While, ast.For)):
        return "conditions"
    return None


def familles(texte: str, variante: str, donne: str = "", exceptions: Mapping[int, str] | None = None) -> list[str]:
    """Les familles des fautes de ``texte`` que ``variante`` corrige (alignement de ``part_lignes``), sans doublon, dans
    l'ordre de ``FAMILLES`` : une ligne remplacée une pour une, par ``famille_faute`` ; une seule ligne manquante qui
    est un ``return``, types et valeur rendue ; tout autre écart (bloc réécrit, lignes en trop ou manquantes), méthode.
    ``exceptions`` : ``{ligne: exception}`` (``_signaler``)."""
    exceptions = exceptions or {}
    ecrites, voulues, alignement, syntaxe = _aligner(texte, variante, donne)
    trouvees = set()
    for op, i1, i2, j1, j2 in alignement:
        if op == "replace" and i2 - i1 == j2 - j1:
            trouvees |= {famille_faute(e, v, exceptions.get(n), n == syntaxe)
                         for (n, e), (_, v) in zip(ecrites[i1:i2], voulues[j1:j2])}
        elif op == "insert" and j2 - j1 == 1 and re.match(r"return\b", voulues[j1][1]):
            trouvees.add("types")
        elif op != "equal":
            trouvees.add("methode")
    return [f for f in FAMILLES if f in trouvees]


def verifier_questions(travaux, python=sys.executable):
    """``verifier_question`` sur chaque ``(q, dossier, fichier_defaut, classe)`` de ``travaux``, résultats dans l'ordre.
    Toujours un sous-processus par question, mais lancés en même temps, un par cœur : 66 ms chacun, surtout le démarrage
    de Python, et 130 questions de code à la fin d'un TP (8,6 s l'une après l'autre). Les questions sont lues ici, dans
    le fil appelant : une question paresseuse se bâtit (des widgets) à la lecture d'un attribut. Dans le navigateur,
    qtpy6 double le pool : un Web Worker par tâche, autant à la fois que de cœurs."""
    prepares = [_preparer(*travail) for travail in travaux]
    lancer = lambda p: p[2] and _lancer(p[2], python)  # noqa: E731
    if len(prepares) < 2:
        finis = [lancer(p) for p in prepares]
    else:
        from concurrent.futures import ThreadPoolExecutor  # noqa: PLC0415
        with ThreadPoolExecutor(os.cpu_count()) as fils:
            finis = list(fils.map(lancer, prepares))
    return [_interpreter(q, *p, fini) for (q, *_), p, fini in zip(travaux, prepares, finis)]


def _preparer(q, dossier, fichier_defaut, classe, contexte=None):
    """(base, fichier, demande) ; demande None si le fichier de l'élève n'existe pas. ``contexte`` : (ce qui précède
    l'exercice, sa première ligne) dans un fichier rendu (``executer``), celui de la question par défaut
    (``FichierRendu.contexte_rendu``, posé par ``texte_corrige``)."""
    contexte, premiere = contexte or getattr(q, "contexte_rendu", None) or ("", q.premiere_ligne)
    nom = q.fichier or fichier_defaut
    fichier = Path(dossier) / nom
    base = {"id": q.id, "fichier": nom, "points": q.points, "obtenus": 0}
    if not fichier.is_file():
        return base, fichier, None
    return base, fichier, json.dumps({
        "fichier": str(fichier), "tests": [vars(t) for t in q.tests], "tests_code": q.tests_code,
        "classe": classe, "autorises": q.autorises, "langage": q.langage,
        "base": q.script_base(), "ordonne": getattr(q, "ordonne", False), "colonnes_libres": getattr(q, "colonnes_libres", False),
        "doublons_libres": getattr(q, "doublons_libres", False), "controle": getattr(q, "controle", ""),
        "prelude": q.prelude_source(), "premiere_ligne": premiere, "contexte": contexte,
        "effet": q.effet, "observe": q.observe, "forme": q.forme, "fonction": q.fonction,
        "fichiers": q.fichiers_deposes(), "mutants": [vars(m) for m in q.mutants], "arborescence": q.arborescence,
        "saisies": q.saisies, "erreur_attendue": q.erreur_attendue,
        "solution": q.solution})  # ``noms_repris`` : les noms de l'élève appariés à ceux de la solution


def _lancer(demande, python):
    """Le processus fini, ou None s'il a dépassé ``DELAI``."""
    try:
        return subprocess.run([python, str(ICI / "verifier.py"), "--enfant"], input=demande, capture_output=True,
                              text=True, encoding="utf-8", timeout=DELAI)
    except subprocess.TimeoutExpired:
        return None


def _interpreter(q, base, fichier, demande, fini):
    if demande is None:
        return {**base, "etat": "absent", "messages": [f"{base['fichier']} n'existe pas encore"]}
    if fini is None:
        return {**base, "etat": "erreur", "delai": True, "messages": [f"le programme ne s'est pas terminé en {DELAI} s : boucle infinie ?"]}
    lignes = [ligne for ligne in fini.stdout.split("\n") if ligne.startswith(MARQUE)]
    if not lignes:  # l'enfant est mort sans répondre : sortie brutale (os._exit), plantage de Python…
        return {**base, "etat": "erreur", "messages": [f"le programme s'est arrêté brutalement (code {fini.returncode})"
                                                       + (f" : {fini.stderr.strip().splitlines()[-1]}" if fini.stderr.strip() else "")]}
    r = json.loads(lignes[-1][len(MARQUE):])
    if q.langage == "python":  # sans effet sur la note : ce que la relecture du code relève, tests passés ou non
        texte = fichier.read_text(encoding="utf-8")
        base = {**base, "remarques": analyse_pyflakes(texte, _connus(q)) + analyse_noms(texte)}
    if r.get("lignes_exception"):  # les fautes que Python a affichées (part_lignes)
        base = {**base, "lignes_exception": r["lignes_exception"]}
    if r["erreur"]:
        return {**base, "etat": "erreur", "interdit": r.get("interdit", False), "messages": [r["erreur"]]}
    if getattr(q, "commentaires", None):  # une note par commentaire attendu, lue dans le texte et non à l'exécution
        manques = q.commentaires_manques(fichier.read_text(encoding="utf-8"))
        r = {**r, "reussis": r["reussis"] + len(q.commentaires) - len(manques), "total": r["total"] + len(q.commentaires),
             "messages": r["messages"] + manques}
    etat = ("reussi" if r["reussis"] == r["total"] else "absent" if r["absents"] == r["total"] else "echec")
    # ``partiel`` : la part juste d'une réponse dont la partie fausse est localisée (localiser_sql) ; ``fautes`` : cette partie
    fraction = max(r["reussis"] / r["total"], r.get("partiel", 0))
    return {**base, "etat": etat, "obtenus": round(base["points"] * fraction, 2), "messages": r["messages"],
            "fautes": r.get("fautes", [])}


def _connus(q) -> set[str]:
    """Les noms que l'élève n'a pas à définir : ceux du prélude, des fonctions fournies à l'exécution, et des exercices
    qui précèdent celui-ci dans un fichier rendu (``FichierRendu.contexte_rendu``)."""
    contexte = (getattr(q, "contexte_rendu", None) or ("",))[0]
    return _noms_poses(q.prelude_source() or "") | _noms_poses(contexte) | {"sortie", "termine", "arborescence"}


def verifier(paquet, dossier, python=sys.executable) -> list[dict]:
    """``verifier_questions`` sur les questions du paquet, plus la règle du lecteur (``noyau.Code._clore``) : chaque
    faute de nommage retire sa part des points à la première question où elle apparaît, pas aux suivantes."""
    questions = a_verifier(paquet.questions())
    resultats = verifier_questions([(q, dossier, paquet.fichier, paquet.classe) for q in questions], python)
    deja = frozenset()
    for q, r in zip(questions, resultats):
        if "remarques" in r:  # un fichier python lu
            texte = (Path(dossier) / r["fichier"]).read_text(encoding="utf-8")
            penalite, r["remarques"] = relecture(texte, frozenset(_connus(q)), deja, (q.solution, q.code_initial))
            deja |= fautes_de_nommage(texte)
            if r["obtenus"]:
                r["obtenus"] = round(max(0, r["obtenus"] - r["points"] * penalite), 2)
    return resultats


def charger(chemin, mot_de_passe=None):
    """Un paquet élève (chiffré : ``mot_de_passe``), ou un sujet de sujets/ (chez le professeur, qui a les banques) converti en paquet."""
    import codes  # noqa: PLC0415
    from modele import Paquet  # noqa: PLC0415 - seulement côté parent : l'enfant n'importe pas Qt
    from modele import charger as charger_objet  # noqa: PLC0415
    cle = str(chemin).endswith(".qcm") and (mot_de_passe or codes.cle_du_fichier(chemin))
    objet = charger_objet(chemin, cle or None)
    if isinstance(objet, Paquet):
        return objet
    from exporter_eleve import paquet  # noqa: PLC0415 - seulement chez le professeur
    from sujet import Sujet  # noqa: PLC0415
    return paquet(Sujet(chemin)).nommer("")  # préparé comme pour un élève, variables tirées


def afficher(resultats):
    for r in resultats:
        print(f"{SYMBOLES[r['etat']]} {r['id']:<40} {r['obtenus']:>5g} / {r['points']:<3g} {r['fichier']}")
        for message in r["messages"]:
            print(f"      {message}")
        for remarque in r.get("remarques", []):
            print(f"      (relecture) {remarque}")
    print(f"total : {sum(r['obtenus'] for r in resultats):g} / {sum(r['points'] for r in resultats):g}")


def solutions(banque, python=sys.executable):
    """Chaque solution de la banque (objet ``Banque``, déjà chargée), et chacune de ses ``autres_solutions``, contre
    ses propres tests ; renvoie [(id, messages)] de celles qui échouent, une autre solution nommée par son rang."""
    programmes = [(q, f"{q.id} (autre solution {k})" if k else q.id, s) for q in a_verifier(banque.questions)
                  for k, s in enumerate([q.solution, *getattr(q, "autres_solutions", [])])]
    with tempfile.TemporaryDirectory() as racine:
        travaux = []
        for n, (q, _, s) in enumerate(programmes):
            (dossier := Path(racine) / str(n)).mkdir()
            (dossier / (q.fichier or "tp.py")).write_text(s, encoding="utf-8")
            travaux.append((q, dossier, "tp.py", banque.niveau))
        return [(nom, r["messages"]) for (_, nom, _), r in zip(programmes, verifier_questions(travaux, python)) if r["etat"] != "reussi"]


# ------------------------------------------------------------------ réparation de syntaxe hors ligne
# Déplacée de .construction/banc_reparation.py (19/10/2026), qui l'importe d'ici. Principe et mesures : en-tête du banc.

PROFONDEUR = 3  # corrections successives au plus
LARGEUR = 6  # candidats non encore compilables gardés d'un niveau au suivant
FERMANTS = {"(": ")", "[": "]", "{": "}"}
MOTS_PYTHON = [*keyword.kwlist]
_MINUSCULES = {m.lower(): m for m in MOTS_PYTHON}


def _erreur(code: str) -> SyntaxError | None:
    """L'erreur d'analyse de ``code``, None s'il compile."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            compile(code, "<eleve>", "exec")
        except SyntaxError as e:
            return e
        except ValueError:  # octets nuls
            return SyntaxError("invalid", ("<eleve>", 1, 1, "", 1, 1))
    return None


def _partie_code(ligne: str) -> int:
    """La longueur de ``ligne`` sans son commentaire final ni ses blancs de fin (un « # » dans une chaîne est ignoré)."""
    guillemet = None
    for i, c in enumerate(ligne):
        if guillemet:
            guillemet = None if c == guillemet else guillemet
        elif c in "\"'":
            guillemet = c
        elif c == "#":
            return len(ligne[:i].rstrip())
    return len(ligne.rstrip())


def _piles(lignes: list[str]) -> list[list[str]]:
    """Pour chaque ligne, la pile des ouvrants encore ouverts à sa fin (chaînes d'une ligne et commentaires ignorés)."""
    pile: list[str] = []
    piles = []
    for ligne in lignes:
        guillemet = None
        for c in ligne:
            if guillemet:
                guillemet = None if c == guillemet else guillemet
            elif c in "\"'":
                guillemet = c
            elif c == "#":
                break
            elif c in FERMANTS:
                pile.append(c)
            elif c in ")]}" and pile:
                pile.pop()
        piles.append(list(pile))
    return piles


def _indent(ligne: str) -> int:
    """Le retrait de ``ligne``, en caractères."""
    return len(ligne) - len(ligne.lstrip())


def _lignes_fermees(lignes: list[str]) -> list[str]:
    """``lignes`` où chaque ligne restée ouverte est fermée à sa fin quand la suivante commence une nouvelle instruction
    (même retrait ou moins, un nom en tête) : la même parenthèse oubliée sur plusieurs lignes copiées-collées, cas réel
    du 12/10/2026 que la recherche pas à pas manque (fermer le bout du programme y repousse l'erreur plus loin)."""
    sortie = list(lignes)
    for i, ligne in enumerate(lignes):
        code = ligne[:_partie_code(ligne)]
        ouverts = _piles([l[:_partie_code(l)] for l in sortie[:i + 1]])[-1]
        suivante = next((l for l in lignes[i + 1:] if l[:_partie_code(l)].strip()), None)  # commentaires sautés
        if not ouverts or not code.strip() or code.rstrip()[-1] in ",\\+-*/%=" or (
                suivante is not None and (_indent(suivante) > _indent(ligne) or not re.match(r"\s*[A-Za-z_]", suivante))):
            continue
        sortie[i] = code + "".join(FERMANTS[o] for o in reversed(ouverts)) + ligne[len(code):]
    return sortie


def _candidats(lignes: list[str], e: SyntaxError) -> list[tuple[int, list[str]]]:
    """[(rang, lignes)] des programmes à un geste de ``lignes``, autour de l'erreur ``e`` ; le rang (plus petit =
    plus plausible) ne sert qu'à départager les ex aequo."""
    n = len(lignes)
    fautive = min(max((e.lineno or 1) - 1, 0), n - 1)
    msg = e.msg or ""
    piles = _piles(lignes)
    fenetre = sorted({i for i in range(fautive - 2, fautive + 2) if 0 <= i < n}, key=lambda i: abs(i - fautive))
    if "never closed" in msg:  # la ligne de l'ouvrant est celle de l'erreur : la fermeture est sur elle ou plus bas
        fenetre = sorted({*fenetre, *range(fautive, min(n, fautive + 8))}, key=lambda i: abs(i - fautive))
    sortie: list[tuple[int, list[str]]] = []
    fermees = _lignes_fermees(lignes)
    if sum(a != b for a, b in zip(fermees, lignes)) >= 2:  # un seul geste pour plusieurs lignes ouvertes ; pour une
        sortie.append((0, fermees))  # seule, les fermants ajoutés plus bas la couvrent, et mieux placés (banc, 12/10/2026)

    def poser(i: int, neuve: str, rang: int = 0) -> None:
        if neuve != lignes[i]:
            sortie.append((rang + 10 * abs(i - fautive), [*lignes[:i], neuve, *lignes[i + 1:]]))

    for i in fenetre:
        ligne = lignes[i]
        fin = _partie_code(ligne)
        code, queue = ligne[:fin], ligne[fin:]
        # --- fermants ajoutés : celui que la pile attend, puis les autres ; en fin de ligne ou avant un « : » final
        attendu = FERMANTS[piles[i][-1]] if piles[i] else None
        for r, f in enumerate([attendu, *")]}"] if attendu else ")]}"):
            if f is None:
                continue
            poser(i, code + f + queue, r)
            if code.endswith(":"):
                poser(i, code[:-1] + f + ":" + queue, r + 1)
        for r, f in enumerate([attendu, *")]}"] if attendu else ")]}"):
            if f is None:
                continue
            for m in re.finditer(r"[)\]},(\[{]|(?= (?:[-+*/%]?=(?!=)|<|>|==|!=|<=|>=|and|or|in|not)(?!\w))", code):  # fermant inséré au milieu
                # un indice ou un dictionnaire contient rarement une comparaison : le fermant y vient avant l'opérateur
                avant_operateur = m.group() == "" and attendu in ("[", "{")
                poser(i, ligne[:m.start()] + f + ligne[m.start():], r + (-4 if avant_operateur else 6))
            for m in re.finditer(r"[)\]}]", code):  # fermant d'une autre sorte : remplacé par celui qu'on attend
                if f == attendu:
                    poser(i, ligne[:m.start()] + f + ligne[m.end():], 3)
        if "never closed" in msg and attendu:  # fermant seul sur une ligne neuve (fin d'un dictionnaire sur plusieurs lignes)
            sortie.append((6 + 10 * abs(i - fautive), [*lignes[:i + 1], " " * _indent(lignes[fautive]) + attendu, *lignes[i + 1:]]))
        # --- deux-points oublié
        if re.match(r"\s*(def|if|elif|else|for|while|class|try|except|finally|with)\b", code) and not code.endswith(":"):
            poser(i, code + ":" + queue, 0)
        # --- « = » pour « == » dans la condition d'un if/elif/while, avant son « : » (une affectation du bloc
        # écrite sur la même ligne, « if x: y = 3 », n'est pas touchée) ; mieux classé quand Python le suggère
        if re.match(r"\s*(if|elif|while)\b", code):
            borne = code.find(":") if ":" in code else len(code)
            for m in re.finditer(r"(?<![=!<>+\-*/%&|^:@])=(?!=)", code[:borne]):
                poser(i, ligne[:m.start()] + "=" + ligne[m.start():], 0 if "'=='" in msg else 4)
        # --- retraits d'un bracket ou d'un guillemet, et ajouts de guillemet / virgule
        for m in re.finditer(r"[()\[\]{}\"',]", code):
            poser(i, ligne[:m.start()] + ligne[m.end():], 5 if m.group() in "\"'" else 3 if m.group() == "," else 7 if m.group() in "([{" else 2)
        for q in "\"'":
            for m in re.finditer(r"(?<=[(\[{,=+ ])(?=\w)|(?=[)\]},:]|$)", code):
                poser(i, ligne[:m.start()] + q + ligne[m.start():], 3)
            for m in re.finditer(q, code):  # « "" » devenu « \"\"\" » : docstring ou chaîne triple
                poser(i, ligne[:m.start()] + q + ligne[m.start():], 4)
            poser(i, code + q + queue, 3)
        for m in re.finditer(r"(?<=[\w)\]\"'])[ ](?=[\w(\[\"'])", code):  # virgule manquante entre deux éléments
            poser(i, ligne[:m.start()] + "," + ligne[m.start():], 5)
        for m in re.finditer(r",(?=[ ]?,|[ ]?\))", code):  # virgule en trop
            poser(i, ligne[:m.start()] + ligne[m.end():], 3)
        # --- mot clé écorché
        for m in re.finditer(r"[A-Za-z_]\w*", code):
            mot = m.group()
            if mot in MOTS_PYTHON:
                continue
            proches = ([_MINUSCULES[mot.lower()]] if mot.lower() in _MINUSCULES else []) \
                + difflib.get_close_matches(mot, MOTS_PYTHON, n=4, cutoff=0.6)  # sous 0.6, le contrôle de forme refuserait
            for k in dict.fromkeys(proches):  # d'autant mieux classé que le mot ressemble au mot clé
                poser(i, ligne[:m.start()] + k + ligne[m.end():], round(10 * (1 - difflib.SequenceMatcher(None, mot, k).ratio())))
        # --- indentation recalée sur les voisines
        if ligne.strip():
            avant = [lignes[j] for j in range(i - 1, -1, -1) if lignes[j].strip()]
            apres = [lignes[j] for j in range(i + 1, n) if lignes[j].strip()]
            niveaux = list(dict.fromkeys([*(_indent(l) for l in avant[:1]),
                                          *((_indent(avant[0]) + 4,) if avant else ()),
                                          *(_indent(l) for l in apres[:1]), *(_indent(l) for l in avant), 0]))
            for niveau in niveaux:
                poser(i, " " * niveau + ligne.lstrip(), 2)
    return sortie


def _caracteres_changes(a: str, b: str) -> int:
    """Le nombre de caractères que ``b`` change à ``a``."""
    return sum(max(i2 - i1, j2 - j1) for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes()
               if tag != "equal")


def _position(e: SyntaxError) -> tuple[int, int]:
    """(ligne, colonne) où l'analyse bute : plus grand = plus loin."""
    return (e.lineno or 0, e.offset or 0)


LIGNES_REPAREES = 3  # au-delà, ce n'est plus une faute de syntaxe réparée mais un programme réécrit : refusé
PONCTUATION = set(" \t()[]{}:,;'\"=")  # ce qu'une réparation peut ajouter, retirer ou changer : jamais un opérateur ni une valeur


def retouche(avant: str, apres: str) -> bool:
    """Vrai si ``apres`` ne diffère de la ligne ``avant`` que par de la ponctuation (``PONCTUATION``, indentation
    comprise) et au plus un mot devenu le mot clé qu'il écorchait (« retrun » → « return »)."""
    mots_avant, mots_apres = re.findall(r"\w+", avant), re.findall(r"\w+", apres)
    ecarts = [(a, b) for a, b in zip(mots_avant, mots_apres) if a != b]
    if len(mots_avant) == len(mots_apres) and len(ecarts) == 1 and keyword.iskeyword(ecarts[0][1]) \
            and difflib.SequenceMatcher(None, *ecarts[0]).ratio() >= 0.6:
        avant = re.sub(rf"\b{ecarts[0][0]}\b", ecarts[0][1], avant, count=1)
    elif len(mots_avant) + len(mots_apres) == 1 and keyword.iskeyword((mots_avant + mots_apres)[0]):
        avant, apres = re.sub(r"\w+", "", avant), re.sub(r"\w+", "", apres)  # une ligne « else: » ajoutée ou retirée
    return all(c in PONCTUATION for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, avant, apres, autojunk=False).get_opcodes()
               if tag != "equal" for c in avant[i1:i2] + apres[j1:j2])


def lignes_reparees(code: str, repare: str) -> list[int] | None:
    """Les numéros (à partir de 1) des lignes de ``code`` que ``repare`` change, s'il ne fait que réparer : au plus
    ``LIGNES_REPAREES`` lignes touchées, chacune par une faute de frappe (``retouche``), une ligne ajoutée ou retirée
    seulement si elle n'est que ponctuation ou un mot clé (« ) », « else: ») ; None sinon, ou sans changement."""
    avant, apres = code.rstrip("\n").split("\n"), repare.rstrip("\n").split("\n")
    touchees: set[int] = set()
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, avant, apres, autojunk=False).get_opcodes():
        if tag == "equal":
            continue
        paires = list(zip(avant[i1:i2], apres[j1:j2]))
        seules = avant[i1 + len(paires):i2] + apres[j1 + len(paires):j2]
        if not all(retouche(x, y) for x, y in paires) or not all(retouche("", l) for l in seules):
            return None
        touchees.update(range(i1 + 1, max(i2, i1 + 1) + 1))
    return sorted(touchees) if 0 < len(touchees) <= LIGNES_REPAREES else None


def _blocs(code: str, corrige: str) -> list[tuple[int, int, list[str]]]:
    """Les blocs que ``corrige`` change dans ``code`` : (début, fin) dans ``code``, lignes qui les remplacent ; un
    remplacement découpé ligne à ligne, le surplus d'un côté en un bloc à la fin, pour que ``minimiser`` puisse les
    séparer (un « print » ajouté après six lignes réparées faisait un seul bloc de sept, 20/10/2026)."""
    a, b = code.split("\n"), corrige.split("\n")
    res = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == "replace":
            n = min(i2 - i1, j2 - j1)
            res += [(i1 + k, i1 + k + 1, [b[j1 + k]]) for k in range(n)] + [(i1 + n, i2, b[j1 + n:j2])] * (i2 - i1 != j2 - j1)
        elif tag != "equal":
            res.append((i1, i2, b[j1:j2]))
    return res


def minimiser(code: str, corrige: str, passe) -> str:
    """``corrige`` ramené au moins de changements possible : chaque bloc changé (``_blocs``) est remis tel que l'élève
    l'a écrit, un à un, et le retour gardé tant que ``passe(programme)`` reste vrai (tous les tests). Le modèle élargit
    sa réparation (une ligne juste réécrite, un print ajouté) : sans ce retour, chaque ligne qu'il touche en trop coûte
    sa part à l'élève (TODO « Correction du code ligne à ligne », E ; mesuré le 20/10/2026 : 14 réparations sur 15 à la
    note de vérité, contre 12 sans).

    Puis chaque ligne que la réparation AJOUTE est essayée seule à chaque autre place, insérée ou à la place d'une
    ligne, et l'essai qui passe, ramené à son tour, est gardé s'il change moins de lignes : le modèle écrit souvent la
    ligne oubliée après le ``print`` de l'élève, avec un second ``print``, ce que le retour seul ne sait pas défaire
    (échantillon v2 du 20/10/2026 : 4 réparations d'Opus sur 24 notées sous la vérité pour cette raison). Dans une
    ligne remplacée, chaque retouche (au caractère) est enfin remise telle que l'élève l'a écrite si les tests passent
    encore : un espace retiré en fin de chaîne coûtait sa part (``part_lignes`` juge au caractère, même échantillon)."""
    lignes = code.split("\n")

    def appliquer(retenus: list[tuple[int, int, list[str]]]) -> str:
        a = list(lignes)
        for i1, i2, rempl in sorted(retenus, reverse=True):
            a[i1:i2] = rempl
        return "\n".join(a)

    def ramener(corrige: str) -> str:
        blocs = _blocs(code, corrige)
        for bloc in list(blocs):
            essai = [b for b in blocs if b is not bloc]
            if essai and passe(appliquer(essai)):
                blocs = essai
        for n, (i1, i2, rempl) in enumerate(blocs):  # une ligne remplacée : ses retouches remises une à une
            if i2 - i1 != 1 or len(rempl) != 1:
                continue
            ligne, reprise = rempl[0], True
            while reprise:
                reprise = False
                for tag, a1, a2, b1, b2 in difflib.SequenceMatcher(None, lignes[i1], ligne, autojunk=False).get_opcodes():
                    avant = lignes[i1][a1:a2]
                    if not avant and not ligne[b1:b2].strip():  # un espace inséré : l'enlever ne rend rien à l'élève
                        continue
                    bords = avant[:len(avant) - len(avant.lstrip())] + ligne[b1:b2].strip() + avant[len(avant.rstrip()):]
                    # « * » -> « + », avec les espaces de l'élève ; pas « ) » -> « + 1 » : plus qu'un signe remplacé
                    essais = (ligne[:b1] + avant + ligne[b2:],) + ((ligne[:b1] + bords + ligne[b2:],) if len(ligne[b1:b2].split()) == 1 else ())
                    for essai in essais:
                        if tag == "equal" or essai in (lignes[i1], ligne):
                            continue
                        blocs[n] = (i1, i2, [essai])
                        if passe(appliquer(blocs)):
                            ligne, reprise = essai, True
                            break
                        blocs[n] = (i1, i2, [ligne])
                    if reprise:
                        break
        return appliquer(blocs)

    def cout(corrige: str) -> tuple[int, int]:
        """Lignes changées, puis caractères : une ligne insérée à côté de celle qu'elle devait remplacer coûte autant de
        lignes, mais plus de caractères."""
        caracteres = sum(max(a2 - a1, b2 - b1) for tag, a1, a2, b1, b2
                         in difflib.SequenceMatcher(None, code, corrige, autojunk=False).get_opcodes() if tag != "equal")
        return sum(max(i2 - i1, len(rempl)) for i1, i2, rempl in _blocs(code, corrige)), caracteres
    meilleur, vus = ramener(corrige), set()
    while True:
        precedent = meilleur
        b = meilleur.split("\n")
        ajoutees = [j for tag, _, _, j1, j2 in difflib.SequenceMatcher(None, lignes, b, autojunk=False).get_opcodes()
                    if tag != "equal" for j in range(j1, j2) if b[j].strip()]
        for j in ajoutees:
            base = b[:j] + b[j + 1:]
            for p in range(len(base) + 1):
                for essai in (base[:p] + [b[j]] + base[p:], base[:p] + [b[j]] + base[p + 1:]):
                    texte = "\n".join(essai)
                    if texte not in vus and cout(texte) < cout(meilleur):
                        vus.add(texte)
                        if passe(texte):
                            meilleur = ramener(texte)
                            break
                if meilleur is not precedent:
                    break
            if meilleur is not precedent:
                break
        if meilleur is precedent:
            return _rattacher(lignes, meilleur, passe)


def _rattacher(lignes: list[str], corrige: str, passe) -> str:
    """``corrige`` où chaque ligne changée dont le code, sans commentaire, est celui d'une AUTRE ligne de l'élève reprend
    cette ligne entière, commentaire compris : son code a été déplacé, pas réécrit. Le retour au caractère de ``minimiser``
    laisse sinon chaque commentaire à sa place et récrit le code des lignes permutées sur place, aucune ligne de l'élève
    n'y reste entière (échantillon v2 du 20/10/2026, tp08_ex10 : sous la vérité pour Sonnet et pour Opus). Gardé si les
    tests passent et qu'il laisse plus de lignes de l'élève intactes, sans en changer plus."""
    def gardees_changees(t: list[str]) -> tuple[int, int]:
        ops = difflib.SequenceMatcher(None, lignes, t, autojunk=False).get_opcodes()
        return (sum(i2 - i1 for tag, i1, i2, _, _ in ops if tag == "equal"),
                sum(max(i2 - i1, j2 - j1) for tag, i1, i2, j1, j2 in ops if tag != "equal"))
    b = corrige.split("\n")
    libres = [l for l in lignes if l not in b]
    for k, ligne in enumerate(b):
        cle = sans_commentaire(ligne).strip()
        candidates = [l for l in libres if cle and ligne not in lignes and sans_commentaire(l).strip() == cle]
        if candidates:  # même code sur plusieurs lignes de l'élève : celle qui en garde le plus d'intactes
            l = max(candidates, key=lambda l: (lambda g, c: (g, -c))(*gardees_changees(b[:k] + [l] + b[k + 1:])))
            b[k] = l
            libres.remove(l)
    texte = "\n".join(b)
    (g0, c0), (g1, c1) = gardees_changees(corrige.split("\n")), gardees_changees(b)
    return texte if texte != corrige and g1 > g0 and c1 <= c0 and passe(texte) else corrige


def reparer(code: str) -> str | None:
    """``code`` réparé (au plus ``PROFONDEUR`` gestes, forme contrôlée par ``lignes_reparees``), ou None."""
    code = code.replace("\r\n", "\n").replace("\r", "\n")
    erreur = _erreur(code)
    if erreur is None:
        return None
    trouves: list[tuple[int, int, int, str]] = []  # (profondeur, rang, écart, programme)
    niveau = [(0, code, erreur)]
    vus = {code}
    for profondeur in range(1, PROFONDEUR + 1):
        suivant = []
        for rang0, source, e in niveau:
            for rang, lignes in _candidats(source.split("\n"), e):
                texte = "\n".join(lignes)
                if texte in vus:
                    continue
                vus.add(texte)
                e2 = _erreur(texte)
                if e2 is None:
                    if lignes_reparees(code, texte):
                        trouves.append((profondeur, rang0 + rang, _caracteres_changes(code, texte), texte))
                elif _position(e2) > _position(e):  # l'analyse bute plus loin : un pas dans le bon sens
                    suivant.append((_position(e2), rang0 + rang, texte, e2))
        if trouves:
            break
        suivant.sort(key=lambda s: (-s[0][0], -s[0][1], s[1]))
        niveau = [(r, t, e2) for _, r, t, e2 in suivant[:LARGEUR]]
    return min(trouves)[3] if trouves else None


def main():
    if sys.argv[1:] == ["--enfant"]:
        return enfant()
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujet", nargs="?", type=Path, help="paquet élève ou sujet")
    analyseur.add_argument("dossier", nargs="?", type=Path, help="dossier des fichiers de l'élève")
    analyseur.add_argument("--lot", type=Path, help="dossier des rendus : un sous-dossier par élève")
    analyseur.add_argument("--solutions", type=Path, nargs="+", help="banques dont vérifier les solutions")
    analyseur.add_argument("--mot-de-passe", help="mot de passe du paquet .qcm (défaut : celui des sujets d'entraînement)")
    analyseur.add_argument("--python", default=sys.executable, help="interpréteur de l'élève (défaut : celui-ci)")
    a = analyseur.parse_args()
    if a.solutions:
        from modele import charger as charger_objet  # noqa: PLC0415 - import tardif : modele importe verifier
        echecs = [(b, *e) for b in a.solutions for e in solutions(charger_objet(b), a.python)]
        for banque, qid, messages in echecs:
            print(f"✘ {banque.name} {qid} : " + " ; ".join(messages))
        return 1 if echecs else 0
    if not a.sujet or not (a.dossier or a.lot):
        analyseur.error("il faut un sujet, et un dossier ou --lot")
    paquet = charger(a.sujet, a.mot_de_passe)
    if a.lot:
        print("eleve;exercice;points;sur")
        for eleve in sorted(p for p in a.lot.iterdir() if p.is_dir()):
            resultats = verifier(paquet, eleve, a.python)
            for r in resultats:
                print(f"{eleve.name};{r['id']};{r['obtenus']:g};{r['points']:g}")
            print(f"{eleve.name};total;{sum(r['obtenus'] for r in resultats):g};{sum(r['points'] for r in resultats):g}")
    else:
        afficher(verifier(paquet, a.dossier, a.python))
    return 0


if __name__ == "__main__":
    sys.exit(main())
