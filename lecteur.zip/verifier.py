"""Vérifie le travail d'un élève : exécute les tests des questions « code » sur ses fichiers.

    python verifier.py SUJET DOSSIER          tableau ✔ / ✘ par exercice, pour un élève
    python verifier.py SUJET --lot RENDUS     un sous-dossier par élève -> CSV eleve;exercice;points
    python verifier.py --solutions BANQUE     chaque solution de la banque contre ses propres tests

SUJET est un paquet élève (exporter_eleve.py) ou, chez le professeur, un sujet de sujets/. Chaque question
s'exécute dans son propre processus, sous délai de garde : une boucle infinie ou un input() de l'élève ne
bloque rien, et son code ne tourne jamais dans le programme appelant (éditeur, application). Le fichier
testé est le ``fichier`` de la question (``exercice_03.py``), à défaut celui du sujet (``tp.py``).

Le côté enfant n'utilise que la bibliothèque standard ; le côté parent lit le paquet avec modele.py (serializejson).
"""

import argparse
import ast
import builtins
import contextlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

import bac_a_sable

ICI = Path(__file__).resolve().parent
DELAI = 10  # secondes par question
MARQUE = "\x1eRESULTAT "  # préfixe de la ligne de résultat de l'enfant, que l'élève n'imprimera pas par hasard
SYMBOLES = {"reussi": "✔", "echec": "✘", "erreur": "✘", "absent": "·"}


# CÔTÉ ENFANT : un processus par question -------------------------------------------------------------------

def _ligne_eleve(exc, fichier, premiere=1):
    """« ligne 12 : » de la dernière trame qui est dans le fichier de l'élève, ou rien ; numérotée comme l'éditeur,
    dont la première ligne porte ``premiere`` (``Code.premiere_ligne``)."""
    trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == fichier]
    return f"ligne {trames[-1].lineno + premiere - 1} : " if trames else ""


def _decrire(exc):
    return f"{type(exc).__name__} : {exc}" if str(exc) else type(exc).__name__


class _FauxPyxel:
    """« import pyxel » charge pyxel_factice.py, même si le vrai est installé : pas de fenêtre, run() rend la main."""

    def find_spec(self, nom, chemin=None, cible=None):
        return importlib.util.spec_from_file_location("pyxel", ICI / "pyxel_factice.py") if nom == "pyxel" else None


def _arite(definition):
    """Le nombre de paramètres positionnels qu'accepte une ``def`` : (minimum, maximum), maximum infini avec ``*args``."""
    a = definition.args
    positionnels = len(a.posonlyargs) + len(a.args)
    return positionnels - len(a.defaults), float("inf") if a.vararg else positionnels


def fonction_choisie(source, solution, nom):
    """« Écrire une fonction qui… » sans nom imposé (``Code.fonction``) : le nom de la fonction de l'élève que les tests
    appellent sous ``nom``, celui de la solution. ``nom`` lui-même si l'élève l'a défini ; sinon, parmi ses fonctions de
    premier niveau qui acceptent autant d'arguments que celle de la solution, celle qu'aucune autre n'appelle (une
    auxiliaire est appelée par la fonction principale), la dernière écrite s'il en reste plusieurs. ``None`` sans
    candidate."""
    def definitions(code):
        return [n for n in ast.parse(code).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]

    eleve = definitions(source)
    if any(d.name == nom for d in eleve):
        return nom
    attendue = next(len(d.args.posonlyargs) + len(d.args.args) for d in definitions(solution) if d.name == nom)
    candidates = [d for d in eleve if _arite(d)[0] <= attendue <= _arite(d)[1]]
    appelees = {n.id for d in eleve for n in ast.walk(d) if isinstance(n, ast.Name) and n.id != d.name}
    racines = [d for d in candidates if d.name not in appelees] or candidates
    return racines[-1].name if racines else None


def _absent(exc, fichier, resultat):
    """Un nom cité par le test que l'élève n'a pas encore écrit : « pas commencé », pas une erreur.
    Un NameError levé dans SON code (variable mal orthographiée) reste une erreur."""
    if isinstance(exc, NameError) and not _ligne_eleve(exc, fichier):
        resultat["absents"] += 1
        resultat["messages"].append(f"{exc.name} n'est pas encore défini")
        return True
    return False


PRELUDE = "<prelude>"


def deposer(dossier, fichiers, permis):
    """Les fichiers de données du sujet (``Code.fichiers``, 1.55 des widgets de bac : le csv que le programme lit),
    écrits dans le dossier où il s'exécute AVANT le crochet d'audit, qui interdit ensuite d'écrire. Renvoie ``permis``
    élargi des modules que le sujet fournit (un ``outils.py`` : ``import outils``, 1.24)."""
    for nom, contenu in (fichiers or {}).items():
        (Path(dossier) / nom).write_text(contenu, encoding="utf-8")
    return {**permis, "modules": permis["modules"] | {nom[:-3] for nom in fichiers or {} if nom.endswith(".py")}}


def preluder(prelude, espace):
    """Exécute le code supposé disponible (``Code.prelude``, celui du professeur) dans l'espace de l'élève, AVANT le
    sien, et rend les noms qu'il y a posés : ``analyser`` les tient pour définis. Compilé à part, il ne décale pas les
    numéros de ligne de l'élève, et n'est pas analysé ; ses ``import`` ne sont pas bornés au programme de la classe.
    Une erreur y est celle du sujet : ``ErreurPrelude``."""
    if not prelude.strip():
        return set()
    avant, importer = set(espace), espace["__builtins__"]["__import__"]
    espace["__builtins__"]["__import__"] = builtins.__import__
    try:
        exec(compile(prelude, PRELUDE, "exec"), espace)  # noqa: S102 - le code du professeur
    except BaseException as exc:  # noqa: BLE001
        raise ErreurPrelude(f"le code fourni par le sujet échoue : {_decrire(exc)}") from exc
    finally:
        espace["__builtins__"]["__import__"] = importer
    return set(espace) - avant


class ErreurPrelude(Exception):
    """Le prélude d'une question ne s'exécute pas : la faute du sujet, pas de l'élève."""


class ErreurObserve(Exception):
    pass


VALEUR = "_valeur_"  # où l'exécution « par effet » garde la valeur de la dernière expression


def _compiler(source, fichier, effet):
    """``effet`` : la dernière instruction, si c'est une expression, est gardée dans ``VALEUR`` — ce que la console
    afficherait ; les numéros de ligne ne bougent pas."""
    arbre = ast.parse(source, fichier)
    if effet and arbre.body and isinstance(arbre.body[-1], ast.Expr):
        dernier = arbre.body[-1]
        arbre.body[-1] = ast.copy_location(ast.Assign([ast.Name(VALEUR, ast.Store())], dernier.value), dernier)
        ast.fix_missing_locations(arbre)
    return compile(arbre, fichier, "exec")


def _effet(espace, sortie, observe):
    """Ce qu'un code a produit : ce qu'il affiche, ou à défaut la valeur de sa dernière expression (``print(x)`` et
    ``x`` se valent), puis le ``repr`` de chaque expression d'``observe``, évaluée après lui."""
    valeur, vus = espace.pop(VALEUR, None), []
    for e in observe:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                vus.append(repr(eval(e, espace)))  # noqa: S307
        except BaseException as exc:  # noqa: BLE001
            raise ErreurObserve(f"{e} provoque une erreur : {_decrire(exc)}") from exc
    return [sortie.strip() or ("" if valeur is None else str(valeur)), *vus]


def _effet_solution(solution, prelude, observe):
    """L'effet de la solution du sujet, exécutée après le prélude dans un espace à elle (code du professeur, non borné)."""
    espace, sortie = {"__builtins__": dict(vars(builtins)), "__name__": "__eleve__"}, io.StringIO()
    preluder(prelude, espace)
    try:
        with contextlib.redirect_stdout(sortie):
            exec(_compiler(solution, "<solution>", True), espace)  # noqa: S102
        return _effet(espace, sortie.getvalue(), observe)
    except BaseException as exc:  # noqa: BLE001
        raise ErreurPrelude(f"la solution du sujet échoue : {_decrire(exc)}") from exc


def _lus(source):
    """Les noms que le code lit."""
    return {n.id for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}


def _ecart(obtenu, attendu, observe):
    """Le message du premier écart, sans la valeur attendue (ce serait donner la réponse) ; None s'il n'y en a pas."""
    if obtenu[0] != attendu[0]:
        return f"ton code affiche « {obtenu[0]} »" if obtenu[0] else "ton code n'affiche rien et ne donne aucune valeur"
    return next((f"après ton code, {e} vaut {o}" for e, o, a in zip(observe, obtenu[1:], attendu[1:]) if o != a), None)


# les mots de ``sans:`` et ``avec:`` qui ne sont pas des noms : boucles et opérateurs
SYNTAXE = {"for": ast.For, "while": ast.While, "//": ast.FloorDiv, "%": ast.Mod, "**": ast.Pow}


def forme_manquee(source, regle):
    """Le message d'une contrainte de FORME (``Code.forme``) que le code ne respecte pas, ``None`` s'il la respecte :
    « comprehension » (une liste, un ensemble ou un dictionnaire en compréhension), « recursive:f » (f s'appelle
    elle-même), « iterative:f » (f ne s'appelle pas), « sans:x » et « avec:x » (le nom, la méthode, la boucle for ou
    while, l'opérateur //, % ou ** x, absent ou présent). Le
    message redit la contrainte de l'énoncé, jamais comment la respecter."""
    noeuds = list(ast.walk(ast.parse(source)))
    genre, _, nom = regle.partition(":")

    def emploie(x):
        if x in SYNTAXE:
            return any(isinstance(n, SYNTAXE[x]) for n in noeuds)
        return any(isinstance(n, ast.Name) and n.id == x or isinstance(n, ast.Attribute) and n.attr == x for n in noeuds)

    if genre == "comprehension":
        if not any(isinstance(n, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)) for n in noeuds):
            return "l'énoncé demande une écriture en compréhension, ton code n'en contient aucune"
    elif genre in ("recursive", "iterative"):
        definitions = [n for n in noeuds if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == nom]
        recursive = any(isinstance(n, ast.Call) and nom in (getattr(n.func, "id", None), getattr(n.func, "attr", None))
                        for d in definitions for n in ast.walk(d))
        if genre == "recursive" and not recursive:
            return f"l'énoncé demande une fonction {nom} récursive : elle doit s'appeler elle-même"
        if genre == "iterative" and recursive:
            return f"l'énoncé demande une fonction {nom} itérative : elle ne doit pas s'appeler elle-même"
    elif genre == "sans" and emploie(nom):
        return f"l'énoncé interdit d'utiliser {nom}, que ton code emploie"
    elif genre == "avec" and not emploie(nom):
        return f"l'énoncé demande d'utiliser {nom}, que ton code n'emploie pas"
    return None


class _Delai(BaseException):  # pas une Exception : un ``except Exception`` de l'élève ne l'arrête pas
    pass


def termine(appel, secondes=1):
    """Pour ``tests_code`` (problème de l'arrêt, 1.40 des widgets de bac) : vrai si ``appel()`` rend la main en moins de
    ``secondes``, faux s'il tourne encore — il est alors interrompu, sans erreur ni message qui dévoile le dispositif.
    Une trace plutôt qu'un fil ou un signal : elle marche aussi dans le Web Worker du navigateur, et une boucle sans fin
    écrite par l'élève est vue comme un appel à la fonction donnée qui ne termine pas."""
    fin = time.monotonic() + secondes

    def trace(_cadre, _evenement, _argument):
        if time.monotonic() > fin:
            raise _Delai
        return trace
    ancienne = sys.gettrace()
    sys.settrace(trace)
    try:
        appel()
    except _Delai:
        return False
    finally:
        sys.settrace(ancienne)
    return True


def executer(fichier, tests, tests_code, classe="", autorises=None, prelude="", premiere=1, effet=False, observe=(),
             solution="", forme=(), fonction="", fichiers=None):
    """Charge le fichier de l'élève et passe les tests ; renvoie {reussis, total, absents, messages, erreur}.
    Le programme de l'élève est borné par bac_a_sable ; ``tests``, ``tests_code`` et ``prelude`` (le code du
    professeur) ne le sont pas. ``effet`` : un test de plus, l'effet du code comparé à celui de ``solution``
    (``Code.effet``). Chaque règle de ``forme`` est un test de plus, sur le texte du code (``forme_manquee``).
    ``fonction`` : le nom libre (``fonction_choisie``), la fonction de l'élève est aussi nommée ainsi pour les tests.
    ``fichiers`` : ceux du sujet (``Code.fichiers``), déposés à côté du programme (``deposer``)."""
    sys.meta_path.insert(0, _FauxPyxel())
    fichier = str(Path(fichier).resolve())
    os.chdir(Path(fichier).parent)
    sys.path.insert(0, str(Path(fichier).parent))
    permis = deposer(Path(fichier).parent, fichiers, bac_a_sable.programme(classe, autorises))  # avant l'effet de la solution
    total = len(tests) + bool(tests_code) + bool(effet) + len(forme)
    resultat = {"reussis": 0, "total": total, "absents": 0, "messages": [], "erreur": None}
    if effet:  # avant le programme de l'élève, qui pose le crochet d'audit
        try:
            attendu = _effet_solution(solution, prelude, observe)
        except ErreurPrelude as exc:
            resultat["erreur"] = str(exc)
            return resultat
    sortie = io.StringIO()
    espace = bac_a_sable.espace(permis, __name__="__eleve__", __file__=fichier)
    try:
        source = Path(fichier).read_text(encoding="utf-8")
        code = _compiler(source, fichier, effet)
        connus = preluder(prelude, espace)
        bac_a_sable.analyser(source, permis, fichier, connus, premiere)
        bac_a_sable.poser(Path(fichier).parent, (str(ICI / "pyxel_factice.py"),))  # le faux pyxel, seul fichier du projet lisible
        with contextlib.redirect_stdout(sortie):
            exec(code, espace)  # noqa: S102 - c'est le principe : exécuter le programme de l'élève
    except SyntaxError as exc:
        resultat["erreur"] = f"ligne {exc.lineno + premiere - 1} : erreur de syntaxe ({exc.msg})"
        return resultat
    except ErreurPrelude as exc:
        resultat["erreur"] = str(exc)
        return resultat
    except EOFError:
        resultat["erreur"] = "le programme attend une saisie au clavier (input) : impossible à vérifier automatiquement"
        return resultat
    except BaseException as exc:  # noqa: BLE001 - toute erreur de l'élève, SystemExit compris
        resultat["erreur"] = f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}"
        return resultat
    espace["__builtins__"] = builtins  # les tests du professeur ne sont pas bornés ; les fonctions de l'élève gardent les leurs
    if fonction:
        choisie = fonction_choisie(source, solution, fonction)
        if choisie is None:
            resultat["messages"].append("ton code ne définit aucune fonction qui prenne les paramètres demandés")
            return resultat
        espace[fonction] = espace[choisie]
    if effet:
        try:
            # « l'instruction qui donne 65.1 » : taper 65.1 aurait le même effet ; la réponse doit lire les données de
            # l'exercice dès que la solution le fait
            ecart = ("ton code n'utilise aucune donnée de l'exercice : il doit les lire, pas recopier le résultat"
                     if _lus(solution) & connus and not _lus(source) & connus
                     else _ecart(_effet(espace, sortie.getvalue(), observe), attendu, observe))
        except ErreurObserve as exc:  # une expression d'observe que le code de l'élève a rendue impossible
            ecart = f"après ton code, {exc}"
        if ecart:
            resultat["messages"].append(ecart)
        else:
            resultat["reussis"] += 1
    for regle in forme:
        manque = forme_manquee(source, regle)
        if manque:
            resultat["messages"].append(manque)
        else:
            resultat["reussis"] += 1
    espace["sortie"], espace["termine"] = sortie.getvalue(), termine
    if "pyxel" in sys.modules:
        espace.update(sys.modules["pyxel"].AIDES)
    for test in tests:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                obtenu = repr(eval(test["appel"], espace))  # noqa: S307
        except BaseException as exc:  # noqa: BLE001
            if not _absent(exc, fichier, resultat):
                resultat["messages"].append(test.get("message") or f"{test['appel']} provoque une erreur : "
                                            f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}")
            continue
        if obtenu == test["attendu"]:
            resultat["reussis"] += 1
        else:
            resultat["messages"].append(test.get("message") or f"{test['appel']} devrait valoir {test['attendu']}, ton code donne {obtenu}")
    if tests_code:
        lignes = tests_code.splitlines()
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                exec(compile(tests_code, "<tests>", "exec"), espace)  # noqa: S102
            resultat["reussis"] += 1
        except BaseException as exc:  # noqa: BLE001
            if _absent(exc, fichier, resultat):
                return resultat
            trames = [t for t in traceback.extract_tb(exc.__traceback__) if t.filename == "<tests>"]
            ligne = lignes[trames[-1].lineno - 1].strip() if trames else ""
            if isinstance(exc, AssertionError):
                resultat["messages"].append(str(exc) or f"test non passé : {ligne}")
            else:
                resultat["messages"].append(f"{_ligne_eleve(exc, fichier, premiere)}{_decrire(exc)}" + (f" (pendant le test : {ligne})" if ligne else ""))
    return resultat


def _autoriseur(action, *_):
    """Le pendant SQL de bac_a_sable : le crochet d'audit de Python ne voit pas sqlite3, qui ouvrirait un fichier
    par son propre code C. Refuser ATTACH, DETACH et PRAGMA enferme la requête dans la base en mémoire."""
    import sqlite3  # noqa: PLC0415 - ici et dans les deux suivantes : le lecteur du navigateur (Pyodide-Qt, sans sqlite3) importe ce module pour lancer l'enfant

    return sqlite3.SQLITE_DENY if action in (sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH, sqlite3.SQLITE_PRAGMA) else sqlite3.SQLITE_OK


def jeu_sql(base, prelude=""):
    """Le script du jeu de données d'une question sql : sa ``base``, puis son ``prelude`` (vues, lignes ajoutées…)."""
    return base + ("\n" + prelude if prelude.strip() else "")


def base_sql(base):
    """Une base ``:memory:`` neuve où le script ``base`` (CREATE/INSERT) a été rejoué, l'autoriseur posé APRÈS lui :
    c'est la requête de l'élève qu'on borne, pas le jeu de données du sujet. Partagée avec la console du lecteur."""
    import sqlite3  # noqa: PLC0415

    connexion = sqlite3.connect(":memory:")
    connexion.executescript(base)
    connexion.set_authorizer(_autoriseur)
    return connexion


def decouper_sql(texte):
    """Les requêtes d'un texte, découpées comme SQLite les découpe : un ``;`` dans une chaîne ne coupe pas."""
    import sqlite3  # noqa: PLC0415

    requetes, courante = [], ""
    for ligne in texte.splitlines(keepends=True):
        courante += ligne
        if sqlite3.complete_statement(courante):
            requetes.append(courante)
            courante = ""
    return requetes + ([courante] if courante.strip() else [])


def _projections(obtenu, attendu):
    """Les lignes d'``obtenu`` ramenées aux colonnes d'``attendu``, dans son ordre (``colonnes_libres``, 1.10 des widgets
    de bac) : chaque colonne attendue est cherchée parmi celles qui portent les mêmes valeurs, une colonne ne sert qu'une
    fois. Rien si les nombres de lignes diffèrent : la comparaison échouera de toute façon."""
    import itertools  # noqa: PLC0415

    if not obtenu or not attendu or len(obtenu) != len(attendu):
        return
    def valeurs(lignes, j):
        return sorted((ligne[j] for ligne in lignes), key=repr)
    candidates = [[i for i in range(len(obtenu[0])) if valeurs(obtenu, i) == valeurs(attendu, j)] for j in range(len(attendu[0]))]
    for choix in itertools.product(*candidates):
        if len(set(choix)) == len(choix):
            yield [tuple(ligne[i] for i in choix) for ligne in obtenu]


def executer_sql(requete, base, tests, ordonne=False, colonnes_libres=False, doublons_libres=False, controle="", solution=""):
    """Exécute la requête de l'élève sur ``base`` et compare les LIGNES du résultat, jamais le texte de la requête.

    ``base`` est un script ``CREATE TABLE … ; INSERT …`` rejoué dans une base ``:memory:`` NEUVE à chaque test, si
    bien qu'un test ne subit pas l'état laissé par le précédent. Un test dont l'``appel`` est vide juge le résultat
    de la requête de l'élève ; sinon ``appel`` est une requête de contrôle jouée APRÈS elle, ce qui couvre les
    INSERT, UPDATE et DELETE, qui ne rendent rien mais laissent une trace. ``attendu`` est le ``repr()`` de la liste
    de tuples attendue ; l'ordre des lignes est indifférent sauf si ``ordonne``.

    La réponse peut enchaîner plusieurs requêtes (1.2 des widgets de bac : « écrire, dans le bon ordre, les requêtes… ») :
    elles sont jouées dans l'ordre, la première erreur arrête tout (une clé étrangère violée, si la base pose
    ``PRAGMA foreign_keys = ON``), et le résultat jugé est celui de la dernière qui rend des lignes.

    ``colonnes_libres`` : le résultat de l'élève peut porter d'autres colonnes que celles d'``attendu``, dans un autre
    ordre (« la liste des trajets… », où choisir ses colonnes est légitime) ; une requête de contrôle, elle, reste
    comparée telle quelle.

    ``doublons_libres`` : une ligne répétée compte pour une (avec ou sans DISTINCT, 1.49 des widgets de bac). ``controle`` :
    des INSERT CACHÉS ajoutés à la base pour un test de plus, dont l'attendu est le résultat de ``solution`` : la base du
    sujet ne discrimine pas toujours (toutes ses lignes passent le WHERE), et l'élève ne voit qu'elle."""
    resultat = {"reussis": 0, "total": len(tests) + bool(controle), "absents": 0, "messages": [], "erreur": None}
    if not requete.strip():
        resultat["erreur"] = "aucune requête écrite"
        return resultat
    import sqlite3  # noqa: PLC0415

    try:
        base_sql(base).close()  # d'abord le jeu de données : sinon son erreur serait imputée à l'élève
    except sqlite3.Error as exc:
        resultat["erreur"] = f"le jeu de données du sujet est refusé par SQLite : {_decrire(exc)}"
        return resultat

    def jouer(script, requetes, appel=""):
        connexion = base_sql(script)
        try:
            obtenu = []
            for instruction in decouper_sql(requetes):
                curseur = connexion.execute(instruction)
                if curseur.description:
                    obtenu = curseur.fetchall()
            return connexion.execute(appel).fetchall() if appel.strip() else obtenu
        finally:
            connexion.close()

    def egal(lignes, attendu):
        if doublons_libres:
            lignes, attendu = list(dict.fromkeys(lignes)), list(dict.fromkeys(attendu))
        return (lignes == attendu) if ordonne else (sorted(lignes, key=repr) == sorted(attendu, key=repr))

    def juste(obtenu, attendu, appel=""):
        return egal(obtenu, attendu) or (colonnes_libres and not appel.strip()
                                         and any(egal(p, attendu) for p in _projections(obtenu, attendu)))

    for test in tests:
        try:
            obtenu = jouer(base, requete, test["appel"])
        except sqlite3.Error as exc:
            resultat["messages"].append(test.get("message") or f"ta requête provoque une erreur SQL : {_decrire(exc)}")
            continue
        try:
            attendu = [tuple(ligne) for ligne in ast.literal_eval(test["attendu"])]
        except (ValueError, SyntaxError):
            resultat["messages"].append(f"attendu illisible dans le sujet : {test['attendu']}")
            continue
        if juste(obtenu, attendu, test["appel"]):
            resultat["reussis"] += 1
        else:
            quoi = f"la requête de contrôle « {test['appel']} » donne" if test["appel"].strip() else "ta requête donne"
            resultat["messages"].append(test.get("message") or f"{quoi} {obtenu}, on attendait {attendu}")
    if controle:
        try:
            attendu = jouer(base + "\n" + controle, solution)
        except sqlite3.Error as exc:
            resultat["messages"].append(f"la solution du sujet échoue sur les lignes de contrôle : {_decrire(exc)}")
            return resultat
        try:
            ok = juste(jouer(base + "\n" + controle, requete), attendu)
        except sqlite3.Error:
            ok = False
        if ok:
            resultat["reussis"] += 1
        else:  # sans les lignes ni le résultat : ce serait donner la réponse
            resultat["messages"].append("sur d'autres lignes que celles du sujet, ta requête ne donne pas le bon résultat : "
                                        "vérifie qu'elle filtre bien selon la condition demandée")
    return resultat

def enfant():
    demande = json.loads(sys.stdin.read())
    sys.stdin = io.StringIO()  # un input() de l'élève lève EOFError au lieu d'attendre
    if demande.get("langage") == "sql":
        resultat = executer_sql(Path(demande["fichier"]).read_text(encoding="utf-8"),
                                jeu_sql(demande.get("base", ""), demande.get("prelude", "")),
                                demande.get("tests", []), demande.get("ordonne", False),
                                demande.get("colonnes_libres", False), demande.get("doublons_libres", False),
                                demande.get("controle", ""), demande.get("solution", ""))
    else:
        resultat = executer(demande["fichier"], demande.get("tests", []), demande.get("tests_code", ""),
                            demande.get("classe", ""), demande.get("autorises"), demande.get("prelude", ""),
                            demande.get("premiere_ligne", 1), demande.get("effet", False), demande.get("observe", []),
                            demande.get("solution", ""), demande.get("forme", []), demande.get("fonction", ""),
                            demande.get("fichiers"))
    sys.__stdout__.write("\n" + MARQUE + json.dumps(resultat) + "\n")


# CÔTÉ PARENT -----------------------------------------------------------------------------------------------

def a_verifier(questions):
    """Les questions « code » et « sql » qui ont des tests, sous-questions de groupe comprises (``questions`` :
    celles d'un paquet élève ou d'une banque)."""
    return [f for q in questions for f in q.feuilles() if f.type in ("code", "sql") and f.testee()]


def verifier_question(q, dossier, fichier_defaut, python=sys.executable, classe=""):
    """{id, fichier, etat, points, obtenus, messages} ; etat : reussi, echec, erreur ou absent. ``classe`` fixe ce
    que le programme a le droit d'employer (bac_a_sable.programme), sauf si la question a sa propre liste."""
    nom = q.fichier or fichier_defaut
    fichier = Path(dossier) / nom
    base = {"id": q.id, "fichier": nom, "points": q.points, "obtenus": 0}
    if not fichier.is_file():
        return {**base, "etat": "absent", "messages": [f"{nom} n'existe pas encore"]}
    demande = json.dumps({"fichier": str(fichier), "tests": [vars(t) for t in q.tests], "tests_code": q.tests_code,
                          "classe": classe, "autorises": q.autorises, "langage": q.langage,
                          "base": q.script_base(), "ordonne": getattr(q, "ordonne", False), "colonnes_libres": getattr(q, "colonnes_libres", False),
                          "doublons_libres": getattr(q, "doublons_libres", False), "controle": getattr(q, "controle", ""),
                          "prelude": q.prelude_source(), "premiere_ligne": q.premiere_ligne,
                          "effet": q.effet, "observe": q.observe, "forme": q.forme, "fonction": q.fonction,
                          "fichiers": q.fichiers,
                          "solution": q.solution if q.effet or q.fonction or getattr(q, "controle", "") else ""})
    try:
        fini = subprocess.run([python, str(ICI / "verifier.py"), "--enfant"], input=demande, capture_output=True,
                              text=True, encoding="utf-8", timeout=DELAI)
    except subprocess.TimeoutExpired:
        return {**base, "etat": "erreur", "messages": [f"le programme ne s'est pas terminé en {DELAI} s : boucle infinie ?"]}
    lignes = [ligne for ligne in fini.stdout.split("\n") if ligne.startswith(MARQUE)]
    if not lignes:  # l'enfant est mort sans répondre : sortie brutale (os._exit), plantage de Python…
        return {**base, "etat": "erreur", "messages": [f"le programme s'est arrêté brutalement (code {fini.returncode})"
                                                       + (f" : {fini.stderr.strip().splitlines()[-1]}" if fini.stderr.strip() else "")]}
    r = json.loads(lignes[-1][len(MARQUE):])
    if r["erreur"]:
        return {**base, "etat": "erreur", "messages": [r["erreur"]]}
    if getattr(q, "commentaires", None):  # une note par commentaire attendu, lue dans le texte et non à l'exécution
        manques = q.commentaires_manques(fichier.read_text(encoding="utf-8"))
        r = {**r, "reussis": r["reussis"] + len(q.commentaires) - len(manques), "total": r["total"] + len(q.commentaires),
             "messages": r["messages"] + manques}
    etat = ("reussi" if r["reussis"] == r["total"] else "absent" if r["absents"] == r["total"] else "echec")
    return {**base, "etat": etat, "obtenus": round(base["points"] * r["reussis"] / r["total"], 2), "messages": r["messages"]}


def verifier(paquet, dossier, python=sys.executable):
    return [verifier_question(q, dossier, paquet.fichier, python, paquet.classe) for q in a_verifier(paquet.questions())]


def charger(chemin, mot_de_passe=None):
    """Un paquet élève (chiffré : ``mot_de_passe``), ou un sujet de sujets/ (chez le professeur, qui a les banques) converti en paquet."""
    import codes  # noqa: PLC0415
    from modele import Paquet  # noqa: PLC0415 - seulement côté parent : l'enfant n'importe pas Qt
    from modele import charger as charger_objet  # noqa: PLC0415
    cle = str(chemin).endswith(".qcm") and (mot_de_passe or codes.cle_du_fichier(chemin))
    objet = charger_objet(chemin, cle or None)
    if isinstance(objet, Paquet):
        return objet
    from exporter_eleve import paquet  # noqa: PLC0415 - seulement chez le professeur
    from sujet import Sujet  # noqa: PLC0415
    return paquet(Sujet(chemin)).nommer("")  # préparé comme pour un élève, variables tirées


def afficher(resultats):
    for r in resultats:
        print(f"{SYMBOLES[r['etat']]} {r['id']:<40} {r['obtenus']:>5g} / {r['points']:<3g} {r['fichier']}")
        for message in r["messages"]:
            print(f"      {message}")
    print(f"total : {sum(r['obtenus'] for r in resultats):g} / {sum(r['points'] for r in resultats):g}")


def solutions(banque, python=sys.executable):
    """Chaque solution de la banque (objet ``Banque``, déjà chargée) contre ses propres tests ; renvoie
    [(id, messages)] de celles qui échouent."""
    echecs = []
    for q in a_verifier(banque.questions):
        with tempfile.TemporaryDirectory() as dossier:
            (Path(dossier) / (q.fichier or "tp.py")).write_text(q.solution, encoding="utf-8")
            r = verifier_question(q, dossier, "tp.py", python, banque.niveau)
        if r["etat"] != "reussi":
            echecs.append((q.id, r["messages"]))
    return echecs


def main():
    if sys.argv[1:] == ["--enfant"]:
        return enfant()
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujet", nargs="?", type=Path, help="paquet élève ou sujet")
    analyseur.add_argument("dossier", nargs="?", type=Path, help="dossier des fichiers de l'élève")
    analyseur.add_argument("--lot", type=Path, help="dossier des rendus : un sous-dossier par élève")
    analyseur.add_argument("--solutions", type=Path, nargs="+", help="banques dont vérifier les solutions")
    analyseur.add_argument("--mot-de-passe", help="mot de passe du paquet .qcm (défaut : celui des sujets d'entraînement)")
    analyseur.add_argument("--python", default=sys.executable, help="interpréteur de l'élève (défaut : celui-ci)")
    a = analyseur.parse_args()
    if a.solutions:
        from modele import charger as charger_objet  # noqa: PLC0415 - import tardif : modele importe verifier
        echecs = [(b, *e) for b in a.solutions for e in solutions(charger_objet(b), a.python)]
        for banque, qid, messages in echecs:
            print(f"✘ {banque.name} {qid} : " + " ; ".join(messages))
        return 1 if echecs else 0
    if not a.sujet or not (a.dossier or a.lot):
        analyseur.error("il faut un sujet, et un dossier ou --lot")
    paquet = charger(a.sujet, a.mot_de_passe)
    if a.lot:
        print("eleve;exercice;points;sur")
        for eleve in sorted(p for p in a.lot.iterdir() if p.is_dir()):
            resultats = verifier(paquet, eleve, a.python)
            for r in resultats:
                print(f"{eleve.name};{r['id']};{r['obtenus']:g};{r['points']:g}")
            print(f"{eleve.name};total;{sum(r['obtenus'] for r in resultats):g};{sum(r['points'] for r in resultats):g}")
    else:
        afficher(verifier(paquet, a.dossier, a.python))
    return 0


if __name__ == "__main__":
    sys.exit(main())
