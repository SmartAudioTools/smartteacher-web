"""Le site d'une application qtpy6 écrite pour le bureau, sans rien y changer : ``python -m qtpy6.web.construire app.py``
écrit dans ``site/`` la page (``js/gabarit.html``, qui lance le script comme ``python app.py`` : ``qtpy6.web.lancer``),
le chargeur ``qtpy6web.js`` et ``app.zip`` (le dossier du script, qtpy6 et ce qu'on y ajoute). Reste à servir ``site/``
(ou le vérifier : ``python -m qtpy6.web.sonde site/index.html capture.png``).

    python -m qtpy6.web.construire app.py [site] [--pyodide URL] [--paquet nom]… [--distribution nom]… [--police f]…
                                   [--titre texte]

``--pyodide`` : où la page charge Pyodide-Qt (l'hébergement de qtpy6 par défaut ; ``./pyodide-qt/`` pour un dossier
servi avec la page). ``--paquet`` : un paquet pur Python importable ici, pris tel qu'installé (``assembler``) ;
``--distribution`` : idem avec ses métadonnées (points d'entrée) ; ``--police`` : un .ttf/.otf, sous ``polices/`` —
Qt-WASM embarque déjà DejaVu Sans et DejaVu Sans Mono, une application n'en a besoin que pour une autre police.
Le dossier du script est pris entier, sauf les fichiers et dossiers cachés, ``__pycache__`` et le site lui-même."""

import argparse
import importlib.resources
import json
from pathlib import Path

from .assembler import assembler

PYODIDE_QT = "https://smartaudiotools.github.io/qtpy6/pyodide-qt/"
DOSSIER = "/home/pyodide/app"


def construire(script, site="site", pyodide=PYODIDE_QT, paquets=(), distributions=(), polices=(), titre=None):
    """Écrit ``site/index.html``, ``site/qtpy6web.js`` et ``site/app.zip`` ; rend la taille de l'archive en octets."""
    script, site = Path(script).resolve(), Path(site).resolve()
    site.mkdir(parents=True, exist_ok=True)
    racine = script.parent
    fichiers = {str(p.relative_to(racine)): p for p in sorted(racine.rglob("*"))
                if p.is_file() and site not in p.parents and "__pycache__" not in p.parts
                and not any(part.startswith(".") for part in p.relative_to(racine).parts)}
    taille = assembler(site / "app.zip", fichiers, paquets=("qtpy6", *paquets), distributions=distributions,
                       polices=polices)
    js = importlib.resources.files("qtpy6.web") / "js"
    page = (js / "gabarit.html").read_text(encoding="utf-8")
    for avant, apres in (('"./pyodide-qt/"', json.dumps(pyodide)),
                         ('"/home/pyodide/app/app.py"', json.dumps(f"{DOSSIER}/{script.name}")),
                         ("<title>Application</title>", f"<title>{titre or script.stem}</title>")):
        assert page.count(avant) == 1, avant  # le gabarit a changé sans ce module
        page = page.replace(avant, apres)
    (site / "index.html").write_text(page, encoding="utf-8")
    (site / "qtpy6web.js").write_text((js / "qtpy6web.js").read_text(encoding="utf-8"), encoding="utf-8")
    return taille


def main(argv=None):
    a = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    a.add_argument("script")
    a.add_argument("site", nargs="?", default="site")
    a.add_argument("--pyodide", default=PYODIDE_QT)
    a.add_argument("--paquet", action="append", default=[])
    a.add_argument("--distribution", action="append", default=[])
    a.add_argument("--police", action="append", default=[])
    a.add_argument("--titre")
    o = a.parse_args(argv)
    taille = construire(o.script, o.site, o.pyodide, o.paquet, o.distribution, o.police, o.titre)
    print(f"{o.site}/ : index.html, qtpy6web.js, app.zip ({taille // 1024} Kio)")


if __name__ == "__main__":
    main()
