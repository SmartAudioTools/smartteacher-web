"""La page dans Firefox (ou Chromium) sans interface, pour vérifier une application sans écran ni clic : sert un dossier en local,
ouvre la page, attend qu'elle pose ``window.etat`` (l'état attendu, ou "erreur"), imprime son ``window.journal``, capture
l'écran, puis écrit chaque image de ``window.captures`` (``{suffixe: png_en_base64}`` : le ``grab()`` d'une fenêtre
Qt, par exemple) en ``<capture>_<suffixe>.png``. Le code de retour dit si l'état attendu a été atteint. La console de la
page s'écrit au fil de l'eau dans ``<capture>.console.log`` : le seul relevé d'une page qui gèle.

    python -m qtpy6.web.sonde page.html?param=x capture.png [--racine DIR] [--delai 120] [--etat fini]
                             [--taille 1000x900] [--zoom 2] [--tactile] [--visible] [--chromium]
                             [--glisser X1,Y1,X2,Y2 | --glisser page] [--pilote]

``page`` est relative à ``--racine`` (le dossier de la page par défaut), servie par http.server : une page ouverte en
file:// n'a ni modules ni fetch. ``--taille`` : la fenêtre en pixels CSS (Firefox ne descend pas sous 500 de large : une
largeur de téléphone se mesure en natif hors écran, ou avec ``--zoom``) ; ``--zoom`` : le zoom du navigateur ou l'écran
HiDPI (``layout.css.devPixelsPerPx``, la capture en est multipliée) ; ``--tactile`` : un écran au doigt (le seul pointeur
est « coarse », ce que ``tactile.detecte`` voit, et les événements touch sont activés) ; ``--visible`` : une vraie fenêtre
sur l'écran, avec son compositeur et sa synchronisation verticale, pour mesurer la fluidité (hors écran, Firefox cadence
ses images seul). ``--glisser`` : une fois l'état atteint, un glissé souris réel (enfoncé en X1,Y1, dix déplacements,
relâché en X2,Y2, en pixels CSS de la fenêtre), puis la capture : un défaut de glisser-déposer propre à un navigateur.
``--glisser page`` : les points viennent de la page (``window.glisser = [x1, y1, x2, y2]``, posé avec l'état attendu), la
sonde pose ``window.etat = "glissé"`` une fois le glissé fait, et attend que la page finisse (``"fini"``) : c'est la page
qui vérifie le résultat du glissé, et un test automatique qui en dépend. ``--pilote`` : pendant que la page tourne, ses
demandes de gestes réels, qu'un événement synthétique de Qt ne remplace pas (un slot qu'un vrai clic déclenche est reporté
par ``bloquant``, pas celui de ``click()``) : ``window.etat = "cliquer"`` (en ``window.clic = [x, y]``, pixels CSS) ou
``"taper"`` (``window.texte``, au clavier, là où est le focus), ``"raccourci"`` (Ctrl + ``window.touche``, « c », « x »
ou « v »), ``"glisser"`` (un glissé souris réel de ``window.glisser = [x1, y1, x2, y2]``, une sélection de texte à la
souris par exemple), ``"fichier"`` (``window.fichier = {nom, texte}``, déposé
dans le sélecteur de fichiers que la page vient d'ouvrir par ``QFileDialog.getOpenFileName``) ou ``"recharger"`` (la page
rechargée, sans réponse : elle repart de zéro et reconnaît un second passage à ce qu'elle retrouve) ; la sonde fait le
geste et répond ``window.etat`` suivi de ``"_fait"``, puis la page poursuit.

Firefox par défaut, parce que Chromium n'ouvre pas sans socket Unix (son verrou d'instance unique,
``process_singleton_posix``), ce qu'un bac à sable peut interdire. ``--chromium`` passe par QtWebEngine, le même moteur
Blink sans ce verrou (Chrome 140 pour Qt 6.11) : un Python qui a ``PyQt6.QtWebEngineWidgets`` (celui de la sonde, sinon
``/usr/bin/python3``) ouvre la page hors écran, et la sonde la pilote par le protocole DevTools en TCP (websocket-client).
Ni zoom, ni tactile, ni fenêtre visible dans ce mode."""

import argparse
import base64
import http.server
import importlib.util
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path


def main(argv=None):
    a = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    a.add_argument("page")
    a.add_argument("capture")
    a.add_argument("--racine", help="le dossier servi (celui de la page par défaut)")
    a.add_argument("--delai", type=float, default=120, help="secondes avant d'abandonner")
    a.add_argument("--etat", default="fini", help="la valeur de window.etat attendue")
    a.add_argument("--taille", default="1000x900")
    a.add_argument("--zoom")
    a.add_argument("--tactile", action="store_true")
    a.add_argument("--visible", action="store_true", help="une vraie fenêtre sur l'écran, pas hors écran")
    a.add_argument("--chromium", action="store_true", help="le moteur Blink de QtWebEngine au lieu de Firefox")
    a.add_argument("--glisser", help="X1,Y1,X2,Y2, ou page (window.glisser) : un glissé souris une fois l'état atteint")
    a.add_argument("--sans-jspi", action="store_true", help="Firefox sans WebAssembly.Suspending : un navigateur trop ancien")
    a.add_argument("--pilote", action="store_true", help="les clics et frappes réels que la page demande (window.etat)")
    o = a.parse_args(argv)
    if o.chromium and (o.zoom or o.tactile or o.visible or o.sans_jspi):
        a.error("--chromium : ni --zoom, ni --tactile, ni --visible, ni --sans-jspi")

    chemin, _, requete = o.page.partition("?")
    racine = Path(o.racine).resolve() if o.racine else Path(chemin).resolve().parent
    relatif = Path(chemin).resolve().relative_to(racine) if o.racine else Path(chemin).name

    class Silencieux(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def end_headers(self):
            self.send_header("Access-Control-Allow-Origin", "*")  # comme GitHub Pages : un cadre isolé charge en CORS
            super().end_headers()

    serveur = http.server.ThreadingHTTPServer(("127.0.0.1", 0), lambda *args: Silencieux(*args, directory=str(racine)))
    threading.Thread(target=serveur.serve_forever, daemon=True).start()

    url = f"http://127.0.0.1:{serveur.server_port}/{relatif}{'?' + requete if requete else ''}"
    largeur, hauteur = o.taille.split("x")
    navigateur = Blink(url, int(largeur), int(hauteur)) if o.chromium else firefox(o, largeur, hauteur, url)
    attendu = o.etat
    try:
        debut = time.time()
        etat = attendre(navigateur, o.etat, debut + o.delai, o.pilote)
        if o.glisser and etat == o.etat:
            points = navigateur.execute_script("return window.glisser") if o.glisser == "page" else o.glisser.split(",")
            glisser(navigateur, *map(float, points))
            if o.glisser == "page":
                navigateur.execute_script("window.etat = 'glissé'")
                attendu = "fini"
                etat = attendre(navigateur, attendu, debut + o.delai)
        print("\n".join(navigateur.execute_script("return window.journal || []")))
        print("état :", etat, "; fenêtre", *navigateur.execute_script("return [innerWidth, innerHeight, devicePixelRatio]"),
              "; tactile" if navigateur.execute_script("return matchMedia('(any-pointer: coarse)').matches") else "; souris",
              "; " + navigateur.execute_script("return navigator.userAgent").split(") ")[-1])
        navigateur.save_screenshot(o.capture)
        for suffixe, b64 in (navigateur.execute_script("return window.captures || {}") or {}).items():
            Path(o.capture).with_stem(Path(o.capture).stem + "_" + suffixe).write_bytes(base64.b64decode(b64))
    finally:
        navigateur.quit()
        serveur.shutdown()
    return etat == attendu


def attendre(navigateur, etat, fin, pilote=False):
    """`window.etat` relu jusqu'à `etat` ou "erreur", ou "délai dépassé" à l'heure `fin` ; avec `pilote`, les gestes que
    la page demande en chemin (``GESTES``) faits au passage."""
    while time.time() < fin:
        lu = navigateur.execute_script("return window.etat")
        if lu in (etat, "erreur"):
            return lu
        if pilote and lu in GESTES:
            if GESTES[lu](navigateur) is not False:  # False : un geste qui ne se répond pas (recharger)
                # Compare-and-set : la page a pu reprendre pendant le geste (sur l'événement d'un dialogue) et demander
                # déjà le suivant ; un « _fait » posé par-dessus l'effacerait, et chacun attendrait l'autre (jalons 3 et 5).
                navigateur.execute_script(f"if (window.etat === '{lu}') window.etat = '{lu}_fait'")
            continue
        time.sleep(0.2 if pilote else 0.5)
    return "délai dépassé"


def cliquer(navigateur):
    """Un vrai clic gauche en ``window.clic`` (pixels CSS de la fenêtre)."""
    x, y = navigateur.execute_script("return window.clic")
    if isinstance(navigateur, Blink):
        for genre, boutons in (("mouseMoved", 0), ("mousePressed", 1), ("mouseReleased", 0)):
            navigateur.cdp("Input.dispatchMouseEvent", type=genre, x=x, y=y, button="left", buttons=boutons, clickCount=1)
    else:
        from selenium.webdriver.common.action_chains import ActionBuilder  # noqa: PLC0415

        actions = ActionBuilder(navigateur)
        actions.pointer_action.move_to_location(round(x), round(y)).click()
        actions.perform()
    repeint(navigateur)


def taper(navigateur):
    """``window.texte`` tapé au vrai clavier, touche par touche, là où le navigateur a le focus ; ``"\\n"`` est la touche
    Entrée (envoyé tel quel, le navigateur ferait un KeyboardEvent de touche ``"\\n"``, que Qt rend en Key 0xa au lieu de
    Key_Return : Spyder n'y voit pas une Entrée, et QPlainTextEdit n'insère pas ce caractère non imprimable)."""
    texte = navigateur.execute_script("return window.texte")
    if isinstance(navigateur, Blink):
        for c in texte:
            if c == "\n":
                navigateur.cdp("Input.dispatchKeyEvent", type="keyDown", key="Enter", code="Enter", windowsVirtualKeyCode=13, text="\r")
                navigateur.cdp("Input.dispatchKeyEvent", type="keyUp", key="Enter", code="Enter", windowsVirtualKeyCode=13)
            else:
                navigateur.cdp("Input.dispatchKeyEvent", type="keyDown", key=c, text=c)
                navigateur.cdp("Input.dispatchKeyEvent", type="keyUp", key=c)
    else:
        from selenium.webdriver.common.action_chains import ActionChains  # noqa: PLC0415
        from selenium.webdriver.common.keys import Keys  # noqa: PLC0415

        ActionChains(navigateur).send_keys(texte.replace("\n", Keys.ENTER)).perform()
    repeint(navigateur)


def raccourci(navigateur):
    """``window.touche`` (« c », « x », « v », ou une autre lettre : « f ») avec Ctrl, au vrai clavier, là où le navigateur a le focus. Blink piloté en
    DevTools ne déclenche pas seul la commande d'édition d'un raccourci : ``commands`` la lui donne, comme le clavier
    (les événements ``copy``, ``cut`` et ``paste`` de la page)."""
    c = navigateur.execute_script("return window.touche")
    if isinstance(navigateur, Blink):
        touche = dict(key=c, code="Key" + c.upper(), windowsVirtualKeyCode=ord(c.upper()), modifiers=2)
        commande = {"c": "copy", "x": "cut", "v": "paste"}.get(c)  # Ctrl+F n'a pas de commande d'édition : la page seule le voit
        navigateur.cdp("Input.dispatchKeyEvent", type="rawKeyDown", commands=[commande] if commande else [], **touche)
        navigateur.cdp("Input.dispatchKeyEvent", type="keyUp", **touche)
    else:
        from selenium.webdriver.common.action_chains import ActionChains  # noqa: PLC0415
        from selenium.webdriver.common.keys import Keys  # noqa: PLC0415

        ActionChains(navigateur).key_down(Keys.CONTROL).send_keys(c).key_up(Keys.CONTROL).perform()
    repeint(navigateur)


def glisse(navigateur):
    """Le glissé de ``window.glisser`` (``[x1, y1, x2, y2]``, pixels CSS), demandé en chemin par la page."""
    glisser(navigateur, *map(float, navigateur.execute_script("return window.glisser")))


def fichier(navigateur):
    """``window.fichier`` ({nom, texte}) déposé dans le sélecteur de fichiers que la page a ouvert (``bloquant.ELEMENT_FICHIERS``,
    déjà présent : la page ne rend la main qu'une fois suspendue dessus) : ce que l'utilisateur fait en choisissant un fichier
    de son disque. Écrit dans un dossier temporaire, qui reste : le navigateur ne lit le fichier qu'après le geste."""
    import tempfile  # noqa: PLC0415

    from .bloquant import ELEMENT_FICHIERS  # noqa: PLC0415

    f = navigateur.execute_script("return window.fichier")
    chemin = os.path.join(tempfile.mkdtemp(prefix="sonde-"), f["nom"])
    Path(chemin).write_text(f["texte"], encoding="utf-8")
    if isinstance(navigateur, Blink):
        # deux sélecteurs possibles : showOpenFilePicker (appel dans l'activation d'un clic), auquel l'hôte répond par
        # ``choix`` (``chooseFiles``, qui le consomme), ou le <input> de repli, qui n'apparaît qu'après le refus du premier
        Path(navigateur.choix).write_text(chemin, encoding="utf-8")
        fin = time.time() + 30
        while os.path.exists(navigateur.choix) and time.time() < fin:
            racine = navigateur.cdp("DOM.getDocument")["root"]["nodeId"]
            noeud = navigateur.cdp("DOM.querySelector", nodeId=racine, selector="#" + ELEMENT_FICHIERS)["nodeId"]
            if noeud:
                os.remove(navigateur.choix)
                navigateur.cdp("DOM.setFileInputFiles", files=[chemin], nodeId=noeud)
                break
            time.sleep(0.1)
    else:
        from selenium.webdriver.common.by import By  # noqa: PLC0415

        navigateur.find_element(By.ID, ELEMENT_FICHIERS).send_keys(chemin)
    repeint(navigateur)


def recharger(navigateur):
    """La page rechargée (F5), sans réponse « _fait » (rend False) : le nouveau document repart de zéro — son chargeur pose
    ``window.etat = "en cours"`` — et reconnaît un second passage à ce qu'il retrouve (IndexedDB, localStorage). Rend la
    main une fois le nouveau document chargé (Blink : rechargement asynchrone, attendu sur ce témoin et readyState)."""
    if isinstance(navigateur, Blink):
        navigateur.cdp("Page.reload")
        fin = time.time() + 60
        while time.time() < fin:
            try:
                if navigateur.execute_script("return document.readyState === 'complete' && window.etat !== 'recharger'"):
                    break
            except RuntimeError:  # l'évaluation tombe sur le document en cours de déchargement
                pass
            time.sleep(0.2)
    else:
        navigateur.refresh()  # bloque jusqu'au chargement du nouveau document
    return False


GESTES = {"cliquer": cliquer, "taper": taper, "raccourci": raccourci, "glisser": glisse, "fichier": fichier, "recharger": recharger}


def repeint(navigateur):
    navigateur.execute_script("return new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))")
    time.sleep(0.3)  # Qt-WASM traite l'événement dans sa boucle, puis repeint : deux images et un peu plus


def firefox(o, largeur, hauteur, url):
    from selenium import webdriver  # noqa: PLC0415 - la dépendance optionnelle [sonde]
    from selenium.webdriver.firefox.service import Service  # noqa: PLC0415

    options = webdriver.FirefoxOptions()
    # la console aussi dans <capture>.console.log, au fil de l'eau : le seul relevé d'une page qui gèle (le journal ne se
    # lit qu'à la fin, par execute_script, qu'une page gelée ne sert plus)
    options.set_preference("devtools.console.stdout.content", True)
    if not o.visible:
        options.add_argument("--headless")
    options.add_argument(f"--width={largeur}")
    options.add_argument(f"--height={hauteur}")
    if o.sans_jspi:
        options.set_preference("javascript.options.wasm_js_promise_integration", False)
    if o.zoom:
        options.set_preference("layout.css.devPixelsPerPx", o.zoom)
    if o.tactile:
        for pref in ("ui.primaryPointerCapabilities", "ui.allPointerCapabilities"):
            options.set_preference(pref, 1)  # 1 = coarse, sans hover : ce que répondent les media queries pointer/any-pointer
        options.set_preference("dom.w3c_touch_events.enabled", 1)
    navigateur = webdriver.Firefox(options=options, service=Service(log_output=os.path.splitext(o.capture)[0] + ".console.log"))
    navigateur.get(url)
    return navigateur


def glisser(navigateur, x1, y1, x2, y2, pas=10):
    """Enfoncé en (x1, y1), `pas` déplacements, relâché en (x2, y2) : de vrais événements souris du navigateur."""
    points = [(x1 + (x2 - x1) * k / pas, y1 + (y2 - y1) * k / pas) for k in range(1, pas + 1)]
    if isinstance(navigateur, Blink):
        souris = navigateur.cdp
        souris("Input.dispatchMouseEvent", type="mouseMoved", x=x1, y=y1)
        souris("Input.dispatchMouseEvent", type="mousePressed", x=x1, y=y1, button="left", buttons=1, clickCount=1)
        for x, y in points:
            souris("Input.dispatchMouseEvent", type="mouseMoved", x=x, y=y, button="left", buttons=1)
            time.sleep(0.03)
        souris("Input.dispatchMouseEvent", type="mouseReleased", x=x2, y=y2, button="left", buttons=0, clickCount=1)
    else:
        from selenium.webdriver.common.action_chains import ActionBuilder  # noqa: PLC0415

        actions = ActionBuilder(navigateur, duration=30)
        actions.pointer_action.move_to_location(x1, y1).pointer_down()
        for x, y in points:
            actions.pointer_action.move_to_location(round(x), round(y))
        actions.pointer_action.pointer_up()
        actions.perform()
    repeint(navigateur)


HOTE = """
import os, sys, time
from PyQt6.QtCore import QEventLoop, QUrl
from PyQt6.QtWebEngineCore import QWebEnginePage
from PyQt6.QtWidgets import QApplication
from PyQt6.QtWebEngineWidgets import QWebEngineView

class Page(QWebEnginePage):
    def chooseFiles(self, mode, anciens, types):  # showOpenFilePicker : le fichier du geste « fichier » (sys.argv[4])
        boucle, fin = QEventLoop(), time.time() + 30
        while not os.path.exists(sys.argv[4]) and time.time() < fin:
            boucle.processEvents(QEventLoop.ProcessEventsFlag.AllEvents, 100)
        if not os.path.exists(sys.argv[4]):
            return []
        with open(sys.argv[4], encoding="utf-8") as f:
            chemin = f.read()
        os.remove(sys.argv[4])
        return [chemin]

app = QApplication(sys.argv[:1])
vue = QWebEngineView()
vue.setPage(Page(vue))
vue.resize(int(sys.argv[2]), int(sys.argv[3]))
vue.setUrl(QUrl(sys.argv[1]))
vue.show()
app.exec()
"""


class Blink:
    """La page dans QtWebEngine hors écran, pilotée par le protocole DevTools : les trois méthodes de Selenium dont la
    sonde se sert (execute_script, save_screenshot, quit), plus `cdp` pour le reste."""

    def __init__(self, url, largeur, hauteur):
        import websocket  # noqa: PLC0415 - websocket-client, la dépendance de Selenium

        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
        python = sys.executable if importlib.util.find_spec("PyQt6.QtWebEngineWidgets") else "/usr/bin/python3"
        env = dict(os.environ, QT_QPA_PLATFORM="offscreen", QTWEBENGINE_DISABLE_SANDBOX="1",
                   # le zygote et le processus GPU veulent des sockets ; WebGL en rendu logiciel (SwiftShader) dans le
                   # processus : avec --disable-gpu, pas de contexte WebGL, Quick/Graphs/Quick3D rendaient vide (11/10/2026)
                   QTWEBENGINE_CHROMIUM_FLAGS="--no-zygote --in-process-gpu --ignore-gpu-blocklist --use-gl=angle "
                                              "--use-angle=swiftshader --enable-unsafe-swiftshader",
                   QTWEBENGINE_REMOTE_DEBUGGING=f"127.0.0.1:{port}")
        import tempfile  # noqa: PLC0415

        # stderr dans un fichier (un tube plein bloquerait Chromium, bavard) : sa fin dit pourquoi l'hôte est mort,
        # cause invisible du seul échec vu (0,9 s, suite complète du 20/10/2026), jamais reproduit depuis
        erreurs = tempfile.TemporaryFile()
        self.choix = os.path.join(tempfile.mkdtemp(prefix="sonde-choix-"), "choix")  # le geste « fichier » -> l'hôte
        self.processus = subprocess.Popen([python, "-c", HOTE, url, str(largeur), str(hauteur), self.choix], env=env,
                                          stdout=subprocess.DEVNULL, stderr=erreurs)
        sans_mandataire = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for _ in range(120):
            try:
                cibles = json.load(sans_mandataire.open(f"http://127.0.0.1:{port}/json"))
                page = next(c for c in cibles if c["type"] == "page")
                break
            except (OSError, StopIteration):
                if self.processus.poll() is not None:
                    erreurs.seek(0)
                    fin = erreurs.read().decode(errors="replace").strip().splitlines()[-5:]
                    raise RuntimeError(f"{python} : QtWebEngine n'a pas démarré (code {self.processus.returncode}) :\n"
                                       + "\n".join(fin)) from None
                time.sleep(0.5)
        else:
            raise RuntimeError("QtWebEngine : pas de page DevTools en 60 s")
        self.ws = websocket.create_connection(page["webSocketDebuggerUrl"], suppress_origin=True)
        self.n = 0

    DELAI = 60  # secondes sans réponse avant d'abandonner : sans borne, une page gelée figeait la sonde (un rejeu 2 h muet)

    def cdp(self, methode, **params):
        import websocket  # noqa: PLC0415

        self.n += 1
        self.ws.send(json.dumps({"id": self.n, "method": methode, "params": params}))
        fin = time.monotonic() + self.DELAI  # une échéance, pas un délai par recv : un événement sans id ne la repousse pas
        while True:
            try:
                self.ws.settimeout(max(fin - time.monotonic(), 0.01))
                r = json.loads(self.ws.recv())
            except websocket.WebSocketTimeoutException:
                raise TimeoutError(f"{methode} : pas de réponse en {self.DELAI} s, la page ne répond plus") from None
            if r.get("id") == self.n:
                if "error" in r:
                    raise RuntimeError(f"{methode} : {r['error']}")
                return r["result"]

    def execute_script(self, code):
        r = self.cdp("Runtime.evaluate", expression=f"(async () => {{ {code} }})()", awaitPromise=True,
                     returnByValue=True)
        return r["result"].get("value")

    def save_screenshot(self, chemin):
        Path(chemin).write_bytes(base64.b64decode(self.cdp("Page.captureScreenshot", format="png")["data"]))

    def quit(self):
        self.ws.close()
        self.processus.terminate()
        self.processus.wait()


if __name__ == "__main__":
    sys.exit(not main())
