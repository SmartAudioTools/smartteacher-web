"""L'écran se touche au doigt (téléphone, tablette, portable tactile) : les cibles de Qt, faites pour la souris (26 px),
montent à ``CIBLE`` (44 pt chez Apple, 48 dp chez Google) et la zone défilante suit le doigt. À activer AVANT de construire
les widgets : la feuille de style s'applique aux widgets à venir comme aux existants, mais les hauteurs déjà calculées
par les dispositions ne sont pas toutes refaites."""

import time

from qtpy6.QtCore import QAbstractAnimation, QEasingCurve, QEvent, QObject, QPropertyAnimation, Qt, QTimer
from qtpy6.QtGui import QInputDevice, QMouseEvent
from qtpy6.QtWidgets import QAbstractButton, QApplication, QPushButton, QScroller, QScrollerProperties, QWidget

from . import navigateur

CIBLE = 44  # la hauteur d'une cible au doigt, en pixels
ACTIF = False  # posé par ``activer`` : ``defiler_au_doigt`` et les applications le lisent


def detecte():
    """Un écran au doigt : téléphone, tablette, portable tactile. Dans le navigateur, parmi ses pointeurs (``any-pointer:
    coarse``) ou par le nombre de doigts qu'il sait suivre (``navigator.maxTouchPoints`` : un portable tactile dont la
    souris est le pointeur principal ne se dit pas toujours « coarse ») ; en natif, parmi les périphériques que Qt a
    recensés (``QInputDevice``, une ``QApplication`` doit exister). Un écran tactile dont personne ne se sert compte aussi :
    le navigateur fait de même. Certains navigateurs ne disent rien (Firefox sous Linux) : ``activer_au_doigt``."""
    if not navigateur():
        return any(d.type() == QInputDevice.DeviceType.TouchScreen for d in QInputDevice.devices())
    import js  # noqa: PLC0415 - le module de Pyodide, qui n'existe que dans le navigateur

    return bool(js.window.matchMedia("(any-pointer: coarse)").matches) or (js.navigator.maxTouchPoints or 0) > 0


def activer_au_doigt(app=None):
    """``activer`` tout de suite si l'écran se dit tactile (``detecte``) ; sinon, dans le navigateur, au premier doigt posé
    sur la page (``pointerdown`` de type ``touch``, écouté avant Qt) : le seul signe sûr quand le navigateur ne dit rien
    de son écran. ``activer`` attend que ce doigt se lève (``pointerup`` ou ``pointercancel``), puis que Qt ait traité ce
    lever : sa feuille remet la page en page, et appliquée sous le doigt posé elle déplaçait ce qu'il visait (un éditeur
    Parsons descendu de 170 px, l'appui reçu par l'énoncé au-dessus : le premier appui long ne prenait rien, R2 de la
    sonde ``redimensionner``, 09/10/2026). Ce premier geste se fait donc à la souris que Qt tire du doigt. Les widgets
    construits APRÈS ce doigt sont faits pour lui (sur un écran d'accueil, c'est l'application qui suit), ceux d'avant
    reçoivent la feuille de style sans toutes leurs hauteurs refaites (``activer``)."""
    if detecte():
        activer(app)
    elif navigateur():
        import js  # noqa: PLC0415
        from pyodide.ffi import create_proxy  # noqa: PLC0415
        from qtpy6.QtCore import QTimer  # noqa: PLC0415

        premier = []  # le pointerId de ce doigt : le lever d'un second doigt, posé pendant lui, n'active rien

        def doigt(evenement):
            if evenement.pointerType == "touch":
                premier.append(evenement.pointerId)
                js.window.removeEventListener("pointerdown", pose, True)
                for nom in ("pointerup", "pointercancel"):
                    js.window.addEventListener(nom, leve, True)

        def lever(evenement):
            if evenement.pointerId == premier[0]:
                for nom in ("pointerup", "pointercancel"):
                    js.window.removeEventListener(nom, leve, True)
                QTimer.singleShot(0, lambda: ACTIF or activer(app))  # après le lever que Qt reçoit de ce même événement

        pose, leve = create_proxy(doigt), create_proxy(lever)
        js.window.addEventListener("pointerdown", pose, True)  # en capture : avant le canevas de Qt


def activer(app=None, cible=CIBLE, case=None):
    """Boutons, listes déroulantes et champs montent à ``cible``, les cases et boutons radio grossissent (``case`` pixels :
    par défaut les 3/4 de ``cible``, un disque plein restant net dans le rond qui l'entoure ; à donner en pixels pour
    l'ajuster), les lignes d'une liste déroulée aussi, l'ascenseur s'élargit. La feuille est AJOUTÉE à celle de
    l'application, pas substituée. Les champs incrustés dans un texte (``QTextDocument``) gardent la hauteur de leur
    ligne : c'est à l'application de les espacer (``marge``)."""
    global ACTIF, CIBLE
    ACTIF, CIBLE = True, cible
    case = cible * 3 // 4 if case is None else case
    app = app or QApplication.instance()
    # Fusion ajoute 8 px de marges à un bouton et 6 à un champ : le padding les remplace, la hauteur donnée fait la cible
    app.setStyleSheet(app.styleSheet() + (
        f"QPushButton {{ min-height: {cible}px; padding: 0px 6px; }} QComboBox, QLineEdit {{ min-height: {cible - 6}px; }}"
        f"QCheckBox::indicator, QRadioButton::indicator {{ width: {case}px; height: {case}px; }}"
        f"QComboBox QAbstractItemView::item {{ min-height: {cible}px; }} QScrollBar:vertical {{ width: 18px; }}"))
    while _EN_ATTENTE:
        defiler_au_doigt(_EN_ATTENTE.pop(0))


def marge(souris=2, hauteur_ligne=26):
    """L'espace à ajouter au-dessus et au-dessous d'un widget d'une ligne (``hauteur_ligne`` px : texte 22, bordures et
    espace 4) pour qu'il fasse une cible au doigt ; ``souris`` sinon."""
    return (CIBLE - hauteur_ligne) // 2 if ACTIF else souris


def defiler_au_doigt(zone):
    """Une ``QScrollArea`` (ou tout ``QAbstractScrollArea``) que le doigt fait défiler, comme partout ailleurs sur un
    téléphone : sans cela, il ne fait rien. Avant ``activer``, la zone attend : ``activer`` l'accroche (un écran que le
    navigateur ne dit pas tactile, Chromium sous Linux, n'est activé qu'au premier doigt, souvent après la construction
    de la page : sans cette attente, rien n'y défilait au doigt, 05/10/2026). Dans le navigateur, la course après le
    lâcher suit les images de l'écran (``_Inertie``)."""
    if not ACTIF:
        _EN_ATTENTE.append(zone)
        zone.destroyed.connect(lambda *_: _EN_ATTENTE.remove(zone) if zone in _EN_ATTENTE else None)
        return
    QScroller.grabGesture(zone.viewport(), QScroller.ScrollerGestureType.TouchGesture)
    _SansClicAuGlisse(zone)
    if navigateur():
        _Inertie(zone)


class _SansClicAuGlisse(QObject):
    """Un glissé qui fait défiler la zone ne clique pas le bouton où le doigt s'est posé : ``QScroller`` laisse passer
    la souris que Qt tire du doigt, et le bouton, qui suit la page sous le doigt, se croyait relâché sur lui (SmartTeacher,
    26/11/2026 : « en scrolant sur la page d'accueil , on pouvait malencontreusement cliquer sur un sujet et l'ouvrir »).
    Dès que le doigt s'éloigne de plus de ``startDragDistance`` (positions GLOBALES, comme ``Toucher``), le bouton est
    relâché sans clic et la souris du geste ne lui parvient plus. Seuls les ``QAbstractButton`` : les widgets qui
    distinguent eux-mêmes un toucher d'un glissé (``Toucher``) reçoivent tout le geste. Un ``QPushButton`` à menu
    (jauges de révision de l'accueil) ouvrirait son menu dès l'appui : au doigt, l'appui ne lui parvient pas, et le menu
    s'ouvre au relâchement d'un toucher sur place.

    Écarté : relâcher le bouton au passage de ``QScroller`` en ``Dragging`` (un seuil au lieu de deux, filtre posé
    le temps du geste seulement) : le menu, ouvert à l'appui, serait déjà là ; l'appui doit donc être vu au filtre."""

    def __init__(self, zone):
        super().__init__(zone)
        self.vue, self.bouton, self.point, self.glisse = zone.viewport(), None, None, False
        QApplication.instance().installEventFilter(self)

    def eventFilter(self, objet, evenement):
        genre = evenement.type()
        if genre not in (QEvent.Type.MouseButtonPress, QEvent.Type.MouseMove, QEvent.Type.MouseButtonRelease):
            return False
        if genre == QEvent.Type.MouseButtonPress:
            bouton = objet if isinstance(objet, QAbstractButton) else None
            doigt = evenement.source() != Qt.MouseEventSource.MouseEventNotSynthesized
            dedans = bouton is not None and self.vue.isAncestorOf(bouton)
            self.bouton, self.point, self.glisse = (bouton, evenement.globalPosition(), False) if doigt and dedans else (None, None, False)
            return self.bouton is not None and self._a_menu(self.bouton)
        if objet is not self.bouton or self.point is None:
            return False
        if not self.glisse and (evenement.globalPosition() - self.point).manhattanLength() > QApplication.startDragDistance():
            self.glisse = True
            self.bouton.setDown(False)
        if genre == QEvent.Type.MouseButtonRelease:
            bouton, glisse, self.bouton, self.point, self.glisse = self.bouton, self.glisse, None, None, False
            if self._a_menu(bouton):
                if not glisse:
                    QTimer.singleShot(0, bouton.showMenu)  # après le relâchement : le menu est modal
                return True
            return glisse
        return self.glisse or self._a_menu(self.bouton)

    @staticmethod
    def _a_menu(bouton):
        return isinstance(bouton, QPushButton) and bouton.menu() is not None


_EN_ATTENTE = []  # les zones de ``defiler_au_doigt`` construites avant ``activer``


DECELERATION = 2500  # px/s² : le freinage de la course après le lâcher (``arrivee``)
VITESSE_MAX = 3000  # px/s : au-delà, la course part à cette vitesse (au plus 1800 px, deux à trois écrans de téléphone)


def arrivee(position, vitesse, deceleration=DECELERATION, plafond=VITESSE_MAX):
    """Où s'arrête la course lancée de ``position`` à ``vitesse`` (px/s, par axe, ramenée à ``plafond``), freinée à
    ``deceleration`` : à v²/2a dans la direction du geste, en pixels de la page. Remplace ``QScroller.finalPosition``,
    réglé pour un bureau : 0,125 m/s² (≈ 490 px/s² à 100 points par pouce, cinq fois plus glissant), course jusqu'à
    ≈ 3900 px, cinq écrans de téléphone (SmartTeacher, 26/11/2026 : « sur telephone l'accueil defilait beaucoup trop
    vite », « qu'avec un simple gest ou pouvait se retrouver quasiment à la fin de la page »)."""
    norme = sum(v * v for v in vitesse) ** 0.5
    if norme < 1:
        return tuple(position)
    if norme > plafond:
        vitesse, norme = [v * plafond / norme for v in vitesse], plafond
    distance = norme * norme / (2 * deceleration)
    return tuple(p + v / norme * distance for p, v in zip(position, vitesse))


class _Inertie(QObject):
    """La course de ``QScroller`` une fois le doigt levé, finie au rythme des images de l'écran. ``QScroller`` avance
    à la minuterie de Qt, que rien ne cale sur l'écran : sur un téléphone simulé (bac NSI, 412 px, densité 2,6),
    40 % des images restaient sans mouvement (pas espacés de 32 à 48 ms) alors qu'une image coûtait 2-3 ms à dessiner
    (``QCM/web/pyqt6/sonde_lecteur.html``, scénario ``doigt``). Au passage en ``Scrolling``, la position où ``QScroller``
    s'arrêterait (``arrivee``, bornée à la plage : le rebond de fin est perdu) est calculée, lui arrêté, et une
    ``QPropertyAnimation`` de qtpy6 (menée par les images, ``qtpy6.animation``) mène chaque ascenseur jusqu'à elle en
    décélérant : ``OutQuad`` part à la vitesse du doigt quand sa durée vaut deux fois la distance divisée par cette
    vitesse. La vitesse est celle des positions des ascenseurs pendant les ``FENETRE`` dernières secondes du glissé :
    ``QScroller.velocity`` est en mètres par seconde, convertis par une densité d'écran que le navigateur ne connaît
    pas ; au moins ``DUREE_MIN`` entre la première et la dernière, sinon QScroller finit seul, réglé au même freinage. Un doigt reposé, une plage qui change ou la zone détruite arrêtent la course ; le doigt qui l'arrête n'est pas
    un clic : son appui et son relâchement n'atteignent pas la page (sans cela, mesuré, il cochait la case dessous 12
    fois sur 12, QScroller seul compris : dans le navigateur, il laisse passer la souris que Qt tire du doigt). Mesuré
    au même profil : après le lâcher, 0 image sans mouvement au lieu de 33 à 48 %, pas d'avant et d'après du même ordre
    (20-30 px) ; écarté, ``QScrollerProperties.FrameRate`` à ``Fps60`` : encore 26 à 42 %, la minuterie restant décalée
    des images.

    Pas de dépassement de la borne non plus, au doigt posé comme à la lancée (``OvershootAlwaysOff``) : la page tirée
    au-delà du bas ou du haut déplace le viewport par-dessus ce qui le borde, et le canevas du navigateur n'y repeint
    pas : l'en-tête gardait des morceaux de page (sonde Blink tactile, ``doigt`` avec ``avant_fin=150``, 4 fois sur 4,
    09/10/2026 ; 0 sur 4 sans dépassement). Coût accepté : plus aucun rebond élastique au doigt dans le navigateur."""

    FENETRE = 0.1  # s
    DUREE_MIN = 0.03  # s : deux positions plus rapprochées que cela donneraient une vitesse au hasard

    def __init__(self, zone):
        super().__init__(zone)
        self.zone, self.courses, self.trace, self.avale = zone, [], [], False
        self.scroller = QScroller.scroller(zone.viewport())
        proprietes = self.scroller.scrollerProperties()
        for metrique in (QScrollerProperties.ScrollMetric.HorizontalOvershootPolicy,
                         QScrollerProperties.ScrollMetric.VerticalOvershootPolicy):
            proprietes.setScrollMetric(metrique, QScrollerProperties.OvershootPolicy.OvershootAlwaysOff)
        # le repli (trop peu de positions pour une vitesse) : QScroller finit seul, au même freinage et plafond
        par_metre = (zone.screen() or QApplication.primaryScreen()).physicalDotsPerInch() / 0.0254
        proprietes.setScrollMetric(QScrollerProperties.ScrollMetric.DecelerationFactor, DECELERATION / par_metre)
        proprietes.setScrollMetric(QScrollerProperties.ScrollMetric.MaximumVelocity, VITESSE_MAX / par_metre)
        self.scroller.setScrollerProperties(proprietes)
        self.scroller.stateChanged.connect(self._etat)
        for barre in self._barres():
            barre.valueChanged.connect(self._noter)
            barre.rangeChanged.connect(self.arreter)

    def _barres(self):
        return self.zone.horizontalScrollBar(), self.zone.verticalScrollBar()

    def _noter(self):
        if self.scroller.state() == QScroller.State.Dragging:
            self.trace.append((time.perf_counter(), *(b.value() for b in self._barres())))

    def arreter(self, *_):
        for course in self.courses:
            course.stop()
            course.deleteLater()
        self.courses = []

    def _etat(self, etat):
        if etat == QScroller.State.Pressed:
            self._avaler(any(c.state() == QAbstractAnimation.State.Running for c in self.courses))  # une course finie : clic
            self.arreter()
            self.trace = []
        elif etat == QScroller.State.Scrolling:
            maintenant = time.perf_counter()
            recents = [p for p in self.trace if maintenant - p[0] <= self.FENETRE]
            self.trace = []
            if len(recents) < 2 or recents[-1][0] - recents[0][0] < self.DUREE_MIN:
                return  # trop peu de positions pour une vitesse (rafale d'événements) : QScroller finit seul
            (t0, *p0), (t1, *p1) = recents[0], recents[-1]
            vitesse = [(b - a) / (t1 - t0) for a, b in zip(p0, p1)]
            x, y = arrivee(p1, vitesse)
            if self.courir(x, y, min(sum(v * v for v in vitesse) ** 0.5, VITESSE_MAX)):
                self.scroller.stop()

    def _avaler(self, oui):
        if oui != self.avale:
            (QApplication.instance().installEventFilter if oui else QApplication.instance().removeEventFilter)(self)
            self.avale = oui

    def eventFilter(self, objet, evenement):
        vue = self.zone.viewport()
        if evenement.type() in (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonDblClick, QEvent.Type.MouseButtonRelease) \
                and isinstance(objet, QWidget) and (objet is vue or vue.isAncestorOf(objet)):
            if evenement.type() == QEvent.Type.MouseButtonRelease:
                self._avaler(False)
            return True
        return False

    def courir(self, x, y, vitesse):
        """Mène les ascenseurs vers (``x``, ``y``), bornés à leur plage, en partant à ``vitesse`` px/s ; faux s'il n'y a
        pas de course (déjà arrivé, ou vitesse nulle)."""
        buts = [(b, min(max(round(v), b.minimum()), b.maximum())) for b, v in zip(self._barres(), (x, y))]
        distance = sum((but - b.value()) ** 2 for b, but in buts) ** 0.5
        if distance < 1 or vitesse < 1:
            return False
        duree = min(max(round(2000 * distance / vitesse), 100), 4000)
        self.arreter()
        for barre, but in buts:
            if but != barre.value():
                course = QPropertyAnimation(barre, b"value", self, duration=duree, easingCurve=QEasingCurve.Type.OutQuad)
                course.setStartValue(barre.value())
                course.setEndValue(but)
                course.start()
                self.courses.append(course)
        return True


_GESTES = {QEvent.Type.TouchBegin: QEvent.Type.MouseButtonPress, QEvent.Type.TouchUpdate: QEvent.Type.MouseMove,
           QEvent.Type.TouchEnd: QEvent.Type.MouseButtonRelease}


def relayer_en_souris(widget, evenement):
    """Un ``QTouchEvent`` (premier doigt seulement) rejoué en ``QMouseEvent`` sur les gestionnaires souris de
    ``widget`` (``mousePressEvent``/``mouseMoveEvent``/``mouseReleaseEvent``, inchangés) : ce que ``widget`` sait déjà
    faire au clic, il le refait au doigt. À appeler depuis un ``event()`` qui a mis ``WA_AcceptTouchEvents`` sur
    ``widget``. Le doigt est alors au widget : chaque événement relayé arrête le ``QScroller`` des ancêtres
    (``defiler_au_doigt``), que l'acceptation seule n'empêche PAS de faire défiler la page en même temps, en natif comme
    dans le navigateur (mesuré le 04/10/2026 : ``tests/test_tactile.py``, web.md, « Pièges »). Rend ``True``
    (traité) ou ``False`` (type ou doigt absent : rien à faire)."""
    genre = _GESTES.get(evenement.type())
    points = evenement.points() if genre is not None else ()
    if not points:
        return False
    position = points[0].position()
    boutons = Qt.MouseButton.NoButton if genre == QEvent.Type.MouseButtonRelease else Qt.MouseButton.LeftButton
    souris = QMouseEvent(genre, position, position, Qt.MouseButton.LeftButton, boutons, evenement.modifiers())
    arreter_le_defilement(widget)
    {QEvent.Type.MouseButtonPress: widget.mousePressEvent, QEvent.Type.MouseMove: widget.mouseMoveEvent,
     QEvent.Type.MouseButtonRelease: widget.mouseReleaseEvent}[genre](souris)
    evenement.accept()
    return True


def arreter_le_defilement(widget):
    """Arrête le ``QScroller`` de chaque ancêtre de ``widget`` (``defiler_au_doigt``) : le doigt est à ``widget``."""
    while widget is not None:
        if QScroller.hasScroller(widget):
            QScroller.scroller(widget).stop()
        widget = widget.parentWidget()


class Toucher:
    """Au doigt (``ACTIF``), un toucher (doigt posé et levé sur place) se distingue d'un glissé, qui fait défiler la page
    (``defiler_au_doigt``) : un widget qui agit au clic n'agit qu'au lever d'un toucher. Pour un widget qui laisse la page
    défiler sous le doigt, contrairement à ``relayer_en_souris`` qui la lui prend ; à la souris, rien ne change.

    ``appui`` (dans ``mousePressEvent``) rend ``True`` pour la souris que Qt tire d'un doigt : ne rien faire encore.
    ``bouge`` (``mouseMoveEvent``) oublie l'appui dès que le doigt s'éloigne de plus de ``startDragDistance``.
    ``leve`` (``mouseReleaseEvent``) rend ``True`` pour un toucher : agir maintenant.
    Les positions sont GLOBALES : quand la page suit le doigt, le point touché ne bouge pas dans le widget, et des
    positions locales n'y verraient aucun glissé. Un toucher que le navigateur annule sans relâchement (la page a pris
    le glissé) est oublié à l'appui suivant, et un relâchement sans appui noté n'est pas un toucher."""

    def __init__(self):
        self.point = None

    def appui(self, evenement):
        doigt = ACTIF and evenement.source() != Qt.MouseEventSource.MouseEventNotSynthesized
        self.point = evenement.globalPosition() if doigt else None
        return doigt

    def bouge(self, evenement):
        if self.point is not None and (evenement.globalPosition() - self.point).manhattanLength() > QApplication.startDragDistance():
            self.point = None

    def leve(self, evenement):
        self.bouge(evenement)
        touche, self.point = self.point is not None, None
        return touche


class AppuiLong(QObject):
    """Au doigt (``ACTIF``), un doigt posé immobile ``DELAI`` ms sur ``widget`` le lui donne : le défilement de la page
    (``defiler_au_doigt``) s'arrête et ``prendre(position)`` est appelé (une liste y lance son glisser) ; avant ce délai, un
    glissé fait défiler la page comme ailleurs. La convention des téléphones pour saisir un élément d'une liste qui défile.
    ``widget`` est celui qui reçoit la souris (le ``viewport()`` d'une vue). À la souris, rien ne change.

    ``DELAI`` reste sous l'appui long des téléphones, qui ouvre le menu ou la sélection du navigateur : 400 ms sous
    Android 12 et suivants (500 avant), environ 500 ms sous iOS. Le menu est de toute façon refusé sur l'écran de Qt
    (``qtpy6web.js``, ``sans_menu``)."""

    DELAI = 300

    def __init__(self, widget, prendre):
        from qtpy6.QtCore import QTimer  # noqa: PLC0415

        super().__init__(widget)
        self.widget, self.prendre = widget, prendre
        self.toucher = Toucher()
        self.minuterie = QTimer(self)
        self.minuterie.setSingleShot(True)
        self.minuterie.setInterval(self.DELAI)
        self.minuterie.timeout.connect(self._prendre)
        widget.installEventFilter(self)

    def eventFilter(self, objet, evenement):
        genre = evenement.type()
        if genre in (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonDblClick):  # un second appui rapide est un double-clic
            if self.toucher.appui(evenement):
                self.position = evenement.position()
                self.minuterie.start()
        elif genre == QEvent.Type.MouseMove:
            self.toucher.bouge(evenement)
            if self.toucher.point is None:
                self.minuterie.stop()
        elif genre == QEvent.Type.MouseButtonRelease:
            self.minuterie.stop()
            self.toucher.point = None
        return False

    def _prendre(self):
        self.toucher.point = None
        arreter_le_defilement(self.widget)
        self.prendre(self.position)
