// Le Web Worker de qtpy6.web.travailleur : Pyodide (l'ordinaire, pas Pyodide-Qt) dans un fil que la page peut terminer,
// des archives dépaquetées, un module importé ; ses appels sont traités un par un, dans l'ordre, chacun rendant la main
// avant le suivant. Lancé depuis une URL blob: : toutes les URL reçues sont absolues.
//   reçus : {init: {indexURL, archives: [{url, dossier}], module, cwd}}, {appel: {id, fonction, args}}
//   émis :  {pret}, {id, sortie} (ce que l'appel imprime, au fil de l'eau), {id, retour}, {id, erreur}, {erreur} (init)
// Ou bien un processus (ProcessusWeb) : un script lancé en __main__, qui lit son stdin comme sur le bureau.
//   reçus : {zmq: message} (zmq_web : un noyau Jupyter dans ce worker parle à la page ; gardé jusqu'à ce que le préambule
//           ait appelé zmq_pret), émis : {zmq: message} de même,
//           {prechauffer: {indexURL, roues}} (charger Pyodide dès maintenant, sans script : le {lancer} qui suivra
//           l'épargne ; roues : [url de .whl] installées ensuite, que le {lancer} ne chargera plus ; répétable),
//           {lancer: {indexURL, zip, dossier, argv, cwd, roues, env, web}} (env : os.environ du programme ; web : le dossier
//           qtpy6/web dépaqueté, d'où le préambule), {entree: texte} (stdin), {entree: null} (fin de fichier),
//           {signal: n} (Popen.send_signal hors SIGKILL/SIGTERM : gardé dans self.signaux, que le préambule livre au
//           prochain time.sleep) ;
//           le zip porte ses chemins depuis la racine du système de fichiers, où il est dépaqueté ; roues :
//           {module: url de .whl}, chacune chargée au premier import de son module (rien sinon : ni octets ni délai)
//   émis :  {sortie} (stdout), {sortie_erreur} (stderr), {fin: code}, {erreur} (Pyodide injoignable, JSPI absent)
globalThis.window ??= globalThis;  // AVANT loadPyodide : SDL (pyxel_web.py) fige window/document au chargement
let py, module, appeler, courant = 0, file = Promise.resolve();  // courant : le numéro de l'appel en cours, 0 hors de tout appel (l'import du module)
let prechauffe = null;  // {indexURL, py: Promise, roues: Set} : le Pyodide lancé par {prechauffer}, qu'un {lancer} du même
                        // indexURL reprend, et les URL des roues qui y sont installées
const decodeur = new TextDecoder();
const zmq_tampon = [];  // {zmq} reçus avant que le préambule ait installé zmq_web
self.zmq_pret = f => { self.recevoir_page = f; zmq_tampon.splice(0).forEach(f); };

function telecharger(url) {
  return fetch(url).then(r => { if (!r.ok) throw new Error(`${url} : ${r.status}`); return r.arrayBuffer(); });
}

async function demarrer({ indexURL, archives, module: nom, cwd }) {
  const zips = archives.map(a => telecharger(a.url));
  const { loadPyodide } = await import(indexURL + "pyodide.mjs");  // worker module : importScripts est refusé chez Google
  const [p, ...donnees] = await Promise.all([loadPyodide({ indexURL }), ...zips]);
  py = p;
  const sortie = { write: octets => { postMessage({ id: courant, sortie: decodeur.decode(octets, { stream: true }) }); return octets.length; } };
  py.setStdout(sortie); py.setStderr(sortie);
  archives.forEach((a, i) => py.unpackArchive(donnees[i], "zip", { extractDir: a.dossier }));
  py.runPython(`import json, os, sys
sys.path[:0] = json.loads(${JSON.stringify(JSON.stringify(archives.map(a => a.dossier)))})
os.makedirs(${JSON.stringify(cwd)}, exist_ok=True); os.chdir(${JSON.stringify(cwd)})`);
  appeler = py.runPython("def _appeler(module, fonction, args):\n    return getattr(module, fonction)(*args.to_py())\n_appeler");
  module = py.pyimport(nom);
  postMessage({ pret: true });
}

async function traiter({ id, fonction, args }) {
  courant = id;
  try {
    let r = appeler(module, fonction, args);
    if (r && typeof r.then === "function") r = await r;  // une fonction async
    if (r && typeof r.toJs === "function") { const v = r.toJs({ dict_converter: Object.fromEntries }); r.destroy(); r = v; }
    py.runPython("import sys; sys.stdout.flush(); sys.stderr.flush()");
    postMessage({ id, retour: r === undefined ? null : r });
  } catch (e) {
    postMessage({ id, erreur: String(e) });
  } finally {
    courant = 0;
  }
}

self.signaux = [];  // {signal} reçus, pas encore livrés au Python du programme
const entrees = [], attentes = [];  // stdin : ce qui est arrivé sans être lu, et les lectures qui attendent
self.prochaine_entree = () => entrees.length ? Promise.resolve(entrees.shift()) : new Promise(r => attentes.push(r));

function charger(indexURL) {
  return import(indexURL + "pyodide.mjs").then(({ loadPyodide }) => loadPyodide({ indexURL }));
}

async function lancer({ indexURL, zip, dossier, argv, cwd, roues, env, web }) {
  const reserve = prechauffe?.indexURL === indexURL ? prechauffe : null;
  py = await (reserve ? reserve.py : charger(indexURL));  // un échec du préchauffage ressort ici, en {erreur}
  prechauffe = null;
  if (reserve) roues = Object.fromEntries(Object.entries(roues || {}).filter(([, url]) => !reserve.roues.has(url)));
  const canal = cle => { const d = new TextDecoder(); return { write: o => { postMessage({ [cle]: d.decode(o, { stream: true }) }); return o.length; } }; };
  py.setStdout(canal("sortie")); py.setStderr(canal("sortie_erreur"));
  py.unpackArchive(zip, "zip", { extractDir: "/" });
  self.chargerRoue = url => py.loadPackage(url, { messageCallback: () => {} });  // sans « Loading… » dans le stdout capturé
  py.globals.set("_lancement", py.toPy({ argv, cwd, dossier, roues: roues || {}, env: env || {}, web }));
  const code = await py.runPythonAsync(`
import atexit, importlib, importlib.util, io, js, os, runpy, sys, traceback
from pyodide.ffi import can_run_sync, run_sync

class _Entree(io.RawIOBase):  # stdin : chaque lecture attend la prochaine écriture de la page (JSPI)
    reste = b""
    def readable(self):
        return True
    def readinto(self, b):
        sys.stdout.flush(); sys.stderr.flush()
        if not self.reste:
            texte = run_sync(js.prochaine_entree())
            if texte is None:
                return 0
            self.reste = texte.encode("utf-8")
        n = min(len(b), len(self.reste))
        b[:n], self.reste = self.reste[:n], self.reste[n:]
        return n

class _Roues:  # une roue chargée au premier import de son module : find_spec télécharge (JSPI) puis laisse la main
    def __init__(self, roues):
        self.roues = dict(roues)
    def find_spec(self, nom, chemin=None, cible=None):
        url = self.roues.pop(nom, None)
        if url:
            run_sync(js.chargerRoue(url))
            importlib.invalidate_caches()
        return None  # PathFinder trouve alors le module installé par la roue

def _executer(argv, cwd, dossier, roues, env, web):
    if not can_run_sync():
        raise RuntimeError("ce navigateur ne sait pas suspendre Python (JSPI) : pas de sous-processus")
    if roues:
        sys.meta_path.insert(0, _Roues(roues))
    # __stdin__ aussi, comme sur un bureau : un script qui enveloppe sys.stdin.buffer puis remplace sys.stdin ne doit pas
    # voir l'ancien objet ramassé, ce qui fermerait le tampon partagé (console_enfant.py de SmartTeacher)
    sys.stdin = sys.__stdin__ = io.TextIOWrapper(io.BufferedReader(_Entree()), encoding="utf-8")
    sys.stdout.reconfigure(line_buffering=True); sys.stderr.reconfigure(line_buffering=True)
    os.environ.update(env)
    os.makedirs(cwd, exist_ok=True); os.chdir(cwd)
    try:
        # zmq et threading de qtpy6 (un noyau Jupyter y parle à la page), sans le qtpy6 complet : voir preambule.py
        spec = importlib.util.spec_from_file_location("_qtpy6_preambule", web + "/preambule.py")
        preambule = importlib.util.module_from_spec(spec); spec.loader.exec_module(preambule)
        preambule.installer(web)
        if argv[0] == "-m":
            sys.path[:0] = [cwd, dossier]; sys.argv = argv[1:]
            runpy.run_module(argv[1], run_name="__main__", alter_sys=True)
        else:
            sys.path.insert(0, dossier); sys.argv = argv
            runpy.run_path(argv[0], run_name="__main__")
        code = 0
    except SystemExit as e:
        if e.code is None or isinstance(e.code, int):
            code = e.code or 0
        else:
            print(e.code, file=sys.stderr); code = 1
    except BaseException:
        traceback.print_exc(); code = 1
    atexit._run_exitfuncs()  # la fermeture des sockets du noyau : un interpréteur qui finit les lance, Pyodide non
    sys.stdout.flush(); sys.stderr.flush()
    return code

_executer(**_lancement)
`);
  postMessage({ fin: code });
}

onmessage = e => {
  const m = e.data;
  if (m.memoire) { (self.qtpy6_memoires ??= new Map()).set(m.memoire.nom, m.memoire.sab); return; }  // memoire_partagee.py
  if (m.zmq) { self.recevoir_page ? self.recevoir_page(m.zmq) : zmq_tampon.push(m.zmq); return; }
  if (m.prechauffer) {  // le rejet est gardé pour le {lancer} qui consommera (le catch vide évite l'« unhandled rejection »)
    const { indexURL, roues = [] } = m.prechauffer;
    if (!prechauffe) prechauffe = { indexURL, py: charger(indexURL), roues: new Set() };
    const reserve = prechauffe, neuves = roues.filter(url => !reserve.roues.has(url));
    if (neuves.length)  // une roue qui échoue ici sera chargée au premier import, comme sans réserve
      reserve.py = reserve.py.then(py => py.loadPackage(neuves, { messageCallback: () => {} })
        .then(() => neuves.forEach(url => reserve.roues.add(url)), () => {}).then(() => py));
    reserve.py.catch(() => {});
    return;
  }
  if (m.lancer) { lancer(m.lancer).catch(e => postMessage({ erreur: String(e) })); return; }
  if (m.signal) { self.signaux.push(m.signal); return; }
  if ("entree" in m) { attentes.length ? attentes.shift()(m.entree) : entrees.push(m.entree); return; }
  file = m.init ? file.then(() => demarrer(m.init)).catch(e => postMessage({ erreur: String(e) }))
                : file.then(() => traiter(m.appel));
};
