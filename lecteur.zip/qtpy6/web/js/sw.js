// qtpy6.web : le service worker d'une page déployée (qtpy6web.service_worker l'enregistre). Il sert depuis le Cache Storage ce
// que la page lui a confié, sans requête : un hôte statique sert avec un max-age court (GitHub Pages : 600 s), passé lequel
// chaque fichier de Pyodide-Qt et de l'application est revalidé (un aller-retour par fichier, 304 sans corps) à chaque visite.
// Servi depuis le dossier de la page (qtpy6.web.construire.deposer l'y met) : un service worker ne contrôle que son dossier
// et ce qui est en dessous.
// La page envoie, une fois prête, la liste des adresses à garder (postMessage, `garder`) : le service worker les relit dans le
// cache HTTP, revalidés (« no-cache » : 304 sans corps quand la page vient de les télécharger) et les range. Un cache par requête
// d'enregistrement (?v=… de la page, cache=… : le nom de l'application, p=… : le Pyodide des workers) ; à l'activation, les
// caches du même nom d'application et d'une autre requête sont effacés. Le Pyodide des workers (p=…, passé à
// l'enregistrement car le service worker ne lit pas les constantes de la page) : un worker neuf demande les fichiers BRUTS
// (pyodide.asm.wasm…) que la page n'a chargés que par leurs jumeaux (qtpy6web.js, en_jumeau) ; il les reçoit de l'entrée du
// jumeau, sinon du réseau, rangés au premier passage — sans quoi chaque worker referait un aller-retour par fichier, et rien
// hors ligne. Le reste (la page, les données de l'application) passe au réseau tel quel.
// Venu de SmartTeacher le 05/10/2026 : ses deux moitiés (la page qui enregistre et range, ce fichier qui sert) vivaient dans
// deux dépôts, et la régression de SmartTeacher rév. 546 (le jumeau .gz du moteur servi brut au worker) n'était vue par aucun
// des deux ; tests/test_web.py, test_service_worker, la voit dans Blink et Firefox.
const REQUETE = new URLSearchParams(location.search);
const NOM = REQUETE.get("cache") || "qtpy6";
const CACHE = NOM + location.search;
const PYODIDE = REQUETE.get("p") || "";
// isoler=… (service_worker(…, { isoler: true })) : la page et ses workers isolés (crossOriginIsolated : SharedArrayBuffer,
// mémoire partagée entre la page et un Worker), sans rien demander à l'hôte (GitHub Pages ne pose pas d'en-têtes) : les
// en-têtes COOP/COEP ajoutés ici à toute réponse de la même origine. « credentialless » plutôt que « require-corp » : les
// fichiers d'un autre domaine (cdn.jsdelivr.net) passent sans en-tête CORP, chargés sans cookies.
const ISOLER = REQUETE.has("isoler");
const isoler = r => {
  if (!ISOLER || !["basic", "default"].includes(r.type)) return r;  // default : une réponse construite ici (jumeau rangé)
  const h = new Headers(r.headers);
  h.set("Cross-Origin-Opener-Policy", "same-origin");
  h.set("Cross-Origin-Embedder-Policy", "credentialless");
  return new Response(r.body, { status: r.status, statusText: r.statusText, headers: h });
};

// skipWaiting à la PREMIÈRE installation seulement (rien à remplacer) : une version neuve, quand une ancienne est active,
// attend que plus aucune page ne s'en serve. L'évincer de force, à la première visite qui suit un déploiement, rendait
// l'ancienne redondante en plein chargement et Firefox coupait les téléchargements qu'elle servait (lecteur.zip.br) :
// « The operation was aborted. » (SmartTeacher W524, 10/11/2026 ; essai apres_deploiement.py, ligne à 500 Kio/s).
self.addEventListener("install", () => { if (!self.registration.active) self.skipWaiting(); });
self.addEventListener("activate", e => e.waitUntil(Promise.all([self.clients.claim(),  // contrôler dès la première visite :
  // sans claim, les workers de cette visite-là échapperaient au cache, qui ne se remplirait qu'à la seconde
  caches.keys().then(cles => Promise.all(
    cles.filter(c => c.startsWith(NOM + "?") && c !== CACHE).map(c => caches.delete(c))))])));
// Un jumeau Brotli ou gzip (NOM.br, NOM.gz, que qtpy6web.js demande à la place de NOM) est rangé DÉCOMPRESSÉ, marqué de
// l'en-tête que qtpy6web.js reconnaît (DECOMPRESSE) : sinon la page le décompresserait à chaque ouverture (0,15 à 0,3 s pour le moteur).
self.addEventListener("message", e => e.waitUntil(caches.open(CACHE).then(cache => Promise.all(e.data.map(async url => {
  if (await cache.match(url)) return;
  // « no-cache » : revalidé (ETag, 304 sans corps si le cache HTTP est à jour), jamais « force-cache ». La version qui
  // s'installe reçoit la liste pendant que l'ancienne sert la page depuis SON cache : le cache HTTP peut alors tenir un
  // fichier d'une version antérieure (même adresse, ex. pyside_agrege.so d'un Qt republié), que force-cache rangeait
  // pour toute la version neuve (SmartTeacher W525, 10/11/2026 : l'ancien Qt servi indéfiniment après le déploiement).
  // Hors ligne, la revalidation échoue : rien n'est rangé pour cette adresse (une visite en ligne le fera), les autres si
  let reponse = await fetch(url, { cache: "no-cache" }).catch(() => undefined);
  if (!reponse?.ok) return;
  const nom = new URL(url).pathname;
  const format = { br: "brotli", gz: "gzip" }[nom.split(".").pop()];
  if (format)
    reponse = new Response(reponse.body.pipeThrough(new DecompressionStream(format)), { headers: {
      "Content-Type": /\.wasm\.\w+$/.test(nom) ? "application/wasm" : "application/octet-stream", "X-Qtpy6-Decompresse": "1" } });
  await cache.put(url, reponse);
})))));
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  e.respondWith(caches.open(CACHE).then(async cache => {
    const garde = await cache.match(e.request);
    if (garde) return garde;
    if (PYODIDE && e.request.url.startsWith(PYODIDE)) {
      // un worker demande l'URL BRUTE d'un fichier que la page n'a chargé que par son jumeau (pyodide.asm.wasm.br…) :
      // l'entrée du jumeau, rangée décompressée (message), est la bonne réponse — sans elle, retéléchargement brut
      const jumeau = await cache.match(e.request.url + ".br") || await cache.match(e.request.url + ".gz");
      if (jumeau) return jumeau;
    }
    const reponse = await fetch(e.request);
    if (PYODIDE && e.request.url.startsWith(PYODIDE) && reponse.ok && ["basic", "cors"].includes(reponse.type)
        && !/\.(br|gz)$/.test(new URL(e.request.url).pathname))
      // jamais une réponse opaque ou en erreur ; jamais un jumeau, que seul « message » range, décompressé : rangé brut
      // ici (la page le demande dès qu'elle est contrôlée, quand p=… est le Pyodide-Qt de la page), « message » le
      // trouvait déjà là, et le worker recevait pour pyodide.asm.wasm du gzip (« Incorrect response MIME type »).
      // L'écriture hors de la chaîne de réponse : un stockage plein ou refusé (QuotaExceededError, navigation privée)
      // ne doit pas transformer une réponse reçue en erreur réseau
      e.waitUntil(cache.put(e.request, reponse.clone()).catch(() => {}));
    return reponse;
  }).then(isoler));
});
