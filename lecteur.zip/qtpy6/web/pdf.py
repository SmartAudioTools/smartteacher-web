"""QtPdf et QtPdfWidgets dans le navigateur, où Qt-WASM ne les a pas (QtPdf repose sur PDFium, construit avec
QtWebEngine) : ``QPdfDocument`` et ``QPdfView`` sous les mêmes noms, dessinés par pdf.js (``js/pdfjs/``, vendu, aucun
réseau) dans un ``<div>`` de la page que la vue cale sur son widget. Le texte y est sélectionnable et copiable, comme
dans le lecteur PDF du navigateur. ``qtpy6.QtPdf`` et ``qtpy6.QtPdfWidgets`` les chargent sous Pyodide.

Le ``<div>`` est au-dessus du canevas de Qt : il n'est montré que quand le widget se voit, est activé (un widget
désactivé cache son PDF : un rideau posé par ``setEnabled(False)`` le couvre) et qu'aucune boîte modale ni menu
n'est ouvert, que Qt dessinerait dessous. Seul le sous-ensemble utile de l'API est doublé : ``QPdfDocument.load``
(chemin ou QIODevice), ``status``, ``pageCount`` et leurs signaux ; ``QPdfView.setDocument`` et les modes, la page
étant toujours ajustée à la largeur, les pages les unes sous les autres, ``setDocumentMargins`` et ``setPageSpacing`` ; les
liens internes du PDF (un sommaire) suivis au clic, comme sur ordinateur ; et ``setPageLimit``, l'ajout de qtpy6 (les
premières pages seules), setMasks (des zones en pavés, leur texte retiré), setCopyZones (seul le texte de ces zones
se sélectionne) et setCopyFilter (ce que copie le navigateur, réécrit), les autres ajouts, comme sur
ordinateur. Le chargement est asynchrone : ``load`` rend ``Error.None_`` avec ``status() == Loading``, puis
``statusChanged(Ready)``."""

import enum
import importlib.resources

from qtpy6.QtCore import QMargins, QObject, QRectF, Signal

from .calque import Calque

_JS = None


def _js():
    """Les fonctions de ``js/pdf_vue.js``, chargées au premier usage (rien n'importe ``js`` au chargement du module)."""
    global _JS
    if _JS is None:
        import js  # noqa: PLC0415
        from pyodide.code import run_js  # noqa: PLC0415

        dossier = importlib.resources.files(__package__).joinpath("js")

        def url(nom):
            if not dossier.joinpath(nom).is_file():  # archive sans pdf.js (assembler, exclure) : à côté de qtpy6web.js
                return js.URL.new(nom, js.qtpy6Js).href
            source = dossier.joinpath(nom).read_text(encoding="utf-8")
            return js.URL.createObjectURL(js.Blob.new([source], type="text/javascript"))

        _JS = run_js(dossier.joinpath("pdf_vue.js").read_text(encoding="utf-8"))(
            url("pdfjs/pdf.min.mjs"), url("pdfjs/pdf.worker.min.mjs"))
    return _JS


class QPdfDocument(QObject):
    class Status(enum.Enum):
        Null, Loading, Ready, Unloading, Error = range(5)

    class Error(enum.Enum):
        None_, Unknown, DataNotYetAvailable, FileNotFound, InvalidFileFormat, IncorrectPassword, \
            UnsupportedSecurityScheme = range(7)

    statusChanged = Signal(object)
    pageCountChanged = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._status, self._erreur, self._pages, self._promesse = self.Status.Null, self.Error.None_, 0, None

    def status(self):
        return self._status

    def error(self):
        return self._erreur

    def pageCount(self):
        return self._pages

    def load(self, source):
        if isinstance(source, str):
            try:
                with open(source, "rb") as f:
                    octets = f.read()
            except OSError:
                self._erreur = self.Error.FileNotFound
                self._statut(self.Status.Error)
                return self._erreur
        else:
            octets = bytes(source.readAll())
        from pyodide.ffi import create_once_callable, to_js  # noqa: PLC0415

        self.close()
        self._erreur = self.Error.None_
        self._statut(self.Status.Loading)
        promesse = self._promesse = _js().ouvrir(to_js(octets))

        def pret(doc):
            if promesse is self._promesse:
                self._pages = doc.numPages
                self.pageCountChanged.emit(self._pages)
                self._statut(self.Status.Ready)

        def echec(raison):
            if promesse is self._promesse:
                self._erreur = (self.Error.IncorrectPassword if "Password" in str(raison.name)
                                else self.Error.InvalidFileFormat)
                self._statut(self.Status.Error)

        promesse.then(create_once_callable(pret), create_once_callable(echec))
        return self.Error.None_

    def close(self):
        if self._promesse is not None:
            self._promesse, self._pages = None, 0
            self.pageCountChanged.emit(0)
            self._statut(self.Status.Null)

    def _statut(self, statut):
        if statut != self._status:
            self._status = statut
            self.statusChanged.emit(statut)


class QPdfView(Calque):
    class PageMode(enum.Enum):
        SinglePage, MultiPage = range(2)

    class ZoomMode(enum.Enum):
        Custom, FitToWidth, FitInView = range(3)

    documentChanged = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._document, self._mode_page, self._mode_zoom = None, self.PageMode.SinglePage, self.ZoomMode.Custom
        self._vue = vue = _js().vue()
        self._limite, self._masques = None, {}
        self._zones_copie = self._filtre = None  # setCopyZones, setCopyFilter
        self._marges, self._ecart = QMargins(6, 6, 6, 6), 3  # les défauts de QPdfView
        self.destroyed.connect(lambda *_: vue.detruire())

    def document(self):
        return self._document

    def setDocument(self, document):
        if self._document is not None:
            self._document.statusChanged.disconnect(self._afficher)
        self._document = document
        if document is not None:
            document.statusChanged.connect(self._afficher)
        self._afficher()
        self.documentChanged.emit(document)

    def _afficher(self, *_):
        prete = self._document is not None and self._document.status() == QPdfDocument.Status.Ready
        self._vue.afficher(self._document._promesse if prete else None)

    def setPageLimit(self, nombre):
        self._limite = nombre
        self._vue.limiter(nombre)

    def pageLimit(self):
        return self._limite

    def setMasks(self, masques):
        """{page: [QRectF en points de la page, depuis son haut gauche]} : ces zones en pavés, leur texte retiré."""
        from pyodide.ffi import to_js  # noqa: PLC0415

        self._masques = {page: [QRectF(r) for r in zones] for page, zones in (masques or {}).items() if zones}
        self._vue.masquer(to_js([[page, r.x(), r.y(), r.width(), r.height()]
                                 for page, zones in self._masques.items() for r in zones]))

    def masks(self):
        return {page: list(zones) for page, zones in self._masques.items()}

    def setCopyZones(self, zones):
        """{page: [QRectF en points]} : seul leur texte se sélectionne et se copie ; {} aucun, None tout (le défaut)."""
        from pyodide.ffi import to_js  # noqa: PLC0415

        self._zones_copie = None if zones is None else {page: [QRectF(r) for r in z] for page, z in zones.items() if z}
        self._vue.copiables(None if zones is None else to_js(
            [[page, r.x(), r.y(), r.width(), r.height()] for page, z in self._zones_copie.items() for r in z]))

    def copyZones(self):
        return None if self._zones_copie is None else {page: list(z) for page, z in self._zones_copie.items()}

    def setCopyFilter(self, fonction):
        """``fonction(texte) -> texte`` réécrit ce que copie le navigateur (None : tel quel)."""
        from pyodide.ffi import create_proxy  # noqa: PLC0415

        self._filtre = fonction and create_proxy(fonction)  # gardé : le proxy vit autant que la vue
        self._vue.filtrer(self._filtre)

    def documentMargins(self):
        return QMargins(self._marges)

    def setDocumentMargins(self, marges):
        self._marges = QMargins(marges)
        self._espacer()

    def pageSpacing(self):
        return self._ecart

    def setPageSpacing(self, ecart):
        self._ecart = ecart
        self._espacer()

    def _espacer(self):
        m = self._marges
        self._vue.espacer(m.left(), m.top(), m.right(), m.bottom(), self._ecart)

    def pageMode(self):
        return self._mode_page

    def setPageMode(self, mode):
        self._mode_page = mode

    def zoomMode(self):
        return self._mode_zoom

    def setZoomMode(self, mode):
        self._mode_zoom = mode

    def _placer(self, *place):
        self._vue.placer(*place)
