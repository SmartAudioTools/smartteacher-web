"""Profileur de complexité : compte les opérations élémentaires d'un programme Python, sans marqueur.

Définition (cours NSI Première, § Complexité) : une opération élémentaire prend un temps constant (affectation,
comparaison, addition, accès à un élément d'une liste) ; une boucle, un appel de fonction, un tri ou une recherche dans
une liste n'en sont pas, il faut compter les opérations qu'ils font exécuter.

Mécanisme : l'AST du programme est réécrit avant `compile` (comme les `assert` de pytest), en pur Python, pour tourner
aussi sous Pyodide.
  - chaque instruction reçoit un compteur de passages et ses opérations fixes, lues dans l'AST (`s = s + liste[i]` → 3) ;
  - les parties évaluées sous condition (`a and b`, `x if c else y`, compréhensions, corps de lambda) comptent quand
    elles sont atteintes ;
  - les nœuds qui peuvent cacher un coût (appels, `in`, `==`, `+`, `*`, tranches, `+=`, `del liste[i]`) passent par une
    enveloppe qui teste le type réel à l'exécution et compte d'après la taille de l'objet à cet instant.

Deux totaux : `total` compte chaque opération une fois (le TOTAL du programme) ; la marge d'une ligne qui appelle une
fonction de l'élève affiche son coût inclusif (passages × opérations, appel compris), qui ne s'ajoute pas au TOTAL.
"""

from __future__ import annotations

import ast
import operator
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Iterator

NOM = "__cx__"
FICHIER = "<editeur>"

# Appels qui dépendent du cadre de l'appelant : une enveloppe les casserait (super() sans argument, locals()…).
_APPELS_DIRECTS = {"super", "locals", "vars", "globals", "eval", "exec", "dir", "breakpoint"}
_COMPARAISONS = {ast.In: "in", ast.NotIn: "not in", ast.Eq: "==", ast.NotEq: "!="}
_OPERATIONS = {ast.Add: "+", ast.Mult: "*"}

# Description du coût, pour l'infobulle.
DECALAGE = "décalage des éléments suivants"
COMPARAISONS = "comparaisons"
COPIE = "copie des éléments"
PARCOURS = "parcours des éléments"
TRI = "comparaisons du tri"
FONCTION = "opérations exécutées par la fonction"
ELEMENTAIRE = "élémentaire"


# ---------------------------------------------------------------------------------------------------------------------
# Lecture du code : opérations fixes d'une expression


def _est_test(e: ast.expr) -> bool:
    """Une comparaison est elle-même le test d'un `if` : on ne compte pas un test de plus."""
    return isinstance(e, ast.Compare)


def cout_test(e: ast.expr) -> int:
    return cout(e) + (0 if _est_test(e) else 1)


def cout_cible(t: ast.expr) -> int:
    """Opérations d'une affectation à la cible `t` (une par nom affecté)."""
    if isinstance(t, (ast.Tuple, ast.List)):
        return sum(cout_cible(e) for e in t.elts)
    if isinstance(t, ast.Starred):
        return cout_cible(t.value)
    if isinstance(t, ast.Attribute):
        return 1 + cout(t.value)
    if isinstance(t, ast.Subscript):
        return 1 + cout(t.value) + cout(t.slice)
    return 1


def cout(e: ast.AST | None) -> int:
    """Opérations élémentaires fixes de l'expression `e`, évaluée une fois.

    Ne compte pas ce qui est compté à l'exécution : les nœuds enveloppés (leurs enfants, eux, sont comptés ici) et les
    parties évaluées sous condition, qui comptent quand elles sont atteintes."""
    if e is None or isinstance(e, (ast.Constant, ast.Name)):
        return 0
    if isinstance(e, ast.Attribute):
        return 1 + cout(e.value)
    if isinstance(e, ast.Subscript):
        if isinstance(e.slice, ast.Slice):
            return cout(e.value) + cout(e.slice)  # tranche : enveloppée
        return 1 + cout(e.value) + cout(e.slice)
    if isinstance(e, ast.BinOp):
        propre = 0 if type(e.op) in _OPERATIONS else 1
        return propre + cout(e.left) + cout(e.right)
    if isinstance(e, ast.UnaryOp):
        if isinstance(e.operand, ast.Constant):
            return 0  # -1 est une constante
        return 1 + cout(e.operand)
    if isinstance(e, ast.Compare):
        enveloppe = len(e.ops) == 1 and type(e.ops[0]) in _COMPARAISONS
        return (0 if enveloppe else len(e.ops)) + cout(e.left) + sum(cout(c) for c in e.comparators)
    if isinstance(e, ast.BoolOp):
        return cout(e.values[0]) + 1  # les opérandes suivants comptent s'ils sont évalués
    if isinstance(e, ast.IfExp):
        return cout_test(e.test)  # la branche prise compte à l'exécution
    if isinstance(e, ast.Call):
        if isinstance(e.func, ast.Name) and e.func.id in _APPELS_DIRECTS:
            propre = 1
            appele = 0
        else:
            propre = 0  # enveloppé
            appele = cout(e.func.value) if isinstance(e.func, ast.Attribute) else cout(e.func)
        return propre + appele + sum(cout(a) for a in e.args) + sum(cout(k.value) for k in e.keywords)
    if isinstance(e, (ast.List, ast.Set)):
        return max(1, len(e.elts)) + sum(cout(x) for x in e.elts)
    if isinstance(e, ast.Tuple):
        return sum(cout(x) for x in e.elts)  # simple regroupement : `a, b = b, a` vaut 2 affectations
    if isinstance(e, ast.Dict):
        return max(1, len(e.keys)) + sum(cout(k) for k in e.keys) + sum(cout(v) for v in e.values)
    if isinstance(e, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
        return 1 + cout(e.generators[0].iter)
    if isinstance(e, ast.Lambda):
        return 1 + sum(cout(d) for d in e.args.defaults) + sum(cout(d) for d in e.args.kw_defaults)
    if isinstance(e, ast.JoinedStr):
        return 1 + sum(cout(v) for v in e.values)
    if isinstance(e, ast.FormattedValue):
        return cout(e.value)
    if isinstance(e, (ast.NamedExpr, ast.Await, ast.Yield, ast.YieldFrom)):
        return 1 + cout(e.value)
    if isinstance(e, ast.Starred):
        return cout(e.value)
    return sum(cout(c) for c in ast.iter_child_nodes(e))


# ---------------------------------------------------------------------------------------------------------------------
# Réécriture de l'AST


@dataclass
class Noeud:
    """Un nœud enveloppé : son étendue dans le code de l'élève, pour le coloriage."""

    instruction: int  # indice de l'instruction qui l'évalue (la marge de sa ligne le compte)
    ligne: int
    colonne: int  # en caractères, pas en octets UTF-8 comme ``col_offset`` : ce qu'un éditeur compte
    fin_ligne: int
    fin_colonne: int
    texte: str


@dataclass
class Table:
    """Ce que la réécriture a numéroté : la ligne de chaque instruction, l'étendue de chaque nœud enveloppé."""

    instructions: list[int] = field(default_factory=list)
    noeuds: list[Noeud] = field(default_factory=list)


def _appel(methode: str, *args: ast.expr, mots: list[ast.keyword] | None = None) -> ast.Call:
    return ast.Call(
        func=ast.Attribute(value=ast.Name(id=NOM, ctx=ast.Load()), attr=methode, ctx=ast.Load()),
        args=list(args),
        keywords=mots or [],
    )


def _const(v: Any) -> ast.Constant:
    return ast.Constant(value=v)


class _Instrumenteur(ast.NodeTransformer):
    def __init__(self, source: str) -> None:
        self.source = source
        self.lignes = source.splitlines()
        self.table = Table()
        self.courante = 0  # instruction en cours de réécriture

    # -- numérotation

    def _caracteres(self, ligne: int, octets: int) -> int:
        """Une colonne de l'AST (octets UTF-8) en caractères."""
        texte = self.lignes[ligne - 1] if 0 < ligne <= len(self.lignes) else ""
        return len(texte.encode()[:octets].decode(errors="ignore"))

    def _instruction(self, s: ast.stmt) -> int:
        self.table.instructions.append(s.lineno)
        return len(self.table.instructions) - 1

    def _noeud(self, e: ast.expr) -> int:
        texte = ast.get_source_segment(self.source, e) or ""
        fin = e.end_lineno or e.lineno
        self.table.noeuds.append(Noeud(self.courante, e.lineno, self._caracteres(e.lineno, e.col_offset), fin,
                                       self._caracteres(fin, e.end_col_offset or 0), texte))
        return len(self.table.noeuds) - 1

    def _passage(self, sid: int, c: int, s: ast.stmt) -> ast.stmt:
        return ast.copy_location(ast.Expr(_appel("p", _const(sid), _const(c))), s)

    def _compte(self, e: ast.expr, c: int) -> ast.expr:
        """`e` évaluée sous condition : ses `c` opérations fixes comptent quand elle est atteinte."""
        nouveau = self.visit(e)
        if c == 0:
            return nouveau
        return ast.copy_location(_appel("compte", _const(self.courante), _const(c), nouveau), e)

    # -- instructions

    def bloc(self, corps: list[ast.stmt], tete: bool = False) -> list[ast.stmt]:
        """Réécrit une suite d'instructions. En tête de module ou de fonction, la docstring et les `from __future__`
        restent en premier, sans compteur."""
        resultat: list[ast.stmt] = []
        i = 0
        if tete:
            while i < len(corps):
                s = corps[i]
                docstring = (
                    i == 0 and isinstance(s, ast.Expr) and isinstance(s.value, ast.Constant)
                    and isinstance(s.value.value, str)
                )
                futur = isinstance(s, ast.ImportFrom) and s.module == "__future__"
                if not (docstring or futur):
                    break
                resultat.append(s)
                i += 1
        for s in corps[i:]:
            resultat.extend(self.instruction(s))
        return resultat or [ast.Pass()]

    def instruction(self, s: ast.stmt) -> list[ast.stmt]:
        if isinstance(s, (ast.Global, ast.Nonlocal)):
            return [s]  # déclarations, rien ne s'exécute
        precedente = self.courante
        sid = self.courante = self._instruction(s)
        try:
            return self._instruction_numerotee(s, sid)
        finally:
            self.courante = precedente

    def _instruction_numerotee(self, s: ast.stmt, sid: int) -> list[ast.stmt]:
        if isinstance(s, ast.For):
            # En-tête : un test par tour plus le test qui sort, une affectation par nom à chaque tour.
            c_iter = cout(s.iter)
            s.iter = _appel("boucle", _const(sid), _const(cout_cible(s.target)), self._compte(s.iter, c_iter))
            s.body = self.bloc(s.body)
            s.orelse = self.bloc(s.orelse) if s.orelse else []
            return [s]
        if isinstance(s, ast.While):
            c = cout_test(s.test)
            s.test = ast.copy_location(_appel("test", _const(sid), _const(c), self.visit(s.test)), s.test)
            s.body = self.bloc(s.body)
            s.orelse = self.bloc(s.orelse) if s.orelse else []
            return [s]
        if isinstance(s, ast.If):
            c = cout_test(s.test)
            s.test = self.visit(s.test)
            s.body = self.bloc(s.body)
            s.orelse = self.bloc(s.orelse) if s.orelse else []
            return [self._passage(sid, c, s), s]
        if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            s.decorator_list = [self.visit(d) for d in s.decorator_list]
            if isinstance(s, ast.ClassDef):
                s.bases = [self.visit(b) for b in s.bases]
                s.keywords = [self.visit(k) for k in s.keywords]
            else:
                s.args = self.visit(s.args)
            s.body = self.bloc(s.body, tete=True)
            return [self._passage(sid, 1, s), s]
        if isinstance(s, (ast.Try, ast.TryStar)):
            s.body = self.bloc(s.body)
            for h in s.handlers:
                hid = self._instruction(h)
                if h.type is not None:
                    h.type = self.visit(h.type)
                h.body = [self._passage(hid, 0, h)] + self.bloc(h.body)
            s.orelse = self.bloc(s.orelse) if s.orelse else []
            s.finalbody = self.bloc(s.finalbody) if s.finalbody else []
            return [self._passage(sid, 0, s), s]
        if isinstance(s, (ast.With, ast.AsyncWith)):
            c = sum(cout(i.context_expr) + (cout_cible(i.optional_vars) if i.optional_vars else 0) for i in s.items)
            s.items = [self.visit(i) for i in s.items]
            s.body = self.bloc(s.body)
            return [self._passage(sid, c, s), s]
        if isinstance(s, ast.AsyncFor):
            c = cout(s.iter) + cout_cible(s.target)
            s.iter = self.visit(s.iter)
            s.body = self.bloc(s.body)
            s.orelse = self.bloc(s.orelse) if s.orelse else []
            return [self._passage(sid, c, s), s]
        if isinstance(s, ast.Match):
            c = cout(s.subject)
            s.subject = self.visit(s.subject)
            for cas in s.cases:
                if cas.guard is not None:
                    cas.guard = self.visit(cas.guard)
                cas.body = self.bloc(cas.body)
            return [self._passage(sid, c, s), s]
        if (isinstance(s, ast.Delete) and len(s.targets) == 1 and isinstance(s.targets[0], ast.Subscript)
                and not isinstance(s.targets[0].slice, ast.Slice)):
            t = s.targets[0]
            c = cout(t.value) + cout(t.slice)
            hid = self._noeud(t)
            appel = _appel("supprime", _const(hid), self.visit(t.value), self.visit(t.slice))
            return [self._passage(sid, c, s), ast.copy_location(ast.Expr(appel), s)]
        if isinstance(s, ast.AugAssign) and type(s.op) in _OPERATIONS and isinstance(s.target, ast.Name):
            # `s += x` : l'opération est enveloppée (concaténation de chaînes), l'affectation compte 1.
            c = 1 + cout(s.value)
            hid = self._noeud(s)
            valeur = _appel("augop", _const(hid), _const(_OPERATIONS[type(s.op)]),
                            ast.Name(id=s.target.id, ctx=ast.Load()), self.visit(s.value))
            nouveau = ast.Assign(targets=[ast.Name(id=s.target.id, ctx=ast.Store())], value=valeur)
            return [self._passage(sid, c, s), ast.copy_location(nouveau, s)]
        c = self._cout_simple(s)
        s = self.generic_visit(s)
        return [self._passage(sid, c, s), s]

    @staticmethod
    def _cout_simple(s: ast.stmt) -> int:
        if isinstance(s, ast.Assign):
            return cout(s.value) + sum(cout_cible(t) for t in s.targets)
        if isinstance(s, ast.AnnAssign):
            return (cout(s.value) + cout_cible(s.target)) if s.value is not None else 0
        if isinstance(s, ast.AugAssign):
            return 2 + cout(s.value) + (cout_cible(s.target) - 1)  # opération + affectation (+ accès de la cible)
        if isinstance(s, ast.Expr):
            return cout(s.value)
        if isinstance(s, ast.Return):
            return 1 + cout(s.value)
        if isinstance(s, ast.Assert):
            return cout_test(s.test)
        if isinstance(s, ast.Raise):
            return 1 + cout(s.exc)
        if isinstance(s, (ast.Import, ast.ImportFrom)):
            return 1
        if isinstance(s, ast.Delete):
            return len(s.targets)
        return 0  # pass, break, continue

    # -- expressions

    def visit_Call(self, e: ast.Call) -> ast.expr:
        if isinstance(e.func, ast.Name) and e.func.id in _APPELS_DIRECTS:
            return self.generic_visit(e)
        hid = self._noeud(e)
        args = [self.visit(a) for a in e.args]
        mots = [self.visit(k) for k in e.keywords]
        if isinstance(e.func, ast.Attribute):
            nouveau = _appel("meth", _const(hid), self.visit(e.func.value), _const(e.func.attr), *args, mots=mots)
        else:
            nouveau = _appel("appel", _const(hid), self.visit(e.func), *args, mots=mots)
        return ast.copy_location(nouveau, e)

    def visit_Compare(self, e: ast.Compare) -> ast.expr:
        if len(e.ops) != 1 or type(e.ops[0]) not in _COMPARAISONS:
            return self.generic_visit(e)
        hid = self._noeud(e)
        nouveau = _appel("compare", _const(hid), _const(_COMPARAISONS[type(e.ops[0])]),
                         self.visit(e.left), self.visit(e.comparators[0]))
        return ast.copy_location(nouveau, e)

    def visit_BinOp(self, e: ast.BinOp) -> ast.expr:
        if type(e.op) not in _OPERATIONS:
            return self.generic_visit(e)
        hid = self._noeud(e)
        nouveau = _appel("binop", _const(hid), _const(_OPERATIONS[type(e.op)]), self.visit(e.left),
                         self.visit(e.right))
        return ast.copy_location(nouveau, e)

    def visit_Subscript(self, e: ast.Subscript) -> ast.expr:
        if not (isinstance(e.ctx, ast.Load) and isinstance(e.slice, ast.Slice)):
            return self.generic_visit(e)
        hid = self._noeud(e)
        t = e.slice
        bornes = [self.visit(b) if b is not None else _const(None) for b in (t.lower, t.upper, t.step)]
        return ast.copy_location(_appel("tranche", _const(hid), self.visit(e.value), *bornes), e)

    def visit_BoolOp(self, e: ast.BoolOp) -> ast.expr:
        dernier = len(e.values) - 1
        valeurs = [self.visit(e.values[0])]
        for i, v in enumerate(e.values[1:], start=1):
            valeurs.append(self._compte(v, cout(v) + (1 if i < dernier else 0)))
        e.values = valeurs
        return e

    def visit_IfExp(self, e: ast.IfExp) -> ast.expr:
        e.test = self.visit(e.test)
        e.body = self._compte(e.body, cout(e.body))
        e.orelse = self._compte(e.orelse, cout(e.orelse))
        return e

    def visit_Lambda(self, e: ast.Lambda) -> ast.expr:
        e.args = self.visit(e.args)
        e.body = self._compte(e.body, 1 + cout(e.body))  # le corps, et le retour de sa valeur
        return e

    def _generateurs(self, e: ast.ListComp | ast.SetComp | ast.DictComp | ast.GeneratorExp) -> None:
        for i, g in enumerate(e.generators):
            # Le premier itérable est évalué une fois, dans l'instruction ; les suivants à chaque tour.
            iterable = self.visit(g.iter) if i == 0 else self._compte(g.iter, cout(g.iter))
            g.iter = ast.copy_location(
                _appel("parcours", _const(self.courante), _const(cout_cible(g.target)), iterable), g.iter
            )
            g.ifs = [self._compte(f, cout_test(f)) for f in g.ifs]

    def visit_ListComp(self, e: ast.ListComp) -> ast.expr:
        self._generateurs(e)
        e.elt = self._compte(e.elt, cout(e.elt) + 1)  # l'élément, et son ajout
        return e

    visit_SetComp = visit_ListComp

    def visit_GeneratorExp(self, e: ast.GeneratorExp) -> ast.expr:
        self._generateurs(e)
        e.elt = self._compte(e.elt, cout(e.elt))
        return e

    def visit_DictComp(self, e: ast.DictComp) -> ast.expr:
        self._generateurs(e)
        e.key = self._compte(e.key, cout(e.key) + cout(e.value) + 1)
        e.value = self.visit(e.value)
        return e


def instrumenter(source: str, fichier: str = FICHIER) -> tuple[Any, Table]:
    """Réécrit `source` et le compile. Les numéros de ligne restent ceux de l'élève (traces d'erreur justes)."""
    arbre = ast.parse(source, fichier)
    inst = _Instrumenteur(source)
    arbre.body = inst.bloc(arbre.body, tete=True)
    ast.fix_missing_locations(arbre)
    return compile(arbre, fichier, "exec"), inst.table


# ---------------------------------------------------------------------------------------------------------------------
# Exécution : le compteur


class _Cle:
    """Enveloppe d'un élément trié : compte chaque comparaison faite par le tri (il n'emploie que `<`)."""

    __slots__ = ("v", "n")

    def __init__(self, v: Any, n: list[int]) -> None:
        self.v = v
        self.n = n

    def __lt__(self, autre: _Cle) -> bool:
        self.n[0] += 1
        return self.v < autre.v


class _Consomme:
    """Itérateur qui compte les éléments consommés (sum, min, max, any, all, qui peuvent s'arrêter avant la fin)."""

    __slots__ = ("it", "n")

    def __init__(self, iterable: Iterable[Any]) -> None:
        self.it = iter(iterable)
        self.n = 0

    def __iter__(self) -> _Consomme:
        return self

    def __next__(self) -> Any:
        v = next(self.it)
        self.n += 1
        return v


_PARCOURUS = {sum, min, max, any, all}
_CONSTRUITS = {list, tuple, set, frozenset, dict}
_SEQUENCES = (list, str, tuple, bytes)
_LINEAIRES_STR = {"find", "rfind", "index", "rindex", "count", "replace", "split", "rsplit", "strip", "lstrip",
                  "rstrip", "lower", "upper", "capitalize", "title", "swapcase", "splitlines", "partition",
                  "rpartition", "isdigit", "isalpha", "isalnum", "isspace", "islower", "isupper"}
_DICT_VUES = (type({}.keys()), type({}.items()))


def _parmi(f: Any, ensemble: set[Any]) -> bool:
    try:
        return f in ensemble
    except TypeError:  # objet appelable non hachable
        return False


def _longueur(x: Any) -> int | None:
    try:
        return len(x)
    except TypeError:
        return None


class Compteur:
    """L'objet `__cx__` que le code réécrit appelle."""

    def __init__(self, table: Table, fichier: str = FICHIER) -> None:
        self.table = table
        self.fichier = fichier
        self.total = 0
        n = len(table.instructions)
        self.passages = [0] * n
        self.operations = [0] * n  # opérations propres de chaque instruction (hors nœuds enveloppés)
        m = len(table.noeuds)
        self.noeud_passages = [0] * m
        self.noeud_cout = [0] * m  # appel d'une fonction de l'élève : coût inclusif
        self.noeud_nature = [ELEMENTAIRE] * m
        self._actifs: dict[Any, int] = {}

    # -- instructions

    def p(self, sid: int, c: int) -> None:
        self.passages[sid] += 1
        self.operations[sid] += c
        self.total += c

    def test(self, sid: int, c: int, v: Any) -> Any:
        self.passages[sid] += 1
        self.operations[sid] += c
        self.total += c
        return v

    def compte(self, sid: int, c: int, v: Any) -> Any:
        self.operations[sid] += c
        self.total += c
        return v

    def boucle(self, sid: int, n: int, iterable: Iterable[Any]) -> Iterator[Any]:
        """En-tête `for` : un passage par test ; à chaque tour un test et n affectations, puis le test qui sort."""
        c = 1 + n
        passages, operations = self.passages, self.operations
        for v in iterable:
            passages[sid] += 1
            operations[sid] += c
            self.total += c
            yield v
        passages[sid] += 1
        operations[sid] += 1
        self.total += 1

    def parcours(self, sid: int, n: int, iterable: Iterable[Any]) -> Iterator[Any]:
        """Boucle d'une compréhension : les mêmes opérations que `boucle`, sans passage de ligne."""
        c = 1 + n
        operations = self.operations
        for v in iterable:
            operations[sid] += c
            self.total += c
            yield v
        operations[sid] += 1
        self.total += 1

    # -- nœuds enveloppés

    def _compter(self, hid: int, c: int, nature: str) -> None:
        self.noeud_passages[hid] += 1
        self.noeud_cout[hid] += c
        self.total += c
        if c > 1:
            self.noeud_nature[hid] = nature

    def _code_eleve(self, f: Any) -> Any:
        code = getattr(f, "__code__", None)
        if code is None:
            code = getattr(getattr(f, "__func__", None), "__code__", None)
        if code is None and isinstance(f, type):
            code = getattr(f.__dict__.get("__init__"), "__code__", None)
        return code if code is not None and code.co_filename == self.fichier else None

    def appel(self, hid: int, f: Callable[..., Any], /, *a: Any, **kw: Any) -> Any:
        code = self._code_eleve(f)
        if code is not None:
            return self._appel_eleve(hid, code, f, a, kw)
        if f is sorted:
            return self._trier(hid, list(a[0]), *a[1:], **kw)
        if _parmi(f, _PARCOURUS) and len(a) == 1:
            it = _Consomme(a[0])
            r = f(it, **kw)
            self._compter(hid, max(1, it.n), PARCOURS)
            return r
        if _parmi(f, _PARCOURUS) and len(a) > 1:
            r = f(*a, **kw)
            self._compter(hid, len(a) - 1, COMPARAISONS)
            return r
        r = f(*a, **kw)
        if a and _parmi(f, _CONSTRUITS):
            self._compter(hid, max(1, len(r)), COPIE)
        else:
            self._compter(hid, 1, ELEMENTAIRE)
        return r

    def _appel_eleve(self, hid: int, code: Any, f: Callable[..., Any], a: tuple[Any, ...], kw: dict[str, Any]) -> Any:
        """Coût inclusif : l'appel, plus tout ce que le corps fait exécuter (déjà compté une fois dans `total`).
        Pour un appel récursif, seul l'appel le plus extérieur porte le coût inclusif, sinon il serait additionné
        à chaque niveau sur la même ligne."""
        exterieur = self._actifs.get(code, 0) == 0
        self._actifs[code] = self._actifs.get(code, 0) + 1
        self.total += 1
        avant = self.total
        try:
            return f(*a, **kw)
        finally:
            self._actifs[code] -= 1
            self.noeud_passages[hid] += 1
            self.noeud_cout[hid] += 1 + (self.total - avant if exterieur else 0)
            if self.noeud_cout[hid] > self.noeud_passages[hid]:
                self.noeud_nature[hid] = FONCTION

    def _trier(self, hid: int, liste: list[Any], key: Callable[[Any], Any] | None = None,
               reverse: bool = False) -> list[Any]:
        """Tri en place de `liste`, comparaisons comptées exactement (décision de l'utilisateur, 30/10/2026)."""
        n = [0]
        if key is None:
            liste.sort(key=lambda v: _Cle(v, n), reverse=reverse)
        else:
            liste.sort(key=lambda v: _Cle(key(v), n), reverse=reverse)
        self._compter(hid, max(1, n[0]), TRI)
        return liste

    def meth(self, hid: int, obj: Any, nom: str, /, *a: Any, **kw: Any) -> Any:
        t = type(obj)
        if t is list:
            return self._meth_liste(hid, obj, nom, a, kw)
        if t is tuple and nom in ("index", "count"):
            return self._meth_liste(hid, obj, nom, a, kw)
        if t is str:
            r = getattr(obj, nom)(*a, **kw)
            if nom == "join":
                self._compter(hid, max(1, len(r)), COPIE)
            elif nom in _LINEAIRES_STR:
                self._compter(hid, max(1, len(obj)), PARCOURS)
            else:
                self._compter(hid, 1, ELEMENTAIRE)
            return r
        if t in (dict, set, frozenset):
            r = getattr(obj, nom)(*a, **kw)
            if nom == "copy":
                self._compter(hid, max(1, len(r)), COPIE)
            elif nom in ("update", "union", "intersection", "difference", "symmetric_difference"):
                self._compter(hid, max(1, sum(_longueur(x) or 1 for x in a)), PARCOURS)
            else:
                self._compter(hid, 1, ELEMENTAIRE)
            return r
        return self.appel(hid, getattr(obj, nom), *a, **kw)

    def _meth_liste(self, hid: int, obj: list[Any], nom: str, a: tuple[Any, ...], kw: dict[str, Any]) -> Any:
        n = len(obj)
        if nom == "sort":
            self._trier(hid, obj, **kw)
            return None
        if nom == "pop":
            i = a[0] if a else -1
            if n and i < 0:
                i += n
            r = obj.pop(*a)
            self._compter(hid, max(1, n - 1 - i), DECALAGE)
            return r
        if nom == "insert":
            i = a[0]
            i = max(0, min(n, i + n if i < 0 else i))
            obj.insert(*a)
            self._compter(hid, max(1, n - i), DECALAGE)
            return None
        if nom in ("index", "remove"):
            try:
                r = getattr(obj, nom)(*a, **kw)
            except ValueError:
                self._compter(hid, max(1, n), COMPARAISONS)
                raise
            # index : comparaisons jusqu'à l'élément ; remove : comparaisons puis décalage, n en tout.
            self._compter(hid, max(1, r + 1 if nom == "index" else n), COMPARAISONS if nom == "index" else DECALAGE)
            return r
        r = getattr(obj, nom)(*a, **kw)
        if nom in ("count", "reverse"):
            self._compter(hid, max(1, n), PARCOURS)
        elif nom == "copy":
            self._compter(hid, max(1, n), COPIE)
        elif nom == "extend":
            self._compter(hid, max(1, len(obj) - n), COPIE)
        else:
            self._compter(hid, 1, ELEMENTAIRE)
        return r

    def _dans(self, x: Any, c: Any) -> tuple[int, bool]:
        t = type(c)
        if t is list or t is tuple:
            for i, e in enumerate(c):
                if e is x or e == x:
                    return i + 1, True
            return max(1, len(c)), False
        if t is str and type(x) is str:
            i = c.find(x)
            return max(1, i + len(x) if i >= 0 else len(c)), i >= 0
        if t is type({}.values()):
            return max(1, len(c)), x in c
        return 1, x in c  # dict, set, range, clés de dict : hachage, élémentaire

    def compare(self, hid: int, op: str, x: Any, y: Any) -> Any:
        if op in ("in", "not in"):
            c, r = self._dans(x, y)
            self._compter(hid, c, COMPARAISONS)
            return r if op == "in" else not r
        r = x == y if op == "==" else x != y
        tx = type(x)
        c = 1
        if tx is type(y) and (tx is list or tx is tuple) and len(x) == len(y):
            c = len(x)
            for i, (u, v) in enumerate(zip(x, y)):
                if not (u is v or u == v):
                    c = i + 1
                    break
        elif tx is type(y) and (tx is dict or tx is set) and len(x) == len(y):
            c = len(x)
        self._compter(hid, max(1, c), COMPARAISONS)
        return r

    def binop(self, hid: int, op: str, a: Any, b: Any) -> Any:
        r = a + b if op == "+" else a * b
        if isinstance(r, _SEQUENCES):
            self._compter(hid, max(1, len(r)), COPIE)
        else:
            self._compter(hid, 1, ELEMENTAIRE)
        return r

    def augop(self, hid: int, op: str, a: Any, b: Any) -> Any:
        """`a += b` : en place pour une liste (seuls les éléments ajoutés sont copiés), copie entière pour une chaîne."""
        avant = _longueur(a) if type(a) is list else None
        r = operator.iadd(a, b) if op == "+" else operator.imul(a, b)
        if avant is not None:
            self._compter(hid, max(1, len(r) - avant), COPIE)
        elif isinstance(r, _SEQUENCES):
            self._compter(hid, max(1, len(r)), COPIE)
        else:
            self._compter(hid, 1, ELEMENTAIRE)
        return r

    def tranche(self, hid: int, obj: Any, debut: Any, fin: Any, pas: Any) -> Any:
        r = obj[slice(debut, fin, pas)]
        n = _longueur(r) if isinstance(obj, _SEQUENCES) else None
        self._compter(hid, max(1, n) if n is not None else 1, COPIE)
        return r

    def supprime(self, hid: int, obj: Any, i: Any) -> None:
        if type(obj) is list and isinstance(i, int):
            n = len(obj)
            j = i + n if i < 0 else i
            del obj[i]
            self._compter(hid, max(1, n - 1 - j), DECALAGE)
        else:
            del obj[i]
            self._compter(hid, 1, ELEMENTAIRE)


# ---------------------------------------------------------------------------------------------------------------------
# Résultats


@dataclass
class Ligne:
    passages: int  # le plus grand nombre de passages des instructions de la ligne
    operations: int  # opérations de la ligne, appels de fonctions de l'élève compris (coût inclusif)


@dataclass
class Cache:
    """Une instruction qui cache un coût : à colorier sur son étendue."""

    ligne: int
    colonne: int
    fin_ligne: int
    fin_colonne: int
    texte: str
    passages: int
    operations: int
    nature: str


@dataclass
class Resultats:
    lignes: dict[int, Ligne]
    caches: list[Cache]
    total: int  # chaque opération comptée une fois
    erreur: BaseException | None = None

    def vers_dict(self) -> dict[str, Any]:
        """Forme JSON (ligne de contrôle de la console des QCM, lanceur de SmartPython Editor)."""
        return {
            "lignes": {str(n): [l.passages, l.operations] for n, l in sorted(self.lignes.items())},
            "caches": [[c.ligne, c.colonne, c.fin_ligne, c.fin_colonne, c.texte, c.passages, c.operations, c.nature]
                       for c in self.caches],
            "total": self.total,
            "erreur": None if self.erreur is None else f"{type(self.erreur).__name__}: {self.erreur}",
        }


def resultats(compteur: Compteur) -> Resultats:
    table = compteur.table
    lignes: dict[int, Ligne] = {}
    for sid, n in enumerate(table.instructions):
        if compteur.passages[sid] == 0 and compteur.operations[sid] == 0:
            continue
        l = lignes.setdefault(n, Ligne(0, 0))
        l.passages = max(l.passages, compteur.passages[sid])
        l.operations += compteur.operations[sid]
    caches = []
    for hid, nd in enumerate(table.noeuds):
        passages, ops = compteur.noeud_passages[hid], compteur.noeud_cout[hid]
        if passages == 0:
            continue
        ligne = table.instructions[nd.instruction]
        lignes.setdefault(ligne, Ligne(0, 0)).operations += ops
        if ops > passages:
            caches.append(Cache(nd.ligne, nd.colonne, nd.fin_ligne, nd.fin_colonne, nd.texte, passages, ops,
                                compteur.noeud_nature[hid]))
    return Resultats(lignes, caches, compteur.total)


def profiler(source: str, globales: dict[str, Any] | None = None, fichier: str = FICHIER) -> Resultats:
    """Exécute `source` en comptant ses opérations élémentaires. Une exception du programme est rendue dans
    `Resultats.erreur` : les comptes jusqu'à l'erreur restent lisibles. Vaut aussi pour `SystemExit` (un `exit()` du
    programme) et `KeyboardInterrupt` (le bouton Stop d'un éditeur) : l'appelant garde les comptes partiels, et relève
    lui-même l'interruption s'il doit la propager."""
    code, table = instrumenter(source, fichier)
    compteur = Compteur(table, fichier)
    g = {"__name__": "__main__"} if globales is None else globales
    g[NOM] = compteur
    erreur = None
    try:
        exec(code, g)
    except BaseException as e:  # noqa: BLE001 - échec, exit() ou Stop : on rend ce qui a été compté
        erreur = e
    r = resultats(compteur)
    r.erreur = erreur
    return r
