"""Les deux mots de passe d'un sujet chiffré (.qcm) : celui du professeur, fixe, qui ouvre tous ses sujets et toutes leurs
copies, et le code donné à une classe, qui change avec chaque export.

Le fichier est le même pour toutes les classes ; sa clé (``cle_sujet``) se dérive du mot de passe professeur et du sel scrypt de
l'en-tête age, lisible en clair (``serializejson._encryption.salt``) : les outils du professeur la recalculent seuls, quel
que soit le nom du fichier. Le code d'une classe (``code_classe``) porte cette clé, le rang de la classe dans ``inscrits``
(ou ``SANS_CLASSE`` : n'importe qui entre, ses copies sont rangées à part), et s'il y a lieu l'heure de DÉPART (le sujet ne
s'ouvre pas avant), la DURÉE de l'épreuve (elle remplace celle du sujet), l'ÉCHÉANCE (le code ne sert plus après, et le
lecteur rend la copie à cette heure), l'ANTI-TRICHE (``anti_triche``), le TEMPS (``temps`` : écran ou absolu) et le mode de SOUMISSION (``SOUMISSIONS``, ``variantes``), le tout mêlé
par une règle que seul le lecteur connaît ; le lecteur refuse un code hors de ses dates, à l'heure en ligne (``horloge``)
ou, sans réseau, à celle de l'ordinateur, puis ne laisse entrer qu'un élève inscrit dans la classe du code (``reconnaitre``).
Le même fichier, déposé d'avance sur les ordinateurs des élèves, s'ouvre ainsi par autant de codes qu'il y a de classes
et de créneaux.

Un code de classe est une PHRASE française faite des mots de ``PHRASES`` (« une tomate timide dessine souvent un château
rouge ») : nom 11 bits, adjectif 9, verbe 9, adverbe 9, nom 11, adjectif 9, soit 58 bits, tous porteurs (``code_classe`` :
clé 26, anti-triche 1, classe 3, temps 1, départ 14, durée 6, échéance 7). Des mots, parce que des élèves se trompent en recopiant des lettres et des
chiffres, et qu'un mot mal orthographié se CORRIGE (``corrections`` : le mot le plus proche de chaque liste, dont deux mots
sont toujours à plus d'une faute) là où une suite de caractères ne se corrige pas ; une phrase, parce qu'elle se retient et
se recopie mieux qu'une suite de mots sans lien. Les déterminants (« un », « une ») et l'accord de l'adjectif ne portent
rien : une faute sur eux n'en est pas une. Aucun bit de contrôle : toute phrase de six mots des listes se lit comme un code,
et c'est le déchiffrement du fichier qui juge (une phrase quelconque l'ouvre 7 fois sur 2²⁶, une par mode de soumission).
La clé a 26 bits, que age dérive par scrypt (0,32 s par essai, mesuré) : environ neuf mois de calcul sur un cœur pour un
seul sujet que la classe connaît déjà — les modes n'y changent rien, c'est la clé du fichier qu'on essaierait, pas des phrases.
Le départ se compte par pas de 5 minutes, modulo 2¹⁴ (57 jours) : il se lit comme la date la plus proche de l'heure, au
plus 14 jours plus tard ou 42 jours plus tôt. Un code qui peut servir plus longtemps (sans échéance, échéance à 43 jours ou
plus, ou à la fin de l'année scolaire : ``LONGS``) compte son départ en heures, modulo 2¹⁴ (1 an et 10 mois) : sinon, au-delà
de 42 jours, il se relirait 57 jours trop tard, et serait refusé comme pas encore ouvert.
Le bit du temps (``ABSOLU`` ou ``ECRAN``) est le 15e bit du départ jusqu'au 08/10/2026, où il le lui a pris : il s'écrit
relatif à l'anti-triche et à ce bit du départ complet, pour qu'un code d'avant (départ sur 15 bits, des 42 derniers jours)
se lise sans temps propre, ``ABSOLU`` sous anti-triche et ``ECRAN`` sinon, la règle de ce jour-là.

Chaque élève entre par son MOT DE PASSE, le même pour tous les sujets de l'année (``reconnaitre_mot_de_passe``) ; la copie
garde sa publique pour ``empreinte`` : dès qu'une copie est déposée avec elle, la page web (``web/pyqt6/pont_qt.py``) n'en
accepte plus d'autre sous ce nom — personne ne répond à sa place. Les listes de classes gardent un identifiant anonyme par
élève (``code_personnel``, colonne ``code``), celui qu'une feuille PAPIER porte : ce n'est plus un mot de passe.

C'est une protection d'obscurité, pas de cryptographie : la règle est dans le code source du lecteur, et qui a lu un code
peut en tirer la clé et déchiffrer le fichier sans le lecteur. Elle suffit à ce qu'elle vise : qu'un sujet ne s'ouvre ni
avant l'heure, ni dans une autre classe, ni après la fin du cours.

Module pur Python : il tourne aussi dans le navigateur (Pyodide).
"""

import base64
import csv
import difflib
import hashlib
import hmac
import itertools
import json
import os
import re
import sys
import unicodedata
from datetime import datetime, timedelta, timezone
from functools import cache
from pathlib import Path
from typing import Any, NamedTuple

from serializejson import rapidjson

import horloge
from noyau import ABSOLU, ECRAN, SOUMISSIONS, TEMPS, normaliser

# 2 048 noms avec leur genre, 512 adjectifs avec leur féminin, 512 verbes, 512 adverbes (``outils/phrases_codes.py``)
PHRASES = Path(__file__).with_name("phrases_codes.txt")
CASES = "navdna"  # un code de classe : nom, adjectif, verbe, adverbe, nom, adjectif
DETERMINANTS = {"m": "un", "f": "une"}
# Le mot de passe professeur : un secret tiré au hasard (``secrets.token_urlsafe(32)``), sans lien avec aucun mot de passe du
# professeur, dans un fichier en clair hors du dépôt, lisible de son compte et de celui de Claude (groupe partagé de /DATA/Python) :
# les deux fabriquent et ouvrent les sujets et les copies. Choix de l'utilisateur, 27/09/2026, à la place du portefeuille KDE, que
# le compte de Claude ne peut pas interroger ; un secret aléatoire plutôt que son mot de passe, que la clé de 26 bits d'un fichier
# (HMAC sans étape lente) livrerait à un dictionnaire.
FICHIER = Path(__file__).resolve().parent.parent.parent / ".smartteacher_professeur"  # pas parents[2] : /lecteur/codes.py sur le web
VARIABLE = "SMARTTEACHER_PROFESSEUR"  # le remplace pour les tests
VARIABLE_FICHIER = "SMARTTEACHER_PROFESSEUR_FICHIER"  # remplace le CHEMIN de ``FICHIER`` : la copie de la suite des tests
# (``tests_modele.py``) n'est pas sous /DATA/Python, ses testeurs de la correction ouvrent pourtant les vrais sujets
ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"  # base 32 de Crockford, pour écrire la clé age d'un sujet
PAS = 5  # minutes : le pas du départ, de la durée et des échéances courtes
AVANCE = 14 * 24 * 60  # minutes : un départ se lit au plus 14 jours après l'heure, sinon avant (``_decoder``)
FIN_ANNEE = 127  # le rang d'échéance « fin de l'année scolaire » : minuit à Paris, le soir du 31 juillet (``fin_annee``)
# les rangs (sans échéance, minuit 43 à 79 jours après, fin d'année) dont le départ se compte en heures : le code sert plus
# longtemps que les 42 jours qu'un départ par pas de 5 minutes, sur 14 bits, sait relire en arrière (aucun code de 43 jours ou
# plus n'avait été donné quand ce rang y est entré, 08/10/2026)
LONGS = 1, *range(90, FIN_ANNEE + 1)
SANS_CLASSE = 7  # le rang d'un code qui ne vérifie aucune liste : entraînement, ou élève absent des listes
CLASSES = 7  # classes par sujet au plus (rangs 0 à 6)
NIVEAUX = "Seconde", "Première", "Terminale"
HORS_LISTE = "Hors liste"  # le dossier des copies rendues avec le code sans classe
PROFESSEUR = "de La Gorce", "Baptiste"  # hors des listes : ce nom n'entre que par le mot de passe professeur (``cle_du_mot``)
SEUIL = 0.8  # ressemblance minimale d'un nom tapé à celui de la liste (difflib)
FAUTES = 2  # lettres fausses corrigées au plus dans l'ensemble d'un code (``corrections``)
MOT_DE_PASSE = 8  # caractères au moins d'un mot de passe choisi par l'élève (``mot_de_passe_refuse``)
# le fichier d'empreintes : à la racine du dossier Dropbox du professeur (lecteur web), dans le dossier partagé de l'élève
# (natif) ; ``{"version": 1, "eleves": {nom_identite: deposer(…)}}``
IDENTITES = "identites.json"
ESSAIS = 8  # lectures corrigées essayées au plus sur le fichier (0,32 s par mode de soumission chacune, ``variantes``)


class Code(NamedTuple):
    cle: str
    classe: int
    depart: datetime | None = None  # en UTC : le sujet ne s'ouvre pas avant
    duree: int | None = None  # minutes : remplace ``duree_minutes`` du sujet
    echeance: datetime | None = None  # en UTC : le code ne sert plus après, la copie est rendue à cette heure
    soumission: int = 0  # le mode de soumission, une clé de ``SOUMISSIONS``
    anti_triche: bool = False  # l'anti-triche (``Paquet.anti_triche``), qui remplace celui du sujet
    temps: str = ECRAN  # le temps de l'épreuve (``Paquet.temps``), qui remplace celui du sujet


def professeur():
    """Le mot de passe du professeur, lu dans ``FICHIER``, ou ``None`` sur une machine qui ne l'a pas (celle d'un élève, le
    navigateur)."""
    if sys.platform == "emscripten":
        return None
    if os.environ.get(VARIABLE):
        return os.environ[VARIABLE]
    fichier = fichier_professeur()
    return fichier.read_text().strip() if fichier.exists() else None


def fichier_professeur() -> Path:
    """Le fichier du mot de passe professeur : ``FICHIER``, ou celui que nomme ``VARIABLE_FICHIER``."""
    return Path(os.environ.get(VARIABLE_FICHIER) or FICHIER)


def cle_sujet(professeur, sel):
    """La clé age d'un sujet : 6 caractères (26 bits : le 27e du code dit l'anti-triche) tirés du mot de passe professeur et
    du sel de son en-tête."""
    return _en_base32(int.from_bytes(hmac.digest(professeur.encode(), sel, "sha256")[:4], "big") >> 6, 6)


def graine_echeances(professeur: str) -> bytes:
    """La clé secrète Ed25519 (32 octets) qui signe ``echeances.csv`` (``echeances.signer``), tirée du mot de passe professeur
    par scrypt 2¹⁷, comme ``secret_eleve`` : la clé publique, dans la page, ne doit pas donner un essai rapide du mot de passe.
    Jamais écrite ni affichée ; le mot de passe lui-même ne signe rien."""
    return rapidjson._scrypt(professeur.encode(), b"SmartTeacher echeances v1", 1 << 17, 8, 1, 32)


def cle_du_fichier(chemin):
    """La clé d'un sujet (ou de la copie d'un élève), recalculée depuis le mot de passe professeur ; ``None`` sans mot de
    passe professeur, ou pour un fichier qui n'est pas chiffré."""
    secret = professeur()
    return secret and cle_du_mot(secret, Path(chemin).read_bytes())


def cle_du_mot(mot, octets):
    """La clé du fichier ``octets`` si ``mot`` est le mot de passe professeur (l'ouvrir le vérifie), tirée du sel écrit en
    clair dans son en-tête age ; ``None`` pour un fichier qui n'est pas chiffré. L'en-tête est lu ici plutôt que par
    ``serializejson._encryption.salt``, que la roue du navigateur n'a pas : c'est là que le professeur tape son mot de passe
    (``lecteur.Accueil.deverrouiller``)."""
    sel = sel_du_fichier(octets)
    return sel and cle_sujet(mot, base64.b64decode(sel + "=" * (-len(sel) % 4)))


ARMURE = b"-----BEGIN AGE ENCRYPTED FILE-----"


def sel_du_fichier(octets: bytes) -> str | None:
    """Le sel scrypt de l'en-tête age de ``octets``, en base64 : le même pour un sujet et toutes ses copies. ``None`` pour un
    fichier qui n'est pas chiffré. Une copie du navigateur est en armure ASCII (``modele.sauver``) : l'en-tête se désarme
    de ses premières lignes base64, 200 octets suffisent (``lecteur.sel_de``)."""
    if octets.startswith(ARMURE):
        texte = b"".join(octets[len(ARMURE):400].split(b"-----")[0].split())  # sans la ligne de fin d'un petit fichier
        octets = base64.b64decode(texte[:len(texte) // 4 * 4])
    sel = re.search(rb"^-> scrypt ([A-Za-z0-9+/]+) \d+$", octets[:200], re.MULTILINE)
    return sel and sel[1].decode()


def code_classe(cle, classe, depart=None, duree=None, echeance=None, soumission=0, anti_triche=False, temps=ECRAN):
    """Le code à donner à la classe de rang ``classe`` (dans ``sorted(paquet.inscrits)``, ou ``SANS_CLASSE``) : une phrase,
    « une tomate timide dessine souvent un château rouge ». Dates UTC, ou à l'heure de cette machine si elles n'ont pas de
    fuseau. ``depart`` se prend à 5 minutes près (arrondi en dessous) ; ``duree`` en minutes, multiple de 5, de 5 à 315 ;
    ``echeance`` demande un ``depart`` et doit tomber de 5 à 120 minutes après lui par pas de 5, ou de 3 à 24 heures après
    par heures pleines, ou à minuit (heure de Paris) de 1 à 79 jours après sa date : 1 jour, c'est le soir même, ou à la fin
    de l'année scolaire (``fin_annee``). Sans échéance ou à la fin de l'année, le départ se prend à l'heure près (``LONGS``).
    ``soumission`` (une clé de ``SOUMISSIONS``) retourne les bits de tête de la clé : le code n'ouvre le fichier que par
    sa variante (``variantes``), et le lecteur qui l'ouvre ainsi sait quel mode il porte ; la clé du fichier ne change pas.
    ``anti_triche`` et ``temps`` (``ECRAN`` ou ``ABSOLU``) : ceux de l'épreuve, un bit chacun."""
    if not 0 <= classe <= SANS_CLASSE:
        raise ValueError(f"{CLASSES} classes au plus par sujet")
    if duree is not None and not (duree % PAS == 0 and PAS <= duree <= 63 * PAS):
        raise ValueError(f"durée de {duree} min : un multiple de 5, de 5 à 315 minutes")
    if echeance is not None and depart is None:
        raise ValueError("une échéance se compte depuis un départ")
    if temps not in TEMPS:
        raise ValueError(f"temps « {temps} » : {' ou '.join(TEMPS)}")
    if soumission not in SOUMISSIONS:
        raise ValueError(f"mode de soumission {soumission} : une clé de SOUMISSIONS")
    rang = 0 if depart is None else 1 if echeance is None else _rang_echeance(_minutes(depart) // PAS * PAS, _minutes(echeance))
    pas = depart and _minutes(depart) // (60 if rang in LONGS else PAS)
    bit = (temps == ABSOLU) ^ bool(anti_triche) ^ ((pas or 0) >> 14 & 1)  # relatif (docstring du module) : 0 pour un code d'avant
    info = ((_en_entier(cle) ^ soumission << 23) << 32 | bool(anti_triche) << 31 | classe << 28 | bit << 27 | (pas or 0) % (1 << 14) << 13
            | (duree or 0) // PAS << 7 | rang)
    return _phrase(_rangs(_feistel(info)))


def lire_code(texte, maintenant=None):
    """Le ``Code`` que ``texte`` porte, écrit juste (casse, accents, séparateurs, déterminants et accords ignorés), ou ``None``
    si ce ne sont pas six mots des listes. Sans contrôle, toute phrase des listes se lit : seul le déchiffrement dit si c'est
    le bon code. Le départ se lit comme la date la plus proche de ``maintenant`` (l'heure en ligne par défaut)."""
    rangs = _rangs_du_texte(texte)
    return rangs and _decoder(rangs, maintenant)


def jeton(texte):
    """Le code de classe ``texte`` (écrit juste) en 12 caractères de base 32, pour un lien (``?code=``) : les mêmes 58 bits
    que la phrase, qu'une URL porterait en ~60 caractères accentués. ``None`` si ce ne sont pas six mots des listes."""
    rangs = _rangs_du_texte(texte)
    return rangs and _en_base32(_entier(rangs), 12)


def phrase_du_jeton(texte):
    """La phrase d'un ``jeton``, que l'accueil du lecteur lit comme si l'élève l'avait tapée ; ``None`` si ce n'en est pas un."""
    texte = texte.strip().upper()
    if len(texte) != 12 or set(texte) - set(ALPHABET) or _en_entier(texte) >> 58:
        return None
    return _phrase(_rangs(_en_entier(texte)))


def variantes(code):
    """Les lectures de ``code`` à essayer sur le fichier, une par mode de soumission (``code_classe``) dans l'ordre de
    ``SOUMISSIONS`` : les bits de tête de la clé retournés. Une phrase quelconque ouvre ainsi le fichier sept fois sur 2²⁶."""
    return [code._replace(cle=_en_base32(_en_entier(code.cle) ^ v << 23, 6), soumission=v) for v in SOUMISSIONS]


def _rangs_du_texte(texte):
    """Les rangs des six mots d'un code de classe écrit juste, ou ``None``."""
    mots = _mots_du_code(texte)
    rangs = mots and [_index()[case].get(m) for case, m in zip(CASES, mots)]
    return None if not rangs or None in rangs else rangs


def _entier(rangs):
    """Les 58 bits d'un code de classe, depuis les rangs de ses six mots (base mixte des tailles des listes)."""
    n = 0
    for case, rang in zip(CASES, rangs):
        n = n * len(_listes()[case]) + rang
    return n


def _rangs(n):
    """L'inverse d'``_entier``."""
    rangs = []
    for case in reversed(CASES):
        n, r = divmod(n, len(_listes()[case]))
        rangs.insert(0, r)
    return rangs


def _decoder(rangs, maintenant):
    info = _feistel(_entier(rangs), inverse=True)
    cle, classe, duree, rang = _en_base32(info >> 32, 6), info >> 28 & 7, (info >> 7 & 63) * PAS or None, info & 127
    anti_triche, bit = bool(info >> 31 & 1), info >> 27 & 1
    if not rang:
        return Code(cle, classe, None, duree, None, anti_triche=anti_triche, temps=ABSOLU if bit ^ anti_triche else ECRAN)
    unite = 60 if rang in LONGS else PAS
    maintenant = (int((maintenant.timestamp() if maintenant else horloge.secondes()) // 60) + AVANCE) // unite
    pas = maintenant - (maintenant - (info >> 13 & 0x3FFF)) % (1 << 14)  # le plus tard possible, au plus AVANCE après l'heure
    depart, temps = pas * unite, ABSOLU if bit ^ anti_triche ^ (pas >> 14 & 1) else ECRAN
    return Code(cle, classe, _date(depart), duree, None if rang == 1 else _date(_echeance(depart, rang)), anti_triche=anti_triche,
                temps=temps)


def _minutes(date):
    return int(date.astimezone(timezone.utc).timestamp()) // 60


def _date(minutes):
    return datetime.fromtimestamp(minutes * 60, timezone.utc)


def _echeance(depart, rang):
    """L'échéance (minutes UTC) du ``rang`` 2 à 127 d'un code parti à ``depart`` : 5 à 120 minutes après par pas de 5 (2 à
    25), 3 à 24 heures après (26 à 47), puis minuit à Paris, 1 à 79 jours après la date du départ (48 à 126), ou la fin de
    l'année scolaire (``FIN_ANNEE``)."""
    if rang <= 25:
        return depart + (rang - 1) * PAS
    if rang <= 47:
        return depart + (rang - 23) * 60
    if rang == FIN_ANNEE:
        return _minutes(fin_annee(_date(depart)))
    return _minutes(minuit(_date(depart), rang - 47))


def fin_annee(date):
    """La fin de l'année scolaire de ``date`` : minuit à Paris, le soir du 31 juillet qui suit (large : les cours finissent
    début juillet). En UTC."""
    jour = (date + timedelta(minutes=_decalage_paris(_minutes(date)))).date()  # la date à Paris
    annee = jour.year + (jour.month >= 8)
    return minuit(datetime(annee, 7, 31, 12, tzinfo=timezone.utc), 1)


def minuit(date, jours):
    """Minuit à Paris, ``jours`` après la date (à Paris) de ``date`` : 1, c'est la fin du jour même. En UTC."""
    jour = (date + timedelta(minutes=_decalage_paris(_minutes(date)))).date() + timedelta(days=jours)
    minutes = int(datetime(jour.year, jour.month, jour.day, tzinfo=timezone.utc).timestamp()) // 60
    return _date(minutes - _decalage_paris(minutes - 120))  # 22 h ou 23 h UTC la veille : jamais sur un changement d'heure


def _rang_echeance(depart, echeance):
    rang = next((r for r in range(2, 128) if _echeance(depart, r) == echeance), None)
    if rang is None:
        raise ValueError(f"échéance {_date(echeance):%d/%m/%Y %H:%M} UTC non codable : de 5 à 120 min après le départ par pas "
                         "de 5, de 3 à 24 h par heures pleines, à minuit (Paris) de 1 à 79 jours après, ou à la fin de l'année scolaire")
    return rang


def _decalage_paris(minutes):
    """Le décalage de l'heure de Paris sur UTC (minutes) à l'instant ``minutes`` UTC : 120 du dernier dimanche de mars au
    dernier dimanche d'octobre (à 1 h UTC), 60 sinon. Calculé, pas lu dans ``zoneinfo`` : le navigateur (Pyodide) n'a pas
    forcément la base des fuseaux."""
    instant = _date(minutes)

    def changement(mois):
        dernier = datetime(instant.year, mois, 31, 1, tzinfo=timezone.utc)
        return dernier - timedelta(days=(dernier.weekday() + 1) % 7)

    return 120 if changement(3) <= instant < changement(10) else 60


def corrections(texte, maintenant=None):
    """Les codes que ``texte`` voulait sans doute dire, écrits juste : six mots des listes, chacun à ``FAUTES`` lettres près
    au plus, à la plus petite somme de fautes (déterminants et accords ne comptent pas), ``ESSAIS`` au plus. Le plus souvent
    un seul : deux mots d'une liste sont à plus d'une faute l'un de l'autre. Au lecteur de les essayer sur le fichier."""
    mots = _mots_du_code(texte)
    if not mots:
        return []
    proches = [_proches(case, m) for case, m in zip(CASES, mots)]
    for fautes in range(FAUTES + 1):
        trouves = [_phrase(r) for r in itertools.islice(_combinaisons(proches, fautes), ESSAIS)]
        if trouves:
            return trouves
    return []


def refus(code, maintenant=None):
    """Pourquoi ``code`` n'ouvre pas le sujet maintenant (ses dates, à l'heure en ligne par défaut), ou ``""``."""
    maintenant = maintenant or horloge.maintenant()
    if code.echeance and maintenant >= code.echeance:
        return f"Ce code n'est plus valable depuis le {horloge.locale(code.echeance):%d/%m/%Y à %H:%M}."
    if code.depart and maintenant < code.depart:
        return f"Ce sujet ne s'ouvre qu'à partir du {horloge.locale(code.depart):%d/%m/%Y à %H:%M}."
    return ""


def niveau(classe):
    """Seconde, Première ou Terminale, lu dans le nom d'une liste de classe : « SECONDE 3 », « B3_P_NSINF_GR1 »,
    « B1_T_NSI_GR1 ». Un nom qui ne se lit pas est une erreur : pas de dossier deviné."""
    if normaliser(classe).startswith("seconde"):
        return "Seconde"
    parties = set(re.split(r"[_\s-]+", classe.upper()))
    if len({"P", "T"} & parties) == 1:
        return "Première" if "P" in parties else "Terminale"
    raise ValueError(f"niveau illisible dans le nom de classe « {classe} » : SECONDE n, …_P_… ou …_T_… attendu")


EN_LIGNE = {"SNT": "Seconde", "NSI/NSI Première": "Première", "NSI/NSI Terminale": "Terminale"}  # matière du disque → niveau de Dropbox
HORS_LIGNE = {"SANS IDE"}  # dossiers du disque absents du Dropbox : leur contenu remonte d'un cran


def en_ligne(chemin: str) -> str:
    """Où un chemin du dossier du professeur (``sujet.PROF`` : « SNT/Les réseaux sociaux/Mini-Interrogations ») se range dans
    son Dropbox : les niveaux à la racine, puis la même arborescence que sur le disque (« Seconde/Les_réseaux_sociaux/… »,
    arborescence validée par l'utilisateur le 29/09/2026), chaque nom passé par ``en_ascii`` : ce chemin est celui du lien
    des élèves ; ``""`` hors des trois niveaux (ESGI, bac, exemples). Un dossier de ``HORS_LIGNE`` est sauté : « SNT/Python/TP/
    SANS IDE » → « Seconde/Python/TP », seul le TP sans IDE étant en ligne et son nom le disant déjà (l'utilisateur,
    08/11/2026)."""
    for disque, dropbox in EN_LIGNE.items():
        if chemin == disque or chemin.startswith(disque + "/"):
            reste = [p for p in chemin[len(disque):].split("/") if p not in HORS_LIGNE]
            return en_ascii(dropbox + "/".join(reste))
    return ""


def en_ascii(nom):
    """``nom`` réduit à « A-Za-z0-9._-/ » : accents ôtés, « ° » en « o », tout autre signe (espace, virgule, apostrophe,
    parenthèse) en un seul « _ », jamais en bord de nom (« n°1 - Exécuter du code Python, Commentaires » →
    « no1_-_Executer_du_code_Python_Commentaires »). Un lien d'élève qui portait « ° » ou un accent était coupé par WhatsApp
    ou Edge (03/10/2026), et encoder en %XX l'enlaidissait : l'utilisateur a préféré normaliser les noms. La même fonction en
    JavaScript : ``ascii`` de web/pyqt6/dropbox.js (le cours cité par un .qcm avec les noms du disque)."""
    nom = unicodedata.normalize("NFKD", nom.replace("°", "o").replace("œ", "oe").replace("Œ", "OE").replace("æ", "ae"))
    nom = re.sub(r"[^A-Za-z0-9./-]+", "_", "".join(c for c in nom if not unicodedata.combining(c)))
    return re.sub(r"_(?=[./]|$)|(?<=/)_|^_", "", nom)


COPIE = re.compile(r" \[[^/]*\][^/]*\.(qcm|etat\.json)$")


def est_copie(chemin: str) -> bool:
    """``chemin`` est-il une copie d'élève (ou son témoin de présence ``.etat.json``) : « <sujet> [<élève>]….qcm » ? Un sujet
    déployé ne peut pas l'être, son nom passé par ``en_ascii`` n'a ni espace ni crochet. Remplace le « /Copies/ » du chemin,
    disparu le 11/10/2026 (``chemin_copie``) ; le même motif en JavaScript : ``copie`` de web/pyqt6/dropbox.js."""
    return bool(COPIE.search(chemin))

def essai(numero):
    """Ce qui suit le nom d'une copie au ``numero``-ième essai d'une révision (``Paquet.nouvel_essai``) : « (2ème essai) »,
    rien pour le premier (l'utilisateur, 03/10/2026)."""
    return f" ({numero}ème essai)" if numero > 1 else ""


def chemin_copie(inscrits, classe, sujet, eleve, dossier="", numero=1):
    """Où ranger une copie dans le dossier Dropbox du professeur : ``<dossier>/<sujet>/[<classe>/]<sujet> [<élève>].qcm``,
    ``<dossier>`` celui du sujet (son ``dossier`` du disque, ``en_ligne`` : les copies à côté du sujet, demande de
    l'utilisateur, 29/09/2026), à la racine hors des niveaux ; un dossier par sujet, sans « Copies/ », la classe dessous
    (arborescence normalisée par l'utilisateur, 11/10/2026), et seulement si le sujet en vise plusieurs ; le numéro de
    l'essai à la fin (``essai``). Le sujet déployé reste à côté, dans ``<dossier>`` : son chemin est le lien des élèves. Le nom de la copie reprend celui du sujet, comme celle qu'un
    élève ouvre depuis un PDF (``lecteur.copie``), pour qu'elle se reconnaisse hors de son dossier (demande de
    l'utilisateur, 28/09/2026).
    ``classe`` ``None`` : le code sans classe, rangé à part (« Hors liste ») pour ne jamais se confondre avec la copie d'un
    inscrit.
    Le niveau, en tête, est celui de la classe, pas celui du dossier du sujet : un sujet du dossier des Premières donné aussi
    à une Terminale (le projet Monkey) y range les copies de cette classe sous « Terminale/ » (l'utilisateur, 10/10/2026 :
    « range selon le niveau de la classe »), donc dans le dossier Dropbox des Terminales."""
    classes = [HORS_LISTE] if classe is None else [classe] if len(inscrits) > 1 else []
    racine = en_ligne(dossier)
    if racine and classe:
        racine = "/".join([en_ascii(niveau(classe)), *racine.split("/")[1:]])
    return "/".join(filter(None, [racine, *map(nom_de_fichier, [sujet, *classes, f"{sujet} [{eleve}]{essai(numero)}"])])) + ".qcm"


def code_personnel(professeur, nom, prenom):
    """L'identifiant anonyme d'un élève, un nom et son adjectif (« un tigre timide », 11 + 9 = 20 bits), le même toute
    l'année : ce que sa feuille papier porte (``listes_classes.py``, ``correction/``). Il n'ouvre plus rien en ligne."""
    n = int.from_bytes(hmac.digest(professeur.encode(), f"eleve|{normaliser(f'{nom} {prenom}')}".encode(), "sha256")[:8], "big")
    return _phrase([n % 2048, n // 2048 % 512])


def inscrire(liste: list[list[str]]) -> list[list[str]]:
    """Les élèves d'une classe tels que le sujet les porte : ``[nom, prénom]``."""
    return [[nom, prenom] for nom, prenom, *_ in liste]


# Le mot de passe choisi par l'élève (conception : SmartTeacher_essais/chantier_jeton/conception_mot_de_passe_W80.md). Il
# IDENTIFIE : de ``nom + mot de passe`` se tire un secret (scrypt), et de lui une EMPREINTE à sens unique (``publique`` : la
# moitié publique d'une clé X25519, seul usage de ``_x25519``), déposée dans Dropbox. L'accueil refuse un mot de passe qui
# ne redonne pas l'empreinte déposée ; une copie gardée par une empreinte n'est reprise que par elle (``garde_valable``).
# Il ne chiffre qu'une chose, le bilan de l'élève (``cle_bilan``, tirée de l'empreinte) ; ses copies, elles, le sont par
# la clé du sujet. La preuve des copies et la liste scellée du professeur ont été retirées le 05/11/2026 : un élève qui
# ouvre F12 lit déjà les réponses et les copies, elles ne protégeaient qu'un cas marginal.

def mot_de_passe_refuse(mot_de_passe: str) -> str | None:
    """Pourquoi un mot de passe choisi est refusé, ou ``None``. Sa publique est lisible dans Dropbox, donc attaquable hors
    ligne : un mot court tombe en quelques minutes, même au coût de ``secret_eleve``."""
    return f"au moins {MOT_DE_PASSE} caractères" if len(mot_de_passe) < MOT_DE_PASSE else None


def nom_identite(nom: str, prenom: str) -> str:
    """L'élève tel que la liste d'empreintes le range : nom et prénom normalisés, mots triés (inversés, ils sont le même)."""
    return " ".join(sorted(normaliser(f"{nom} {prenom}").split()))


def secret_eleve(nom: str, prenom: str, mot_de_passe: str) -> bytes:
    """La clé X25519 secrète d'un élève : scrypt 2¹⁷ (~0,3 s natif) de son nom et de son mot de passe. Le sel ne dépend que
    du nom : le même secret sur tout poste sans rien lire avant, natif hors ligne compris."""
    cle = nom_identite(nom, prenom)
    return rapidjson._scrypt(f"{cle}\n{mot_de_passe}".encode(), f"SmartTeacher identite v1|{cle}".encode(), 1 << 17, 8, 1, 32)


def publique(secret: bytes) -> str:
    """L'empreinte d'un secret d'élève, en base64 : la moitié publique de sa clé X25519, celle qu'il dépose."""
    return base64.b64encode(_x25519(secret)).decode()


def deposer(nom: str, prenom: str, secret: bytes) -> dict[str, str]:
    """L'entrée qu'un élève dépose, à la clé ``nom_identite`` du fichier d'empreintes."""
    return {"nom": nom, "prenom": prenom, "publique": publique(secret),
            "depose": datetime.now(timezone.utc).isoformat(timespec="minutes")}


def cle_bilan(publique_eleve: str) -> str:
    """La clé du bilan d'un élève (``bilans_widget``), tirée de son empreinte : l'élève la calcule de son mot de passe
    (``publique(secret)``), le professeur de l'entrée déposée dans ``identites.json``, sans son mot de passe. Qui lit le
    fichier d'empreintes la calcule aussi : risque accepté, comme les réponses lisibles par F12."""
    return hmac.new(b"SmartTeacher bilan v2", publique_eleve.encode(), "sha256").hexdigest()


def garde_valable(identites: dict[str, Any], nom: str, prenom: str, garde: str, empreinte: str) -> bool:
    """La copie déposée de garde ``garde`` (``Paquet.empreinte``) peut-elle être reprise par l'élève d'empreinte ``empreinte``
    (sa publique) ? Oui si c'est la sienne, une publique que le professeur a réinitialisée, ou une garde d'avant les mots de
    passe (vide, ou contrôle hexadécimal du code personnel retiré le 03/11/2026, jamais de la longueur d'une publique) :
    c'est l'accueil qui a vérifié le mot de passe. Toute autre publique : non, c'est quelqu'un d'autre."""
    if hmac.compare_digest(garde.encode(), empreinte.encode()) or len(garde) != LONGUEUR_PUBLIQUE:
        return True
    return garde in identites.get(REVOQUEES, {}).get(nom_identite(nom, prenom), [])


def reinitialiser(identites: dict[str, Any], nom: str, prenom: str) -> bool:
    """Le mot de passe de ``nom prenom`` oublié (``identites`` modifié sur place) : plus d'empreinte, il en choisit un autre à
    sa prochaine visite. Sa publique va dans ``REVOQUEES`` : un poste qui a gardé son identité ne redépose pas l'ancienne
    (``garde_revoquee``), et ses copies déjà gardées par elle restent les siennes (``garde_valable``). Faux s'il n'avait
    rien de déposé."""
    cle = nom_identite(nom, prenom)
    deposee = identites.get("eleves", {}).pop(cle, None)
    if not deposee:
        return False
    publiques = identites.setdefault(REVOQUEES, {}).setdefault(cle, [])
    if deposee["publique"] not in publiques:
        publiques.append(deposee["publique"])
    return True


def garde_revoquee(identites: dict[str, Any], nom: str, prenom: str, secret: bytes) -> bool:
    """L'identité gardée sur un poste date d'avant la réinitialisation de ce mot de passe, et rien n'a été redéposé depuis."""
    return entree_deposee(identites, nom, prenom) is None and \
        publique(secret) in identites.get(REVOQUEES, {}).get(nom_identite(nom, prenom), [])


REVOQUEES = "revoquees"  # dans le fichier d'empreintes : les publiques réinitialisées de chaque élève (``reinitialiser``)
LONGUEUR_PUBLIQUE = 44  # caractères d'une publique X25519 en base64 (``publique``) : ce qui la distingue d'une ancienne garde


def nettoyer_identites(identites: dict[str, Any]) -> bool:
    """Retire du fichier d'empreintes ``identites`` (modifié sur place) ce que les versions d'avant y écrivaient : les codes
    personnels (avant le 03/11/2026 ; il est lisible de tout élève) et la publique du professeur (avant le 05/11/2026, retrait
    des preuves et des sceaux). Rend ``True`` s'il a changé."""
    change = identites.pop("professeur", None) is not None
    for entree in identites.get("eleves", {}).values():
        change = entree.pop("code", None) is not None or change
    return change


PREMIERE_VISITE = (f"Première visite : choisissez un mot de passe, le même que pour Teams (au moins {MOT_DE_PASSE} caractères). "
                   "Il est affiché pour le relire ; tout autre poste vous le demandera.")
GARDE_PERIMEE = "Tapez votre mot de passe."  # l'identité gardée sur ce poste date d'avant une réinscription : à oublier


class Reconnu(NamedTuple):
    """L'élève reconnu par ``reconnaitre_mot_de_passe`` : son ``secret`` (dont l'empreinte garde ses copies et ouvre son
    bilan, ``cle_bilan``) et l'empreinte à déposer à sa première visite (``depot``, sinon None)."""
    secret: bytes
    depot: dict[str, str] | None


def premiere_visite(identites: dict[str, Any], inscrits: list[list[str]], nom: str, prenom: str,
                    garde: tuple[str, str, bytes] | None = None) -> bool:
    """``nom prenom`` est un inscrit qui n'a pas encore déposé d'empreinte ni d'identité gardée sur ce poste : il choisit son
    mot de passe, affiché en clair puisqu'il ne le tape qu'une fois (l'utilisateur, 03/11/2026)."""
    inscrit = nom and prenom and reconnaitre(nom, prenom, inscrits)
    if not inscrit:
        return False
    if garde and nom_identite(*garde[:2]) == nom_identite(inscrit[0], inscrit[1]) \
            and not garde_revoquee(identites, inscrit[0], inscrit[1], garde[2]):
        return False
    return entree_deposee(identites, inscrit[0], inscrit[1]) is None


def reconnaitre_mot_de_passe(identites: dict[str, Any], nom: str, prenom: str, tape: str,
                             garde: bytes | None = None) -> Reconnu | str:
    """L'entrée par mot de passe, la même à l'accueil d'un sujet et au tableau de bord, en natif comme sur le web : la
    publique tirée de ``tape`` (ou, sans lui, du secret ``garde`` sur ce poste) doit être celle déposée dans ``identites``.
    Sans dépôt, c'est la première visite : un mot de passe assez long. Rend le ``Reconnu``, ou ce qu'il faut dire à l'élève (``GARDE_PERIMEE`` : oublier la garde).
    Le natif hors ligne, sur un autre poste, n'a pas encore le fichier : il redépose (``ajouter_depot`` ne réécrit jamais une
    autre publique)."""
    if not tape and garde is None:
        return (f"Tapez votre mot de passe. À votre première visite, choisissez-en un, le même que pour Teams (au moins "
                f"{MOT_DE_PASSE} caractères) : tout autre poste vous le demandera.")
    if not tape and garde_revoquee(identites, nom, prenom, garde):
        return GARDE_PERIMEE
    secret = secret_eleve(nom, prenom, tape) if tape else garde
    deposee = entree_deposee(identites, nom, prenom)
    if deposee and deposee["publique"] != publique(secret):
        return f"Ce mot de passe n'est pas celui de {nom} {prenom}." if tape else GARDE_PERIMEE
    if deposee is None and tape and (refus := mot_de_passe_refuse(tape)):
        return f"Première visite : choisissez un mot de passe d'{refus}."
    return Reconnu(secret, None if deposee else deposer(nom, prenom, secret))


def identites_lire(texte: str | None) -> dict[str, Any]:
    """Le fichier d'empreintes (``IDENTITES``) lu : vide s'il est absent ou illisible (l'élève y est alors à sa première visite)."""
    try:
        identites = json.loads(texte) if texte else {}
    except ValueError:
        return {}
    return identites if isinstance(identites, dict) and isinstance(identites.get("eleves", {}), dict) else {}


def entree_deposee(identites: dict[str, Any], nom: str, prenom: str) -> dict[str, Any] | None:
    """L'empreinte que ``nom prenom`` a déposée, ou ``None`` : sa première visite (ou un fichier pas encore synchronisé)."""
    return identites.get("eleves", {}).get(nom_identite(nom, prenom))


def ajouter_depot(identites: dict[str, Any], entree: dict[str, str]) -> bool:
    """Ajoute à ``identites`` (modifié sur place) l'empreinte ``entree`` (``deposer``), si l'élève n'y est pas encore. Faux si
    une AUTRE publique y est déjà : l'élève ne réécrit jamais celle d'un autre, l'accueil l'a refusé avant."""
    eleves = identites.setdefault("eleves", {})
    deja = eleves.setdefault(nom_identite(entree["nom"], entree["prenom"]), entree)
    identites.setdefault("version", 1)
    return deja["publique"] == entree["publique"]


def _x25519(k: bytes, u: bytes = (9).to_bytes(32, "little")) -> bytes:
    """X25519 (RFC 7748, échelle de Montgomery) en Python pur, quelques millisecondes : ni libsodium à étendre, ni roue
    web à reconstruire. Pas en temps constant, sans gravité ici : rien n'est mesuré du dehors pendant le calcul."""
    p = 2**255 - 19
    n = int.from_bytes(k, "little") & ~7 & ((1 << 255) - 1) | (1 << 254)
    x1 = int.from_bytes(u, "little") & ((1 << 255) - 1)
    x2, z2, x3, z3, echange = 1, 0, x1, 1, 0
    for t in range(254, -1, -1):
        bit = n >> t & 1
        if echange ^ bit:
            x2, x3, z2, z3 = x3, x2, z3, z2
        echange = bit
        a, b, c, d = x2 + z2, x2 - z2, x3 + z3, x3 - z3
        aa, bb, da, cb = a * a % p, b * b % p, d * a % p, c * b % p
        e = aa - bb
        x3, z3 = (da + cb) ** 2 % p, x1 * (da - cb) ** 2 % p
        x2, z2 = aa * bb % p, e * (aa + 121665 * e) % p
    if echange:
        x2, z2 = x3, z3
    return (x2 * pow(z2, p - 2, p) % p).to_bytes(32, "little")


def lire_liste(chemin):
    """Les élèves d'une classe, ``[[nom, prénom], …]``, depuis un CSV à en-tête ``nom,prenom`` (celui d'``identifier.py``),
    ``[nom, prénom, code]`` quand sa colonne ``code`` le donne (``listes_classes.py`` : l'identifiant du papier)."""
    with open(chemin, newline="", encoding="utf-8-sig") as f:
        return [[l["nom"].strip(), l["prenom"].strip(), *filter(None, [(l.get("code") or "").strip()])] for l in csv.DictReader(f)]


def codes_distribues(chemin):
    """Les identifiants papier qu'une liste (``lire_liste``) a distribués, ``{(nom, prénom): code}`` ; vide sans liste."""
    return {(l[0], l[1]): l[2] for l in lire_liste(chemin) if len(l) > 2} if Path(chemin).exists() else {}


def reconnaitre(nom, prenom, inscrits):
    """L'élève de ``inscrits`` que « ``nom`` ``prenom`` » désigne, avec une tolérance aux fautes (accents, casse, lettre
    oubliée, nom et prénom inversés) : son entrée, ``[nom, prénom, …]`` ; ou ``None`` : personne d'assez proche, ou deux élèves presque aussi proches."""
    tapes = normaliser(f"{nom} {prenom}"), normaliser(f"{prenom} {nom}")
    scores = sorted(((max(difflib.SequenceMatcher(None, t, normaliser(f"{i[0]} {i[1]}")).ratio() for t in tapes), i)
                     for i in inscrits), key=lambda s: -s[0])
    if not scores or scores[0][0] < SEUIL:
        return None
    if scores[0][0] < 1 and len(scores) > 1 and scores[1][0] > scores[0][0] - 0.05:
        return None
    return scores[0][1]


def _h(etiquette, n, bits):
    return int.from_bytes(hashlib.sha256(etiquette + n.to_bytes(10, "big")).digest(), "big") >> 256 - bits


def _feistel(n, inverse=False):
    """Mêle les 58 bits d'un code (4 tours de Feistel sur deux moitiés de 29 bits, sans clé) : changer un mot pour déplacer
    une date change aussi la clé, et le fichier ne s'ouvre plus."""
    gauche, droite = n >> 29, n & 0x1FFFFFFF
    for tour in reversed(range(4)) if inverse else range(4):
        if inverse:
            gauche, droite = droite ^ _h(b"tour%d" % tour, gauche, 29), gauche
        else:
            gauche, droite = droite, gauche ^ _h(b"tour%d" % tour, droite, 29)
    return gauche << 29 | droite


_DETERMINANTS = set(DETERMINANTS.values())


@cache
def _listes():
    """``{"n": [(nom, genre), …], "a": [(masculin, féminin), …], "v": [(verbe,), …], "d": [(adverbe,), …]}``, dans
    l'ordre du fichier."""
    listes = {"n": [], "a": [], "v": [], "d": []}
    for ligne in PHRASES.read_text(encoding="utf-8").splitlines():
        if ligne and not ligne.startswith("#"):
            case, *mots = ligne.split()
            listes[case].append(tuple(mots))
    return listes


@cache
def _index():
    """Pour chaque case, forme tapée (sans accents) -> rang ; les deux genres d'un adjectif mènent au même rang, le genre
    d'un nom n'est pas une forme."""
    return {case: {_tapes(f)[0]: i for i, formes in enumerate(liste) for f in (formes[:1] if case == "n" else formes)}
            for case, liste in _listes().items()}


def _phrase(rangs):
    """La phrase écrite juste d'une suite de rangs dans ``CASES`` (6 pour un code de classe, 2 pour un identifiant papier) :
    « un » ou « une » devant chaque nom, l'adjectif accordé."""
    listes, mots, genre = _listes(), [], "m"
    for case, rang in zip(CASES, rangs):
        formes = listes[case][rang]
        if case == "n":
            genre = formes[1]
            mots += [DETERMINANTS[genre], formes[0]]
        else:
            mots.append(formes[genre == "f"] if case == "a" else formes[0])
    return " ".join(mots)


def _mots_du_code(texte):
    """Les six mots porteurs d'un code de classe tapé, ou ``None`` : sans les déterminants ; si l'un d'eux est mal tapé
    (huit mots en tout), par leur place."""
    tapes = _tapes(texte)
    mots = [m for m in tapes if m not in _DETERMINANTS]
    if len(mots) == len(CASES):
        return mots
    return tapes[1:5] + tapes[6:] if len(tapes) == len(CASES) + 2 else None


def _tapes(texte):
    """Les mots d'une saisie, sans casse ni accents : tout ce qui n'est pas une lettre sépare."""
    return re.findall(r"[a-z]+", normaliser(texte).replace("œ", "oe").replace("æ", "ae"))


def _proches(case, tape):
    """Les rangs des mots de la ``case`` à ``FAUTES`` lettres au plus de ``tape`` : ``{rang: fautes}`` (la forme la plus
    proche d'un adjectif, masculin ou féminin)."""
    proches = {}
    for m, i in _index()[case].items():
        if abs(len(m) - len(tape)) <= FAUTES and (d := _distance(tape, m)) <= min(FAUTES, proches.get(i, FAUTES)):
            proches[i] = d
    return proches


def _combinaisons(proches, fautes):
    """Les suites de rangs dont la somme des fautes vaut ``fautes``, un rang choisi dans chaque ``proches``."""
    for choix in itertools.product(*(p.items() for p in proches)):
        if sum(d for _, d in choix) == fautes:
            yield [i for i, _ in choix]


def _distance(a, b):
    """Distance d'édition (Levenshtein) : lettres ajoutées, ôtées ou changées."""
    ligne = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        precedente, ligne[0] = ligne[0], i
        for j, cb in enumerate(b, 1):
            precedente, ligne[j] = ligne[j], min(ligne[j] + 1, ligne[j - 1] + 1, precedente + (ca != cb))
    return ligne[-1]


def nom_de_fichier(texte):
    """Un nom sûr pour Dropbox comme pour tout système de fichiers : sans / \\ : * ? " < > |, ni retour à la ligne (titre sur
    deux lignes), ni espace ou point en bord."""
    return re.sub(r"\s+", " ", re.sub(r'[\\/:*?"<>|]+', "-", texte)).strip(" .") or "sans nom"


def _en_base32(n, chiffres):
    return "".join(ALPHABET[n >> 5 * i & 31] for i in reversed(range(chiffres)))


def _en_entier(texte):
    n = 0
    for c in texte:
        n = n << 5 | ALPHABET.index(c)
    return n
