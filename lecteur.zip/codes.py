"""Les deux mots de passe d'un sujet chiffré (.qcm) : celui du professeur, fixe, qui ouvre tous ses sujets et toutes leurs
copies, et le code donné à une classe, qui change avec chaque export.

Le fichier est le même pour toutes les classes ; sa clé (``cle_sujet``) se dérive du mot de passe professeur et du sel scrypt de
l'en-tête age, lisible en clair (``serializejson._encryption.salt``) : les outils du professeur la recalculent seuls, quel
que soit le nom du fichier. Le code d'une classe (``code_classe``) porte cette clé, le rang de la classe dans ``inscrits``
et, s'il y en a une, une date limite ou d'ouverture, le tout mêlé par une règle que seul le lecteur connaît ; le lecteur
refuse un code hors de ses dates, puis ne laisse entrer qu'un élève inscrit dans la classe du code (``reconnaitre``).

Chaque élève a aussi, s'il le veut, son code PERSONNEL (``code_personnel``) : le même pour tous les sujets de l'année, tiré du
mot de passe professeur et de son nom. Le sujet n'en porte qu'un contrôle par inscrit (``inscrire``), qui dépend de sa clé ; le
lecteur refuse un code personnel faux, et le lecteur web envoie son ``empreinte`` avec la copie : dès qu'une copie est
déposée avec elle, le professeur (``web/pyqt6/dropbox.js``) n'en accepte plus d'autre sous ce nom — personne ne répond à sa place.

C'est une protection d'obscurité, pas de cryptographie : la règle est dans le code source du lecteur, l'horloge est celle
de l'élève, et qui a lu un code peut en tirer la clé et déchiffrer le fichier sans le lecteur. Elle suffit à ce qu'elle
vise : qu'un sujet ne s'ouvre ni avant l'heure, ni dans une autre classe, ni après la fin du cours.

Module pur Python : il tourne aussi dans le navigateur (Pyodide).
"""

import csv
import difflib
import hashlib
import hmac
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import NamedTuple

from serializejson import rapidjson

from noyau import normaliser

PORTEFEUILLE = ["service", "SmartTeacher", "cle", "professeur"]  # attributs du secret dans le portefeuille KDE (secret-tool)
MOTS = Path(__file__).with_name("mots_codes.txt")  # 2 048 noms communs simples, un par ligne
RANGER = f"secret-tool store --label=SmartTeacher {' '.join(PORTEFEUILLE)}"  # le professeur y range son mot de passe, une fois
ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"  # base 32 de Crockford : ni I, L, O ni U, qui se lisent mal ; un code
# donné aux élèves s'écrit en minuscules, et la saisie lit o comme 0, i et l comme 1 (``_propre``)
AUCUNE, LIMITE, OUVERTURE = range(3)  # la sorte de date d'un code
ORIGINE, QUART = datetime(2026, 1, 1), timedelta(minutes=15)  # dates à la minute près : un quart d'heure, heure locale
SEUIL = 0.8  # ressemblance minimale d'un nom tapé à celui de la liste (difflib)


class Code(NamedTuple):
    cle: str
    classe: int
    sorte: int
    date: datetime | None


def professeur():
    """Le mot de passe du professeur, lu dans son portefeuille KDE (jamais en clair sur le disque), ou ``None`` sur une
    machine qui n'en a pas (celle d'un élève, le navigateur)."""
    if sys.platform == "emscripten":
        return None
    try:
        lu = subprocess.run(["secret-tool", "lookup", *PORTEFEUILLE], capture_output=True, text=True, check=False)
    except OSError:  # pas de secret-tool
        return None
    return lu.stdout.strip() or None


def cle_sujet(professeur, sel):
    """La clé age d'un sujet : 8 caractères (40 bits) tirés du mot de passe professeur et du sel de son en-tête."""
    return _en_base32(int.from_bytes(hmac.digest(professeur.encode(), sel, "sha256")[:5], "big"), 8)


def cle_du_fichier(chemin):
    """La clé d'un sujet exporté avec des listes de classes (ou de la copie d'un élève), recalculée depuis le mot de passe
    professeur ; ``None`` sans mot de passe professeur, ou pour un fichier qui n'est pas chiffré."""
    secret = professeur()
    if not secret:
        return None
    # pas au chargement : la roue serializejson du navigateur, compilée à part, peut précéder ``salt``, dont seul le
    # professeur se sert
    from serializejson._encryption import DecryptionError, salt  # noqa: PLC0415
    try:
        return cle_sujet(secret, salt(Path(chemin).read_bytes()))
    except DecryptionError:
        return None


def code_classe(cle, classe, sorte=AUCUNE, date=None):
    """Le code à donner à la classe de rang ``classe`` (dans ``sorted(paquet.inscrits)``) : 15 caractères, « xxxxx-xxxxx-xxxxx »."""
    quarts = 0 if sorte == AUCUNE else round((date - ORIGINE) / QUART)
    if not (0 <= classe < 32 and 0 <= quarts < 1 << 20):
        raise ValueError("classe (32 au plus) ou date (2026 à 2055) hors de portée")
    k = _en_entier(cle)
    info = classe << 22 | sorte << 20 | quarts
    droite = (info << 8 | _h(b"controle", k << 27 | info, 8)) ^ _h(b"droite", k, 35)
    texte = _en_base32((k ^ _h(b"gauche", droite, 40)) << 35 | droite, 15)
    return "-".join(texte[i:i + 5] for i in range(0, 15, 5)).lower()


def lire_code(texte):
    """Le ``Code`` que ``texte`` porte, ou ``None`` si ce n'est pas un code de classe (un autre mot de passe, une faute de
    frappe : la somme de contrôle en attrape 255 sur 256). Tirets, espaces et casse ignorés, O lu 0, I et L lus 1."""
    texte = _propre(texte)
    if len(texte) != 15 or not all(c in ALPHABET for c in texte):
        return None
    n = _en_entier(texte)
    droite = n & (1 << 35) - 1
    k = n >> 35 ^ _h(b"gauche", droite, 40)
    ouvert = droite ^ _h(b"droite", k, 35)
    info = ouvert >> 8
    sorte = info >> 20 & 3
    if ouvert & 255 != _h(b"controle", k << 27 | info, 8) or sorte > OUVERTURE:
        return None
    return Code(_en_base32(k, 8), info >> 22, sorte, None if sorte == AUCUNE else ORIGINE + (info & (1 << 20) - 1) * QUART)


def refus(code, maintenant=None):
    """Pourquoi ``code`` n'ouvre pas le sujet maintenant (sa date), ou ``""``."""
    maintenant = maintenant or datetime.now()
    if code.sorte == LIMITE and maintenant > code.date:
        return f"Ce code n'est plus valable depuis le {code.date:%d/%m/%Y à %H:%M}."
    if code.sorte == OUVERTURE and maintenant < code.date:
        return f"Ce sujet ne s'ouvre qu'à partir du {code.date:%d/%m/%Y à %H:%M}."
    return ""


def code_personnel(professeur, nom, prenom):
    """Le code personnel d'un élève, deux mots de ``MOTS`` (« tigre-lampe », 22 bits pour 2 048 mots), les mêmes pour tous
    les sujets. Seul le professeur le calcule : le lecteur n'a pas besoin de la liste."""
    mots = MOTS.read_text(encoding="utf-8").split()
    n = int.from_bytes(hmac.digest(professeur.encode(), f"eleve|{normaliser(f'{nom} {prenom}')}".encode(), "sha256")[:8], "big")
    return f"{mots[n % len(mots)]}-{mots[n // len(mots) % len(mots)]}"


def inscrire(professeur, cle, liste):
    """Les élèves d'une classe tels que le sujet les porte : ``[nom, prénom, contrôle de son code personnel]``."""
    return [[nom, prenom, _controle(cle, [nom, prenom], code_personnel(professeur, nom, prenom))] for nom, prenom in liste]


def verifier_personnel(cle, inscrit, texte):
    """Le code personnel ``texte`` est-il celui de ``inscrit`` (une entrée d'``inscrire``) ?"""
    return len(inscrit) > 2 and hmac.compare_digest(_controle(cle, inscrit, texte), inscrit[2])


def empreinte(texte):
    """Ce que le professeur garde d'un code personnel pour reconnaître son élève (``dropbox.js``) : un simple haché. La fiche
    qui le porte est lisible avec la clé de la page, mais le code n'a que 22 bits et se vérifie déjà sur le sujet : le haché
    n'y ajoute pas de faiblesse."""
    return hashlib.sha256(f"smartteacher|{_propre(texte)}".encode()).hexdigest()[:16]


def lire_liste(chemin):
    """Les élèves d'une classe, ``[[nom, prénom], …]``, depuis un CSV à en-tête ``nom,prenom`` (celui d'``identifier.py``)."""
    with open(chemin, newline="", encoding="utf-8-sig") as f:
        return [[l["nom"].strip(), l["prenom"].strip()] for l in csv.DictReader(f)]


def reconnaitre(nom, prenom, inscrits):
    """L'élève de ``inscrits`` que « ``nom`` ``prenom`` » désigne, avec une tolérance aux fautes (accents, casse, lettre
    oubliée, nom et prénom inversés) : son entrée, ``[nom, prénom, …]`` ; ou ``None`` : personne d'assez proche, ou deux élèves presque aussi proches."""
    tapes = normaliser(f"{nom} {prenom}"), normaliser(f"{prenom} {nom}")
    scores = sorted(((max(difflib.SequenceMatcher(None, t, normaliser(f"{i[0]} {i[1]}")).ratio() for t in tapes), i)
                     for i in inscrits), key=lambda s: -s[0])
    if not scores or scores[0][0] < SEUIL:
        return None
    if scores[0][0] < 1 and len(scores) > 1 and scores[1][0] > scores[0][0] - 0.05:
        return None
    return scores[0][1]


def _propre(texte):
    return normaliser(texte).upper().replace("-", "").replace(" ", "").translate(str.maketrans("OIL", "011"))


def _controle(cle, inscrit, code):
    """Ce que le sujet garde du code personnel d'un inscrit : 32 bits d'un scrypt (2¹⁵, ~45 ms) salé par la clé du sujet et
    le nom. Le code n'a que 22 bits : un contrôle rapide le rendrait à qui a le sujet et sa clé (celle-ci se tire d'un code
    de classe) en quelques secondes de force brute ; ainsi, c'est de l'ordre de deux jours de calcul par élève et par sujet
    (2²² essais de 45 ms), bien au-delà de ce qu'un élève tente pour répondre à la place d'un autre."""
    sel = f"smartteacher|{cle}|{normaliser(' '.join(inscrit[:2]))}".encode()
    return rapidjson._scrypt(_propre(code).encode(), sel, 1 << 15, 8, 1, 4).hex()


def _h(etiquette, n, bits):
    return int.from_bytes(hashlib.sha256(etiquette + n.to_bytes(10, "big")).digest(), "big") >> 256 - bits


def _en_base32(n, chiffres):
    return "".join(ALPHABET[n >> 5 * i & 31] for i in reversed(range(chiffres)))


def _en_entier(texte):
    n = 0
    for c in texte:
        n = n << 5 | ALPHABET.index(c)
    return n
