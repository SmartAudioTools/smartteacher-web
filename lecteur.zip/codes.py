"""Les deux mots de passe d'un sujet chiffré (.qcm) : celui du professeur, fixe, qui ouvre tous ses sujets et toutes leurs
copies, et le code donné à une classe, qui change avec chaque export.

Le fichier est le même pour toutes les classes ; sa clé (``cle_sujet``) se dérive du mot de passe professeur et du sel scrypt de
l'en-tête age, lisible en clair (``serializejson._encryption.salt``) : les outils du professeur la recalculent seuls, quel
que soit le nom du fichier. Le code d'une classe (``code_classe``) porte cette clé, le rang de la classe dans ``inscrits``
(ou ``SANS_CLASSE`` : n'importe qui entre, ses copies sont rangées à part), et s'il y a lieu l'heure de DÉPART (le sujet ne
s'ouvre pas avant), la DURÉE de l'épreuve (elle remplace celle du sujet), l'ÉCHÉANCE (le code ne sert plus après, et le
lecteur rend la copie à cette heure) et le mode de SOUMISSION (``SOUMISSIONS``, ``variantes``), le tout mêlé
par une règle que seul le lecteur connaît ; le lecteur refuse un code hors de ses dates, à l'heure en ligne (``horloge``)
ou, sans réseau, à celle de l'ordinateur, puis ne laisse entrer qu'un élève inscrit dans la classe du code (``reconnaitre``).
Le même fichier, déposé d'avance sur les ordinateurs des élèves, s'ouvre ainsi par autant de codes qu'il y a de classes
et de créneaux.

Un code de classe est une PHRASE française faite des mots de ``PHRASES`` (« une tomate timide dessine souvent un château
rouge ») : nom 11 bits, adjectif 9, verbe 9, adverbe 9, nom 11, adjectif 9, soit 58 bits, tous porteurs (``code_classe`` :
clé 27, classe 3, départ 15, durée 6, échéance 7). Des mots, parce que des élèves se trompent en recopiant des lettres et des
chiffres, et qu'un mot mal orthographié se CORRIGE (``corrections`` : le mot le plus proche de chaque liste, dont deux mots
sont toujours à plus d'une faute) là où une suite de caractères ne se corrige pas ; une phrase, parce qu'elle se retient et
se recopie mieux qu'une suite de mots sans lien. Les déterminants (« un », « une ») et l'accord de l'adjectif ne portent
rien : une faute sur eux n'en est pas une. Aucun bit de contrôle : toute phrase de six mots des listes se lit comme un code,
et c'est le déchiffrement du fichier qui juge (une phrase quelconque l'ouvre 6 fois sur 2²⁷, une par mode de soumission).
La clé a 27 bits, que age dérive par scrypt (0,32 s par essai, mesuré) : environ un an et demi de calcul sur un cœur pour un
seul sujet que la classe connaît déjà — les modes n'y changent rien, c'est la clé du fichier qu'on essaierait, pas des phrases.
Le départ se compte par pas de 5 minutes, modulo 2¹⁵ (114 jours) : il se lit comme la date la plus proche de l'heure, au
plus 14 jours plus tard ou 100 jours plus tôt.

Chaque élève a aussi, s'il le veut, son code PERSONNEL (``code_personnel``) : le même pour tous les sujets de l'année, tiré du
mot de passe professeur et de son nom. Le sujet n'en porte qu'un contrôle par inscrit (``inscrire``), qui dépend de sa clé ; le
lecteur refuse un code personnel faux, et la copie garde son ``empreinte`` : dès qu'une copie est déposée avec elle, la
page web (``web/pyqt6/pont_qt.py``) n'en accepte plus d'autre sous ce nom — personne ne répond à sa place.

C'est une protection d'obscurité, pas de cryptographie : la règle est dans le code source du lecteur, et qui a lu un code
peut en tirer la clé et déchiffrer le fichier sans le lecteur. Elle suffit à ce qu'elle vise : qu'un sujet ne s'ouvre ni
avant l'heure, ni dans une autre classe, ni après la fin du cours.

Module pur Python : il tourne aussi dans le navigateur (Pyodide).
"""

import base64
import csv
import difflib
import hashlib
import hmac
import itertools
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from functools import cache
from pathlib import Path
from typing import NamedTuple

from serializejson import rapidjson

import horloge
from noyau import SOUMISSIONS, normaliser

# 2 048 noms avec leur genre, 512 adjectifs avec leur féminin, 512 verbes, 512 adverbes (``outils/phrases_codes.py``)
PHRASES = Path(__file__).with_name("phrases_codes.txt")
CASES = "navdna"  # un code de classe : nom, adjectif, verbe, adverbe, nom, adjectif
DETERMINANTS = {"m": "un", "f": "une"}
# Le mot de passe professeur : un secret tiré au hasard (``secrets.token_urlsafe(32)``), sans lien avec aucun mot de passe du
# professeur, dans un fichier en clair hors du dépôt, lisible de son compte et de celui de Claude (groupe partagé de /DATA/Python) :
# les deux fabriquent et ouvrent les sujets et les copies. Choix de l'utilisateur, 27/09/2026, à la place du portefeuille KDE, que
# le compte de Claude ne peut pas interroger ; un secret aléatoire plutôt que son mot de passe, que la clé de 27 bits d'un fichier
# (HMAC sans étape lente) livrerait à un dictionnaire.
FICHIER = Path(__file__).resolve().parent.parent.parent / ".smartteacher_professeur"  # pas parents[2] : /lecteur/codes.py sur le web
VARIABLE = "SMARTTEACHER_PROFESSEUR"  # le remplace pour les tests
ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"  # base 32 de Crockford, pour écrire la clé age d'un sujet
PAS = 5  # minutes : le pas du départ, de la durée et des échéances courtes
AVANCE = 14 * 24 * 60 // PAS  # un départ se lit au plus 14 jours après l'heure, sinon avant (``_decoder``)
SANS_CLASSE = 7  # le rang d'un code qui ne vérifie aucune liste : entraînement, ou élève absent des listes
CLASSES = 7  # classes par sujet au plus (rangs 0 à 6)
NIVEAUX = "Seconde", "Première", "Terminale"
HORS_LISTE = "Hors liste"  # le dossier des copies rendues avec le code sans classe
PROFESSEUR = "de La Gorce", "Baptiste"  # hors des listes : ce nom n'entre que par le mot de passe professeur (``cle_du_mot``)
SEUIL = 0.8  # ressemblance minimale d'un nom tapé à celui de la liste (difflib)
FAUTES = 2  # lettres fausses corrigées au plus dans l'ensemble d'un code (``corrections``)
ESSAIS = 8  # lectures corrigées essayées au plus sur le fichier (0,32 s par mode de soumission chacune, ``variantes``)


class Code(NamedTuple):
    cle: str
    classe: int
    depart: datetime | None = None  # en UTC : le sujet ne s'ouvre pas avant
    duree: int | None = None  # minutes : remplace ``duree_minutes`` du sujet
    echeance: datetime | None = None  # en UTC : le code ne sert plus après, la copie est rendue à cette heure
    soumission: int = 0  # le mode de soumission, une clé de ``SOUMISSIONS``


def professeur():
    """Le mot de passe du professeur, lu dans ``FICHIER``, ou ``None`` sur une machine qui ne l'a pas (celle d'un élève, le
    navigateur)."""
    if sys.platform == "emscripten":
        return None
    if os.environ.get(VARIABLE):
        return os.environ[VARIABLE]
    return FICHIER.read_text().strip() if FICHIER.exists() else None


def cle_sujet(professeur, sel):
    """La clé age d'un sujet : 6 caractères (27 bits) tirés du mot de passe professeur et du sel de son en-tête."""
    return _en_base32(int.from_bytes(hmac.digest(professeur.encode(), sel, "sha256")[:4], "big") >> 5, 6)


def cle_du_fichier(chemin):
    """La clé d'un sujet (ou de la copie d'un élève), recalculée depuis le mot de passe professeur ; ``None`` sans mot de
    passe professeur, ou pour un fichier qui n'est pas chiffré."""
    secret = professeur()
    return secret and cle_du_mot(secret, Path(chemin).read_bytes())


def cle_du_mot(mot, octets):
    """La clé du fichier ``octets`` si ``mot`` est le mot de passe professeur (l'ouvrir le vérifie), tirée du sel écrit en
    clair dans son en-tête age ; ``None`` pour un fichier qui n'est pas chiffré. L'en-tête est lu ici plutôt que par
    ``serializejson._encryption.salt``, que la roue du navigateur n'a pas : c'est là que le professeur tape son mot de passe
    (``lecteur.Accueil.deverrouiller``)."""
    sel = re.search(rb"^-> scrypt ([A-Za-z0-9+/]+) \d+$", octets[:200], re.MULTILINE)
    return sel and cle_sujet(mot, base64.b64decode(sel[1] + b"=" * (-len(sel[1]) % 4)))


def code_classe(cle, classe, depart=None, duree=None, echeance=None, soumission=0):
    """Le code à donner à la classe de rang ``classe`` (dans ``sorted(paquet.inscrits)``, ou ``SANS_CLASSE``) : une phrase,
    « une tomate timide dessine souvent un château rouge ». Dates UTC, ou à l'heure de cette machine si elles n'ont pas de
    fuseau. ``depart`` se prend à 5 minutes près (arrondi en dessous) ; ``duree`` en minutes, multiple de 5, de 5 à 315 ;
    ``echeance`` demande un ``depart`` et doit tomber de 5 à 120 minutes après lui par pas de 5, ou de 3 à 24 heures après
    par heures pleines, ou à minuit (heure de Paris) de 1 à 80 jours après sa date : 1 jour, c'est le soir même.
    ``soumission`` (une clé de ``SOUMISSIONS``) retourne les bits de tête de la clé : le code n'ouvre le fichier que par
    sa variante (``variantes``), et le lecteur qui l'ouvre ainsi sait quel mode il porte ; la clé du fichier ne change pas."""
    if not 0 <= classe <= SANS_CLASSE:
        raise ValueError(f"{CLASSES} classes au plus par sujet")
    if duree is not None and not (duree % PAS == 0 and PAS <= duree <= 63 * PAS):
        raise ValueError(f"durée de {duree} min : un multiple de 5, de 5 à 315 minutes")
    if echeance is not None and depart is None:
        raise ValueError("une échéance se compte depuis un départ")
    if soumission not in SOUMISSIONS:
        raise ValueError(f"mode de soumission {soumission} : une clé de SOUMISSIONS")
    pas = depart and _minutes(depart) // PAS
    rang = 0 if depart is None else 1 if echeance is None else _rang_echeance(pas * PAS, _minutes(echeance))
    info = ((_en_entier(cle) ^ soumission << 24) << 31 | classe << 28 | (pas or 0) % (1 << 15) << 13 | (duree or 0) // PAS << 7 | rang)
    return _phrase(_rangs(_feistel(info)))


def lire_code(texte, maintenant=None):
    """Le ``Code`` que ``texte`` porte, écrit juste (casse, accents, séparateurs, déterminants et accords ignorés), ou ``None``
    si ce ne sont pas six mots des listes. Sans contrôle, toute phrase des listes se lit : seul le déchiffrement dit si c'est
    le bon code. Le départ se lit comme la date la plus proche de ``maintenant`` (l'heure en ligne par défaut)."""
    rangs = _rangs_du_texte(texte)
    return rangs and _decoder(rangs, maintenant)


def jeton(texte):
    """Le code de classe ``texte`` (écrit juste) en 12 caractères de base 32, pour un lien (``?code=``) : les mêmes 58 bits
    que la phrase, qu'une URL porterait en ~60 caractères accentués. ``None`` si ce ne sont pas six mots des listes."""
    rangs = _rangs_du_texte(texte)
    return rangs and _en_base32(_entier(rangs), 12)


def phrase_du_jeton(texte):
    """La phrase d'un ``jeton``, que l'accueil du lecteur lit comme si l'élève l'avait tapée ; ``None`` si ce n'en est pas un."""
    texte = texte.strip().upper()
    if len(texte) != 12 or set(texte) - set(ALPHABET) or _en_entier(texte) >> 58:
        return None
    return _phrase(_rangs(_en_entier(texte)))


def variantes(code):
    """Les lectures de ``code`` à essayer sur le fichier, une par mode de soumission (``code_classe``) dans l'ordre de
    ``SOUMISSIONS`` : les bits de tête de la clé retournés. Une phrase quelconque ouvre ainsi le fichier six fois sur 2²⁷."""
    return [code._replace(cle=_en_base32(_en_entier(code.cle) ^ v << 24, 6), soumission=v) for v in SOUMISSIONS]


def _rangs_du_texte(texte):
    """Les rangs des six mots d'un code de classe écrit juste, ou ``None``."""
    mots = _mots_du_code(texte)
    rangs = mots and [_index()[case].get(m) for case, m in zip(CASES, mots)]
    return None if not rangs or None in rangs else rangs


def _entier(rangs):
    """Les 58 bits d'un code de classe, depuis les rangs de ses six mots (base mixte des tailles des listes)."""
    n = 0
    for case, rang in zip(CASES, rangs):
        n = n * len(_listes()[case]) + rang
    return n


def _rangs(n):
    """L'inverse d'``_entier``."""
    rangs = []
    for case in reversed(CASES):
        n, r = divmod(n, len(_listes()[case]))
        rangs.insert(0, r)
    return rangs


def _decoder(rangs, maintenant):
    info = _feistel(_entier(rangs), inverse=True)
    cle, classe, duree, rang = _en_base32(info >> 31, 6), info >> 28 & 7, (info >> 7 & 63) * PAS or None, info & 127
    if not rang:
        return Code(cle, classe, None, duree, None)
    maintenant = int((maintenant.timestamp() if maintenant else horloge.secondes()) // 60) // PAS + AVANCE
    pas = maintenant - (maintenant - (info >> 13 & 0x7FFF)) % (1 << 15)  # le plus tard possible, au plus AVANCE après l'heure
    depart = pas * PAS
    return Code(cle, classe, _date(depart), duree, None if rang == 1 else _date(_echeance(depart, rang)))


def _minutes(date):
    return int(date.astimezone(timezone.utc).timestamp()) // 60


def _date(minutes):
    return datetime.fromtimestamp(minutes * 60, timezone.utc)


def _echeance(depart, rang):
    """L'échéance (minutes UTC) du ``rang`` 2 à 127 d'un code parti à ``depart`` : 5 à 120 minutes après par pas de 5 (2 à
    25), 3 à 24 heures après (26 à 47), puis minuit à Paris, 1 à 80 jours après la date du départ (48 à 127)."""
    if rang <= 25:
        return depart + (rang - 1) * PAS
    if rang <= 47:
        return depart + (rang - 23) * 60
    return _minutes(minuit(_date(depart), rang - 47))


def minuit(date, jours):
    """Minuit à Paris, ``jours`` après la date (à Paris) de ``date`` : 1, c'est la fin du jour même. En UTC."""
    jour = (date + timedelta(minutes=_decalage_paris(_minutes(date)))).date() + timedelta(days=jours)
    minutes = int(datetime(jour.year, jour.month, jour.day, tzinfo=timezone.utc).timestamp()) // 60
    return _date(minutes - _decalage_paris(minutes - 120))  # 22 h ou 23 h UTC la veille : jamais sur un changement d'heure


def _rang_echeance(depart, echeance):
    rang = next((r for r in range(2, 128) if _echeance(depart, r) == echeance), None)
    if rang is None:
        raise ValueError(f"échéance {_date(echeance):%d/%m/%Y %H:%M} UTC non codable : de 5 à 120 min après le départ par pas "
                         "de 5, de 3 à 24 h par heures pleines, ou à minuit (Paris) de 1 à 80 jours après")
    return rang


def _decalage_paris(minutes):
    """Le décalage de l'heure de Paris sur UTC (minutes) à l'instant ``minutes`` UTC : 120 du dernier dimanche de mars au
    dernier dimanche d'octobre (à 1 h UTC), 60 sinon. Calculé, pas lu dans ``zoneinfo`` : le navigateur (Pyodide) n'a pas
    forcément la base des fuseaux."""
    instant = _date(minutes)

    def changement(mois):
        dernier = datetime(instant.year, mois, 31, 1, tzinfo=timezone.utc)
        return dernier - timedelta(days=(dernier.weekday() + 1) % 7)

    return 120 if changement(3) <= instant < changement(10) else 60


def corrections(texte, maintenant=None):
    """Les codes que ``texte`` voulait sans doute dire, écrits juste : six mots des listes, chacun à ``FAUTES`` lettres près
    au plus, à la plus petite somme de fautes (déterminants et accords ne comptent pas), ``ESSAIS`` au plus. Le plus souvent
    un seul : deux mots d'une liste sont à plus d'une faute l'un de l'autre. Au lecteur de les essayer sur le fichier."""
    mots = _mots_du_code(texte)
    if not mots:
        return []
    proches = [_proches(case, m) for case, m in zip(CASES, mots)]
    for fautes in range(FAUTES + 1):
        trouves = [_phrase(r) for r in itertools.islice(_combinaisons(proches, fautes), ESSAIS)]
        if trouves:
            return trouves
    return []


def refus(code, maintenant=None):
    """Pourquoi ``code`` n'ouvre pas le sujet maintenant (ses dates, à l'heure en ligne par défaut), ou ``""``."""
    maintenant = maintenant or horloge.maintenant()
    if code.echeance and maintenant >= code.echeance:
        return f"Ce code n'est plus valable depuis le {horloge.locale(code.echeance):%d/%m/%Y à %H:%M}."
    if code.depart and maintenant < code.depart:
        return f"Ce sujet ne s'ouvre qu'à partir du {horloge.locale(code.depart):%d/%m/%Y à %H:%M}."
    return ""


def niveau(classe):
    """Seconde, Première ou Terminale, lu dans le nom d'une liste de classe : « SECONDE 3 », « B3_P_NSINF_GR1 »,
    « B1_T_NSI_GR1 ». Un nom qui ne se lit pas est une erreur : pas de dossier deviné."""
    if normaliser(classe).startswith("seconde"):
        return "Seconde"
    parties = set(re.split(r"[_\s-]+", classe.upper()))
    if len({"P", "T"} & parties) == 1:
        return "Première" if "P" in parties else "Terminale"
    raise ValueError(f"niveau illisible dans le nom de classe « {classe} » : SECONDE n, …_P_… ou …_T_… attendu")


def chemin_copie(inscrits, classe, titre, eleve):
    """Où ranger une copie dans le dossier Dropbox du professeur : ``Copies/<niveau>/<classe>/<sujet>/<sujet> [<élève>].qcm``,
    le dossier de la classe seulement si le sujet vise plusieurs classes de ce niveau ; le nom de la copie reprend celui du
    sujet, comme celle qu'un élève ouvre depuis un PDF (``lecteur.copie_du_pdf``), pour qu'elle se reconnaisse hors de son
    dossier (demande de l'utilisateur, 28/09/2026). ``classe`` ``None`` : le code sans classe, rangé à part (« Hors
    liste ») pour ne jamais se confondre avec la copie d'un inscrit."""
    if classe is None:
        niveaux = {niveau(c) for c in inscrits or ()}
        dossiers = [*niveaux, HORS_LISTE] if len(niveaux) == 1 else [HORS_LISTE]
    else:
        dossiers = [niveau(classe)]
        if sum(niveau(c) == dossiers[0] for c in inscrits) > 1:
            dossiers.append(classe)
    return "/".join(["Copies", *map(nom_de_fichier, [*dossiers, titre, f"{titre} [{eleve}]"])]) + ".qcm"


def code_personnel(professeur, nom, prenom):
    """Le code personnel d'un élève, un nom et son adjectif (« un tigre timide », 11 + 9 = 20 bits), le même pour tous les
    sujets de l'année. Seul le professeur le calcule."""
    n = int.from_bytes(hmac.digest(professeur.encode(), f"eleve|{normaliser(f'{nom} {prenom}')}".encode(), "sha256")[:8], "big")
    return _phrase([n % 2048, n // 2048 % 512])


def inscrire(professeur, cle, liste):
    """Les élèves d'une classe tels que le sujet les porte : ``[nom, prénom, contrôle de son code personnel]``."""
    return [[nom, prenom, _controle(cle, [nom, prenom], code_personnel(professeur, nom, prenom))] for nom, prenom in liste]


def verifier_personnel(cle, inscrit, texte):
    """Le code personnel ``texte`` est-il celui de ``inscrit`` (une entrée d'``inscrire``) ?"""
    return len(inscrit) > 2 and hmac.compare_digest(_controle(cle, inscrit, texte), inscrit[2])


def empreinte(texte):
    """Ce que la copie garde d'un code personnel pour reconnaître son élève (``Paquet.empreinte``) : un simple haché. La copie
    se lit avec la clé de la page, mais le code n'a que 20 bits et se vérifie déjà sur le sujet : le haché n'y ajoute pas
    de faiblesse."""
    return hashlib.sha256(f"smartteacher|{_propre(texte)}".encode()).hexdigest()[:16]


def lire_liste(chemin):
    """Les élèves d'une classe, ``[[nom, prénom], …]``, depuis un CSV à en-tête ``nom,prenom`` (celui d'``identifier.py``)."""
    with open(chemin, newline="", encoding="utf-8-sig") as f:
        return [[l["nom"].strip(), l["prenom"].strip()] for l in csv.DictReader(f)]


def reconnaitre(nom, prenom, inscrits):
    """L'élève de ``inscrits`` que « ``nom`` ``prenom`` » désigne, avec une tolérance aux fautes (accents, casse, lettre
    oubliée, nom et prénom inversés) : son entrée, ``[nom, prénom, …]`` ; ou ``None`` : personne d'assez proche, ou deux élèves presque aussi proches."""
    tapes = normaliser(f"{nom} {prenom}"), normaliser(f"{prenom} {nom}")
    scores = sorted(((max(difflib.SequenceMatcher(None, t, normaliser(f"{i[0]} {i[1]}")).ratio() for t in tapes), i)
                     for i in inscrits), key=lambda s: -s[0])
    if not scores or scores[0][0] < SEUIL:
        return None
    if scores[0][0] < 1 and len(scores) > 1 and scores[1][0] > scores[0][0] - 0.05:
        return None
    return scores[0][1]


def _propre(texte):
    """Un code personnel sous une seule forme, quels que soient son déterminant et l'accord de son adjectif : « tigre|timide »
    pour « une tigre timides ». Ce qui ne s'y lit pas reste tel quel, et ne vérifiera rien."""
    mots = [m for m in _tapes(texte) if m not in _DETERMINANTS]
    if len(mots) == 2 and (nom := _index()["n"].get(mots[0])) is not None and (adj := _index()["a"].get(mots[1])) is not None:
        return f"{_listes()['n'][nom][0]}|{_listes()['a'][adj][0]}"
    return "".join(_tapes(texte))


def _controle(cle, inscrit, code):
    """Ce que le sujet garde du code personnel d'un inscrit : 32 bits d'un scrypt (2¹⁵, ~45 ms) salé par la clé du sujet et
    le nom. Le code n'a que 20 bits : un contrôle rapide le rendrait à qui a le sujet et sa clé (celle-ci se tire d'un code
    de classe) en quelques secondes de force brute ; ainsi, c'est de l'ordre de treize heures de calcul par élève et par sujet
    (2²⁰ essais de 45 ms), bien au-delà de ce qu'un élève tente pour répondre à la place d'un autre."""
    sel = f"smartteacher|{cle}|{normaliser(' '.join(inscrit[:2]))}".encode()
    return rapidjson._scrypt(_propre(code).encode(), sel, 1 << 15, 8, 1, 4).hex()


def _h(etiquette, n, bits):
    return int.from_bytes(hashlib.sha256(etiquette + n.to_bytes(10, "big")).digest(), "big") >> 256 - bits


def _feistel(n, inverse=False):
    """Mêle les 58 bits d'un code (4 tours de Feistel sur deux moitiés de 29 bits, sans clé) : changer un mot pour déplacer
    une date change aussi la clé, et le fichier ne s'ouvre plus."""
    gauche, droite = n >> 29, n & 0x1FFFFFFF
    for tour in reversed(range(4)) if inverse else range(4):
        if inverse:
            gauche, droite = droite ^ _h(b"tour%d" % tour, gauche, 29), gauche
        else:
            gauche, droite = droite, gauche ^ _h(b"tour%d" % tour, droite, 29)
    return gauche << 29 | droite


_DETERMINANTS = set(DETERMINANTS.values())


@cache
def _listes():
    """``{"n": [(nom, genre), …], "a": [(masculin, féminin), …], "v": [(verbe,), …], "d": [(adverbe,), …]}``, dans
    l'ordre du fichier."""
    listes = {"n": [], "a": [], "v": [], "d": []}
    for ligne in PHRASES.read_text(encoding="utf-8").splitlines():
        if ligne and not ligne.startswith("#"):
            case, *mots = ligne.split()
            listes[case].append(tuple(mots))
    return listes


@cache
def _index():
    """Pour chaque case, forme tapée (sans accents) -> rang ; les deux genres d'un adjectif mènent au même rang, le genre
    d'un nom n'est pas une forme."""
    return {case: {_tapes(f)[0]: i for i, formes in enumerate(liste) for f in (formes[:1] if case == "n" else formes)}
            for case, liste in _listes().items()}


def _phrase(rangs):
    """La phrase écrite juste d'une suite de rangs dans ``CASES`` (6 pour un code de classe, 2 pour un code personnel) :
    « un » ou « une » devant chaque nom, l'adjectif accordé."""
    listes, mots, genre = _listes(), [], "m"
    for case, rang in zip(CASES, rangs):
        formes = listes[case][rang]
        if case == "n":
            genre = formes[1]
            mots += [DETERMINANTS[genre], formes[0]]
        else:
            mots.append(formes[genre == "f"] if case == "a" else formes[0])
    return " ".join(mots)


def _mots_du_code(texte):
    """Les six mots porteurs d'un code de classe tapé, ou ``None`` : sans les déterminants ; si l'un d'eux est mal tapé
    (huit mots en tout), par leur place."""
    tapes = _tapes(texte)
    mots = [m for m in tapes if m not in _DETERMINANTS]
    if len(mots) == len(CASES):
        return mots
    return tapes[1:5] + tapes[6:] if len(tapes) == len(CASES) + 2 else None


def _tapes(texte):
    """Les mots d'une saisie, sans casse ni accents : tout ce qui n'est pas une lettre sépare."""
    return re.findall(r"[a-z]+", normaliser(texte).replace("œ", "oe").replace("æ", "ae"))


def _proches(case, tape):
    """Les rangs des mots de la ``case`` à ``FAUTES`` lettres au plus de ``tape`` : ``{rang: fautes}`` (la forme la plus
    proche d'un adjectif, masculin ou féminin)."""
    proches = {}
    for m, i in _index()[case].items():
        if abs(len(m) - len(tape)) <= FAUTES and (d := _distance(tape, m)) <= min(FAUTES, proches.get(i, FAUTES)):
            proches[i] = d
    return proches


def _combinaisons(proches, fautes):
    """Les suites de rangs dont la somme des fautes vaut ``fautes``, un rang choisi dans chaque ``proches``."""
    for choix in itertools.product(*(p.items() for p in proches)):
        if sum(d for _, d in choix) == fautes:
            yield [i for i, _ in choix]


def _distance(a, b):
    """Distance d'édition (Levenshtein) : lettres ajoutées, ôtées ou changées."""
    ligne = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        precedente, ligne[0] = ligne[0], i
        for j, cb in enumerate(b, 1):
            precedente, ligne[j] = ligne[j], min(ligne[j] + 1, ligne[j - 1] + 1, precedente + (ca != cb))
    return ligne[-1]


def nom_de_fichier(texte):
    """Un nom sûr pour Dropbox comme pour tout système de fichiers : sans / \\ : * ? " < > |, ni retour à la ligne (titre sur
    deux lignes), ni espace ou point en bord."""
    return re.sub(r"\s+", " ", re.sub(r'[\\/:*?"<>|]+', "-", texte)).strip(" .") or "sans nom"


def _en_base32(n, chiffres):
    return "".join(ALPHABET[n >> 5 * i & 31] for i in reversed(range(chiffres)))


def _en_entier(texte):
    n = 0
    for c in texte:
        n = n << 5 | ALPHABET.index(c)
    return n
