"""Les bilans des élèves et de la classe : l'agrégat des bilans de copie (``Paquet.statistiques``, les six axes de
``noyau.AXES``), par épreuve ou par élève (« TODO - Bilans des élèves et de la classe », idées 2 et 3 du TODO
Divers). Outil du professeur, sans fenêtre :

    bilans.py epreuve <dossier des copies> [--propositions <campagne>.csv …] [--papier <notes.csv> <AAAA-MM-JJ> <épreuve> …]
    bilans.py eleves <dossier> [--eleve "Nom Prénom"] [--papier …]
    bilans.py fichiers <dossier> -o <dossier de sortie> [--listes liste.csv …] [--papier …]
    options communes : [--format md|csv] [-o fichier] [--banques dossier]

``fichiers`` écrit le bilan de chaque élève, « Bilan [Nom Prénom].report », chiffré pour lui et le professeur s'il a un mot
de passe, en clair sinon (``bilans_widget``), que le lecteur ouvre comme une copie ; écrit dans le dossier Dropbox de
l'application (à la racine ou sous un niveau, ``Seconde/Bilans`` par exemple), il a un lien vers la page en ligne, une ligne
« élève<TAB>lien » par élève sur la sortie standard. Rangé dans le « Bilans » de son niveau (``-o "<Dropbox>/Seconde/Bilans"``),
il s'affiche en entier sur la page des classes (``tableau_eleves.Tableau``), et seule l'évolution des thèmes d'une copie
rendue dans le bilan de cette copie, ouvert par le mot de passe tapé à l'accueil (``Paquet.poser_bilan``,
``lecteur.bilan_a_cote``, ``pont_qt.bilan_du_professeur`` ; l'utilisateur, 25/10/2026, puis 06/11/2026 : « il ne faut pas
afficher le bilan complet de l'année sur chaque copie »).

Chaque copie devient d'abord un RELEVÉ (``releve_paquet``, ``releves_papier``), un dict qui ne dépend plus de Qt :

    {"eleve", "epreuve", "fin" (time.time() du rendu, None), "etat" ("corrigée" | "en attente"), "passation"
     ("numerique" | "papier"), "obtenu", "total", "questions": [{"id", "theme", "obtenu", "points", "bonus"}],
     "statistiques": [[axe, [[libellé, gagné, noté], …]], …], "source"}

puis ``bilan_epreuve`` et ``bilan_eleve`` les additionnent. Décisions de l'utilisateur (TODO, 24/10/2026) :
  - la chronologie d'un élève est celle de la date de rendu que porte la copie (``Paquet.fin``), jamais l'ordre de
    correction ni celui des fichiers ;
  - tout est recalculé à chaque passage : aucun cumul n'est gardé d'une fois sur l'autre ;
  - une copie pas encore corrigée (pas rendue, ou des points encore laissés au professeur) est « en attente » : elle est montrée, mais n'entre dans AUCUNE moyenne, jamais comptée à zéro.
Une copie papier rendue (``correction/copie_papier.py``) est un PDF corrigé, rangé où serait la copie en ligne, son
``.qcm`` en pièce jointe : elle entre comme une copie électronique (passation « papier », date du scan). Une pile corrigée
mais pas rendue entre par ses ``notes_*.csv`` (``--papier``), question par question, leurs axes repris de la banque par
l'id de la question, sa date donnée en argument ; jamais les deux pour la même pile, elle compterait deux fois.

Le mot de passe professeur n'est lu que par ``codes.cle_du_fichier``, pour ouvrir chaque copie : rien de lui ni de la
clé n'est écrit, ni dans un relevé ni dans une sortie.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import io
import json
import os
import re
import sys
import tempfile
import time
from datetime import date, datetime
from functools import cache
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import noyau

RACINE = Path(__file__).resolve().parent
EN_ATTENTE, CORRIGEE = "en attente", "corrigée"
# une copie dont la note perd au moins 15 % du total sur la précédente : 3 points sur 20 (instruction_2). Attrape à tort
# l'écart d'une épreuve à 2 ou 3 questions, où une seule question fait 30 % : l'alerte dit les deux notes, le professeur juge.
BAISSE = 0.15
# les mots-clés des questions, que le bilan de l'élève ne montre plus : « je ne souhaite pas garder les mots clef, mais
# coller au BO, ou aux sections de mes cours » (l'utilisateur, 25/10/2026)
MOTS_CLES = "Sous-thèmes"
QUESTIONS_RATEES = 5  # les questions les plus ratées d'une épreuve, montrées
IGNORES = {"backup"}  # dossiers de sauvegarde à côté des copies (les « _… » aussi : restaurations, transits)
# le script des appréciations du bulletin (``appreciation_trimestrielle``, ``appreciation_annuelle``), dont le bilan de
# l'élève reprend le calcul (l'utilisateur, 25/10/2026 : « que ça soit le même calcul »)
SCRIPT_APPRECIATIONS = RACINE.parent / "appreciations/appreciations_annee_intermediaires_moyenne.py"
# les conseils de classe des deux premiers trimestres, 2026-2027 (l'utilisateur, 25/10/2026) : une copie rendue avant
# le jour du conseil compte dans le trimestre qu'il clôt, une copie rendue ce jour-là dans le suivant. Les jours des conseils
# plutôt que l'envoi des notes, quelques jours avant (l'utilisateur, 01/11/2026 : « garde les jours des conseils »). À changer
# chaque année.
CONSEILS = (date(2026, 12, 4), date(2027, 2, 16))
# début et fin de l'année, pour la part écoulée du trimestre en cours (``moyenne_annee``) : la rentrée, et le conseil du
# 3e trimestre (28/05/2027), provisoire comme les deux autres
ANNEE = (date(2026, 9, 1), date(2027, 5, 28))
TRIMESTRES = ("1er trimestre", "2e trimestre", "3e trimestre")
# les parts égales du bulletin (``moyenne_bulletin``), reconnues au nom de l'épreuve (``categorie``)
CATEGORIES = (("interrogation", r"\binterro"), ("DS", r"\bDS\b"), ("TP", r"\bTP"), ("projet", r"\bprojet"))


# --- les relevés --------------------------------------------------------------------------------------------------------

def _obtenu(f: Any) -> float:
    return 0 if f.sanctionnee() else (f.obtenu or 0) + (f.justification_obtenue or 0)


def _abordee(q: Any) -> bool:
    """L'élève a commencé la question : une feuille traitée, ou une saisie dont un morceau au moins est rempli."""
    return any(f.repondue or (f.saisie not in (None, "", [], {})
                              and not (isinstance(f.saisie, list) and all(s is None for s in f.saisie)))
               for f in q.feuilles())


DEVINABLES = {"Alternative"}  # Vrai/Faux : le hasard y donne une chance sur deux


def devinable(q: dict[str, Any]) -> bool:
    """Vrai/Faux ou choix à deux options : une réussite n'y prouve rien (décision 1, ETUDE.md). Ici et non dans
    ``entrainement`` (qui le réexporte) : le lecteur web l'appelle (``_premier_essai``) sans embarquer ``sujet.py``."""
    return q.get("__class__") in DEVINABLES or len(q.get("propositions") or [None] * 3) <= 2


def _premier_essai(q: Any) -> dict[str, Any]:
    """Le premier essai de ``q`` (``revision.etat_notions``) : ``premier`` vrai si toutes ses feuilles sont closes à
    pleins points sans seconde chance ni indice, faux si l'une est fausse (``reussie``) ou a pris sa seconde chance, None
    tant qu'une reste à noter ou si elle n'est juste qu'avec un indice ; ``instant`` : la première soumission (``horodatage``) ; ``devinable`` : Vrai/Faux ou deux options
    (``devinable``), hors de l'acquis ; ``validante`` : toutes ses feuilles peuvent valider l'acquis (leur champ
    ``validante``, ``revision.validante_feuilles``), None si la copie ne le porte pas (``etat_notions`` lit la banque)."""
    from revision import condition_remplie, premiere_soumission, validante_feuilles  # noqa: PLC0415 - revision importe bilans

    feuilles = q.feuilles()
    if any(f.seconde or (f.obtenu is not None and not f.reussie()) for f in feuilles):
        premier = False
    elif feuilles and all(f.fermee and f.obtenu is not None and f.obtenu >= f.points for f in feuilles):
        premier = True  # ``obtenu`` seul : une justification notée ne rattrape pas une réponse fausse
    else:
        premier = None  # à noter, ou juste avec un indice : ni réussite sans aide, ni échec qui ferait perdre l'acquis
    return {"premier": premier, "instant": premiere_soumission(q),
            "devinable": devinable({"__class__": type(q).__name__, "propositions": getattr(q, "propositions", None)}),
            "validante": validante_feuilles(q) and condition_remplie(q)}


def releve_paquet(paquet: Any, source: str = "") -> dict[str, Any]:
    """Le relevé d'une copie électronique (``noyau.Paquet``). En attente : pas rendue (``fin`` vide), en pause, ou des
    points encore laissés au professeur (``resultat``) ; la note est celle du professeur s'il l'a écrite, sinon celle de
    la machine, bonus compris sans dépasser le total (comme l'entête de la copie).
    Les questions vides après la dernière abordée sont du temps qui a manqué (``"non_abordee"``) : la note les compte,
    ni l'arbre, ni les axes, ni le bilan d'une épreuve ; une question vide au milieu, sautée, compte 0 comme une erreur
    (règle proposée à l'utilisateur, 25/10/2026 : « oui, cette règle me convient »)."""
    obtenu, _, attente = paquet.resultat()
    # une copie papier rendue est corrigée, même sans date de scan (``copie_papier.py`` sans --le ni tri.json)
    corrigee = (paquet.fin is not None or paquet.passation == "papier") and not paquet.suspendue and not attente
    bonus = {id(q) for s in paquet.sections if s.bonus for q in s.questions}
    toutes = paquet.questions()
    # papier : la saisie lue peut manquer sur une réponse écrite (``copie_papier.py``), rien n'y est retiré
    derniere = len(toutes) if paquet.passation == "papier" else max(
        (i for i, q in enumerate(toutes) if _abordee(q)), default=-1)
    questions = []
    for i, q in enumerate(toutes):
        feuilles = q.feuilles()
        notee = all(f.obtenu is not None for f in feuilles)
        questions.append({"id": q.id, "theme": q.programme or "", "points": q.total(), "bonus": id(q) in bonus,
                          "obtenu": sum(_obtenu(f) for f in feuilles) if notee else None, "non_abordee": i > derniere,
                          **_premier_essai(q)})
    note = paquet.note if paquet.note is not None else min(obtenu, paquet.total)
    essai = f" ({paquet.essai}e essai)" if paquet.essai > 1 else ""
    return {"eleve": paquet.eleve, "epreuve": (paquet.nom or " - ".join(filter(None, [paquet.titre, paquet.sous_titre]))) + essai,
            "fin": paquet.fin, "etat": CORRIGEE if corrigee else EN_ATTENTE, "passation": paquet.passation,
            "cours_devoile": dict(getattr(paquet, "cours_devoile", {})),
            "obtenu": note, "total": paquet.total, "questions": questions,
            "statistiques": [[axe, [list(l) for l in lignes]] for axe, lignes in
                             paquet.statistiques({q["id"] for q in questions if q["non_abordee"]})], "source": source}


def est_copie_eleve(chemin: Path, dossier: Path) -> bool:
    """Une copie d'élève à compter : « <sujet> [<élève>].qcm » (``codes.est_copie``), hors des dossiers de sauvegarde et de
    transit (« _… », ``IGNORES``) SOUS ``dossier`` : ceux au-dessus de lui ne comptent pas."""
    import codes  # noqa: PLC0415

    sous = chemin.parent.relative_to(dossier).parts
    return codes.est_copie(str(chemin)) and not any(p.startswith("_") or p in IGNORES for p in sous)


def releves_copies(dossier: Path) -> list[dict[str, Any]]:
    """Les relevés des copies électroniques sous ``dossier`` (sous-dossiers compris), chacune ouverte par la clé que le
    mot de passe professeur en dérive ; celles du professeur lui-même (essais) laissées de côté. Une copie papier rendue
    y est le ``.qcm`` joint à son PDF, s'il n'a pas de ``.qcm`` à côté. Une copie illisible est signalée sur la sortie
    d'erreur et sautée ; un PDF sans pièce jointe n'est pas une copie."""
    import codes  # noqa: PLC0415 - Qt et mot de passe : seulement pour ouvrir les copies
    from sujet import piece_jointe  # noqa: PLC0415
    from verifier import charger  # noqa: PLC0415

    professeur = " ".join(codes.PROFESSEUR)
    releves = []
    copies = [c for c in Path(dossier).rglob("*.qcm") if est_copie_eleve(c, Path(dossier))]
    copies += [c for c in Path(dossier).rglob("*.pdf")
               if est_copie_eleve(c.with_suffix(".qcm"), Path(dossier)) and not c.with_suffix(".qcm").exists()]
    with tempfile.TemporaryDirectory() as temporaire:
        for chemin in sorted(copies):
            try:
                qcm = chemin
                if chemin.suffix == ".pdf":
                    try:
                        octets = piece_jointe(chemin)
                    except ValueError:
                        continue
                    (qcm := Path(temporaire) / chemin.with_suffix(".qcm").name).write_bytes(octets)
                paquet = charger(qcm, codes.cle_du_fichier(qcm))
            except Exception as erreur:  # noqa: BLE001 - une copie abîmée n'arrête pas le bilan des autres
                print(f"copie illisible, sautée : {chemin} ({erreur})", file=sys.stderr)
                continue
            if paquet.eleve != professeur:
                releves.append(releve_paquet(paquet, str(chemin)))
            paquet.deleteLater()
    return releves


def index_banques(dossier: Path = RACINE / "banque") -> dict[str, dict[str, Any]]:
    """{id: champs pédagogiques} de toutes les questions des banques, lues en JSON (sans Qt) ; ceux du groupe d'une
    sous-question sous ``"groupe"``, où ``_axes`` les reprend axe par axe (comme ``Paquet.statistiques``) ; sous ``"cours"``,
    le thème du cours du professeur, le dossier de la banque sous celui du niveau (``banque/SNT/Python/…``), s'il y en a un ;
    sous ``"validante"``, ``revision.validante_question`` : ``revision.etat_notions`` la prend pour une copie qui ne porte
    pas le champ (W342)."""
    from revision import validante_question  # noqa: PLC0415 - revision importe bilans
    champs = ("programme", "tags", "competences_livret", "capacites_programme", "verbe_action", "pensee_informatique", "fiche",
              "erreurs")
    index: dict[str, dict[str, Any]] = {}

    def parcourir(questions: list[Any], parent: dict[str, Any], cours: dict[str, str]) -> None:
        for q in questions:
            if isinstance(q, dict) and "id" in q:
                index[q["id"]] = {c: q[c] for c in champs if q.get(c)} | ({"groupe": parent} if parent else {}) | cours \
                    | {"validante": validante_question(q)}
                parcourir(q.get("sous_questions") or [], {c: q[c] for c in champs[:-1] if q.get(c)}, cours)

    for fichier in Path(dossier).rglob("*.json"):
        dossiers = fichier.relative_to(dossier).parts[:-1][Path(dossier).name == "banque":]
        try:
            parcourir(json.loads(fichier.read_text(encoding="utf-8")).get("questions") or [], {},
                      {"cours": dossiers[0]} if dossiers else {})
        except (ValueError, AttributeError):
            continue  # pas une banque
    return index


def _question(champs: dict[str, Any]) -> SimpleNamespace:
    return SimpleNamespace(programme=champs.get("programme") or "", tags=champs.get("tags") or [],
                           competences_livret=champs.get("competences_livret") or {},
                           capacites_programme=champs.get("capacites_programme") or [],
                           verbe_action=champs.get("verbe_action"), pensee_informatique=champs.get("pensee_informatique") or [])


def _axes(champs: dict[str, Any]) -> list[tuple[str, dict[str, float]]]:
    """Ce que la question relève de chaque axe ; un axe vide pour elle se reprend de son groupe (``relever(f) or
    relever(q)`` de ``Paquet.statistiques``)."""
    q, groupe = _question(champs), _question(champs.get("groupe", {}))
    return [(axe, relever(q) or relever(groupe)) for axe, relever in noyau.AXES]


def statistiques(questions: list[dict[str, Any]], banque: dict[str, dict[str, Any]]) -> list[list[Any]]:
    """Le bilan par axe d'une copie dont on n'a que les points par question (une copie papier), au format de
    ``Paquet.statistiques`` et dans son ordre : Bloom dans l'ordre de la taxonomie, le reste du plus au moins réussi."""
    cumuls: dict[str, dict[Any, list[float]]] = {axe: {} for axe, _ in noyau.AXES}
    for q in questions:
        if q["obtenu"] is None:
            continue
        for axe, cles in _axes(banque.get(q["id"], {})):
            for cle, poids in cles.items():
                cumul = cumuls[axe].setdefault(cle, [0, 0])
                cumul[0] += poids * q["obtenu"]
                cumul[1] += poids * q["points"]
    bilan = []
    for axe, _ in noyau.AXES:
        lignes = [[cle, g, n] for cle, (g, n) in cumuls[axe].items() if n]
        if axe == "Niveaux de Bloom":
            lignes = [[cle[1], g, n] for cle, g, n in sorted(lignes)]
        else:
            lignes.sort(key=lambda ligne: (-ligne[1] / ligne[2], ligne[0]))
        if lignes:
            bilan.append([axe, lignes])
    return bilan


def _theme(champs: dict[str, Any]) -> str:
    return champs.get("programme") or champs.get("groupe", {}).get("programme", "")


def _champ(champs: dict[str, Any], nom: str) -> Any:
    return champs.get(nom) or champs.get("groupe", {}).get(nom)


def bareme_papier(notes: Path) -> tuple[dict[str, tuple[float, bool]], float] | None:
    """Le barème du sujet imprimé d'un CSV de notes : ``({id: (points, bonus)}, total des obligatoires)``. Le total d'une
    copie vient du sujet, jamais du CSV, qui ne relève que des points (décision du Superviseur, 24/10/2026). Le sujet :
    le paquet joint au PDF de l'archive que nomme le ``tri.json`` de la pile (le CSV est dans la pile ou dans son dossier
    de travail), à défaut le ``source.json`` de cette archive ; None si ni l'un ni l'autre ne se trouve."""
    import exporter_eleve  # noqa: PLC0415 - Qt : seulement pour lire le sujet
    from sujet import Sujet  # noqa: PLC0415

    tri = next((d / "tri.json" for d in (notes.parent, notes.parent.parent) if (d / "tri.json").exists()), None)
    archive = Path((json.loads(tri.read_text(encoding="utf-8")).get("sujet") or {}).get("archive") or "") if tri else None
    if not (archive and archive.is_dir()):
        return None
    for source in [*sorted(p for p in archive.glob("*.pdf") if "corrigé" not in p.name), *archive.glob("*source.json")]:
        try:
            paquet = exporter_eleve.preparer(Sujet(source), chiffrer=False)[0]
        except Exception:  # noqa: BLE001 - PDF sans paquet joint (archive d'avant la pièce jointe) : la source suivante
            continue
        bonus = {id(q) for s in paquet.sections if s.bonus for q in s.questions}
        bareme = {q.id: (q.total(), id(q) in bonus) for q in paquet.questions()}, paquet.total
        paquet.deleteLater()
        return bareme
    return None


def releves_papier(chemin: Path, date: str, epreuve: str, banque: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Les relevés des copies papier d'un ``notes_*.csv`` (``arbitrer.py fusionner``, ``corriger_papier.py`` :
    copie;question;points;sur…), une par valeur de ``eleve`` si la colonne existe, sinon de ``copie`` : pour qu'une copie
    papier rejoigne les copies électroniques d'un élève, cette colonne doit porter « Nom Prénom ». ``date`` (AAAA-MM-JJ)
    tient lieu de date de rendu. Une ligne sans points (``points`` vide) laisse la copie en attente.
    Barème, questions bonus et total viennent du sujet imprimé (``bareme_papier``) : la note, bonus compris sans dépasser
    le total, comme une copie électronique. Sans sujet trouvable, le total reste la somme des « sur » du CSV, bonus
    compris, et l'épreuve le dit (« bonus inconnus »)."""
    with open(chemin, encoding="utf-8", newline="") as f:
        lignes = list(csv.DictReader(f, delimiter=";"))
    fin = datetime.strptime(date, "%Y-%m-%d").timestamp()
    bareme, total = bareme_papier(Path(chemin)) or ({}, None)
    if total is None:
        epreuve += " (bonus inconnus)"
    copies: dict[str, list[dict[str, Any]]] = {}
    for ligne in lignes:
        eleve = (ligne.get("eleve") or ligne.get("copie") or "").strip()
        points = (ligne.get("points") or "").strip()
        sur, bonus = bareme.get(ligne["question"], (float(ligne["sur"]), False))
        copies.setdefault(eleve, []).append({
            "id": ligne["question"], "theme": _theme(banque.get(ligne["question"], {})),
            "points": sur, "obtenu": float(points) if points else None, "bonus": bonus})
    releves = []
    for eleve, questions in copies.items():
        corrigee = all(q["obtenu"] is not None for q in questions)
        sur = sum(q["points"] for q in questions) if total is None else total
        releves.append({"eleve": eleve, "epreuve": epreuve, "fin": fin, "etat": CORRIGEE if corrigee else EN_ATTENTE,
                        "passation": "papier", "obtenu": min(sum(q["obtenu"] or 0 for q in questions), sur),
                        "total": sur, "questions": questions,
                        "statistiques": statistiques(questions, banque), "source": str(chemin)})
    return releves


def erreurs_types(chemins: list[Path], banque: dict[str, dict[str, Any]]) -> list[tuple[str, str, int]]:
    """Le comptage des erreurs types des propositions de ``corriger_lot.py`` (colonne ``erreur_type``, numéro dans la
    liste ``erreurs`` de la question, de 1) : [(question, erreur, copies), …], les plus fréquentes d'abord."""
    comptes: dict[tuple[str, str], int] = {}
    for chemin in chemins:
        with open(chemin, encoding="utf-8", newline="") as f:
            for ligne in csv.DictReader(f, delimiter=";"):
                numero = (ligne.get("erreur_type") or "").strip()
                if not numero.isdigit():
                    continue
                erreurs = banque.get(ligne["question"], {}).get("erreurs") or []
                texte = erreurs[int(numero) - 1] if 1 <= int(numero) <= len(erreurs) else f"erreur type n°{numero}"
                cle = ligne["question"], texte if isinstance(texte, str) else json.dumps(texte, ensure_ascii=False)
                comptes[cle] = comptes.get(cle, 0) + 1
    return sorted(((q, e, n) for (q, e), n in comptes.items()), key=lambda t: (-t[2], t[0], t[1]))


# --- les agrégats -------------------------------------------------------------------------------------------------------

def taux(gagne: float, note: float) -> float | None:
    return gagne / note if note else None


def _cumuler_axes(releves: list[dict[str, Any]]) -> list[list[Any]]:
    cumuls: dict[str, dict[str, list[float]]] = {}
    for r in releves:
        for axe, lignes in r["statistiques"]:
            for libelle, g, n in lignes:
                cumul = cumuls.setdefault(axe, {}).setdefault(libelle, [0, 0])
                cumul[0] += g
                cumul[1] += n
    ordre = [axe for axe, _ in noyau.AXES]
    return [[axe, sorted(([l, g, n, g / n] for l, (g, n) in cumuls[axe].items() if n), key=lambda x: (x[3], x[0]))]
            for axe in sorted(cumuls, key=ordre.index)]


def bilan_epreuve(releves: list[dict[str, Any]], erreurs: list[tuple[str, str, int]] | None = None) -> dict[str, Any]:
    """Le bilan d'une épreuve sur ses copies CORRIGÉES : moyenne, taux par question et par axe (du moins au mieux réussi),
    les questions et les thèmes les plus ratés, les erreurs types comptées ; les copies en attente comptées à part."""
    corrigees = [r for r in releves if r["etat"] == CORRIGEE]
    questions: dict[str, dict[str, Any]] = {}
    for r in corrigees:
        for q in r["questions"]:
            if q["obtenu"] is None or q.get("non_abordee"):
                continue
            cumul = questions.setdefault(q["id"], {"id": q["id"], "theme": q["theme"], "obtenu": 0, "points": 0, "copies": 0})
            cumul["obtenu"] += q["obtenu"]
            cumul["points"] += q["points"]
            cumul["copies"] += 1
    par_question = sorted(({**c, "taux": taux(c["obtenu"], c["points"])} for c in questions.values() if c["points"]),
                          key=lambda c: (c["taux"], c["id"]))
    axes = _cumuler_axes(corrigees)
    themes = next((lignes for axe, lignes in axes if axe == "Thèmes"), [])
    return {
        "epreuves": sorted({r["epreuve"] for r in releves}),
        "copies": len(corrigees), "en_attente": sorted(r["eleve"] for r in releves if r["etat"] == EN_ATTENTE),
        "moyenne": sum(r["obtenu"] / r["total"] for r in corrigees) / len(corrigees) if corrigees else None,
        "questions": par_question, "plus_ratees": par_question[:QUESTIONS_RATEES],
        "axes": axes, "themes_rates": [t for t in themes if t[3] < noyau.SEUIL_FAIBLE],
        "erreurs_types": erreurs or [],
    }


def bilan_eleve(releves: list[dict[str, Any]]) -> dict[str, Any]:
    """Le parcours d'un élève : ses copies dans l'ordre de leur date de rendu (``fin`` ; une copie jamais rendue à la
    fin), son taux à chacune (None en attente), et les alertes, sur les seules copies corrigées : une baisse nette
    (``BAISSE``) d'une copie à la suivante, un même libellé d'axe sous ``SEUIL_FAIBLE`` deux fois de suite (parmi les
    copies qui le notent)."""
    ordre = sorted(releves, key=lambda r: (r["fin"] is None, r["fin"] or 0, r["epreuve"]))
    parcours = [{"epreuve": r["epreuve"], "fin": r["fin"], "etat": r["etat"], "passation": r["passation"],
                 "obtenu": r["obtenu"], "total": r["total"],
                 "non_abordees": sum(bool(q.get("non_abordee")) for q in r["questions"]),
                 "taux": taux(r["obtenu"], r["total"]) if r["etat"] == CORRIGEE else None} for r in ordre]
    corrigees = [r for r in ordre if r["etat"] == CORRIGEE]
    les_taux = [p["taux"] for p in parcours if p["taux"] is not None]
    alertes, conseils = [], []  # les mêmes constats, dits au professeur, puis à l'élève (l'utilisateur, 25/10/2026)
    for avant, apres in zip(corrigees, corrigees[1:]):
        t1, t2 = taux(avant["obtenu"], avant["total"]), taux(apres["obtenu"], apres["total"])
        if t1 is not None and t2 is not None and t1 - t2 >= BAISSE:
            alertes.append(f"baisse nette : {avant['epreuve']} {t1:.0%} → {apres['epreuve']} {t2:.0%}")
            conseils.append(f"Vos résultats ont baissé entre {avant['epreuve']} ({t1:.0%}) et {apres['epreuve']} ({t2:.0%}) : "
                            "reprenez ce qui est à retravailler avant la prochaine épreuve.")
    derniers: dict[tuple[str, str], tuple[str, float]] = {}  # (axe, libellé) -> (épreuve, taux) à sa dernière copie
    for r in corrigees:
        for axe, lignes in r["statistiques"]:
            for libelle, g, n in lignes:
                if not n:
                    continue
                t, precedent = g / n, derniers.get((axe, libelle))
                if t < noyau.SEUIL_FAIBLE and precedent and precedent[1] < noyau.SEUIL_FAIBLE:
                    alertes.append(f"{axe} « {libelle} » sous {noyau.SEUIL_FAIBLE:.0%} deux fois de suite : "
                                   f"{precedent[0]} {precedent[1]:.0%}, {r['epreuve']} {t:.0%}")
                    conseils += [] if axe == MOTS_CLES else [f"« {libelle} » n'atteint pas la moitié des points deux fois de suite ({precedent[0]} "
                                    f"{precedent[1]:.0%}, {r['epreuve']} {t:.0%}) : revoyez-le en priorité, et posez vos questions."]
                derniers[(axe, libelle)] = r["epreuve"], t
    eleves = sorted({r["eleve"] for r in releves})
    return {"eleve": eleves[0] if len(eleves) == 1 else eleves, "parcours": parcours, "alertes": alertes,
            "conseils": conseils, "axes": _cumuler_axes(corrigees),
            "moyenne": sum(les_taux) / len(les_taux) if les_taux else None}


def par_eleve(releves: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    eleves: dict[str, list[dict[str, Any]]] = {}
    for r in releves:
        eleves.setdefault(r["eleve"], []).append(r)
    return dict(sorted(eleves.items()))


# --- l'appréciation du bulletin, projetée ------------------------------------------------------------------------------

@cache
def script_appreciations() -> dict[str, Any]:
    """Les fonctions et les dictionnaires du script des appréciations de l'utilisateur, importé tel quel (sa génération
    est sous ``if __name__ == "__main__"``, 25/10/2026) : le calcul reste le sien, écrit à un seul endroit."""
    spec = importlib.util.spec_from_file_location("appreciations_script", SCRIPT_APPRECIATIONS)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return vars(module)


def trimestre(jour: date) -> int:
    """0, 1 ou 2 : le trimestre de ``jour`` (``CONSEILS``)."""
    return sum(jour >= conseil for conseil in CONSEILS)


def categorie(epreuve: str) -> str | None:
    """La part du bulletin que compte ``epreuve``, lue dans son nom : « TP », « DS », « interrogation » ou « projet » ; ``None``
    pour une révision, qui ne compte jamais (l'utilisateur, 25/10/2026 : « des notes qui servent juste pour aider les
    élèves à anticiper la note qu'ils auront », « elles servent à les aider à savoir quoi travailler » : elles restent
    dans les points solides et à retravailler), ni ce qui ne porte aucun de ces mots, comme un sujet de bac (« ils
    serviront de révisions chez eux »)."""
    if re.search(r"\bR[ée]visions?\b", epreuve, re.IGNORECASE):
        return None
    for nom, motif in CATEGORIES:
        if re.search(motif, epreuve, re.IGNORECASE):
            return nom
    return None


def moyenne_bulletin(notes: list[tuple[str, float]]) -> float | None:
    """La moyenne sur 20 de ``notes`` ([(catégorie, note sur 20), …]) : chaque catégorie présente pèse autant, la
    moyenne simple de ses copies (l'utilisateur, 25/10/2026 : « les TP doivent représenter 1/3 de la note, les DS 1/3
    et les mini-interrogations 1/3. s'il n'y a pas eu de l'une […] c'est 1/2 1/2 », « les projets comptent comme une
    nouvelle catégorie à part égale si présente »)."""
    parts: dict[str, list[float]] = {}
    for nom, note in notes:
        parts.setdefault(nom, []).append(note)
    return sum(sum(n) / len(n) for n in parts.values()) / len(parts) if parts else None


def moyennes_trimestres(parcours: list[dict[str, Any]], aujourd_hui: date) -> tuple[list[float | None], int | None]:
    """Les moyennes sur 20 des trois trimestres (``None`` sans copie notée) et le dernier trimestre noté jusqu'à celui en
    cours (``None`` : aucun) : les copies corrigées par date de rendu, TP, DS, interrogations et projets à parts égales
    (``moyenne_bulletin``)."""
    notes: list[list[tuple[str, float]]] = [[], [], []]
    for p in parcours:
        nom = categorie(p["epreuve"])
        if nom and p["taux"] is not None and p["fin"] is not None:
            notes[trimestre(datetime.fromtimestamp(p["fin"]).date())].append((nom, 20 * p["taux"]))
    moyennes = [moyenne_bulletin(n) for n in notes]
    courant = trimestre(aujourd_hui)
    return moyennes, max((i for i, m in enumerate(moyennes[:courant + 1]) if m is not None), default=None)


def moyenne_annee(parcours: list[dict[str, Any]], aujourd_hui: date) -> float | None:
    """La moyenne sur 20 de l'année à ``aujourd_hui`` : celle des moyennes de trimestre (l'utilisateur, 25/10/2026 : « la
    moyenne à l'année est la moyenne des 3 moyennes de trimestre »), le trimestre en cours compté « au prorata du
    trimestre écoulé », un trimestre sans copie notée ne comptant pas."""
    moyennes, _ = moyennes_trimestres(parcours, aujourd_hui)
    courant = trimestre(aujourd_hui)
    debut, fin = ([ANNEE[0], *CONSEILS, ANNEE[1]])[courant:courant + 2]
    poids = [1.0] * courant + [min(max((aujourd_hui - debut) / (fin - debut), 0.0), 1.0)]
    comptes = [(m, p) for m, p in zip(moyennes, poids) if m is not None]
    if not comptes:
        return None
    if sum(p for _, p in comptes) == 0:  # le premier jour du trimestre, sans trimestre noté avant : ce qu'il y a
        return comptes[-1][0]
    return sum(m * p for m, p in comptes) / sum(p for _, p in comptes)


def appreciations(parcours: list[dict[str, Any]], aujourd_hui: date) -> list[list[str]]:
    """L'appréciation que le bulletin donnera si l'élève continue ainsi (l'utilisateur, 25/10/2026) : [[titre, texte], …],
    celle de chaque trimestre noté jusqu'à celui en cours, puis celle de l'année à ce jour. La note d'un trimestre
    (``moyennes_trimestres``) passe dans ``appreciation_trimestrielle`` (comparée au trimestre d'avant) ; l'année prend
    la phrase de ``APPRECIATIONS_ANNEE`` pour ``moyenne_annee`` et la tendance des seuls trimestres commencés, comme
    ``appreciation_annuelle`` du script (l'utilisateur, 25/10/2026 : « il ne faut aucunement extrapoler les trimestres
    non commencés »). À la fin d'un trimestre, celle du trimestre EST l'appréciation du script pour cette
    moyenne ; à la fin de l'année, celle de l'année EST ``appreciation_annuelle`` des trois moyennes."""
    script = script_appreciations()
    moyennes, dernier = moyennes_trimestres(parcours, aujourd_hui)
    courant = trimestre(aujourd_hui)
    if dernier is None:
        return []
    virgule = lambda x: f"{round(x, 1):g}".replace(".", ",")
    rendus = []
    for i in range(dernier + 1):
        if moyennes[i] is None:
            continue
        quand = "si vous continuez ainsi, moyenne actuelle" if i == courant else "moyenne"
        texte = script["appreciation_trimestrielle"](moyennes[i], moyennes[i - 1] if i else None, i + 1)
        rendus.append([f"{TRIMESTRES[i]} ({quand} {virgule(moyennes[i])} / 20)", texte])
    if courant < 2:  # l'utilisateur, 25/10/2026 : « ça sert à rien de parler d'année avant le début du 3ème trimestre »
        return rendus
    commences = [m for m in moyennes[:dernier + 1] if m is not None]
    annee = script["APPRECIATIONS_ANNEE"][script["note_arrondie"](moyenne_annee(parcours, aujourd_hui))]
    rendus.append(["L'année à ce jour", annee[script["tendance_annuelle"](commences)]])
    return rendus


def moyenne_affichee(parcours: list[dict[str, Any]], aujourd_hui: date) -> tuple[str, float | None]:
    """La moyenne en tête du bilan, ``(période, moyenne sur 20)`` : celle de l'année (``moyenne_annee``) à partir du
    3e trimestre, avant celle du dernier trimestre noté (« ça sert à rien de parler d'année avant le début du 3ème
    trimestre », 25/10/2026) ; ``("de l'année", None)`` si rien n'est noté."""
    moyennes, dernier = moyennes_trimestres(parcours, aujourd_hui)
    if trimestre(aujourd_hui) == 2 or dernier is None:
        return "de l'année", moyenne_annee(parcours, aujourd_hui)
    return f"du {TRIMESTRES[dernier]}", moyennes[dernier]


def chemins_question(champs: dict[str, Any]) -> list[tuple[str, ...]]:
    """Les chemins COMPLETS d'une question dans l'arbre du bilan (règles d'``arbre``) : thème du cours, à défaut grand
    thème du BO, « Autres » sans rien ; puis section du cours (``fiche``), à défaut contenu du BO et sa capacité.
    Partagé par ``arbre`` et ``entrainement.py``, qui compose un sujet par section de « Réviser »."""
    parties = [[c.strip() for c in capacite.split("->")] for capacite in _champ(champs, "capacites_programme") or []]
    tete = champs.get("cours") or next((c[0] for c in parties if len(c) > 1), "Autres")
    if _champ(champs, "fiche"):
        return [(tete, *(s.strip() for s in _champ(champs, "fiche").split("->")))]
    if programme := _champ(champs, "programme"):
        return [(tete, programme, c[-1]) for c in parties] or [(tete, programme)]
    return [(tete, c[-1]) for c in parties] or [(tete,)]


def arbre(releves: list[dict[str, Any]], banque: dict[str, dict[str, Any]]) -> list[list[Any]]:
    """Les points des questions notées en arbre, ``[[libellé, gagné, noté, taux, enfants], …]``, champs repris de la
    banque par l'id : « il faut utiliser mes thèmes et mes grandes sections quand le cours existe, sinon tu te replies sur
    le BO » (l'utilisateur, 25/10/2026). En tête le thème du cours (``"cours"`` d'``index_banques``), à défaut le grand
    thème du BO (« localisation », le préfixe d'une capacité) ; puis la section du cours (``fiche``, « Structures de
    contrôle -> for »), à défaut le contenu du BO (``programme``) et sa capacité, celle-ci seulement sous un contenu qui
    en a plusieurs (presque toujours une seule, qui le redirait). Une question compte entière dans chaque nœud qu'elle
    touche, une fois ; sans thème ni capacité, sous « Autres ». Dans l'ordre où les copies les voient."""
    noeuds: dict[tuple[str, ...], list[float]] = {}
    capacites: set[tuple[str, ...]] = set()
    for r in releves:
        for q in r["questions"]:
            champs = banque.get(q["id"], {})
            if q["obtenu"] is None or q.get("non_abordee") or not q["points"] or not champs:
                continue
            chemins = chemins_question(champs)
            if not _champ(champs, "fiche") and _champ(champs, "programme"):
                capacites |= {c for c in chemins if len(c) == 3}
            for prefixe in dict.fromkeys(c[:i] for c in chemins for i in range(1, len(c) + 1)):
                noeud = noeuds.setdefault(prefixe, [0, 0])
                noeud[0] += q["obtenu"]
                noeud[1] += q["points"]
    for chemin in capacites:
        if sum(len(c) == 3 and c[:2] == chemin[:2] for c in noeuds) == 1:
            del noeuds[chemin]

    def enfants(parent: tuple[str, ...]) -> list[list[Any]]:
        return [[c[-1], g, n, g / n, enfants(c)] for c, (g, n) in noeuds.items()
                if len(c) == len(parent) + 1 and c[:-1] == parent]

    return enfants(())


# --- les fichiers de bilan, un par élève (``bilans_widget``) ----------------------------------------------------------

def bilan_fichier(releves: list[dict[str, Any]], aujourd_hui: date | None = None,
                  banque: dict[str, dict[str, Any]] | None = None, maintenant: float | None = None) -> dict[str, Any]:
    """Les paramètres du ``bilans_widget.Bilan`` d'un élève : son parcours sans la source ni le détail des questions, et
    sans note pour une copie en attente (rien, jamais 0) ; les conseils, pas les alertes, qui sont dites au professeur ;
    l'arbre des copies corrigées (``arbre``, champs repris de ``banque``) et les autres axes, sans les mots-clés ;
    l'appréciation et la moyenne de tête (``moyenne_affichee``) à ``aujourd_hui`` (par défaut, le jour même) ; les points
    de chaque copie par thème (``themes_par_copie``), d'où l'évolution montrée sous la copie et sur la page des classes ;
    l'état de ses notions à ``maintenant`` (``revision.etat_notions`` sur toutes ses copies, ``revision.en_bilan``) et cet
    instant (``notions_le``), d'où le lecteur compose son questionnaire « Réviser » (décision 22:49 du professeur)."""
    from revision import en_bilan, etat_notions, jauges  # noqa: PLC0415 - revision importe bilans
    b = bilan_eleve(releves)
    maintenant = time.time() if maintenant is None else maintenant
    parcours = [{"epreuve": p["epreuve"], "fin": p["fin"], "etat": p["etat"], "total": p["total"], "taux": p["taux"],
                 "obtenu": p["obtenu"] if p["etat"] == CORRIGEE else None} for p in b["parcours"]]
    aujourd_hui = aujourd_hui or date.today()
    periode, annee = moyenne_affichee(b["parcours"], aujourd_hui)
    corrigees = [r for r in releves if r["etat"] == CORRIGEE]
    # une réponse laissée au professeur n'a pas de premier essai (``_premier_essai``) : elle ne compte pas (08/11/2026)
    etats = etat_notions(releves, banque or {}, maintenant)
    return {"eleve": b["eleve"], "parcours": parcours, "conseils": b["conseils"],
            "arbre": jauges(arbre(corrigees, banque or {}), etats),  # la jauge d'acquis, plus le taux de réussite (08/11/2026)
            "axes": [a for a in b["axes"] if a[0] != MOTS_CLES], "appreciations": appreciations(b["parcours"], aujourd_hui), "periode": periode, "annee": annee,
            "themes_par_copie": themes_par_copie(corrigees, banque or {}),
            "etat_notions": en_bilan(etats), "notions_le": maintenant}


def themes_par_copie(corrigees: list[dict[str, Any]], banque: dict[str, dict[str, Any]]) -> list[list[Any]]:
    """``[[épreuve, fin, thème, gagné, noté], …]`` : les points de chaque copie corrigée par thème, dans l'ordre des rendus,
    d'où l'évolution d'un thème d'une copie à l'autre (``bilans_widget.evolution`` ; l'utilisateur, 06/11/2026 : « quelques
    éléments pour voir l'évolution dans le ou les thèmes concernés par la copie »). Le thème est la tête de ``arbre`` (le
    thème du cours, à défaut celui du BO) ; pour une copie dont aucune question n'est dans les banques, son axe « Thèmes »
    (``Paquet.statistiques``)."""
    lignes = []
    for r in sorted(corrigees, key=lambda r: (r["fin"] is None, r["fin"] or 0, r["epreuve"])):
        themes = [(l, g, n) for l, g, n, _, _ in arbre([r], banque)] or next(
            (detail for axe, detail in r["statistiques"] if axe == "Thèmes"), [])
        lignes += [[r["epreuve"], r["fin"], l, g, n] for l, g, n in themes if n]
    return lignes


def dropbox_de_l_application() -> Path:
    """Le dossier Dropbox de l'application, où sont le fichier d'empreintes et les bilans en ligne."""
    sys.path.insert(0, str(RACINE / "web"))
    from dropbox_professeur import RACINE as DROPBOX  # noqa: PLC0415
    return DROPBOX.resolve()


def ecrire_bilans(releves: list[dict[str, Any]], sortie: Path, listes: list[Path],
                  banque: dict[str, dict[str, Any]] | None = None,
                  identites: dict[str, Any] | None = None) -> list[tuple[str, Path | None]]:
    """Écrit le bilan de chaque élève des listes dans ``sortie``, « Bilan [Nom Prénom].report » : chiffré pour lui et le
    professeur (``codes.cle_bilan``, tirée de sa publique déposée) s'il en a une, en clair s'il n'a pas encore de mot de
    passe. ``identites`` : le fichier d'empreintes, celui de Dropbox par défaut ; absent, rien n'est écrit (tout partirait en
    clair). Rend ``(élève, fichier)``, ``None`` pour un élève hors des listes : dit sur stderr."""
    import codes  # noqa: PLC0415
    import serializejson  # noqa: PLC0415
    from bilans_widget import Bilan, nom_du_fichier  # noqa: PLC0415 - Qt : seulement pour écrire les fichiers
    inscrits = [e for liste in listes for e in codes.lire_liste(liste)]
    if identites is None:
        fichier = dropbox_de_l_application() / codes.IDENTITES
        if not fichier.is_file():  # tout partirait en clair, même le bilan d'un élève qui a un mot de passe
            raise SystemExit(f"{fichier} absent : aucun bilan écrit")
        identites = codes.identites_lire(fichier.read_text(encoding="utf-8"))
    genere = datetime.now().strftime("%d/%m/%Y")
    sortie.mkdir(parents=True, exist_ok=True)
    faits: list[tuple[str, Path | None]] = []
    for eleve, siens in par_eleve(releves).items():
        inscrit = codes.reconnaitre(eleve, "", inscrits)
        if inscrit is None:
            print(f"{eleve} : sur aucune liste, pas de bilan", file=sys.stderr)
            faits.append((eleve, None))
            continue
        # sous le nom du relevé, puis sous celui de la liste : une faute de frappe dans le relevé n'écrit pas le bilan en clair
        cles = codes.nom_identite(eleve, ""), codes.nom_identite(inscrit[0], inscrit[1])
        publique = next(filter(None, (identites.get("eleves", {}).get(c, {}).get("publique") for c in cles)), None)
        # en armure ASCII, comme une copie d'élève (``modele.sauver``) : le lecteur web le lit en texte
        chiffrement = {"encryption_key": codes.cle_bilan(publique), "encryption_in_base64": True} if publique else {}
        chemin = sortie / nom_du_fichier(eleve)
        bilan = Bilan(**bilan_fichier(siens, banque=banque), genere=genere)
        serializejson.dump(bilan, str(chemin), bytes_compression=None, index=None, sort_keys=False,
                           single_line_list_numbers=False, **chiffrement)
        bilan.deleteLater()
        faits.append((eleve, chemin))
    serializejson.wait_writes()
    return faits


def liens(faits: list[tuple[str, Path | None]], hote: str) -> list[tuple[str, str]]:
    """Le lien de chaque bilan déposé dans le dossier Dropbox de l'application (``web/dropbox_professeur.RACINE``, à la racine
    ou sous un niveau) : « HOTE?sujet=<sa place> », que la page en ligne ouvre (``dropbox.js``), comme le lien d'un sujet
    (``deployer_qcm``). Un bilan hors de ce dossier, ou dans un
    sous-dossier de la racine qui n'est pas un niveau, n'a pas de lien : ``dropbox.js fichier`` le refuserait."""
    from urllib.parse import quote  # noqa: PLC0415
    dropbox = dropbox_de_l_application()
    rendus = []
    for eleve, chemin in faits:
        place = chemin and chemin.resolve()
        if place and place.is_relative_to(dropbox):
            place = place.relative_to(dropbox).as_posix()
            if re.fullmatch(r"((Seconde|Première|Terminale)/.+/)?[^/\\]+\.report", place):  # le motif de dropbox.js fichier
                rendus.append((eleve, f"{hote}?sujet={quote(place)}"))
    return rendus


def hote() -> str:
    """L'adresse de la page en ligne, la seule ligne lue de ``web/deployer.conf`` (HOTE), vide sans elle."""
    conf = RACINE / "web/deployer.conf"
    lignes = conf.read_text().splitlines() if conf.exists() else []
    return next((l.partition("=")[2].strip().strip("'\"") for l in lignes if l.startswith("HOTE=")), "")


# --- les sorties --------------------------------------------------------------------------------------------------------

def _pc(t: float | None) -> str:
    return "—" if t is None else f"{t:.0%}"


def _date(fin: float | None) -> str:
    return "—" if fin is None else datetime.fromtimestamp(fin).strftime("%d/%m/%Y %H:%M")


def _note(p: dict[str, Any]) -> str:
    return EN_ATTENTE if p["etat"] == EN_ATTENTE else f"{p['obtenu']:g} / {p['total']:g}"


def markdown_epreuve(bilan: dict[str, Any]) -> str:
    lignes = [f"# Bilan : {', '.join(bilan['epreuves'])}", "",
              f"{bilan['copies']} copies corrigées, moyenne {_pc(bilan['moyenne'])} ; "
              f"{len(bilan['en_attente'])} en attente (hors moyennes){' : ' + ', '.join(bilan['en_attente']) if bilan['en_attente'] else ''}.",
              "", "## Questions les plus ratées", "", "| question | thème | réussite | copies |", "|---|---|---|---|"]
    lignes += [f"| {q['id']} | {q['theme']} | {_pc(q['taux'])} | {q['copies']} |" for q in bilan["plus_ratees"]]
    if bilan["themes_rates"]:
        lignes += ["", "## Thèmes sous la moitié des points", ""]
        lignes += [f"- {l} : {_pc(t)} ({g:g} / {n:g})" for l, g, n, t in bilan["themes_rates"]]
    lignes += ["", "## Axes", ""]
    for axe, detail in bilan["axes"]:
        lignes += [f"**{axe}** : " + " ; ".join(f"{l} {_pc(t)}" for l, _, _, t in detail), ""]
    if bilan["erreurs_types"]:
        lignes += ["## Erreurs types", "", "| question | erreur | copies |", "|---|---|---|"]
        lignes += [f"| {q} | {e} | {n} |" for q, e, n in bilan["erreurs_types"]]
    lignes += ["", "## Toutes les questions", "", "| question | thème | réussite | copies |", "|---|---|---|---|"]
    lignes += [f"| {q['id']} | {q['theme']} | {_pc(q['taux'])} | {q['copies']} |" for q in bilan["questions"]]
    return "\n".join(lignes) + "\n"


def markdown_eleve(bilan: dict[str, Any]) -> str:
    lignes = [f"## {bilan['eleve']}", "", f"Moyenne des copies corrigées : {_pc(bilan['moyenne'])}.", "",
              "| rendue le | épreuve | passation | note | réussite |", "|---|---|---|---|---|"]
    lignes += [f"| {_date(p['fin'])} | {p['epreuve']} | {p['passation']} | "
               f"{_note(p)} | {_pc(p['taux'])} |"
               for p in bilan["parcours"]]
    if bilan["alertes"]:
        lignes += ["", "Alertes :", *[f"- {a}" for a in bilan["alertes"]]]
    for axe, detail in bilan["axes"]:
        lignes += ["", f"**{axe}** : " + " ; ".join(f"{l} {_pc(t)}" for l, _, _, t in detail)]
    return "\n".join(lignes) + "\n"


def csv_epreuve(bilan: dict[str, Any]) -> str:
    sortie = io.StringIO()
    ecrire = csv.writer(sortie, delimiter=";", lineterminator="\n")
    ecrire.writerow(["sorte", "axe", "libelle", "gagne", "note", "taux", "copies"])
    for q in bilan["questions"]:
        ecrire.writerow(["question", "", q["id"], f"{q['obtenu']:g}", f"{q['points']:g}", f"{q['taux']:.3f}", q["copies"]])
    for axe, detail in bilan["axes"]:
        for l, g, n, t in detail:
            ecrire.writerow(["axe", axe, l, f"{g:g}", f"{n:g}", f"{t:.3f}", ""])
    for q, e, n in bilan["erreurs_types"]:
        ecrire.writerow(["erreur_type", q, e, "", "", "", n])
    return sortie.getvalue()


def csv_eleves(bilans: list[dict[str, Any]]) -> str:
    sortie = io.StringIO()
    ecrire = csv.writer(sortie, delimiter=";", lineterminator="\n")
    ecrire.writerow(["eleve", "fin", "epreuve", "passation", "etat", "obtenu", "total", "taux", "alertes"])
    for b in bilans:
        for p in b["parcours"]:
            notee = p["etat"] == CORRIGEE  # une copie en attente n'a pas de note : rien, jamais 0
            ecrire.writerow([b["eleve"], _date(p["fin"]), p["epreuve"], p["passation"], p["etat"],
                             f"{p['obtenu']:g}" if notee else "", f"{p['total']:g}",
                             "" if p["taux"] is None else f"{p['taux']:.3f}", ""])
        for a in b["alertes"]:
            ecrire.writerow([b["eleve"], "", "", "", "", "", "", "", a])
    return sortie.getvalue()


def main(arguments: list[str] | None = None) -> int:
    lecteur = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    lecteur.add_argument("sorte", choices=["epreuve", "eleves", "fichiers"])
    lecteur.add_argument("dossier", type=Path, nargs="?", help="dossier des copies électroniques (sous-dossiers compris)")
    lecteur.add_argument("--papier", nargs=3, action="append", default=[], metavar=("NOTES_CSV", "AAAA-MM-JJ", "EPREUVE"))
    lecteur.add_argument("--propositions", type=Path, action="append", default=[], help="CSV de corriger_lot (erreur_type)")
    lecteur.add_argument("--eleve", help="« Nom Prénom » : ce seul élève")
    lecteur.add_argument("--banques", type=Path, default=RACINE / "banque")
    lecteur.add_argument("--format", choices=["md", "csv"], default="md")
    lecteur.add_argument("-o", "--sortie", type=Path, help="fichier ; pour « fichiers », le dossier des bilans")
    lecteur.add_argument("--listes", type=Path, nargs="+", default=sorted((RACINE / "listes").glob("*.csv")),
                         help="« fichiers » : les listes de classes, seuls leurs élèves ont un bilan (défaut : listes/)")
    a = lecteur.parse_args(arguments)
    if a.sorte == "fichiers" and not a.sortie:
        lecteur.error("« fichiers » demande -o DOSSIER")
    banque = index_banques(a.banques) if a.papier or a.propositions or a.sorte == "fichiers" else {}
    releves = releves_copies(a.dossier) if a.dossier else []
    for notes, date, epreuve in a.papier:
        releves += releves_papier(Path(notes), date, epreuve, banque)
    if a.eleve:
        releves = [r for r in releves if r["eleve"] == a.eleve]
    if a.sorte == "epreuve":
        bilan = bilan_epreuve(releves, erreurs_types(a.propositions, banque))
        texte = markdown_epreuve(bilan) if a.format == "md" else csv_epreuve(bilan)
    elif a.sorte == "fichiers":
        faits = ecrire_bilans(releves, a.sortie, a.listes, banque)
        adresse = hote()
        rendus = liens(faits, adresse) if adresse else []
        for eleve, lien in rendus:
            print(f"{eleve}\t{lien}")
        ecrits = sum(1 for _, c in faits if c)
        print(f"{ecrits} bilans écrits dans {a.sortie}, {len(faits) - ecrits} refusés ; "
              + (f"{len(rendus)} liens" + (" (un lien demande le dossier Dropbox de l'application, à la racine ou sous"
                                           " Seconde/, Première/, Terminale/)" if len(rendus) < ecrits else "")
                 if adresse else "pas de lien : pas d'HOTE dans web/deployer.conf"), file=sys.stderr)
        return 0
    else:
        bilans = [bilan_eleve(r) for r in par_eleve(releves).values()]
        texte = "\n".join(markdown_eleve(b) for b in bilans) if a.format == "md" else csv_eleves(bilans)
    if a.sortie:
        a.sortie.write_text(texte, encoding="utf-8")
    else:
        sys.stdout.write(texte)
    return 0


if __name__ == "__main__":
    # sortie immédiate, sans la fin de l'interpréteur : elle détruisait un à un les objets Qt de toutes les copies lues, 16 min
    # pour les 433 du dossier Seconde après 22 min de recalcul (essai W223, 07/11/2026), et la veille de
    # ``web/sauvegarde_travaux.py`` attend ce processus. Tout est écrit quand ``main`` rend la main (``write_text``,
    # ``serializejson.wait_writes``) ; seules les sorties standard, tamponnées, restent à vider.
    # sans écran : lire une copie (``verifier.charger``) montre ses widgets, environ 3,6 fenêtres sans parent par copie ; lancé
    # dans la session par la veille, chacune passait dans la barre des tâches, une icône « bilans.py » qui clignotait 20 min
    # durant (W447, 08/11/2026). Un calcul n'affiche rien : forcé, même si la session impose une plateforme.
    os.environ["QT_QPA_PLATFORM"] = "offscreen"
    code = main()
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(code)
