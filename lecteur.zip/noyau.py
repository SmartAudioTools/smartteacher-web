"""Le noyau du modèle objet de QCM/, sans Qt : les données et la logique des banques, questions, sujets et paquets.

``modele.py`` en dérive ses widgets (``class ChoixUnique(noyau.ChoixUnique, Choix)``) ; le lecteur web l'importe
seul, sous Pyodide. Tout ce qui s'affiche passe par des crochets sans effet ici, que les widgets redéfinissent :
``_dire`` (le retour sous la question), ``_montrer_enonce``, ``_montrer_indice``, ``afficher_contexte``, ``montrer``,
``mettre_a_jour`` ; pour un paquet, ``_afficher_page``, ``_defiler``, ``_rafraichir_vue``,
``_confirmer``, ``_montrer_fin`` et ``_devant``. Ce que les crochets reçoivent est aussi gardé en attributs (``dit``,
``contextes_affiches``, ``cachee``, ``numero``), qu'une interface sans widget lit directement.

La saisie de l'élève est rangée dans ``_valeur`` par ``_lire``/``_ecrire`` ; un widget les redéfinit pour la lire
dans ses champs. Voir la docstring de ``modele.py`` pour le format des fichiers.
"""

import ast
import contextlib
import copy
import difflib
import functools
import html
import inspect
import json
import math
import operator
import random
import re
import sys
import time
import traceback
import unicodedata
from fractions import Fraction
from pathlib import Path

import horloge
from adresse import adresser, dire

try:
    import serializejson
except ModuleNotFoundError:
    serializejson = None
    if sys.platform != "emscripten":  # le python3 du système : ni serializejson ni qtpy6 (voir ../CLAUDE.md)
        sys.exit("serializejson introuvable : lancer avec /DATA/Python/SmartPython/CachyOS/versions/SmartPython/bin/python")

ID = re.compile(r"^[a-z0-9_]+(->[a-z0-9_]+)*$")
ACCOLADES = re.compile(r"\{([^{}\n]+)\}")
BAREMES = ("tout_ou_rien", "proportionnel", "penalite", "par_case")
DESTINATIONS = ("papier", "electronique", "tp", "projet")
RANGEMENTS = ("TP", "Révisions", "Mini-Interrogations", "DS", "Projets")  # sous-dossier d'un cours où vont les exports d'un sujet
VERT = "#00b050"  # ce qui est juste : le vert vif des cours (``VERT_REPONSE`` de texte_md ; l'utilisateur, 26/09/2026)
POLICE_MAIN = "Kalam"  # ce que la correction écrit en rouge ou en vert, à la main comme un professeur (27/09/2026)
CLASSES = {}  # nom -> classe, pour un chargeur sans serializejson ; les widgets de modele.py remplacent leur noyau
NOYAU = {}  # nom -> classe de ce module, sans widget (``en_donnees``)
DONNEES = []  # non vide le temps d'un bloc ``en_donnees`` : aucune correction n'y est lancée
@functools.cache
def niveaux_bloom():
    """Les niveaux de ``referentiels/niveaux_bloom.json``, lus au premier bilan (le lecteur web l'embarque, ``construire.py``)."""
    return json.loads((Path(__file__).resolve().parent / "referentiels/niveaux_bloom.json").read_text(encoding="utf-8"))["niveaux"]


def niveau_bloom(verbe):
    """(rang, libellé) du niveau de Bloom que signale le verbe de la consigne, None s'il n'est dans aucun."""
    for rang, niveau in enumerate(niveaux_bloom().values()):
        if verbe in niveau["verbes"]:
            return rang, niveau["libelle"]
    return None


def rangement(tag):
    """Un tag qui range la question sans dire ce qu'elle travaille : année, source, section, forme ou TP (relevé sur les
    banques, 02/10/2026). Le bilan de l'élève ne le montre pas comme un sous-thème : « 2025 : 30 % » ne lui dit rien."""
    return (tag.isdigit() or re.fullmatch(r"tp\d*(_.*)?", tag) is not None
            or tag.lower() in {"bac", "qcm", "bonus", "parsons", "vrai-faux", "cases à cocher", "texte à trous", "cours à trous",
                               "code libre", "code à trous", "code à compléter", "code à corriger", "code à modifier"})


# Les axes du bilan d'une copie (``Paquet.statistiques``, demande de l'utilisateur, 02/10/2026) : ce qu'une question
# relève de chacun, {clé: poids}. Le poids d'une compétence du livret est le sien, les autres comptent 1 ; d'une capacité
# du programme (« thème -> capacité »), seule la capacité est montrée, le thème étant son propre axe.
AXES = [
    ("Thèmes", lambda q: {q.programme: 1} if q.programme else {}),
    ("Sous-thèmes", lambda q: dict.fromkeys([t for t in q.tags if not rangement(t)], 1)),
    ("Compétences", lambda q: dict(q.competences_livret)),
    ("Capacités du programme", lambda q: {c.split("->")[-1].strip(): 1 for c in q.capacites_programme}),
    ("Niveaux de Bloom", lambda q: {n: 1 for n in [niveau_bloom(q.verbe_action)] if n}),
    ("Pensée informatique", lambda q: dict.fromkeys(q.pensee_informatique, 1)),
]
SEUIL_FORT, SEUIL_FAIBLE = 0.75, 0.5  # trois quarts des points au moins : un point fort ; moins de la moitié : à travailler


def ressorts(statistiques, maximum):
    """Les libellés les plus nets du bilan (``Paquet.statistiques``) : (points forts, points à travailler), les mieux
    (ou les moins bien) réussis d'abord, à réussite égale ceux qui portent le plus de points ; un libellé vu sur deux
    axes une seule fois, ``maximum`` de chaque côté."""
    lignes = [(gagne / note, note, libelle) for _, detail in statistiques for libelle, gagne, note in detail]
    forts = [libelle for taux, _, libelle in sorted(lignes, key=lambda l: (-l[0], -l[1])) if taux >= SEUIL_FORT]
    faibles = [libelle for taux, _, libelle in sorted(lignes, key=lambda l: (l[0], -l[1])) if taux < SEUIL_FAIBLE]
    return list(dict.fromkeys(forts))[:maximum], list(dict.fromkeys(faibles))[:maximum]


def suggerer_appreciation(taux, forts, faibles):
    """Une appréciation proposée au professeur depuis le bilan de la copie — jamais écrite d'office : il l'écrit
    lui-même, à la main (demande de l'utilisateur, 04/10/2026, « je veux qu'elle fasse authentique »)."""
    phrases = ["Excellent travail." if taux >= 0.85 else "Très bon travail." if taux >= 0.7 else
               "Un travail correct, mais irrégulier." if taux >= 0.5 else "Un travail encore fragile."]
    if forts:
        phrases.append(f"Points solides : {', '.join(forts)}.")
    if faibles:
        phrases.append(f"À retravailler : {', '.join(faibles)}.")
    return " ".join(phrases)


class Evenement:
    """Les abonnés d'un ``SignalPur`` pour un objet donné, avec l'interface d'un signal Qt."""

    def __init__(self):
        self.abonnes = []

    def connect(self, fonction):
        self.abonnes.append(fonction)

    def emit(self, *args):
        for fonction in list(self.abonnes):
            fonction(*args)


class SignalPur:
    """Un signal Qt sans Qt : ``objet.changee.connect(f)``, ``objet.changee.emit()``."""

    def __set_name__(self, classe, nom):
        self.nom = "_signal_" + nom

    def __get__(self, objet, classe=None):
        if objet is None:
            return self
        if self.nom not in objet.__dict__:
            objet.__dict__[self.nom] = Evenement()
        return objet.__dict__[self.nom]


@functools.cache
def parametres(classe):
    """{nom: défaut} des paramètres d'``__init__`` de la classe et de ses ancêtres (``empty`` : obligatoire)."""
    resultat = {}
    for c in reversed(classe.__mro__):
        if "__init__" in c.__dict__:
            resultat.update({n: p.default for n, p in inspect.signature(c.__init__).parameters.items()
                             if p.kind is p.POSITIONAL_OR_KEYWORD and n != "self"})
    return resultat


@functools.cache
def proprietes(classe):
    """Les paramètres de ``parametres`` que la classe expose en property : cherchés une fois par classe, pas à chaque
    objet sérialisé (3 806 objets copiés à l'ouverture de python_tp, 02/10/2026)."""
    return [nom for nom in parametres(classe) if isinstance(getattr(classe, nom, None), property)]


def _defaut(valeur, defaut):
    return (valeur == defaut or (defaut is None and not valeur and valeur != 0)
            or (isinstance(defaut, tuple) and valeur == list(defaut)))


class Objet:
    """Base de toutes les classes : sérialisation plate, valeurs par défaut omises, ``__init__`` rappelé au chargement."""

    def __init_subclass__(cls, **kw):
        super().__init_subclass__(**kw)
        CLASSES[cls.__name__] = cls
        if cls.__module__ == __name__:
            NOYAU[cls.__name__] = cls
        if serializejson:
            serializejson.constructors[cls.__name__] = cls

    def _ordre(self, etat):
        return etat

    def __serializejson__(self):
        """Les attributs qui sont des paramètres d'``__init__``, puis les paramètres qui sont des properties (la
        ``saisie`` d'une question, lue dans ses widgets) : ni l'un ni l'autre à sa valeur par défaut."""
        classe = type(self)
        defauts = parametres(classe)
        en_c = getattr(serializejson, "etat_sans_defauts", None)  # absente d'un module compilé plus ancien
        if en_c is not None:
            etat = en_c(self, defauts, proprietes(classe))
        else:
            etat = {nom: valeur for nom, valeur in vars(self).items()
                    if nom in defauts and not _defaut(valeur, defauts[nom])}
            for nom in proprietes(classe):
                if nom not in etat:
                    valeur = getattr(self, nom)
                    if not _defaut(valeur, defauts[nom]):
                        etat[nom] = valeur
        return classe.__name__, None, self._ordre(etat)

    def __getattr__(self, nom):
        """Un objet lu sans aucun champ (tout à sa valeur par défaut) n'a pas reçu d'état : serializejson n'appelle
        alors pas ``__setstate__``. Le premier accès à un attribut l'initialise."""
        if nom.startswith("__") or vars(self) or inspect.Parameter.empty in parametres(type(self)).values():
            raise AttributeError(nom)  # des paramètres obligatoires : ce n'est pas un objet sans champ
        self.__init__()
        return getattr(self, nom)

    def __setstate__(self, etat):
        try:
            self.__init__(**etat)
        except TypeError as exc:
            raise TypeError(f"{type(self).__name__} {etat.get('id', etat.get('texte', ''))} : {exc}".replace("  ", " ")) from None


def copier(valeur, remplacer=lambda texte: texte, sauf=(), imposes=None, classes=None):
    """Copie profonde d'un arbre d'objets, sans jamais partager de sous-objet (serializejson écrirait un ``$ref``) ;
    ``remplacer`` transforme chaque chaîne au passage, les champs nommés dans ``sauf`` ne sont pas copiés et ceux de
    ``imposes`` (pour la racine seulement) remplacent les copies. Un objet est reconstruit par son ``__init__`` (un
    widget ne peut pas l'être autrement) à partir de l'état que serializejson écrirait, dans la classe du même nom de
    ``classes`` s'il est donné (``CLASSES`` : l'écran d'un paquet préparé en données, ``en_donnees``)."""
    if isinstance(valeur, str):
        return remplacer(valeur)
    if isinstance(valeur, list):
        return [copier(v, remplacer, sauf, classes=classes) for v in valeur]
    if isinstance(valeur, dict):
        return {k: copier(v, remplacer, sauf, classes=classes) for k, v in valeur.items()}
    if isinstance(valeur, Objet):
        etat = {k: copier(v, remplacer, sauf, classes=classes) for k, v in valeur.__serializejson__()[2].items() if k not in sauf}
        return (classes or {}).get(type(valeur).__name__, type(valeur))(**{**etat, **(imposes or {})})
    return valeur


def accolades(espace, noms):
    """De quoi remplacer, dans un texte, chaque ``{expression}`` qui cite l'un des ``noms`` par sa valeur dans
    ``espace`` ; une autre accolade reste telle quelle : ``{.rouge}`` de Pandoc, dictionnaires du code Python."""
    def remplacer(m):
        try:
            cites = {n.id for n in ast.walk(ast.parse(m.group(1), mode="eval")) if isinstance(n, ast.Name)}
        except SyntaxError:
            return m.group(0)
        return str(eval(m.group(1), espace)) if cites & set(noms) else m.group(0)
    return lambda texte: ACCOLADES.sub(remplacer, texte)


def cite_r(champs):
    """Les champs d'un cas de ``selon`` citent la saisie de la source (``{r…}``) : ils ne s'écrivent qu'avec elle."""
    return bool(re.search(r"\{[^{}\n]*\br\b", repr(champs)))


def _selon(methode):
    """La méthode, appelée sur la ``variante`` de la question quand elle en a une (``Question.__init_subclass__``)."""
    @functools.wraps(methode)
    def aiguillee(self, *args):
        variante = self.variante()
        if variante is self:
            return methode(self, *args)
        variante.saisie = self.saisie  # que lit l'attendu d'une conversion
        return getattr(variante, methode.__name__)(*args)
    return aiguillee


@contextlib.contextmanager
def en_donnees():
    """Le temps du bloc, un objet lu (serializejson) ou rebâti (``CLASSES``) l'est dans sa classe de ce module, sans widget.
    Le lecteur lit et prépare ainsi le sujet (``Paquet.nommer``), puis n'en construit l'écran qu'une fois, sur la copie de
    l'élève (``ecran``) : le sujet lu construisait le sien, jeté aussitôt, et sa préparation
    rebâtissait chaque question jusqu'à trois fois (``version_electronique``, ``instancier``, ``copier``). Mesuré le
    02/10/2026 sur python_tp (218 questions), en natif : 3,6 s → 1,55 s, la copie sérialisée identique."""
    ecran = dict(CLASSES)
    constructeurs = dict(serializejson.constructors) if serializejson else {}
    CLASSES.update(NOYAU)
    if serializejson:
        serializejson.constructors.update(NOYAU)
    DONNEES.append(True)
    try:
        yield
    finally:
        DONNEES.pop()
        CLASSES.update(ecran)
        if serializejson:
            serializejson.constructors.update(constructeurs)


def ecran(objet):
    """L'objet lu en données (``en_donnees``), rebâti dans les classes de l'écran (``CLASSES``) ; tel quel s'il y est déjà."""
    return objet if type(objet) is CLASSES.get(type(objet).__name__, type(objet)) else copier(objet, classes=CLASSES)


LOGO = "logo du thème"  # le visuel du thème dans les médias ; sans extension, hors de portée des médias d'une banque
MEDIAS = {}  # nom -> octets : alimenté par Banque et Paquet (leurs questions sont construites avant eux)


def normaliser(valeur):
    """Casse, accents et espaces multiples ignorés."""
    texte = unicodedata.normalize("NFD", str(valeur).strip().lower())
    return " ".join("".join(c for c in texte if not unicodedata.combining(c)).split())


def nombre(valeur):
    """La valeur d'un texte numérique, ``None`` sinon. Virgule décimale, et un « ≈ », « ~ » ou « environ » devant,
    qu'un élève recopie du corrigé ou d'une consigne, ne changent pas le nombre."""
    try:
        return float(re.sub(r"^(≈|~|environ)\s*", "", str(valeur).strip().replace(",", ".")))
    except ValueError:
        return None


def comparable(valeur):
    """``normaliser``, plus ce qu'un élève tape sans y penser et qui ne change pas sa réponse : apostrophe
    typographique, œ, virgule décimale (« 3,5 »), espaces des milliers (« 1 024 »), ponctuation finale. C'est la
    forme sous laquelle une saisie se compare à une réponse attendue ou à une erreur listée — pas celle d'un nom
    d'élève (``normaliser`` reste la clé des graines et des codes)."""
    texte = normaliser(valeur)
    for a, b in (("’", "'"), ("‘", "'"), ("´", "'"), ("œ", "oe"), ("æ", "ae")):
        texte = texte.replace(a, b)
    if re.fullmatch(r"\d+,\d+", texte):
        texte = texte.replace(",", ".")
    if re.fullmatch(r"\d{1,3}( \d{3})+", texte):
        texte = texte.replace(" ", "")
    return texte.rstrip(" .;:") or texte


def distance(a, b):
    """Distance de Damerau-Levenshtein (alignement optimal) : lettre changée, ajoutée, retirée ou deux voisines
    échangées comptent un."""
    d = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(len(a) + 1):
        d[i][0] = i
    for j in range(len(b) + 1):
        d[0][j] = j
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] != b[j - 1]))
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[-1][-1]


def marge(reponse):
    """Fautes de frappe tolérées sur cette réponse attendue : UNE pour un mot ou une phrase d'au moins cinq
    lettres, sans chiffre ni symbole ni sigle ; AUCUNE sinon. Une valeur, du code, « HTTP » pour « HTTPS » ou
    « pile » pour « file » ne sont pas des coquilles. Deux fautes ne sont jamais tolérées : « croissant » est à deux
    lettres de « décroissant », « possible » d'« impossible » (mesuré sur les banques, 01/10/2026)."""
    n = comparable(reponse)
    if len(n) < 5 or not re.fullmatch(r"[a-z' -]+", n) or sum(c.isupper() for c in str(reponse)) >= 2:
        return 0
    return 1


def lettres(texte):
    """Les lettres d'un texte, casse gardée, sans accents : ce que ``ReponseCourte.casse`` compare en plus."""
    return [c for c in unicodedata.normalize("NFD", str(texte)) if c.isalpha()]


def egal(saisie, reponse):
    return comparable(saisie) == comparable(reponse)


def coquille(saisie, reponses, connus=(), exact=False):
    """La saisie est-elle l'une des ``reponses`` à une faute de frappe près (``marge``) ? Jamais si ``exact`` (la
    question l'exige), si la saisie est vide, ni si une chaîne de ``connus`` — erreurs listées, choix proposés,
    réponses des autres trous de la question — est aussi proche : « aucun » pour « aucune » quand l'autre case
    attend « aucun » n'est pas une coquille, c'est l'autre réponse."""
    s = comparable(saisie)
    if exact or not s:
        return False
    acceptees = {comparable(r) for r in reponses}
    for r in reponses:
        m = marge(r)
        if m and distance(s, comparable(r)) <= m:
            return not any(distance(s, comparable(c)) <= m for c in connus if comparable(c) not in acceptees)
    return False


def indice_de(erreurs, saisie):
    """L'indice de l'erreur reconnue à l'exact dans ``saisie``, à défaut celui de « toute autre erreur »."""
    for e in erreurs:
        if e.reponse is not None and egal(e.reponse, saisie):
            return e.indice
    return next((e.indice for e in erreurs if e.reponse is None and not e.description), None)


def points_txt(p):
    return f"{p:g} point" + ("s" if p >= 2 else "")


def en_capitales(titre):
    """Le titre d'un sujet tel qu'il s'affiche en tête : en capitales, sauf les lignes qu'un retour à la ligne place
    avant la dernière, gardées telles qu'écrites (« Mini évaluation : » / « LES RÉSEAUX SOCIAUX » : demande de
    l'utilisateur, 25/09/2026)."""
    *avant, sujet = titre.split("\n")
    return "\n".join([*avant, sujet.upper()])


def melange(elements, graine):
    """Un ordre tiré d'une graine fixe (deux exports se ressemblent), jamais l'ordre d'origine."""
    elements, tires = list(elements), list(elements)
    alea = random.Random(graine)
    while len(elements) > 1 and tires == elements:
        alea.shuffle(tires)
    return tires


# --- sous-objets d'une question -------------------------------------------------------------------------------

class Proposition(Objet):
    def __init__(self, texte, correcte=False, feedback=""):
        self.texte, self.correcte, self.feedback = texte, correcte, feedback


class Test(Objet):
    """Un test de code : ``appel`` est une expression, ``attendu`` le repr() de sa valeur. En SQL, ``appel`` est une
    requête de CONTRÔLE jouée après celle de l'élève, vide pour juger le résultat de la sienne. En assembleur, deux
    états des registres : ``appel`` celui de départ, ``attendu`` celui de la fin (« r1 = 7, r2 = 5 »)."""

    def __init__(self, appel, attendu, message=""):
        self.appel, self.attendu, self.message = appel, attendu, message


class Mutant(Objet):
    """Une version FAUSSE du code testé (« écrire un test », 1.9 des widgets de bac) : ``code`` redéfinit une fonction
    ou une classe, ``message`` dit le cas que les tests de l'élève oublient, sans montrer la variante. Les ``assert`` de
    l'élève doivent passer sur la vraie version et échouer sur celle-ci (``verifier.mutant_survit``)."""

    def __init__(self, code, message=""):
        self.code, self.message = code, message


class Rectangle(Objet):
    """Zone rectangulaire d'une image, en pixels."""

    def __init__(self, x, y, largeur, hauteur):
        self.x, self.y, self.largeur, self.hauteur = x, y, largeur, hauteur

    def decrire(self):
        return f"rectangle {self.x}, {self.y}, {self.largeur}, {self.hauteur}"

    def contient(self, x, y):
        return self.x <= x <= self.x + self.largeur and self.y <= y <= self.y + self.hauteur

    def centre(self):
        return [self.x + self.largeur // 2, self.y + self.hauteur // 2]


class Cercle(Objet):
    def __init__(self, x, y, rayon):
        self.x, self.y, self.rayon = x, y, rayon

    def decrire(self):
        return f"cercle {self.x}, {self.y}, {self.rayon}"

    def contient(self, x, y):
        return (x - self.x) ** 2 + (y - self.y) ** 2 <= self.rayon ** 2

    def centre(self):
        return [self.x, self.y]


class Paire(Objet):
    def __init__(self, gauche, droite):
        self.gauche, self.droite = gauche, droite


class Element(Objet):
    """Un élément à classer, avec la catégorie où il va."""

    def __init__(self, texte, categorie):
        self.texte, self.categorie = texte, categorie


class Erreur(Objet):
    """Une erreur attendue et son indice : ``reponse`` reconnue par ``egal`` (et préférée à une coquille), ``description`` rapprochée par un LLM ;
    ni l'une ni l'autre : « toute autre erreur »."""

    def __init__(self, indice, reponse=None, description=""):
        self.indice, self.reponse, self.description = indice, reponse, description


class Indice(Objet):
    def __init__(self, texte, delai=0, malus=0):
        self.texte, self.delai, self.malus = texte, delai, malus


class Justification(Objet):
    def __init__(self, points, consigne="Justifier votre réponse."):
        self.points, self.consigne = points, consigne


class SecondeChance(Objet):
    """Un second essai après une erreur, avec l'indice lié à l'erreur, moyennant ``malus`` (fraction des points)."""

    def __init__(self, malus=0, actif=True):
        self.malus, self.actif = malus, actif


class Trou(Objet):
    """Un trou de texte : ``reponses`` absent = correction manuelle ; ``choix`` présent = liste déroulante ; ``exact``
    refuse la faute de frappe que ``coquille`` tolère sinon (un mot-clé du langage, une valeur à recopier) ; ``base`` : un
    nombre que l'élève peut suivre de sa base (« 0101₂ », « 0101_2 », « 0101(2) »), une autre base le rendant faux ; en
    base 2, ses chiffres s'espacent pour se lire (l'utilisateur, 03/10/2026, table de correspondances du cours) ;
    ``comparaison`` lit saisie et réponses comme des valeurs Python, comme celle d'une ``ReponseCourte`` (« formule »
    exceptée) : une case qui attend une liste, en ordre libre avec « ensemble » (1.7 des widgets de bac)."""

    def __init__(self, reponses=None, choix=None, erreurs=None, exact=False, comparaison="texte", base=None):
        self.reponses, self.choix, self.erreurs, self.exact = reponses, choix, erreurs or [], exact
        self.comparaison, self.base = comparaison, base


class Rapport(Objet):
    """Deux cases MESURÉES d'un tableau (un temps, un compteur) qu'aucune valeur « vraie » ne peut corriger, mais dont
    le QUOTIENT, lui, est connu : « temps pour n = 2000 » sur « temps pour n = 1000 » vaut 2 pour une boucle simple, 4
    pour deux boucles imbriquées, 1 pour des divisions par 2 (idée de l'utilisateur, 02/10/2026). ``cases`` =
    [numérateur, dénominateur] ; ``attendu`` ± ``tolerance`` (un quart d'``attendu`` à défaut) juge les deux mesures
    ENSEMBLE, en une note ; ``resultat`` = la case où l'élève écrit le rapport, jugée sur SES propres mesures, au nombre
    de décimales qu'il a écrites (« 2 » comme « 2,03 » pour 2,0312…)."""

    def __init__(self, cases, attendu=None, tolerance=None, resultat=None):
        self.cases, self.attendu, self.tolerance, self.resultat = cases, attendu, tolerance, resultat

    def jugees(self):
        """Les cases que ce rapport corrige à la place du professeur."""
        return set(self.cases if self.attendu is not None else []) | ({self.resultat} if self.resultat else set())

    def accepte(self, q):
        """Le quotient ``q`` des deux mesures est-il ``attendu``, à ``tolerance`` près ?"""
        return q is not None and abs(q - self.attendu) <= (self.attendu / 4 if self.tolerance is None else self.tolerance)


class Sommet(Objet):
    """Un sommet d'une question ``dessin``, nommé et placé (en pixels) par le professeur ; l'élève n'y touche pas.
    ``marque`` : ``"initial"`` ou ``"final"``, les deux états particuliers d'un automate. ``texte`` : ce qui s'affiche,
    quand plusieurs sommets portent le même (les feuilles « + » d'un arbre de décision) ; le ``nom`` reste unique."""

    def __init__(self, nom, x=0, y=0, marque="", texte=""):  # x, y : sans objet en mode « arbre », qui dispose lui-même
        self.nom, self.x, self.y, self.marque, self.texte = nom, x, y, marque, texte

    def libelle(self):
        return str(self.texte or self.nom)


class Arete(Objet):
    """Une arête attendue : « g »/« d » pour un arbre binaire, une lettre pour un automate, un poids pour un graphe
    pondéré, rien pour un graphe nu."""

    def __init__(self, source, cible, etiquette=""):
        self.source, self.cible, self.etiquette = source, cible, etiquette


class Reference(Objet):
    """Une question d'une section de sujet dont les points remplacent ceux de la banque (sinon : simple chaîne)."""

    def __init__(self, id, points):
        self.id, self.points = id, points


# --- questions ------------------------------------------------------------------------------------------------

DUREE_PAR_DIFFICULTE = {None: 45, 1: 45, 2: 90, 3: 150}  # secondes, faute de ``duree`` mesurée ; calées pour que les
# sujets déjà donnés tiennent dans leur durée (SNT réseaux sociaux : 10 questions, 10 min), à remplacer par les mesures


class Question(Objet):
    """Les champs communs à tous les types ; ``type`` (attribut de classe) est le nom historique du type.

    Chaque type définit ``juste`` (la saisie juste), ``corriger`` (``(fraction des points ou None, indice)``) et
    ``_attendu`` (la correction en Markdown) ; son widget, dans modele.py, ``_corps`` et ``_lire``/``_ecrire``.
    Les champs de session — ``saisie``, ``justifie``, ``ouverte`` (début), ``presence`` (secondes passées dessus, qui font courir le délai des indices), ``debloques``
    (indices découverts), ``aidee`` (aide affichée), ``reformulee`` (énoncé reformulé affiché), ``seconde`` (seconde chance accordée), ``fermee`` (validée, ``obtenu`` = points gagnés, ``None`` si
    elle attend le professeur), ``cochees`` (dans un projet, les actions de l'énoncé cochées, par rang) — sont
    enregistrés avec la question. ``graine`` est posée par ``instancier``."""

    type = ""
    sous_questions = ()  # ne change que pour un Groupe
    classe = ""  # posée par le paquet qui contient la question : elle fixe ce que le programme de l'élève peut employer
    autorises = None  # liste blanche propre à la question, qui remplace celle de la classe (champ de ``Code``)
    editeur_externe, reprend, suite_de = False, (), ""  # champs de ``Code``, que le paquet lit sur toutes ses feuilles
    projet = False  # posée par le paquet : dans un projet, les actions de l'énoncé se cochent et ses blocs de code se copient
    changee = SignalPur()  # la question a changé d'état (soumise, validée, figée) : à enregistrer
    dit = ("", "")  # le dernier retour affiché sous la question : (Markdown, couleur)
    numero = None
    cachee = False  # masquée par le paquet (``revele``, sous-questions l'une après l'autre)
    retenue = False  # posée par le paquet (``Paquet.retenir``) : ni « Soumettre » ni Entrée, le mode de soumission l'interdit
    source = None  # posée par le paquet : la question que cite ``selon``

    def __init_subclass__(cls, **kw):
        """``juste``, ``corriger`` et ``_attendu`` passent par la ``variante`` de la question, partout où on les appelle."""
        super().__init_subclass__(**kw)
        for nom in ("juste", "corriger", "_attendu"):
            if nom in vars(cls):
                setattr(cls, nom, _selon(vars(cls)[nom]))

    def __init__(self, id, enonce, points=1, difficulte=None, tags=None, programme="", fiche="", competences_livret=None,
                 capacites_programme=None, pensee_informatique=None, verbe_action="", contexte="", explication="",
                 explication_fausse="", enonce_simplifie="", aide="", aide_cours="", masque_cours="", zone_cours=None, necessite_ordinateur=False, couleur_obligatoire=False, copiable=False, epinglable=False, duree=None, usage="", electronique=None, revele=None, selon=None, indices=None, variables=None, justification=None,
                 seconde_chance=None, graine=None, saisie=None, justifie="", ouverte=None, presence=0, debloques=0, seconde=False,
                 fermee=False, obtenu=None, repondue=False, reformulee=False, aidee=False, cochees=None, horodatage=None,
                 remarque="", justification_obtenue=None, verrouillee=False, signalements=None):
        self.id, self.enonce, self.points, self.difficulte = id, enonce, points, difficulte
        self.tags, self.programme, self.fiche = tags or [], programme, fiche
        self.competences_livret, self.capacites_programme = competences_livret or {}, capacites_programme or []
        self.pensee_informatique, self.verbe_action = pensee_informatique or [], verbe_action
        self.contexte, self.explication, self.necessite_ordinateur = contexte, explication, necessite_ordinateur
        self.explication_fausse, self.copiable, self.couleur_obligatoire = explication_fausse, copiable, couleur_obligatoire
        self.epinglable = epinglable  # elle sert aux suivantes : l'élève peut l'épingler (``afficher_contextes``)
        self.sert_aux_suivantes = epinglable  # ``epingler_possible``
        self.duree = duree  # secondes pour y répondre, estimées ; absente : ``DUREE_PAR_DIFFICULTE``
        # le nom (sans extension) du cours qui en donne la réponse, et où : [page (1 = la première), x0, y0, x1, y1] en points
        # depuis le haut gauche ; un sujet ``acces_cours`` qui le joint montre cette zone en pavés tant qu'elle n'est pas
        # close (``Sujet.cours_masques``, ``Paquet.masques_cours``)
        self.masque_cours, self.zone_cours = masque_cours, zone_cours
        self.usage = usage  # "formatif", "sommatif", ou "" : les deux
        self.electronique = electronique  # ce que le .qcm en change : voir ``version_electronique``
        self.revele, self.indices, self.variables = revele or [], indices or [], variables or {}
        # la réponse attendue dépend de la saisie d'une autre question : {"question": id, "cas": [{"si": expression de r,
        # "libelle": …, <champs de correction remplacés>}, …]} (``variante``)
        self.selon = selon
        self.justification, self.seconde_chance, self.graine = justification, seconde_chance, graine
        self.ouverte, self.presence, self.debloques, self.seconde, self.fermee, self.obtenu = ouverte, presence, debloques, seconde, fermee, obtenu
        self.repondue, self.enonce_simplifie, self.reformulee = repondue, enonce_simplifie, reformulee
        self.aide, self.aide_cours, self.aidee, self.cochees = aide, aide_cours, aidee, cochees or []  # aide_cours : la variante quand le cours est sous la main, retenue par un sujet ``acces_cours``
        self._depart, self._justifie_depart = saisie, justifie
        self.actif, self.modifiable = False, True
        self.contextes_affiches = []
        self.contextes_connus = {}  # nom -> markdown de chaque texte partagé cité, affiché ou non (``afficher_contextes``)
        self.horodatage = horodatage or []  # instants (time.time()) où l'élève a validé ou soumis : de quoi mesurer ``duree``
        # posés par la correction différée (``noter``) : le commentaire du correcteur, que l'élève lit sous la correction,
        # et les points de la justification, à part de ``obtenu`` comme ils sont à part de ``points``
        self.remarque, self.justification_obtenue = remarque, justification_obtenue
        # le cadenas de l'élève : la question traitée et sa saisie figée contre une fausse manœuvre (``verrouiller``)
        self.verrouillee = verrouillee
        # ce que l'élève a écrit au professeur depuis la question (``signaler``) : {"sorte", "texte", "instant"}
        self.signalements = signalements or []

    def version_electronique(self, sans_ide=False):
        """La question telle que la pose le .qcm, quand elle diffère du papier (un TP où l'élève travaille dans son
        éditeur devient une question ``code`` dans l'éditeur du lecteur) : ``electronique`` vaut ``False`` (question
        absente du .qcm) ou un dict de champs qui remplacent les siens, ``classe`` (« Code », « ReponseOuverte »…)
        changeant le type ; les champs non remplacés sont repris quand la classe les connaît. Un TP qui a deux .qcm,
        « avec IDE » et « sans IDE », range dans ce dict une clé ``sans_ide`` : la variante (dict, ``False`` ou ``None``)
        du second, tout entier dans le lecteur, que prend un sujet à ``sans_ide``."""
        variante = self.electronique
        if sans_ide and isinstance(variante, dict) and "sans_ide" in variante:
            variante = variante["sans_ide"]
        if variante is None:
            return self
        if variante is False:
            return None
        variante = {k: v for k, v in variante.items() if k != "sans_ide"}
        classe = CLASSES[variante.pop("classe", type(self).__name__)]
        champs = parametres(classe)
        etat = {k: v for k, v in self.__serializejson__()[2].items() if k in champs and k != "electronique"}
        return classe(**copier({**etat, **variante}))

    def duree_estimee(self):
        """Secondes pour y répondre : ``duree`` si elle est posée, sinon la somme des sous-questions d'un groupe, sinon
        le forfait de sa difficulté."""
        if self.duree is None and self.sous_questions:
            return sum(sq.duree_estimee() for sq in self.sous_questions)
        return self.duree or DUREE_PAR_DIFFICULTE[self.difficulte]

    # -- affichage (crochets : les widgets de modele.py les redéfinissent)

    def reperer(self, marque):
        """Le repère de la sous-question (« a. ») en tête de son énoncé, sur la MÊME ligne : seul sur sa ligne,
        il s'éloigne de la consigne qu'il numérote. N'écrit pas dans ``enonce``, qui est la donnée enregistrée."""
        self.marque = marque
        self._montrer_enonce()

    marque = ""

    def _montrer_enonce(self):
        """L'énoncé, ou sa reformulation quand l'élève l'a demandée, derrière le repère de sous-question."""

    def reformuler(self):
        """Bascule entre l'énoncé et sa reformulation ; ``reformulee`` est enregistré avec la copie. Offert à toute la
        classe, sans malus : une aide à la lecture, qui ne change pas ce qui est évalué."""
        self.reformulee = not self.reformulee
        self._montrer_enonce()
        self.changee.emit()

    def numeroter(self, numero=None):
        """« Question n°x » au-dessus de l'énoncé."""
        self.numero = numero

    def _construire(self):
        """À la fin du ``__init__`` de chaque type, ses champs posés : la saisie et l'état de session relus."""
        self._valeur = None
        if self.sous_questions:
            return
        if self._depart is not None:
            self._ecrire(self._depart)
        self.justifie = self._justifie_depart
        if self.aidee:
            self._montrer_indice("**Aide** : " + self.aide)
        for i in self.indices[:self.debloques]:
            self._montrer_indice("**Indice** : " + i.texte)
        if self.fermee:
            self._dire("Réponse enregistrée.")
        elif self.seconde:
            self._reprendre_seconde()
        self.mettre_a_jour()

    def _reprendre_seconde(self):
        """Une copie rouverte pendant sa seconde chance."""
        self._dire("Seconde chance : " + (self._indiquer(self.corriger(self.saisie)[1]) or ""))

    def _indiquer(self, indice):
        """L'indication de la seconde chance, dite sous la question ; un lecteur qui l'écrit ailleurs la rend vide."""
        return indice

    def afficher_contexte(self, markdown):
        """Sous « Question n°x », jamais au-dessus : hors du bloc numéroté, un texte partagé se lit comme la fin de
        la question PRÉCÉDENTE (QCM Algorithmique, questions 99, 126 et 132)."""
        self.contextes_affiches.insert(0, markdown)

    def epingler_possible(self, oui):
        """L'épinglage n'est proposé que pour une question qui sert aux suivantes (l'utilisateur, 04/10/2026) : elle
        affiche un texte partagé qu'une suivante cite sans le répéter, ou elle porte ``epinglable``."""
        self.sert_aux_suivantes = oui

    def contextes_cites(self):
        """Les textes partagés que la question ouvre, dans l'ordre de lecture : ``contexte`` est un nom, ou
        plusieurs quand la question ajoute son introduction propre à une figure déjà citée par ses voisines."""
        if not self.contexte:
            return []
        return [self.contexte] if isinstance(self.contexte, str) else list(self.contexte)

    sans_execution = False  # posé par le paquet : voir DefinitionSujet

    _trou_corrige = None  # pour un texte à trous : comment écrire un trou dans la correction

    def _dire(self, markdown, couleur=""):
        self.dit = (markdown, couleur)

    def _montrer_indice(self, markdown, tete=False):
        """Une aide (``tete`` : en premier) ou un indice découvert, sous la question."""

    def mettre_a_jour(self):
        """Ce qui est actif, visible et écrit sur les boutons, selon l'état de la question."""

    def montrer(self, visible):
        self.cachee = not visible

    def feuilles(self):
        """Les questions à noter : elle-même, ou les sous-questions d'un groupe."""
        return [self]

    def revelations(self):
        """Les questions dont celle-ci montre la réponse : ``revele``, plus celles qu'un code ``reprend`` ou dont son
        prélude exécute la solution."""
        return self.revele

    def solutions_citees(self):
        return []  # ``Code`` : les questions dont son prélude exécute la solution

    def total(self):
        """Justification comprise : elle est notée en plus de la réponse, et à la main."""
        return self.points + (self.justification.points if self.justification else 0)

    # -- la saisie de l'élève

    @property
    def saisie(self):
        return None if self.sous_questions else self._lire()

    @saisie.setter
    def saisie(self, valeur):
        if not self.sous_questions:
            self._ecrire(valeur)

    def _lire(self):
        return self._valeur

    def _ecrire(self, valeur):
        self._valeur = valeur

    @property
    def justifie(self):
        return self._justifie if self.justification else ""

    @justifie.setter
    def justifie(self, texte):
        self._justifie = texte

    def chance(self):
        return self.seconde_chance if self.seconde_chance and self.seconde_chance.actif else None

    devinable = False  # la réponse se choisit parmi des options données : le hasard y rapporte
    MALUS_DEVINABLE = 0.5

    def reponse_forcee(self):
        """Après une erreur, il ne reste qu'une réponse possible : une seconde chance la donnerait."""
        return False

    def adapter_chance(self, chance):
        """La seconde chance du SUJET, ajustée au hasard : aucune là où elle donnerait la réponse (Vrai/Faux), au
        moins −50 % là où l'on choisit parmi des options (à −25 %, répondre au hasard y devient rentable), telle quelle là
        où la réponse se saisit. Une ``seconde_chance`` écrite sur la question elle-même n'y passe pas."""
        if not chance or not chance.actif or not self.devinable:
            return chance
        return SecondeChance(actif=False) if self.reponse_forcee() else SecondeChance(max(chance.malus, self.MALUS_DEVINABLE))

    def garder_une_aide(self, acces_cours):
        """Le sujet dit si les élèves ont le cours : une seule aide reste, l'``aide_cours`` s'ils l'ont (à défaut l'aide)."""
        self.aide, self.aide_cours = (self.aide_cours or self.aide) if acces_cours else self.aide, ""

    def indice_delai(self):
        """Secondes avant le prochain indice (0 : déblocable), ou ``None`` s'il n'y en a plus."""
        if self.debloques >= len(self.indices):
            return None
        return max(0, self.indices[self.debloques].delai - self.presence) \
            if self.indices[self.debloques].delai else 0

    def demarrer(self):
        """La question est posée : ses champs deviennent modifiables."""
        if self.sous_questions or self.actif:
            return
        self.actif = True
        if self.ouverte is None:
            self.ouverte = time.time()
        self.mettre_a_jour()

    def figer(self):
        """Plus aucune modification, sans changer l'état de la question."""
        for f in self.feuilles():
            f.actif = False
            f.mettre_a_jour()

    def aider(self):
        """L'aide, gratuite et offerte à tous : une piste pour démarrer (méthode, rappel de cours), jamais la réponse ;
        ``aidee`` est enregistré avec la copie."""
        if self.aide and not self.aidee:
            self.aidee = True
            self._montrer_indice("**Aide** : " + self.aide, tete=True)
            self.mettre_a_jour()
            self.changee.emit()

    def debloquer(self):
        if self.indice_delai() == 0:
            self._montrer_indice("**Indice** : " + self.indices[self.debloques].texte)
            self.debloques += 1
            self.mettre_a_jour()
            self.changee.emit()

    def complete(self):
        """La réponse est entière : quelque chose de saisi, et aucune case laissée vide dans une liste (classement,
        appariement)."""
        saisie = self.saisie
        return saisie is not None and not (isinstance(saisie, list) and None in saisie)

    def quitter(self):
        """L'élève passe à une autre question : celle-ci devient « traitée » si sa réponse est entière (``complete``),
        sans bouton ni correction ; revenue incomplète, elle ne l'est plus. La navigation « Non traitée » la saute alors
        (demande de l'utilisateur, 28/09/2026 : le bouton « Marquer comme traitée » déduit de l'activité de l'élève)."""
        traitee = self.actif and not self.fermee and (self.verrouillee or self.complete())
        if traitee != self.repondue:
            self.repondue = traitee
            self.horodatage.append(round(time.time(), 1))
            self.mettre_a_jour()
            self.changee.emit()

    def verrouiller(self, verrouillee=None):
        """Le cadenas (demande de l'utilisateur, 03/10/2026) : fermé, la question est traitée, en plus de ``quitter``, et sa
        saisie ne se modifie plus ; rouvert, elle redevient traitée selon sa réponse."""
        self.verrouillee = not self.verrouillee if verrouillee is None else verrouillee
        self.repondue = self.actif and not self.fermee and (self.verrouillee or self.complete())
        self.horodatage.append(round(time.time(), 1))
        self.mettre_a_jour()
        self.changee.emit()

    SIGNALEMENTS = {"bug": "Signaler un problème", "idee": "Proposer une amélioration",
                    "question": "Poser une question au professeur"}

    def signaler(self, sorte, texte):
        """Un message de l'élève au professeur sur cette question (``SIGNALEMENTS``), gardé dans la copie : son envoi
        sera branché plus tard (demande de l'utilisateur, 03/10/2026)."""
        if texte.strip():
            self.signalements.append({"sorte": sorte, "texte": texte.strip(), "instant": round(time.time(), 1)})
            self.changee.emit()

    def soumettre(self):
        """Corrige la réponse : une seconde chance si elle est fausse et permise, sinon la question est close. ``retenue``
        n'y est pas regardée : elle cache « Soumettre » et coupe Entrée, pas « Corriger mes réponses » qui passe par ici."""
        if self.fermee or not self.actif:
            return
        fraction, indice = self.corriger(self.saisie)
        self.horodatage.append(round(time.time(), 1))
        chance = self.chance()
        if chance and not self.seconde and fraction is not None and fraction < 1:
            self.seconde = True
            # les points encore à gagner, pas ceux perdus (demande de l'utilisateur, 28/09/2026)
            prix = f", pour {points_txt(round(self.points * max(0, 1 - self.malus()), 2))}" if self.points else ""
            # en rouge comme une correction, la seconde chance en vert (demandes de l'utilisateur, 26/09/2026)
            self._dire(f"**Ce n'est pas la bonne réponse.** {self._indiquer(indice) or ''}\n\n"
                       f'<span style="color:{VERT}">{dire("Vous pouvez réessayer")}{prix}.</span>', "#c0392b")
        else:
            self._clore(fraction)
            # sans console, l'élève découvre l'erreur de son programme ici : brute tant qu'il peut réessayer, expliquée ensuite
            self._dire("\n\n".join(filter(None, ["Réponse enregistrée.", self.sans_execution and self._diagnostic()])))
        self.mettre_a_jour()
        self.changee.emit()

    def geler(self):
        """Fige la réponse telle qu'elle est, sans seconde chance (la question est révélée, ou l'épreuve finie)."""
        if not self.fermee:
            self._clore(self.corriger(self.saisie)[0])
            self.mettre_a_jour()
            self.changee.emit()

    def malus(self):
        """La fraction des points retirée par les indices débloqués et la seconde chance jouée."""
        return sum(i.malus for i in self.indices[:self.debloques]) + (self.chance().malus if self.seconde and self.chance() else 0)

    def _clore(self, fraction):
        self.obtenu = None if fraction is None else round(self.points * max(0, fraction - self.malus()), 2)
        self.fermee = True

    def rouvrir(self):
        """Revenir sur une réponse validée (``retour``), sauf si la seconde chance a été jouée."""
        if self.fermee and not self.seconde and self.modifiable:
            self.fermee, self.obtenu = False, None
            self._dire("")
            self.mettre_a_jour()
            self.changee.emit()

    def noter(self, fraction=None, remarque=None, trou=None, justification=False):
        """La fraction retenue par le professeur pour ce que la machine n'a pas su noter (correction différée) : posée
        sur la feuille, qui recalcule ``obtenu`` par sa propre règle (``_clore`` : le malus une seule fois ; un trou
        refait la moyenne de tous les trous). Rejouable : la même fusion redonne le même état."""
        if justification:
            self.justification_obtenue = round(self.justification.points * fraction, 2)
        elif trou is not None:
            self.retenus[str(trou)] = fraction  # les clés de ``trous`` sont des chaînes
            self._clore(self.corriger(self.saisie)[0])
        else:
            self._clore(fraction)
        if remarque:
            ligne = ("Justification : " if justification else f"Trou {trou} : " if trou is not None else "") + remarque
            if ligne not in self.remarque.split("\n"):
                self.remarque = "\n".join(filter(None, [self.remarque, ligne]))

    # -- la correction

    def juste(self):
        """La saisie juste."""
        raise NotImplementedError

    def corriger(self, saisie):
        """``(fraction des points, indice)`` : fraction ``None`` si la réponse n'est pas corrigeable par la machine."""
        raise NotImplementedError

    def _attendu(self):
        return ""

    def montrer_correction(self, couleur=""):
        """La correction (réponse attendue, remarques, explication) sous la question, de la ``couleur`` donnée ; la saisie de l'élève reste."""
        for f in self.feuilles():
            attendu = f._attendu()
            f._dire("\n\n".join(filter(None, [f._diagnostic(), f"**Correction**\n\n{attendu}" if attendu else "",
                                                f.explication if f.EXPLICATION_CORRIGEE else "",
                                                f.explication_fausse,
                                                f._bareme(),  # après la correction, jamais au premier essai (04/10/2026)
                                                # un paragraphe par item : un simple \n se lirait en espace
                                                "**Remarque du correcteur**\n\n" + f.remarque.replace("\n", "\n\n")
                                                if f.remarque else ""])), couleur)

    EXPLICATION_CORRIGEE = True  # l'explication sous la correction ; non quand la correction la contient déjà

    def _diagnostic(self):
        """Dans la correction seulement : ce que la saisie a de faux, au-delà de la réponse attendue."""
        return ""

    def _bareme(self):
        """Dans la correction seulement, après elle : le barème détaillé quand des points manquent. Pas au premier essai
        d'une question qui en a un second (l'utilisateur, 04/10/2026 : « le barème doit apparaître après la correction ;
        il ne doit pas apparaître dès le premier essai s'il y en a un deuxième »)."""
        return ""

    def confirmer(self):
        """Bonne réponse : une confirmation en vert, avec l'explication s'il y en a une."""
        self._dire("\n\n".join(filter(None, ["**Bonne réponse !**", self.explication])), VERT)

    def presenter_corrige(self):
        """Comme dans une banque : la bonne réponse saisie, la correction dessous, plus rien de modifiable."""
        self.saisie = self.juste()
        self.montrer_correction("#c0392b")
        self.figer()

    # -- fabrication

    def instancier(self, graine, heritees=None, points=None):
        """La question avec ses ``variables`` tirées de la graine, ses ``{expressions}`` remplacées dans tous ses textes
        (sous-questions comprises, qui héritent des variables du groupe), sa ``graine`` propre pour les mélanges et, si
        ``points`` est donné, ces points (un groupe n'en a pas : c'est la somme de ses sous-questions).
        Une accolade dont le contenu n'est pas une expression citant une variable est laissée telle quelle : ``{.rouge}``
        de Pandoc, dictionnaires du code Python."""
        espace, valeurs = self.tirer(graine, heritees)
        imposes = {"graine": graine}
        if self.sous_questions:
            imposes["sous_questions"] = [sq.instancier(f"{graine}|{sq.id}", valeurs) for sq in self.sous_questions]
        elif points is not None:
            imposes["points"] = points
        return copier(self, accolades(espace, valeurs), sauf=("sous_questions", "saisie"), imposes=imposes)

    def tirer(self, graine, heritees=None):
        """``(espace, valeurs)`` : les ``variables`` tirées de la graine (``valeurs``, celles du groupe ``heritees`` comprises),
        et l'espace où s'évaluent les ``{expressions}`` des textes, fonctions du tirage et variables. Une même graine rend les
        mêmes valeurs : ``Conversion.nombre_bis`` en retire d'autres, dans les mêmes bornes."""
        alea = random.Random(graine)
        espace = {"randint": alea.randint, "randrange": alea.randrange, "uniform": alea.uniform, "choice": alea.choice,
                  "sample": alea.sample, "melange": lambda elements: alea.sample(list(elements), len(elements))}
        valeurs = dict(heritees or {})
        for nom, expression in self.variables.items():
            valeurs[nom] = eval(expression, {**espace, **valeurs})
        espace.update(valeurs)
        return espace, valeurs

    def variante(self, r=None):
        """La question telle qu'on la corrige, d'après la saisie ``r`` de la question que cite ``selon`` (sa ``source``
        par défaut) : ses champs remplacés par ceux du premier cas dont l'expression ``si`` est vraie, les ``{…}`` qui
        citent ``r`` évalués. Elle-même sans ``selon``, sans réponse à la source, si aucun cas n'est vrai ou si un cas
        lève une exception : la correction écrite vaut alors. Une variante par saisie de la source, gardée (le cache
        des verdicts d'un code va avec)."""
        if not self.selon:
            return self
        if r is None:
            r = self.source.saisie if self.source else None
            if r is None:
                return self
        variantes = vars(self).setdefault("_variantes", {})
        cle = repr(r)
        if cle not in variantes:
            variantes[cle] = self
            try:
                cas = next((c for c in self.selon["cas"] if eval(c["si"], {"r": r})), None)
                if cas:
                    remplacer = accolades({"r": r}, ["r"])
                    champs = {k: copier(v, remplacer) for k, v in cas.items() if k not in ("si", "libelle")}
                    variantes[cle] = self._avec(champs)
            except Exception:
                pass
        return variantes[cle]

    def _avec(self, champs):
        """Une copie en données de la question, ces champs de correction remplacés : la variante d'un cas de ``selon``."""
        return copier(self, sauf=("saisie",), imposes={**champs, "selon": None}, classes=NOYAU)

    def problemes(self):
        """[(niveau, message)] : ce que la classe ne peut pas empêcher (niveau « erreur » ou « avert »)."""
        p = []
        for sans_ide in (False, True) if self.electronique not in (None, False) else ():
            try:
                variante = self.version_electronique(sans_ide)
            except (KeyError, TypeError) as exc:
                p.append(("erreur", f"electronique : {exc}"))
            else:
                p += [(niveau, "electronique : " + message) for niveau, message in variante.problemes()] if variante else []
        if not ID.match(self.id):
            p.append(("erreur", f"identifiant « {self.id} » : minuscules, chiffres et _, mots séparés par ->"))
        if not self.enonce:
            p.append(("erreur", "énoncé vide"))
        if (self.aide or self.aide_cours) and self.sous_questions:
            p.append(("erreur", "aide : un groupe n'a pas de bouton « Aide », la mettre sur ses sous-questions"))
        if self.aide_cours and not self.aide:
            p.append(("avert", "aide_cours sans aide : un sujet sans acces_cours n'aura pas d'aide du tout"))
        if self.enonce_simplifie and self.enonce_simplifie.split() == self.enonce.split():
            p.append(("avert", "enonce_simplifie : identique à l'énoncé, le bouton « Reformuler » n'y changerait rien"))
        if not self.points > 0:
            p.append(("erreur", "points : strictement positifs"))
        if self.difficulte not in (None, 1, 2, 3):
            p.append(("erreur", "difficulte : 1, 2 ou 3"))
        if self.duree is not None and not self.duree > 0:
            p.append(("erreur", "duree : secondes, strictement positive"))
        if self.id in self.revele:
            p.append(("erreur", "révèle sa propre réponse"))
        if self.selon:
            p += self._problemes_selon()
        if len(set(self.revele)) != len(self.revele):
            p.append(("erreur", "revele : identifiants en double"))
        if any(a.delai > b.delai for a, b in zip(self.indices, self.indices[1:])):
            p.append(("erreur", "indices : les délais doivent aller croissant"))
        if sum(i.malus for i in self.indices) > 1:
            p.append(("erreur", "indices : la somme des malus dépasse 1 (tous les points)"))
        if self.chance() and self.reponse_forcee():
            p.append(("avert", "seconde_chance : après une erreur il ne reste qu'une réponse, le second essai la donne"))
        if len(self.indices) > 1 or any(i.malus != 0.5 or i.delai < 30 for i in self.indices):  # convention, pas une impossibilité
            p.append(("avert", "indices : la convention est un seul indice, à −50 % (malus 0.5) après au moins 30 secondes "
                               "(delai 30) ; ce qui aide sans donner la réponse va dans aide, gratuite"))
        for ou, reponses, erreurs in [("", getattr(self, "reponses", None), getattr(self, "erreurs", []))] + [
                (f"trou {n}, ", trou.reponses, trou.erreurs) for n, trou in getattr(self, "trous", {}).items()]:
            attendues = {str(r).strip().lower() for r in reponses or []}
            for e in erreurs:
                if e.reponse is not None and str(e.reponse).strip().lower() in attendues:
                    p.append(("erreur", f"{ou}erreur « {e.reponse} » qui est une réponse acceptée"))
                if e.reponse is not None and self.type in ("reponse_ouverte", "code"):
                    p.append(("erreur", f"erreur « {e.reponse} » : pas de réponse exacte pour ce type, utiliser description"))
            if sum(e.reponse is None and not e.description for e in erreurs) > 1:
                p.append(("erreur", f"{ou}plusieurs erreurs sans reponse ni description (une seule « toute autre erreur »)"))
        return p

    def _problemes_selon(self):
        """Ce qui se voit sur la question seule : la source est vérifiée par ``valider.py``, qui voit la banque."""
        if self.sous_questions:
            return [("erreur", "selon : sur chaque sous-question, pas sur le groupe")]
        if self.selon.get("question") in (None, self.id):
            return [("erreur", "selon : « question » doit citer une autre question")]
        p, champs = [], parametres(type(self))
        for n, cas in enumerate(self.selon.get("cas") or [None], 1):
            if not isinstance(cas, dict) or "si" not in cas:
                p.append(("erreur", f"selon, cas {n} : un dict avec « si », l'expression de r qui le choisit"))
                continue
            try:
                compile(cas["si"], "<selon>", "eval")
            except SyntaxError as exc:
                p.append(("erreur", f"selon, cas {n} : « {cas['si']} » n'est pas une expression ({exc.msg})"))
            remplaces = {k: v for k, v in cas.items() if k not in ("si", "libelle")}
            if inconnus := remplaces.keys() - champs.keys():
                p.append(("erreur", f"selon, cas {n} : {', '.join(sorted(inconnus))}, pas un champ de {self.type}"))
            elif not cite_r(remplaces):  # sinon la juste de la source en décide (valider.py)
                variante = self._avec(remplaces)
                p += [(niveau, f"selon, cas {n} : {message}") for niveau, message in variante.problemes()]
                if variante.corriger(variante.juste())[0] not in (1, None):
                    p.append(("erreur", f"selon, cas {n} : sa propre réponse juste n'y est pas notée juste"))
        return p

    def _ordre(self, etat):
        communs = parametres(Question)
        tete = {k: etat[k] for k in ("id", "enonce", "enonce_simplifie") if k in etat}  # la reformulation se relit sous l'énoncé
        return {**tete, **{k: v for k, v in etat.items() if k not in communs}, **{k: v for k, v in etat.items() if k in communs and k not in tete}}


class Alternative(Question):
    type = "alternative"

    devinable = True

    def reponse_forcee(self):
        return True

    def __init__(self, id, enonce, reponse, libelles=("Vrai", "Faux"), **commun):
        super().__init__(id, enonce, **commun)
        self.reponse, self.libelles = reponse, list(libelles)
        self._construire()

    def juste(self):
        return self.reponse

    def corriger(self, saisie):
        return (1 if saisie == self.reponse else 0), None

    def _attendu(self):
        return self.libelles[0 if self.reponse else 1]

    def problemes(self):
        return super().problemes() + ([("erreur", "libelles : exactement deux")] if len(self.libelles) != 2 else [])


class Choix(Question):
    """Base de ChoixUnique et ChoixMultiples : ``saisie`` = indices (de ``propositions``, non mélangées) des cases cochées."""

    devinable = True

    def reponse_forcee(self):
        return self.type == "choix_unique" and len(self.propositions) <= 2

    def __init__(self, id, enonce, propositions, melanger=True, **commun):
        super().__init__(id, enonce, **commun)
        self.propositions, self.melanger = propositions, melanger

    def correctes(self):
        return sum(1 for p in self.propositions if p.correcte)

    def _cochees(self):
        return [i for i, b in enumerate(self.boutons) if b.isChecked()]

    def _feedbacks(self, indices):
        return "\n\n".join(self.propositions[i].feedback for i in indices if self.propositions[i].feedback) or None

    def _attendu(self):
        justes = "\n".join(f"- {p.texte}" for p in self.propositions if p.correcte)
        remarques = "\n".join(f"- {p.texte} : {p.feedback}" for p in self.propositions if p.feedback)
        return justes + ("\n\n" + remarques if remarques else "")

    def problemes(self):
        return super().problemes() + ([("erreur", "au moins deux propositions")] if len(self.propositions) < 2 else [])


class ChoixUnique(Choix):
    type = "choix_unique"

    EXCLUSIF = True

    def __init__(self, id, enonce, propositions, melanger=True, **commun):
        super().__init__(id, enonce, propositions, melanger, **commun)
        self._construire()

    def juste(self):
        return next(i for i, p in enumerate(self.propositions) if p.correcte)

    def corriger(self, saisie):
        if saisie is None:
            return 0, None
        return (1 if self.propositions[saisie].correcte else 0), self._feedbacks([saisie])

    def problemes(self):
        return super().problemes() + ([("erreur", f"choix_unique doit avoir exactement 1 proposition correcte, {self.correctes()} trouvée(s)")]
                                      if self.correctes() != 1 else [])


class ChoixMultiples(Choix):
    type = "choix_multiples"

    EXCLUSIF = False

    def __init__(self, id, enonce, propositions, bareme="tout_ou_rien", melanger=True, **commun):
        super().__init__(id, enonce, propositions, melanger, **commun)
        self.bareme = bareme
        self._construire()

    def juste(self):
        return [i for i, p in enumerate(self.propositions) if p.correcte]

    def corriger(self, saisie):
        """tout_ou_rien : toutes les bonnes cases et aucune autre ; proportionnel : la part des propositions bien traitées
        (cochée à juste titre ou laissée à juste titre) ; penalite : une case fausse retire ce que rapporte une juste ;
        par_case : idem, mais une case correcte laissée vide coûte aussi — une copie blanche gagnerait alors les cases
        justement vides, d'où le 0 imposé quand rien n'est coché."""
        coches, bonnes = set(saisie or []), {i for i, p in enumerate(self.propositions) if p.correcte}
        justes, fausses = len(coches & bonnes), coches - bonnes
        if self.bareme == "proportionnel":
            fraction = (len(self.propositions) - len(coches ^ bonnes)) / len(self.propositions)
        elif self.bareme == "penalite":
            fraction = max(0, justes - len(fausses)) / len(bonnes)
        elif self.bareme == "par_case":
            n = len(self.propositions)
            fraction = max(0, n - 2 * len(coches ^ bonnes)) / n if coches else 0
        else:
            fraction = 1 if coches == bonnes else 0
        return fraction, (self._feedbacks(sorted(fausses)) if fraction < 1 else None)

    def problemes(self):
        return (super().problemes() + ([("erreur", "aucune proposition correcte")] if not self.correctes() else [])
                + ([("erreur", f"bareme « {self.bareme} » : {', '.join(BAREMES)}")] if self.bareme not in BAREMES else []))


COMPARAISONS = ("texte", "valeur", "liste", "ensemble", "formule")  # ``ReponseCourte.comparaison``
ILLISIBLE = object()  # ce que rend ``valeur_saisie`` d'un texte qui n'est pas une valeur Python


def valeur_saisie(texte, comparaison):
    """La valeur Python d'une réponse courte (``ast.literal_eval``) ; en ``liste`` et ``ensemble``, la liste de ses
    éléments, crochets facultatifs (« 3, 1, 2 » comme « [3, 1, 2] », « 3 » comme « [3] »), et des listes séparées par
    des espaces ou des points-virgules comme par des virgules (« [0, 3] ; [0, 5] »). ``ILLISIBLE`` sinon."""
    texte = str(texte).strip()
    if comparaison != "valeur":
        texte = re.sub(r"\]\s*;?\s*\[", "], [", texte)
    try:
        v = ast.literal_eval(texte)
    except (ValueError, TypeError, SyntaxError, MemoryError, RecursionError):
        return ILLISIBLE
    if comparaison == "valeur":
        return v
    return list(v) if isinstance(v, (list, tuple)) else [v]


OPERATIONS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
              ast.FloorDiv: operator.floordiv, ast.USub: operator.neg, ast.UAdd: operator.pos}
POINTS = (3, 4, 7, 10, 16, 25)  # valeurs des variables où deux formules sont comparées : plus de points que leur degré


def formule(texte, variables):
    """Les valeurs exactes (``Fraction``) d'une expression algébrique écrite à la main en fonction de ``variables``
    (lettres seules), aux ``POINTS`` : « n(n-1)/2 », « n²/2 − n/2 », « 2^h - 1 », « C(n) = n×(n−1)/2 » (seul le
    dernier membre compte) ; multiplication implicite, ``^`` ou ``**``, virgule décimale. ``ILLISIBLE`` sinon."""
    t = str(texte).split("=")[-1]
    for a, b in (("×", "*"), ("·", "*"), ("÷", "/"), ("−", "-"), ("–", "-"), ("^", "**"), ("²", "**2"), ("³", "**3")):
        t = t.replace(a, b)
    jetons = re.findall(r"\d+(?:[.,]\d+)?|\*\*|//|[A-Za-z]|\S", re.sub(r"(?<=\d),(?=\d)", ".", t))
    if not jetons or any(j.isalpha() and j not in variables for j in jetons):
        return ILLISIBLE
    # « 2n », « n(n-1) », « (n+1)n » : le signe de multiplication omis
    ecrit = [j if i == 0 or not ((jetons[i - 1][-1].isalnum() or jetons[i - 1] == ")")
                                 and (j.isalpha() or j == "(" or (j[0].isdigit() and jetons[i - 1].isalpha())))
             else "*" + j for i, j in enumerate(jetons)]

    def calcul(noeud, valeurs):
        if isinstance(noeud, ast.Constant) and type(noeud.value) in (int, float):
            return Fraction(str(noeud.value))
        if isinstance(noeud, ast.Name):
            return valeurs[noeud.id]
        if isinstance(noeud, ast.UnaryOp):
            return OPERATIONS[type(noeud.op)](calcul(noeud.operand, valeurs))
        a, b = calcul(noeud.left, valeurs), calcul(noeud.right, valeurs)
        if isinstance(noeud.op, ast.Pow):  # exposant entier, et pas de quoi saturer la mémoire (« 2^2^2^2^2 »)
            if b.denominator != 1 or max(abs(a.numerator), a.denominator).bit_length() * abs(b) > 100_000:
                raise ValueError
            return a ** int(b)
        return OPERATIONS[type(noeud.op)](a, b)
    try:
        arbre = ast.parse("".join(ecrit), mode="eval").body
        return tuple(calcul(arbre, {v: Fraction(POINTS[(k + i) % len(POINTS)]) for i, v in enumerate(variables)})
                     for k in range(len(POINTS)))
    except (SyntaxError, ValueError, KeyError, AttributeError, ZeroDivisionError, RecursionError, MemoryError):
        return ILLISIBLE


def meme_valeur(a, b):
    """``a == b`` sans confondre ``True`` et ``1`` ni une liste et un tuple, à toute profondeur."""
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return type(a) is type(b) and len(a) == len(b) and all(map(meme_valeur, a, b))
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(meme_valeur(a[k], b[k]) for k in a)
    if isinstance(a, bool) or isinstance(b, bool):
        return a is b
    return a == b


def note_ensemble(saisis, attendus):
    """Barème ``penalite`` sur les éléments : un juste rapporte 1/n, un faux en retire autant, plancher 0 ; ordre et
    doublons ignorés."""
    distincts = []
    for x in saisis:
        if not any(meme_valeur(x, y) for y in distincts):
            distincts.append(x)
    justes = sum(any(meme_valeur(x, y) for y in attendus) for x in distincts)
    return max(0, justes - (len(distincts) - justes)) / len(attendus) if attendus else 0


class ReponseCourte(Question):
    type = "reponse_courte"

    def __init__(self, id, enonce, reponses, tolerance=None, erreurs=None, exact=False, comparaison="texte", motif=None,
                 casse=False, **commun):
        super().__init__(id, enonce, **commun)
        self.reponses, self.tolerance, self.erreurs, self.exact = reponses, tolerance, erreurs or [], exact
        # « texte » : la comparaison souple de toujours ; sinon saisie et réponses lues comme des valeurs Python
        # (``valeur_saisie``), « ensemble » noté élément par élément
        self.comparaison = comparaison
        # expression régulière qui accepte en plus toute saisie de sa forme (« un nom possible commençant par
        # MARTI »), appliquée en entier à la saisie ``comparable`` : minuscules, sans accents (1.38 des widgets de bac)
        self.motif = motif
        # majuscules et minuscules distinguées (« c » n'est pas « F » : 1.64 des widgets de bac) ; le reste de la
        # comparaison souple demeure, les coquilles ne sont plus admises
        self.casse = casse
        self._construire()

    def lire(self, texte):
        """La valeur d'une saisie ou d'une réponse hors de la comparaison texte (``valeur_saisie``, ``formule``)."""
        if self.comparaison == "formule":
            return formule(texte, sorted(set(re.findall(r"[A-Za-z]", str(self.reponses[0])))))  # ses lettres
        return valeur_saisie(texte, self.comparaison)

    def juste(self):
        return str(self.reponses[0])

    def accepte(self, saisie, reponse):
        a, b = nombre(saisie), nombre(reponse)
        if self.tolerance is not None and a is not None and b is not None:
            return abs(a - b) <= self.tolerance
        return egal(saisie, reponse)

    def corriger(self, saisie):
        """1 pour une réponse acceptée, ou à une coquille près (``coquille`` : jamais si une erreur listée est aussi
        proche, ni si ``exact``) ; sinon 0 et l'indice de l'erreur reconnue."""
        saisie = saisie or ""
        if self.comparaison == "formule":  # les réponses qui ne sont pas des formules (« 1 + 2 + … + (n-1) ») en texte
            v = self.lire(saisie)
            if any(egal(saisie, r) or v is not ILLISIBLE and v == self.lire(r) for r in self.reponses):
                return 1, None
            return 0, indice_de(self.erreurs, saisie)
        if self.comparaison != "texte":
            v = self.lire(saisie)
            if v is ILLISIBLE:
                return 0, indice_de(self.erreurs, saisie)
            attendus = [self.lire(r) for r in self.reponses]
            if self.comparaison == "ensemble":
                note = max(note_ensemble(v, a) for a in attendus)
            else:
                note = int(any(meme_valeur(v, a) for a in attendus))
            return note, None if note == 1 else indice_de(self.erreurs, saisie)
        if self.motif and re.fullmatch(self.motif, comparable(saisie)):
            return 1, None
        if self.casse:
            if any(self.accepte(saisie, r) and lettres(saisie) == lettres(r) for r in self.reponses):
                return 1, None
        elif any(self.accepte(saisie, r) for r in self.reponses) or coquille(saisie, self.reponses, [e.reponse for e in self.erreurs if e.reponse is not None], self.exact):
            return 1, None
        return 0, indice_de(self.erreurs, saisie)

    def _attendu(self):
        return " ou ".join(f"`{r}`" for r in self.reponses) + (f" (tolérance ± {self.tolerance:g})" if self.tolerance is not None else "")

    def problemes(self):
        p = super().problemes() + ([("erreur", "reponses : au moins une")] if not self.reponses else [])
        if self.comparaison not in COMPARAISONS:
            p.append(("erreur", f"comparaison « {self.comparaison} » : une de {', '.join(COMPARAISONS)}"))
        elif self.comparaison != "texte":
            p += [("erreur", f"comparaison {self.comparaison} : la réponse « {r} » ne se lit pas")
                  for r in self.reponses[:1 if self.comparaison == "formule" else None] if self.lire(r) is ILLISIBLE]
            if self.tolerance is not None:
                p.append(("erreur", "tolerance : sans effet hors de la comparaison texte"))
            if self.motif:
                p.append(("erreur", "motif : sans effet hors de la comparaison texte"))
            if self.casse:
                p.append(("erreur", "casse : sans effet hors de la comparaison texte (les chaînes y sont déjà exactes)"))
        if self.motif:
            try:
                p += [("erreur", f"motif : la réponse « {r} » ne s'y conforme pas")
                      for r in self.reponses if not re.fullmatch(self.motif, comparable(r))]
            except re.error as e:
                p.append(("erreur", f"motif « {self.motif} » : {e}"))
            if self.casse:
                p.append(("erreur", "motif : appliqué en minuscules, il accepterait une casse fausse avec casse"))
        return p


class ReponseOuverte(Question):
    type = "reponse_ouverte"

    def __init__(self, id, enonce, corrige, mots_cles=None, lignes=5, erreurs=None, console=False, **commun):
        super().__init__(id, enonce, **commun)
        self.corrige, self.mots_cles, self.lignes, self.erreurs = corrige, mots_cles or [], lignes, erreurs or []
        self.console = console  # l'interpréteur interactif de Python au-dessus de la réponse (le widget du type code, sans éditeur)
        self._construire()

    def juste(self):
        return self.corrige

    def corriger(self, saisie):
        return None, None  # corrigée à la main

    def _attendu(self):
        return self.corrige + (f"\n\nMots-clés : {', '.join(self.mots_cles)}" if self.mots_cles else "")


def note_trou(trou, texte, connus=()):
    """1 si le texte saisi est l'une des réponses attendues du trou, ou l'une d'elles à une coquille près (``coquille``,
    qui s'abstient devant un ``connus`` aussi proche), 0 sinon ; hors de la comparaison texte, la note d'une
    ``ReponseCourte`` (« ensemble » : une fraction, élément par élément)."""
    if trou.base:
        corps, base = base_suffixe(texte)
        if base not in (None, trou.base):
            return 0
        # la base oubliée hors de la base 10 coûte la moitié de la case, comme le résultat d'une ``Conversion`` vaut
        # autant que sa base (l'utilisateur, 03/10/2026 : « la base est facultative uniquement en base 10 »)
        return note_texte(trou, corps, connus) * (0.5 if base_manquante(trou.base, texte) else 1)
    return note_texte(trou, texte, connus)


def note_texte(trou, texte, connus=()):
    """``note_trou`` sans la base."""
    if trou.comparaison == "texte":
        return int(any(egal(texte, r) for r in trou.reponses) or coquille(texte, trou.reponses, connus, trou.exact))
    v = valeur_saisie(texte, trou.comparaison)
    if v is ILLISIBLE:
        return 0
    attendus = [valeur_saisie(r, trou.comparaison) for r in trou.reponses]
    if trou.comparaison == "ensemble":
        return max(note_ensemble(v, a) for a in attendus)
    return int(any(meme_valeur(v, a) for a in attendus))


def trou_juste(trou, texte, connus=()):
    """Le trou est-il entièrement juste (``note_trou``) ?"""
    return note_trou(trou, texte, connus) == 1


def connus_du_trou(trous, n, choix=None):
    """Ce qui, écrit dans le trou ``n``, n'est PAS une coquille d'une de ses réponses : ses erreurs listées, les choix
    proposés (les siens ou ceux de la question), et les réponses attendues des autres trous."""
    trou = trous[n]
    return ([e.reponse for e in trou.erreurs if e.reponse is not None] + list(trou.choix or choix or [])
            + [r for m, t in trous.items() if m != n for r in t.reponses or []])


def quotient(numerateur, denominateur):
    a, b = nombre(numerateur), nombre(denominateur)
    return a / b if a is not None and b else None


def arrondi_pareil(texte, valeur):
    """Le texte saisi est-il ``valeur`` arrondie, ou tronquée, au nombre de décimales qu'il porte ? « 2 », « 2,0 » et
    « 2,03 » valent 2,0312 ; « 2,1 » non. À une demi-unité près, inclus : 2,025 s'arrondit à « 2,02 » comme à « 2,03 »,
    selon qu'on calcule ou qu'on lit. Tronqué seulement avec des décimales (« 2,03 » pour 2,036) : « 2 » pour 2,9, non."""
    n = nombre(texte)
    if n is None or valeur is None:
        return False
    decimales = len(str(texte).strip().replace(",", ".").partition(".")[2])
    pas = 10 ** -decimales
    return abs(n - valeur) <= pas / 2 + pas / 1e6 or (decimales > 0 and abs(n - math.floor(valeur / pas) * pas) < pas / 1e6)


def cle_distincte(texte, synonymes=None):
    """La clé sous laquelle ``distinctes`` compare une réponse : le rang de sa classe de ``synonymes`` (« élu » et
    « en exécution » sont le même état), à une coquille près ; son texte normalisé sinon."""
    for rang, classe in enumerate(synonymes or []):
        if any(egal(texte, s) for s in classe) or coquille(texte, classe):
            return rang
    return normaliser(texte)


def variantes(valeur):
    """Les réponses admises d'une case d'une combinaison : une seule écrite comme texte, ou leur liste."""
    return valeur if isinstance(valeur, list) else [valeur]


def hors_combinaison(combinaisons, saisie):
    """Les cases d'un groupe de ``combinaisons`` qui ne s'accordent pas avec la combinaison que la saisie suit le mieux :
    « 192.168.10.0 » avec « 1 » saut mêle deux lignes justes, et l'une des deux cases est fausse."""
    fautives = set()
    for groupe in combinaisons or []:
        accords = [{n for n, valeur in ligne.items() if any(egal(saisie.get(n, ""), r) for r in variantes(valeur))
                    or coquille(saisie.get(n, ""), variantes(valeur))} for ligne in groupe]
        meilleure = max(accords, key=len)
        fautives |= set(groupe[0]) - meilleure
    return fautives


def corriger_trous(trous, saisie, distinctes=None, retenus=None, rapports=None, choix=None, synonymes=None,
                   combinaisons=None, inchangees=()):
    """La fraction et l'indice d'un ensemble de ``Trou`` remplis : moyenne des trous corrigibles, ``None`` si tous
    sont relevés (``reponses`` absent). Partagée par ``TexteATrous`` et ``Tableau``, dont c'est la même correction.
    ``distinctes`` : des groupes de trous dont les réponses doivent être deux à deux DIFFÉRENTES. « Proposer deux
    adresses » n'est pas deux questions indépendantes — chaque réponse y est juste isolément, c'est leur ÉGALITÉ
    qui est fausse, et une correction trou par trou ne peut pas la voir.
    ``retenus`` : {numéro: fraction} retenues par le professeur (correction différée), qui comptent pour ces trous,
    relevés ou refusés par la comparaison exacte.
    ``rapports`` : des ``Rapport`` entre cases mesurées, qui notent ce qu'aucune valeur attendue ne peut noter.
    ``choix`` : la banque de mots commune de la question, parmi ce que ``coquille`` ne doit pas rapprocher.
    ``synonymes`` : des classes de réponses qui, dans un groupe de ``distinctes``, comptent pour UNE (``cle_distincte``).
    ``combinaisons`` : des groupes de lignes complètes admises ; une case n'y est juste qu'avec les autres cases de la même
    (``hors_combinaison``).
    ``inchangees`` : des trous déjà justes tels qu'affichés (``modifier`` d'un tableau), qui ne comptent que s'ils sont
    devenus faux : « indiquer les modifications » se note sur ce qui change."""
    saisie, retenus = saisie or {}, retenus or {}
    fautifs = set()
    for groupe in distinctes or []:
        memes = {}
        for n in groupe:
            if normaliser(saisie.get(n, "")):
                memes.setdefault(cle_distincte(saisie[n], synonymes), []).append(n)
        fautifs |= {n for pareils in memes.values() if len(pareils) > 1 for n in pareils}
    melanges = hors_combinaison(combinaisons, saisie)
    notes, indice = [], None
    for n, trou in trous.items():
        if n in retenus:
            notes.append(retenus[n])
            continue
        if trou.reponses is None:
            continue  # relevé, à corriger à la main
        note = 0 if n in fautifs or n in melanges else note_trou(trou, saisie.get(n, ""), connus_du_trou(trous, n, choix))
        if note == 1 and n in inchangees:
            continue
        notes.append(note)
        indice = indice or (None if note == 1 else BASE_OUBLIEE if note and trou.base and base_manquante(trou.base, saisie.get(n, ""))
                            else indice_de(trou.erreurs, saisie.get(n, "")))
    if fautifs and not indice:
        indice = "Deux réponses qui doivent différer sont identiques."
    if melanges and not indice:
        indice = "Les cases de la ligne ne vont pas ensemble : chacune est juste, mais pas avec les autres."
    for rapport in rapports or []:
        q = quotient(*(saisie.get(n, "") for n in rapport.cases))
        if rapport.attendu is not None:
            juste = rapport.accepte(q)
            notes.append(juste)
            indice = indice or (None if juste else "Le rapport entre les deux mesures n'est pas celui qu'on attend.")
        if rapport.resultat and rapport.resultat not in retenus:
            juste = arrondi_pareil(saisie.get(rapport.resultat, ""), q)
            notes.append(juste)
            indice = indice or (None if juste else "Le rapport écrit n'est pas le quotient des deux valeurs mesurées.")
    return (sum(notes) / len(notes) if notes else None), indice


def solution_trous(trous, distinctes=None, rapports=None, synonymes=None, combinaisons=None):
    """La réponse attendue : la première réponse de chaque trou corrigible, les trous relevés omis. Dans un groupe
    de ``distinctes``, les trous acceptent souvent la MÊME liste de réponses (deux adresses prises dans le même
    sous-réseau) : chacun prend alors la première encore libre, sinon la solution proposée serait celle que la
    correction refuse. La case ``resultat`` d'un ``Rapport`` montre le rapport attendu (« ≈ 2 »), ou celui des
    réponses attendues de ses deux cases (compteurs : 1999 / 999) ; ses mesures restent relevées. Un groupe de
    ``combinaisons`` montre sa première ligne, sans quoi la première réponse de chaque case pourrait les mêler."""
    solution = {n: str(t.reponses[0]) + str(t.base or "").translate(INDICE) for n, t in trous.items() if t.reponses}  # la base due
    combinees = {n: str(variantes(valeur)[0]) for groupe in combinaisons or [] for n, valeur in groupe[0].items()}
    solution.update(combinees)
    for rapport in rapports or []:
        attendu = rapport.attendu if rapport.attendu is not None else quotient(*(solution.get(n, "") for n in rapport.cases))
        if rapport.resultat and attendu is not None:
            solution[rapport.resultat] = f"≈ {attendu:.3g}".replace(".", ",")
    for groupe in distinctes or []:
        prises = set()
        for n in groupe:
            if n in combinees:  # déjà fixée par sa ligne, qu'un autre choix mêlerait
                prises.add(cle_distincte(combinees[n], synonymes))
                continue
            trou = trous.get(n)
            libre = next((r for r in (trou.reponses or []) if cle_distincte(r, synonymes) not in prises), None) if trou else None
            if libre is not None:
                solution[n] = str(libre)
                prises.add(cle_distincte(libre, synonymes))
    return solution


def problemes_trous(trous, choix_communs, quoi="trou", jugees=()):
    """Les contrôles d'un ensemble de ``Trou``, communs au texte à trous et au tableau ; ``jugees`` = les trous sans
    réponse attendue qu'un ``Rapport`` corrige quand même."""
    p = []
    for n, trou in trous.items():
        if trou.comparaison not in COMPARAISONS or trou.comparaison == "formule":
            p.append(("erreur", f"{quoi} {n}, comparaison « {trou.comparaison} » : une de "
                                f"{', '.join(c for c in COMPARAISONS if c != 'formule')}"))
        elif trou.comparaison != "texte":
            p += [("erreur", f"{quoi} {n}, comparaison {trou.comparaison} : la réponse « {r} » ne se lit pas")
                  for r in trou.reponses or [] if valeur_saisie(r, trou.comparaison) is ILLISIBLE]
            if trou.reponses is None or trou.choix or choix_communs:
                p.append(("erreur", f"{quoi} {n}, comparaison {trou.comparaison} : des réponses, pas de liste de choix"))
        choix = trou.choix or choix_communs
        if trou.reponses is None and n not in jugees:
            p.append(("avert", f"{quoi} {n} sans réponse attendue, correction manuelle"))
        elif choix and not set(trou.reponses) & set(choix):
            p.append(("erreur", f"{quoi} {n}, aucune réponse ne figure dans la liste de choix"))
    return p


class TexteATrous(Question):
    """``saisie`` = {numéro de trou: texte saisi ou choisi}."""

    type = "texte_a_trous"

    MARQUEUR = re.compile(r"\[\[(\d+)\]\]")

    def __init__(self, id, enonce, texte, trous, choix=None, retenus=None, **commun):
        super().__init__(id, enonce, **commun)
        self.texte, self.trous, self.choix = texte, trous, choix
        self.retenus = retenus or {}  # {numéro: fraction} posées par ``noter`` (correction différée)
        self.devinable = bool(choix) or any(t.choix for t in trous.values())  # listes déroulantes
        self._construire()

    def juste(self):
        return solution_trous(self.trous)

    def corriger(self, saisie):
        return corriger_trous(self.trous, saisie, retenus=self.retenus, choix=self.choix)

    def trou_juste(self, n, texte):
        """Pour ceux qui corrigent un trou à part (correction à l'écran, lot différé) : la même règle que ``corriger``."""
        return trou_juste(self.trous[n], texte, connus_du_trou(self.trous, n, self.choix))

    def complete(self):
        return len(self.saisie or {}) == len(self.trous)

    def _attendu(self):
        return self.texte

    def _trou_corrige(self, n):
        """Le mot attendu à la place du trou : en vert si l'élève l'avait, en rouge sinon (correction)."""
        trou, saisie = self.trous[n], self._lire() or {}
        if trou.reponses is None:
            return f"<b>{html.escape(saisie.get(n, '…'))}</b>"
        juste = self.trou_juste(n, saisie.get(n, ""))
        # 11,7 pt sur ce corps de 10 (a_l_echelle) = 14 pt à l'écran, comme modele.TAILLE_MAIN : Kalam, à corps égal,
        # a des lettres basses (x-height) plus petites que la police du sujet (27/09/2026). « font-size:» sans espace,
        # sinon a_l_echelle ne le reconnaît pas (le trou restait à 10,8 pt jusqu'au 28/09/2026)
        return (f'<span style="color: {VERT if juste else "#c0392b"}; font-family: {POLICE_MAIN}; font-size:11.7pt">'
                f'{html.escape(str(trou.reponses[0]))}</span>')

    def problemes(self):
        p = super().problemes()
        marqueurs, trous = set(self.MARQUEUR.findall(self.texte)), set(self.trous)
        if marqueurs != trous:
            p.append(("erreur", f"marqueurs {sorted(marqueurs)} ≠ trous déclarés {sorted(trous)}"))
        return p + problemes_trous(self.trous, self.choix)


class FigureATrous(TexteATrous):
    """Des étiquettes à poser sur une figure (1.12 des widgets de bac, « compléter le schéma ») : un texte à trous dont
    les trous sont posés sur l'image ``image``, aux ``places`` = {numéro: [x, y]}, le centre de la case en fraction de la
    largeur et de la hauteur de la figure (de 0 à 1 : la même place à toute taille, à l'écran comme sur le papier).
    Numéroter les trous comme les emplacements de la figure, quand elle en a. Correction, ``choix`` et ``retenus`` : ceux
    du texte à trous."""

    type = "figure_a_trous"

    def __init__(self, id, enonce, image, places, trous, choix=None, retenus=None, **commun):
        super(TexteATrous, self).__init__(id, enonce, **commun)  # pas de ``texte`` : les trous sont sur la figure
        self.image, self.places, self.trous, self.choix = image, places, trous, choix
        self.retenus = retenus or {}
        self.devinable = bool(choix) or any(t.choix for t in trous.values())
        self._construire()

    def _attendu(self):
        """La correction écrite : chaque trou, dans l'ordre de ses numéros, avec ce qui était attendu."""
        return " ; ".join(f"**{n}** : [[{n}]]" for n in sorted(self.trous, key=lambda n: (len(n), n)))

    def problemes(self):
        p = super(TexteATrous, self).problemes() + problemes_trous(self.trous, self.choix)
        if set(self.places) != set(self.trous):
            p.append(("erreur", f"places {sorted(self.places)} ≠ trous déclarés {sorted(self.trous)}"))
        for n, place in self.places.items():
            if not (isinstance(place, list) and len(place) == 2 and all(isinstance(v, (int, float)) and 0 <= v <= 1 for v in place)):
                p.append(("erreur", f"place {n} : [x, y] en fractions de la figure, de 0 à 1"))
        return p


ROND_PION, ROND_VIDE = "●", "◌"  # une case de réglette (``Tableau.pions``) au corrigé, comme sur la figure du sujet


class Tableau(Question):
    """``saisie`` = {"ligne,colonne": texte saisi ou choisi} ; les cases à remplir sont des ``Trou``, comme un texte à trous.

    ``colonnes`` est la ligne d'en-têtes et ``lignes`` la grille telle qu'elle s'affiche (liste de listes de Markdown).
    Une case dont la référence ``"ligne,colonne"`` (numérotées à partir de 0, en-têtes non comptés) figure dans
    ``cellules`` est à remplir : ce qu'en dit ``lignes`` est alors ignoré. Les autres sont données. Un chronogramme
    s'écrit ainsi : une colonne par instant, une ligne par signal, des cellules à ``choix = ["0", "1"]``.

    ``distinctes`` = les groupes de cases dont les réponses doivent être deux à deux DIFFÉRENTES, par exemple
    ``[["0,1", "1,1"]]`` pour « proposer deux adresses IP » : sans cette contrainte, la même adresse écrite deux
    fois serait comptée juste deux fois, chaque case étant corrigée isolément. ``synonymes`` = les classes de réponses
    qui n'y comptent que pour une : ``[["élu", "en exécution"]]`` (1.41 des widgets de bac).

    ``combinaisons`` = des groupes de LIGNES complètes admises, quand plusieurs réponses justes engagent plusieurs cases
    à la fois (deux routes possibles, deux clés étrangères : 1.36 et 1.22 des widgets de bac) ; chaque ligne est un
    ``{"ligne,colonne": réponse ou liste de réponses}``, aux mêmes cases d'une ligne à l'autre. Les ``reponses`` de
    chaque case restent leur réunion : la case est corrigée comme d'habitude, PUIS doit s'accorder avec les autres
    cases de la ligne que la saisie suit le mieux.

    ``frise`` : un chronogramme d'ordonnancement en frise type Gantt (1.13 des widgets de bac) : une colonne par instant,
    une ligne par processus, l'élève colorie pour chaque instant la case du processus exécuté. C'est un AFFICHAGE : la
    grille reste celle d'un tableau, les instants étant ses colonnes (une seule ligne) ou ses lignes (deux colonnes,
    l'instant puis le processus), et chaque case se note comme avant ; les processus sont ses ``choix``, sauf « aucun »
    (``VIDES``), qu'une colonne laissée blanche vaut.

    ``rapports`` = les ``Rapport`` entre cases mesurées (temps, compteurs d'une question de complexité) : la case du
    numérateur sur celle du dénominateur doit valoir ``attendu`` à ``tolerance`` près, et la case ``resultat`` où
    l'élève écrit ce rapport doit être le quotient de ses propres mesures. Ce sont les seules cases sans ``reponses``
    que la machine corrige.

    ``lignes_libres`` : l'élève ajoute lui-même ses lignes (« autant de lignes que nécessaire »). ``lignes`` porte la
    grille ATTENDUE ; l'élève en voit les ``minimum`` premières (par défaut, jusqu'à la première ligne qui a une case à
    remplir, incluse) et en fait paraître une de plus à chaque « + ligne », sans savoir combien il en faut. Une ligne
    écrite au-delà de la grille coûte autant qu'une ligne manquante, comme une arête en trop d'un ``dessin`` ; ses
    cases à remplir sont celles de la dernière ligne, et une case donnée y prolonge la numérotation des deux dernières
    (« Étape » 5, 6 → 7, 8), ou reste vide (``donnee``).

    ``modifier`` : « indiquer les modifications à apporter à la table » (1.27 des widgets de bac). Chaque case à remplir
    arrive PRÉ-REMPLIE du texte que lui donne ``lignes`` (l'état d'avant), que l'élève corrige ; une case dont ce texte est
    déjà juste ne compte que si l'élève la rend fausse, sans quoi recopier la table rapporterait des points.

    ``caracteres`` : une grille caractère par caractère (Polybe, Vigenère, César, taquin : 1.19 des widgets de bac). Chaque
    case à remplir prend UN caractère, la saisie passe d'elle-même à la suivante, et la grille est notée case par case
    comme toute autre : une erreur de grille ne coûte plus que ses cases.

    ``a_entourer`` : les cases DONNÉES que l'élève doit entourer (« entourer le bit qui a subi l'erreur » : 1.37 des widgets
    de bac), des références ``"ligne,colonne"``. La grille n'a alors aucune case à remplir (``cellules`` vide) ; la saisie
    est la liste des cases entourées, notée par la règle ``penalite`` des cases à cocher (``note_ensemble`` : une case en
    trop annule une juste, plancher 0). L'élève en entoure autant qu'il veut : rien ne lui dit combien il en faut.

    ``simulation`` : un jeu à cases joué coup après coup, noté par ses RÈGLES et non case par case (1.47 des widgets de
    bac : baguenaudier, tubes de couleurs). Du Python du professeur, exécuté comme les expressions de ``selon`` et des
    ``variables``, qui définit ``depart`` (l'état initial), ``jouer(etat, ligne)`` (l'état après le coup qu'écrit la
    ``ligne``, liste des textes de ses cases, ou ``None`` si le coup n'est pas permis ou l'état écrit est faux ; une
    exception vaut ``None``) et, en option, ``but(etat)``. Chaque ligne se joue sur l'état de la précédente, et toute
    suite de coups permis qui atteint le but est juste, pas seulement celle de ``lignes``, qui n'en est qu'un exemple.
    Avec ``coups_au_choix``, chaque ligne se joue depuis ``depart`` : ce sont LES coups possibles, dans n'importe quel
    ordre. Le nombre de coups joués est borné par celui des lignes que l'élève peut ouvrir (le double de la grille plus
    deux) ; une boucle sans fin dans ``jouer`` serait une faute du professeur, que ``valider`` voit en rejouant la grille.

    ``pions`` (avec ``simulation``) : les cases à deux choix (« vide »/« pion ») se dessinent en réglette, comme la figure
    du sujet : un rond plein pour le second mot, un rond pointillé sinon, et un clic bascule. Une case sans pion se lit
    vide (« »), d'où la simulation obligatoire : elle seule sait qu'une case vide vaut le premier mot."""

    type = "tableau"

    REFERENCE = re.compile(r"^(\d+),(\d+)$")

    def __init__(self, id, enonce, colonnes, lignes, cellules, choix=None, distinctes=None, rapports=None,
                 lignes_libres=False, minimum=None, synonymes=None, combinaisons=None, modifier=False,
                 caracteres=False, frise=False, a_entourer=None, simulation=None, coups_au_choix=False, pions=False, **commun):
        super().__init__(id, enonce, **commun)
        self.colonnes, self.lignes, self.cellules, self.choix = colonnes, lignes, cellules, choix
        self.distinctes, self.rapports = distinctes, rapports
        self.lignes_libres, self.minimum = lignes_libres, minimum
        self.synonymes, self.combinaisons, self.modifier = synonymes, combinaisons, modifier
        self.caracteres = caracteres
        self.frise = frise
        self.a_entourer = a_entourer
        self.simulation, self.coups_au_choix, self.pions = simulation, coups_au_choix, pions
        self._construire()

    def juste(self):
        if self.a_entourer:
            return sorted(self.a_entourer)
        return solution_trous(self.cellules, self.distinctes, self.rapports, self.synonymes, self.combinaisons)

    def a_entete(self):
        """Faux quand aucune colonne n'a de titre (une grille de bits, 1.37) : pas de ligne d'en-tête vide, ni à l'écran
        ni sur le papier."""
        return any(str(c).strip() for c in self.colonnes)

    def montrees(self):
        """Les lignes affichées d'emblée, avant tout « + ligne »."""
        if not self.lignes_libres:
            return len(self.lignes)
        if self.minimum is not None:
            return self.minimum
        return next((r for r in range(len(self.lignes)) if self.cases_de_ligne(r)), len(self.lignes) - 1) + 1

    def donnee(self, r, c):
        """Le texte donné de la case ``r,c`` ; au-delà de la grille, un nombre entier qui prolonge les deux dernières
        lignes, ou rien."""
        if r < len(self.lignes):
            return self.lignes[r][c]
        entiers = [int(t) for t in (str(l[c]).strip() for l in self.lignes[-2:]) if re.fullmatch(r"-?\d+", t)]
        return str(entiers[1] + (entiers[1] - entiers[0]) * (r - len(self.lignes) + 1)) if len(entiers) == 2 else ""

    def cases_de_ligne(self, r):
        """Les colonnes à remplir de la ligne ``r`` ; au-delà de la grille attendue, celles de sa dernière ligne."""
        r = min(r, len(self.lignes) - 1)
        return [c for c in range(len(self.colonnes)) if f"{r},{c}" in self.cellules]

    def lignes_ecrites(self, saisie):
        """Le nombre de lignes de la saisie : jusqu'à la dernière où quelque chose est écrit, ``montrees`` au moins."""
        ecrites = [int(n.split(",")[0]) for n, t in (saisie or {}).items() if str(t).strip() and self.REFERENCE.match(n)]
        return max([self.montrees(), *(r + 1 for r in ecrites)])

    def corriger(self, saisie):
        if self.a_entourer:
            fraction = note_ensemble(saisie or [], self.a_entourer)
            return fraction, None if fraction == 1 else "Les cases entourées ne sont pas toutes les bonnes."
        if self.simulation and saisie:
            return self._simuler(saisie)
        fraction, indice = corriger_trous(self.cellules, saisie, self.distinctes, rapports=self.rapports, choix=self.choix,
                                          synonymes=self.synonymes, combinaisons=self.combinaisons,
                                          inchangees=self.inchangees())
        if not self.lignes_libres or fraction is None:
            return fraction, indice
        en_trop = sum(len(self.cases_de_ligne(r)) for r in range(len(self.lignes), self.lignes_ecrites(saisie)))
        if not en_trop:
            return fraction, indice
        notes = self.notees()
        return fraction * notes / (notes + en_trop), indice or "Le tableau a plus de lignes qu'il n'en faut."

    def regles(self):
        """Les fonctions de la ``simulation`` : ``(depart, jouer, but)``."""
        espace = {}
        exec(self.simulation, espace)
        return espace["depart"], espace["jouer"], espace.get("but", lambda etat: True)

    def etats(self, saisie):
        """L'état du jeu après chaque ligne écrite, jouée depuis ``depart`` (chacune depuis ``depart`` avec
        ``coups_au_choix``) ; None pour un coup que les règles ne permettent pas, après lequel une suite s'arrête."""
        depart, jouer, _ = self.regles()
        etat = depart
        for r in range(self.lignes_ecrites(saisie)):
            ligne = [str(saisie.get(f"{r},{c}", "") if c in self.cases_de_ligne(r) else self.donnee(r, c)).strip()
                     for c in range(len(self.colonnes))]
            try:
                suivant = jouer(copy.deepcopy(depart if self.coups_au_choix else etat), ligne)
            except Exception:
                suivant = None
            yield suivant
            if suivant is None and not self.coups_au_choix:
                return
            etat = suivant

    def coup_interdit(self, saisie):
        """La ligne du premier coup que les règles ne permettent pas (``simulation``), None s'il n'y en a pas : c'est
        elle que la correction rature (l'utilisateur, 04/10/2026 : « rature la ligne du premier coup interdit »)."""
        if not (self.simulation and saisie):
            return None
        return next((r for r, etat in enumerate(self.etats(saisie)) if etat is None), None)

    def _simuler(self, saisie):
        """La note d'une ``simulation``, chaque ligne écrite étant un coup. Une suite de coups tous permis qui atteint le but
        vaut tout ; sinon la moitié des points au prorata des coups permis avant le premier qui ne l'est pas. Avec
        ``coups_au_choix`` : k coups possibles distincts trouvés sur n, en m lignes écrites, valent k / max(n, m), une
        ligne fausse ou répétée comptant comme une ligne en trop."""
        depart, _, but = self.regles()
        n, etats = self.lignes_ecrites(saisie), list(self.etats(saisie))
        if self.coups_au_choix:
            trouves = {repr(e) for e in etats if e is not None}
            fraction = len(trouves) / max(len(self.lignes), n)
            return fraction, None if fraction == 1 else "Les lignes ne sont pas exactement les coups possibles."
        if etats and etats[-1] is None:
            r = len(etats) - 1
            return 0.5 * r / n, f"Le coup de la ligne {r + 1} n'est pas permis par les règles."
        try:
            atteint = but(etats[-1] if etats else depart)
        except Exception:
            atteint = False
        return (1, None) if atteint else (0.5, "La suite de coups n'atteint pas le but.")

    def notees(self):
        """Le nombre de cases notées : les cellules à réponse et les rapports (attendu, résultat)."""
        return (sum(t.reponses is not None for t in self.cellules.values())
                + sum((r.attendu is not None) + bool(r.resultat) for r in self.rapports or []))

    def _bareme(self):
        """Le barème, quand des cases ont le bon nombre mais pas sa base : la moitié de leurs points (``note_trou``),
        dite à l'élève (l'utilisateur, 03/10/2026 : « detailler le bareme […] quand il a le bon resultat […] mais a oublié
        la notation de la base »)."""
        saisie = self.saisie or {}
        sans = [n for n, t in self.cellules.items() if t.base and t.reponses and base_manquante(t.base, saisie.get(n, ""))
                and note_trou(t, saisie.get(n, ""), connus_du_trou(self.cellules, n, self.choix)) == 0.5]
        if not sans:
            return ""
        case, k = self.points / self.notees(), len(sans)
        return (f"**Barème** : chaque case vaut {round(case, 2):g} pt. {k} case{'s' if k > 1 else ''} "
                f"{'ont' if k > 1 else 'a'} le bon nombre sans sa base (« {saisie[sans[0]]} ») : la moitié de "
                f"{'leurs' if k > 1 else 'ses'} points, soit −{round(k * case / 2, 2):g} pt.")

    def inchangees(self):
        """Avec ``modifier``, les cases déjà justes telles qu'affichées."""
        if not self.modifier:
            return set()
        return {n for n, t in self.cellules.items() if t.reponses is not None and trou_juste(t, self.donnee(*map(int, n.split(","))))}

    VIDES = ("aucun", "vide", "rien", "", "—", "-")  # les choix d'une ``frise`` qui disent qu'aucun processus ne s'exécute

    def instants(self):
        """Les instants d'une ``frise``, dans l'ordre : ``(libellé, case)``, la case étant leur référence ``"ligne,colonne"`` —
        une colonne de l'unique ligne, ou la seconde case d'une ligne dont la première nomme l'instant."""
        if len(self.lignes) == 1:
            return [(str(titre), f"0,{c}") for c, titre in enumerate(self.colonnes)]
        return [(str(ligne[0]), f"{r},1") for r, ligne in enumerate(self.lignes)]

    def _choix_frise(self):
        return [str(p) for p in self.choix or next((t.choix for t in self.cellules.values() if t.choix), [])]

    def processus(self):
        """Les lignes d'une ``frise`` : les choix proposés, dans leur ordre, sans « aucun »."""
        vides = {comparable(v) for v in self.VIDES}
        return [p for p in self._choix_frise() if comparable(p) not in vides]

    def vide(self):
        """Ce que vaut un instant laissé blanc sur une ``frise`` : le choix « aucun » proposé, ou rien."""
        return next((p for p in self._choix_frise() if p not in self.processus()), "")

    def execute(self, n, saisie):
        """Le processus que la saisie (ou la grille, pour une case donnée) exécute à l'instant de la case ``n``, ou ``None``."""
        valeur = (saisie or {}).get(n) if n in self.cellules else self.donnee(*map(int, n.split(",")))
        return next((p for p in self.processus() if egal(valeur, p)), None)

    def trou_juste(self, n, texte):
        """Une case corrigée à part, par la même règle que ``corriger``."""
        return trou_juste(self.cellules[n], texte, connus_du_trou(self.cellules, n, self.choix))

    def jugees(self):
        """Les cases sans ``reponses`` qu'un ``Rapport`` corrige quand même."""
        return set().union(*(r.jugees() for r in self.rapports or []))

    def manuelles(self):
        """Les cases qui restent au professeur : relevées, et dans aucun ``Rapport``."""
        return {n for n, t in self.cellules.items() if t.reponses is None} - self.jugees()

    def complete(self):
        if self.a_entourer:
            return bool(self.saisie)
        if not self.lignes_libres:
            return len(self.saisie or {}) == len(self.cellules)
        saisie = self.saisie or {}  # toutes les cases des lignes que l'élève a ouvertes, et pas une de plus
        return all(saisie.get(f"{r},{c}") for r in range(self.lignes_ecrites(saisie)) for c in self.cases_de_ligne(r))

    def case(self, r, c, corrige=False):
        """Le contenu Markdown d'une case : le texte donné, ou la réponse attendue si ``corrige``, ou un blanc (le texte
        d'avant, avec ``modifier``)."""
        trou = self.cellules.get(f"{min(r, len(self.lignes) - 1)},{c}")
        if trou is None or (self.modifier and not corrige):
            return self.donnee(r, c)
        if not corrige or r >= len(self.lignes):
            return ""
        attendu = self.juste().get(f"{r},{c}", "(relevé)")
        return (ROND_PION if attendu == trou.choix[1] else ROND_VIDE) if self.en_pion(trou) else attendu

    def en_pion(self, trou):
        """Vrai pour une case de la réglette (``pions``) : une case à deux choix, le second étant le pion."""
        return bool(self.pions and self.simulation and trou and trou.choix and len(trou.choix) == 2)

    def consigne_simulation(self):
        """Ce que dit le corrigé d'une ``simulation`` au-dessus de la grille attendue, qui n'est qu'un exemple."""
        if not self.simulation:
            return ""
        return ("Les coups possibles, dans n'importe quel ordre." if self.coups_au_choix
                else "Une solution parmi d'autres : toute suite de coups permis qui atteint le but est juste.")

    def _attendu(self):
        entetes = "| " + " | ".join(str(e) for e in self.colonnes) + " |"
        tiret = "|" + "---|" * len(self.colonnes)
        corps = [("| " + " | ".join(self.case(r, c, corrige=True) for c in range(len(self.colonnes))) + " |")
                 for r in range(len(self.lignes))]
        return "\n\n".join(filter(None, [self.but_manque(), self.consigne_simulation(), "\n".join([entetes, tiret, *corps])]))

    def but_manque(self):
        """Ce que dit la correction d'une ``simulation`` quand l'élève n'a joué que des coups permis sans atteindre le but :
        rien n'est raturé dans sa grille (``coup_interdit``), la phrase dit pourquoi les points manquent."""
        saisie = self.saisie
        if not self.simulation or self.coups_au_choix or not saisie or self.coup_interdit(saisie) is not None \
                or self._simuler(saisie)[0] == 1:
            return ""
        return "Tous les coups écrits sont permis, mais la suite n'atteint pas le but."

    def problemes(self):
        p = super().problemes()
        largeur = len(self.colonnes)
        for r, ligne_ in enumerate(self.lignes):
            if len(ligne_) != largeur:
                p.append(("erreur", f"ligne {r} : {len(ligne_)} cases pour {largeur} colonnes"))
        p += [("erreur", f"colonne {c} : une image ne se met que dans une case, pas dans un en-tête")  # 1.57
              for c, titre in enumerate(self.colonnes) if "![" in str(titre)]
        if self.a_entourer is not None:
            p += self._problemes_entourer()
        elif not self.cellules:
            p.append(("erreur", "tableau sans aucune case à remplir"))
        if self.lignes_libres:
            if self.minimum is not None and not 1 <= self.minimum <= len(self.lignes):
                p.append(("erreur", f"minimum {self.minimum} : entre 1 et {len(self.lignes)}, les lignes de la grille attendue"))
            for r in range(self.montrees(), len(self.lignes)):
                if not self.cases_de_ligne(r):  # cachée tant que l'élève ne l'ouvre pas : ce qu'elle donne lui manquerait
                    p.append(("erreur", f"lignes_libres : la ligne {r}, cachée d'abord, n'a aucune case à remplir"))
            if not self.cases_de_ligne(len(self.lignes) - 1):
                p.append(("erreur", "lignes_libres : la dernière ligne, modèle des lignes ajoutées, n'a aucune case à remplir"))
        elif self.minimum is not None:
            p.append(("avertissement", "minimum sans lignes_libres : ignoré"))
        if self.caracteres:
            p += [("erreur", f"caracteres : la case {n} attend « {r} », plus d'un caractère")
                  for n, t in self.cellules.items() for r in t.reponses or [] if len(str(r)) > 1]
        for reference in self.cellules:
            m = self.REFERENCE.match(str(reference))
            if not m or not (int(m[1]) < len(self.lignes) and int(m[2]) < largeur):
                p.append(("erreur", f"cellule {reference} : hors de la grille {len(self.lignes)}×{largeur}"))
        for groupe in self.distinctes or []:
            if len(groupe) < 2:
                p.append(("erreur", f"distinctes {groupe} : une contrainte porte sur au moins deux cases"))
            for reference in groupe:
                if reference not in self.cellules:
                    p.append(("erreur", f"distinctes : la case {reference} n'est pas à remplir"))
        if self.synonymes and not self.distinctes:
            p.append(("erreur", "synonymes : sans effet sans distinctes"))
        p += [("erreur", f"synonymes {classe} : une classe réunit au moins deux réponses")
              for classe in self.synonymes or [] if len(classe) < 2]
        for groupe in self.combinaisons or []:
            if len(groupe) < 2:
                p.append(("erreur", "combinaisons : un groupe propose au moins deux lignes"))
            for ligne in groupe:
                if set(ligne) != set(groupe[0]):
                    p.append(("erreur", f"combinaisons : {sorted(ligne)} au lieu des cases {sorted(groupe[0])}"))
                for n, valeur in ligne.items():
                    trou = self.cellules.get(n)
                    p += [("erreur", f"combinaisons : la case {n} n'admet pas « {r} »") for r in variantes(valeur)
                          if not (trou and trou.reponses and any(egal(r, s) for s in trou.reponses))]
        for rapport in self.rapports or []:
            if len(rapport.cases) != 2 or (rapport.attendu is None and not rapport.resultat):
                p.append(("erreur", f"rapport {rapport.cases} : deux cases (numérateur, dénominateur), et un attendu ou une case résultat"))
            for reference in [*rapport.cases, *([rapport.resultat] if rapport.resultat else [])]:
                if reference not in self.cellules:
                    p.append(("erreur", f"rapport : la case {reference} n'est pas à remplir"))
            if rapport.resultat in self.cellules and self.cellules[rapport.resultat].reponses is not None:
                p.append(("erreur", f"rapport : la case {rapport.resultat} a déjà ses réponses, elle serait jugée deux fois"))
            if rapport.attendu is not None and all(self.cellules.get(n) and self.cellules[n].reponses for n in rapport.cases):
                q = quotient(*(self.cellules[n].reponses[0] for n in rapport.cases))
                if not rapport.accepte(q):
                    p.append(("erreur", f"rapport {rapport.cases} : les réponses attendues des deux cases donnent {q}, pas {rapport.attendu}"))
        if self.frise:
            p += self._problemes_frise()
        if self.simulation:
            p += self._problemes_simulation()
        elif self.coups_au_choix:
            p.append(("avertissement", "coups_au_choix sans simulation : ignoré"))
        if self.pions and not self.simulation:
            p.append(("erreur", "pions sans simulation : une case sans pion se lit vide, seule une simulation la vaut au premier mot"))
        return p + problemes_trous(self.cellules, self.choix, "cellule", self.jugees())

    def _problemes_simulation(self):
        """Les règles s'exécutent, et la grille attendue les suit : sinon aucune réponse, pas même celle du corrigé,
        ne serait juste."""
        try:
            self.regles()
        except Exception as e:
            return [("erreur", f"simulation : {type(e).__name__} {e} (il faut depart, jouer(etat, ligne) et, en option, but(etat))")]
        juste = {n: v[0] if isinstance(v, list) else v for n, v in self.juste().items()}
        if self.manuelles() or self._simuler(juste)[0] != 1:
            return [("erreur", "simulation : la grille attendue n'est pas une suite de coups permis qui atteint le but"
                     + (" (chaque ligne un coup possible distinct, tous présents)" if self.coups_au_choix else ""))]
        return []

    def _problemes_entourer(self):
        if self.cellules or self.lignes_libres or self.modifier or self.caracteres or self.frise or self.choix:
            return [("erreur", "a_entourer : la grille est toute donnée (ni cellules, ni lignes_libres, modifier, caracteres, frise, choix)")]
        p = [("erreur", f"a_entourer : la case {n} est hors de la grille {len(self.lignes)}×{len(self.colonnes)}")
             for n in self.a_entourer if not ((m := self.REFERENCE.match(str(n))) and int(m[1]) < len(self.lignes)
                                               and int(m[2]) < len(self.colonnes))]
        if not self.a_entourer:
            p.append(("erreur", "a_entourer : au moins une case"))
        if len(set(self.a_entourer)) < len(self.a_entourer):
            p.append(("erreur", "a_entourer : une case citée deux fois"))
        return p

    def _problemes_frise(self):
        if self.lignes_libres or self.modifier or self.caracteres or self.rapports:
            return [("erreur", "frise : sans lignes_libres, modifier, caracteres ni rapports")]
        if len(self.lignes) != 1 and not (len(self.colonnes) == 2 and all(n.endswith(",1") for n in self.cellules)):
            return [("erreur", "frise : une seule ligne (un instant par colonne), ou deux colonnes (l'instant, puis la case du processus)")]
        p = [("erreur", f"frise : la case {n} n'a pas de choix (les processus)") for n, t in self.cellules.items()
             if not (t.choix or self.choix)]
        if len(self.processus()) < 2:
            p.append(("erreur", "frise : au moins deux processus parmi les choix"))
        p += [("erreur", f"frise : la case {n} donne « {self.donnee(*map(int, n.split(',')))} », ni un processus ni « aucun »")
              for _, n in self.instants() if n not in self.cellules and self.execute(n, None) is None
              and comparable(self.donnee(*map(int, n.split(",")))) not in {comparable(v) for v in self.VIDES}]
        return p


def code_nu(texte):
    """Un élément écrit en Markdown (```` `x = 1` ````) rendu tel qu'il s'exécute, indentation comprise."""
    return texte[1:-1] if len(texte) > 1 and texte.startswith("`") and texte.endswith("`") else texte


class Ordre(Question):
    """``saisie`` = indices des ``elements`` (dans le bon ordre) dans l'ordre où l'élève les a rangés.

    ``langage`` vide : les éléments sont des étiquettes à glisser dans une liste. ``langage = "python"`` : ce sont
    des lignes de code, remises dans l'ordre DANS l'éditeur Python lui-même, où elles arrivent sans indentation
    (sinon les niveaux trahiraient l'ordre) : l'élève les indente aussi, et la saisie devient
    ``{"ordre": [...], "niveaux": [...]}`` (le niveau de chaque ligne, dans l'ordre rangé), jugée sur les deux. Une
    saisie en simple liste (ancienne copie, lecteur qui montre l'indentation) ne juge que l'ordre. Le texte n'est
    pas modifiable ; ``executable`` donne à l'élève la console pour essayer son rangement.

    ``intrus`` : des étapes qui n'ont pas leur place dans la suite (« Alice chiffre avec sa clé publique », 1.51 des
    widgets de bac : protocole cryptographique). L'élève compose alors sa suite en y glissant les étapes choisies depuis
    une réserve, qui les contient toutes au départ ; la saisie est la suite composée (indices dans ``elements`` puis
    ``intrus``), juste si elle est exactement ``elements``. Avec ``langage`` (Parsons à lignes distractrices, 1.3) :
    toutes les lignes attendent, mélangées, dans une réserve sous l'éditeur, qui part vide ; l'élève y envoie
    celles qu'il garde et les range ; ``ordre`` ne cite que les lignes gardées.

    ``variantes`` : d'autres suites tout aussi justes, chacune la liste de ses étapes (textes de ``elements``), quand
    l'ordre de certaines n'importe pas (Alice peut signer puis chiffrer, ou l'inverse). La note reste celle de
    l'``ordre`` : tout ou rien, sur la suite ``elements`` ou l'une de ses variantes."""

    type = "ordre"

    devinable = True

    def __init__(self, id, enonce, elements, langage="", executable=False, intrus=None, variantes=None, **commun):
        super().__init__(id, enonce, **commun)
        self.elements, self.langage, self.executable, self.intrus = elements, langage, executable, intrus or []
        self.variantes = variantes or []
        self.depart = melange(range(len(self.elements) + len(self.intrus)), self.graine)  # avec intrus, ceux-ci aussi
        self._construire()

    def juste(self):
        return list(range(len(self.elements)))

    def suites_justes(self):
        """``juste()`` puis chaque variante, en indices dans ``elements``."""
        return [self.juste()] + [[self.elements.index(e) for e in v] for v in self.variantes]

    def suite_visee(self, saisie):
        """La suite juste la plus proche de ``saisie`` : celle vers laquelle la correction corrige."""
        return max(self.suites_justes(), key=lambda s: difflib.SequenceMatcher(None, saisie or [], s).ratio())

    def niveaux_justes(self):
        return [(len(code_nu(e)) - len(code_nu(e).lstrip(" "))) // 4 for e in self.elements]

    def corriger(self, saisie):
        if isinstance(saisie, dict):
            return int(saisie["ordre"] == self.juste() and saisie["niveaux"] == self.niveaux_justes()), None
        return int((self.depart if saisie is None else saisie) in self.suites_justes()), None

    def _attendu(self):
        """Les accents graves n'entourent que du code : sans ``langage``, les éléments sont des étiquettes en
        français, et les accents graves s'y liraient tels quels là où la correction n'est pas rendue en Markdown."""
        return "\n".join([f"{n}. " + (f"`{code_nu(e)}`" if self.langage else e) for n, e in enumerate(self.elements, 1)]
                         + [f"- hors de la suite : {e}" for e in self.intrus])

    def problemes(self):
        """``executable`` promet un bouton « Exécuter » qui marche : les lignes, remises dans le bon ordre, doivent
        donc former un programme valide — sans quoi l'élève n'obtiendrait qu'une erreur de syntaxe, quoi qu'il range."""
        p = super().problemes()
        p += [("erreur", f"intrus « {e} » : aussi parmi les elements") for e in self.intrus if e in self.elements]
        if self.variantes and self.langage:
            p.append(("erreur", "variantes : seulement pour des étiquettes, pas des lignes de code (langage)"))
        p += [("erreur", f"variante {n} : ses étapes doivent être celles de elements, une fois chacune")
              for n, v in enumerate(self.variantes, 1) if sorted(v) != sorted(self.elements)]
        if self.executable and self.langage != "python":
            p.append(("erreur", "executable sans langage python : rien à exécuter"))
        elif self.executable:
            try:
                compile("\n".join(code_nu(e) for e in self.elements), self.id, "exec")
            except SyntaxError as exc:
                p.append(("erreur", f"executable, mais les lignes dans le bon ordre ne compilent pas : "
                                    f"{exc.msg} (ligne {exc.lineno})"))
        return p


class Appariement(Question):
    """``saisie`` = pour chaque élément de gauche, l'indice de son élément de droite (``paires`` puis ``distracteurs``), ou ``None``."""

    type = "appariement"

    devinable = True

    def __init__(self, id, enonce, paires, distracteurs=None, **commun):
        super().__init__(id, enonce, **commun)
        self.paires, self.distracteurs = paires, distracteurs or []
        self._construire()

    def juste(self):
        return list(range(len(self.paires)))

    def corriger(self, saisie):
        saisie = saisie or [None] * len(self.paires)
        return sum(saisie[i] == i for i in range(len(self.paires))) / len(self.paires), None

    def _attendu(self):
        return "\n".join(f"- {p.gauche} → {p.droite}" for p in self.paires)

    def problemes(self):
        gauches = [p.gauche for p in self.paires]
        return super().problemes() + ([("erreur", "éléments de gauche en double")] if len(gauches) != len(set(gauches)) else [])


class PointSelection(Question):
    """``saisie`` = [x, y], en pixels de l'image d'origine."""

    type = "point_selection"

    def __init__(self, id, enonce, image, zones, **commun):
        super().__init__(id, enonce, **commun)
        self.image, self.zones = image, zones
        self._construire()

    def juste(self):
        return self.zones[0].centre()

    def corriger(self, saisie):
        return (1 if saisie and any(z.contient(*saisie) for z in self.zones) else 0), None

    def _attendu(self):
        return "Zones attendues, en pixels : " + "; ".join(z.decrire() for z in self.zones)

    def problemes(self):
        return super().problemes() + ([("avert", "seconde_chance sans effet, pas d'indice possible sur une sélection de point")]
                                      if self.seconde_chance and self.seconde_chance.actif else [])


class Dessin(Question):
    """``saisie`` = [[source, cible, étiquette], …] : les arêtes tracées par l'élève entre des sommets que le
    professeur a NOMMÉS ET PLACÉS. C'est ce qui rend la correction possible sans comparer deux graphes à un
    isomorphisme près : les arêtes se comparent en ensembles. Un arbre binaire est le cas où les étiquettes sont
    « g » et « d », un automate celui où les sommets portent une ``marque`` et les arêtes les lettres de l'alphabet,
    un circuit logique celui où les sommets sont des portes nommées.
    ``decor`` : des arêtes DONNÉES, tracées en gris clair et que l'élève ne peut ni créer ni effacer. C'est ce qui
    permet de demander un chemin dans un réseau déjà tracé, ou la suite d'un arbre dont le début est fourni."""

    type = "dessin"

    def __init__(self, id, enonce, sommets, aretes=None, oriente=False, etiquettes=None, image="", decor=None,
                 mode="aretes", chemins=None, parcours=None, designes=None, couleurs=0, propriete="", poids=None,
                 appareils=None, table=None, groupes=None, grille=None, **commun):
        super().__init__(id, enonce, **commun)
        self.sommets, self.aretes, self.oriente = sommets, aretes or [], oriente
        self.etiquettes, self.image, self.decor = etiquettes or [], image, decor or []
        # ``mode`` « chemin » : l'élève clique des sommets dans l'ordre, ``saisie`` = [nom, …]. Les ordres acceptés sont
        # ``chemins`` (énumérés), ou ``parcours`` = {type: largeur | profondeur, depart}, vérifié sur le graphe du
        # ``decor`` : tous les ordres valides passent sans qu'on les écrive. Crédit : le plus long début juste.
        self.mode, self.chemins, self.parcours = mode, chemins or [], parcours
        # ``mode`` « sommets » : l'élève clique les sommets de la réponse, sans ordre (un sous-arbre, les feuilles, les
        # nœuds d'un niveau) ; ``designes`` = ceux attendus. Un sommet en trop coûte autant qu'un sommet manquant.
        self.designes = designes or []
        # ``mode`` « coloration » : un clic sur un sommet fait défiler les ``couleurs`` (0 à couleurs − 1), ``saisie`` =
        # {nom: couleur}. Noté sur la contrainte (aucune arête du ``decor`` entre deux sommets de même couleur), pas sur
        # une coloration écrite : toutes celles qui conviennent passent.
        self.couleurs = couleurs
        # ``propriete`` « partition » (mode « coloration », ``decor`` dessiné mais pas noté) : l'élève range des sommets en
        # groupes, une couleur par groupe, ``groupes`` = les groupes attendus [[sommet, …], …] ; noté comme un ensemble
        # d'ensembles (les couleurs sont interchangeables), un sommet dans un seul groupe : un routeur membre de plusieurs
        # sous-réseaux s'y dessine en une interface par sous-réseau. Un sommet absent de ``groupes`` reste sans couleur.
        self.groupes = groupes or []
        # ``propriete`` (mode « arbre ») : « huffman » ou « shannon_fano », un arbre de codage noté sur l'algorithme et
        # non sur les ``aretes`` (qui en donnent UN, celui du corrigé) : égalités départagées autrement, tous les arbres
        # que l'algorithme peut produire passent. ``poids`` = {symbole: occurrences}, les feuilles ; les autres sommets
        # sont les nœuds internes, et celui dont le nom est un nombre doit porter le poids de son sous-arbre.
        self.propriete, self.poids = propriete, poids or {}
        # ``propriete`` « reseau » (mode « aretes ») : un schéma de réseau, ``appareils`` = {sommet: routeur, switch, hub,
        # machine ou machine:<réseau>} ; noté sur ses propriétés (``_corriger_reseau``), les ``aretes`` en sont UN exemple.
        # Les appareils en surnombre (un hub et un switch posés au choix) peuvent rester sans câble
        self.appareils = appareils or {}
        # ``propriete`` « circuit » (mode « aretes », oriente) : un circuit logique, ``appareils`` = {sommet: entree, sortie,
        # et, ou, xor ou non}, les portes posées en réserve parmi lesquelles l'élève choisit ; ``table`` = la table de
        # vérité attendue {"01": 1, …}, une clé par combinaison des entrées prises dans l'ordre des sommets. Noté sur la
        # table du circuit obtenu (``_corriger_circuit``), les ``aretes`` en sont UN exemple.
        self.table = table or {}
        # ``grille`` = [haut, long] (mode « aretes », non orienté) : un labyrinthe, dessiné en cellules et en murs ; les
        # sommets sont les cellules « ligne,colonne » ((0,0) en haut à gauche, comme au bac), une arête est un mur ouvert
        # entre deux cellules voisines, que l'élève ouvre ou referme d'un clic. Notée comme toute liste d'arêtes.
        self.grille = grille or []
        self._construire()

    def juste(self):
        if self.mode == "chemin":
            return [str(n) for n in self.chemins[0]] if self.chemins else self._un_parcours()
        if self.mode == "sommets":
            return [str(n) for n in self.designes]
        if self.mode == "coloration":
            return {str(n): i for i, g in enumerate(self.groupes) for n in g} if self.propriete == "partition" else self.une_coloration() or {}
        return self._attendues()

    def _attendues(self):
        """Les arêtes que l'élève doit poser ; en mode arbre sans ``decor``, la racine en tête : ["", racine, ""]."""
        aretes = [[a.source, a.cible, a.etiquette] for a in self.aretes]
        return ([["", str(self.racine()), ""]] if self.mode == "arbre" and not self.decor else []) + aretes

    # -- mode « arbre » : l'élève pose chaque valeur en fils d'un nœud déjà posé, l'arbre se dispose tout seul

    def cotes(self):
        """Les côtés d'un fils : g et d pour un arbre binaire ; pour un arbre n-aire (trie), les ``etiquettes`` des
        branches, que l'élève choisit en ajoutant l'enfant."""
        return [str(e) for e in self.etiquettes] or ["g", "d"]

    def racine(self):
        """Le nœud que rien ne porte, dans le décor et les arêtes attendues ; à défaut d'arête, le premier sommet."""
        aretes = self.decor + self.aretes
        enfants = {a.cible for a in aretes}
        return next((a.source for a in aretes if a.source not in enfants), self.sommets[0].nom if self.sommets else "")

    def disposes(self, marge):
        """Les sommets à leur place : la leur, ou, quand aucun n'en a (un arbre du décor, dont les nœuds ne sont pas
        placés à la main), celle de l'arbre disposé comme en mode « arbre », décalée de ``marge`` pixels."""
        if any(s.x or s.y for s in self.sommets) or not self.decor:
            return self.sommets
        positions = self.agencement([[a.source, a.cible, a.etiquette] for a in self.decor], vides=False)[0]
        return [Sommet(s.nom, x + marge, y + marge, s.marque, s.texte)
                for s in self.sommets for x, y in [positions.get(str(s.nom), (0, 0))]]

    def agencement(self, aretes, vides=True, vide=32):
        """Les positions d'un arbre décrit par ses arêtes [parent, enfant, côté] (et ["", racine, ""]), en pixels,
        haut de la racine à y = 0 : {nom: (x, y)}, et les emplacements libres [(parent, côté, x, y)] où poser un fils.
        Chaque feuille et chaque emplacement prend sa largeur de gauche à droite, un parent se centre sur ses enfants :
        un fils gauche est donc toujours à gauche de son père. ``vides`` : un emplacement sous chaque nœud (la toile) ;
        sinon seulement l'autre côté d'un fils unique d'arbre binaire, invisible, pour qu'on voie s'il est à gauche
        ou à droite (le corrigé imprimé)."""
        long = max([8 * len(s.libelle()) for s in self.sommets] or [0])  # un nom plus large que son cercle s'écrit
        # dessous : chaque nœud prend sa largeur, et un étage de plus la place du nom, au-dessus des arêtes qui partent
        noeud, etage = max(50, long + 12), 64 if long <= 38 else 86
        cotes = self.cotes()
        binaire = cotes == ["g", "d"]
        enfants, racines = {}, []
        for parent, enfant, cote in aretes:
            if parent == "":
                racines.append(enfant)
            else:
                enfants.setdefault(str(parent), []).append((str(cote), enfant))
        if not racines:  # le décor donné : sa racine
            portes = {str(e) for _, e, _ in aretes}
            racines = [p for p, _, _ in aretes if str(p) not in portes][:1]
        positions, places, curseur = {}, [], [0]

        def poser(nom, profondeur):
            fils = dict(enfants.get(str(nom), []))
            if binaire:  # un côté libre sous chaque nœud ; au corrigé, seulement celui qui situe un fils unique
                suite = [c for c in cotes if c in fils or vides or len(fils) == 1]
            else:  # les enfants dans l'ordre des étiquettes, puis « + » pour en ajouter un
                suite = sorted(fils, key=lambda c: cotes.index(c) if c in cotes else len(cotes)) + (["+"] if vides else [])
            xs = []
            for cote in suite:
                if cote in fils:
                    xs.append(poser(fils[cote], profondeur + 1))
                else:  # un emplacement : la largeur d'un nœud en n-aire, où il est seul sous son père
                    large = vide if binaire else noeud
                    xs.append(curseur[0] + large / 2)
                    curseur[0] += large
                    if vides:
                        places.append((str(nom), cote, xs[-1], (profondeur + 1) * etage))
            if not xs:  # une feuille sans emplacement : sa propre largeur
                xs, curseur[0] = [curseur[0] + noeud / 2], curseur[0] + noeud
            positions[str(nom)] = ((xs[0] + xs[-1]) / 2, profondeur * etage)
            return positions[str(nom)][0]

        for r in racines:
            poser(r, 0)
        return positions, places

    def libelles(self):
        """nom -> ce qui s'affiche."""
        return {str(s.nom): s.libelle() for s in self.sommets}

    def formes(self, triples):
        """Un arbre [parent, enfant, côté] vu par sa forme étiquetée : {chemin des côtés depuis la racine: texte}. Deux
        arbres qui ne diffèrent que par les noms de sommets de même texte y sont égaux : c'est ainsi qu'on juge un arbre
        dont les textes se répètent (1.42 des widgets de bac, l'arbre de décision réduit), sans isomorphisme à chercher —
        le côté de chaque fils le situe."""
        textes, enfants, racines = self.libelles(), {}, []
        for parent, enfant, cote in triples:
            if parent == "":
                racines.append(str(enfant))
            else:
                enfants.setdefault(str(parent), []).append((str(cote), str(enfant)))
        if not racines:  # le décor seul : sa racine
            portes = {str(e) for _, e, _ in triples}
            racines = [str(p) for p, _, _ in triples if str(p) not in portes][:1]
        formes, vus, pile = {}, set(), [((), r) for r in racines[:1]]
        while pile:
            chemin, nom = pile.pop()
            if nom not in vus:  # une saisie bouclée ne tourne pas sans fin
                vus.add(nom)
                formes[chemin] = textes.get(nom, nom)
                pile += [((*chemin, c), e) for c, e in enfants.get(nom, [])]
        return formes

    def _attendu_arbre(self):
        if any(s.texte for s in self.sommets):  # des textes répétés : « fils gauche de + » ne désignerait rien
            formes, cotes = self.formes([[a.source, a.cible, a.etiquette] for a in self.decor] + self._attendues()), self.cotes()
            noms = {"g": "gauche", "d": "droit"}
            return "\n".join("  " * len(c) + "- " + (f"{noms.get(c[-1], c[-1])} : " if c else "") + t for c, t in
                             sorted(formes.items(), key=lambda ct: [cotes.index(c) for c in ct[0] if c in cotes]))
        cotes = {"g": "fils gauche", "d": "fils droit"}
        return "\n".join(f"- {e} : racine" if p == "" else f"- {e} : {cotes.get(c, 'enfant « ' + str(c) + ' »')} de {p}"
                         for p, e, c in self._attendues())

    # -- mode « arbre », ``propriete`` : un arbre de codage

    def _corriger_codage(self, saisie):
        """La part des regroupements justes. Huffman : on rejoue l'algorithme sur l'arbre posé, en fusionnant à chaque
        tour deux frères dont les poids sont les deux plus petits du moment (lesquels, en cas d'égalité, n'importe pas) ;
        la note est le nombre de fusions avant le premier blocage. Shannon-Fano : chaque nœud interne sépare ses symboles,
        rangés par poids croissant, en deux groupes de totaux les plus proches possibles, les plus petits poids du côté
        de la première étiquette ; chaque nœud est jugé sur les symboles qu'il porte, la racine devant les porter tous."""
        poids, cotes = {str(k): v for k, v in self.poids.items()}, self.cotes()
        enfants, racine = {}, None
        for parent, enfant, cote in saisie or []:
            if parent == "":
                racine = str(enfant)
            else:
                enfants.setdefault(str(parent), {})[str(cote)] = str(enfant)
        feuilles = {}

        def descendre(nom):
            if nom not in feuilles:  # une saisie bouclée ne tourne pas sans fin
                feuilles[nom] = [nom] if nom in poids else []
                for e in enfants.get(nom, {}).values():
                    feuilles[nom] = feuilles[nom] + descendre(e)
            return feuilles[nom]
        if racine:
            descendre(racine)
        total = lambda nom: sum(poids[f] for f in feuilles.get(nom, [nom]) if f in poids)
        libelles = self.libelles()

        def interne(nom):  # deux enfants, et le poids écrit dans son nom s'il en porte un
            texte = libelles.get(nom, nom).strip()
            juste = not re.fullmatch(r"\d+([.,]\d+)?", texte) or float(texte.replace(",", ".")) == total(nom)
            return nom not in poids and len(enfants.get(nom, {})) == 2 and juste
        attendus, justes = len(poids) - 1, 0
        if self.propriete == "huffman":
            actifs, parents = set(poids), {e: p for p, fils in enfants.items() for e in fils.values()}
            while len(actifs) > 1:
                w = sorted(total(n) for n in actifs)[:2]
                paire = next((p for p in {parents.get(n) for n in actifs} if p and interne(p)
                              and set(enfants[p].values()) <= actifs
                              and sorted(total(e) for e in enfants[p].values()) == w), None)
                if paire is None:
                    break
                actifs = actifs - set(enfants[paire].values()) | {paire}
                justes += 1
        else:
            pile = [(racine, set(poids))] if racine else []
            while pile:
                nom, confies = pile.pop()
                fils = enfants.get(nom, {})
                bonne = interne(nom) and set(feuilles[nom]) == confies and set(fils) == set(cotes[:2])
                if bonne:
                    petits, grands = ([poids[f] for f in feuilles[fils[c]]] for c in cotes[:2])
                    ranges = sorted(petits + grands)
                    ecart = min(abs(2 * sum(ranges[:i]) - sum(ranges)) for i in range(1, len(ranges)))
                    bonne = bool(petits and grands) and max(petits) <= min(grands) and abs(sum(petits) - sum(grands)) == ecart
                justes += bonne
                pile += [(e, set(feuilles[e])) for e in fils.values() if e not in poids]  # chacun sur ce qu'il a reçu
        note = justes / attendus
        return note, (None if note == 1 else f"{justes} regroupement{'s' * (justes > 1)} sur {attendus} conforme"
                                             f"{'s' * (justes > 1)} à l'algorithme")

    # -- mode « chemin »

    def voisins(self):
        """Le graphe du ``decor`` : nom -> voisins, dans l'ordre du décor ; noms en texte, comme la saisie."""
        graphe = {str(s.nom): [] for s in self.sommets}
        for a in self.decor:
            graphe.setdefault(str(a.source), []).append(str(a.cible))
            if not self.oriente:
                graphe.setdefault(str(a.cible), []).append(str(a.source))
        return graphe

    def _un_parcours(self):
        """Un ordre de ``parcours`` valide, voisins pris dans l'ordre du décor : celui du corrigé et de ``--auto``."""
        graphe, depart = self.voisins(), str((self.parcours or {}).get("depart"))
        if depart not in graphe:
            return []
        if self.parcours.get("type") == "largeur":
            ordre = [depart]
            for u in ordre:
                ordre += [v for v in graphe[u] if v not in ordre]
            return ordre
        ordre = []

        def visiter(u):
            ordre.append(u)
            for v in graphe[u]:
                if v not in ordre:
                    visiter(v)
        visiter(depart)
        return ordre

    def debut_de_parcours(self, saisie):
        """La longueur du plus long début de ``saisie`` qui suit un parcours valide, et celle d'un parcours complet.
        Largeur : les voisins non encore vus du sommet en tête de file arrivent ensemble, dans n'importe quel ordre.
        Profondeur (récursive) : chaque sommet est un voisin non vu du plus profond sommet qui en a encore."""
        graphe, depart = self.voisins(), str(self.parcours.get("depart"))
        attendu = len(self._un_parcours())
        if not saisie or saisie[0] != depart:
            return 0, attendu
        vus, n = [depart], 1
        if self.parcours.get("type") == "largeur":
            for u in vus:
                a_voir = list(dict.fromkeys(v for v in graphe.get(u, []) if v not in vus))
                while a_voir and n < len(saisie) and saisie[n] in a_voir:
                    a_voir.remove(saisie[n])
                    vus.append(saisie[n])
                    n += 1
                if a_voir:
                    break
            return n, attendu
        pile = [depart]
        while n < len(saisie) and pile:
            while pile and not [v for v in graphe.get(pile[-1], []) if v not in vus]:
                pile.pop()
            if not pile or saisie[n] not in graphe.get(pile[-1], []) or saisie[n] in vus:
                break
            vus.append(saisie[n])
            pile.append(saisie[n])
            n += 1
        return n, attendu

    def _corriger_chemin(self, saisie):
        saisie = [str(s) for s in saisie or []]
        if self.parcours:
            n, attendu = self.debut_de_parcours(saisie)
            return n / max(attendu, len(saisie), 1)
        notes = [0]
        for chemin in self.chemins:
            chemin = [str(s) for s in chemin]
            n = next((i for i, (a, b) in enumerate(zip(chemin, saisie)) if a != b), min(len(chemin), len(saisie)))
            notes.append(n / max(len(chemin), len(saisie), 1))
        return max(notes)

    # -- mode « coloration »

    def une_coloration(self):
        """Une coloration du graphe du ``decor`` en ``couleurs`` couleurs, la plus petite couleur libre d'abord, sommets
        les plus contraints d'abord (retour arrière : les graphes d'un sujet ont une dizaine de sommets) ; ``None`` s'il
        n'y en a pas."""
        graphe, couleur = self.voisins(), {}

        def colorer():
            libres = [s for s in graphe if s not in couleur]
            if not libres:
                return True
            s = max(libres, key=lambda s: (len({couleur[v] for v in graphe[s] if v in couleur}), len(graphe[s])))
            for c in range(self.couleurs):
                if all(couleur.get(v) != c for v in graphe[s]):
                    couleur[s] = c
                    if colorer():
                        return True
                    del couleur[s]
            return False
        return {s: couleur[s] for s in graphe} if colorer() else None

    def _groupes_saisis(self, saisie):
        """Les groupes que dessine ``saisie`` ({sommet: couleur}) : l'ensemble des ensembles de sommets de même couleur."""
        rangs = {}
        for n, c in (saisie or {}).items():
            if isinstance(c, int) and 0 <= c < self.couleurs:
                rangs.setdefault(c, set()).add(str(n))
        return {frozenset(g) for g in rangs.values()}

    def _corriger_partition(self, saisie):
        """La part des groupes attendus que l'élève a faits EXACTEMENT, divisée par le plus grand des deux nombres de
        groupes : un groupe en trop coûte autant qu'un groupe manquant. Le message compte, sans dire lesquels."""
        obtenus, attendus = self._groupes_saisis(saisie), {frozenset(map(str, g)) for g in self.groupes}
        justes = len(obtenus & attendus)
        faux = len(obtenus) - justes
        return justes / max(len(obtenus), len(attendus)), "; ".join(filter(None, [
            f"{len(attendus) - justes} groupe{'s' * (len(attendus) - justes > 1)} attendu{'s' * (len(attendus) - justes > 1)} "
            "non formé" + "s" * (len(attendus) - justes > 1) if justes < len(attendus) else "",
            f"{faux} groupe{'s' * (faux > 1)} formé{'s' * (faux > 1)} à tort" if faux else ""])) or None

    def _corriger_coloration(self, saisie):
        """La part des arêtes du ``decor`` dont les deux bouts sont colorés différemment (un bout sans couleur ne compte
        pas). Le message compte ce qui manque, sans dire quoi changer."""
        saisie = {str(n): c for n, c in (saisie or {}).items() if isinstance(c, int) and 0 <= c < self.couleurs}
        sommets = [str(s.nom) for s in self.sommets]
        aretes = {tuple(sorted((str(a.source), str(a.cible)))) for a in self.decor}
        sans = [s for s in sommets if s not in saisie]
        conflits = sum(1 for a, b in aretes if a in saisie and saisie.get(a) == saisie.get(b))
        bonnes = sum(1 for a, b in aretes if a in saisie and b in saisie and saisie[a] != saisie[b])
        note = bonnes / len(aretes)  # un decor vide est refusé par problemes
        if sans and note == 1:  # un sommet isolé sans couleur : la coloration n'est pas complète
            note = (len(sommets) - len(sans)) / len(sommets)
        message = "; ".join(filter(None, [
            f"{len(sans)} sommet{'s' * (len(sans) > 1)} sans couleur" if sans else "",
            f"{conflits} arête{'s' * (conflits > 1)} entre deux sommets de même couleur" if conflits else ""]))
        return note, message or None

    def cle(self, source, cible, etiquette=""):
        """La forme comparable d'une arête : non orientée, les deux bouts sont interchangeables."""
        bouts = (str(source), str(cible)) if self.oriente or self.mode == "arbre" else tuple(sorted((str(source), str(cible))))
        return (*bouts, normaliser(etiquette))

    def corriger(self, saisie):
        """Une arête en trop coûte autant qu'une arête manquante : sinon, tout relier vaudrait la note maximale. Un
        chemin trop long est divisé par sa longueur : sinon, poursuivre au hasard après la fin ne coûterait rien."""
        if self.mode == "chemin":
            return self._corriger_chemin(saisie), None
        if self.mode == "coloration":
            return self._corriger_partition(saisie) if self.propriete == "partition" else self._corriger_coloration(saisie)
        if self.mode == "arbre" and self.propriete:
            return self._corriger_codage(saisie)
        if self.propriete == "reseau":
            return self._corriger_reseau(saisie)
        if self.propriete == "circuit":
            return self._corriger_circuit(saisie)
        if self.mode == "arbre" and any(s.texte for s in self.sommets):  # par la forme : chaque nœud à sa place
            donne = [[a.source, a.cible, a.etiquette] for a in self.decor]
            fixes = self.formes(donne) if donne else {}
            attendus, poses = [{c: t for c, t in self.formes(donne + list(triples)).items() if c not in fixes}
                               for triples in (self._attendues(), saisie or [])]
            justes = sum(poses.get(c) == t for c, t in attendus.items())
            return (max(0, (justes - (len(poses) - justes)) / len(attendus)) if attendus else None), None
        if self.mode == "sommets":
            choisis, attendus = {str(n) for n in saisie or []}, set(self.juste())
            justes = len(choisis & attendus)
            return (max(0, (justes - (len(choisis) - justes)) / len(attendus)) if attendus else None), None
        restantes, justes = [self.cle(*a) for a in self._attendues()], 0
        attendues = len(restantes)
        tracees = [self.cle(*a) for a in (saisie or [])]
        for cle in tracees:
            if cle in restantes:
                restantes.remove(cle)
                justes += 1
        return (max(0, (justes - (len(tracees) - justes)) / attendues) if attendues else None), None

    def genre(self, nom):
        """Le type d'appareil d'un sommet (``appareils``), sans le réseau d'une machine : routeur, switch, hub, machine."""
        return str(self.appareils.get(nom, "")).partition(":")[0]

    def _corriger_reseau(self, saisie):
        """Une note par machine bien raccordée : un seul câble, vers un switch ou un hub ; de là, sans traverser de
        routeur, un routeur atteint et aucune machine d'un autre réseau. Le message compte les machines fautives par
        défaut, sans dire où brancher quoi."""
        voisins = {str(s.nom): set() for s in self.sommets}
        for a, b in [(x.source, x.cible) for x in self.decor] + [(s[0], s[1]) for s in saisie or []]:
            if str(a) != str(b) and str(a) in voisins and str(b) in voisins:
                voisins[str(a)].add(str(b))
                voisins[str(b)].add(str(a))
        machines = [n for n in voisins if self.genre(n) == "machine"]
        defauts = {"cable": 0, "appareil": 0, "routeur": 0, "melange": 0}
        for m in machines:
            if len(voisins[m]) != 1:
                defauts["cable"] += 1
                continue
            if self.genre(next(iter(voisins[m]))) not in ("switch", "hub"):
                defauts["appareil"] += 1
                continue
            segment, pile = {m}, [m]
            while pile:
                for v in voisins[pile.pop()] - segment:
                    if self.genre(v) != "routeur":
                        segment.add(v)
                        pile.append(v)
            if not any(self.genre(v) == "routeur" for n in segment for v in voisins[n]):
                defauts["routeur"] += 1
            elif len({str(self.appareils[n]) for n in segment if self.genre(n) == "machine"}) > 1:
                defauts["melange"] += 1
        textes = {"cable": ("n'a", "n'ont", "pas exactement un câble"), "appareil": ("n'est pas reliée", "ne sont pas reliées", "à un switch ou un hub"),
                  "routeur": ("n'atteint", "n'atteignent", "aucun routeur"),
                  "melange": ("partage son switch", "partagent leur switch", "avec une machine d'un autre réseau")}
        message = "; ".join(f"{k} machine{'s' * (k > 1)} {textes[d][k > 1]} {textes[d][2]}" for d, k in defauts.items() if k)
        return (len(machines) - sum(defauts.values())) / len(machines), message or None

    ARITES = {"non": (1, 1), "et": (2, 9), "ou": (2, 9), "xor": (2, 2)}  # nombre d'entrées permis d'une porte

    def _entrees_circuit(self):
        """Les sommets d'entrée, dans l'ordre où la ``table`` lit leurs bits."""
        return [str(s.nom) for s in self.sommets if self.genre(s.nom).lower() == "entree"]

    def _corriger_circuit(self, saisie):
        """La table de vérité du circuit tracé, comparée à ``table`` : une note par ligne juste. Une arête se lit dans le
        sens où elle est possible (une entrée ne reçoit rien, la sortie ne donne rien) ; seules comptent les portes
        reliées à la sortie. Un défaut de câblage (porte sans ses entrées, sortie libre, boucle) rend toutes les lignes
        fausses et se dit sans nommer la porte ; sinon le message compte les lignes fausses, sans dire lesquelles."""
        genre = {str(s.nom): self.genre(s.nom).lower() for s in self.sommets}
        recoit = {n: [] for n in genre}
        for a, b in [(str(x[0]), str(x[1])) for x in saisie or []]:
            if a not in genre or b not in genre or a == b:
                continue
            if genre[b] == "entree" or genre[a] == "sortie":
                a, b = b, a
            if genre[b] != "entree" and genre[a] != "sortie" and a not in recoit[b]:
                recoit[b].append(a)
        defauts = set()

        def valeur(nom, bits, en_cours):
            if genre[nom] == "entree":
                return bits[nom]
            if nom in en_cours:
                defauts.add("une boucle")
                return None
            sources = recoit[nom]
            mini, maxi = self.ARITES.get(genre[nom], (1, 1))  # la sortie : un seul fil
            if not mini <= len(sources) <= maxi:
                defauts.add("la sortie n'a pas exactement un fil" if genre[nom] == "sortie" else "une porte n'a pas le bon nombre d'entrées")
                return None
            entrees = [valeur(n, bits, en_cours | {nom}) for n in sources]
            if None in entrees:
                return None
            return {"sortie": lambda e: e[0], "non": lambda e: 1 - e[0], "et": all, "ou": any,
                    "xor": lambda e: e[0] ^ e[1]}[genre[nom]](entrees) * 1

        sortie = next(n for n, g in genre.items() if g == "sortie")
        noms = self._entrees_circuit()
        justes = sum(valeur(sortie, dict(zip(noms, map(int, cle))), frozenset()) == attendu for cle, attendu in self.table.items())
        if defauts:
            return 0, "; ".join(sorted(defauts))
        fausses = len(self.table) - justes
        return justes / len(self.table), (f"{fausses} ligne{'s' * (fausses > 1)} de la table de vérité "
                                          f"{'sont fausses' if fausses > 1 else 'est fausse'}" if fausses else None)

    def _attendu(self):
        if self.propriete == "circuit":
            noms = self._entrees_circuit()
            return (f"Un circuit dont la sortie vaut, pour ({', '.join(noms)}) :\n"
                    + "\n".join(f"- {', '.join(cle)} → {v}" for cle, v in self.table.items())
                    + "\nPar exemple :\n" + "\n".join(f"- {a.source} → {a.cible}" for a in self.aretes))
        if self.propriete == "reseau":
            return ("Chaque machine reliée par un seul câble à un switch ou un hub, relié au routeur (directement ou par "
                    "d'autres switchs), sans machine d'un autre réseau ; par exemple :\n"
                    + "\n".join(f"- {a.source} — {a.cible}" for a in self.aretes))
        if self.mode == "chemin":
            if self.parcours:
                nom = {"largeur": "en largeur", "profondeur": "en profondeur"}.get(self.parcours.get("type"), "")
                return f"Un parcours {nom} depuis {self.parcours.get('depart')}, par exemple : " + " → ".join(map(str, self.juste()))
            return "\n".join("- " + " → ".join(map(str, c)) for c in self.chemins)
        if self.mode == "arbre" and self.propriete:
            nom = {"huffman": "de Huffman", "shannon_fano": "de Shannon-Fano"}[self.propriete]
            return (f"Un arbre possible :\n{self._attendu_arbre()}\nTout arbre que l'algorithme {nom} peut produire est "
                    "accepté (égalités départagées autrement).")
        if self.mode == "arbre":
            return self._attendu_arbre()
        if self.mode == "sommets":
            return "Sommets : " + ", ".join(self.juste())
        if self.propriete == "partition":
            return "Groupes attendus : " + " ; ".join("{" + ", ".join(map(str, g)) + "}" for g in self.groupes)
        if self.mode == "coloration":
            return (f"Deux sommets reliés n'ont jamais la même couleur (0 à {self.couleurs - 1}), par exemple : "
                    + ", ".join(f"{s} : {c}" for s, c in self.juste().items()))
        fleche = "→" if self.oriente else "—"
        return "\n".join(f"- {a.source} {fleche} {a.cible}" + (f" ({a.etiquette})" if a.etiquette else "")
                         for a in self.aretes)

    def _problemes_partition(self, noms):
        vus = [str(n) for g in self.groupes for n in g]
        p = [("erreur", f"groupes : sommet « {n} » inconnu") for n in vus if n not in map(str, noms)]
        p += [("erreur", f"groupes : sommet « {n} » dans deux groupes, un sommet n'a qu'une couleur") for n in sorted(set(vus)) if vus.count(n) > 1]
        if len(self.groupes) < 2:
            p.append(("erreur", "partition : groupes attendus, au moins 2"))
        elif self.couleurs < len(self.groupes):
            p.append(("erreur", f"partition : {len(self.groupes)} groupes mais {self.couleurs} couleurs seulement"))
        return p

    def _problemes_arbre(self):
        p, cotes, portes, places = [], self.cotes(), {}, set()
        for a in self.decor + self.aretes:
            if str(a.etiquette) not in cotes:
                p.append(("erreur", f"arbre : arête {a.source}-{a.cible}, côté « {a.etiquette} » hors de {', '.join(cotes)}"))
            if a.cible in portes:
                p.append(("erreur", f"arbre : {a.cible} a deux parents"))
            portes[a.cible] = a.source
            if (a.source, a.etiquette) in places:
                p.append(("erreur", f"arbre : {a.source} a deux enfants du côté « {a.etiquette} »"))
            places.add((a.source, a.etiquette))
        racines = {a.source for a in self.decor + self.aretes if a.source not in portes}
        if len(racines) > 1:
            p.append(("erreur", f"arbre : plusieurs racines ({', '.join(map(str, sorted(map(str, racines))))})"))
        elif portes and not racines:
            p.append(("erreur", "arbre : un cycle, pas de racine"))
        if self.decor and not self.aretes:
            p.append(("erreur", "arbre : aucune arête attendue après le décor, la question ne peut pas être corrigée"))
        if self.oriente:
            p.append(("avert", "mode arbre : oriente sans effet, l'arbre se lit toujours de la racine vers les feuilles"))
        if self.propriete:
            p += self._problemes_codage()
        return p

    def _problemes_codage(self):
        if self.propriete not in ("huffman", "shannon_fano"):
            return [("erreur", f"propriete « {self.propriete} » : huffman ou shannon_fano")]
        noms = {str(s.nom) for s in self.sommets}
        p = [("erreur", f"poids : symbole « {n} » sans sommet") for n in self.poids if str(n) not in noms]
        if len(self.poids) < 2 or len(self.cotes()) != 2 or self.decor:
            p.append(("erreur", "propriete : au moins deux symboles dans poids, deux etiquettes (0 et 1), pas de decor"))
        elif len(noms) - len(self.poids) != len(self.poids) - 1:
            p.append(("erreur", f"propriete : {len(self.poids)} symboles demandent {len(self.poids) - 1} nœuds internes, "
                                f"il y en a {len(noms) - len(self.poids)}"))
        elif not p and self.corriger(self.juste())[0] != 1:
            p.append(("erreur", f"propriete : l'arbre des aretes n'est pas un arbre de {self.propriete}"))
        return p

    def _problemes_reseau(self):
        noms = {str(s.nom) for s in self.sommets}
        p = [("erreur", f"appareils : sommet « {n} » inconnu") for n in self.appareils if str(n) not in noms]
        p += [("erreur", f"appareils : « {t} » pour {n}, attendu routeur, switch, hub ou machine[:réseau]")
              for n, t in self.appareils.items() if self.genre(n) not in ("routeur", "switch", "hub", "machine")
              or (self.genre(n) != "machine" and ":" in str(t))]
        p += [("erreur", f"appareils : sommet « {n} » sans type") for n in sorted(noms - set(map(str, self.appareils)))]
        if self.mode != "aretes" or self.oriente:
            p.append(("erreur", "propriete reseau : en mode aretes, non orienté"))
        elif not p and not any(self.genre(n) == "machine" for n in self.appareils):
            p.append(("erreur", "propriete reseau : aucune machine à raccorder"))
        elif not p and self.corriger(self.juste())[0] != 1:
            p.append(("erreur", f"propriete reseau : les aretes ne forment pas un réseau juste ({self.corriger(self.juste())[1]})"))
        return p

    def _problemes_circuit(self):
        noms = {str(s.nom) for s in self.sommets}
        genres = {str(n): self.genre(n).lower() for n in self.appareils}
        p = [("erreur", f"appareils : sommet « {n} » inconnu") for n in genres if n not in noms]
        p += [("erreur", f"appareils : « {t} » pour {n}, attendu entree, sortie, et, ou, xor ou non") for n, t in genres.items()
              if t not in ("entree", "sortie", *self.ARITES)]
        p += [("erreur", f"appareils : sommet « {n} » sans type") for n in sorted(noms - set(genres))]
        if self.mode != "aretes" or not self.oriente:
            p.append(("erreur", "propriete circuit : en mode aretes, oriente"))
        if p:
            return p
        entrees = self._entrees_circuit()
        if not entrees or list(genres.values()).count("sortie") != 1:
            return [("erreur", "propriete circuit : au moins une entrée et une seule sortie")]
        if sorted(self.table) != sorted(format(i, f"0{len(entrees)}b") for i in range(2 ** len(entrees))) \
                or any(v not in (0, 1) for v in self.table.values()):
            return [("erreur", f"table : une clé par combinaison des {len(entrees)} entrées (« {'0' * len(entrees)} »…), "
                               "valeur 0 ou 1")]
        if self.corriger(self.juste())[0] != 1:
            return [("erreur", f"propriete circuit : les aretes ne réalisent pas la table ({self.corriger(self.juste())[1]})")]
        return []

    def voisines(self, a, b):
        """Deux cellules « ligne,colonne » d'une ``grille`` qui partagent un mur."""
        (la, ca), (lb, cb) = (map(int, str(n).split(",")) for n in (a, b))
        return abs(la - lb) + abs(ca - cb) == 1

    def murs(self, ouverts):
        """Les murs intérieurs d'une ``grille`` encore debout quand les passages ``ouverts`` ([a, b, étiquette]) sont percés,
        chacun par ses deux bouts en pas de cellule depuis le coin haut gauche : (colonne, ligne). Le même tracé à
        l'écran (``ToileLabyrinthe``) et sur le papier (``figure_dessin``)."""
        haut, long = self.grille
        perces = {self.cle(*a[:2]) for a in ouverts}
        return ([((c + 1, l), (c + 1, l + 1)) for l in range(haut) for c in range(long - 1)
                 if self.cle(f"{l},{c}", f"{l},{c + 1}") not in perces]
                + [((c, l + 1), (c + 1, l + 1)) for l in range(haut - 1) for c in range(long)
                   if self.cle(f"{l},{c}", f"{l + 1},{c}") not in perces])

    def _problemes_grille(self, noms):
        p = []
        if len(self.grille) != 2 or not all(isinstance(n, int) and n >= 1 for n in self.grille) or self.grille == [1, 1]:
            return [("erreur", "grille : [haut, long], deux entiers ≥ 1, au moins deux cellules")]
        haut, long = self.grille
        cellules = {f"{l},{c}" for l in range(haut) for c in range(long)}
        if set(map(str, noms)) != cellules:
            p.append(("erreur", f"grille : les sommets sont exactement les {haut * long} cellules « ligne,colonne », de 0,0 à "
                                f"{haut - 1},{long - 1}"))
        elif any(not self.voisines(a.source, a.cible) for a in self.aretes):
            p.append(("erreur", "grille : une arête (un passage) relie deux cellules qui ne sont pas voisines"))
        if self.mode != "aretes" or self.oriente or self.propriete or self.decor or self.etiquettes:
            p.append(("erreur", "grille : en mode aretes seulement, non orienté, sans propriete, decor ni etiquettes"))
        return p

    def problemes(self):
        p = super().problemes()
        noms = [s.nom for s in self.sommets]
        if len(set(noms)) != len(noms):
            p.append(("erreur", "deux sommets portent le même nom : les arêtes ne désigneraient rien de sûr"))
        if self.mode not in ("aretes", "chemin", "arbre", "sommets", "coloration"):
            p.append(("erreur", f"mode « {self.mode} » : aretes, chemin, arbre, sommets ou coloration"))
        elif self.mode == "coloration":
            if not isinstance(self.couleurs, int) or self.couleurs < 2:
                p.append(("erreur", "mode coloration : couleurs, le nombre de couleurs permises, au moins 2"))
            elif self.propriete == "partition":
                p += self._problemes_partition(noms)
            elif not self.decor:
                p.append(("erreur", "mode coloration : le graphe à colorer est le decor, qui est vide"))
            elif self.une_coloration() is None:
                p.append(("erreur", f"mode coloration : le graphe ne se colore pas en {self.couleurs} couleurs"))
            if self.aretes or self.etiquettes:
                p.append(("avert", "mode coloration : aretes et etiquettes sans effet"))
        elif self.mode == "sommets":
            if not self.designes:
                p.append(("erreur", "mode sommets : designes vide, la question ne peut pas être corrigée"))
            p += [("erreur", f"designes : sommet « {n} » inconnu") for n in self.designes if n not in noms]
            if self.aretes or self.etiquettes:
                p.append(("avert", "mode sommets : aretes et etiquettes sans effet"))
        elif self.mode == "arbre":
            p += self._problemes_arbre()
        elif self.mode == "chemin":
            if bool(self.chemins) == bool(self.parcours):
                p.append(("erreur", "mode chemin : chemins OU parcours, l'un des deux"))
            for c in self.chemins:
                p += [("erreur", f"chemin : sommet « {n} » inconnu") for n in c if n not in noms]
            if self.parcours:
                if self.parcours.get("type") not in ("largeur", "profondeur"):
                    p.append(("erreur", "parcours : type largeur ou profondeur"))
                if self.parcours.get("depart") not in noms:
                    p.append(("erreur", f"parcours : départ « {self.parcours.get('depart')} » inconnu"))
                if not self.decor:
                    p.append(("erreur", "parcours : il se vérifie sur le graphe du decor, qui est vide"))
            if self.aretes or self.etiquettes:
                p.append(("avert", "mode chemin : aretes et etiquettes sans effet"))
        elif not self.aretes and self.mode != "arbre":  # un arbre réduit à sa racine se corrige sur elle
            p.append(("erreur", "aucune arête attendue, la question ne peut pas être corrigée"))
        if self.grille:
            p += self._problemes_grille(noms)
        if self.propriete == "reseau":
            p += self._problemes_reseau()
        elif self.propriete == "circuit":
            p += self._problemes_circuit()
        elif self.propriete == "partition":
            if self.mode != "coloration":
                p.append(("erreur", "propriete « partition » : seulement en mode coloration"))
        elif self.propriete and self.mode != "arbre":
            p.append(("erreur", "propriete : seulement en mode arbre (ou « reseau », « circuit » en mode aretes, « partition » en mode coloration)"))
        elif self.appareils:
            p.append(("avert", "appareils sans effet hors de propriete « reseau » ou « circuit »"))
        if self.table and self.propriete != "circuit":
            p.append(("avert", "table sans effet hors de propriete « circuit »"))
        for a in self.decor:
            if a.source not in noms or a.cible not in noms:
                p.append(("erreur", f"décor {a.source}-{a.cible} : sommet inconnu"))
        for a in self.aretes + self.decor:
            if a.source == a.cible:  # la toile n'en trace pas, l'élève ne peut donc pas la poser (choix du 24/09/2026)
                p.append(("erreur", f"arête {a.source}-{a.cible} : une boucle ne se dessine pas"))
        for a in self.aretes:
            if a.source not in noms or a.cible not in noms:
                p.append(("erreur", f"arête {a.source}-{a.cible} : sommet inconnu"))
            elif self.etiquettes and self.mode != "arbre" and a.etiquette not in [str(e) for e in self.etiquettes]:
                p.append(("erreur", f"arête {a.source}-{a.cible} : l'étiquette « {a.etiquette} » n'est pas proposée à l'élève"))
        for s in self.sommets:
            if s.marque not in ("", "initial", "final"):
                p.append(("erreur", f"sommet {s.nom} : marque « {s.marque} » inconnue (initial, final ou rien)"))
        if self.seconde_chance and self.seconde_chance.actif:
            p.append(("avert", "seconde_chance sans effet, pas d'indice possible sur un dessin"))
        return p


# retrait, début de ligne donné, et l'espace qui l'en sépare : la marque collée au début (« res# à compléter ») n'en
# impose aucune, l'élève continue le mot ou l'expression (« res.append(x) ») ; la même que celle du papier (exporter_pdf.py)
MARQUE_A_COMPLETER = re.compile(r"^( *)(.*?)( *)# à compléter *$")
MARQUE_A_MODIFIER = re.compile(r"^( *)(.*?) *# à modifier *$")
SOLUTION_CITEE = re.compile(r"(?m)^@solution[ \t]+(\S+)[ \t]*$")  # une ligne du prélude (``Code.solutions_citees``)


def sans_marque_modifier(code):
    """Le code donné tel que le papier l'imprime : chaque ligne « # à modifier » sans sa marque."""
    return "\n".join(m.group(1) + m.group(2) if (m := MARQUE_A_MODIFIER.match(l)) else l for l in code.split("\n"))


def remplir(fixes, morceaux):
    """Le texte des parties ``fixes`` avec, entre deux parties consécutives, les ``morceaux`` de l'élève."""
    return "".join(f + m for f, m in zip(fixes, [*morceaux, ""]))


def zones_du_gabarit(fixes, texte):
    """Les intervalles (début, fin) de ``texte`` où l'élève a écrit, si ``texte`` garde dans l'ordre et mot pour mot
    chacune des parties ``fixes`` (``Code.gabarit``) ; ``None`` s'il en a touché une."""
    m = re.fullmatch("(.*?)".join(re.escape(f) for f in fixes), texte, re.DOTALL)
    return [m.span(k) for k in range(1, len(fixes))] if m else None


class Code(Question):
    """``saisie`` = le code écrit ; corrigé par ``verifier.verifier_question`` (un sous-processus par question)."""

    type = "code"
    ordonne = False  # champ de ``Sql``, que ``verifier_question`` lit sur toute question de code

    def __init__(self, id, enonce, solution, langage="python", code_initial="", tests=None, tests_code="", fichier="",
                 lignes=10, erreurs=None, autorises=None, editeur_externe=False, lien="", prelude="", verrouille=False,
                 premiere_ligne=1, reprend=None, effet=False, observe=None, forme=None, fonction="", fichiers=None, commentaires=None, mutants=None, arborescence=None, verdict=None, trace_console=None, suite_de="", fige=None, **commun):
        super().__init__(id, enonce, **commun)
        self.solution, self.langage, self.code_initial, self.tests = solution, langage, code_initial, tests or []
        # la question ``code`` dont l'élève reprend ici son propre code (TP : il modifie son fichier d'une question à
        # l'autre) : tant qu'il n'a rien écrit, l'éditeur montre ce qu'il y a écrit, vide sinon, à la place de
        # ``code_initial``, qui donnerait la réponse de la précédente (l'utilisateur, 05/10/2026). ``origine`` (la
        # question, posée par le paquet) et ``suites`` (celles qui partent de celle-ci) ne s'enregistrent pas
        self.suite_de, self.origine, self.suites = suite_de, None, []
        # ce que l'éditeur d'une suite montrait quand elle a été close sans être touchée : il n'en bouge plus, même rouvert
        # avant la question citée (06/10/2026)
        self.fige = fige
        # le code supposé disponible, que l'élève ne voit pas : exécuté avant le sien, à la correction comme dans la
        # console (« @contexte » : les blocs de code des textes partagés que la question cite ; une ligne « @solution <id> » :
        # la solution d'une question précédente, prise dans ``reprises``) ; en sql, un script rejoué
        # après ``base``. ``verrouille`` : seules les lignes « # à compléter » de ``code_initial`` s'écrivent à l'écran
        self.prelude, self.verrouille = prelude, verrouille
        # le numéro qu'affiche l'éditeur pour la première ligne du code, celui des messages d'erreur avec lui : le
        # sujet cite « ligne 41 » d'un listing qui commence à 41, ou « ligne 3 » d'une méthode posée dans une classe
        # (premiere_ligne ≤ 0, les lignes de l'enveloppe restent sans numéro)
        self.premiere_ligne = premiere_ligne
        # les questions ``code`` dont ce code donné contient la solution (la « référence ») : la correction la garde,
        # l'écran la remplace par le code de l'élève à ces questions (``reprises``, posé par le paquet : id -> question),
        # le papier par une mention ; la question ne paraît qu'une fois ces questions closes (``revelations``)
        self.reprend, self.reprises = reprend or [], {}
        # « écrire l'instruction qui… » : la saisie est jugée par son EFFET, comparé à celui de la solution, chacune
        # exécutée après le prélude — ce qu'elle affiche (ou la valeur de sa dernière expression, comme la console
        # l'écrit), puis la valeur de chaque expression d'``observe`` (« panier1.contenu ») : toute écriture juste passe
        self.effet, self.observe = effet, observe or []
        # des contraintes de FORME sur le texte du code, une note de test chacune : « comprehension », « recursive:f »,
        # « iterative:f », « sans:sort », « avec:append », « sans:for », « sans:// » (``verifier.forme_manquee``) — ce que les tests de valeurs ne voient pas
        self.forme = forme or []
        # « écrire une fonction qui… » sans en imposer le nom : celui de la fonction de la solution, que les tests
        # appellent ; la fonction de l'élève, quel que soit son nom, le prend aussi (``verifier.fonction_choisie``)
        self.fonction = fonction
        # les fichiers de données que le sujet fournit au programme, {nom: contenu texte} (le csv qu'il lit) : écrits dans
        # son dossier avant chaque exécution, console comme correction (``verifier.deposer``) ; un « .db » est une base
        # SQLite, donnée par son script ou par le nom d'une base de la banque (``bases_connues``, ``poser_bases``)
        self.fichiers, self.bases_connues = fichiers or {}, {}
        # « compléter la ligne 10 par un commentaire » (verrouille) : pour chaque zone dont la solution est un commentaire,
        # dans l'ordre, les mots qu'il doit contenir, chacun avec ses variantes (« droit|gauche vide ») ; une note de
        # test par zone (``commentaires_manques``)
        self.commentaires = commentaires or []
        # « écrire un jeu de tests » : des versions fausses du code donné (``Mutant``), une note de test chacune, que
        # les ``assert`` de l'élève doivent faire échouer après avoir passé sur la vraie (``verifier.mutant_survit``)
        self.mutants = mutants or []
        # « os.mkdir », « os.chmod » : un système de fichiers SIMULÉ, {chemin relatif: droits octaux}, « / » final pour un
        # dossier ({"Contrats/": "755"}) ; « os » y est importable et doublé, l'arbre remis à cet état avant chaque test,
        # que les tests lisent par « arborescence() » (``verifier.SystemeSimule``)
        self.arborescence = arborescence or {}
        self.tests_code, self.fichier, self.lignes, self.erreurs = tests_code, fichier, lignes, erreurs or []
        self.autorises = autorises
        # le code s'écrit hors du lecteur (Pyxel Studio…), et l'énoncé le dit : ni éditeur ni console à l'écran
        self.editeur_externe = editeur_externe
        # champ de session : le lien du projet Pyxel Studio, donné à la première de ces questions (``premiere_externe``,
        # posée par le paquet) ; à chaque soumission, son app.py devient la saisie (``modele.Code._rapatrier``)
        self.lien, self.premiere_externe = lien, None
        # champ de session : le verdict du Web Worker, {saisie, fraction, message}, rangé avec la copie pour qu'une copie
        # rouverte dans le navigateur remontre la correction sans relancer de worker (``corriger``)
        self.verdict = verdict
        # champ de session : la console telle que l'élève l'a laissée, {texte, historique, graine, journal}, qu'une copie
        # rouverte réaffiche et rejoue (``console_code.ConsoleCode.etat``)
        self.trace_console = trace_console
        self._corrections = {}  # (saisie, classe) -> correction : un sous-processus par appel, et on en fait plusieurs
        self._fautes = {}  # (saisie, classe) -> les (début, fin) de la partie fausse, posés par _verifier_ensemble
        if self.type == "code":  # mesuré : sans cela, un Sql rouvert en seconde chance corrige sur une base vide,
            self._construire()     # « no such table », car _construire corrige AVANT que Sql n'ait posé self.base

    def juste(self):
        return self.solution

    def prelude_source(self):
        """Le code du prélude tel qu'il s'exécute : « @contexte » devient les blocs ``` de son langage pris dans les
        textes partagés que la question cite, dans l'ordre où elle les cite. Un listing numéroté comme le sujet
        (« 1 import sqlite3 », chaque ligne précédée de son numéro) perd ses numéros. Une ligne « @solution <id> »
        devient la solution de cette question, du même tirage (celle du paquet), ou « # @solution <id> » hors paquet."""
        if self.prelude.strip() != "@contexte":
            return SOLUTION_CITEE.sub(lambda m: self.reference(self.reprises[m[1]]) if m[1] in self.reprises
                                      else f"# @solution {m[1]}", self.prelude)
        blocs = [m.group(1) for texte in self.contextes_connus.values()
                 for m in re.finditer(rf"^```{self.langage}[ \t]*\n(.*?)^```", texte, re.MULTILINE | re.DOTALL)]
        return "\n".join(re.sub(r"(?m)^ *\d+ ?", "", b) if all(re.match(r" *\d+( |$)", ligne) for ligne in b.splitlines())
                         else b for b in blocs)

    def script_base(self):
        """Le jeu de données sur lequel tourne le code : rien hors SQL (``Sql.script_base``)."""
        return ""

    def fichiers_deposes(self):
        """``fichiers`` tels que le programme les reçoit : une base « .db » nommée y devient son script."""
        return {nom: self.bases_connues.get(c, c) if nom.endswith(".db") else c for nom, c in self.fichiers.items()}

    def bases_citees(self):
        """Les noms des ``bases`` de la banque que la question emploie (``exporter_eleve`` n'embarque qu'elles)."""
        return {c for nom, c in self.fichiers.items() if nom.endswith(".db")}

    def _decouper(self):
        """Les parties fixes du code donné et, pour chaque zone qui les sépare, le texte qu'elle montre au départ :
        rien pour une ligne « # à compléter », qui garde fixes son retrait et le début de ligne qui précède la marque
        (« return »), suivi d'une espace s'il en a une avant la marque ; la ligne sans sa marque pour une ligne « # à modifier » (code donné que
        l'élève doit changer, comme l'échafaudage d'un sujet de bac), qui ne garde fixe que son retrait, et des lignes
        « # à modifier » consécutives forment une seule zone, où l'élève peut aussi en retirer. ``None`` sans marque."""
        fixes, departs, courant, modifiable = [], [], [], False
        for ligne in self.code_initial.split("\n"):
            completer, modifier = MARQUE_A_COMPLETER.match(ligne), MARQUE_A_MODIFIER.match(ligne)
            if modifier and modifiable:
                departs[-1] += "\n" + modifier.group(1) + modifier.group(2)
                continue
            if completer or modifier:
                m = completer or modifier
                courant.append(m.group(1) + (m.group(2) + " " * bool(m.group(3)) if completer else ""))
                fixes.append("\n".join(courant))
                departs.append("" if completer else m.group(2))
                courant = [""]  # la zone se termine au saut de la ligne suivante, qui commence la partie fixe d'après
            else:
                courant.append(ligne)
            modifiable = bool(modifier)
        return (fixes + ["\n".join(courant)], departs) if fixes else None

    def gabarit(self):
        """Le code donné d'une question ``verrouille``, découpé en ses parties fixes (``_decouper``) : l'élève écrit
        entre deux parties consécutives, et nulle part ailleurs. ``None`` sans aucune marque."""
        decoupe = self._decouper()
        return decoupe and decoupe[0]

    def departs(self):
        """Ce que chaque zone du gabarit montre avant toute frappe : vide, ou la ligne « # à modifier » sans sa marque."""
        decoupe = self._decouper()
        return decoupe[1] if decoupe else []

    def vierge(self):
        """Le texte que l'éditeur montre avant toute frappe : ``code_initial``, ou, verrouillé, ses zones à leur départ."""
        if self.suite_de:  # le code de l'élève à la question ``suite_de``, vide hors d'un paquet
            if self.fermee and self.fige is not None:
                return self.fige
            code = self.origine.code_eleve() if self.origine else ""
            return code + "\n" if code else ""
        gabarit = self.gabarit_ecran() if self.verrouille else None
        return remplir(gabarit, self.departs()) if gabarit else self.code_initial

    def revelations(self):
        return self.revele + self.reprend

    def solutions_citees(self):
        """Les ``id`` des lignes « @solution <id> » du prélude : les questions ``code`` dont la réponse est supposée écrite
        (« en utilisant la fonction de la question 2 »), exécutée avant le code de l'élève sans lui être montrée (1.4). Elle ne cache
        pas la question (choix de l'utilisateur, 05/10/2026) : la console peut appeler la fonction de référence."""
        return SOLUTION_CITEE.findall(self.prelude)

    @staticmethod
    def reference(question):
        """Ce que ``reprend`` cherche dans le code donné : la solution de ``question``, sans ses sauts de ligne de bord."""
        return question.solution.strip("\n")

    def _gabarit_repris(self, remplacer):
        """``gabarit()`` où la référence de chaque question reprise devient ``remplacer(id, question)``, quand le paquet
        connaît la question (sinon, ou sans ``reprend``, le gabarit tel quel)."""
        gabarit = self.gabarit()
        for qid in self.reprend:
            if gabarit and qid in self.reprises:
                ref = self.reference(self.reprises[qid])
                gabarit = [f.replace(ref, remplacer(qid, self.reprises[qid]), 1) for f in gabarit]
        return gabarit

    def reprendre(self, question):
        """Le paquet donne la question ``question``, que celle-ci reprend ou dont son prélude cite la solution."""
        self.reprises[question.id] = question

    def partir_de(self, question):
        """Le paquet donne la question ``suite_de``, dont l'éditeur reprend le code de l'élève."""
        self.origine = question
        question.suites.append(self)

    def _clore(self, fraction):
        self.fige = self.vierge() if self.suite_de and self.saisie is None else None
        super()._clore(fraction)

    def __serializejson__(self):
        """Une suite vidée à la main (saisie ``""``) n'est pas une suite jamais touchée (``None``, qui reprend le code
        de la question citée) : ``_defaut`` les confond, la saisie vide est donc écrite explicitement ; de même un
        éditeur figé vide (``fige``)."""
        nom, _, etat = super().__serializejson__()
        if self.suite_de and (self.saisie == "" or self.fige == ""):
            etat = self._ordre({**etat, **({"saisie": ""} if self.saisie == "" else {}), **({"fige": ""} if self.fige == "" else {})})
        return nom, None, etat

    def gabarit_ecran(self):
        """Le gabarit affiché : la référence d'une question reprise y devient ce que l'élève y a écrit."""
        return self._gabarit_repris(lambda _, q: q.code_eleve())

    def code_eleve(self):
        """Ce que l'élève a écrit, ou le code de départ s'il n'a rien écrit : ce qu'une question qui reprend celle-ci montre."""
        return (self.vierge() if self.saisie is None else self.saisie).strip("\n")

    def gabarit_saisie(self):
        """Le gabarit de la saisie enregistrée : la référence y devient une ligne « # @reprend <id> », qui ne dit rien de la
        réponse (ni de l'élève, qui peut encore changer pendant le chargement d'une copie)."""
        return self._gabarit_repris(lambda qid, _: f"# @reprend {qid}")

    def texte_corrige(self, saisie):
        """Le code que la correction exécute : la saisie où chaque « # @reprend » redevient la référence. Une saisie qui ne
        suit pas ce gabarit (la solution, une copie d'avant) est corrigée telle quelle."""
        zones = zones_du_gabarit(self.gabarit_saisie(), saisie) if self.reprend and saisie is not None else None
        return remplir(self.gabarit(), [saisie[a:b] for a, b in zones]) if zones is not None else saisie

    def corriger(self, saisie):
        v = self.verdict  # rangé avec la copie : la correction d'un Web Worker, qu'une copie rouverte ne refait pas
        if v is not None and v["saisie"] == saisie:
            return v["fraction"], v["message"]
        if DONNEES:  # pas de correction en données (une seconde chance rouverte) : l'écran rebâti la refait
            return None, None
        cle = (saisie, self.classe)
        if cle not in self._corrections:
            self._corrections[cle] = self._verifier(saisie)
        return self._corrections[cle]

    def testee(self):
        """Faux : sans test, la question reste au professeur."""
        return bool(self.tests or self.tests_code or self.effet or self.forme or self.commentaires or self.mutants)

    def zones_commentaires(self, texte):
        """Les intervalles de ``texte`` (verrouillé) qu'occupent les zones dont la solution est un commentaire ;
        ``None`` si ``texte`` ne suit pas le gabarit."""
        gabarit = self.gabarit()
        solution, zones = zones_du_gabarit(gabarit, self.solution), zones_du_gabarit(gabarit, texte)
        if solution is None or zones is None:
            return None
        return [z for z, (a, b) in zip(zones, solution) if self.solution[a:b].strip().startswith("#")]

    def commentaires_manques(self, texte):
        """Les messages des commentaires attendus que ``texte`` n'écrit pas, un par zone fautive, sans dire ce qu'il
        fallait écrire ; toutes les zones fautives si ``texte`` ne suit pas le gabarit."""
        zones = self.zones_commentaires(texte)
        if zones is None:
            return ["le code donné a été modifié : les commentaires ne peuvent pas être lus"] * len(self.commentaires)
        messages = []
        for (a, b), mots in zip(zones, self.commentaires):
            ecrit, ligne = texte[a:b].strip(), texte.count("\n", 0, a) + self.premiere_ligne
            if not ecrit.startswith("#"):
                messages.append(f"ligne {ligne} : un commentaire était attendu (une ligne qui commence par #)")
            elif not all(any(comparable(v) in comparable(ecrit[1:]) for v in str(mot).split("|")) for mot in mots):
                messages.append(f"ligne {ligne} : le commentaire ne décrit pas le cas traité à cet endroit")
        return messages

    def fautes(self, saisie):
        """Les (début, fin) dans ``saisie`` de la partie fausse d'une réponse en partie juste - clauses ou requêtes d'un
        Sql (verifier.localiser_sql), fonctions d'un programme (verifier.variantes_python) -, vides pour une partie
        manquante ; [] si rien ne se localise, ou avant la correction."""
        return self._fautes.get((saisie, self.classe), [])

    def _verifier(self, saisie):
        return self._verifier_ensemble([(self, saisie)])[0] if self.testee() else (None, None)

    @classmethod
    def corriger_ensemble(cls, questions):
        """Remplit d'un coup le cache de ``corriger`` pour la saisie de chacune des ``questions`` : leurs sous-processus
        tournent en même temps. 130 questions de code à la fin d'un TP prenaient 8,6 s l'une après l'autre."""
        demandes = [(q, q.saisie) for q in questions if q.testee() and (q.saisie, q.classe) not in q._corrections]
        for (q, saisie), correction in zip(demandes, cls._verifier_ensemble(demandes)):
            q._corrections[(saisie, q.classe)] = correction

    @staticmethod
    def _verifier_ensemble(demandes):
        """``_verifier`` de chaque ``(question, saisie)`` testée, par ``verifier.verifier_questions``."""
        import tempfile  # noqa: PLC0415 - seulement ici : verifier.py importe modele côté professeur
        from pathlib import Path  # noqa: PLC0415

        from verifier import variantes_python, verifier_questions  # noqa: PLC0415

        def lancer(textes):
            with tempfile.TemporaryDirectory() as racine:
                travaux = []
                for n, (q, texte) in enumerate(textes):
                    (dossier := Path(racine) / str(n)).mkdir()
                    (dossier / (q.fichier or "tp.py")).write_text(texte, encoding="utf-8")
                    travaux.append((q, dossier, "tp.py", q.classe))
                return verifier_questions(travaux)

        textes = [q.texte_corrige(saisie) if saisie is not None else q.code_initial for q, saisie in demandes]
        resultats = lancer([(q, texte) for (q, _), texte in zip(demandes, textes)])
        # un programme en partie faux : ses variantes (une ou deux fonctions remplacées par celles de la solution), toutes
        # en un lot ; la première qui passe tous les tests désigne la partie fausse, et le reste vaut sa part des points
        variantes = {n: variantes_python(texte, q.solution, q.code_initial) for n, ((q, saisie), texte, r) in enumerate(zip(demandes, textes, resultats))
                     if q.langage == "python" and saisie is not None and r["etat"] == "echec"}
        lot = [(n, noms, fautes, variante) for n, (_, liste) in variantes.items() for noms, fautes, variante in liste]
        for (n, noms, fautes, _), r in zip(lot, lancer([(demandes[n][0], variante) for n, _, _, variante in lot])):
            if r["etat"] == "reussi" and not resultats[n]["fautes"]:
                q, total = demandes[n][0], variantes[n][0]
                resultats[n] = {**resultats[n], "fautes": fautes, "obtenus": max(resultats[n]["obtenus"], round(q.points * (1 - len(noms) / max(total, len(noms))), 2))}
        for (q, saisie), texte, r in zip(demandes, textes, resultats):
            q._fautes[(saisie, q.classe)] = r.get("fautes", []) if texte == saisie else []  # « # @reprend » : positions d'un autre texte
        return [(r["obtenus"] / q.points, "\n\n".join(r["messages"]) or None) for (q, _), r in zip(demandes, resultats)]

    def _diagnostic(self):
        """Le message d'erreur de Python traduit et expliqué (erreurs_python.py) : jamais avant la soumission, où
        l'élève n'a que le message brut."""
        from erreurs_python import expliquer  # noqa: PLC0415

        source = self.code_initial if self.saisie is None else self.saisie
        if self.langage != "python" or source == self.solution:
            return ""
        return expliquer(self.corriger(self.saisie)[1], source)

    def _attendu(self):
        tests = "\n".join(f"- `{t.appel}` → `{t.attendu}`" for t in self.tests)
        return f"```{self.langage}\n{self.solution.rstrip()}\n```" + (f"\n\n{tests}" if tests else "")

    def problemes(self):
        p = super().problemes()
        if not self.testee():
            p.append(("avert", "code sans tests, correction manuelle seulement"))
        if self.observe and not self.effet:
            p.append(("erreur", "observe sans effet : ces expressions ne seraient jamais évaluées"))
        if self.effet and self.langage != "python":
            p.append(("erreur", f"effet : seulement en python, pas en {self.langage}"))
        if self.forme:
            from verifier import forme_manquee  # noqa: PLC0415 - seulement ici, comme dans _verifier
            for regle in self.forme:
                genre, _, nom = str(regle).partition(":")
                if genre not in ("comprehension", "recursive", "iterative", "sans", "avec") or (genre == "comprehension") == bool(nom):
                    p.append(("erreur", f"forme : « {regle} » n'est ni comprehension, ni recursive:f, iterative:f, sans:x ou avec:x"))
                elif self.langage != "python":
                    p.append(("erreur", f"forme : seulement en python, pas en {self.langage}"))
                else:
                    try:
                        manque = forme_manquee(self.solution, regle)
                    except SyntaxError:
                        manque = None  # la solution illisible est signalée par ses tests
                    if manque:
                        p.append(("erreur", f"forme : la solution elle-même ne la respecte pas ({manque})"))
        for expression in self.observe:
            try:
                compile(expression, "<observe>", "eval")
            except SyntaxError as exc:
                p.append(("erreur", f"observe : « {expression} » n'est pas une expression ({exc.msg})"))
        if self.fonction:
            try:
                noms = [n.name for n in ast.parse(self.solution).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            except SyntaxError:
                noms = [self.fonction]  # la solution illisible est signalée par ses tests
            if self.langage != "python":
                p.append(("erreur", f"fonction : seulement en python, pas en {self.langage}"))
            elif self.fonction not in noms:
                p.append(("erreur", f"fonction : la solution ne définit pas {self.fonction} au premier niveau"))
        for nom in self.fichiers:
            if self.langage != "python":
                p.append(("erreur", f"fichiers : seulement en python, pas en {self.langage}"))
            elif nom in ("", ".", "..") or "/" in nom or "\\" in nom or nom == (self.fichier or "tp.py"):
                p.append(("erreur", f"fichiers : « {nom} » doit être un simple nom de fichier, autre que celui du programme"))
            elif nom.endswith(".db") and re.fullmatch(r"[\w-]+", self.fichiers[nom].strip()) and self.fichiers[nom] not in self.bases_connues:
                p.append(("erreur", f"fichiers : « {nom} », base « {self.fichiers[nom]} » absente des bases de la banque"))
        if self.mutants and self.langage != "python":
            p.append(("erreur", f"mutants : seulement en python, pas en {self.langage}"))
        for mutant in self.mutants:
            try:
                compile(mutant.code, "<mutant>", "exec")
            except SyntaxError as exc:
                p.append(("erreur", f"mutants : un code n'est pas du python ({exc.msg})"))
        if self.arborescence and (self.langage != "python" or self.mutants):
            p.append(("erreur", "arborescence : seulement en python, et sans mutants (qui ne voient pas le système simulé)"))
        for chemin, mode in self.arborescence.items():
            parent = chemin.rstrip("/").rpartition("/")[0]
            if not re.fullmatch(r"[0-7]{3}", mode) or chemin.startswith("/") or ".." in chemin.split("/"):
                p.append(("erreur", f"arborescence : « {chemin}: {mode} » veut un chemin relatif et des droits en octal (« 755 »)"))
            elif parent and parent + "/" not in self.arborescence:
                p.append(("erreur", f"arborescence : le dossier parent de « {chemin} » manque (« {parent}/ »)"))
        if self.langage == "assembleur":
            from verifier import ErreurAssembleur, assembler, lire_registres  # noqa: PLC0415 - comme forme_manquee
            if self.tests_code:
                p.append(("erreur", "tests_code : seulement en python, pas en assembleur"))
            for test in self.tests:
                for champ in ("appel", "attendu"):
                    try:
                        if not lire_registres(getattr(test, champ)) and champ == "attendu":
                            p.append(("erreur", "test, attendu vide : le test réussirait toujours"))
                    except ValueError as exc:
                        p.append(("erreur", f"test, {champ} : {exc}"))
            try:
                assembler(self.solution)
            except ErreurAssembleur as exc:
                p.append(("erreur", f"solution : {exc}"))
        if self.code_initial and self.code_initial == self.solution:
            p.append(("erreur", "code_initial identique à la solution"))
        if self.verrouille:
            gabarit = self.gabarit()
            if gabarit is None:
                p.append(("erreur", "verrouille sans aucune ligne « # à compléter » : l'élève n'aurait rien où écrire"))
            elif not zones_du_gabarit(gabarit, self.solution):
                p.append(("erreur", "verrouille : la solution ne reprend pas mot pour mot le code donné hors des lignes "
                                    "« # à compléter » et « # à modifier » (retrait et début de ligne compris)"))
        if not self.verrouille and any(MARQUE_A_MODIFIER.match(l) for l in self.code_initial.split("\n")):
            p.append(("erreur", "« # à modifier » sans verrouille : l'élève verrait la marque"))
        if self.commentaires:
            zones = self.zones_commentaires(self.solution) if self.verrouille else None
            if zones is None:
                p.append(("erreur", "commentaires sans verrouille : l'élève n'a pas de ligne où écrire un commentaire"))
            elif len(zones) != len(self.commentaires):
                p.append(("erreur", f"commentaires : {len(self.commentaires)} entrées pour {len(zones)} zones dont la "
                                    "solution est un commentaire"))
            elif not all(isinstance(m, list) and m for m in self.commentaires):
                p.append(("erreur", "commentaires : chaque entrée est une liste de mots, non vide"))
            elif manques := self.commentaires_manques(self.solution):
                p.append(("erreur", f"commentaires : la solution elle-même ne les respecte pas ({manques[0]})"))
        if self.suite_de and (self.verrouille or self.code_initial or self.suite_de == self.id):
            p.append(("erreur", "suite_de : ni verrouille, ni code_initial (jamais affiché), ni elle-même"))
        if self.reprend and not self.verrouille:
            p.append(("erreur", "reprend sans verrouille : l'élève pourrait réécrire le code repris"))
        if self.id in self.reprend or len(set(self.reprend)) != len(self.reprend):
            p.append(("erreur", "reprend : elle-même ou des identifiants en double"))
        if self.solutions_citees() and (self.langage != "python" or self.id in self.solutions_citees()):
            p.append(("erreur", "prelude « @solution » : en python, et la solution d'une AUTRE question"))
        if not isinstance(self.premiere_ligne, int) or isinstance(self.premiere_ligne, bool):
            p.append(("erreur", f"premiere_ligne : un entier attendu, pas {self.premiere_ligne!r}"))
        if self.prelude.strip() == "@contexte" and not self.prelude_source().strip():
            p.append(("erreur", f"prelude « @contexte » : aucun bloc ```{self.langage} dans les contextes cités"))
        elif self.prelude and self.langage == "python":
            try:
                compile(self.prelude_source(), "<prelude>", "exec")
            except SyntaxError as exc:
                p.append(("erreur", f"prelude, ligne {exc.lineno} : erreur de syntaxe ({exc.msg})"))
        return p


class Sql(Code):
    """``saisie`` = la requête écrite ; corrigée en l'EXÉCUTANT sur ``base``, jamais en comparant son texte.

    ``base`` est le script ``CREATE TABLE … ; INSERT …`` du jeu de données, en TEXTE : la banque reste un JSON
    diffable, et ``medias`` ne transporte de toute façon que des images. Chaque ``Test`` rejoue ce script dans une
    base neuve en mémoire, si bien qu'un test ne subit pas l'état laissé par le précédent : un ``appel`` vide juge
    le résultat de la requête de l'élève, un ``appel`` non vide est une requête de CONTRÔLE jouée après elle, ce qui
    note aussi un INSERT, un UPDATE ou un DELETE. ``attendu`` est le ``repr()`` de la liste de tuples attendue ;
    l'ordre des lignes est indifférent sauf si ``ordonne``, et les colonnes se comparent par position, donc les
    alias sont libres mais un ``SELECT *`` à la place des colonnes demandées est refusé, sauf si ``colonnes_libres``.
    ``doublons_libres`` : une ligne répétée compte pour une (DISTINCT facultatif). ``controle`` : des INSERT ajoutés à la
    base pour la correction seulement, jamais montrés ; un test de plus y compare le résultat de l'élève à celui de la
    ``solution`` (une base qui ne discrimine pas : toutes ses lignes passent le WHERE)."""

    type = "sql"

    def __init__(self, id, enonce, solution, base, tests=None, ordonne=False, langage="sql", fichier="requete.sql",
                 lignes=6, afficher_base=True, colonnes_libres=False, doublons_libres=False, controle="", **commun):
        # ``langage`` est redéclaré pour que son défaut soit « sql » ici : sans cela il serait écrit dans le JSON
        # (différent du défaut de Code), puis relu dans ``commun`` — et passé deux fois à Code au rechargement.
        super().__init__(id, enonce, solution, langage=langage, tests=tests, fichier=fichier, lignes=lignes, **commun)
        # ``base`` : le script, ou le nom d'un script des ``bases`` de la banque (``bases_connues``, posées par la banque
        # ou le paquet, ``poser_bases``) ; ``afficher_base`` faux : le papier ne l'imprime pas, l'énoncé montre le schéma
        self.base, self.ordonne, self.afficher_base = base, ordonne, afficher_base
        # ``colonnes_libres`` : le résultat peut porter plus de colonnes, dans un autre ordre (verifier.executer_sql)
        self.colonnes_libres, self.doublons_libres, self.controle = colonnes_libres, doublons_libres, controle
        self._construire()

    def testee(self):
        return super().testee() or bool(self.controle)

    def script_base(self):
        return self.bases_connues.get(self.base, self.base)

    def bases_citees(self):
        return {self.base}

    def _attendu(self):
        tests = "\n".join(f"- {'résultat' if not t.appel.strip() else f'`{t.appel}`'} → `{t.attendu}`" for t in self.tests)
        return f"```{self.langage}\n{self.solution.rstrip()}\n```" + (f"\n\n{tests}" if tests else "")

    def problemes(self):
        import sqlite3  # noqa: PLC0415 - seulement ici, pour éprouver le script de la base

        p = super().problemes()
        if re.fullmatch(r"[\w-]+", self.base.strip()) and self.base not in self.bases_connues:  # un nom, pas un script
            p.append(("erreur", f"base « {self.base} » absente des bases de la banque"))
            return p
        if not self.script_base().strip():
            p.append(("erreur", "sql sans base : la requête n'aurait rien sur quoi tourner"))
            return p
        try:
            sqlite3.connect(":memory:").executescript(self.script_base())
        except sqlite3.Error as exc:
            p.append(("erreur", f"base : {type(exc).__name__} : {exc}"))
        if self.controle:  # rien à exiger de son effet : une ligne que la solution filtre est celle qui refuse un WHERE oublié
            try:
                sqlite3.connect(":memory:").executescript(self.script_base() + "\n" + self.controle)
            except sqlite3.Error as exc:
                p.append(("erreur", f"controle : {type(exc).__name__} : {exc}"))
        if self.tests_code:
            p.append(("erreur", "sql : tests_code est du Python, sans effet ici ; écrire des tests"))
        return p


class Classement(Question):
    """``saisie`` = pour chaque élément (dans l'ordre de ``elements``), l'indice de la catégorie choisie, ou ``None``."""

    type = "classement"

    devinable = True

    def __init__(self, id, enonce, categories, elements, **commun):
        super().__init__(id, enonce, **commun)
        self.categories, self.elements = categories, elements
        self.depart = melange(range(len(self.elements)), self.graine)
        self._construire()

    def juste(self):
        return [self.categories.index(e.categorie) for e in self.elements]

    def corriger(self, saisie):
        saisie = saisie or [None] * len(self.elements)
        return sum(s == j for s, j in zip(saisie, self.juste())) / len(self.elements), None

    def _attendu(self):
        return "\n".join(f"- **{c}** : " + ", ".join(e.texte for e in self.elements if e.categorie == c) for c in self.categories)

    def problemes(self):
        p, utilisees = super().problemes(), {e.categorie for e in self.elements}
        p += [("erreur", f"catégorie « {c} » absente de categories") for c in sorted(utilisees - set(self.categories))]
        return p + [("avert", f"catégorie « {c} » sans aucun élément") for c in sorted(set(self.categories) - utilisees)]


CHIFFRES = "0123456789ABCDEF"
NOM_BASE = {2: "binaire", 10: "décimal", 16: "hexadécimal"}
INDICE_BASE = {2: "₂", 10: "₁₀", 16: "₁₆"}
EXPOSANT = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")
INDICE = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")
SUSCRITS = "⁰¹²³⁴⁵⁶⁷⁸⁹₀₁₂₃₄₅₆₇₈₉"


def queue_suscrite(texte):
    """(corps, queue) : ``texte`` sans l'exposant ou la base qui le termine (« 94₁₀ » → « 94 », « ₁₀ »). Dans une case
    alignée à droite, le corps s'aligne sur le bord et la queue déborde dans la marge : unités sous unités, qu'il y ait un
    exposant ou non (l'utilisateur, 03/10/2026)."""
    corps = texte.rstrip(SUSCRITS)
    return corps, texte[len(corps):]


SUFFIXE_BASE = re.compile(r"(?:[₀-₉]+|_\d+|\(\d+\))$")  # « 199₁₀ », « 199_10 », « 199(10) » : la base écrite derrière


def base_manquante(base, texte):
    """Le nombre ``texte`` est écrit sans sa base, alors qu'elle est due : partout sauf en base 10, où elle est facultative
    (l'utilisateur, 03/10/2026)."""
    return base != 10 and base_suffixe(texte)[1] is None


# comment écrire la base, dans les consignes de toute question qui la demande (l'utilisateur, 03/10/2026 : « il faut préciser
# dans les instructions comment préciser la base ! »), à l'écran et sur le papier ; réduite au geste (l'utilisateur, 04/10/2026 :
# « Écrivez la base en indice derrière le résultat : Maj+↓ puis ses chiffres ») : la base 10 n'est plus dite facultative,
# une conversion la compte sur son résultat (``Conversion.base_ecrite``)
CONSIGNE_BASE_PAPIER = "Écrire la base en indice derrière {quoi}, par exemple 1011₂ ou 2F₁₆."
CONSIGNE_BASE_ECRAN = "Écrire la base en indice derrière {quoi} : Maj+↓ puis ses chiffres."
BASE_OUBLIEE = "La base est oubliée : écris-la en indice derrière le nombre (Maj+↓ au clavier), sauf en base 10."


def base_suffixe(texte):
    """(corps, base) : ``texte`` sans espaces ni la base écrite derrière lui, et cette base (``None`` sans base écrite) :
    « 0101₂ », « 0101_2 », « 0101(2) » → (« 0101 », 2)."""
    texte = re.sub(r"\s", "", str(texte or ""))
    suffixe = SUFFIXE_BASE.search(texte)
    if not suffixe:
        return texte, None
    return texte[:suffixe.start()], int(re.sub(r"\D", "", suffixe[0].translate(str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789"))))


TERME = re.compile(r"([0-9A-F]+)[×X*]([0-9]+)(?:\^|\*\*)([0-9]+)")  # « 1×2⁶ » (exposant ramené à « ^6 »), « 14*16**1 »
METHODES = {"binaire": {(10, 16), (16, 10)}, "ponderation": {(2, 10), (16, 10)}, "polynomial": {(2, 10), (16, 10)}, "soustractions": {(10, 2)}, "divisions": {(10, 2), (10, 16)},
            "paquets": {(2, 16), (16, 2)}}
METHODE_PAR_DEFAUT = {(2, 10): "ponderation", (16, 10): "ponderation", (10, 2): "soustractions", (10, 16): "divisions",
                      (2, 16): "paquets", (16, 2): "paquets"}
NOM_METHODE = {"binaire": "via binaire", "ponderation": "pondération", "polynomial": "développement polynomial", "soustractions": "soustractions successives",
               "divisions": "divisions successives", "paquets": "paquets de 4 bits"}
GAUCHE = -1  # abscisse du bord gauche de la colonne des étiquettes, dans un ``plan`` de conversion
# les couleurs des tableaux du cours (« Conversions de nombres », NSI Première)
BLEU_DONNEE, VERT_RESULTAT, GRIS_ENTETE, NOIR_BANDEAU = "#00b0f0", "#00b050", "#d9d9d9", "#0d0d0d"
GRIS_DONNEE = "#ececec"  # une case donnée d'une grille ou d'un ``tableau`` : ce qui reste blanc est à remplir
GRIS_SIGNE = "#a6a6a6"  # le « + » d'un polynôme dont la case de gauche est encore vide
VERT_FOIS, BLEU_SOUSTRACTION, VERT_LECTURE = "#92d050", "#41719c", "#66c71f"
# marque les traits droits d'une grille : l'écran les retire du SVG et les trace calés sur les pixels (``GrilleConversion``),
# car QSvgRenderer anticrénèle toujours, et un trait de 0,9 px tombé entre deux pixels s'y peignait en deux pixels gris,
# un bord épais (l'utilisateur, 03/10/2026) ; le PDF, vectoriel, les garde tels quels
NET = ' shape-rendering="crispEdges"'


def en_base(n, base):
    texte = ""
    while True:
        n, r = divmod(n, base)
        texte = CHIFFRES[r] + texte
        if not n:
            return texte


def chiffres_propres(texte, signes="=+"):
    """Ce que l'élève a écrit, débarrassé de ce qui ne compte pas : espaces, casse, signe de notation (« = 71 », « + 64 »,
    « -128 » d'une soustraction), base écrite derrière (« 199₁₀ »), préfixe Python (« 0b », « 0x »)."""
    texte = SUFFIXE_BASE.sub("", re.sub(r"\s", "", str(texte or "")).upper()).lstrip(signes)
    return texte[2:] if texte[:2] in ("0B", "0X") else texte


def valeur_en_base(texte, base, signes="=+"):
    try:
        return int(chiffres_propres(texte, signes), base)
    except ValueError:
        return None


class Conversion(Question):
    """Une conversion de nombre posée selon une méthode du cours, étape par étape : l'élève remplit les cases du tableau
    de la méthode, et chaque case est corrigée : la moitié des points pour les calculs (à proportion des cases justes), un
    quart pour le résultat, un quart pour sa base écrite derrière lui (« 94₁₀ »). ``saisie`` =
    {clé de case: texte}. Le corrigé se calcule à partir de ``nombre`` : rien n'est à écrire case par case.

    ``nombre`` est écrit dans la base ``de`` (« 11000111 », « C7 », « 199 ») et converti vers la base ``vers`` ;
    ``methode`` (déduite des deux bases si elle est absente) : ``ponderation`` (2 ou 16 → 10), ``polynomial`` (2 ou
    16 → 10, le polynôme posé terme à terme : « 1×2⁶ », puis sa valeur), ``soustractions``
    (10 → 2), ``divisions`` (10 → 2 ou 16, divisions successives), ``paquets`` (2 ↔ 16, paquets de 4 bits), ``binaire``
    (10 ↔ 16 « via binaire » : les deux tableaux du cours enchaînés en un, soustractions puis paquets, ou paquets puis
    pondération), ou ``choix``
    quand l'énoncé n'en impose aucune : l'élève choisit parmi celles qui valent pour les deux bases (``methodes``), et
    ``saisie["methode"]`` porte son choix ; à défaut, c'est la méthode par défaut (demande de l'utilisateur, 01/10/2026).
    ``chiffres`` : le nombre de colonnes (8 pour un octet), à défaut celui qu'il faut. ``puissances_donnees`` : la ligne
    des puissances en décimales est donnée au lieu d'être à remplir. ``nombre_donne`` (soustractions) : faux, la case du
    nombre décimal est à remplir, quand la question précédente du groupe le fait calculer (2⁸ − |x| du complément à 2) —
    l'afficher donnerait sa réponse (choix de l'utilisateur, 02/10/2026). ``en_tableau`` (méthodes en grille, à l'essai) :
    la grille est un vrai tableau (``tableau``), ``QTableWidget`` à l'écran et tableau sur le papier, au lieu de la figure
    SVG sous des champs ; les deux rendus coexistent, pour être comparés dans un même sujet (l'utilisateur, 04/10/2026).

    Les flèches du cours (×2 entre les puissances, du reste à la soustraction suivante, sens de lecture des restes) ne se
    dessinent qu'une fois remplie la case qu'elles désignent : elles retracent le chemin de l'élève sans lui souffler
    l'étape suivante (demande de l'utilisateur, 01/10/2026)."""

    type = "conversion"
    EXPLICATION_CORRIGEE = False  # « 8 + 4 + 1 = 13₁₀ » redirait la ligne de ``_attendu``

    def __init__(self, id, enonce, nombre, de, vers, methode="", chiffres=None, puissances_donnees=False, nombre_donne=True,
                 niveau=1, en_tableau=False, **commun):
        super().__init__(id, enonce, **commun)
        self.nombre, self.de, self.vers, self.methode = str(nombre), de, vers, methode
        self.chiffres, self.puissances_donnees, self.nombre_donne = chiffres, puissances_donnees, nombre_donne
        self.en_tableau = en_tableau
        self.niveau = niveau  # posé par le sujet (``DefinitionSujet.niveau_conversions``), pas par la banque
        self._construire()

    def procede(self):
        return self.methode if self.methode not in ("", "choix") else METHODE_PAR_DEFAUT.get((self.de, self.vers), "")

    def methodes(self):
        """Les méthodes que l'élève peut employer : toutes celles des deux bases pour ``choix``, sinon la seule imposée."""
        if self.methode == "choix":
            return [m for m, bases in METHODES.items() if (self.de, self.vers) in bases]
        return [self.procede()]

    def pour(self, saisie):
        """La question posée selon la méthode choisie dans ``saisie`` (la défaut, si rien n'est choisi), ou elle-même
        quand la méthode est imposée."""
        if self.methode != "choix":
            return self
        m = (saisie or {}).get("methode")
        return Conversion(self.id, self.enonce, self.nombre, self.de, self.vers, m if m in self.methodes() else self.procede(),
                          self.chiffres, self.puissances_donnees, self.nombre_donne, self.niveau, self.en_tableau)  # du noyau : une copie d'un widget du lecteur ne vaudrait rien

    # -- le rattrapage : un second essai sur un autre nombre (demande de l'utilisateur, 03/10/2026)

    def nombre_bis(self):
        """Le nombre du second essai, tiré de la graine de la question (donc propre à chaque élève) : autant de chiffres
        significatifs dans la base ``de``, autant de colonnes dans la grille, une autre valeur. ``None`` si la question
        n'en a pas (nombre tiré par ``variables`` et pas encore résolu, ou aucun autre nombre de la même taille).
        Un nombre tiré par ``variables`` (« {v} ») se retire par elles, sous d'autres graines : le second essai reste dans les
        bornes que la banque a choisies (130 à 250, pas 999 dans une grille de 8 bits), et tient dans la grille."""
        if "{" in self.nombre:
            return None
        try:
            tirees = self.tirer(self.graine)[1] if self.variables else {}
        except Exception:  # une variable qui cite celles d'un groupe : tirage libre
            tirees = {}
        nom = next((n for n, v in tirees.items() if str(v) == self.nombre), None)
        alea, k = random.Random(f"{self.graine}|{self.id}|bis"), len(en_base(self.valeur(), self.de))
        for i in range(200):
            if nom:
                nombre = str(self.tirer(f"{self.graine}|bis{i}")[1][nom])
            else:
                nombre = en_base(alea.randrange(self.de ** (k - 1) if k > 1 else 1, self.de ** k), self.de).rjust(
                    len(chiffres_propres(self.nombre)), "0")
            bis = self.bis({}, nombre)
            if (bis.valeur() != self.valeur() and bis.colonnes() == self.colonnes()
                    and not any(g == "erreur" for g, _ in bis.problemes())):
                return nombre
        return None

    def bis(self, premier, nombre=None):
        """La question du second essai : la même, sur ``nombre_bis``, selon la méthode du premier essai ``premier``."""
        q = self.pour(premier)
        return Conversion(self.id, self.enonce, nombre or self.nombre_bis(), self.de, self.vers, q.procede(), self.chiffres,
                          self.puissances_donnees, niveau=self.niveau, en_tableau=self.en_tableau)

    def papier(self):
        """La question telle qu'elle s'imprime : le polynôme des niveaux 1 et 2, dont les cases paraissent à mesure qu'on
        écrit, se pose sur le papier comme au niveau 3, une ligne d'écriture par étape (choix de l'utilisateur, 03/10/2026)."""
        if self.niveau >= 3 or "polynomial" not in self.methodes():
            return self
        return Conversion(self.id, self.enonce, self.nombre, self.de, self.vers, self.methode, self.chiffres,
                          self.puissances_donnees, self.nombre_donne, 3, self.en_tableau)

    def rattrapage(self):
        """Le second essai est ouvert : une seconde chance accordée, et un autre nombre à convertir."""
        return self.seconde and self.nombre_bis() is not None

    @staticmethod
    def premier(saisie):
        return {k: v for k, v in (saisie or {}).items() if k != "bis"}

    def soumettre(self):
        """Comme toute question, sauf la seconde chance : au lieu de corriger sur place, la correction du premier essai
        sur sa grille, et dessous la même conversion sur un autre nombre, pour la moitié des points (``corriger``)."""
        avant = self.seconde
        super().soumettre()
        if self.seconde and not avant and self.rattrapage():
            self._dire("")
            self._ouvrir_bis()

    def _ouvrir_bis(self):
        """Crochet du lecteur : la grille du second essai."""

    def _reprendre_seconde(self):
        if self.rattrapage():
            self._ouvrir_bis()
        else:
            super()._reprendre_seconde()

    def malus(self):
        """La seconde chance d'un rattrapage ne retire rien : c'est le second essai qui ne vaut que la moitié."""
        return super().malus() - (self.chance().malus if self.chance() and self.rattrapage() else 0)

    def correction_premier(self):
        """Ce que l'élève lit entre ses deux grilles : le diagnostic du premier essai, puis la consigne du second."""
        premier = self.premier(self.saisie)
        bis = self.bis(premier)  # une copie du noyau, sans seconde chance
        prix = round(self.points * max(0, 0.5 - self.malus()), 2)
        # la correction est tracée sur la grille du premier essai, le barème attend la correction finale ; sur la même ligne
        # que le constat en rouge, l'annonce du second essai en vert (demandes de l'utilisateur, 04/10/2026)
        return (f"**Ce n'est pas la bonne réponse.** <span style=\"color:{VERT}\">"
                + dire("Mais vous avez droit à un second essai ci-dessous avec un autre nombre !") + "</span>",
                f"**Second essai**, pour la moitié des points ({points_txt(prix)}) : convertir "
                f"{chiffres_propres(bis.nombre)}{INDICE_BASE[self.de]} en {NOM_BASE[self.vers]}"
                + (f", par la même méthode ({NOM_METHODE[bis.procede()]})." if self.methode == "choix" else "."))

    def demande_base(self):
        """La grille a une case du résultat, derrière lequel s'écrit la base : pas les soustractions ni les paquets vers le
        binaire, dont le résultat est une rangée de bits."""
        return "{" not in self.nombre and any("resultat" in self.pour({"methode": m}).juste() for m in self.methodes())

    def valeur(self):
        return valeur_en_base(self.nombre, self.de)

    def resultat(self):
        return en_base(self.valeur(), self.vers)

    def colonnes(self):
        """Le nombre de colonnes de chiffres : ``chiffres``, à défaut ce qu'il faut (par paquets de 4 bits entre 2 et 16)."""
        if self.procede() in ("paquets", "binaire"):
            bits = 4 * len(chiffres_propres(self.nombre)) if self.de == 16 else len(en_base(self.valeur(), 2)) \
                if self.de == 10 else len(chiffres_propres(self.nombre))
            return self.chiffres or -(-bits // 4) * 4
        if self.procede() in ("ponderation", "polynomial"):
            return self.chiffres or len(chiffres_propres(self.nombre))
        return self.chiffres or len(en_base(self.valeur(), 2))

    # -- le plan : la grille de la méthode, en unités (une colonne de chiffres, une ligne de texte)

    def plan(self, saisie=None, tout=False):
        """La grille telle que la dessinent le lecteur (``modele.py``) et le PDF (``exporter_pdf.py``) : ``cases``
        (``cle`` d'une case à remplir ou ``None``, ``texte`` donné, ``attendu``, position ``x``/``y``, largeur ``l`` en
        colonnes, ``couleur``, ``aligne`` d/c/g, ``gras``), ``etiquettes`` (la colonne de gauche : ``y``, ``h``,
        ``texte`` sur une ou plusieurs lignes, ``couleur``), ``fonds`` et ``traits`` (``GAUCHE`` : le bord gauche des
        étiquettes), ``fleches`` déjà filtrées sur ``saisie`` (``de`` et ``vers`` : des clés de cases, ``genre`` fois /
        droite / lecture), ``largeur`` et ``hauteur``. ``tout`` : les divisions avec toutes les étapes possibles, au lieu
        de s'arrêter à la dernière que l'élève a ouverte."""
        if self.methode == "choix":
            return self.pour(saisie).plan(saisie, tout)
        saisie = {k: v for k, v in (saisie or {}).items() if str(v).strip()}
        p = {"cases": [], "etiquettes": [], "fonds": [], "traits": [], "fleches": [], "largeur": 0, "hauteur": 0,
             "grille": self.procede() != "divisions"}
        getattr(self, "_plan_" + self.procede())(p, saisie, tout)
        for c in p["cases"]:
            if c["cle"] == "resultat":  # sa base s'écrit derrière lui, et compte dans la note (``corriger``)
                c["attendu"] += INDICE_BASE[self.vers]
        ecrites = saisie.keys() | {c["cle"] for c in p["cases"] if c["cle"] and not c["remplir"]}  # remplies ou données
        p["fleches"] = [f for f in p["fleches"] if f.get("quand", f["vers"]) in ecrites]
        if p["grille"]:
            self._fonds_des_cases(p)
        return p

    @staticmethod
    def _fonds_des_cases(p: dict[str, object]) -> None:
        """Dans une grille, le blanc dit ce qu'il y a à remplir, comme dans un ``tableau`` (l'utilisateur, 05/10/2026 :
        « mettre blanc les cases à remplir de la ligne puissances de 2 en décimales », « en très clair les cases déjà
        remplies du tableau Binaire → Décimal ») : une case à remplir posée sur un fond (l'en-tête gris) en reçoit un
        blanc par-dessus, une case donnée ou une étiquette hors fond un gris très clair. Ajoutés après les fonds du
        procédé : le SVG les peint par-dessus, ``tableau`` prend le dernier qui couvre la cellule."""
        def sous_un_fond(x: float, y: float, l: float, h: float) -> bool:
            return any(fx <= x and x + l <= fx + fl and fy <= y + 1e-6 and y + h <= fy + fh + 1e-6 for fx, fy, fl, fh, _ in fonds)
        fonds = list(p["fonds"])
        for c in p["cases"]:
            dessous = sous_un_fond(c["x"], c["y"], c["l"], c["h"])
            if c["remplir"] and dessous:
                p["fonds"].append((c["x"], c["y"], c["l"], c["h"], "#ffffff"))
            elif not c["remplir"] and str(c["texte"]).strip() and not dessous:
                p["fonds"].append((c["x"], c["y"], c["l"], c["h"], GRIS_DONNEE))
        for e in p["etiquettes"]:
            if not e.get("gras") and not sous_un_fond(GAUCHE, e["y"], 1, e["h"]):
                p["fonds"].append((GAUCHE, e["y"], 1, e["h"], GRIS_DONNEE))

    @staticmethod
    def _case(p, cle, x, y, texte="", attendu="", remplir=True, l=1, couleur="", aligne="d", gras=False, h=1, signe=""):
        p["cases"].append({"cle": cle, "texte": texte, "attendu": attendu, "remplir": remplir and cle is not None,
                           "x": x, "y": y, "l": l, "h": h, "couleur": couleur, "aligne": aligne, "gras": gras, "signe": signe})

    @staticmethod
    def _etiquette(p, y, texte, h=1, couleur=""):
        p["etiquettes"].append({"y": y, "h": h, "texte": texte, "couleur": couleur})

    def _bandeau(self, p, y, n):
        p["fonds"].append((GAUCHE, y, n + 1, 1, NOIR_BANDEAU))
        par = " → (Binaire)" if self.procede() == "binaire" else ""  # l'intitulé du cours : « Décimal ➞ ( Binaire ) ➞ Hexadécimal »
        p["etiquettes"].append({"y": y, "h": 1, "texte": f"{NOM_BASE[self.de].capitalize()}{par} → {NOM_BASE[self.vers].capitalize()}",
                                "couleur": "#ffffff", "gras": True})

    def _puissances(self, p, base, n):
        """L'en-tête gris du cours : les puissances de la base (données au niveau 1, à écrire « 2⁷ » à partir du niveau 2 :
        demande de l'utilisateur, 03/10/2026), puis leur valeur en décimales (à remplir sauf ``puissances_donnees``),
        reliées de droite à gauche par les flèches « ×2 ». Descendu de ``haut`` : plus loin de la consigne, plus près du
        tableau dessous (l'utilisateur, 03/10/2026), ce qui laisse aux flèches une ligne et un dixième."""
        haut = 0.3
        p["fonds"].append((GAUCHE, haut, n + 1, 2, GRIS_ENTETE))
        self._etiquette(p, haut, f"puissances de {base}")
        self._etiquette(p, haut + 1, f"puissances de {base} en décimales")
        for j in range(n):
            e = n - 1 - j
            puissance = f"{base}{str(e).translate(EXPOSANT)}"
            self._case(p, f"e{j}" if self.niveau >= 2 else None, j, haut, "" if self.niveau >= 2 else puissance, puissance)
            self._case(p, f"p{j}", j, haut + 1, str(base ** e) if self.puissances_donnees else "", str(base ** e),
                       remplir=not self.puissances_donnees)
        for j in range(n - 1):
            p["fleches"].append({"de": f"p{j + 1}", "vers": f"p{j}", "genre": "fois", "texte": f"×{base}"})

    def _plan_ponderation(self, p, saisie, tout):
        b, n = self.de, self.colonnes()
        chiffres = chiffres_propres(self.nombre).rjust(n, "0")
        self._puissances(p, b, n)
        y = 3.4  # sous les flèches « ×2 »
        self._bandeau(p, y, n)
        self._etiquette(p, y + 1, f"nombre {NOM_BASE[b]}", couleur=BLEU_DONNEE)
        quoi = "nombre binaire" if b == 2 else "chiffre hexadécimal"
        self._etiquette(p, y + 2, f"puissances de {b} pondérées\n(puissances de {b} en décimales ×\n{quoi} à convertir)", 3)
        self._etiquette(p, y + 5, "nombre décimal (total)", couleur=VERT_RESULTAT)
        for j, c in enumerate(chiffres):
            self._case(p, None, j, y + 1, c, couleur=BLEU_DONNEE, gras=True)
            terme = CHIFFRES.index(c) * b ** (n - 1 - j)
            self._case(p, f"w{j}", j, y + 2, attendu=("+ " if j else "") + str(terme), h=3, signe="+ " if j else "")
        self._case(p, "resultat", 0, y + 5, attendu=str(self.valeur()), l=n, couleur=VERT_RESULTAT, aligne="c", gras=True)
        p["largeur"], p["hauteur"] = n, y + 6

    def _polynome(self):
        """(termes, valeurs) du corrigé, à écrire : tous les termes « chiffre×baseⁿ », zéros compris, puis les valeurs non
        nulles."""
        termes = self._attendus_polynome(nuls=True)[0]
        return ([f"{c}×{b}{str(e).translate(EXPOSANT)}" for c, b, e in termes],
                [str(c * b ** e) for c, b, e in termes if c] or ["0"])

    def _plan_polynomial(self, p, saisie, tout):
        """« Même principe, mais en posant explicitement le polynôme » (le cours) : une formule, pas un tableau (demande
        de l'utilisateur, 03/10/2026, « on devrait juste écrire une formule mathématique ») — le nombre, « = », les termes
        « chiffre×base^rang » reliés par des « + », puis leurs valeurs, puis la somme. Le cours n'y trace aucune flèche.
        Les étiquettes disent ce que chaque ligne attend (demande de l'utilisateur, 03/10/2026).

        Quatre niveaux, que choisit le sujet (``niveau``, demande de l'utilisateur, 03/10/2026) : 1, deux cases par ligne,
        une de plus dès que la dernière est remplie, le « + » gris tant que la case à sa gauche est vide ; 2, une seule
        case, « + » au clavier en ouvre une à droite (``saisie["+t"]`` : le nombre de cases ouvertes, que la grille du
        lecteur y ajoute sans le garder) ; 3, une case libre par ligne ; 4, une justification libre et le résultat. Les
        termes nuls sont facultatifs, et la correction ne regarde pas leur place (``_fautes``) : rien ne dit d'avance
        combien il en faut."""
        b, n, niveau = self.de, self.colonnes(), self.niveau
        termes, valeurs = self._polynome()
        l, signe = (2 if b == 16 else 1.5), 0.5  # « 14×16¹ » à l'aise ; un « + » ou un « = »
        nombre = f"{chiffres_propres(self.nombre)}{INDICE_BASE[b]}"
        tete = max(1, round((len(nombre) * self.CORPS * 0.55 + 8) / self.COLONNE * 2) / 2)
        x0 = tete + signe
        largeur = x0 + n * l + (n - 1) * signe
        self._case(p, None, 0, 0, nombre, l=tete, couleur=BLEU_DONNEE, gras=True)
        if niveau >= 4:
            y = 4  # quatre lignes d'écriture
            self._case(p, None, tete, 0, "=", l=signe, aligne="c")
            self._case(p, "justification", x0, 0, attendu=f"{' + '.join(termes)}\n= {' + '.join(valeurs)}", l=largeur - x0,
                       h=y, aligne="g")
            self._etiquette(p, 0, "justification :\ntermes « coefficient × " + f"{b}ⁿ »,\npuis nombres simples", y)
            y += 0.5
        else:
            for y in (0, 1.5):
                self._case(p, None, tete, y, "=", l=signe, aligne="c")
            if niveau == 3:
                self._case(p, "t", x0, 0, attendu=" + ".join(termes), l=largeur - x0, aligne="g")
                self._case(p, "w", x0, 1.5, attendu=" + ".join(valeurs), l=largeur - x0, aligne="g")
            else:
                for ligne, y, attendus in (("t", 0, termes), ("w", 1.5, valeurs)):
                    dernier = max((j for j in range(n) if f"{ligne}{j}" in saisie), default=-1)
                    ouvertes = int(saisie.get("+" + ligne, 0) or 0)
                    k = n if tout else min(n, max(2, dernier + 2) if niveau == 1 else max(1, dernier + 1, ouvertes))
                    x = x0
                    for j in range(k):
                        if j:
                            gris = not tout and f"{ligne}{j}" not in saisie  # un « + » sans terme à sa droite ne compte pas
                            self._case(p, None, x, y, "+", l=signe, aligne="c", couleur=GRIS_SIGNE if gris else "")
                            x += signe
                        self._case(p, f"{ligne}{j}", x, y, attendu=attendus[j] if j < len(attendus) else "", l=l, aligne="c")
                        x += l
            self._etiquette(p, 0, f"coefficient × {b}ⁿ")
            self._etiquette(p, 1.5, "nombres simples")
            y = 3
        self._case(p, None, tete, y, "=", l=signe, aligne="c")
        self._case(p, "resultat", x0, y, attendu=str(self.valeur()), l=2.5, couleur=VERT_RESULTAT, aligne="c", gras=True)
        self._etiquette(p, y, "résultat", couleur=VERT_RESULTAT)
        p["grille"], p["trous"] = False, True
        p["largeur"], p["hauteur"] = largeur, y + 1

    def _plan_soustractions(self, p, saisie, tout):
        n, valeur = self.colonnes(), self.valeur()
        self._puissances(p, 2, n)
        y = 3.4
        self._bandeau(p, y, n)
        self._etiquette(p, y + 1, "nombre décimal", couleur=BLEU_DONNEE)
        self._etiquette(p, y + 2, "puissance de 2 en décimales\ninférieure ou égale au reste", 2)
        self._etiquette(p, y + 4, "reste")
        self._etiquette(p, y + 5, "nombre binaire", couleur=VERT_RESULTAT)
        # une seule case sur toute la ligne, nombre centré (l'utilisateur, 05/10/2026 : « le nombre décimal ne doit pas
        # être que sur deux cases, mais sur une qui s'affiche sur toute la largeur, avec le nombre centré »)
        self._case(p, "nombre", 0, y + 1, f"{valeur}{INDICE_BASE[10]}" if self.nombre_donne else "",
                   str(valeur), remplir=not self.nombre_donne, l=n, couleur=BLEU_DONNEE, aligne="c", gras=True)
        reste, bits = valeur, en_base(valeur, 2).rjust(n, "0")
        for j, bit in enumerate(bits):
            puissance = 2 ** (n - 1 - j)
            if bit == "1":
                reste -= puissance
            self._case(p, f"s{j}", j, y + 2, attendu=f"-{puissance}" if bit == "1" else "", h=2, signe="-")
            self._case(p, f"r{j}", j, y + 4, attendu=f"={reste}" if bit == "1" else "")
            self._case(p, f"b{j}", j, y + 5, attendu=bit, couleur=VERT_RESULTAT, gras=True)
        source = "nombre"  # la flèche part du reste dont l'élève est parti : la dernière case « reste » remplie avant
        for j in range(n):
            if f"s{j}" in saisie:
                p["fleches"].append({"de": source, "vers": f"s{j}", "genre": "droite"})
            if f"r{j}" in saisie:
                source = f"r{j}"
        p["largeur"], p["hauteur"] = n, y + 6

    def _plan_binaire(self, p, saisie, tout):
        """« Méthode via binaire » (le cours) : ses deux tableaux enchaînés en un seul. Décimal → hexadécimal : les
        soustractions successives, puis les bits regroupés par paquets de 4 ; hexadécimal → décimal : chaque chiffre en
        paquet de 4 bits, puis la pondération des bits. L'en-tête des puissances de 2 est celui de la première méthode."""
        n, haut = self.colonnes(), 1.4
        groupe = "chiffre ou lettre associée\npar groupe de 4 bits"
        hexa = (self.resultat() if self.de == 10 else chiffres_propres(self.nombre)).rjust(n // 4, "0")
        bits = en_base(self.valeur(), 2).rjust(n, "0")
        if self.de == 10:
            self._plan_soustractions(p, saisie, tout)  # jusqu'à la ligne « nombre binaire », en y = 8.4
            p["etiquettes"][-1]["couleur"] = ""  # le binaire n'est plus le résultat, seulement une étape
            for c in p["cases"]:
                if c["cle"] and c["cle"][0] == "b":
                    c["couleur"] = ""
            y = 9.4
            self._etiquette(p, y, groupe, haut)
            for i, chiffre in enumerate(hexa):
                self._case(p, f"g{i}", 4 * i, y, attendu=chiffre, l=4, h=haut, aligne="c")
            self._etiquette(p, y + haut, "nombre hexadécimal", couleur=VERT_RESULTAT)
            self._case(p, "resultat", 0, y + haut, attendu=self.resultat(), l=n, couleur=VERT_RESULTAT, aligne="c", gras=True)
            p["traits"] += [(4 * i, 8.4, 4 * i, y + haut) for i in range(1, n // 4)]
            p["hauteur"] = y + haut + 1
            return
        self._puissances(p, 2, n)
        y = 3.4
        self._bandeau(p, y, n)
        self._etiquette(p, y + 1, "nombre hexadécimal", couleur=BLEU_DONNEE)
        self._case(p, "nombre", 0, y + 1, f"{chiffres_propres(self.nombre)}{INDICE_BASE[16]}", remplir=False, l=n,
                   couleur=BLEU_DONNEE, aligne="c", gras=True)
        self._etiquette(p, y + 2, groupe, haut)
        for i, chiffre in enumerate(hexa):
            self._case(p, f"g{i}", 4 * i, y + 2, attendu=chiffre, l=4, h=haut, aligne="c")
        y += 2 + haut
        self._etiquette(p, y, "nombre binaire")
        self._etiquette(p, y + 1, "puissances de 2 pondérées\n(puissances de 2 en décimales ×\nnombre binaire à convertir)", 3)
        self._etiquette(p, y + 4, "nombre décimal (total)", couleur=VERT_RESULTAT)
        for j, bit in enumerate(bits):
            self._case(p, f"b{j}", j, y, attendu=bit, gras=True)
            self._case(p, f"w{j}", j, y + 1, attendu=("+ " if j else "") + str(int(bit) * 2 ** (n - 1 - j)), h=3,
                       signe="+ " if j else "")
        self._case(p, "resultat", 0, y + 4, attendu=str(self.valeur()), l=n, couleur=VERT_RESULTAT, aligne="c", gras=True)
        p["traits"] += [(4 * i, 5.4, 4 * i, y + 1) for i in range(1, n // 4)]
        p["largeur"], p["hauteur"] = n, y + 5

    def _plan_divisions(self, p, saisie, tout):
        """Les divisions posées comme à l'école primaire, en escalier : à l'étape k, le dividende en (k, k), le diviseur
        à sa droite derrière la potence, le reste sous le dividende, le quotient sous le diviseur — dividende de l'étape
        suivante, qui se pose à partir de lui. Une étape ne paraît qu'une fois le quotient précédent écrit, et différent
        de 0 : rien ne dit d'avance combien il y en aura. Ni grille ni fond (l'utilisateur, 02/10/2026 : « des
        divisions posées comme en primaire, pas un tableau ») ; à l'écran seulement, une case vide est en pointillé
        (``svg``)."""
        b, valeur = self.vers, self.valeur()
        dividendes = [valeur]
        while dividendes[-1]:
            dividendes.append(dividendes[-1] // b)
        if len(dividendes) == 1:
            dividendes.append(0)
        m = len(dividendes) - 1  # le nombre de divisions
        plafond = m + 2  # deux de trop au plus : de quoi se tromper sans que la grille ne s'arrête au bon endroit
        etapes = 1
        while etapes < plafond and (tout or (f"q{etapes}" in saisie and chiffres_propres(saisie[f"q{etapes}"]) != "0")):
            etapes += 1
        x0 = 1  # une colonne libre à gauche, pour la flèche du sens de lecture
        self._etiquette(p, 0, "nombre décimal", couleur=BLEU_DONNEE)
        self._case(p, "nombre", x0, 0, str(valeur), remplir=False, couleur=BLEU_DONNEE, gras=True)
        bas = b == 16  # en base 16, le reste converti en chiffre (« = C₁₆ ») sous le reste
        for k in range(etapes):
            x, juste = x0 + k, k < m
            reste = dividendes[k] % b if juste else None
            self._case(p, None, x + 1, k, str(b), aligne="g")
            p["traits"] += [(x + 1, k, x + 1, k + 2), (x + 1, k + 1, x + 2, k + 1)]  # la potence
            self._case(p, f"r{k}", x, k + 1, attendu=str(reste) if juste else "")
            if bas:
                self._case(p, f"h{k}", x, k + 2, attendu=f"={CHIFFRES[reste]}" if juste else "",
                           couleur=VERT_RESULTAT, aligne="c")
            self._case(p, f"q{k + 1}", x + 1, k + 1, attendu=str(dividendes[k + 1]) if juste else "")
        y = etapes + 1 + bas + 0.4
        self._etiquette(p, y, f"nombre {NOM_BASE[b]}", couleur=VERT_RESULTAT)
        self._case(p, "resultat", x0, y, attendu=self.resultat(), l=etapes + 1, couleur=VERT_RESULTAT, aligne="g", gras=True)
        if etapes > 1:
            p["fleches"].append({"de": f"r{etapes - 1}", "vers": "r0", "genre": "lecture", "quand": "resultat",
                                 "texte": "sens de lecture"})
        p["largeur"], p["hauteur"] = x0 + etapes + 1, y + 1

    def _plan_paquets(self, p, saisie, tout):
        n = self.colonnes()
        self._bandeau(p, 0, n)
        hexa = (self.resultat() if self.de == 2 else chiffres_propres(self.nombre)).rjust(n // 4, "0")
        bits = (chiffres_propres(self.nombre) if self.de == 2 else en_base(self.valeur(), 2)).rjust(n, "0")
        source, cible = ("binaire", "hexadécimal") if self.de == 2 else ("hexadécimal", "binaire")
        self._etiquette(p, 1, f"nombre {source}", couleur=BLEU_DONNEE)
        haut = 1.4  # deux lignes de libellé : sur une seule, la figure dépasse la largeur d'une page A4
        self._etiquette(p, 2, "chiffre ou lettre associée\npar groupe de 4 bits", haut)
        self._etiquette(p, 2 + haut, f"nombre {cible}", couleur=VERT_RESULTAT)
        donne = len(chiffres_propres(self.nombre))
        if self.de == 2:
            for j, bit in enumerate(bits):
                if j >= n - donne:
                    self._case(p, None, j, 1, bit, couleur=BLEU_DONNEE, gras=True)
                else:  # « compléter par des 0 à gauche » (corrigé du professeur) : c'est à l'élève de les écrire
                    self._case(p, f"z{j}", j, 1, attendu="0", couleur=BLEU_DONNEE, gras=True)
            for i, chiffre in enumerate(hexa):
                self._case(p, f"g{i}", 4 * i, 2, attendu=chiffre, l=4, h=haut, aligne="c")
            self._case(p, "resultat", 0, 2 + haut, attendu=self.resultat(), l=n, couleur=VERT_RESULTAT, aligne="c", gras=True)
        else:
            self._case(p, "nombre", 0, 1, f"{chiffres_propres(self.nombre)}{INDICE_BASE[16]}", remplir=False, l=n,
                       couleur=BLEU_DONNEE, aligne="c", gras=True)
            for i, chiffre in enumerate(hexa):
                self._case(p, f"g{i}", 4 * i, 2, attendu=chiffre, l=4, h=haut, aligne="c")
            for j, bit in enumerate(bits):
                self._case(p, f"b{j}", j, 2 + haut, attendu=bit, couleur=VERT_RESULTAT, gras=True)
        debut, fin = (1, 2 + haut) if self.de == 2 else (2, 3 + haut)  # pas sur le nombre écrit d'un seul tenant
        p["traits"] += [(4 * i, debut, 4 * i, fin) for i in range(1, n // 4)]  # la séparation des paquets, en trait épais
        p["largeur"], p["hauteur"] = n, 3 + haut

    # -- le dessin : un SVG, le même à l'écran (sous les champs de saisie) et sur le papier

    COLONNE, LIGNE, CORPS = 34, 20, 10  # en points : une colonne de chiffres, une ligne, le corps du texte (10 pt imprimés)
    MARGE = 11  # en points, entre le texte et le bord droit de sa case : unités, dizaines, centaines restent alignées d'une
    # case à l'autre, et un exposant ou une base de deux chiffres (« ₁₀ », 9 pt) y déborde sans toucher le bord (03/10/2026)

    def svg(self, plan, valeurs=None, police="Carlito", couleur_valeurs="", police_valeurs="", largeur_max=None, ecrites=None,
            calque=False):
        """La figure de ``plan`` en SVG, un point par unité : fonds, bordures, étiquettes, textes donnés, traits, flèches ;
        et ``valeurs`` ({clé: texte}) écrites dans les cases à remplir — le corrigé, ou une copie, sur le papier. À l'écran
        on n'en passe pas : les champs de saisie se posent par-dessus, aux places que donne ``rectangle``. ``largeur_max``
        (en points) réduit la taille déclarée d'une figure plus large, sans toucher au dessin (16 bits sur une page A4).
        ``ecrites`` (à l'écran) : les cases que l'élève a remplies ; sans grille, les autres sont en pointillé, pour qu'il
        voie où écrire. Sur le papier, rien : la copie reste une division posée sur une feuille blanche ; sauf une formule à
        ``trous`` (le polynôme), dont chaque trou vide reçoit un trait d'écriture gris, sinon rien ne dit où écrire.
        ``calque`` : les flèches seules, à poser sur le vrai tableau d'une question ``en_tableau`` (``tableau``)."""
        g, cases = self.geometrie(plan), {c["cle"]: c for c in plan["cases"] if c["cle"]}
        largeur, hauteur = g["x"](plan["largeur"]) + 1, g["y"](plan["hauteur"]) + 1
        reduction = min(1, largeur_max / largeur) if largeur_max else 1
        s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{largeur * reduction / 72:.3f}in" '
             f'height="{hauteur * reduction / 72:.3f}in" '
             f'viewBox="0 0 {largeur} {hauteur}" font-family="{police}" font-size="{self.CORPS}">']

        def texte(x, y, contenu, ancre="middle", couleur="#000000", gras=False, famille="", corps=None, tourne=0):
            s.append(f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="{ancre}" fill="{couleur or "#000000"}"'
                     + (' font-weight="bold"' if gras else "") + (f' font-family="{famille}"' if famille else "")
                     + (f' font-size="{corps}"' if corps else "")
                     + (f' transform="rotate({tourne:.1f} {x:.1f} {y:.1f})"' if tourne else "")
                     + f">{html.escape(str(contenu))}</text>")

        dessin = {**plan, "fonds": [], "cases": [], "etiquettes": [], "traits": []} if calque else plan  # (``geometrie`` : plan)
        for x, y, l, h, couleur in dessin["fonds"]:
            s.append(f'<rect x="{g["x"](x)}" y="{g["y"](y)}" width="{g["x"](x + l) - g["x"](x)}" height="{h * self.LIGNE}" '
                     f'fill="{couleur}"/>')
        for c in dessin["cases"]:
            x, y, l, h = self.rectangle(plan, c)
            if plan["grille"]:
                s.append(f'<rect x="{x}" y="{y}" width="{l}" height="{h}" fill="none" stroke="#7f7f7f" stroke-width="0.75"{NET}/>')
            elif ecrites is not None and c["remplir"] and c["cle"] not in ecrites:
                s.append(f'<rect x="{x + 2}" y="{y + 2}" width="{l - 4}" height="{h - 4}" fill="none" stroke="#a6a6a6" '
                         f'stroke-width="0.6" stroke-dasharray="2 2"/>')
            elif ecrites is None and plan.get("trous") and c["remplir"] and not (valeurs or {}).get(c["cle"]):
                for i in range(1, round(c["h"]) + 1):  # une ligne d'écriture par ligne de la case
                    s.append(f'<line x1="{x + 3}" y1="{y + i * self.LIGNE - 3}" x2="{x + l - 3}" y2="{y + i * self.LIGNE - 3}" '
                             f'stroke="#a6a6a6" stroke-width="0.6"/>')
        for e in dessin["etiquettes"]:
            lignes, y = e["texte"].split("\n"), g["y"](e["y"])
            if plan["grille"] and not e.get("gras"):
                s.append(f'<rect x="0" y="{y}" width="{g["etiquettes"]}" height="{e["h"] * self.LIGNE}" fill="none" '
                         f'stroke="#7f7f7f" stroke-width="0.75"{NET}/>')
            haut = y + (e["h"] * self.LIGNE - len(lignes) * self.CORPS * 1.2) / 2
            for i, ligne in enumerate(lignes):
                texte(g["etiquettes"] / 2, haut + (i + 0.82) * self.CORPS * 1.2, ligne, couleur=e["couleur"], gras=e.get("gras"))
        for x1, y1, x2, y2 in dessin["traits"]:
            s.append(f'<line x1="{g["x"](x1)}" y1="{g["y"](y1)}" x2="{g["x"](x2)}" y2="{g["y"](y2)}" stroke="#000000" '
                     f'stroke-width="{1.5 if plan["grille"] else 1}"{NET}/>')
        for c in dessin["cases"]:
            contenu = c["texte"] if not c["remplir"] else (valeurs or {}).get(c["cle"], "")
            if not str(contenu).strip():
                continue
            x, y, l, h = self.rectangle(plan, c)
            ancre, ax = {"d": ("end", x + l - self.MARGE), "g": ("start", x + self.MARGE)}.get(c["aligne"], ("middle", x + l / 2))
            ecrit = c["remplir"] and couleur_valeurs
            lignes = str(contenu).split("\n")  # une justification : une ligne de texte par ligne de la case
            for i, ligne in enumerate(lignes):
                base = self.ligne_de_base(plan, c) if len(lignes) == 1 else y + (i + 0.5) * self.LIGNE + self.CORPS * 0.36
                corps, queue = queue_suscrite(ligne) if c["aligne"] == "d" else (ligne, "")
                for morceau, a in ((corps, ancre), (queue, "start")):  # la queue part du bord du corps, dans la marge
                    if morceau:
                        texte(ax, base, morceau, a, couleur_valeurs if ecrit else c["couleur"], c["gras"],
                              police_valeurs if c["remplir"] else "")
        for f in plan["fleches"]:
            self._fleche(s, texte, plan, cases[f["de"]], cases[f["vers"]], f)
        s.append("</svg>")
        return "\n".join(s)

    def geometrie(self, plan):
        """Les abscisses et ordonnées en points d'un plan : la colonne des étiquettes à gauche (aussi large que la plus
        longue de leurs lignes, estimée sur la chasse moyenne de Carlito), puis les colonnes de chiffres."""
        lignes = [ligne for e in plan["etiquettes"] for ligne in e["texte"].split("\n")]
        etiquettes = round(max([len(ligne) for ligne in lignes] or [0]) * self.CORPS * 0.5 + 12)
        return {"etiquettes": etiquettes, "x": lambda x: 0 if x == GAUCHE else etiquettes + x * self.COLONNE,
                "y": lambda y: y * self.LIGNE}

    def rectangle(self, plan, case, g=None):
        """La place d'une case, en points : (x, y, largeur, hauteur). ``g`` : la ``geometrie`` du plan, à qui l'a déjà."""
        g = g or self.geometrie(plan)
        return g["x"](case["x"]), g["y"](case["y"]), case["l"] * self.COLONNE, case["h"] * self.LIGNE

    def ligne_de_base(self, plan, case, g=None):
        """L'ordonnée en points de la ligne de base d'une case d'une seule ligne : là où ``svg`` écrit son texte, et où le
        lecteur cale celui que l'élève tape (``modele.ChampConversion.caler``)."""
        _, y, _, h = self.rectangle(plan, case, g)
        return y + h / 2 + self.CORPS * 0.36

    def tableau(self, plan):
        """Le plan d'une méthode en grille (``plan["grille"]``) en vrai tableau, pour une question ``en_tableau`` : les
        bornes distinctes des cases et des étiquettes font les colonnes et les lignes, leurs tailles en points dans
        ``colonnes`` (la première, celle des étiquettes) et ``lignes``. Chaque case et chaque étiquette est une cellule
        (``ligne``, ``colonne``, ``hauteur`` et ``largeur`` en lignes et colonnes du tableau, ``case`` ou ``etiquette`` du
        plan), et ce qui reste d'une ligne, des cellules vides, une par plage : la ligne des flèches « ×2 », le bandeau.
        ``fond`` : la couleur de ``plan["fonds"]`` sous la cellule ; ``bord`` : son cadre gris, là où ``svg`` en trace
        un ; ``epais`` : son bord gauche est un trait épais de ``plan["traits"]`` (les paquets de 4 bits)."""
        rond = lambda v: round(v, 6)  # noqa: E731 — 2 + 1,4 et 3,4 : la même borne
        xs = sorted({0, rond(plan["largeur"]), *(rond(v) for c in plan["cases"] for v in (c["x"], c["x"] + c["l"]))})
        ys = sorted({0, rond(plan["hauteur"]), *(rond(v) for c in plan["cases"] + plan["etiquettes"]
                                                  for v in (c["y"], c["y"] + c["h"]))})
        bornes = [GAUCHE, *xs]
        cellules, prises = [], set()

        def cellule(x0, x1, y0, y1, **quoi):
            j, i = bornes.index(rond(x0)), ys.index(rond(y0))
            largeur, hauteur = bornes.index(rond(x1)) - j, ys.index(rond(y1)) - i
            dedans = lambda fx, fy, fl, fh: fx <= x0 and x1 <= fx + fl and fy <= y0 + 1e-6 and y1 <= fy + fh + 1e-6  # noqa: E731
            cellules.append({"ligne": i, "colonne": j, "hauteur": hauteur, "largeur": largeur, "case": None, "etiquette": None,
                             "fond": next((f[4] for f in reversed(plan["fonds"]) if dedans(*f[:4])), ""), "bord": False,
                             "epais": any(t[0] == t[2] == x0 and t[1] <= y0 + 1e-6 and y1 <= t[3] + 1e-6 for t in plan["traits"]),
                             **quoi})
            prises.update((i + a, j + b) for a in range(hauteur) for b in range(largeur))

        for e in plan["etiquettes"]:
            cellule(GAUCHE, 0, e["y"], e["y"] + e["h"], etiquette=e, bord=not e.get("gras"))
        for c in plan["cases"]:
            cellule(c["x"], c["x"] + c["l"], c["y"], c["y"] + c["h"], case=c, bord=True)
        for i in range(len(ys) - 1):  # le reste, par plages libres d'une même ligne
            j = 0
            while j < len(bornes) - 1:
                if (i, j) in prises:
                    j += 1
                    continue
                fin = next((k for k in range(j, len(bornes) - 1) if (i, k) in prises), len(bornes) - 1)
                cellule(bornes[j], bornes[fin], ys[i], ys[i + 1])
                j = fin
        g = self.geometrie(plan)
        return {"colonnes": [g["etiquettes"]] + [(b - a) * self.COLONNE for a, b in zip(xs, xs[1:])],
                "lignes": [(b - a) * self.LIGNE for a, b in zip(ys, ys[1:])],
                "cellules": sorted(cellules, key=lambda c: (c["ligne"], c["colonne"]))}

    def _fleche(self, s, texte, plan, de, vers, f):
        x1, y1, l1, h1 = self.rectangle(plan, de)
        x2, y2, l2, h2 = self.rectangle(plan, vers)

        def pointe(px, py, dx, dy, couleur, taille=6):
            n = (dx * dx + dy * dy) ** 0.5 or 1
            dx, dy = dx / n, dy / n
            gauche = (px - taille * dx - taille * 0.5 * dy, py - taille * dy + taille * 0.5 * dx)
            droite = (px - taille * dx + taille * 0.5 * dy, py - taille * dy - taille * 0.5 * dx)
            s.append(f'<polygon points="{px:.1f},{py:.1f} {gauche[0]:.1f},{gauche[1]:.1f} {droite[0]:.1f},{droite[1]:.1f}" '
                     f'fill="{couleur}"/>')

        if f["genre"] == "fois":  # sous l'en-tête, en arc, de la puissance à celle de sa gauche
            a, b, bas = x1 + l1 / 2, x2 + l2 / 2, y1 + h1
            s.append(f'<path d="M {a - 4:.1f} {bas + 2:.1f} Q {(a + b) / 2:.1f} {bas + 17:.1f} {b + 4:.1f} {bas + 4:.1f}" '
                     f'fill="none" stroke="{VERT_FOIS}" stroke-width="1.5"/>')
            pointe(b + 3, bas + 3, -1, -1.1, VERT_FOIS, 5)
            texte((a + b) / 2, bas + 18.5, f["texte"], couleur=VERT_FOIS, corps=self.CORPS * 0.8)
        elif f["genre"] == "droite":  # d'un bord de case à l'autre, sur la droite qui joint leurs centres
            (ax, ay), (bx, by) = (x1 + l1 / 2, y1 + h1 / 2), (x2 + l2 / 2, y2 + h2 / 2)
            dx, dy = bx - ax, by - ay

            def bord(l, h):
                return min(l / 2 / abs(dx) if dx else 1e9, h / 2 / abs(dy) if dy else 1e9)
            t1, t2 = bord(l1 - 6, h1 - 4), 1 - bord(l2 - 6, h2 - 4)
            s.append(f'<line x1="{ax + t1 * dx:.1f}" y1="{ay + t1 * dy:.1f}" x2="{ax + t2 * dx:.1f}" y2="{ay + t2 * dy:.1f}" '
                     f'stroke="{BLEU_SOUSTRACTION}" stroke-width="1.5"/>')
            pointe(ax + t2 * dx, ay + t2 * dy, dx, dy, BLEU_SOUSTRACTION)
        else:  # la grosse flèche du sens de lecture, du coin bas gauche du dernier chiffre lu au coin bas gauche du premier
            # (l'utilisateur, 03/10/2026) : en base 16, les chiffres convertis (« =C ») sous les restes
            (ax, ay), (bx, by) = (self._coin_chiffre(plan, de), self._coin_chiffre(plan, vers))
            dx, dy = bx - ax, by - ay
            n = (dx * dx + dy * dy) ** 0.5 or 1
            s.append(f'<line x1="{ax:.1f}" y1="{ay:.1f}" x2="{bx - 9 * dx / n:.1f}" y2="{by - 9 * dy / n:.1f}" '
                     f'stroke="{VERT_LECTURE}" stroke-width="4"/>')
            pointe(bx, by, dx, dy, VERT_LECTURE, 11)
            angle = math.degrees(math.atan2(dy, dx))
            angle = angle + 180 if abs(angle) > 90 else angle  # lisible, jamais tête en bas
            texte((ax + bx) / 2 + 9 * dy / n, (ay + by) / 2 - 9 * dx / n + 4, f["texte"], couleur=VERT_LECTURE,
                  corps=self.CORPS * 0.8, gras=True, tourne=angle)

    def _coin_chiffre(self, plan, case):
        """Le coin bas gauche du chiffre d'un reste (en base 16, de son chiffre converti, la case ``h`` sous lui), un peu
        en dehors : la chasse estimée sur celle des chiffres de Carlito (½ cadratin), la ligne de base celle de ``svg``."""
        if self.vers == 16:
            case = next(c for c in plan["cases"] if c["cle"] == "h" + case["cle"][1:])
        x, y, l, h = self.rectangle(plan, case)
        largeur = len(str(case["attendu"]) or "0") * self.CORPS * 0.51
        gauche = {"d": x + l - self.MARGE - largeur, "g": x + self.MARGE}.get(case["aligne"], x + l / 2 - largeur / 2)
        return gauche - 7, y + h / 2 + self.CORPS * 0.36 + 8  # 7 et 8 px de jeu : à 2 et 3 la pointe touchait les chiffres

    # -- la correction

    def base_de(self, cle):
        """La base dans laquelle s'écrit une case : celle du résultat, du chiffre converti, d'un bit, ou décimale."""
        if cle == "resultat":
            return self.vers
        return {"g": 16, "h": 16, "b": 2, "z": 2}.get(cle[0], 10)

    def egal(self, cle, saisi, attendu):
        if cle[0] == "e":  # une puissance : « 2⁷ », « 2^7 », « 2**7 »
            return self._puissance(saisi) is not None and self._puissance(saisi) == self._puissance(attendu)
        if cle[0] == "t":  # un terme : même chiffre (« E » ou « 14 »), même base, même rang
            return self._terme(saisi) is not None and self._terme(saisi) == self._terme(attendu)
        signes = "=+-" if cle[0] == "s" else "=+"  # « -128 » ou « 128 » : le signe d'une soustraction est une notation
        v = valeur_en_base(saisi, self.base_de(cle), signes)
        return v is not None and v == valeur_en_base(attendu, self.base_de(cle), signes)

    def base_ecrite(self, texte):
        """La base du résultat écrite derrière lui, et juste : « 94₁₀ », « 94_10 », « 94(10) ». Due en base 10 aussi :
        facultative pendant les calculs, elle doit apparaître sur le résultat final (l'utilisateur, 04/10/2026)."""
        return base_suffixe(texte)[1] == self.vers

    def neutre(self, cle):
        """Une case facultative : laissée vide, elle n'est ni fausse ni comptée ; écrite, elle se corrige comme les autres.
        Une puissance pondérée nulle (« + 0 » sous un bit à 0, l'utilisateur, 04/10/2026), et la ligne des puissances en
        décimales de l'en-tête, une aide au calcul que l'élève qui les sait n'a pas à recopier (« pourquoi j'ai eu faux au
        premier essai ? tout est bon ! » : soustractions justes, en-tête laissé vide, 0,6 — l'utilisateur, 04/10/2026)."""
        return cle[0] == "p" or cle[0] == "w" and self.procede() in ("ponderation", "binaire") and \
            valeur_en_base(self.juste().get(cle, ""), 10, "=+") == 0

    @staticmethod
    def _brut(texte):
        """``texte`` sans espaces ni « + » de tête, en majuscules, exposant ramené à « ^7 », « ×× » (« ** » que la
        grille a changé en « × ») à « ** »."""
        texte = re.sub(r"\s", "", str(texte or "")).upper().lstrip("+").replace("××", "**")
        return re.sub("[⁰¹²³⁴⁵⁶⁷⁸⁹]+", lambda m: "^" + m[0].translate(str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")), texte)

    def _puissance(self, texte):
        m = re.fullmatch(r"([0-9]+)(?:\^|\*\*)([0-9]+)", self._brut(texte))
        return (int(m[1]), int(m[2])) if m else None

    def _terme(self, texte):
        m = TERME.fullmatch(self._brut(texte))
        if not m:  # « 2⁶ » pour « 1×2⁶ » : le « 1× » est facultatif (l'utilisateur, 03/10/2026), et « 2 » vaut 2¹ (04/10/2026)
            if self._brut(texte) == str(self.de):
                return 1, self.de, 1
            puissance = self._puissance(texte)
            return (1, *puissance) if puissance else None
        return (int(m[1]) if m[1].isdigit() else CHIFFRES.index(m[1]) if len(m[1]) == 1 else None), int(m[2]), int(m[3])

    def juste(self):
        if "{" in self.nombre:  # tiré par ``variables`` : la question brute d'une banque n'a pas encore de cases
            return {}
        cases = {c["cle"]: c["attendu"] for c in self.plan(tout=True)["cases"] if c["remplir"] and c["attendu"]}
        return {**cases, "methode": self.procede()} if self.methode == "choix" else cases

    def complete(self):
        saisie = self.saisie or {}
        if self.rattrapage():
            saisie, q = saisie.get("bis") or {}, self.bis(self.premier(saisie))
        else:
            q = self.pour(saisie)
        if q.procede() == "polynomial":  # les termes nuls sont facultatifs : le résultat, et quelque chose avant lui
            return bool(str(saisie.get("resultat", "")).strip()) and any(q._morceaux(saisie))
        return all(str(saisie.get(k, "")).strip() for k in q.juste() if k != "methode" and not q.neutre(k))

    INDICES = {"e": "Une puissance est fausse : {b} à la puissance le rang de sa colonne (0 tout à droite).",
               "p": "Une puissance en décimales est fausse : chacune vaut {b} fois celle de sa droite.",
               "w": "Une puissance pondérée est fausse : c'est la puissance multipliée par le chiffre au-dessus.",
               "t": "Un terme du polynôme est faux ou manque : c'est le chiffre × {b} puissance son rang (0 tout à droite).",
               "v": "Une valeur du polynôme est fausse ou manque : chaque terme calculé, chiffre × {b} puissance son rang.",
               "s": "Une soustraction est fausse : on retire la plus grande puissance de 2 que contient le reste.",
               "b": "Un bit est faux.",
               "q": "Une division est fausse : le quotient est la division entière par {b}.",
               "h": "Un reste est mal écrit en chiffre hexadécimal.",
               "g": "Un paquet de 4 bits est mal converti.",
               "z": "Le nombre de bits doit être un multiple de 4 : complète à gauche par des 0.",
               "n": "Le nombre décimal à convertir est faux : c'est le résultat de la question précédente.",
               "resultat": "Le nombre final est faux.",
               "base": "La base est oubliée : écris-la en indice derrière le résultat (Maj+↓ au clavier), même en base 10."}

    def corriger(self, saisie):
        if "{" in self.nombre:  # jamais posée ainsi : le sujet la tire avant (``Sujet.resoudre``, ``Paquet.nommer``)
            return None, None
        if (saisie or {}).get("bis"):  # le meilleur des deux essais, le second ne valant que la moitié (l'utilisateur, 03/10/2026)
            premier = self.premier(saisie)
            (f1, _), (f2, indice) = self.corriger(premier), self.bis(premier).corriger(saisie["bis"])
            return max(f1, 0.5 * f2), indice
        if self.methode == "choix":  # selon la méthode choisie ; le choix lui-même ne se corrige pas
            return self.pour(saisie).corriger({k: v for k, v in (saisie or {}).items() if k != "methode"})
        saisie = {k: v for k, v in (saisie or {}).items() if str(v).strip()}
        attendu = self.juste()
        fausses, en_trop = self._fautes(saisie)
        notees = [k for k in attendu if k in saisie or not self.neutre(k)]  # une case facultative vide ne compte pas
        total = len(notees) + len(en_trop)
        fraction = (len(notees) - len(fausses)) / total if total else None
        if "resultat" in attendu:
            fraction = sum(obtenu for _, obtenu, _ in self.bareme(saisie))
            if not fausses and not self.base_ecrite(saisie.get("resultat", "")):
                fausses = ["base"]
        if fausses:
            cle = fausses[0] if fausses[0] in ("resultat", "base") else fausses[0][0]
            if cle == "w" and self.procede() == "polynomial":
                cle = "v"
            if cle == "r":  # un reste faux : il vient de la soustraction ou de la division qui l'a produit
                cle = "q" if self.procede() == "divisions" else "s"
            base = self.vers if self.procede() == "divisions" else 2 if self.procede() in ("soustractions", "binaire") else self.de
            indice = self.INDICES.get(cle, "").format(b=base)
        else:
            indice = "Certaines cases devaient rester vides." if en_trop else None
        return fraction, indice

    def _fautes(self, saisie):
        """Les cases fausses (ou vides) et celles remplies en trop, de ``saisie`` sans ses cases vides."""
        if self.procede() == "polynomial":
            return self._fautes_polynome(saisie)
        attendu = self.juste()
        champs = {c["cle"] for c in self.plan(tout=True)["cases"] if c["remplir"]}
        return ([k for k, v in attendu.items() if not (k in saisie and self.egal(k, saisie[k], v))
                 and (k in saisie or not self.neutre(k))],
                [k for k in saisie if k in champs and k not in attendu])

    # le polynôme se corrige morceau par morceau, sans regarder leur place : un terme nul (« 0×2⁵ », « 0 ») est neutre,
    # chaque terme et chaque valeur non nuls du corrigé sont une unité de calcul (choix de l'utilisateur, 03/10/2026)

    def _attendus_polynome(self, nuls=False):
        """(termes, valeurs) du corrigé : les termes (chiffre, base, rang), les nuls seulement si ``nuls``, et leurs valeurs."""
        b, n = self.de, self.colonnes()
        termes = [(CHIFFRES.index(c), b, n - 1 - j) for j, c in enumerate(chiffres_propres(self.nombre).rjust(n, "0"))]
        termes = [t for t in termes if nuls or t[0]]
        return termes, [c * b ** e for c, b, e in termes]

    @staticmethod
    def _apparier(ecrits, attendus, lire, nul):
        """(manquants, faux) : les ``attendus`` qu'aucun écrit ne donne, les écrits ni attendus ni nuls."""
        reste, faux = list(attendus), 0
        for m in ecrits:
            v = lire(m)
            if v is not None and v in reste:
                reste.remove(v)
            elif v is None or not nul(v):
                faux += 1
        return len(reste), faux

    def _comparer(self, sorte, ecrits):
        termes, valeurs = self._attendus_polynome()
        if sorte == "t":
            nul = lambda m: (0, 0, 0) if valeur_en_base(m, 10) == 0 else None  # noqa: E731 - « 0 » pour « 0×2⁶ »
            return self._apparier(ecrits, termes, lambda m: self._terme(m) or nul(m), lambda t: t[0] == 0)
        return self._apparier(ecrits, valeurs, lambda m: valeur_en_base(m, 10), lambda v: v == 0)

    def _morceaux(self, saisie):
        """(termes, valeurs) écrits par l'élève : les cases dans l'ordre, une ligne coupée aux « + », ou la justification."""
        saisie = saisie or {}
        if self.niveau >= 4:
            return self._lire_justification(saisie.get("justification", ""))
        if self.niveau == 3:
            coupe = lambda t: [m.strip() for m in str(t).strip().lstrip("=").split("+") if m.strip()]
            return coupe(saisie.get("t", "")), coupe(saisie.get("w", ""))
        rangs = lambda c: [str(saisie[k]) for k in sorted((k for k in saisie if re.fullmatch(c + r"\d+", k)), key=lambda k: int(k[1:]))
                           if str(saisie[k]).strip()]
        return rangs("t"), rangs("w")

    def _lire_justification(self, texte):
        """Une justification libre (niveau 4), coupée aux « = » et aux retours à la ligne, chaque segment aux « + » : un
        segment qui porte un « × » ou un exposant donne des termes, un autre des nombres ; de chaque sorte, on retient le
        segment le plus proche du corrigé — le nombre de départ ou le résultat recopiés ne comptent donc pas."""
        meilleurs = {"t": ([], None), "w": ([], None)}
        for segment in re.split(r"[=\n]", str(texte or "")):
            morceaux = [m.strip() for m in segment.split("+") if m.strip()]
            if not morceaux:
                continue
            sorte = "t" if any(re.search("[×xX*^⁰¹²³⁴⁵⁶⁷⁸⁹]", m) for m in morceaux) else "w"
            ecart = sum(self._comparer(sorte, morceaux))
            if meilleurs[sorte][1] is None or ecart < meilleurs[sorte][1]:
                meilleurs[sorte] = (morceaux, ecart)
        return meilleurs["t"][0], meilleurs["w"][0]

    def _fautes_polynome(self, saisie):
        """Comme ``_fautes`` : des clés « t… » et « w… » pour les termes et valeurs qui manquent, « +t… » pour les morceaux
        faux au-delà (un morceau faux à la place d'un juste ne coûte qu'une fois)."""
        fausses, en_trop = [], []
        for sorte, ecrits in zip("tw", self._morceaux(saisie)):
            manquants, faux = self._comparer(sorte, ecrits)
            fausses += [f"{sorte}{i}" for i in range(manquants)]
            en_trop += [f"+{sorte}{i}" for i in range(max(0, faux - manquants))]
        attendu = self.juste().get("resultat", "")
        if not ("resultat" in saisie and self.egal("resultat", saisie["resultat"], attendu)):
            fausses.append("resultat")
        return fausses, en_trop

    def _unites(self):
        """Le nombre de calculs notés : les cases à remplir hors résultat et hors puissances pondérées nulles (``neutre``) ;
        pour un polynôme, ses termes et valeurs non nuls."""
        if self.procede() == "polynomial":
            return sum(map(len, self._attendus_polynome()))
        return len([k for k in self.juste() if k not in ("resultat", "methode") and not self.neutre(k)])

    def bareme(self, saisie):
        """Les trois parts de la note, en fractions des points : ``(libellé, obtenu, maximum)`` — ½ les calculs (à
        proportion des cases justes), ¼ le résultat, ¼ sa base écrite derrière lui, pour toutes les méthodes
        (l'utilisateur, 03/10/2026). Une puissance pondérée nulle écrite fausse compte comme une case de plus, fausse."""
        saisie = {k: v for k, v in (saisie or {}).items() if str(v).strip() and k != "methode"}
        attendu = self.juste()
        fausses, en_trop = self._fautes(saisie)
        neutres = len([k for k in fausses if k != "resultat" and self.neutre(k)])
        calculs = self._unites() + len(en_trop) + neutres
        justes = self._unites() - len([k for k in fausses if k != "resultat" and not self.neutre(k)])
        resultat = saisie.get("resultat", "")
        base = base_suffixe(resultat)[1]
        ecrite = "absente avec le résultat" if not resultat else "écrite" if base == self.vers \
            else "oubliée" if base is None else f"fausse (base {base})"
        pluriel = "s" if justes > 1 else ""
        return [(f"calculs : {justes} case{pluriel} juste{pluriel} sur {calculs}"
                 + (f", dont {len(en_trop)} remplie{'s' if len(en_trop) > 1 else ''} en trop" if en_trop else ""),
                 0.5 * justes / calculs if calculs else 0.5, 0.5),
                ("résultat : " + ("juste" if "resultat" not in fausses else "faux" if resultat else "absent"),
                 0.25 * ("resultat" not in fausses), 0.25),
                (f"base du résultat : {ecrite}", 0.25 * (bool(resultat) and self.base_ecrite(resultat)), 0.25)]

    def _bareme(self):
        """Le barème détaillé quand des points manquent (l'utilisateur, 03/10/2026 : « en particulier quand il a le bon
        résultat et fait les bons calculs mais a oublié la notation de la base »)."""
        saisie = self.premier(self.saisie)
        question = self.pour(saisie)
        if "{" in self.nombre or not saisie or "resultat" not in question.juste():
            return ""
        parts = question.bareme(saisie)
        if all(obtenu == maximum for _, obtenu, maximum in parts):
            return ""
        lignes = [f"- {libelle} : {round(obtenu * self.points, 2):g} / {round(maximum * self.points, 2):g}"
                  for libelle, obtenu, maximum in parts]
        if (self.saisie or {}).get("bis"):
            parts = self.bis(saisie).bareme(self.saisie["bis"])
            lignes += ["- second essai, pour la moitié des points :"] + [
                f"    - {libelle} : {round(obtenu * self.points / 2, 2):g} / {round(maximum * self.points / 2, 2):g}"
                for libelle, obtenu, maximum in parts] + ["- note retenue : le meilleur des deux essais"]
        return "**Barème**\n\n" + "\n".join(lignes)

    # -- la correction à la main (``modele.SurimpressionConversion``) : ce qui se barre, ce qui se réécrit, case par case

    def annoter(self, saisie):
        """Ce que le correcteur trace sur la grille (demande de l'utilisateur, 03/10/2026) : {clé de case: (état, ratures,
        ajout)}. ``état`` : « juste », « faux », « manque » (case vide qui attendait quelque chose : ``ajout`` s'y écrit)
        ou « trop » (case remplie qui devait rester vide). ``ratures`` : les morceaux faux de ce que l'élève a écrit, en
        positions dans son texte, chacun avec ce qu'il fallait écrire — seulement le chiffre, l'exposant ou la base fautifs
        quand le reste est juste ; ``ajout`` : ce qui manque derrière (la base oubliée d'un résultat), ou la case entière."""
        saisie = {k: str(v) for k, v in (saisie or {}).items() if str(v).strip() and k not in ("methode", "bis")}
        polynome = self.procede() == "polynomial"
        notes = {}
        for cle, attendu in self.juste().items():
            if cle == "methode" or polynome and cle != "resultat":
                continue
            texte = saisie.get(cle, "")
            if not texte and self.neutre(cle):
                continue  # « + 0 » : facultatif, rien à écrire à sa place
            if not texte:
                notes[cle] = ("manque", [], attendu)
            elif cle == "resultat":
                notes[cle] = self._annoter_resultat(texte)
            elif self.egal(cle, texte, attendu):
                notes[cle] = ("juste", [], "")
            else:
                notes[cle] = ("faux", self._ratures(cle, texte, attendu), "")
        if polynome and self.niveau <= 2:
            notes.update(self._annoter_polynome(saisie))
        elif not polynome:
            champs = {c["cle"] for c in self.plan(tout=True)["cases"] if c["remplir"]}
            notes.update({k: ("trop", [self._morceau(texte)], "") for k, texte in saisie.items()
                          if k in champs and k not in notes})
        return notes

    @staticmethod
    def _morceau(texte, correction=""):
        """(début, fin, correction) : ``texte`` entier, sans ses blancs ni le signe de notation qui le précède (« = », « + »,
        « - ») : barré, le signe resterait seul juste."""
        debut = len(texte) - len(texte.lstrip(" =+-"))
        return debut, len(texte.rstrip()), correction

    def _ratures(self, cle, texte, attendu):
        if cle[0] == "e":  # « 2⁷ » : la base ou l'exposant, chacun barré seul s'il est seul faux
            m = re.fullmatch(r"\s*(\d+)\s*(?:\^|\*\*|××)?\s*([⁰¹²³⁴⁵⁶⁷⁸⁹]+|(?<=[\^*×]|\s)\d+)\s*", texte)
            if m and self._puissance(texte) and self._puissance(attendu):
                (b, e), (b0, e0) = self._puissance(texte), self._puissance(attendu)
                return ([(m.start(1), m.end(1), str(b0))] if b != b0 else []) + \
                       ([(m.start(2), m.end(2), str(e0).translate(EXPOSANT))] if e != e0 else [])
        return [self._morceau(texte, attendu.lstrip(" =+-"))]

    def _annoter_resultat(self, texte):
        """Le nombre et sa base, corrigés chacun pour soi : un nombre juste à la base oubliée ne prend que la base, en
        ajout, à la base fausse que la base ; un nombre faux est barré, et le résultat entier se réécrit, base comprise
        (c'est lui que l'on entoure)."""
        nu = texte.rstrip()
        suffixe = SUFFIXE_BASE.search(nu)
        fin = suffixe.start() if suffixe else len(nu)
        base = base_suffixe(nu)[1]
        nombre_juste = valeur_en_base(texte[:fin], self.vers) == self.valeur() and texte[:fin].strip() != ""
        base_juste = base == self.vers
        if nombre_juste and base_juste:
            return "juste", [], ""
        if not nombre_juste:  # une base fausse derrière est barrée avec, sans correction à part
            return "faux", [self._morceau(texte[:fin], self.resultat() + INDICE_BASE[self.vers])] + \
                ([(suffixe.start(), suffixe.end(), "")] if suffixe and not base_juste else []), ""
        if suffixe:
            return "faux", [(suffixe.start(), suffixe.end(), INDICE_BASE[self.vers])], ""
        return "faux", [], INDICE_BASE[self.vers]

    def _annoter_polynome(self, saisie):
        """Les lignes « termes » et « valeurs » aux niveaux 1 et 2, sans regarder la place (comme ``_fautes``) : un morceau
        juste ou nul n'est pas marqué ; un faux prend un attendu qui manque — de même rang pour un terme, dont seuls le
        chiffre, la base ou l'exposant fautifs sont barrés —, ou il est en trop ; les attendus restants s'écrivent dans
        les cases vides de la ligne, dans l'ordre."""
        notes = {}
        termes, valeurs = self._attendus_polynome()
        for ligne, attendus in (("t", termes), ("w", valeurs)):
            cles = [f"{ligne}{j}" for j in range(self.colonnes())]
            lire = (lambda m: self._terme(m)) if ligne == "t" else (lambda m: valeur_en_base(m, 10))
            reste, fausses = list(attendus), []
            for k in (k for k in cles if k in saisie):
                v = lire(saisie[k])
                if v is not None and v in reste:
                    reste.remove(v)
                elif v is not None and (v[0] == 0 if ligne == "t" else v == 0) or ligne == "t" and valeur_en_base(saisie[k], 10) == 0:
                    pass  # un terme nul : facultatif, ni juste ni faux
                else:
                    fausses.append(k)
            ecrire = lambda a: f"{a[0]}×{a[1]}{str(a[2]).translate(EXPOSANT)}" if ligne == "t" else str(a)  # noqa: E731
            for k in fausses:
                v = lire(saisie[k])
                pair = next((a for a in reste if ligne == "t" and v and a[2] == v[2]), reste[0] if reste else None)
                if pair is None:
                    notes[k] = ("trop", [self._morceau(saisie[k])], "")
                    continue
                reste.remove(pair)
                notes[k] = ("faux", self._ratures_terme(saisie[k], pair) if ligne == "t" else [self._morceau(saisie[k], ecrire(pair))], "")
            for k, a in zip((k for k in cles if k not in saisie), reste):
                notes[k] = ("manque", [], ecrire(a))
        return notes

    def _ratures_terme(self, texte, attendu):
        """« 1×2⁵ » pour « 1×2⁶ » : seuls le chiffre, la base ou l'exposant fautifs sont barrés ; tout le terme s'il ne se lit pas."""
        m = re.fullmatch(r"\s*\+?\s*([0-9A-Fa-f]+)\s*[×xX*]\s*(\d+)\s*(?:\^|\*\*|××)?\s*([⁰¹²³⁴⁵⁶⁷⁸⁹]+|(?<=[\^*×]|\s)\d+)\s*", texte)
        lu = self._terme(texte)
        c, b, e = attendu
        if not (m and lu):
            return [self._morceau(texte, f"{c}×{b}{str(e).translate(EXPOSANT)}")]
        return [(m.start(g), m.end(g), juste) for g, ecrit, juste in
                ((1, lu[0], str(c) if b != 16 else CHIFFRES[c]), (2, lu[1], str(b)), (3, lu[2], str(e).translate(EXPOSANT)))
                if ecrit != (c, b, e)[g - 1]]

    def _attendu(self):
        if (self.saisie or {}).get("bis"):
            premier = self.premier(self.saisie)
            return f"{self.bis(premier, self.nombre)._attendu()}\n\nSecond essai : {self.bis(premier)._attendu()}"
        if self.methode == "choix":
            return self.pour(self.saisie)._attendu()
        # le nombre de départ, le calcul, le résultat, en une suite d'égalités (l'utilisateur, 03/10/2026 : « nombre départ
        # (avec la base) = somme pondérée = résultat (avec la base) ») ; les divisions, qui n'en sont pas une, après « : »
        valeur, b, procede = self.valeur(), self.vers, self.procede()
        depart = f"**{chiffres_propres(self.nombre)}{INDICE_BASE[self.de]}**"
        arrivee = f"**{self.resultat()}{INDICE_BASE[self.vers]}**"
        bits = en_base(valeur, 2)
        bits = bits.rjust(max(self.colonnes(), -(-len(bits) // 4) * 4 if procede in ("paquets", "binaire") else 0), "0")
        paquets = " ".join(bits[i:i + 4] for i in range(0, len(bits), 4)) + INDICE_BASE[2]
        puissances = " + ".join(str(2 ** (len(bits) - 1 - j)) for j, bit in enumerate(bits) if bit == "1")
        if procede in ("polynomial", "ponderation"):
            n = self.colonnes()
            chiffres = chiffres_propres(self.nombre).rjust(n, "0")
            termes = " + ".join(f"{CHIFFRES.index(c)}×" + (f"{self.de}{str(n - 1 - j).translate(EXPOSANT)}"
                                                            if procede == "polynomial" else str(self.de ** (n - 1 - j)))
                                for j, c in enumerate(chiffres))
            if procede == "polynomial":
                termes += " = " + " + ".join(str(CHIFFRES.index(c) * self.de ** (n - 1 - j)) for j, c in enumerate(chiffres) if c != "0")
            return f"{depart} = {termes} = {arrivee}"
        if procede == "soustractions":
            return f"{depart} = {puissances} = {arrivee}"
        if procede == "binaire":
            return f"{depart} = {puissances} = {paquets} = {arrivee}" if self.de == 10 else f"{depart} = {paquets} = {puissances} = {arrivee}"
        if procede == "divisions":
            etapes, d = [], valeur
            while True:
                etapes.append(f"{d} = {b} × {d // b} + {d % b}")
                d //= b
                if not d:
                    break
            return f"{depart} = {arrivee} : {' ; '.join(etapes)} (restes lus de bas en haut)"
        return f"{depart} = {paquets} = {arrivee}"

    def problemes(self):
        p = super().problemes()
        if "{" in self.nombre:
            return p  # tiré par ``variables`` : contrôlé une fois instancié
        if self.de not in NOM_BASE or self.vers not in NOM_BASE:
            p.append(("erreur", f"bases {self.de} → {self.vers} : 2, 10 ou 16"))
            return p
        if (self.de, self.vers) not in METHODES.get(self.procede(), ()):
            p.append(("erreur", f"méthode « {self.procede()} » : pas pour {self.de} → {self.vers}"))
            return p
        if self.valeur() is None:
            p.append(("erreur", f"nombre « {self.nombre} » : pas un nombre en base {self.de}"))
            return p
        utiles = len(en_base(self.valeur(), 2 if self.procede() not in ("ponderation", "polynomial") else self.de))
        if self.chiffres and self.chiffres < utiles:
            p.append(("erreur", f"chiffres = {self.chiffres} : il en faut au moins {utiles}"))
        if self.chiffres and self.procede() in ("paquets", "binaire") and self.chiffres % 4:
            p.append(("erreur", f"chiffres = {self.chiffres} : un multiple de 4 pour des paquets de 4 bits"))
        return p


class Attribut(Objet):
    """Un attribut d'une relation de ``schema`` : son ``nom`` (et les ``synonymes`` acceptés quand l'élève l'écrit lui-même),
    ``cle`` s'il fait partie de la clé primaire, ``reference`` (« Relation.attribut ») la clé primaire qu'il référence s'il
    est une clé étrangère, ``domaines`` les domaines acceptés (« INT », « entier ») quand la question les demande."""

    def __init__(self, nom, synonymes=None, cle=False, reference="", domaines=None):
        self.nom, self.synonymes, self.cle, self.reference, self.domaines = nom, synonymes or [], cle, reference, domaines or []

    def designe(self, texte):
        return any(egal(texte, n) for n in [self.nom, *self.synonymes])

    def domaine_juste(self, texte):
        """Les paramètres d'un domaine ne comptent pas : « VARCHAR(30) » vaut « VARCHAR », « DECIMAL(5,2) » « DECIMAL »."""
        nu = lambda d: re.sub(r"\s*\(.*\)\s*$", "", str(d))
        return any(egal(nu(texte), nu(d)) for d in self.domaines)


class Relation(Objet):
    """Une relation de ``schema`` : son ``nom`` (toujours donné) et ses ``attributs`` attendus ; ``fixe`` : donnée tout entière,
    clés comprises, pour que les autres la référencent (la table des joueurs que référence celle des scores)."""

    def __init__(self, nom, attributs, fixe=False):
        self.nom, self.attributs, self.fixe = nom, attributs, fixe


SCHEMA_DEMANDES = ("attributs", "cles", "etrangeres", "domaines")


class Schema(Question):
    """Un schéma relationnel à compléter (1.18 des widgets de bac) : une boîte par relation, chaque attribut sur sa ligne,
    l'élève coche ceux de la clé primaire et choisit, pour une clé étrangère, la clé primaire qu'elle référence ; à côté,
    la notation du bac se compose à mesure : Score (id, #id_joueur, points), clé primaire soulignée.

    ``demande`` : ce que l'élève fait, parmi « attributs » (il écrit lui-même les attributs, comparés au nom et aux
    ``synonymes`` : « proposer un schéma »), « cles », « etrangeres », « domaines » ; le reste est affiché tel quel. Sans
    « attributs », les attributs sont donnés dans l'ordre de la banque.

    ``saisie`` = {relation: [{"nom", "cle", "reference", "domaine"}, …]}, pour chaque relation non ``fixe``. Notée en
    ensembles, comme les sommets désignés d'un ``dessin`` : chaque attribut trouvé, chaque clé primaire, chaque clé étrangère
    bien référencée compte un, chacun en trop retire un (tout cocher ne rapporte rien), un domaine juste compte un."""

    type = "schema"

    def __init__(self, id, enonce, relations, demande=("cles", "etrangeres"), **commun):
        super().__init__(id, enonce, **commun)
        self.relations, self.demande = relations, list(demande)
        self._construire()

    def a_remplir(self):
        return [r for r in self.relations if not r.fixe]

    def ligne_juste(self, a):
        return {"nom": a.nom, "cle": a.cle, "reference": a.reference, "domaine": (a.domaines or [""])[0]}

    def juste(self):
        return {r.nom: [self.ligne_juste(a) for a in r.attributs] for r in self.a_remplir()}

    def designe(self, reference):
        """L'attribut que désigne « Relation.attribut » (un nom écrit par l'élève, ou un synonyme), ``None`` sinon."""
        relation, _, nom = str(reference).partition(".")
        return next((a for r in self.relations if egal(r.nom, relation) for a in r.attributs if a.designe(nom)), None)

    def apparier(self, relation, lignes):
        """[(ligne, attribut ou None)] : par la position si les attributs sont donnés, par le nom sinon (le premier attribut
        pas encore pris qu'il désigne)."""
        if "attributs" not in self.demande:
            return list(zip(lignes, relation.attributs))
        libres, paires = list(relation.attributs), []
        for ligne in lignes:
            a = next((a for a in libres if a.designe(ligne.get("nom", ""))), None)
            if a:
                libres.remove(a)
            paires.append((ligne, a))
        return paires

    def corriger(self, saisie):
        saisie, justes, fausses, total = saisie or {}, 0, 0, 0
        for r in self.a_remplir():
            paires = [(l, a) for l, a in self.apparier(r, saisie.get(r.nom) or []) if str(l.get("nom", "")).strip() or a]
            if "attributs" in self.demande:
                total += len(r.attributs)
                justes += sum(a is not None for _, a in paires)
                fausses += sum(a is None for _, a in paires)
            if "cles" in self.demande:
                total += sum(a.cle for a in r.attributs)
                justes += sum(bool(l.get("cle")) and a is not None and a.cle for l, a in paires)
                fausses += sum(bool(l.get("cle")) and not (a is not None and a.cle) for l, a in paires)
            if "etrangeres" in self.demande:
                total += sum(bool(a.reference) for a in r.attributs)
                for l, a in paires:
                    if l.get("reference"):
                        bonne = a is not None and a.reference and self.designe(l["reference"]) is self.designe(a.reference)
                        justes, fausses = justes + bool(bonne), fausses + (not bonne)
            if "domaines" in self.demande:
                total += sum(bool(a.domaines) for a in r.attributs)
                justes += sum(a is not None and a.domaine_juste(l.get("domaine", "")) for l, a in paires)
        return (max(0, (justes - fausses) / total) if total else None), None

    @staticmethod
    def notation(relation, lignes, domaines=False, cibles=True):
        """La relation dans la notation du bac, en Markdown : Score ([id]{.souligne}, #id_joueur → Joueur.id, points) ;
        sans ``cibles``, celle de l'énoncé, ``#id_joueur`` seul (la cible y est souvent la réponse d'une autre question)."""
        def attribut(l):
            nom = str(l.get("nom", "")).strip() or "…"
            texte = ("#" if l.get("reference") else "") + (f"[{nom}]{{.souligne}}" if l.get("cle") else nom)
            return (texte + (f" : {l['domaine']}" if domaines and l.get("domaine") else "")
                    + (f" → {l['reference']}" if cibles and l.get("reference") else ""))
        return f"{relation} ({', '.join(map(attribut, lignes))})"

    def _attendu(self):
        return self.schema_attendu()

    def schema_attendu(self):
        """Le schéma attendu dans la notation du bac, celui du corrigé imprimé (l'écran le corrige à la main sur les lignes)."""
        domaines = any(a.domaines for r in self.relations for a in r.attributs)
        lignes = [self.notation(r.nom, [self.ligne_juste(a) for a in r.attributs], domaines) for r in self.a_remplir()]
        lignes = [f"- {l}" for l in lignes] if len(lignes) > 1 else lignes
        synonymes = [f"{a.nom} : {', '.join(a.synonymes)}" for r in self.a_remplir() for a in r.attributs if a.synonymes]
        return "\n".join(lignes + (["", "Noms également acceptés : " + " ; ".join(synonymes)] if synonymes and "attributs" in self.demande else []))

    def problemes(self):
        p = super().problemes()
        p += [("erreur", f"demande « {d} » : parmi {', '.join(SCHEMA_DEMANDES)}") for d in self.demande if d not in SCHEMA_DEMANDES]
        noms = [normaliser(r.nom) for r in self.relations]
        if len(set(noms)) != len(noms):
            p.append(("erreur", "deux relations portent le même nom"))
        if not self.a_remplir():
            p.append(("erreur", "toutes les relations sont fixes : rien à compléter"))
        for r in self.relations:
            for a in r.attributs:
                if a.reference and self.designe(a.reference) is None:
                    p.append(("erreur", f"{r.nom}.{a.nom} : référence « {a.reference} » sans attribut (Relation.attribut)"))
                elif a.reference and not self.designe(a.reference).cle:
                    p.append(("avert", f"{r.nom}.{a.nom} : référence « {a.reference} », qui n'est pas une clé primaire"))
            if len({normaliser(a.nom) for a in r.attributs}) != len(r.attributs):
                p.append(("erreur", f"{r.nom} : deux attributs portent le même nom"))
        if "domaines" in self.demande and not any(a.domaines for r in self.a_remplir() for a in r.attributs):
            p.append(("erreur", "demande domaines, mais aucun attribut n'a de domaines attendus"))
        if not p and self.corriger(self.juste())[0] != 1:
            p.append(("erreur", "le schéma attendu n'obtient pas la note maximale"))
        return p


CATEGORIES_UNIX = ("propriétaire (user)", "groupe (group)", "autres (other)")
MODE_SYMBOLIQUE = re.compile(r"([ugoa]*)((?:[-+=][rwx]*)+)")
TRIPLET = re.compile(r"[r-][w-][x-]")


def chmod(commande, avant, fichier, annexe=False):
    """Les droits (9 caractères) après ``commande`` appliquée à ``avant``, ou ``ValueError`` avec le message du terminal.
    Modes : octal (644 ou 0644), symbolique GNU (``u+x,go-r``, sans lettre ugo pour tous), plusieurs séparés par des
    espaces comme dans les sujets de bac (``chmod u+x g-r o-r f``) ; avec ``annexe``, la notation positionnelle des
    annexes de bac, trois jetons utilisateur, groupe, autres (``chmod rwx +r -x f``, ``r--`` ou ``+r-wx``)."""
    mots = commande.split()
    if mots[:1] == ["sudo"]:
        mots = mots[1:]
    if not mots:
        raise ValueError("")
    if mots[0] != "chmod":
        raise ValueError(f"{mots[0]} : commande introuvable")
    if len(mots) < 3:
        raise ValueError("chmod: opérande manquant")
    *modes, chemin = mots[1:]
    if chemin.rstrip("/").rsplit("/", 1)[-1] != fichier:
        raise ValueError(f"chmod: impossible d'accéder à '{chemin}': Aucun fichier ou dossier de ce nom")
    bits = [list(avant[3 * i:3 * i + 3]) for i in range(3)]

    def appliquer(categories, operation, lettres):
        for i in categories:
            for j, l in enumerate("rwx"):
                if operation == "=" or l in lettres:
                    bits[i][j] = l if operation == "+" or operation == "=" and l in lettres else "-"

    positionnel = annexe and len(modes) == 3 and all(re.fullmatch(r"[-+rwx]+", m) for m in modes)
    for i, mode in enumerate(modes):
        if positionnel and TRIPLET.fullmatch(mode) and not re.fullmatch(r"-[rwx]+", mode):  # r--, --x ; -wx enlève
            appliquer([i], "=", mode)
        elif positionnel:
            for operation, lettres in re.findall(r"([-+=])([rwx]*)", mode if mode[0] in "+-" else "=" + mode):
                appliquer([i], operation, lettres)
        elif re.fullmatch(r"0?[0-7]{3}", mode):
            bits = [[l if int(c) & (4 >> j) else "-" for j, l in enumerate("rwx")] for c in mode[-3:]]
        else:
            for morceau in mode.split(","):
                trouve = MODE_SYMBOLIQUE.fullmatch(morceau)
                if not trouve:
                    raise ValueError(f"chmod: mode incorrect : « {mode} »")
                qui = trouve[1].replace("a", "ugo") or "ugo"
                for operation, lettres in re.findall(r"([-+=])([rwx]*)", trouve[2]):
                    appliquer(["ugo".index(c) for c in qui], operation, lettres)
    return "".join("".join(b) for b in bits)


class Permissions(Question):
    """Des droits Unix (1.52 des widgets de bac) : une grille de neuf cases, propriétaire, groupe, autres × lecture,
    écriture, exécution, que l'élève coche à partir de ``avant`` ; ou, avec ``commande``, la commande ``chmod`` qu'il
    tape dans un terminal simulé, au nom de ``utilisateur``, dont l'effet s'affiche à mesure (``chmod``).

    ``saisie`` = les 9 caractères cochés (``rwxr--r--``), ou la commande. Notée comme les cases à cocher
    (``penalite``) : chaque droit que ``droits`` change par rapport à ``avant`` compte un, chaque droit changé à tort
    retire un. Une commande refusée (fichier inconnu, mode incorrect, ``utilisateur`` qui n'est pas le
    ``proprietaire`` ni root, sans ``sudo``) ne change rien."""

    type = "permissions"

    def __init__(self, id, enonce, fichier, droits, avant="---------", commande=False, utilisateur="", proprietaire="",
                 notation_annexe=False, **commun):
        super().__init__(id, enonce, **commun)
        self.fichier, self.droits, self.avant, self.commande = fichier, droits, avant, commande
        self.utilisateur, self.proprietaire, self.notation_annexe = utilisateur, proprietaire, notation_annexe
        self._construire()

    def refusee(self, commande):
        return bool(self.proprietaire and self.utilisateur not in (self.proprietaire, "root")
                    and commande.split()[:1] != ["sudo"])

    def executer(self, commande):
        """Les droits après ``commande``, ou ``ValueError`` avec le message du terminal."""
        droits = chmod(commande, self.avant, self.fichier, self.notation_annexe)
        if self.refusee(commande):
            raise ValueError(f"chmod: modification des droits de '{commande.split()[-1]}': Opération non permise")
        return droits

    def droits_saisis(self, saisie):
        if not self.commande:
            return saisie or self.avant
        try:
            return self.executer(saisie or "")
        except ValueError:
            return self.avant

    def juste(self):
        if not self.commande:
            return self.droits
        octal = "".join(str(sum(4 >> j for j in range(3) if self.droits[3 * i + j] != "-")) for i in range(3))
        return ("sudo " if self.refusee("chmod") else "") + f"chmod {octal} {self.fichier}"

    def corriger(self, saisie):
        apres = self.droits_saisis(saisie)
        attendus = [i for i in range(9) if self.droits[i] != self.avant[i]]
        justes = sum(apres[i] == self.droits[i] for i in attendus)
        fausses = sum(apres[i] != self.avant[i] for i in range(9) if i not in attendus)
        return max(0, (justes - fausses) / len(attendus)), None

    def _attendu(self):
        if not self.commande:
            return f"`{self.droits}`"
        sudo = "sudo " if self.refusee("chmod") else ""
        if self.notation_annexe:
            mode = " ".join(self.droits[3 * i:3 * i + 3] for i in range(3))
        else:
            changes = {(c, op): "".join(l for j, l in enumerate("rwx") if self.droits[3 * i + j] != self.avant[3 * i + j]
                                        and (self.droits[3 * i + j] == l) == (op == "+"))
                       for i, c in enumerate("ugo") for op in "+-"}
            mode = ",".join(c + op + lettres for (c, op), lettres in changes.items() if lettres)
        return f"`{sudo}chmod {mode} {self.fichier}` (ou `{self.juste()}`)"

    def problemes(self):
        p = super().problemes()
        for nom in ("droits", "avant"):
            if not re.fullmatch(TRIPLET.pattern * 3, getattr(self, nom)):
                p.append(("erreur", f"{nom} : 9 caractères, r, w, x ou - à leur place (rwxr-xr--)"))
        if not p and self.droits == self.avant:
            p.append(("erreur", "droits identiques à avant : rien à changer"))
        if not self.fichier or "/" in self.fichier:
            p.append(("erreur", "fichier : un nom, sans chemin"))
        if (self.utilisateur or self.proprietaire or self.notation_annexe) and not self.commande:
            p.append(("avert", "utilisateur, proprietaire et notation_annexe ne servent qu'avec commande"))
        if not p and self.corriger(self.juste())[0] != 1:
            p.append(("erreur", "la réponse attendue n'obtient pas la note maximale"))
        return p


DESSINS_AXE = ("maison", "antenne")  # les objets que l'axe sait dessiner ; tout autre nom : un point étiqueté


class Pose(Objet):
    """Une sorte d'objet d'une question ``axe`` : ``nom`` (« maison », « antenne » se dessinent, un autre nom fait un
    point étiqueté), ``positions`` sur l'axe, ``donne`` s'il est déjà placé (l'élève n'y touche pas), ``portee`` > 0 :
    la double flèche de portée que la correction trace autour de chaque objet (une antenne et son rayon d'action)."""

    def __init__(self, nom, positions, donne=False, portee=0):
        self.nom, self.positions, self.donne, self.portee = nom, positions, donne, portee


class Axe(Question):
    """Un axe gradué (1.56 des widgets de bac) de ``debut`` à ``fin``, une graduation tous les ``pas``, un nombre tous
    les ``legende`` (``pas`` à défaut) ; l'élève y pose les objets de ``objets`` qui ne sont pas ``donne``, aimantés à
    ``finesse`` près (``pas`` à défaut).

    ``saisie`` = {nom: [positions]}. Notée comme les cases à cocher (``penalite``) : chaque position attendue posée compte
    un, chaque position posée à tort retire un. La note compare des ENSEMBLES : elle suppose une réponse unique (un
    algorithme imposé, une liste donnée) ; « un placement qui couvre toutes les maisons », qui en admet plusieurs,
    demanderait une note par couverture que ce type n'a pas."""

    type = "axe"

    def __init__(self, id, enonce, debut, fin, objets, pas=1, legende=None, finesse=None, **commun):
        super().__init__(id, enonce, **commun)
        self.debut, self.fin, self.pas, self.legende, self.finesse = debut, fin, pas, legende, finesse
        self.objets = objets
        self._construire()

    def cran(self):
        return self.finesse or self.pas

    def crans(self, positions):
        """Les positions en nombres de crans depuis ``debut`` : des entiers, que les flottants ne trahissent pas."""
        return {round((p - self.debut) / self.cran()) for p in positions}

    def a_poser(self):
        return [o for o in self.objets if not o.donne]

    def juste(self):
        return {o.nom: sorted(o.positions) for o in self.a_poser()}

    def corriger(self, saisie):
        saisie, justes, fausses, attendus = saisie or {}, 0, 0, 0
        for o in self.a_poser():
            attendu, pose = self.crans(o.positions), self.crans(saisie.get(o.nom, []))
            attendus += len(attendu)
            justes += len(attendu & pose)
            fausses += len(pose - attendu)
        return max(0, (justes - fausses) / attendus), None

    def _attendu(self):
        return " ; ".join(f"{o.nom} en " + ", ".join(f"{p:g}".replace(".", ",") for p in sorted(o.positions))
                          for o in self.a_poser())

    # -- la figure, la même à l'écran (``AxeGradue`` la dessine et pose ses objets aux places de ``geometrie``) et sur le papier

    MARGE, BANDE, CORPS = 12, 40, 10  # en points : marge à droite, hauteur d'une bande d'objets, corps des nombres

    def geometrie(self):
        """Les places de la figure, en points : ``x(v)`` l'abscisse de la valeur ``v`` ; ``bande(i)`` le bas de la bande
        de l'objet ``i`` (une bande par sorte d'objet, au-dessus de l'axe : une antenne et une maison au même point ne se
        cachent pas) ; ``axe`` l'ordonnée du trait ; ``portee`` celle des doubles flèches, sous les nombres ; ``gauche`` la
        marge où chaque bande montre l'objet qu'elle reçoit."""
        unite = max(24, 12 / self.cran())  # un cran visable : 12 points au moins
        gauche = max([54] + [6 * len(o.nom) + 26 for o in self.objets if o.nom not in DESSINS_AXE])
        axe = self.BANDE * len(self.objets) + 6
        portee = axe + 30
        return {"x": lambda v: gauche + (v - self.debut) * unite, "unite": unite, "gauche": gauche, "axe": axe,
                "bande": lambda i: self.BANDE * (i + 1), "portee": portee,
                "largeur": gauche + (self.fin - self.debut) * unite + self.MARGE,
                "hauteur": portee + (8 if any(o.portee for o in self.objets) else -6)}

    def position(self, k):
        """La valeur du cran ``k`` : un entier quand elle l'est (``2``, pas ``2.0``), arrondie sinon (``0.1 * 3``)."""
        v = round(self.debut + k * self.cran(), 9)
        return int(v) if v == int(v) else v

    def svg(self, poses=None, couleur="#1565c0", portees=False, police="Carlito", largeur_max=None):
        """L'axe, ses graduations et ses nombres, les objets donnés en gris, et ``poses`` ({nom: [positions]}) en
        ``couleur`` : la saisie de l'élève à l'écran, la réponse au corrigé. ``portees`` : la double flèche de portée
        sous l'axe pour chaque objet posé qui en a une. Un point par unité ; ``largeur_max`` (en points) réduit la taille
        déclarée, sans toucher au dessin."""
        g, poses = self.geometrie(), poses or {}
        largeur, hauteur = g["largeur"], g["hauteur"]
        reduction = min(1, largeur_max / largeur) if largeur_max else 1
        s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{largeur * reduction / 72:.3f}in" height="{hauteur * reduction / 72:.3f}in" '
             f'viewBox="0 0 {largeur:.1f} {hauteur:.1f}" font-family="{police}" font-size="{self.CORPS}">']
        y = g["axe"]
        s.append(f'<line x1="{g["gauche"] - 8:.1f}" y1="{y}" x2="{g["x"](self.fin) + 8:.1f}" y2="{y}" stroke="#000000" stroke-width="1.5"/>')
        n, legende = round((self.fin - self.debut) / self.pas), self.legende or self.pas
        for k in range(n + 1):
            v = self.debut + k * self.pas
            nombre = abs((v - self.debut) / legende - round((v - self.debut) / legende)) < 1e-9
            x, h = g["x"](v), 6 if nombre else 4
            s.append(f'<line x1="{x:.1f}" y1="{y - h}" x2="{x:.1f}" y2="{y + h}" stroke="#000000" stroke-width="1.2"/>')
            if nombre:
                s.append(f'<text x="{x:.1f}" y="{y + 18}" text-anchor="middle">{f"{round(v, 9):g}".replace(".", ",")}</text>')
        for i, o in enumerate(self.objets):
            base = g["bande"](i)
            s.append(self.dessin(o.nom, 14, base, "#9e9e9e", legende=True))
            places = o.positions if o.donne else poses.get(o.nom, [])
            for p in places:
                s.append(self.dessin(o.nom, g["x"](p), base, "#757575" if o.donne else couleur))
                if portees and o.portee:
                    a, b, yp = g["x"](max(self.debut, p - o.portee)), g["x"](min(self.fin, p + o.portee)), g["portee"]
                    s.append(f'<g stroke="{couleur}" fill="{couleur}" stroke-width="1"><line x1="{a + 4:.1f}" y1="{yp}" x2="{b - 4:.1f}" y2="{yp}"/>'
                             f'<polygon points="{a:.1f},{yp} {a + 6:.1f},{yp - 3} {a + 6:.1f},{yp + 3}"/>'
                             f'<polygon points="{b:.1f},{yp} {b - 6:.1f},{yp - 3} {b - 6:.1f},{yp + 3}"/></g>')
        return "\n".join(s + ["</svg>"]) + "\n"

    @staticmethod
    def dessin(nom, x, base, couleur, legende=False):
        """L'objet ``nom`` debout sur ``base``, centré sur ``x``, comme dans les sujets de bac : la maison, l'antenne (mât en
        triangle, ondes de part et d'autre) ; tout autre nom, un rond plein (et son nom en légende)."""
        trait = f'stroke="{couleur}" fill="none" stroke-width="1.2"'
        if nom == "maison":
            return (f'<g {trait}><rect x="{x - 7:.1f}" y="{base - 16}" width="14" height="16" fill="#ffffff"/>'
                    f'<polygon points="{x - 7:.1f},{base - 16} {x:.1f},{base - 24} {x + 7:.1f},{base - 16}" fill="#ffffff"/>'
                    f'<rect x="{x - 2:.1f}" y="{base - 6}" width="4" height="6"/></g>')
        if nom == "antenne":
            return (f'<g {trait}><polygon points="{x - 6:.1f},{base} {x:.1f},{base - 26} {x + 6:.1f},{base}"/>'
                    f'<line x1="{x - 3:.1f}" y1="{base - 13}" x2="{x + 3:.1f}" y2="{base - 13}"/>'
                    f'<circle cx="{x:.1f}" cy="{base - 29}" r="2.2" fill="{couleur}"/>'
                    + "".join(f'<path d="M {x - d:.1f} {base - 29 - r} A {r} {r} 0 0 {sens} {x - d:.1f} {base - 29 + r}"/>'
                              f'<path d="M {x + d:.1f} {base - 29 - r} A {r} {r} 0 0 {1 - sens} {x + d:.1f} {base - 29 + r}"/>'
                              for d, r, sens in ((5, 5, 0), (8, 8, 0)))
                    + "</g>")
        if legende:
            return f'<text x="{x - 10:.1f}" y="{base - 8}" text-anchor="start" fill="{couleur}">{html.escape(nom)}</text>'
        return f'<circle cx="{x:.1f}" cy="{base - 8}" r="4.5" fill="{couleur}" stroke="none"/>'

    def problemes(self):
        p = super().problemes()
        if not self.debut < self.fin or self.pas <= 0 or self.cran() <= 0:
            return p + [("erreur", "il faut debut < fin, pas et finesse positifs")]
        noms = [o.nom for o in self.objets]
        if len(set(noms)) != len(noms):
            p.append(("erreur", "deux objets portent le même nom"))
        if not any(o.positions for o in self.a_poser()):
            p.append(("erreur", "aucune position à poser par l'élève (objets tous donnés ou vides)"))
        for o in self.objets:
            if len(self.crans(o.positions)) != len(o.positions):
                p.append(("erreur", f"{o.nom} : deux positions sur le même cran"))
            for x in o.positions:
                if not self.debut <= x <= self.fin or abs((x - self.debut) / self.cran() - round((x - self.debut) / self.cran())) > 1e-9:
                    p.append(("erreur", f"{o.nom} en {x:g} : hors de l'axe ou entre deux crans de finesse"))
            if o.portee < 0:
                p.append(("erreur", f"{o.nom} : portée négative"))
        if not p and self.corriger(self.juste())[0] != 1:
            p.append(("erreur", "la réponse attendue n'obtient pas la note maximale"))
        return p


class Maillon(Objet):
    """Un maillon d'une question ``liste_chainee`` : ``nom``, qui le désigne (deux maillons de même valeur ont deux noms),
    ``pointeurs`` = {champ: nom du maillon visé, ou ``None``}, un par case pointeur ; ``donnes`` : les champs déjà tracés,
    que l'élève ne touche pas ; ``valeur`` : ce qu'affiche sa case centrale (``nom`` à défaut)."""

    def __init__(self, nom, pointeurs, donnes=(), valeur=None):
        self.nom, self.pointeurs, self.donnes, self.valeur = nom, pointeurs, list(donnes), valeur


class ListeChainee(Question):
    """Un schéma de maillons (1.44 des widgets de bac : liste chaînée, pile ou file chaînée, collier circulaire) : chaque
    maillon est une boîte de cases, ``champs`` dans l'ordre (``valeur`` désigne la case centrale), et l'élève tire la flèche
    de chaque case pointeur vers le maillon visé, ou y écrit ``None``.

    ``saisie`` = {"nom.champ": nom visé ou ``None``}, une clé par pointeur rempli. Notée sur les pointeurs à remplir : chacun
    juste compte un, sans pénalité (un pointeur n'a qu'une réponse). Une case laissée vide ne vaut pas ``None``."""

    type = "liste_chainee"

    def __init__(self, id, enonce, maillons, champs=("pred", "valeur", "succ"), **commun):
        super().__init__(id, enonce, **commun)
        self.maillons, self.champs = maillons, list(champs)
        self._construire()

    def pointeurs(self):
        return [c for c in self.champs if c != "valeur"]

    def a_remplir(self):
        """Les clés « nom.champ » que l'élève remplit."""
        return [f"{m.nom}.{c}" for m in self.maillons for c in self.pointeurs() if c not in m.donnes]

    def attendu(self, cle):
        nom, _, champ = cle.rpartition(".")
        return next(m for m in self.maillons if m.nom == nom).pointeurs.get(champ)

    def juste(self):
        return {cle: self.attendu(cle) for cle in self.a_remplir()}

    def corriger(self, saisie):
        saisie, cles = saisie or {}, self.a_remplir()
        return sum(cle in saisie and saisie[cle] == self.attendu(cle) for cle in cles) / len(cles), None

    def _attendu(self):
        return " ; ".join(f"`{cle}` → {'`None`' if (v := self.attendu(cle)) is None else v}" for cle in self.a_remplir())

    # -- la figure, la même à l'écran (``Chaine`` la dessine et y prend les flèches tirées) et sur le papier

    MARGE, CASE, CENTRE, HAUTEUR, ECART, BANDE, CORPS = 10, 26, 34, 24, 46, 46, 10  # en points

    def cote(self, champ):
        """+1 pour une case à droite de la valeur (ses flèches passent au-dessus), -1 à gauche (au-dessous)."""
        return 1 if self.champs.index(champ) > self.champs.index("valeur") else -1

    def geometrie(self):
        """Les places de la figure, en points : ``case(i, champ)`` le rectangle (x, y, l, h) d'une case du maillon ``i`` ;
        ``boite(i)`` celui du maillon entier ; ``haut`` l'ordonnée du haut des boîtes."""
        largeurs = [self.CENTRE if c == "valeur" else self.CASE for c in self.champs]
        boite = sum(largeurs)
        haut = self.MARGE + (self.BANDE if any(self.cote(c) > 0 for c in self.pointeurs()) else 0)
        bas = self.BANDE if any(self.cote(c) < 0 for c in self.pointeurs()) else 0

        def case(i, champ):
            k = self.champs.index(champ)
            return (self.MARGE + i * (boite + self.ECART) + sum(largeurs[:k]), haut, largeurs[k], self.HAUTEUR)

        return {"case": case, "boite": lambda i: (self.MARGE + i * (boite + self.ECART), haut, boite, self.HAUTEUR),
                "haut": haut, "largeur": 2 * self.MARGE + len(self.maillons) * (boite + self.ECART) - self.ECART,
                "hauteur": haut + self.HAUTEUR + bas + self.MARGE}

    def trace(self, i, champ, j):
        """La flèche de la case ``champ`` du maillon ``i`` vers le maillon ``j`` : (départ, points de contrôle, arrivée),
        des (x, y) en points. Vers le voisin naturel (une case de droite vers le suivant, de gauche vers le précédent), un
        trait droit, au tiers haut ou bas de la boîte pour que les deux sens ne se couvrent pas ; ailleurs, et vers soi-même,
        une courbe par-dessus (case de droite) ou par-dessous, qui arrive au milieu du bord de la boîte visée."""
        g, cote = self.geometrie(), self.cote(champ)
        x, y, l, h = g["case"](i, champ)
        depart = (x + l / 2, y + h / 2 - cote * h / 6)
        bx, by, bl, bh = g["boite"](j)
        if j == i + cote:
            arrivee = (bx if cote > 0 else bx + bl, depart[1])
            return depart, [], arrivee
        bord = by if cote > 0 else by + bh
        arrivee = (bx + bl / 2 + (6 if j < i else -6 if j > i else 0), bord)
        creux = min(self.BANDE - 8, 16 + 8 * abs(j - i))
        sommet = bord - cote * creux
        return depart, [(depart[0], sommet), (arrivee[0], sommet)], arrivee

    def svg(self, saisie=None, couleur="#1565c0", police="Carlito", largeur_max=None):
        """Les maillons, leurs pointeurs donnés en noir et ceux de ``saisie`` en ``couleur`` (l'élève à l'écran, la
        réponse au corrigé) : une flèche vers le maillon visé, ``None`` écrit dans la case. Un point par unité ;
        ``largeur_max`` (en points) réduit la taille déclarée, sans toucher au dessin."""
        g, saisie = self.geometrie(), saisie or {}
        largeur, hauteur = g["largeur"], g["hauteur"]
        reduction = min(1, largeur_max / largeur) if largeur_max else 1
        s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{largeur * reduction / 72:.3f}in" height="{hauteur * reduction / 72:.3f}in" '
             f'viewBox="0 0 {largeur:.1f} {hauteur:.1f}" font-family="{police}" font-size="{self.CORPS}">']
        index = {m.nom: i for i, m in enumerate(self.maillons)}
        for i, m in enumerate(self.maillons):
            for c in self.champs:
                x, y, l, h = g["case"](i, c)
                s.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{l:.1f}" height="{h:.1f}" fill="#ffffff" stroke="#000000" stroke-width="1"/>')
                if c == "valeur":
                    s.append(f'<text x="{x + l / 2:.1f}" y="{y + h / 2 + 3.5:.1f}" text-anchor="middle">'
                             f'{html.escape(str(m.nom if m.valeur is None else m.valeur))}</text>')
        for i, m in enumerate(self.maillons):
            for c in self.pointeurs():
                cle = f"{m.nom}.{c}"
                if c in m.donnes:
                    cible, teinte = m.pointeurs.get(c), "#000000"
                elif cle in saisie:
                    cible, teinte = saisie[cle], couleur
                else:
                    continue
                if cible is None:
                    x, y, l, h = g["case"](i, c)
                    s.append(f'<text x="{x + l / 2:.1f}" y="{y + h / 2 + 3:.1f}" text-anchor="middle" font-size="8" fill="{teinte}">None</text>')
                elif cible in index:
                    s.append(self.fleche(*self.trace(i, c, index[cible]), teinte))
        return "\n".join(s + ["</svg>"]) + "\n"

    @staticmethod
    def fleche(depart, controles, arrivee, couleur):
        """Un point au départ, le trait (droit, ou courbe de Bézier par ``controles``) et la pointe à l'arrivée."""
        (x0, y0), (x1, y1) = depart, arrivee
        chemin = f"M {x0:.1f} {y0:.1f} " + (f"C {controles[0][0]:.1f} {controles[0][1]:.1f} {controles[1][0]:.1f} {controles[1][1]:.1f} "
                                             if controles else "L ") + f"{x1:.1f} {y1:.1f}"
        dx, dy = (x1 - controles[1][0], y1 - controles[1][1]) if controles else (x1 - x0, y1 - y0)
        n = math.hypot(dx, dy) or 1
        dx, dy = dx / n, dy / n
        pointe = f"{x1:.1f},{y1:.1f} {x1 - 7 * dx - 3 * dy:.1f},{y1 - 7 * dy + 3 * dx:.1f} {x1 - 7 * dx + 3 * dy:.1f},{y1 - 7 * dy - 3 * dx:.1f}"
        return (f'<g stroke="{couleur}" fill="{couleur}" stroke-width="1.2"><circle cx="{x0:.1f}" cy="{y0:.1f}" r="2" stroke="none"/>'
                f'<path d="{chemin}" fill="none"/><polygon points="{pointe}" stroke="none"/></g>')

    def problemes(self):
        p = super().problemes()
        if self.champs.count("valeur") != 1 or len(set(self.champs)) != len(self.champs):
            return p + [("erreur", "champs : des noms distincts, dont « valeur » une fois")]
        noms = [m.nom for m in self.maillons]
        if len(set(noms)) != len(noms):
            p.append(("erreur", "deux maillons portent le même nom (``valeur`` peut se répéter, pas ``nom``)"))
        for m in self.maillons:
            if set(m.pointeurs) != set(self.pointeurs()):
                p.append(("erreur", f"{m.nom} : un pointeur par champ, {', '.join(self.pointeurs())}"))
            p += [("erreur", f"{m.nom}.{c} : « {v} » n'est le nom d'aucun maillon") for c, v in m.pointeurs.items()
                  if v is not None and v not in noms]
            p += [("erreur", f"{m.nom} : champ donné « {c} » inconnu") for c in m.donnes if c not in self.pointeurs()]
        if not self.a_remplir():
            p.append(("erreur", "tous les pointeurs sont donnés : rien à tracer"))
        return p


SUIVIES = ("", "tri_fusion")  # ``Deroulement.suivie`` : à la place, ou en suivant l'erreur selon la règle du tri fusion
TROP = object()  # ce qu'attend une case de ``Deroulement`` qui n'a pas lieu d'être : de trop si elle est remplie


def liste_ecrite(valeurs):
    """Une liste écrite comme dans les sujets : « [46, 108] »."""
    return "[" + ", ".join(repr(v) for v in valeurs) + "]"


class Deroulement(Question):
    """Le déroulement d'un algorithme « diviser pour régner », que l'élève construit (1.58 des widgets de bac : le tri
    fusion du bac Liban 2023 jour 2). De la liste de départ, il sépare chaque liste en deux, jusqu'à celles qu'on ne
    sépare plus ; sous chaque séparation paraît la case de sa fusion, où il écrit la liste qui en remonte, comme
    l'exemple du sujet.

    ``attendu`` : l'arbre attendu, {"texte": liste écrite, "fils": [arbres], "fusion": liste écrite}, sans ``fils`` ni
    ``fusion`` pour une liste qu'on ne sépare pas ; son ``texte`` est la liste de départ, donnée. ``saisie`` : l'arbre
    de l'élève, de même forme. ``suivie`` : "" (défaut), chaque case comparée à celle de même place dans ``attendu`` ;
    "tri_fusion", l'erreur suivie : chaque case jugée sur ce que l'élève a écrit au-dessus d'elle (la moitié de sa
    liste coupée à ``len // 2`` ; sa fusion, ce qui remonte de ses fils, trié), et ``attendu`` doit suivre cette règle.

    Notée sur les cases d'``attendu``, la liste de départ exceptée : chaque case juste compte un, chaque case remplie qui
    n'a pas lieu d'être (une séparation de trop) en retire un, plancher 0. Une liste se compare en valeur (« [46,108] »
    vaut « [46, 108] », crochets facultatifs comme en réponse courte), dans l'ordre ; un texte qui n'est pas une liste
    Python, à la lettre, espaces exceptés."""

    type = "deroulement"

    def __init__(self, id, enonce, attendu, suivie="", **commun):
        super().__init__(id, enonce, **commun)
        self.attendu, self.suivie = attendu, suivie
        self._construire()

    def racine(self):
        return self.attendu["texte"]

    def juste(self):
        return copier(self.attendu)

    @staticmethod
    def cases_de(arbre, chemin=()):
        """(chemin, sorte, texte) de chaque case de l'arbre, de haut en bas : sa liste (``"texte"``, sauf à la racine,
        donnée) puis, sous une liste séparée, sa fusion (``"fusion"``) ; ``chemin`` : les rangs des fils depuis la racine."""
        if chemin:
            yield chemin, "texte", arbre.get("texte", "")
        for i, fils in enumerate(arbre.get("fils") or []):
            yield from Deroulement.cases_de(fils, chemin + (i,))
        if arbre.get("fils"):
            yield chemin, "fusion", arbre.get("fusion", "")

    @staticmethod
    def tri_fusion(valeurs):
        """L'arbre du tri fusion de ``valeurs``, coupées à ``len // 2`` (la règle de ``suivie``)."""
        if len(valeurs) <= 1:
            return {"texte": liste_ecrite(valeurs)}
        m = len(valeurs) // 2
        return {"texte": liste_ecrite(valeurs), "fils": [Deroulement.tri_fusion(valeurs[:m]), Deroulement.tri_fusion(valeurs[m:])],
                "fusion": liste_ecrite(sorted(valeurs))}

    def valeur(self, texte):
        """La liste qu'écrit un texte (crochets facultatifs), ``ILLISIBLE`` sinon ; bornée en longueur : ``literal_eval``
        d'une saisie démesurée (« [[[[… ») coûte cher avant d'échouer."""
        texte = str(texte or "").strip()
        if not texte or len(texte) > 4 * len(self.racine()) + 20:
            return ILLISIBLE
        return valeur_saisie(texte, "liste")

    def egal(self, texte, attendu):
        if attendu is TROP or attendu is ILLISIBLE or not str(texte or "").strip():
            return False
        valeur = self.valeur(attendu)
        if valeur is ILLISIBLE:
            return re.sub(r"\s", "", str(texte)) == re.sub(r"\s", "", attendu)
        return self.valeur(texte) == valeur

    def attendus(self, saisie):
        """{(chemin, sorte): ce qu'attend chaque case de ``saisie``} : un texte, ``TROP`` (la case n'a pas lieu d'être) ou,
        en erreur suivie, ``ILLISIBLE`` (ce qu'elle suit ne s'y prête pas : elle ne peut pas être juste)."""
        saisie = saisie or {}
        if not self.suivie:
            reference = {(c, s): t for c, s, t in self.cases_de(self.attendu)}
            return {(c, s): reference.get((c, s), TROP) for c, s, _ in self.cases_de(saisie)}
        resultat = {}

        def suivre(noeud, chemin, attendue, ecrite):  # ecrite : la liste écrite dans le nœud, ce que ses fils suivent
            if chemin:
                resultat[chemin, "texte"] = attendue
            fils = noeud.get("fils") or []
            separable = attendue is not TROP and (ecrite is ILLISIBLE or len(ecrite) > 1)
            for i, f in enumerate(fils):
                if not separable or i >= 2:
                    a = TROP
                elif ecrite is ILLISIBLE:
                    a = ILLISIBLE
                else:
                    a = liste_ecrite((ecrite[:len(ecrite) // 2], ecrite[len(ecrite) // 2:])[i])
                suivre(f, chemin + (i,), a, self.valeur(f.get("texte")))
            if fils:
                remontees = [self.valeur(f.get("fusion") if f.get("fils") else f.get("texte")) for f in fils]
                try:
                    fusion = ILLISIBLE if ILLISIBLE in remontees else liste_ecrite(sorted(sum(remontees, [])))
                except TypeError:  # des valeurs qui ne se comparent pas : [1, "a"]
                    fusion = ILLISIBLE
                resultat[chemin, "fusion"] = fusion if separable else TROP

        suivre(saisie, (), self.racine(), self.valeur(self.racine()))
        return resultat

    def corriger(self, saisie):
        attendus, textes = self.attendus(saisie), {(c, s): t for c, s, t in self.cases_de(saisie or {})}
        n = sum(1 for _ in self.cases_de(self.attendu)) or 1
        justes = sum(self.egal(textes[k], a) for k, a in attendus.items())
        trop = sum(a is TROP and bool(str(textes[k]).strip()) for k, a in attendus.items())
        return max(0, (min(justes, n) - trop) / n), None

    def manquantes(self, saisie):
        """Les cases d'``attendu`` que l'élève n'a pas construites : la surimpression ne peut pas les corriger en place."""
        construites = {(c, s) for c, s, _ in self.cases_de(saisie or {})}
        return [(c, s) for c, s, _ in self.cases_de(self.attendu) if (c, s) not in construites]

    def _attendu(self):
        """Rien quand l'élève a construit toutes les cases : elles sont corrigées à la main en surimpression ; sinon le
        déroulement attendu, rangée par rangée, qu'aucune case ne peut porter."""
        if not self.manquantes(self.saisie):
            return ""
        lignes = ["   ".join(t for _, t in sorted(rangee)) for rangee in self.rangees(self.attendu)]
        return "Le déroulement attendu :\n\n```\n" + "\n".join(lignes) + "\n```"

    # -- la figure : les mêmes places à l'écran (``ArbreDeroulement`` y pose ses champs) et sur le papier (``svg``)

    HAUTEUR, ECART, MARGE, CORPS, LARGEUR = 20, 16, 6, 10, 410  # en points ; LARGEUR : celle de l'exemple du bac

    def places(self, arbre, largeur=None, plafond=None):
        """Les places de ``arbre``, en points, sur ``largeur`` (``LARGEUR`` à défaut), aucune case plus large que
        ``plafond`` (de quoi écrire la liste de départ, à défaut) : ``cases`` {(chemin, sorte):
        (x, y, l, h)}, la racine en ((), "texte") ; ``fleches`` [(x1, y1, x2, y2)], de chaque liste vers ses moitiés,
        et de ce qui remonte de chaque moitié vers la fusion ; ``hauteur``. Une liste séparée à la profondeur d est sur
        la rangée d, sa fusion sur la rangée 2D − d (D : la plus grande profondeur) : l'arbre et son miroir, comme
        l'exemple du sujet. Chaque liste non séparée occupe une colonne, une liste séparée s'étend sur celles de ses
        moitiés."""
        largeur = largeur or self.LARGEUR

        def profondeur(n):
            return 1 + max(map(profondeur, n["fils"])) if n.get("fils") else 0

        def feuilles(n):
            return sum(map(feuilles, n["fils"])) if n.get("fils") else 1

        d_max, colonne = profondeur(arbre), largeur / feuilles(arbre)
        plafond = plafond or 6 * len(self.racine()) + 20  # assez large pour la plus longue liste, la liste de départ
        cases, fleches = {}, []

        def rang(r):
            return r * (self.HAUTEUR + self.ECART)

        def placer(n, chemin, d, debut):  # debut : la première colonne du nœud ; rend la case qui remonte de lui
            fin = debut + feuilles(n)
            l = min((fin - debut) * colonne - self.MARGE, plafond)
            x = (debut + fin) * colonne / 2 - l / 2
            cases[chemin, "texte"] = haut = (x, rang(d), l, self.HAUTEUR)
            if not n.get("fils"):
                return haut
            cases[chemin, "fusion"] = bas = (x, rang(2 * d_max - d), l, self.HAUTEUR)
            for i, f in enumerate(n["fils"]):
                remontee = placer(f, chemin + (i,), d + 1, debut)
                fils_haut = cases[chemin + (i,), "texte"]
                fleches.append((x + l / 2, haut[1] + self.HAUTEUR, fils_haut[0] + fils_haut[2] / 2, fils_haut[1]))
                fleches.append((remontee[0] + remontee[2] / 2, remontee[1] + self.HAUTEUR, x + l / 2, bas[1]))
                debut += feuilles(f)
            return bas

        placer(arbre, (), 0, 0)
        return {"cases": cases, "fleches": fleches, "hauteur": rang(2 * d_max) + self.HAUTEUR}

    def rangees(self, arbre):
        """Les textes de l'arbre par rangée, de haut en bas : [[(x, texte)]]."""
        places, textes = self.places(arbre)["cases"], {(c, s): t for c, s, t in self.cases_de(arbre)}
        textes[(), "texte"] = arbre.get("texte", "")
        rangees = {}
        for k, (x, y, _, _) in places.items():
            rangees.setdefault(y, []).append((x, textes[k]))
        return [rangees[y] for y in sorted(rangees)]

    def svg(self, arbre=None, couleur="#1565c0", police="Carlito", largeur=None, main=False):
        """L'arbre en vecteurs, comme l'exemple du sujet (des listes et des flèches, sans cadres) : la liste de départ en
        noir, les autres en ``couleur`` (et à la main, en ``POLICE_MAIN`` 9 pt, si ``main`` : le corrigé). Sans ``arbre``, la même place laissée blanche (la copie de l'élève : au bac, il
        construit l'arbre sur sa copie). ``largeur`` en points, ``LARGEUR`` à défaut."""
        largeur = largeur or self.LARGEUR
        g = self.places(arbre or self.attendu, largeur)
        s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{largeur / 72:.3f}in" height="{g["hauteur"] / 72:.3f}in" '
             f'viewBox="0 0 {largeur:.1f} {g["hauteur"]:.1f}" font-family="{police}" font-size="{self.CORPS}">']
        if arbre:
            textes = {(c, s): t for c, s, t in self.cases_de(arbre)}
            textes[(), "texte"] = self.racine()
            for k, (x, y, l, h) in g["cases"].items():
                donnee = k == ((), "texte")
                s.append(f'<text x="{x + l / 2:.1f}" y="{y + h / 2 + self.CORPS * 0.35:.1f}" text-anchor="middle" '
                         + (f'font-family="{POLICE_MAIN}" font-size="9" ' if main and not donnee else "")
                         + f'fill="{"#000000" if donnee else couleur}">{html.escape(str(textes[k]))}</text>')
            for x1, y1, x2, y2 in g["fleches"]:
                s.append(fleche_svg(x1, y1 + 1, x2, y2 - 1))
        return "\n".join(s + ["</svg>"]) + "\n"

    def problemes(self):
        p = super().problemes()
        if self.suivie not in SUIVIES:
            return p + [("erreur", f"suivie « {self.suivie} » : {', '.join(map(repr, SUIVIES))}")]
        if not isinstance(self.attendu, dict) or not str(self.attendu.get("texte", "")).strip():
            return p + [("erreur", "attendu sans liste de départ (« texte »)")]
        if not self.attendu.get("fils"):
            return p + [("erreur", "attendu sans séparation : rien à dérouler")]

        def verifier(n):
            if n.get("fils") and (len(n["fils"]) < 2 or not str(n.get("fusion", "")).strip()):
                p.append(("erreur", f"{n.get('texte')} : une séparation a deux fils au moins et une fusion"))
            for f in n.get("fils") or []:
                if not str(f.get("texte", "")).strip():
                    p.append(("erreur", f"{n.get('texte')} : un fils sans liste"))
                verifier(f)

        verifier(self.attendu)
        if self.suivie == "tri_fusion":
            depart = self.valeur(self.racine())
            regle = None if depart is ILLISIBLE else self.tri_fusion(depart)
            if regle is None or [(c, s) for c, s, _ in self.cases_de(regle)] != [(c, s) for c, s, _ in self.cases_de(self.attendu)] \
                    or not all(self.egal(t, a) for (_, _, t), (_, _, a) in zip(self.cases_de(self.attendu), self.cases_de(regle))):
                p.append(("erreur", "attendu ne suit pas la règle du tri fusion (moitiés coupées à len // 2, fusions triées)"))
        if not p and self.corriger(self.juste())[0] != 1:
            p.append(("erreur", "la réponse attendue n'obtient pas la note maximale"))
        return p


def fleche_svg(x1, y1, x2, y2, couleur="#000000"):
    """Une flèche de (x1, y1) à (x2, y2), sa pointe pleine comme celles des sujets de bac."""
    longueur = math.hypot(x2 - x1, y2 - y1) or 1
    ux, uy = (x2 - x1) / longueur, (y2 - y1) / longueur
    bx, by = x2 - 7 * ux, y2 - 7 * uy
    return (f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{bx:.1f}" y2="{by:.1f}" stroke="{couleur}" stroke-width="1"/>'
            f'<polygon points="{x2:.1f},{y2:.1f} {bx - 3 * uy:.1f},{by + 3 * ux:.1f} {bx + 3 * uy:.1f},{by - 3 * ux:.1f}" fill="{couleur}"/>')


class Personnalise(Question):
    """Une question dont le professeur écrit lui-même le widget, quand aucun type ne convient.

    ``widget`` est du code Python exécuté à la construction, avec pour noms de départ ceux de ce module (les classes
    Qt, ``Texte``, ``hauteur``…). Il y définit des fonctions qui reçoivent la question en premier argument et tiennent
    lieu des méthodes d'un type : ``corps(q, d)`` (les widgets de saisie, ajoutés à la disposition ``d`` et à
    ``q.entrees`` pour être grisés hors épreuve), ``lire(q)`` (la saisie, en JSON), ``ecrire(q, valeur)`` (l'inverse),
    ``corriger(q, saisie)`` (``(fraction, indice)``) et, facultative, ``juste(q)`` (la bonne saisie, que le corrigé
    montre dans le widget). ``papier`` et ``attendu`` sont le repli Markdown des exports imprimés : un widget ne
    s'imprime pas.

    Ce code est celui du professeur, embarqué dans le sujet comme le ``tests_code`` d'une question ``code`` : il
    n'est ni filtré ni confiné. Il est en revanche isolé des pannes — une erreur, à son exécution comme dans l'une
    de ses fonctions, dégrade la question en message rouge et renvoie sa correction au professeur, au lieu
    d'emporter le paquet en pleine épreuve."""

    type = "personnalise"

    def __init__(self, id, enonce, widget, papier="", attendu="", **commun):
        super().__init__(id, enonce, **commun)
        self.widget, self.papier, self.attendu = widget, papier, attendu
        self.fonctions, self.panne = {}, ""
        self._construire()

    def _casser(self, quoi, exc):
        """Panne du code du professeur : la question le dit en rouge, et sa correction lui revient."""
        traceback.print_exc()
        self.panne = f"{quoi} : {exc.__class__.__name__} : {exc}"

    def _appeler(self, nom, defaut, *args):
        """La fonction du professeur, ou ``defaut`` si elle manque, si elle tombe, ou si la question est déjà en panne."""
        if self.panne or nom not in self.fonctions:
            return defaut
        try:
            return self.fonctions[nom](self, *args)
        except Exception as exc:  # noqa: BLE001 - n'importe quelle erreur du code du professeur
            self._casser(f"{nom}()", exc)
            return defaut

    def juste(self):
        return self._appeler("juste", None)

    def corriger(self, saisie):
        return self._appeler("corriger", (None, None), saisie)  # en panne : fraction None, la question attend le professeur

    def _attendu(self):
        return self.attendu

    def problemes(self):
        p = super().problemes()
        if self.panne:
            p.append(("erreur", f"widget : {self.panne}"))
        if not self.attendu:
            p.append(("avert", "sans attendu : le corrigé n'aura rien à montrer"))
        if not self.papier:
            p.append(("avert", "sans papier : le sujet imprimé n'aura que des lignes à remplir"))
        return p


class Groupe(Question):
    type = "groupe"

    def __init__(self, id, enonce, sous_questions, **commun):
        if "points" in commun:
            raise TypeError("un groupe n'a pas de points propres, c'est la somme des sous-questions")
        super().__init__(id, enonce, **commun)
        self.sous_questions = sous_questions
        for lettre, sq in zip("abcdefghijklmnopqrstuvwxyz", sous_questions):
            sq.reperer(f"{lettre}.")
        self._construire()

    def feuilles(self):
        return self.sous_questions

    def total(self):
        return sum(sq.total() for sq in self.sous_questions)

    def montrer_correction(self, couleur=""):
        for sq in self.sous_questions:
            sq.montrer_correction(couleur)

    def presenter_corrige(self):
        for sq in self.sous_questions:
            sq.presenter_corrige()

    def problemes(self):
        p = super().problemes()
        if len(self.sous_questions) < 2:
            p.append(("erreur", "un groupe a au moins deux sous-questions"))
        rangs = {sq.id: n for n, sq in enumerate(self.sous_questions)}
        for n, sq in enumerate(self.sous_questions):
            if isinstance(sq, Groupe):
                p.append(("erreur", f"{sq.id} : groupe dans un groupe, un seul niveau permis"))
            for r in sq.revele:
                if r == self.id or rangs.get(r, -1) > n:
                    p.append(("erreur", f"{sq.id} : révèle {r}, qui ne la précède pas dans le groupe (ordre fixe)"))
        return p


# --- banque, section, sujet, paquet -----------------------------------------------------------------------------

def revelees(q, groupe_de):
    """Les questions dont ``q`` ou l'une de ses sous-questions révèle la réponse (champ ``revele``), une
    sous-question citée étant remplacée par son groupe : ``groupe_de`` = {id de sous-question: id du groupe}."""
    return {groupe_de.get(r, r) for sq in [q, *q.sous_questions] for r in sq.revelations()} - {q.id}


def ordonner(resolues, groupe_de, melanger=""):
    """Les (question, …) d'une section, mélangées d'abord si ``melanger`` (le titre du sujet : un ordre propre au sujet,
    le même sur papier et pour chaque élève), puis chacune après celles dont elle révèle la réponse, l'ordre reçu conservé
    pour le reste (une boucle de révélations, refusée par le validateur, garde simplement l'ordre reçu)."""
    restant, ordre = list(resolues), []
    if melanger:
        random.Random(melanger + str(len(restant))).shuffle(restant)
    while restant:
        presentes = {q.id for q, *_ in restant}
        ordre.append(restant.pop(next((i for i, (q, *_) in enumerate(restant) if not revelees(q, groupe_de) & presentes), 0)))
    return ordre


def poser_bases(questions, bases):
    """Chaque question SQL dont la ``base`` est un nom des ``bases`` partagées y trouve son script, comme chaque
    question de code dont un fichier « .db » en nomme une."""
    for q in questions:
        for f in (q, *q.sous_questions):
            if isinstance(f, Code):  # pas ``hasattr`` : sur une question construite plus tard (``modele.differee``), il la bâtirait
                f.bases_connues = bases


def afficher_contextes(questions, contextes, repeter=False):
    """Chaque texte partagé s'ouvre au-dessus de la première question qui le cite — au-dessus de CHACUNE si
    ``repeter`` : une question par écran, c'est la seule façon que la figure de l'exercice reste sous les yeux."""
    vus = {}  # nom -> la question qui l'affiche
    for q in questions:
        for f in q.feuilles():
            f.epingler_possible(q.epinglable or f.epinglable)
        for f in (q, *q.sous_questions):
            f.contextes_connus = {nom: contextes[nom] for nom in f.contextes_cites() if nom in contextes}
            for nom in reversed(f.contextes_cites()):  # insérés au-dessus les uns des autres, donc du dernier au premier
                if repeter or nom not in vus:
                    vus[nom] = f
                    f.afficher_contexte(contextes[nom])
                elif vus[nom] in vus[nom].feuilles():  # le texte d'un groupe reste avec lui : pas une feuille à épingler
                    vus[nom].epingler_possible(True)  # sa figure sert à une question suivante, qui ne la répète pas


class Banque(Objet):
    """Un fichier de banque : questions, textes partagés (``contextes``) et fichiers embarqués (``medias`` : nom -> bytes).
    Affichée, elle montre ses questions corrigées."""

    def __init__(self, matiere, questions, niveau="", theme="", contextes=None, medias=None, bases=None):
        self.matiere, self.niveau, self.theme = matiere, niveau, theme
        self.contextes, self.medias, self.questions = contextes or {}, medias or {}, questions
        self.bases = bases or {}  # nom -> script SQL, écrit une fois pour toutes les questions d'un exercice
        MEDIAS.update(self.medias)
        afficher_contextes(questions, self.contextes)
        poser_bases(questions, self.bases)


def au_choix(parts, k):
    """Les ``parts`` des sections hors bonus — des nombres, ou des tuples comparés par leur somme — réduites aux ``k``
    meilleures (toutes sans ``k``) : « le candidat traite au choix 3 exercices parmi les 5 » (bac 2021-2022, 1.54 des
    widgets de bac). La machine retient les meilleures plutôt que de faire choisir l'élève : il ne perd rien à en
    avoir commencé un quatrième, et le correcteur n'a pas de choix déclaré à vérifier."""
    cle = lambda p: sum(p) if isinstance(p, tuple) else p
    return sorted(parts, key=cle, reverse=True)[:k] if k else list(parts)


class Section(Objet):
    """``questions`` : les questions d'un paquet, ou, dans un sujet, des identifiants (ou une ``Reference`` quand les points
    diffèrent de ceux de la banque) qui n'ont rien à afficher. ``bonus`` : ses points s'ajoutent à la note sans compter
    dans le total (questions pour les plus rapides). ``nouvelle_page`` : sur papier, la section commence sur une
    feuille à elle (page impaire, recto-verso), pour être ramassée à part. ``electronique`` : ``titre`` et ``consignes``
    tels que le .qcm les affiche, quand ils y diffèrent du papier (``Question.electronique``)."""

    def __init__(self, questions, titre="", consignes="", bonus=False, nouvelle_page=False, electronique=None):
        self.titre, self.consignes, self.questions, self.bonus = titre, consignes, questions, bonus
        self.nouvelle_page, self.electronique = nouvelle_page, electronique


class DefinitionSujet(Objet):
    """Un fichier de sujet (évaluation papier, QCM électronique, TP ou projet)."""

    def __init__(self, titre, destination, banques, sections, sous_titre="", theme="", matiere="", classe="", date="",
                 duree_minutes=None, consignes="", fichier="tp.py", melanger_questions=False, affichage="sujet",
                 retour=True, graine=None, seconde_chance=None, correction=True, revision="",
                 entrainement=False, acces_cours=False, sans_execution=False, dossier="", sans_ide=False,
                 surveillance=False, cours=None, cours_pages=None, exercices_au_choix=None,
                 nouvel_essai=False, niveau_conversions=1, numerotation_par_section=False, adresse="vous"):
        self.titre, self.sous_titre, self.theme, self.matiere, self.classe = titre, sous_titre, theme, matiere, classe
        self.date, self.duree_minutes, self.destination, self.consignes = date, duree_minutes, destination, consignes
        # les banques vouvoient (consignes à l'infinitif) ; « tu » tutoie tous les textes du sujet, à l'export, et les messages
        # du programme (``adresse.py``, demande de l'utilisateur, 04/10/2026)
        self.adresse = adresse
        self.fichier, self.melanger_questions, self.affichage, self.retour = fichier, melanger_questions, affichage, retour
        self.graine, self.seconde_chance, self.banques, self.sections = graine, seconde_chance, banques, sections
        self.correction, self.revision = correction, revision
        self.entrainement = entrainement  # ni indice ni seconde chance ne coûtent de points : seuls les délais comptent
        self.niveau_conversions = niveau_conversions  # 1 à 4 : l'aide qu'offrent ses conversions (``Conversion.niveau``)
        self.nouvel_essai = nouvel_essai  # une révision : la copie rendue, l'élève peut repasser l'épreuve, d'autres valeurs tirées
        self.sans_execution = sans_execution  # comme sur papier : pas de console, le code ne tourne qu'à la soumission
        self.acces_cours = acces_cours  # les élèves ont le cours sous la main : l'``aide_cours`` d'une question remplace son ``aide``
        self.dossier = dossier  # où vont ses exports, relatif au dossier du professeur (``sujet.sortie``) ; vide : Exports/
        self.sans_ide = sans_ide  # le .qcm d'un TP « sans IDE » : ses questions prennent ``electronique["sans_ide"]``
        self.surveillance = surveillance  # le lecteur noircit l'écran une minute à chaque sortie de l'épreuve (``Lecteur.sortir``)
        self.cours = cours or []  # les PDF du cours que le lecteur ouvre à côté des questions, relatifs au dossier du professeur (``PROF``)
        # le lecteur n'en montre que les premières pages, celles vues en classe (None : toutes) ; une liste parallèle à
        # ``cours`` donne sa limite à chacun (une fusion de sujets sur des cours différents, ``fusionner_qcm.py``)
        self.cours_pages = cours_pages
        self.exercices_au_choix = exercices_au_choix  # k : seules les k meilleures sections (hors bonus) comptent (``au_choix``)
        self.numerotation_par_section = numerotation_par_section  # les questions repartent de 1 à chaque section (un bac : « question 4 » de l'exercice)

    def problemes(self):
        """[(niveau, message)] : ce que la classe ne peut pas empêcher."""
        regles = [(self.destination in DESTINATIONS, f"destination « {self.destination} » : {', '.join(DESTINATIONS)}"),
                  (bool(self.titre), "titre vide"), (bool(self.banques), "aucune banque"),
                  (type(self.graine) is int, f"graine « {self.graine} » : un entier, propre au sujet (tirages et clé du .qcm)"),
                  (all(s.questions for s in self.sections) and bool(self.sections), "sections : au moins une, chacune avec des questions"),
                  (re.fullmatch(r"[A-Za-z0-9_.-]+\.py", self.fichier) is not None, f"fichier « {self.fichier} » : un nom en .py"),
                  (not self.date or re.fullmatch(r"\d{4}-\d\d-\d\d", self.date) is not None, f"date « {self.date} » : AAAA-MM-JJ"),
                  (self.duree_minutes is None or self.duree_minutes > 0, "duree_minutes : strictement positive"),
                  (self.affichage in ("sujet", "question"), f"affichage « {self.affichage} » : sujet ou question"),
                  (self.adresse in ("vous", "tu"), f"adresse « {self.adresse} » : vous ou tu"),
                  (not self.cours or self.acces_cours, "cours sans acces_cours : le lecteur ne montre le cours qu'avec acces_cours"),
                  (all(c.lower().endswith(".pdf") for c in self.cours), f"cours {self.cours} : des fichiers .pdf"),
                  (self.cours_pages is None or bool(self.cours) and (
                      type(self.cours_pages) is int and self.cours_pages > 0 or type(self.cours_pages) is list
                      and len(self.cours_pages) == len(self.cours) and all(p is None or type(p) is int and p > 0 for p in self.cours_pages)),
                   f"cours_pages « {self.cours_pages} » : un nombre de pages strictement positif, ou un par cours, avec un cours"),
                  (self.exercices_au_choix is None or (type(self.exercices_au_choix) is int
                   and 0 < self.exercices_au_choix < sum(not s.bonus for s in self.sections)),
                   f"exercices_au_choix « {self.exercices_au_choix} » : un entier entre 1 et le nombre de sections hors bonus, exclu")]
        return [("erreur", message) for ok, message in regles if not ok]


# Les modes de soumission que porte un code de classe (``codes.code_classe``, demande de l'utilisateur, 28/09/2026), dans
# l'ordre où le lecteur les essaie : le numéro retourne les 3 bits de tête de la clé (``codes.variantes``). 0 est le code
# d'avant les modes, 4 le code de TP d'avant (bit de tête seul) : les codes déjà donnés s'ouvrent toujours.
SOUMISSIONS = {
    0: "Par question, à tout moment, avec rattrapage",
    4: "Globale dans le dernier quart du temps, avec rattrapage",
    1: "Par question, à tout moment, sans rattrapage",
    5: "Globale dans le dernier quart du temps, sans rattrapage",
    2: "À la fin seulement, sans correction",
    3: "À la fin seulement, correction après l'échéance",
}
RATTRAPAGE = {0, 4}  # une seconde chance à chaque question : celle du sujet, ou à défaut ``MALUS_RATTRAPAGE``
MALUS_RATTRAPAGE = 0.25
GLOBALES = {4, 5}  # « Corriger mes réponses » et « Rendre ma copie » attendent les 3/4 du temps, aucune question seule
FINALES = {2, 3}  # aucune question seule : rien n'est corrigé avant de rendre la copie
SANS_CORRECTION, DIFFEREE = 2, 3  # la correction jamais montrée, ou seulement après l'échéance (ou la fin de la durée)


class Paquet(Objet):
    """Le fichier que reçoit l'élève, chiffré : le sujet tiré pour lui, questions complètes, et — enregistrée à chaque
    réponse dans le même fichier — sa session (``courante``, ``debut``, ``fin``, et l'état de chaque question).

    ``affichage`` : « sujet » (tout sur un écran défilant) ou « question » (une par écran) ; ``retour`` : revenir sur une
    réponse soumise ; ``correction`` : note et correction en fin d'épreuve. Une question qui en révèle une autre n'apparaît
    qu'une fois celle-ci validée (ou figée par le passage à l'écran suivant). ``eleve`` : « Nom Prénom », saisi à l'ouverture.
    ``graine`` : celle du sujet tant que le paquet reste à préparer : un seul fichier pour la classe, ses questions telles
    que la banque les donne (une seule fois) avec les réglages du sujet (``date`` et ``revision`` de l'export,
    ``melanger_questions``, ``seconde_chance``, ``entrainement``, ``acces_cours``, ceux de ``DefinitionSujet``), que
    ``nommer`` applique pour chaque élève ; vide une fois préparé (la copie). C'est aussi, en clair, la sauvegarde d'un
    export PDF, dont ``sujet.lire`` refait la définition du sujet. ``inscrits`` : ``{classe: [[nom, prénom], …]}``, les
    élèves admis à ouvrir le sujet, reconnus à l'accueil par le code de leur classe (``codes``). ``note`` et ``appreciation`` :
    celles que le professeur écrit sur la copie rendue, dans l'entête ; sans ``note``, c'est celle de la machine qui s'affiche.
    Le paquet à préparer garde chaque question telle que le papier la pose, sa version pour l'écran à côté
    (``Question.electronique``, ``Section.electronique``) : un seul fichier sert au PDF qui l'embarque et au lecteur, qui
    prend la version pour l'écran à l'accueil (``nommer``) ; ``sans_ide`` : celle d'un TP « sans IDE »."""

    def __init__(self, titre, destination, sections, sous_titre="", theme="", matiere="", classe="", date="", consignes="",
                 duree_minutes=None, fichier="tp.py", contextes=None, medias=None, affichage="sujet", retour=True,
                 correction=True, courante=0, debut=None, fin=None, eleve="", graine="", sans_execution=False,
                 inscrits=None, revision="", melanger_questions=False, seconde_chance=None, entrainement=False,
                 acces_cours=False, note=None, appreciation="", appreciation_encre=None, empreinte="", heure_locale=False, sans_ide=False,
                 surveillance=False, sorties=None, soumission=None, cours=None, cours_pages=None, dossier="", limite=None, nom="", bases=None,
                 exercices_au_choix=None, cours_masques=None, cours_code=None, nouvel_essai=False, essai=1, origine="",
                 numerotation_par_section=False, adresse="vous"):
        self.titre, self.sous_titre, self.theme, self.matiere, self.classe = titre, sous_titre, theme, matiere, classe
        self.sans_ide, self.surveillance = sans_ide, surveillance
        # ``DefinitionSujet.adresse`` : ses textes sont déjà tutoyés, les messages du programme s'y accordent (``adresse.dire``) ;
        # posée avant que ``nommer`` ne refasse les questions de l'élève, dont les consignes des widgets
        self.adresse = adresse
        adresser(adresse)
        # ``DefinitionSujet.nouvel_essai`` ; le numéro de l'essai de cette copie, et le sujet à préparer qu'elle garde, sérialisé
        # (un texte : ni widget à bâtir à l'ouverture, ni objet partagé), d'où ``nouvel_essai_suivant`` retire le suivant
        self.nouvel_essai, self.essai, self.origine = nouvel_essai, essai, origine
        self.dossier = dossier  # celui du sujet (``DefinitionSujet.dossier``) : ses copies vont à côté (``codes.chemin_copie``)
        # le nom du fichier du sujet, celui de son .qcm : il nomme les copies en ligne. Pas le titre, que deux sujets peuvent
        # partager (le projet Pyxel et ses questions bonus : copies confondues, 01/10/2026) ; vide dans un .qcm d'avant
        self.nom = nom
        # les PDF du cours (``DefinitionSujet.cours``), en onglets à côté des questions : pas dans le fichier, un même cours
        # sert à beaucoup de sujets (demande de l'utilisateur, 29/09/2026). Leurs chemins depuis le dossier du .qcm, le même sur
        # le disque du professeur et dans son Dropbox ; ``lire_cours(chemin)`` en rend les octets (None : introuvable), posé
        # par qui ouvre le paquet (``lecteur.Lecteur``, ``pont_qt``)
        self.cours, self.lire_cours = cours or [], lambda chemin: None
        self.cours_pages = cours_pages  # ``DefinitionSujet.cours_pages`` : au-delà, le lecteur ne montre rien
        # ``Sujet.cours_masques``, chemins depuis le dossier du .qcm ; un .qcm d'avant le 05/10/2026 n'a que des ids, sans zone
        self.cours_masques = {c: z for c, z in (cours_masques or {}).items() if isinstance(z, dict)}
        # ``Sujet.cours_code`` : les zones de code des cours, seules copiables (un sujet Pyxel Studio) ; vide, rien ne se copie
        self.cours_code = cours_code or {}
        # les sorties de l'épreuve (``lecteur.Lecteur.sortir``) : [départ, retour] en time.time(), départ None pour une copie
        # rouverte (page fermée ou rechargée), retour None si l'élève n'est pas revenu avant la fin
        self.sorties = sorties or []
        # l'appréciation écrite à la main (tablette graphique, ``modele.Manuscrit``) : des traits ``[[x, y, pression], …]``
        # en fractions de la hauteur du champ ; quand il y en a, c'est elle qui s'affiche, pas le texte tapé
        self.note, self.appreciation, self.appreciation_encre = note, appreciation, appreciation_encre or []
        # la copie d'un élève : l'empreinte de son code personnel (son contrôle lent, ``codes.inscrire`` : le lecteur web n'accepte plus d'autre
        # copie sous ce nom sans ce code), si l'heure de fin a été jugée sur l'horloge de l'ordinateur, faute de réseau, et
        # l'échéance du code de la première ouverture (en time.time()) : la copie rouverte la garde (l'utilisateur, 30/09/2026)
        self.empreinte, self.heure_locale, self.limite = empreinte, heure_locale, limite
        # le mode de soumission du code qui a ouvert le sujet (``SOUMISSIONS``, ``nommer``), None sans code ; ``retenir`` et
        # ``masquer`` le font respecter, au fil du chronomètre du lecteur
        self.soumission, self.retenue, self.masquee = soumission, False, soumission == DIFFEREE
        self.destination, self.consignes, self.duree_minutes, self.fichier = destination, consignes, duree_minutes, fichier
        self.contextes, self.medias, self.sections, self.date, self.revision = contextes or {}, medias or {}, sections, date, revision
        self.affichage, self.retour, self.correction = affichage, retour, correction
        self.courante, self.debut, self.fin, self.demarre, self.fige = courante, debut, fin, False, False
        self.ici = None  # la question où était l'élève à la dernière seconde : ``ecouler`` voit qu'il la quitte
        self.eleve, self.graine, self.sans_execution, self.inscrits = eleve, graine, sans_execution, inscrits or {}
        self.melanger_questions, self.seconde_chance = melanger_questions, seconde_chance
        self.entrainement, self.acces_cours = entrainement, acces_cours
        self.exercices_au_choix = exercices_au_choix  # ``DefinitionSujet.exercices_au_choix``
        self.total = sum(au_choix([sum(q.total() for q in s.questions) for s in sections if not s.bonus], exercices_au_choix))
        self.bases = bases or {}
        MEDIAS.update(self.medias)
        afficher_contextes(self.questions(), self.contextes, self.affichage == "question")
        poser_bases(self.questions(), self.bases)
        self.numerotation_par_section = numerotation_par_section  # ``DefinitionSujet.numerotation_par_section``
        for groupe in [s.questions for s in sections] if numerotation_par_section else [self.questions()]:
            for n, q in enumerate(groupe, 1):
                q.numeroter(n)
        self.feuilles = [f for q in self.questions() for f in q.feuilles()]
        self.cibles = {f.id: [f] for f in self.feuilles} | {q.id: q.feuilles() for q in self.questions()}
        # Les questions bonus avancent à part : finir les autres remplit la barre d'avancement, pas « presque tout ».
        self.feuilles_bonus = [f for s in sections if s.bonus for q in s.questions for f in q.feuilles()]
        self.pages = self.unites = self.questions()  # un écran par question en mode « question »
        premiere_externe = next((f for f in self.feuilles if f.editeur_externe), None)
        for f in self.feuilles:
            f.classe, f.projet, f.sans_execution = classe, destination == "projet", sans_execution
            f.premiere_externe = premiere_externe  # lue par les seules questions editeur_externe
            for r in [*f.reprend, *f.solutions_citees()]:
                if r in self.cibles:
                    f.reprendre(self.cibles[r][0])
            if f.suite_de in self.cibles:
                f.partir_de(self.cibles[f.suite_de][0])
            if f.selon and f.selon.get("question") in self.cibles:
                f.source = self.cibles[f.selon["question"]][0]
            if f.projet:
                f._montrer_enonce()  # ses actions à cocher et ses codes à copier, que la question seule ignorait
            f.modifiable = retour and not self._fausse(f)
            f.changee.connect(self.rafraichir)
            f.changee.connect(functools.partial(self._suite, f))
            f.mettre_a_jour()
        self._construire()

    def __setstate__(self, etat):
        etat.pop("total", None)  # écrit par les exports d'avant le 26/09/2026 : il se calcule
        super().__setstate__(etat)

    def nommer(self, eleve, soumission=None):
        """Le paquet au nom de l'élève, préparé pour lui si ce n'est pas déjà fait (``graine``) : ``variables`` et mélanges
        tirés (graine du sujet, nom, id de la question), questions et sections dans leur version pour l'écran
        (``Question.version_electronique``), une seule aide (``acces_cours``), la seconde chance du sujet donnée
        à chaque question qui n'a pas la sienne (ajustée au hasard, ``Question.adapter_chance``), aucun malus pour un
        ``entrainement`` (la même banque sert à l'évaluation), questions mélangées si le sujet le demande et chacune après
        celles dont elle révèle la réponse. Tout est déterministe : le même élève retrouve le même sujet. Une copie, déjà
        préparée, est rendue telle quelle, sous SON nom : ``eleve`` ne la renomme pas (une copie passée à un camarade reste
        celle de son auteur, et l'élève n'a pas à retaper le sien, l'utilisateur, 30/09/2026).
        ``soumission``, le mode du code (``SOUMISSIONS``), est écrit dans la copie : avec rattrapage, la seconde chance du
        sujet ou à défaut une de ``MALUS_RATTRAPAGE`` ; sans, aucune ; ``SANS_CORRECTION`` retire la correction."""
        if not self.graine:
            self.eleve = self.eleve or eleve
            return self
        rattrapage = soumission is None or soumission in RATTRAPAGE
        chance = self.seconde_chance or (soumission is not None and SecondeChance(MALUS_RATTRAPAGE))
        correction = self.correction and soumission != SANS_CORRECTION
        essai = f"|essai {self.essai}" if self.essai > 1 else ""  # un nouvel essai : d'autres valeurs, un autre ordre
        graine = f"{self.graine}|{normaliser(eleve)}{essai}"
        groupe_de = {sq.id: q.id for q in self.questions() for sq in q.sous_questions}
        sections = []
        for s in self.sections:
            questions = [q.instancier(f"{graine}|{q.id}") for q in (q.version_electronique(self.sans_ide) for q in s.questions) if q]
            for f in (f for q in questions for f in q.feuilles()):
                f.garder_une_aide(self.acces_cours)
                f.seconde_chance = (f.seconde_chance or f.adapter_chance(chance)) if correction and rattrapage else SecondeChance(actif=False)
                if self.entrainement:
                    f.seconde_chance = f.seconde_chance and SecondeChance(0, f.seconde_chance.actif)
                    for i in f.indices:
                        i.malus = 0
            ordre = ordonner([(q,) for q in questions], groupe_de, self.melanger_questions and self.titre + essai)
            textes = {"titre": s.titre, "consignes": s.consignes} | (s.electronique or {})
            sections.append(copier(s, sauf=("questions", "electronique"), imposes={"questions": [q for q, in ordre], **textes}))
        origine = serializejson.dumps(self) if self.nouvel_essai else ""
        return copier(self, sauf=("sections", "origine"), imposes={"sections": sections, "graine": "", "eleve": eleve, "origine": origine,
                                                                    "correction": correction, "soumission": soumission})

    def nouvel_essai_suivant(self):
        """La copie de l'essai suivant (``nouvel_essai``, demande de l'utilisateur, 03/10/2026) : le sujet gardé (``origine``)
        préparé de nouveau au nom de l'élève, d'autres valeurs tirées (le numéro de l'essai entre dans la graine), avec ce que
        le code avait mis dans la première copie (``lecteur.Accueil.nommer``)."""
        with en_donnees():
            sujet = serializejson.loads(self.origine, authorized_classes=list(serializejson.constructors))
            sujet.essai = self.essai + 1
            copie = sujet.nommer(self.eleve, self.soumission)
        for champ in ("empreinte", "limite", "surveillance", "duree_minutes"):
            setattr(copie, champ, getattr(self, champ))
        return copie

    def entete(self):
        """Le texte de l'entête : titre en capitales, sous-titre. Les consignes n'y sont pas : elles ouvrent le sujet, qui
        défile, pour que l'entête ne garde pas leur hauteur une fois l'épreuve commencée."""
        return "\n\n".join(filter(None, [f"# {en_capitales(self.titre).replace(chr(10), '<br>')}", self.sous_titre and f"## {self.sous_titre}"]))

    def _construire(self):
        if self.fin is not None:
            self._montrer_fin()
        else:
            # copie rouverte : chaque question soumise montre ce que sa soumission montrait (l'utilisateur, 05/10/2026 :
            # « la correction devrait réapparaître à la réouverture »)
            for f in self.feuilles:
                self._montrer_issue(f)
            self.rafraichir()

    # -- crochets de l'affichage

    def _afficher_page(self, n):
        """Mode « question » : l'écran ``n``."""

    def _defiler(self, n, recadrer=False):
        """Mode « sujet » : fait défiler la vue jusqu'à la question ``n``. ``recadrer`` : seulement si une autre question
        est visible au-dessus d'elle ; jamais vers le haut, ce qui cacherait la correction au bas d'une longue question."""

    def _rafraichir_vue(self):
        """Barres d'avancement et boutons de navigation."""

    def _confirmer(self):
        """« Soumettre toutes les questions » : l'élève confirme."""
        return True

    def questions(self):
        return [q for s in self.sections for q in s.questions]

    def _page(self):
        return [self.pages[self.courante]] if self.affichage == "question" else self.questions()

    def demarrer(self):
        """L'élève commence : les questions visibles deviennent modifiables."""
        self.demarre = True
        self.debut = self.debut or horloge.secondes()  # l'heure en ligne : début et fin sont des dates de la copie, pas des durées
        self.rafraichir()

    def aller(self, n):
        """Écran ``n`` (mode « question ») : ce que ses questions révèlent est d'abord figé."""
        if not 0 <= n < len(self.pages) or (n < self.courante and not self.retour):
            return
        self.courante = n
        self._afficher_page(n)
        self.fige = True
        for f in (f for q in self._page() for f in q.feuilles()):
            for r in f.revelations() + self.pages[n].revelations():
                for cible in self.cibles.get(r, []):
                    cible.geler()
        self.fige = False
        self.rafraichir()

    def _suite(self, feuille):
        """Après un changement de ``feuille``. Mode « sujet » : soumise, la vue se cale sur la question elle-même,
        pour qu'on relise l'énoncé et la correction (demande de l'utilisateur, 26/09/2026), puis l'élève avance par « Non
        traitée ». Mode « question » : une fois toutes les questions de l'écran closes, on passe au suivant, sauf avec
        ``correction`` (« Suivant »). Une confirmation ou une correction reste affichée sur chaque question soumise
        (demande de l'utilisateur, 26/09/2026 : plus seulement sur la dernière).
        ``geler`` émet aussi ``changee`` : ce qu'il fige (révélation, fin) n'enchaîne pas."""
        if self.fin is not None or self.fige:
            return
        self._montrer_issue(feuille)
        if self.affichage == "sujet":
            if feuille.fermee:
                self.courante = next(n for n, q in enumerate(self.unites) if feuille in q.feuilles())
                self._defiler(self.courante, recadrer=True)
                self.rafraichir()
        elif not self.correction and all(f.fermee for f in self.pages[self.courante].feuilles()):
            self.aller(self.courante + 1)

    def _montrer_issue(self, feuille):
        """Sous une question close d'un sujet à ``correction`` : la correction si elle est fausse (plus de retour possible),
        la confirmation si elle est juste. Rien en données (``_fausse``) ni sans ``correction`` : un sujet sommatif garde
        « Réponse enregistrée. »."""
        if DONNEES or not (self.correction and feuille.fermee):
            return
        fraction = feuille.corriger(feuille.saisie)[0]
        if fraction == 1:
            feuille.confirmer()
        elif fraction is not None:
            feuille.montrer_correction("#c0392b")
            feuille.modifiable = False  # la correction est vue : plus de retour possible
            feuille.mettre_a_jour()

    def _fausse(self, feuille):
        """Close sur une mauvaise réponse, dont la correction doit s'afficher. Pas en données (``en_donnees``) : l'écran
        rebâti (``ecran``) le recalcule, et la correction d'un code y lancerait un sous-processus, dans le navigateur un
        Web Worker attendu hors d'un slot Qt, qui plante le WASM sans trace Python (copie rouverte, 03/10/2026)."""
        return not DONNEES and self.correction and feuille.fermee and feuille.corriger(feuille.saisie)[0] not in (1, None)

    def _libre(self, unite):
        """Où mènent ◀ ▶ (l'utilisateur, 03/10/2026) : pendant l'épreuve, une question (ou un écran) dont une feuille
        visible n'est ni traitée ni soumise, ou attend sa seconde chance ; la copie rendue et corrigée, une question qui
        n'a pas tous ses points."""
        feuilles = [f for f in unite.feuilles() if not f.cachee]
        if self.fin is not None:
            return self.corrigee() and any(f.obtenu is not None and f.obtenu < f.points for f in feuilles)
        return any(not f.fermee and (f.seconde or not f.repondue) for f in feuilles)

    def _voisine(self, sens):
        """Rang de la prochaine (``sens`` = 1) ou de la précédente (-1) question à reprendre (``_libre``), ou ``None``."""
        fin = len(self.unites) if sens > 0 else -1
        return next((n for n in range(self.courante + sens, fin, sens) if self._libre(self.unites[n])), None)

    def sauter(self, sens):
        """Va à la question voisine à reprendre (``_libre``) : à son écran, ou en la faisant défiler dans la vue."""
        n = self._voisine(sens)
        if n is None:
            return
        if self.affichage == "question":
            self.aller(n)
        else:
            self.courante = n
            self._defiler(n)
            self.rafraichir()

    def _devant(self):
        """La question ouverte où est l'élève : ici la première de l'écran ; le widget y ajoute la souris et ce que
        montre la vue."""
        return next((f for q in self._page() for f in q.feuilles() if f.actif and not (f.fermee or f.cachee)), None)

    def ecouler(self):
        """Une seconde de plus, appelée par le chronomètre du lecteur : le délai des indices ne court que sur la question
        où est l'élève (``_devant``), pas sur toutes les questions posées (demande de l'utilisateur, 27/09/2026) ; celle
        qu'il vient de quitter devient « traitée » si sa réponse est entière (``Question.quitter``)."""
        f = self._devant()
        if f is not self.ici:
            if self.ici is not None:
                self.ici.quitter()
            self.ici = f
        if f is not None and f.indice_delai():
            f.presence += 1
            f.mettre_a_jour()

    def retenir(self, oui):
        """Tant que ``oui``, ni « Corriger mes réponses » ni « Rendre ma copie » : la soumission globale attend les 3/4 du
        temps, et l'élève n'a aucune bonne réponse à donner à son voisin d'ici là (demande de l'utilisateur, 28/09/2026 ; le
        chronomètre du lecteur lève la retenue). Une question seule ne se soumet que dans un mode par question."""
        une_a_une = oui or self.soumission in GLOBALES | FINALES
        if oui == self.retenue and all(f.retenue == une_a_une for f in self.feuilles):
            return
        self.retenue = oui
        for f in self.feuilles:
            f.retenue = une_a_une
            f.mettre_a_jour()
        self.rafraichir()

    def masquer(self, oui):
        """Correction différée (``DIFFEREE``) : tant que ``oui``, la copie rendue ne montre ni correction ni note ; le
        chronomètre du lecteur lève le masque à l'échéance, et la fin se remontre avec elles."""
        if oui != self.masquee:
            self.masquee = oui
            if self.fin is not None:
                self._montrer_fin()

    def corrigee(self):
        """La correction et la note se montrent : le sujet le prévoit, et une correction différée a passé l'échéance."""
        return self.correction and not self.masquee

    def masques_cours(self) -> list[list[list[float]]]:
        """Pour chaque PDF du cours, dans l'ordre de ``cours``, les zones (``zone_cours``) à montrer en pavés : celles des
        questions de ``cours_masques`` encore ouvertes, l'épreuve en cours (l'utilisateur, 03/10/2026 : « cachée tant qu'on
        n'a pas soumis la question définitivement, au bout des essais s'il y en a plusieurs ») ; comme ``revele``, à la
        fermeture. Le lecteur pixelise à l'affichage, le PDF reste entier (l'utilisateur, 05/10/2026 : « rester avec un seul
        pdf ») : un affichage, pas une protection."""
        if self.fin is not None:
            return [[] for _ in self.cours]
        return [[zone for i, zone in self.cours_masques.get(c, {}).items() if not all(f.fermee for f in self.cibles.get(i, ()))]
                for c in self.cours]

    def rafraichir(self):
        """Ce qui est visible (rien avant ce qu'il révèle, dans un groupe rien avant la précédente en mode « question »),
        ce qui commence à courir (délai des indices), et où en est l'avancement. Rien pendant ``fige`` : chaque feuille
        que le gel change émet ``changee`` (terminer en gelait 218 : 218 parcours), on rafraîchit une fois au dégel."""
        if self.fige:
            return
        page = {x for p in self._page() for x in p.feuilles()} if self.demarre else ()
        for q in self.questions():
            for f in (q, *q.sous_questions):
                cachee = any(not all(c.fermee for c in self.cibles.get(r, [])) for r in f.revelations()) and self.fin is None
                if self.affichage == "question" and f in q.sous_questions and self.fin is None:
                    avant = q.sous_questions[:q.sous_questions.index(f)]
                    cachee = cachee or not all(a.fermee for a in avant)
                f.montrer(not cachee)
                if not cachee and f in page:
                    f.demarrer()
        self._rafraichir_vue()

    def resultat(self):
        """(points gagnés, points corrigés par la machine, points laissés au professeur) : sur ``total``."""
        def part(s):
            feuilles = [f for q in s.questions for f in q.feuilles()]
            return (sum((f.obtenu or 0) + (f.justification_obtenue or 0) for f in feuilles),
                    sum((f.points if f.obtenu is None else 0)
                        + (f.justification.points if f.justification and f.justification_obtenue is None else 0)
                        for f in feuilles if f.fermee))
        parts = au_choix([part(s) for s in self.sections if not s.bonus], self.exercices_au_choix)
        parts += [part(s) for s in self.sections if s.bonus]
        obtenus, attente = sum(o for o, _ in parts), sum(a for _, a in parts)
        return obtenus, self.total - attente, attente

    def bonus(self):
        """(points gagnés, points possibles) des sections ``bonus`` : ``resultat`` les compte dans les points gagnés."""
        return (sum((f.obtenu or 0) + (f.justification_obtenue or 0) for f in self.feuilles_bonus),
                sum(f.total() for f in self.feuilles_bonus))

    def statistiques(self):
        """Le bilan de la copie, axe par axe (``AXES``) : [(axe, [(libellé, points gagnés, points notés), …]), …], sur les
        seules questions déjà notées, bonus compris (elles disent aussi ce que l'élève sait faire). Une sous-question sans
        champ pédagogique prend ceux de son groupe. Les niveaux de Bloom dans l'ordre de la taxonomie, le reste du plus
        réussi au moins réussi ; un axe que le sujet ne renseigne pas est absent."""
        cumuls = {axe: {} for axe, _ in AXES}
        for q in self.questions():
            for f in q.feuilles():
                if f.obtenu is None:
                    continue
                for axe, relever in AXES:
                    for cle, poids in (relever(f) or relever(q)).items():
                        gagne, note = cumuls[axe].get(cle, (0, 0))
                        cumuls[axe][cle] = gagne + poids * f.obtenu, note + poids * f.points
        bilan = []
        for axe, _ in AXES:
            lignes = [(cle, g, n) for cle, (g, n) in cumuls[axe].items() if n]
            if axe == "Niveaux de Bloom":
                lignes = [(cle[1], g, n) for cle, g, n in sorted(lignes)]
            else:
                lignes.sort(key=lambda ligne: (-ligne[1] / ligne[2], ligne[0]))
            if lignes:
                bilan.append((axe, lignes))
        return bilan

    def rejouable(self):
        """Une seconde chance existe quelque part dans ce sujet : soumettre sans terminer a alors un sens (l'élève
        peut reprendre une réponse fausse) ; sinon « Corriger mes réponses » ne ferait que « Rendre ma copie » sans
        la note, et le bouton n'est pas montré."""
        return any(f.chance() for f in self.feuilles)

    def soumettre_tout(self, confirmer=True):
        """Le bouton « Corriger mes réponses » : chaque question encore ouverte est soumise comme si l'élève
        l'avait validée lui-même — donc une réponse fausse ouvre sa seconde chance, tant qu'il reste du temps. Seule
        la fin du temps (``terminer``) soumet définitivement. ``fige`` empêche la navigation automatique de s'emballer
        sur les dizaines de ``changee`` émis au passage ; le bouton se rallume s'il reste des secondes chances."""
        if confirmer and not self._confirmer():
            return
        self.fige = True
        for f in self.feuilles:
            if not f.fermee:
                f.demarrer()
                f.soumettre()
        self.fige = False
        self.rafraichir()

    def terminer(self):
        """Fin de l'épreuve : toute question encore ouverte est figée telle quelle, sans seconde chance — le temps
        écoulé ne laisse pas de rattrapage —, puis la note et la correction s'affichent. Le chronomètre appelle ceci."""
        self.fige = True
        if codes := [f for f in self.feuilles if isinstance(f, Code) and not f.fermee]:
            type(codes[0]).corriger_ensemble(codes)  # en parallèle, avant que geler ne les corrige une à une
        for f in self.feuilles:
            f.geler()
        self.fige = False
        self.rafraichir()
        if self.fin is None:  # la date de rendu, dans la copie : une copie de fichiers ne la change pas (l'utilisateur, 30/09/2026)
            self.fin = horloge.secondes()
            self.heure_locale = self.heure_locale or not horloge.en_ligne()
        self._montrer_fin()

    def _montrer_fin(self):
        """L'épreuve finie : tout est figé et visible, avec la correction si ``corrigee``."""
        for f in self.feuilles:
            f.figer()
        for q in self.questions():
            for f in (q, *q.sous_questions):
                f.montrer(True)
        if self.corrigee():
            for q in self.questions():
                q.montrer_correction("#c0392b")
