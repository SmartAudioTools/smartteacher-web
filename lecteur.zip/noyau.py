"""Le noyau du modèle objet de QCM/, sans Qt : les données et la logique des banques, questions, sujets et paquets.

``modele.py`` en dérive ses widgets (``class ChoixUnique(noyau.ChoixUnique, Choix)``) ; le lecteur web l'importe
seul, sous Pyodide. Tout ce qui s'affiche passe par des crochets sans effet ici, que les widgets redéfinissent :
``_dire`` (le retour sous la question), ``_montrer_enonce``, ``_montrer_indice``, ``afficher_contexte``, ``montrer``,
``mettre_a_jour`` ; pour un paquet, ``_afficher_page``, ``_defiler``, ``_rafraichir_vue``,
``_confirmer``, ``_montrer_fin`` et ``_devant``. Ce que les crochets reçoivent est aussi gardé en attributs (``dit``,
``contextes_affiches``, ``cachee``, ``numero``), qu'une interface sans widget lit directement.

La saisie de l'élève est rangée dans ``_valeur`` par ``_lire``/``_ecrire`` ; un widget les redéfinit pour la lire
dans ses champs. Voir la docstring de ``modele.py`` pour le format des fichiers.
"""

import ast
import functools
import html
import inspect
import random
import re
import sys
import time
import traceback
import unicodedata

try:
    import serializejson
except ModuleNotFoundError:
    serializejson = None
    if sys.platform != "emscripten":  # le python3 du système : ni serializejson ni qtpy6 (voir ../CLAUDE.md)
        sys.exit("serializejson introuvable : lancer avec /DATA/Python/SmartPython/CachyOS/versions/SmartPython/bin/python")

ID = re.compile(r"^[a-z0-9_]+(->[a-z0-9_]+)*$")
ACCOLADES = re.compile(r"\{([^{}\n]+)\}")
BAREMES = ("tout_ou_rien", "proportionnel", "penalite", "par_case")
DESTINATIONS = ("papier", "electronique", "tp", "projet")
RANGEMENTS = ("TP", "Révisions", "Mini-Interrogations", "DS", "Projets")  # sous-dossier d'un cours où vont les exports d'un sujet
VERT = "#00b050"  # ce qui est juste : le vert vif des cours (``VERT_REPONSE`` de texte_md ; l'utilisateur, 26/09/2026)
POLICE_MAIN = "Kalam"  # ce que la correction écrit en rouge ou en vert, à la main comme un professeur (27/09/2026)
CLASSES = {}  # nom -> classe, pour un chargeur sans serializejson ; les widgets de modele.py remplacent leur noyau


class Evenement:
    """Les abonnés d'un ``SignalPur`` pour un objet donné, avec l'interface d'un signal Qt."""

    def __init__(self):
        self.abonnes = []

    def connect(self, fonction):
        self.abonnes.append(fonction)

    def emit(self, *args):
        for fonction in list(self.abonnes):
            fonction(*args)


class SignalPur:
    """Un signal Qt sans Qt : ``objet.changee.connect(f)``, ``objet.changee.emit()``."""

    def __set_name__(self, classe, nom):
        self.nom = "_signal_" + nom

    def __get__(self, objet, classe=None):
        if objet is None:
            return self
        if self.nom not in objet.__dict__:
            objet.__dict__[self.nom] = Evenement()
        return objet.__dict__[self.nom]


@functools.cache
def parametres(classe):
    """{nom: défaut} des paramètres d'``__init__`` de la classe et de ses ancêtres (``empty`` : obligatoire)."""
    resultat = {}
    for c in reversed(classe.__mro__):
        if "__init__" in c.__dict__:
            resultat.update({n: p.default for n, p in inspect.signature(c.__init__).parameters.items()
                             if p.kind is p.POSITIONAL_OR_KEYWORD and n != "self"})
    return resultat


def _defaut(valeur, defaut):
    return (valeur == defaut or (defaut is None and not valeur and valeur != 0)
            or (isinstance(defaut, tuple) and valeur == list(defaut)))


class Objet:
    """Base de toutes les classes : sérialisation plate, valeurs par défaut omises, ``__init__`` rappelé au chargement."""

    def __init_subclass__(cls, **kw):
        super().__init_subclass__(**kw)
        CLASSES[cls.__name__] = cls
        if serializejson:
            serializejson.constructors[cls.__name__] = cls

    def _ordre(self, etat):
        return etat

    def __serializejson__(self):
        """Les attributs qui sont des paramètres d'``__init__``, puis les paramètres qui sont des properties (la
        ``saisie`` d'une question, lue dans ses widgets) : ni l'un ni l'autre à sa valeur par défaut."""
        defauts = parametres(type(self))
        etat = {nom: valeur for nom, valeur in vars(self).items() if nom in defauts and not _defaut(valeur, defauts[nom])}
        for nom, defaut in defauts.items():
            if nom not in etat and isinstance(getattr(type(self), nom, None), property):
                valeur = getattr(self, nom)
                if not _defaut(valeur, defaut):
                    etat[nom] = valeur
        return type(self).__name__, None, self._ordre(etat)

    def __getattr__(self, nom):
        """Un objet lu sans aucun champ (tout à sa valeur par défaut) n'a pas reçu d'état : serializejson n'appelle
        alors pas ``__setstate__``. Le premier accès à un attribut l'initialise."""
        if nom.startswith("__") or vars(self) or inspect.Parameter.empty in parametres(type(self)).values():
            raise AttributeError(nom)  # des paramètres obligatoires : ce n'est pas un objet sans champ
        self.__init__()
        return getattr(self, nom)

    def __setstate__(self, etat):
        try:
            self.__init__(**etat)
        except TypeError as exc:
            raise TypeError(f"{type(self).__name__} {etat.get('id', etat.get('texte', ''))} : {exc}".replace("  ", " ")) from None


def copier(valeur, remplacer=lambda texte: texte, sauf=(), imposes=None):
    """Copie profonde d'un arbre d'objets, sans jamais partager de sous-objet (serializejson écrirait un ``$ref``) ;
    ``remplacer`` transforme chaque chaîne au passage, les champs nommés dans ``sauf`` ne sont pas copiés et ceux de
    ``imposes`` (pour la racine seulement) remplacent les copies. Un objet est reconstruit par son ``__init__`` (un
    widget ne peut pas l'être autrement) à partir de l'état que serializejson écrirait."""
    if isinstance(valeur, str):
        return remplacer(valeur)
    if isinstance(valeur, list):
        return [copier(v, remplacer, sauf) for v in valeur]
    if isinstance(valeur, dict):
        return {k: copier(v, remplacer, sauf) for k, v in valeur.items()}
    if isinstance(valeur, Objet):
        etat = {k: copier(v, remplacer, sauf) for k, v in valeur.__serializejson__()[2].items() if k not in sauf}
        return type(valeur)(**{**etat, **(imposes or {})})
    return valeur


LOGO = "logo du thème"  # le visuel du thème dans les médias ; sans extension, hors de portée des médias d'une banque
MEDIAS = {}  # nom -> octets : alimenté par Banque et Paquet (leurs questions sont construites avant eux)


def normaliser(valeur):
    """Casse, accents et espaces multiples ignorés."""
    texte = unicodedata.normalize("NFD", str(valeur).strip().lower())
    return " ".join("".join(c for c in texte if not unicodedata.combining(c)).split())


def nombre(valeur):
    try:
        return float(str(valeur).strip().replace(",", "."))
    except ValueError:
        return None


def indice_de(erreurs, saisie):
    """L'indice de l'erreur reconnue à l'exact dans ``saisie``, à défaut celui de « toute autre erreur »."""
    for e in erreurs:
        if e.reponse is not None and normaliser(e.reponse) == normaliser(saisie):
            return e.indice
    return next((e.indice for e in erreurs if e.reponse is None and not e.description), None)


def points_txt(p):
    return f"{p:g} point" + ("s" if p >= 2 else "")


def en_capitales(titre):
    """Le titre d'un sujet tel qu'il s'affiche en tête : en capitales, sauf les lignes qu'un retour à la ligne place
    avant la dernière, gardées telles qu'écrites (« Mini évaluation : » / « LES RÉSEAUX SOCIAUX » : demande de
    l'utilisateur, 25/09/2026)."""
    *avant, sujet = titre.split("\n")
    return "\n".join([*avant, sujet.upper()])


def melange(elements, graine):
    """Un ordre tiré d'une graine fixe (deux exports se ressemblent), jamais l'ordre d'origine."""
    elements, tires = list(elements), list(elements)
    alea = random.Random(graine)
    while len(elements) > 1 and tires == elements:
        alea.shuffle(tires)
    return tires


# --- sous-objets d'une question -------------------------------------------------------------------------------

class Proposition(Objet):
    def __init__(self, texte, correcte=False, feedback=""):
        self.texte, self.correcte, self.feedback = texte, correcte, feedback


class Test(Objet):
    """Un test de code : ``appel`` est une expression, ``attendu`` le repr() de sa valeur. En SQL, ``appel`` est une
    requête de CONTRÔLE jouée après celle de l'élève, vide pour juger le résultat de la sienne."""

    def __init__(self, appel, attendu, message=""):
        self.appel, self.attendu, self.message = appel, attendu, message


class Rectangle(Objet):
    """Zone rectangulaire d'une image, en pixels."""

    def __init__(self, x, y, largeur, hauteur):
        self.x, self.y, self.largeur, self.hauteur = x, y, largeur, hauteur

    def decrire(self):
        return f"rectangle {self.x}, {self.y}, {self.largeur}, {self.hauteur}"

    def contient(self, x, y):
        return self.x <= x <= self.x + self.largeur and self.y <= y <= self.y + self.hauteur

    def centre(self):
        return [self.x + self.largeur // 2, self.y + self.hauteur // 2]


class Cercle(Objet):
    def __init__(self, x, y, rayon):
        self.x, self.y, self.rayon = x, y, rayon

    def decrire(self):
        return f"cercle {self.x}, {self.y}, {self.rayon}"

    def contient(self, x, y):
        return (x - self.x) ** 2 + (y - self.y) ** 2 <= self.rayon ** 2

    def centre(self):
        return [self.x, self.y]


class Paire(Objet):
    def __init__(self, gauche, droite):
        self.gauche, self.droite = gauche, droite


class Element(Objet):
    """Un élément à classer, avec la catégorie où il va."""

    def __init__(self, texte, categorie):
        self.texte, self.categorie = texte, categorie


class Erreur(Objet):
    """Une erreur attendue et son indice : ``reponse`` reconnue à l'exact, ``description`` rapprochée par un LLM ;
    ni l'une ni l'autre : « toute autre erreur »."""

    def __init__(self, indice, reponse=None, description=""):
        self.indice, self.reponse, self.description = indice, reponse, description


class Indice(Objet):
    def __init__(self, texte, delai=0, malus=0):
        self.texte, self.delai, self.malus = texte, delai, malus


class Justification(Objet):
    def __init__(self, points, consigne="Justifiez votre réponse."):
        self.points, self.consigne = points, consigne


class SecondeChance(Objet):
    """Un second essai après une erreur, avec l'indice lié à l'erreur, moyennant ``malus`` (fraction des points)."""

    def __init__(self, malus=0, actif=True):
        self.malus, self.actif = malus, actif


class Trou(Objet):
    """Un trou de texte : ``reponses`` absent = correction manuelle ; ``choix`` présent = liste déroulante."""

    def __init__(self, reponses=None, choix=None, erreurs=None):
        self.reponses, self.choix, self.erreurs = reponses, choix, erreurs or []


class Sommet(Objet):
    """Un sommet d'une question ``dessin``, nommé et placé (en pixels) par le professeur ; l'élève n'y touche pas.
    ``marque`` : ``"initial"`` ou ``"final"``, les deux états particuliers d'un automate."""

    def __init__(self, nom, x, y, marque=""):
        self.nom, self.x, self.y, self.marque = nom, x, y, marque


class Arete(Objet):
    """Une arête attendue : « g »/« d » pour un arbre binaire, une lettre pour un automate, un poids pour un graphe
    pondéré, rien pour un graphe nu."""

    def __init__(self, source, cible, etiquette=""):
        self.source, self.cible, self.etiquette = source, cible, etiquette


class Reference(Objet):
    """Une question d'une section de sujet dont les points remplacent ceux de la banque (sinon : simple chaîne)."""

    def __init__(self, id, points):
        self.id, self.points = id, points


# --- questions ------------------------------------------------------------------------------------------------

DUREE_PAR_DIFFICULTE = {None: 45, 1: 45, 2: 90, 3: 150}  # secondes, faute de ``duree`` mesurée ; calées pour que les
# sujets déjà donnés tiennent dans leur durée (SNT réseaux sociaux : 10 questions, 10 min), à remplacer par les mesures


class Question(Objet):
    """Les champs communs à tous les types ; ``type`` (attribut de classe) est le nom historique du type.

    Chaque type définit ``juste`` (la saisie juste), ``corriger`` (``(fraction des points ou None, indice)``) et
    ``_attendu`` (la correction en Markdown) ; son widget, dans modele.py, ``_corps`` et ``_lire``/``_ecrire``.
    Les champs de session — ``saisie``, ``justifie``, ``ouverte`` (début), ``presence`` (secondes passées dessus, qui font courir le délai des indices), ``debloques``
    (indices découverts), ``aidee`` (aide affichée), ``reformulee`` (énoncé reformulé affiché), ``seconde`` (seconde chance accordée), ``fermee`` (validée, ``obtenu`` = points gagnés, ``None`` si
    elle attend le professeur), ``cochees`` (dans un projet, les actions de l'énoncé cochées, par rang) — sont
    enregistrés avec la question. ``graine`` est posée par ``instancier``."""

    type = ""
    sous_questions = ()  # ne change que pour un Groupe
    classe = ""  # posée par le paquet qui contient la question : elle fixe ce que le programme de l'élève peut employer
    autorises = None  # liste blanche propre à la question, qui remplace celle de la classe (champ de ``Code``)
    projet = False  # posée par le paquet : dans un projet, les actions de l'énoncé se cochent et ses blocs de code se copient
    changee = SignalPur()  # la question a changé d'état (soumise, validée, figée) : à enregistrer
    dit = ("", "")  # le dernier retour affiché sous la question : (Markdown, couleur)
    numero = None
    cachee = False  # masquée par le paquet (``revele``, sous-questions l'une après l'autre)
    retenue = False  # posée par le paquet (``Paquet.retenir``) : un TP, pas de soumission avant les 3/4 du temps

    def __init__(self, id, enonce, points=1, difficulte=None, tags=None, programme="", fiche="", competences_livret=None,
                 capacites_programme=None, pensee_informatique=None, verbe_action="", contexte="", explication="",
                 explication_fausse="", enonce_simplifie="", aide="", aide_cours="", necessite_ordinateur=False, couleur_obligatoire=False, copiable=False, duree=None, usage="", electronique=None, revele=None, indices=None, variables=None, justification=None,
                 seconde_chance=None, graine=None, saisie=None, justifie="", ouverte=None, presence=0, debloques=0, seconde=False,
                 fermee=False, obtenu=None, repondue=False, reformulee=False, aidee=False, cochees=None, horodatage=None):
        self.id, self.enonce, self.points, self.difficulte = id, enonce, points, difficulte
        self.tags, self.programme, self.fiche = tags or [], programme, fiche
        self.competences_livret, self.capacites_programme = competences_livret or {}, capacites_programme or []
        self.pensee_informatique, self.verbe_action = pensee_informatique or [], verbe_action
        self.contexte, self.explication, self.necessite_ordinateur = contexte, explication, necessite_ordinateur
        self.explication_fausse, self.copiable, self.couleur_obligatoire = explication_fausse, copiable, couleur_obligatoire
        self.duree = duree  # secondes pour y répondre, estimées ; absente : ``DUREE_PAR_DIFFICULTE``
        self.usage = usage  # "formatif", "sommatif", ou "" : les deux
        self.electronique = electronique  # ce que le .qcm en change : voir ``version_electronique``
        self.revele, self.indices, self.variables = revele or [], indices or [], variables or {}
        self.justification, self.seconde_chance, self.graine = justification, seconde_chance, graine
        self.ouverte, self.presence, self.debloques, self.seconde, self.fermee, self.obtenu = ouverte, presence, debloques, seconde, fermee, obtenu
        self.repondue, self.enonce_simplifie, self.reformulee = repondue, enonce_simplifie, reformulee
        self.aide, self.aide_cours, self.aidee, self.cochees = aide, aide_cours, aidee, cochees or []  # aide_cours : la variante quand le cours est sous la main, retenue par un sujet ``acces_cours``
        self._depart, self._justifie_depart = saisie, justifie
        self.actif, self.modifiable = False, True
        self.contextes_affiches = []
        self.horodatage = horodatage or []  # instants (time.time()) où l'élève a validé ou soumis : de quoi mesurer ``duree``

    def version_electronique(self, sans_ide=False):
        """La question telle que la pose le .qcm, quand elle diffère du papier (un TP où l'élève travaille dans son
        éditeur devient une question ``code`` dans l'éditeur du lecteur) : ``electronique`` vaut ``False`` (question
        absente du .qcm) ou un dict de champs qui remplacent les siens, ``classe`` (« Code », « ReponseOuverte »…)
        changeant le type ; les champs non remplacés sont repris quand la classe les connaît. Un TP qui a deux .qcm,
        « avec IDE » et « sans IDE », range dans ce dict une clé ``sans_ide`` : la variante (dict, ``False`` ou ``None``)
        du second, tout entier dans le lecteur, que prend un sujet à ``sans_ide``."""
        variante = self.electronique
        if sans_ide and isinstance(variante, dict) and "sans_ide" in variante:
            variante = variante["sans_ide"]
        if variante is None:
            return self
        if variante is False:
            return None
        variante = {k: v for k, v in variante.items() if k != "sans_ide"}
        classe = CLASSES[variante.pop("classe", type(self).__name__)]
        champs = parametres(classe)
        etat = {k: v for k, v in self.__serializejson__()[2].items() if k in champs and k != "electronique"}
        return classe(**copier({**etat, **variante}))

    def duree_estimee(self):
        """Secondes pour y répondre : ``duree`` si elle est posée, sinon la somme des sous-questions d'un groupe, sinon
        le forfait de sa difficulté."""
        if self.duree is None and self.sous_questions:
            return sum(sq.duree_estimee() for sq in self.sous_questions)
        return self.duree or DUREE_PAR_DIFFICULTE[self.difficulte]

    # -- affichage (crochets : les widgets de modele.py les redéfinissent)

    def reperer(self, marque):
        """Le repère de la sous-question (« a. ») en tête de son énoncé, sur la MÊME ligne : seul sur sa ligne,
        il s'éloigne de la consigne qu'il numérote. N'écrit pas dans ``enonce``, qui est la donnée enregistrée."""
        self.marque = marque
        self._montrer_enonce()

    marque = ""

    def _montrer_enonce(self):
        """L'énoncé, ou sa reformulation quand l'élève l'a demandée, derrière le repère de sous-question."""

    def reformuler(self):
        """Bascule entre l'énoncé et sa reformulation ; ``reformulee`` est enregistré avec la copie. Offert à toute la
        classe, sans malus : une aide à la lecture, qui ne change pas ce qui est évalué."""
        self.reformulee = not self.reformulee
        self._montrer_enonce()
        self.changee.emit()

    def numeroter(self, numero=None):
        """« Question n°x » au-dessus de l'énoncé."""
        self.numero = numero

    def _construire(self):
        """À la fin du ``__init__`` de chaque type, ses champs posés : la saisie et l'état de session relus."""
        self._valeur = None
        if self.sous_questions:
            return
        if self._depart is not None:
            self._ecrire(self._depart)
        self.justifie = self._justifie_depart
        if self.aidee:
            self._montrer_indice("**Aide** : " + self.aide)
        for i in self.indices[:self.debloques]:
            self._montrer_indice("**Indice** : " + i.texte)
        if self.fermee:
            self._dire("Réponse enregistrée.")
        elif self.seconde:
            self._dire("Seconde chance : " + (self.corriger(self.saisie)[1] or ""))
        self.mettre_a_jour()

    def afficher_contexte(self, markdown):
        """Sous « Question n°x », jamais au-dessus : hors du bloc numéroté, un texte partagé se lit comme la fin de
        la question PRÉCÉDENTE (QCM Algorithmique, questions 99, 126 et 132)."""
        self.contextes_affiches.insert(0, markdown)

    def contextes_cites(self):
        """Les textes partagés que la question ouvre, dans l'ordre de lecture : ``contexte`` est un nom, ou
        plusieurs quand la question ajoute son introduction propre à une figure déjà citée par ses voisines."""
        if not self.contexte:
            return []
        return [self.contexte] if isinstance(self.contexte, str) else list(self.contexte)

    sans_execution = False  # posé par le paquet : voir DefinitionSujet

    _trou_corrige = None  # pour un texte à trous : comment écrire un trou dans la correction

    def _dire(self, markdown, couleur=""):
        self.dit = (markdown, couleur)

    def _montrer_indice(self, markdown, tete=False):
        """Une aide (``tete`` : en premier) ou un indice découvert, sous la question."""

    def mettre_a_jour(self):
        """Ce qui est actif, visible et écrit sur les boutons, selon l'état de la question."""

    def montrer(self, visible):
        self.cachee = not visible

    def feuilles(self):
        """Les questions à noter : elle-même, ou les sous-questions d'un groupe."""
        return [self]

    def total(self):
        """Justification comprise : elle est notée en plus de la réponse, et à la main."""
        return self.points + (self.justification.points if self.justification else 0)

    # -- la saisie de l'élève

    @property
    def saisie(self):
        return None if self.sous_questions else self._lire()

    @saisie.setter
    def saisie(self, valeur):
        if not self.sous_questions:
            self._ecrire(valeur)

    def _lire(self):
        return self._valeur

    def _ecrire(self, valeur):
        self._valeur = valeur

    @property
    def justifie(self):
        return self._justifie if self.justification else ""

    @justifie.setter
    def justifie(self, texte):
        self._justifie = texte

    def chance(self):
        return self.seconde_chance if self.seconde_chance and self.seconde_chance.actif else None

    devinable = False  # la réponse se choisit parmi des options données : le hasard y rapporte
    MALUS_DEVINABLE = 0.5

    def reponse_forcee(self):
        """Après une erreur, il ne reste qu'une réponse possible : une seconde chance la donnerait."""
        return False

    def adapter_chance(self, chance):
        """La seconde chance du SUJET, ajustée au hasard : aucune là où elle donnerait la réponse (Vrai/Faux), au
        moins −50 % là où l'on choisit parmi des options (à −25 %, répondre au hasard y devient rentable), telle quelle là
        où la réponse se saisit. Une ``seconde_chance`` écrite sur la question elle-même n'y passe pas."""
        if not chance or not chance.actif or not self.devinable:
            return chance
        return SecondeChance(actif=False) if self.reponse_forcee() else SecondeChance(max(chance.malus, self.MALUS_DEVINABLE))

    def garder_une_aide(self, acces_cours):
        """Le sujet dit si les élèves ont le cours : une seule aide reste, l'``aide_cours`` s'ils l'ont (à défaut l'aide)."""
        self.aide, self.aide_cours = (self.aide_cours or self.aide) if acces_cours else self.aide, ""

    def indice_delai(self):
        """Secondes avant le prochain indice (0 : déblocable), ou ``None`` s'il n'y en a plus."""
        if self.debloques >= len(self.indices):
            return None
        return max(0, self.indices[self.debloques].delai - self.presence) \
            if self.indices[self.debloques].delai else 0

    def demarrer(self):
        """La question est posée : ses champs deviennent modifiables."""
        if self.sous_questions or self.actif:
            return
        self.actif = True
        if self.ouverte is None:
            self.ouverte = time.time()
        self.mettre_a_jour()

    def figer(self):
        """Plus aucune modification, sans changer l'état de la question."""
        for f in self.feuilles():
            f.actif = False
            f.mettre_a_jour()

    def aider(self):
        """L'aide, gratuite et offerte à tous : une piste pour démarrer (méthode, rappel de cours), jamais la réponse ;
        ``aidee`` est enregistré avec la copie."""
        if self.aide and not self.aidee:
            self.aidee = True
            self._montrer_indice("**Aide** : " + self.aide, tete=True)
            self.mettre_a_jour()
            self.changee.emit()

    def debloquer(self):
        if self.indice_delai() == 0:
            self._montrer_indice("**Indice** : " + self.indices[self.debloques].texte)
            self.debloques += 1
            self.mettre_a_jour()
            self.changee.emit()

    def complete(self):
        """La réponse est entière : quelque chose de saisi, et aucune case laissée vide dans une liste (classement,
        appariement)."""
        saisie = self.saisie
        return saisie is not None and not (isinstance(saisie, list) and None in saisie)

    def quitter(self):
        """L'élève passe à une autre question : celle-ci devient « traitée » si sa réponse est entière (``complete``),
        sans bouton ni correction ; revenue incomplète, elle ne l'est plus. La navigation « Non traitée » la saute alors
        (demande de l'utilisateur, 28/09/2026 : le bouton « Marquer comme traitée » déduit de l'activité de l'élève)."""
        traitee = self.actif and not self.fermee and self.complete()
        if traitee != self.repondue:
            self.repondue = traitee
            self.horodatage.append(round(time.time(), 1))
            self.mettre_a_jour()
            self.changee.emit()

    def soumettre(self):
        """Corrige la réponse : une seconde chance si elle est fausse et permise, sinon la question est close."""
        if self.fermee or not self.actif or self.retenue:
            return
        fraction, indice = self.corriger(self.saisie)
        self.horodatage.append(round(time.time(), 1))
        chance = self.chance()
        if chance and not self.seconde and fraction is not None and fraction < 1:
            self.seconde = True
            # les points encore à gagner, pas ceux perdus (demande de l'utilisateur, 28/09/2026)
            prix = f", pour {points_txt(round(self.points * max(0, 1 - self.malus()), 2))}" if self.points else ""
            # en rouge comme une correction, la seconde chance en vert (demandes de l'utilisateur, 26/09/2026)
            self._dire(f"**Ce n'est pas la bonne réponse.** {indice or ''}\n\n"
                       f'<span style="color:{VERT}">Vous pouvez réessayer{prix}.</span>', "#c0392b")
        else:
            self._clore(fraction)
            # sans console, l'élève découvre l'erreur de son programme ici : brute tant qu'il peut réessayer, expliquée ensuite
            self._dire("\n\n".join(filter(None, ["Réponse enregistrée.", self.sans_execution and self._diagnostic()])))
        self.mettre_a_jour()
        self.changee.emit()

    def geler(self):
        """Fige la réponse telle qu'elle est, sans seconde chance (la question est révélée, ou l'épreuve finie)."""
        if not self.fermee:
            self._clore(self.corriger(self.saisie)[0])
            self.mettre_a_jour()
            self.changee.emit()

    def malus(self):
        """La fraction des points retirée par les indices débloqués et la seconde chance jouée."""
        return sum(i.malus for i in self.indices[:self.debloques]) + (self.chance().malus if self.seconde and self.chance() else 0)

    def _clore(self, fraction):
        self.obtenu = None if fraction is None else round(self.points * max(0, fraction - self.malus()), 2)
        self.fermee = True

    def rouvrir(self):
        """Revenir sur une réponse validée (``retour``), sauf si la seconde chance a été jouée."""
        if self.fermee and not self.seconde and self.modifiable:
            self.fermee, self.obtenu = False, None
            self._dire("")
            self.mettre_a_jour()
            self.changee.emit()

    # -- la correction

    def juste(self):
        """La saisie juste."""
        raise NotImplementedError

    def corriger(self, saisie):
        """``(fraction des points, indice)`` : fraction ``None`` si la réponse n'est pas corrigeable par la machine."""
        raise NotImplementedError

    def _attendu(self):
        return ""

    def montrer_correction(self, couleur=""):
        """La correction (réponse attendue, remarques, explication) sous la question, de la ``couleur`` donnée ; la saisie de l'élève reste."""
        for f in self.feuilles():
            attendu = f._attendu()
            f._dire("\n\n".join(filter(None, [f._diagnostic(), f"**Correction**\n\n{attendu}" if attendu else "", f.explication,
                                                f.explication_fausse])), couleur)

    def _diagnostic(self):
        """Dans la correction seulement : ce que la saisie a de faux, au-delà de la réponse attendue."""
        return ""

    def confirmer(self):
        """Bonne réponse : une confirmation en vert, avec l'explication s'il y en a une."""
        self._dire("\n\n".join(filter(None, ["**Bonne réponse !**", self.explication])), VERT)

    def presenter_corrige(self):
        """Comme dans une banque : la bonne réponse saisie, la correction dessous, plus rien de modifiable."""
        self.saisie = self.juste()
        self.montrer_correction("#c0392b")
        self.figer()

    # -- fabrication

    def instancier(self, graine, heritees=None, points=None):
        """La question avec ses ``variables`` tirées de la graine, ses ``{expressions}`` remplacées dans tous ses textes
        (sous-questions comprises, qui héritent des variables du groupe), sa ``graine`` propre pour les mélanges et, si
        ``points`` est donné, ces points (un groupe n'en a pas : c'est la somme de ses sous-questions).
        Une accolade dont le contenu n'est pas une expression citant une variable est laissée telle quelle : ``{.rouge}``
        de Pandoc, dictionnaires du code Python."""
        alea = random.Random(graine)
        espace = {"randint": alea.randint, "randrange": alea.randrange, "uniform": alea.uniform, "choice": alea.choice,
                  "sample": alea.sample, "melange": lambda elements: alea.sample(list(elements), len(elements))}
        valeurs = dict(heritees or {})
        for nom, expression in self.variables.items():
            valeurs[nom] = eval(expression, {**espace, **valeurs})
        espace.update(valeurs)

        def remplacer(m):
            try:
                noms = {n.id for n in ast.walk(ast.parse(m.group(1), mode="eval")) if isinstance(n, ast.Name)}
            except SyntaxError:
                return m.group(0)
            return str(eval(m.group(1), espace)) if noms & valeurs.keys() else m.group(0)

        imposes = {"graine": graine}
        if self.sous_questions:
            imposes["sous_questions"] = [sq.instancier(f"{graine}|{sq.id}", valeurs) for sq in self.sous_questions]
        elif points is not None:
            imposes["points"] = points
        return copier(self, lambda texte: ACCOLADES.sub(remplacer, texte), sauf=("sous_questions", "saisie"), imposes=imposes)

    def problemes(self):
        """[(niveau, message)] : ce que la classe ne peut pas empêcher (niveau « erreur » ou « avert »)."""
        p = []
        for sans_ide in (False, True) if self.electronique not in (None, False) else ():
            try:
                variante = self.version_electronique(sans_ide)
            except (KeyError, TypeError) as exc:
                p.append(("erreur", f"electronique : {exc}"))
            else:
                p += [(niveau, "electronique : " + message) for niveau, message in variante.problemes()] if variante else []
        if not ID.match(self.id):
            p.append(("erreur", f"identifiant « {self.id} » : minuscules, chiffres et _, mots séparés par ->"))
        if not self.enonce:
            p.append(("erreur", "énoncé vide"))
        if (self.aide or self.aide_cours) and self.sous_questions:
            p.append(("erreur", "aide : un groupe n'a pas de bouton « Aide », la mettre sur ses sous-questions"))
        if self.aide_cours and not self.aide:
            p.append(("avert", "aide_cours sans aide : un sujet sans acces_cours n'aura pas d'aide du tout"))
        if self.enonce_simplifie and self.enonce_simplifie.split() == self.enonce.split():
            p.append(("avert", "enonce_simplifie : identique à l'énoncé, le bouton « Reformuler » n'y changerait rien"))
        if not self.points > 0:
            p.append(("erreur", "points : strictement positifs"))
        if self.difficulte not in (None, 1, 2, 3):
            p.append(("erreur", "difficulte : 1, 2 ou 3"))
        if self.duree is not None and not self.duree > 0:
            p.append(("erreur", "duree : secondes, strictement positive"))
        if self.id in self.revele:
            p.append(("erreur", "révèle sa propre réponse"))
        if len(set(self.revele)) != len(self.revele):
            p.append(("erreur", "revele : identifiants en double"))
        if any(a.delai > b.delai for a, b in zip(self.indices, self.indices[1:])):
            p.append(("erreur", "indices : les délais doivent aller croissant"))
        if sum(i.malus for i in self.indices) > 1:
            p.append(("erreur", "indices : la somme des malus dépasse 1 (tous les points)"))
        if self.chance() and self.reponse_forcee():
            p.append(("avert", "seconde_chance : après une erreur il ne reste qu'une réponse, le second essai la donne"))
        if len(self.indices) > 1 or any(i.malus != 0.5 or i.delai < 60 for i in self.indices):  # convention, pas une impossibilité
            p.append(("avert", "indices : la convention est un seul indice, à −50 % (malus 0.5) après au moins une minute "
                               "(delai 60) ; ce qui aide sans donner la réponse va dans aide, gratuite"))
        for ou, reponses, erreurs in [("", getattr(self, "reponses", None), getattr(self, "erreurs", []))] + [
                (f"trou {n}, ", trou.reponses, trou.erreurs) for n, trou in getattr(self, "trous", {}).items()]:
            attendues = {str(r).strip().lower() for r in reponses or []}
            for e in erreurs:
                if e.reponse is not None and str(e.reponse).strip().lower() in attendues:
                    p.append(("erreur", f"{ou}erreur « {e.reponse} » qui est une réponse acceptée"))
                if e.reponse is not None and self.type in ("reponse_ouverte", "code"):
                    p.append(("erreur", f"erreur « {e.reponse} » : pas de réponse exacte pour ce type, utiliser description"))
            if sum(e.reponse is None and not e.description for e in erreurs) > 1:
                p.append(("erreur", f"{ou}plusieurs erreurs sans reponse ni description (une seule « toute autre erreur »)"))
        return p

    def _ordre(self, etat):
        communs = parametres(Question)
        tete = {k: etat[k] for k in ("id", "enonce", "enonce_simplifie") if k in etat}  # la reformulation se relit sous l'énoncé
        return {**tete, **{k: v for k, v in etat.items() if k not in communs}, **{k: v for k, v in etat.items() if k in communs and k not in tete}}


class Alternative(Question):
    type = "alternative"

    devinable = True

    def reponse_forcee(self):
        return True

    def __init__(self, id, enonce, reponse, libelles=("Vrai", "Faux"), **commun):
        super().__init__(id, enonce, **commun)
        self.reponse, self.libelles = reponse, list(libelles)
        self._construire()

    def juste(self):
        return self.reponse

    def corriger(self, saisie):
        return (1 if saisie == self.reponse else 0), None

    def _attendu(self):
        return self.libelles[0 if self.reponse else 1]

    def problemes(self):
        return super().problemes() + ([("erreur", "libelles : exactement deux")] if len(self.libelles) != 2 else [])


class Choix(Question):
    """Base de ChoixUnique et ChoixMultiples : ``saisie`` = indices (de ``propositions``, non mélangées) des cases cochées."""

    devinable = True

    def reponse_forcee(self):
        return self.type == "choix_unique" and len(self.propositions) <= 2

    def __init__(self, id, enonce, propositions, melanger=True, **commun):
        super().__init__(id, enonce, **commun)
        self.propositions, self.melanger = propositions, melanger

    def correctes(self):
        return sum(1 for p in self.propositions if p.correcte)

    def _cochees(self):
        return [i for i, b in enumerate(self.boutons) if b.isChecked()]

    def _feedbacks(self, indices):
        return "\n\n".join(self.propositions[i].feedback for i in indices if self.propositions[i].feedback) or None

    def _attendu(self):
        justes = "\n".join(f"- {p.texte}" for p in self.propositions if p.correcte)
        remarques = "\n".join(f"- {p.texte} : {p.feedback}" for p in self.propositions if p.feedback)
        return justes + ("\n\n" + remarques if remarques else "")

    def problemes(self):
        return super().problemes() + ([("erreur", "au moins deux propositions")] if len(self.propositions) < 2 else [])


class ChoixUnique(Choix):
    type = "choix_unique"

    EXCLUSIF = True

    def __init__(self, id, enonce, propositions, melanger=True, **commun):
        super().__init__(id, enonce, propositions, melanger, **commun)
        self._construire()

    def juste(self):
        return next(i for i, p in enumerate(self.propositions) if p.correcte)

    def corriger(self, saisie):
        if saisie is None:
            return 0, None
        return (1 if self.propositions[saisie].correcte else 0), self._feedbacks([saisie])

    def problemes(self):
        return super().problemes() + ([("erreur", f"choix_unique doit avoir exactement 1 proposition correcte, {self.correctes()} trouvée(s)")]
                                      if self.correctes() != 1 else [])


class ChoixMultiples(Choix):
    type = "choix_multiples"

    EXCLUSIF = False

    def __init__(self, id, enonce, propositions, bareme="tout_ou_rien", melanger=True, **commun):
        super().__init__(id, enonce, propositions, melanger, **commun)
        self.bareme = bareme
        self._construire()

    def juste(self):
        return [i for i, p in enumerate(self.propositions) if p.correcte]

    def corriger(self, saisie):
        """tout_ou_rien : toutes les bonnes cases et aucune autre ; proportionnel : la part des propositions bien traitées
        (cochée à juste titre ou laissée à juste titre) ; penalite : une case fausse retire ce que rapporte une juste ;
        par_case : idem, mais une case correcte laissée vide coûte aussi — une copie blanche gagnerait alors les cases
        justement vides, d'où le 0 imposé quand rien n'est coché."""
        coches, bonnes = set(saisie or []), {i for i, p in enumerate(self.propositions) if p.correcte}
        justes, fausses = len(coches & bonnes), coches - bonnes
        if self.bareme == "proportionnel":
            fraction = (len(self.propositions) - len(coches ^ bonnes)) / len(self.propositions)
        elif self.bareme == "penalite":
            fraction = max(0, justes - len(fausses)) / len(bonnes)
        elif self.bareme == "par_case":
            n = len(self.propositions)
            fraction = max(0, n - 2 * len(coches ^ bonnes)) / n if coches else 0
        else:
            fraction = 1 if coches == bonnes else 0
        return fraction, (self._feedbacks(sorted(fausses)) if fraction < 1 else None)

    def problemes(self):
        return (super().problemes() + ([("erreur", "aucune proposition correcte")] if not self.correctes() else [])
                + ([("erreur", f"bareme « {self.bareme} » : {', '.join(BAREMES)}")] if self.bareme not in BAREMES else []))


class ReponseCourte(Question):
    type = "reponse_courte"

    def __init__(self, id, enonce, reponses, tolerance=None, erreurs=None, **commun):
        super().__init__(id, enonce, **commun)
        self.reponses, self.tolerance, self.erreurs = reponses, tolerance, erreurs or []
        self._construire()

    def juste(self):
        return str(self.reponses[0])

    def accepte(self, saisie, reponse):
        a, b = nombre(saisie), nombre(reponse)
        if self.tolerance is not None and a is not None and b is not None:
            return abs(a - b) <= self.tolerance
        return normaliser(saisie) == normaliser(reponse)

    def corriger(self, saisie):
        saisie = saisie or ""
        if any(self.accepte(saisie, r) for r in self.reponses):
            return 1, None
        return 0, indice_de(self.erreurs, saisie)

    def _attendu(self):
        return " ou ".join(f"`{r}`" for r in self.reponses) + (f" (tolérance ± {self.tolerance:g})" if self.tolerance is not None else "")

    def problemes(self):
        return super().problemes() + ([("erreur", "reponses : au moins une")] if not self.reponses else [])


class ReponseOuverte(Question):
    type = "reponse_ouverte"

    def __init__(self, id, enonce, corrige, mots_cles=None, lignes=5, erreurs=None, **commun):
        super().__init__(id, enonce, **commun)
        self.corrige, self.mots_cles, self.lignes, self.erreurs = corrige, mots_cles or [], lignes, erreurs or []
        self._construire()

    def juste(self):
        return self.corrige

    def corriger(self, saisie):
        return None, None  # corrigée à la main

    def _attendu(self):
        return self.corrige + (f"\n\nMots-clés : {', '.join(self.mots_cles)}" if self.mots_cles else "")


def trou_juste(trou, texte):
    """Le texte saisi est-il l'une des réponses attendues du trou ?"""
    return any(normaliser(texte) == normaliser(r) for r in trou.reponses)


def corriger_trous(trous, saisie, distinctes=None):
    """La fraction et l'indice d'un ensemble de ``Trou`` remplis : moyenne des trous corrigibles, ``None`` si tous
    sont relevés (``reponses`` absent). Partagée par ``TexteATrous`` et ``Tableau``, dont c'est la même correction.
    ``distinctes`` : des groupes de trous dont les réponses doivent être deux à deux DIFFÉRENTES. « Proposer deux
    adresses » n'est pas deux questions indépendantes — chaque réponse y est juste isolément, c'est leur ÉGALITÉ
    qui est fausse, et une correction trou par trou ne peut pas la voir."""
    saisie = saisie or {}
    fautifs = set()
    for groupe in distinctes or []:
        memes = {}
        for n in groupe:
            texte = normaliser(saisie.get(n, ""))
            if texte:
                memes.setdefault(texte, []).append(n)
        fautifs |= {n for pareils in memes.values() if len(pareils) > 1 for n in pareils}
    notes, indice = [], None
    for n, trou in trous.items():
        if trou.reponses is None:
            continue  # relevé, à corriger à la main
        juste = trou_juste(trou, saisie.get(n, "")) and n not in fautifs
        notes.append(juste)
        indice = indice or (None if juste else indice_de(trou.erreurs, saisie.get(n, "")))
    if fautifs and not indice:
        indice = "Deux réponses qui doivent différer sont identiques."
    return (sum(notes) / len(notes) if notes else None), indice


def solution_trous(trous, distinctes=None):
    """La réponse attendue : la première réponse de chaque trou corrigible, les trous relevés omis. Dans un groupe
    de ``distinctes``, les trous acceptent souvent la MÊME liste de réponses (deux adresses prises dans le même
    sous-réseau) : chacun prend alors la première encore libre, sinon la solution proposée serait celle que la
    correction refuse."""
    solution = {n: str(t.reponses[0]) for n, t in trous.items() if t.reponses}
    for groupe in distinctes or []:
        prises = set()
        for n in groupe:
            trou = trous.get(n)
            libre = next((r for r in (trou.reponses or []) if normaliser(r) not in prises), None) if trou else None
            if libre is not None:
                solution[n] = str(libre)
                prises.add(normaliser(libre))
    return solution


def problemes_trous(trous, choix_communs, quoi="trou"):
    """Les contrôles d'un ensemble de ``Trou``, communs au texte à trous et au tableau."""
    p = []
    for n, trou in trous.items():
        choix = trou.choix or choix_communs
        if trou.reponses is None:
            p.append(("avert", f"{quoi} {n} sans réponse attendue, correction manuelle"))
        elif choix and not set(trou.reponses) & set(choix):
            p.append(("erreur", f"{quoi} {n}, aucune réponse ne figure dans la liste de choix"))
    return p


class TexteATrous(Question):
    """``saisie`` = {numéro de trou: texte saisi ou choisi}."""

    type = "texte_a_trous"

    MARQUEUR = re.compile(r"\[\[(\d+)\]\]")

    def __init__(self, id, enonce, texte, trous, choix=None, **commun):
        super().__init__(id, enonce, **commun)
        self.texte, self.trous, self.choix = texte, trous, choix
        self.devinable = bool(choix) or any(t.choix for t in trous.values())  # listes déroulantes
        self._construire()

    def juste(self):
        return solution_trous(self.trous)

    def corriger(self, saisie):
        return corriger_trous(self.trous, saisie)

    def complete(self):
        return len(self.saisie or {}) == len(self.trous)

    def _attendu(self):
        return self.texte

    def _trou_corrige(self, n):
        """Le mot attendu à la place du trou : en vert si l'élève l'avait, en rouge sinon (correction)."""
        trou, saisie = self.trous[n], self._lire() or {}
        if trou.reponses is None:
            return f"<b>{html.escape(saisie.get(n, '…'))}</b>"
        juste = trou_juste(trou, saisie.get(n, ""))
        # 11,7 pt sur ce corps de 10 (a_l_echelle) = 14 pt à l'écran, comme modele.TAILLE_MAIN : Kalam, à corps égal,
        # a des lettres basses (x-height) plus petites que la police du sujet (27/09/2026). « font-size:» sans espace,
        # sinon a_l_echelle ne le reconnaît pas (le trou restait à 10,8 pt jusqu'au 28/09/2026)
        return (f'<span style="color: {VERT if juste else "#c0392b"}; font-family: {POLICE_MAIN}; font-size:11.7pt">'
                f'{html.escape(str(trou.reponses[0]))}</span>')

    def problemes(self):
        p = super().problemes()
        marqueurs, trous = set(self.MARQUEUR.findall(self.texte)), set(self.trous)
        if marqueurs != trous:
            p.append(("erreur", f"marqueurs {sorted(marqueurs)} ≠ trous déclarés {sorted(trous)}"))
        return p + problemes_trous(self.trous, self.choix)


class Tableau(Question):
    """``saisie`` = {"ligne,colonne": texte saisi ou choisi} ; les cases à remplir sont des ``Trou``, comme un texte à trous.

    ``colonnes`` est la ligne d'en-têtes et ``lignes`` la grille telle qu'elle s'affiche (liste de listes de Markdown).
    Une case dont la référence ``"ligne,colonne"`` (numérotées à partir de 0, en-têtes non comptés) figure dans
    ``cellules`` est à remplir : ce qu'en dit ``lignes`` est alors ignoré. Les autres sont données. Un chronogramme
    s'écrit ainsi : une colonne par instant, une ligne par signal, des cellules à ``choix = ["0", "1"]``.

    ``distinctes`` = les groupes de cases dont les réponses doivent être deux à deux DIFFÉRENTES, par exemple
    ``[["0,1", "1,1"]]`` pour « proposer deux adresses IP » : sans cette contrainte, la même adresse écrite deux
    fois serait comptée juste deux fois, chaque case étant corrigée isolément."""

    type = "tableau"

    REFERENCE = re.compile(r"^(\d+),(\d+)$")

    def __init__(self, id, enonce, colonnes, lignes, cellules, choix=None, distinctes=None, **commun):
        super().__init__(id, enonce, **commun)
        self.colonnes, self.lignes, self.cellules, self.choix = colonnes, lignes, cellules, choix
        self.distinctes = distinctes
        self._construire()

    def juste(self):
        return solution_trous(self.cellules, self.distinctes)

    def corriger(self, saisie):
        return corriger_trous(self.cellules, saisie, self.distinctes)

    def complete(self):
        return len(self.saisie or {}) == len(self.cellules)

    def case(self, r, c, corrige=False):
        """Le contenu Markdown d'une case : le texte donné, ou la réponse attendue si ``corrige``, ou un blanc."""
        trou = self.cellules.get(f"{r},{c}")
        if trou is None:
            return self.lignes[r][c]
        if not corrige:
            return ""
        return self.juste().get(f"{r},{c}", "(relevé)")

    def _attendu(self):
        entetes = "| " + " | ".join(str(e) for e in self.colonnes) + " |"
        tiret = "|" + "---|" * len(self.colonnes)
        corps = [("| " + " | ".join(self.case(r, c, corrige=True) for c in range(len(self.colonnes))) + " |")
                 for r in range(len(self.lignes))]
        return "\n".join([entetes, tiret, *corps])

    def problemes(self):
        p = super().problemes()
        largeur = len(self.colonnes)
        for r, ligne_ in enumerate(self.lignes):
            if len(ligne_) != largeur:
                p.append(("erreur", f"ligne {r} : {len(ligne_)} cases pour {largeur} colonnes"))
        if not self.cellules:
            p.append(("erreur", "tableau sans aucune case à remplir"))
        for reference in self.cellules:
            m = self.REFERENCE.match(str(reference))
            if not m or not (int(m[1]) < len(self.lignes) and int(m[2]) < largeur):
                p.append(("erreur", f"cellule {reference} : hors de la grille {len(self.lignes)}×{largeur}"))
        for groupe in self.distinctes or []:
            if len(groupe) < 2:
                p.append(("erreur", f"distinctes {groupe} : une contrainte porte sur au moins deux cases"))
            for reference in groupe:
                if reference not in self.cellules:
                    p.append(("erreur", f"distinctes : la case {reference} n'est pas à remplir"))
        return p + problemes_trous(self.cellules, self.choix, "cellule")


def code_nu(texte):
    """Un élément écrit en Markdown (```` `x = 1` ````) rendu tel qu'il s'exécute, indentation comprise."""
    return texte[1:-1] if len(texte) > 1 and texte.startswith("`") and texte.endswith("`") else texte


class Ordre(Question):
    """``saisie`` = indices des ``elements`` (dans le bon ordre) dans l'ordre où l'élève les a rangés.

    ``langage`` vide : les éléments sont des étiquettes à glisser dans une liste. ``langage = "python"`` : ce sont
    des lignes de code, remises dans l'ordre DANS l'éditeur Python lui-même, où elles arrivent sans indentation
    (sinon les niveaux trahiraient l'ordre) : l'élève les indente aussi, et la saisie devient
    ``{"ordre": [...], "niveaux": [...]}`` (le niveau de chaque ligne, dans l'ordre rangé), jugée sur les deux. Une
    saisie en simple liste (ancienne copie, lecteur qui montre l'indentation) ne juge que l'ordre. Le texte n'est
    pas modifiable ; ``executable`` donne à l'élève la console pour essayer son rangement."""

    type = "ordre"

    devinable = True

    def __init__(self, id, enonce, elements, langage="", executable=False, **commun):
        super().__init__(id, enonce, **commun)
        self.elements, self.langage, self.executable = elements, langage, executable
        self.depart = melange(range(len(self.elements)), self.graine)
        self._construire()

    def juste(self):
        return list(range(len(self.elements)))

    def niveaux_justes(self):
        return [(len(code_nu(e)) - len(code_nu(e).lstrip(" "))) // 4 for e in self.elements]

    def corriger(self, saisie):
        if isinstance(saisie, dict):
            return int(saisie["ordre"] == self.juste() and saisie["niveaux"] == self.niveaux_justes()), None
        return (1 if (self.depart if saisie is None else saisie) == self.juste() else 0), None

    def _attendu(self):
        """Les accents graves n'entourent que du code : sans ``langage``, les éléments sont des étiquettes en
        français, et les accents graves s'y liraient tels quels là où la correction n'est pas rendue en Markdown."""
        return "\n".join(f"{n}. " + (f"`{code_nu(e)}`" if self.langage else e) for n, e in enumerate(self.elements, 1))

    def problemes(self):
        """``executable`` promet un bouton « Exécuter » qui marche : les lignes, remises dans le bon ordre, doivent
        donc former un programme valide — sans quoi l'élève n'obtiendrait qu'une erreur de syntaxe, quoi qu'il range."""
        p = super().problemes()
        if self.executable and self.langage != "python":
            p.append(("erreur", "executable sans langage python : rien à exécuter"))
        elif self.executable:
            try:
                compile("\n".join(code_nu(e) for e in self.elements), self.id, "exec")
            except SyntaxError as exc:
                p.append(("erreur", f"executable, mais les lignes dans le bon ordre ne compilent pas : "
                                    f"{exc.msg} (ligne {exc.lineno})"))
        return p


class Appariement(Question):
    """``saisie`` = pour chaque élément de gauche, l'indice de son élément de droite (``paires`` puis ``distracteurs``), ou ``None``."""

    type = "appariement"

    devinable = True

    def __init__(self, id, enonce, paires, distracteurs=None, **commun):
        super().__init__(id, enonce, **commun)
        self.paires, self.distracteurs = paires, distracteurs or []
        self._construire()

    def juste(self):
        return list(range(len(self.paires)))

    def corriger(self, saisie):
        saisie = saisie or [None] * len(self.paires)
        return sum(saisie[i] == i for i in range(len(self.paires))) / len(self.paires), None

    def _attendu(self):
        return "\n".join(f"- {p.gauche} → {p.droite}" for p in self.paires)

    def problemes(self):
        gauches = [p.gauche for p in self.paires]
        return super().problemes() + ([("erreur", "éléments de gauche en double")] if len(gauches) != len(set(gauches)) else [])


class PointSelection(Question):
    """``saisie`` = [x, y], en pixels de l'image d'origine."""

    type = "point_selection"

    def __init__(self, id, enonce, image, zones, **commun):
        super().__init__(id, enonce, **commun)
        self.image, self.zones = image, zones
        self._construire()

    def juste(self):
        return self.zones[0].centre()

    def corriger(self, saisie):
        return (1 if saisie and any(z.contient(*saisie) for z in self.zones) else 0), None

    def _attendu(self):
        return "Zones attendues, en pixels : " + "; ".join(z.decrire() for z in self.zones)

    def problemes(self):
        return super().problemes() + ([("avert", "seconde_chance sans effet, pas d'indice possible sur une sélection de point")]
                                      if self.seconde_chance and self.seconde_chance.actif else [])


class Dessin(Question):
    """``saisie`` = [[source, cible, étiquette], …] : les arêtes tracées par l'élève entre des sommets que le
    professeur a NOMMÉS ET PLACÉS. C'est ce qui rend la correction possible sans comparer deux graphes à un
    isomorphisme près : les arêtes se comparent en ensembles. Un arbre binaire est le cas où les étiquettes sont
    « g » et « d », un automate celui où les sommets portent une ``marque`` et les arêtes les lettres de l'alphabet,
    un circuit logique celui où les sommets sont des portes nommées.
    ``decor`` : des arêtes DONNÉES, tracées en gris clair et que l'élève ne peut ni créer ni effacer. C'est ce qui
    permet de demander un chemin dans un réseau déjà tracé, ou la suite d'un arbre dont le début est fourni."""

    type = "dessin"

    def __init__(self, id, enonce, sommets, aretes, oriente=False, etiquettes=None, image="", decor=None, **commun):
        super().__init__(id, enonce, **commun)
        self.sommets, self.aretes, self.oriente = sommets, aretes, oriente
        self.etiquettes, self.image, self.decor = etiquettes or [], image, decor or []
        self._construire()

    def juste(self):
        return [[a.source, a.cible, a.etiquette] for a in self.aretes]

    def cle(self, source, cible, etiquette=""):
        """La forme comparable d'une arête : non orientée, les deux bouts sont interchangeables."""
        bouts = (source, cible) if self.oriente else tuple(sorted((str(source), str(cible))))
        return (*bouts, normaliser(etiquette))

    def corriger(self, saisie):
        """Une arête en trop coûte autant qu'une arête manquante : sinon, tout relier vaudrait la note maximale."""
        restantes, justes = [self.cle(a.source, a.cible, a.etiquette) for a in self.aretes], 0
        attendues = len(restantes)
        tracees = [self.cle(*a) for a in (saisie or [])]
        for cle in tracees:
            if cle in restantes:
                restantes.remove(cle)
                justes += 1
        return (max(0, (justes - (len(tracees) - justes)) / attendues) if attendues else None), None

    def _attendu(self):
        fleche = "→" if self.oriente else "—"
        return "\n".join(f"- {a.source} {fleche} {a.cible}" + (f" ({a.etiquette})" if a.etiquette else "")
                         for a in self.aretes)

    def problemes(self):
        p = super().problemes()
        noms = [s.nom for s in self.sommets]
        if len(set(noms)) != len(noms):
            p.append(("erreur", "deux sommets portent le même nom : les arêtes ne désigneraient rien de sûr"))
        if not self.aretes:
            p.append(("erreur", "aucune arête attendue, la question ne peut pas être corrigée"))
        for a in self.decor:
            if a.source not in noms or a.cible not in noms:
                p.append(("erreur", f"décor {a.source}-{a.cible} : sommet inconnu"))
        for a in self.aretes + self.decor:
            if a.source == a.cible:  # la toile n'en trace pas, l'élève ne peut donc pas la poser (choix du 24/09/2026)
                p.append(("erreur", f"arête {a.source}-{a.cible} : une boucle ne se dessine pas"))
        for a in self.aretes:
            if a.source not in noms or a.cible not in noms:
                p.append(("erreur", f"arête {a.source}-{a.cible} : sommet inconnu"))
            elif self.etiquettes and a.etiquette not in [str(e) for e in self.etiquettes]:
                p.append(("erreur", f"arête {a.source}-{a.cible} : l'étiquette « {a.etiquette} » n'est pas proposée à l'élève"))
        for s in self.sommets:
            if s.marque not in ("", "initial", "final"):
                p.append(("erreur", f"sommet {s.nom} : marque « {s.marque} » inconnue (initial, final ou rien)"))
        if self.seconde_chance and self.seconde_chance.actif:
            p.append(("avert", "seconde_chance sans effet, pas d'indice possible sur un dessin"))
        return p


class Code(Question):
    """``saisie`` = le code écrit ; corrigé par ``verifier.verifier_question`` (un sous-processus par question)."""

    type = "code"

    def __init__(self, id, enonce, solution, langage="python", code_initial="", tests=None, tests_code="", fichier="",
                 lignes=10, erreurs=None, autorises=None, **commun):
        super().__init__(id, enonce, **commun)
        self.solution, self.langage, self.code_initial, self.tests = solution, langage, code_initial, tests or []
        self.tests_code, self.fichier, self.lignes, self.erreurs = tests_code, fichier, lignes, erreurs or []
        self.autorises = autorises
        self._corrections = {}  # (saisie, classe) -> correction : un sous-processus par appel, et on en fait plusieurs
        if self.type == "code":  # mesuré : sans cela, un Sql rouvert en seconde chance corrige sur une base vide,
            self._construire()     # « no such table », car _construire corrige AVANT que Sql n'ait posé self.base

    def juste(self):
        return self.solution

    def corriger(self, saisie):
        cle = (saisie, self.classe)
        if cle not in self._corrections:
            self._corrections[cle] = self._verifier(saisie)
        return self._corrections[cle]

    def testee(self):
        """Faux : sans test, la question reste au professeur."""
        return bool(self.tests or self.tests_code)

    def _verifier(self, saisie):
        import tempfile  # noqa: PLC0415 - seulement ici : verifier.py importe modele côté professeur
        from pathlib import Path  # noqa: PLC0415

        from verifier import verifier_question  # noqa: PLC0415
        if not self.testee():
            return None, None
        with tempfile.TemporaryDirectory() as dossier:
            (Path(dossier) / (self.fichier or "tp.py")).write_text(saisie if saisie is not None else self.code_initial, encoding="utf-8")
            r = verifier_question(self, dossier, "tp.py", classe=self.classe)
        return r["obtenus"] / self.points, ("\n\n".join(r["messages"]) or None)

    def _diagnostic(self):
        """Le message d'erreur de Python traduit et expliqué (erreurs_python.py) : jamais avant la soumission, où
        l'élève n'a que le message brut."""
        from erreurs_python import expliquer  # noqa: PLC0415

        source = self.code_initial if self.saisie is None else self.saisie
        if self.langage != "python" or source == self.solution:
            return ""
        return expliquer(self.corriger(self.saisie)[1], source)

    def _attendu(self):
        tests = "\n".join(f"- `{t.appel}` → `{t.attendu}`" for t in self.tests)
        return f"```{self.langage}\n{self.solution.rstrip()}\n```" + (f"\n\n{tests}" if tests else "")

    def problemes(self):
        p = super().problemes()
        if not self.tests and not self.tests_code:
            p.append(("avert", "code sans tests, correction manuelle seulement"))
        if self.code_initial and self.code_initial == self.solution:
            p.append(("erreur", "code_initial identique à la solution"))
        return p


class Sql(Code):
    """``saisie`` = la requête écrite ; corrigée en l'EXÉCUTANT sur ``base``, jamais en comparant son texte.

    ``base`` est le script ``CREATE TABLE … ; INSERT …`` du jeu de données, en TEXTE : la banque reste un JSON
    diffable, et ``medias`` ne transporte de toute façon que des images. Chaque ``Test`` rejoue ce script dans une
    base neuve en mémoire, si bien qu'un test ne subit pas l'état laissé par le précédent : un ``appel`` vide juge
    le résultat de la requête de l'élève, un ``appel`` non vide est une requête de CONTRÔLE jouée après elle, ce qui
    note aussi un INSERT, un UPDATE ou un DELETE. ``attendu`` est le ``repr()`` de la liste de tuples attendue ;
    l'ordre des lignes est indifférent sauf si ``ordonne``, et les colonnes se comparent par position, donc les
    alias sont libres mais un ``SELECT *`` à la place des colonnes demandées est refusé."""

    type = "sql"

    def __init__(self, id, enonce, solution, base, tests=None, ordonne=False, langage="sql", fichier="requete.sql",
                 lignes=6, **commun):
        # ``langage`` est redéclaré pour que son défaut soit « sql » ici : sans cela il serait écrit dans le JSON
        # (différent du défaut de Code), puis relu dans ``commun`` — et passé deux fois à Code au rechargement.
        super().__init__(id, enonce, solution, langage=langage, tests=tests, fichier=fichier, lignes=lignes, **commun)
        self.base, self.ordonne = base, ordonne
        self._construire()

    def _attendu(self):
        tests = "\n".join(f"- {'résultat' if not t.appel.strip() else f'`{t.appel}`'} → `{t.attendu}`" for t in self.tests)
        return f"```{self.langage}\n{self.solution.rstrip()}\n```" + (f"\n\n{tests}" if tests else "")

    def problemes(self):
        import sqlite3  # noqa: PLC0415 - seulement ici, pour éprouver le script de la base

        p = super().problemes()
        if not self.base.strip():
            p.append(("erreur", "sql sans base : la requête n'aurait rien sur quoi tourner"))
            return p
        try:
            sqlite3.connect(":memory:").executescript(self.base)
        except sqlite3.Error as exc:
            p.append(("erreur", f"base : {type(exc).__name__} : {exc}"))
        if self.tests_code:
            p.append(("erreur", "sql : tests_code est du Python, sans effet ici ; écrire des tests"))
        return p


class Classement(Question):
    """``saisie`` = pour chaque élément (dans l'ordre de ``elements``), l'indice de la catégorie choisie, ou ``None``."""

    type = "classement"

    devinable = True

    def __init__(self, id, enonce, categories, elements, **commun):
        super().__init__(id, enonce, **commun)
        self.categories, self.elements = categories, elements
        self.depart = melange(range(len(self.elements)), self.graine)
        self._construire()

    def juste(self):
        return [self.categories.index(e.categorie) for e in self.elements]

    def corriger(self, saisie):
        saisie = saisie or [None] * len(self.elements)
        return sum(s == j for s, j in zip(saisie, self.juste())) / len(self.elements), None

    def _attendu(self):
        return "\n".join(f"- **{c}** : " + ", ".join(e.texte for e in self.elements if e.categorie == c) for c in self.categories)

    def problemes(self):
        p, utilisees = super().problemes(), {e.categorie for e in self.elements}
        p += [("erreur", f"catégorie « {c} » absente de categories") for c in sorted(utilisees - set(self.categories))]
        return p + [("avert", f"catégorie « {c} » sans aucun élément") for c in sorted(set(self.categories) - utilisees)]


class Personnalise(Question):
    """Une question dont le professeur écrit lui-même le widget, quand aucun type ne convient.

    ``widget`` est du code Python exécuté à la construction, avec pour noms de départ ceux de ce module (les classes
    Qt, ``Texte``, ``hauteur``…). Il y définit des fonctions qui reçoivent la question en premier argument et tiennent
    lieu des méthodes d'un type : ``corps(q, d)`` (les widgets de saisie, ajoutés à la disposition ``d`` et à
    ``q.entrees`` pour être grisés hors épreuve), ``lire(q)`` (la saisie, en JSON), ``ecrire(q, valeur)`` (l'inverse),
    ``corriger(q, saisie)`` (``(fraction, indice)``) et, facultative, ``juste(q)`` (la bonne saisie, que le corrigé
    montre dans le widget). ``papier`` et ``attendu`` sont le repli Markdown des exports imprimés : un widget ne
    s'imprime pas.

    Ce code est celui du professeur, embarqué dans le sujet comme le ``tests_code`` d'une question ``code`` : il
    n'est ni filtré ni confiné. Il est en revanche isolé des pannes — une erreur, à son exécution comme dans l'une
    de ses fonctions, dégrade la question en message rouge et renvoie sa correction au professeur, au lieu
    d'emporter le paquet en pleine épreuve."""

    type = "personnalise"

    def __init__(self, id, enonce, widget, papier="", attendu="", **commun):
        super().__init__(id, enonce, **commun)
        self.widget, self.papier, self.attendu = widget, papier, attendu
        self.fonctions, self.panne = {}, ""
        self._construire()

    def _casser(self, quoi, exc):
        """Panne du code du professeur : la question le dit en rouge, et sa correction lui revient."""
        traceback.print_exc()
        self.panne = f"{quoi} : {exc.__class__.__name__} : {exc}"

    def _appeler(self, nom, defaut, *args):
        """La fonction du professeur, ou ``defaut`` si elle manque, si elle tombe, ou si la question est déjà en panne."""
        if self.panne or nom not in self.fonctions:
            return defaut
        try:
            return self.fonctions[nom](self, *args)
        except Exception as exc:  # noqa: BLE001 - n'importe quelle erreur du code du professeur
            self._casser(f"{nom}()", exc)
            return defaut

    def juste(self):
        return self._appeler("juste", None)

    def corriger(self, saisie):
        return self._appeler("corriger", (None, None), saisie)  # en panne : fraction None, la question attend le professeur

    def _attendu(self):
        return self.attendu

    def problemes(self):
        p = super().problemes()
        if self.panne:
            p.append(("erreur", f"widget : {self.panne}"))
        if not self.attendu:
            p.append(("avert", "sans attendu : le corrigé n'aura rien à montrer"))
        if not self.papier:
            p.append(("avert", "sans papier : le sujet imprimé n'aura que des lignes à remplir"))
        return p


class Groupe(Question):
    type = "groupe"

    def __init__(self, id, enonce, sous_questions, **commun):
        if "points" in commun:
            raise TypeError("un groupe n'a pas de points propres, c'est la somme des sous-questions")
        super().__init__(id, enonce, **commun)
        self.sous_questions = sous_questions
        for lettre, sq in zip("abcdefghijklmnopqrstuvwxyz", sous_questions):
            sq.reperer(f"{lettre}.")
        self._construire()

    def feuilles(self):
        return self.sous_questions

    def total(self):
        return sum(sq.total() for sq in self.sous_questions)

    def montrer_correction(self, couleur=""):
        for sq in self.sous_questions:
            sq.montrer_correction(couleur)

    def presenter_corrige(self):
        for sq in self.sous_questions:
            sq.presenter_corrige()

    def problemes(self):
        p = super().problemes()
        if len(self.sous_questions) < 2:
            p.append(("erreur", "un groupe a au moins deux sous-questions"))
        rangs = {sq.id: n for n, sq in enumerate(self.sous_questions)}
        for n, sq in enumerate(self.sous_questions):
            if isinstance(sq, Groupe):
                p.append(("erreur", f"{sq.id} : groupe dans un groupe, un seul niveau permis"))
            for r in sq.revele:
                if r == self.id or rangs.get(r, -1) > n:
                    p.append(("erreur", f"{sq.id} : révèle {r}, qui ne la précède pas dans le groupe (ordre fixe)"))
        return p


# --- banque, section, sujet, paquet -----------------------------------------------------------------------------

def revelees(q, groupe_de):
    """Les questions dont ``q`` ou l'une de ses sous-questions révèle la réponse (champ ``revele``), une
    sous-question citée étant remplacée par son groupe : ``groupe_de`` = {id de sous-question: id du groupe}."""
    return {groupe_de.get(r, r) for sq in [q, *q.sous_questions] for r in sq.revele} - {q.id}


def ordonner(resolues, groupe_de, melanger=""):
    """Les (question, …) d'une section, mélangées d'abord si ``melanger`` (le titre du sujet : un ordre propre au sujet,
    le même sur papier et pour chaque élève), puis chacune après celles dont elle révèle la réponse, l'ordre reçu conservé
    pour le reste (une boucle de révélations, refusée par le validateur, garde simplement l'ordre reçu)."""
    restant, ordre = list(resolues), []
    if melanger:
        random.Random(melanger + str(len(restant))).shuffle(restant)
    while restant:
        presentes = {q.id for q, *_ in restant}
        ordre.append(restant.pop(next((i for i, (q, *_) in enumerate(restant) if not revelees(q, groupe_de) & presentes), 0)))
    return ordre


def afficher_contextes(questions, contextes, repeter=False):
    """Chaque texte partagé s'ouvre au-dessus de la première question qui le cite — au-dessus de CHACUNE si
    ``repeter`` : une question par écran, c'est la seule façon que la figure de l'exercice reste sous les yeux."""
    vus = set()
    for q in questions:
        for f in (q, *q.sous_questions):
            for nom in reversed(f.contextes_cites()):  # insérés au-dessus les uns des autres, donc du dernier au premier
                if repeter or nom not in vus:
                    vus.add(nom)
                    f.afficher_contexte(contextes[nom])


class Banque(Objet):
    """Un fichier de banque : questions, textes partagés (``contextes``) et fichiers embarqués (``medias`` : nom -> bytes).
    Affichée, elle montre ses questions corrigées."""

    def __init__(self, matiere, questions, niveau="", theme="", contextes=None, medias=None):
        self.matiere, self.niveau, self.theme = matiere, niveau, theme
        self.contextes, self.medias, self.questions = contextes or {}, medias or {}, questions
        MEDIAS.update(self.medias)
        afficher_contextes(questions, self.contextes)


class Section(Objet):
    """``questions`` : les questions d'un paquet, ou, dans un sujet, des identifiants (ou une ``Reference`` quand les points
    diffèrent de ceux de la banque) qui n'ont rien à afficher. ``bonus`` : ses points s'ajoutent à la note sans compter
    dans le total (questions pour les plus rapides). ``nouvelle_page`` : sur papier, la section commence sur une
    feuille à elle (page impaire, recto-verso), pour être ramassée à part. ``electronique`` : ``titre`` et ``consignes``
    tels que le .qcm les affiche, quand ils y diffèrent du papier (``Question.electronique``)."""

    def __init__(self, questions, titre="", consignes="", bonus=False, nouvelle_page=False, electronique=None):
        self.titre, self.consignes, self.questions, self.bonus = titre, consignes, questions, bonus
        self.nouvelle_page, self.electronique = nouvelle_page, electronique


class DefinitionSujet(Objet):
    """Un fichier de sujet (évaluation papier, QCM électronique, TP ou projet)."""

    def __init__(self, titre, destination, banques, sections, sous_titre="", theme="", matiere="", classe="", date="",
                 duree_minutes=None, consignes="", fichier="tp.py", melanger_questions=False, affichage="sujet",
                 retour=True, graine=None, seconde_chance=None, correction=True, revision="",
                 entrainement=False, acces_cours=False, sans_execution=False, dossier="", sans_ide=False,
                 surveillance=False):
        self.titre, self.sous_titre, self.theme, self.matiere, self.classe = titre, sous_titre, theme, matiere, classe
        self.date, self.duree_minutes, self.destination, self.consignes = date, duree_minutes, destination, consignes
        self.fichier, self.melanger_questions, self.affichage, self.retour = fichier, melanger_questions, affichage, retour
        self.graine, self.seconde_chance, self.banques, self.sections = graine, seconde_chance, banques, sections
        self.correction, self.revision = correction, revision
        self.entrainement = entrainement  # ni indice ni seconde chance ne coûtent de points : seuls les délais comptent
        self.sans_execution = sans_execution  # comme sur papier : pas de console, le code ne tourne qu'à la soumission
        self.acces_cours = acces_cours  # les élèves ont le cours sous la main : l'``aide_cours`` d'une question remplace son ``aide``
        self.dossier = dossier  # où vont ses exports, relatif au dossier du professeur (``sujet.sortie``) ; vide : Exports/
        self.sans_ide = sans_ide  # le .qcm d'un TP « sans IDE » : ses questions prennent ``electronique["sans_ide"]``
        self.surveillance = surveillance  # le lecteur noircit l'écran une minute à chaque sortie de l'épreuve (``Lecteur.sortir``)

    def problemes(self):
        """[(niveau, message)] : ce que la classe ne peut pas empêcher."""
        regles = [(self.destination in DESTINATIONS, f"destination « {self.destination} » : {', '.join(DESTINATIONS)}"),
                  (bool(self.titre), "titre vide"), (bool(self.banques), "aucune banque"),
                  (type(self.graine) is int, f"graine « {self.graine} » : un entier, propre au sujet (tirages et clé du .qcm)"),
                  (all(s.questions for s in self.sections) and bool(self.sections), "sections : au moins une, chacune avec des questions"),
                  (re.fullmatch(r"[A-Za-z0-9_.-]+\.py", self.fichier) is not None, f"fichier « {self.fichier} » : un nom en .py"),
                  (not self.date or re.fullmatch(r"\d{4}-\d\d-\d\d", self.date) is not None, f"date « {self.date} » : AAAA-MM-JJ"),
                  (self.duree_minutes is None or self.duree_minutes > 0, "duree_minutes : strictement positive"),
                  (self.affichage in ("sujet", "question"), f"affichage « {self.affichage} » : sujet ou question"),
                  (not self.dossier or self.dossier.rsplit("/", 1)[-1] in RANGEMENTS,
                   f"dossier « {self.dossier} » : se termine par {', '.join(RANGEMENTS)}")]
        return [("erreur", message) for ok, message in regles if not ok]


class Paquet(Objet):
    """Le fichier que reçoit l'élève, chiffré : le sujet tiré pour lui, questions complètes, et — enregistrée à chaque
    réponse dans le même fichier — sa session (``courante``, ``debut``, ``fin``, et l'état de chaque question).

    ``affichage`` : « sujet » (tout sur un écran défilant) ou « question » (une par écran) ; ``retour`` : revenir sur une
    réponse soumise ; ``correction`` : note et correction en fin d'épreuve. Une question qui en révèle une autre n'apparaît
    qu'une fois celle-ci validée (ou figée par le passage à l'écran suivant). ``eleve`` : « Nom Prénom », saisi à l'ouverture.
    ``graine`` : celle du sujet tant que le paquet reste à préparer : un seul fichier pour la classe, ses questions telles
    que la banque les donne (une seule fois) avec les réglages du sujet (``date`` et ``revision`` de l'export,
    ``melanger_questions``, ``seconde_chance``, ``entrainement``, ``acces_cours``, ceux de ``DefinitionSujet``), que
    ``nommer`` applique pour chaque élève ; vide une fois préparé (la copie). C'est aussi, en clair, la sauvegarde d'un
    export PDF, dont ``sujet.lire`` refait la définition du sujet. ``inscrits`` : ``{classe: [[nom, prénom], …]}``, les
    élèves admis à ouvrir le sujet, reconnus à l'accueil par le code de leur classe (``codes``). ``note`` et ``appreciation`` :
    celles que le professeur écrit sur la copie rendue, dans l'entête ; sans ``note``, c'est celle de la machine qui s'affiche.
    Le paquet à préparer garde chaque question telle que le papier la pose, sa version pour l'écran à côté
    (``Question.electronique``, ``Section.electronique``) : un seul fichier sert au PDF qui l'embarque et au lecteur, qui
    prend la version pour l'écran à l'accueil (``nommer``) ; ``sans_ide`` : celle d'un TP « sans IDE »."""

    def __init__(self, titre, destination, sections, sous_titre="", theme="", matiere="", classe="", date="", consignes="",
                 duree_minutes=None, fichier="tp.py", contextes=None, medias=None, affichage="sujet", retour=True,
                 correction=True, courante=0, debut=None, fin=None, eleve="", graine="", sans_execution=False,
                 inscrits=None, revision="", melanger_questions=False, seconde_chance=None, entrainement=False,
                 acces_cours=False, note=None, appreciation="", empreinte="", heure_locale=False, sans_ide=False,
                 surveillance=False, sorties=None):
        self.titre, self.sous_titre, self.theme, self.matiere, self.classe = titre, sous_titre, theme, matiere, classe
        self.sans_ide, self.surveillance = sans_ide, surveillance
        # les sorties de l'épreuve (``lecteur.Lecteur.sortir``) : [départ, retour] en time.time(), départ None pour une copie
        # rouverte (page fermée ou rechargée), retour None si l'élève n'est pas revenu avant la fin
        self.sorties = sorties or []
        self.note, self.appreciation = note, appreciation
        # la copie d'un élève : l'empreinte de son code personnel (``codes.empreinte`` : le lecteur web n'accepte plus d'autre
        # copie sous ce nom sans ce code), et si l'heure de fin a été jugée sur l'horloge de l'ordinateur, faute de réseau
        self.empreinte, self.heure_locale, self.limite = empreinte, heure_locale, None  # limite : celle du code, pas enregistrée
        self.tp, self.retenue = False, False  # le code est d'un TP (``codes.en_tp``), pas enregistré non plus : voir ``retenir``
        self.destination, self.consignes, self.duree_minutes, self.fichier = destination, consignes, duree_minutes, fichier
        self.contextes, self.medias, self.sections, self.date, self.revision = contextes or {}, medias or {}, sections, date, revision
        self.affichage, self.retour, self.correction = affichage, retour, correction
        self.courante, self.debut, self.fin, self.demarre, self.fige = courante, debut, fin, False, False
        self.ici = None  # la question où était l'élève à la dernière seconde : ``ecouler`` voit qu'il la quitte
        self.eleve, self.graine, self.sans_execution, self.inscrits = eleve, graine, sans_execution, inscrits or {}
        self.melanger_questions, self.seconde_chance = melanger_questions, seconde_chance
        self.entrainement, self.acces_cours = entrainement, acces_cours
        self.total = sum(q.total() for s in sections if not s.bonus for q in s.questions)
        MEDIAS.update(self.medias)
        afficher_contextes(self.questions(), self.contextes, self.affichage == "question")
        for n, q in enumerate(self.questions(), 1):
            q.numeroter(n)
        self.feuilles = [f for q in self.questions() for f in q.feuilles()]
        self.cibles = {f.id: [f] for f in self.feuilles} | {q.id: q.feuilles() for q in self.questions()}
        # Les questions bonus avancent à part : finir les autres remplit la barre d'avancement, pas « presque tout ».
        self.feuilles_bonus = [f for s in sections if s.bonus for q in s.questions for f in q.feuilles()]
        self.pages = self.unites = self.questions()  # un écran par question en mode « question »
        for f in self.feuilles:
            f.classe, f.projet, f.sans_execution = classe, destination == "projet", sans_execution
            if f.projet:
                f._montrer_enonce()  # ses actions à cocher et ses codes à copier, que la question seule ignorait
            f.modifiable = retour and not self._fausse(f)
            f.changee.connect(self.rafraichir)
            f.changee.connect(functools.partial(self._suite, f))
            f.mettre_a_jour()
        self._construire()

    def __setstate__(self, etat):
        etat.pop("total", None)  # écrit par les exports d'avant le 26/09/2026 : il se calcule
        super().__setstate__(etat)

    def nommer(self, eleve):
        """Le paquet au nom de l'élève, préparé pour lui si ce n'est pas déjà fait (``graine``) : ``variables`` et mélanges
        tirés (graine du sujet, nom, id de la question), questions et sections dans leur version pour l'écran
        (``Question.version_electronique``), une seule aide (``acces_cours``), la seconde chance du sujet donnée
        à chaque question qui n'a pas la sienne (ajustée au hasard, ``Question.adapter_chance``), aucun malus pour un
        ``entrainement`` (la même banque sert à l'évaluation), questions mélangées si le sujet le demande et chacune après
        celles dont elle révèle la réponse. Tout est déterministe : le même élève retrouve le même sujet. Une copie, déjà
        préparée, est rendue telle quelle ; la refaire ne changerait rien, sauf le mélange des questions."""
        if not self.graine:
            self.eleve = eleve
            return self
        graine = f"{self.graine}|{normaliser(eleve)}"
        groupe_de = {sq.id: q.id for q in self.questions() for sq in q.sous_questions}
        sections = []
        for s in self.sections:
            questions = [q.instancier(f"{graine}|{q.id}") for q in (q.version_electronique(self.sans_ide) for q in s.questions) if q]
            for f in (f for q in questions for f in q.feuilles()):
                f.garder_une_aide(self.acces_cours)
                f.seconde_chance = SecondeChance(actif=False) if not self.correction else f.seconde_chance or f.adapter_chance(self.seconde_chance)
                if self.entrainement:
                    f.seconde_chance = f.seconde_chance and SecondeChance(0, f.seconde_chance.actif)
                    for i in f.indices:
                        i.malus = 0
            ordre = ordonner([(q,) for q in questions], groupe_de, self.melanger_questions and self.titre)
            textes = {"titre": s.titre, "consignes": s.consignes} | (s.electronique or {})
            sections.append(copier(s, sauf=("questions", "electronique"), imposes={"questions": [q for q, in ordre], **textes}))
        return copier(self, sauf=("sections",), imposes={"sections": sections, "graine": "", "eleve": eleve})

    def entete(self):
        """Le texte de l'entête : titre en capitales, sous-titre. Les consignes n'y sont pas : elles ouvrent le sujet, qui
        défile, pour que l'entête ne garde pas leur hauteur une fois l'épreuve commencée."""
        return "\n\n".join(filter(None, [f"# {en_capitales(self.titre).replace(chr(10), '<br>')}", self.sous_titre and f"## {self.sous_titre}"]))

    def _construire(self):
        if self.fin is not None:
            self._montrer_fin()
        else:
            self.rafraichir()

    # -- crochets de l'affichage

    def _afficher_page(self, n):
        """Mode « question » : l'écran ``n``."""

    def _defiler(self, n, recadrer=False):
        """Mode « sujet » : fait défiler la vue jusqu'à la question ``n``. ``recadrer`` : seulement si une autre question
        est visible au-dessus d'elle ; jamais vers le haut, ce qui cacherait la correction au bas d'une longue question."""

    def _rafraichir_vue(self):
        """Barres d'avancement et boutons de navigation."""

    def _confirmer(self):
        """« Soumettre toutes les questions » : l'élève confirme."""
        return True

    def questions(self):
        return [q for s in self.sections for q in s.questions]

    def _page(self):
        return [self.pages[self.courante]] if self.affichage == "question" else self.questions()

    def demarrer(self):
        """L'élève commence : les questions visibles deviennent modifiables."""
        self.demarre = True
        self.debut = self.debut or time.time()
        self.rafraichir()

    def aller(self, n):
        """Écran ``n`` (mode « question ») : ce que ses questions révèlent est d'abord figé."""
        if not 0 <= n < len(self.pages) or (n < self.courante and not self.retour):
            return
        self.courante = n
        self._afficher_page(n)
        self.fige = True
        for f in (f for q in self._page() for f in q.feuilles()):
            for r in f.revele + self.pages[n].revele:
                for cible in self.cibles.get(r, []):
                    cible.geler()
        self.fige = False
        self.rafraichir()

    def _suite(self, feuille):
        """Après un changement de ``feuille``. Mode « sujet » : soumise, la vue se cale sur la question elle-même,
        pour qu'on relise l'énoncé et la correction (demande de l'utilisateur, 26/09/2026), puis l'élève avance par « Non
        traitée ». Mode « question » : une fois toutes les questions de l'écran closes, on passe au suivant, sauf avec
        ``correction`` (« Suivant »). Une confirmation ou une correction reste affichée sur chaque question soumise
        (demande de l'utilisateur, 26/09/2026 : plus seulement sur la dernière).
        ``geler`` émet aussi ``changee`` : ce qu'il fige (révélation, fin) n'enchaîne pas."""
        if self.fin is not None or self.fige:
            return
        fausse = self._fausse(feuille)
        if fausse:
            feuille.montrer_correction("#c0392b")
            feuille.modifiable = False  # la correction est vue : plus de retour possible
            feuille.mettre_a_jour()
        elif self.correction and feuille.fermee and feuille.corriger(feuille.saisie)[0] == 1:
            feuille.confirmer()
        if self.affichage == "sujet":
            if feuille.fermee:
                self.courante = next(n for n, q in enumerate(self.unites) if feuille in q.feuilles())
                self._defiler(self.courante, recadrer=True)
                self.rafraichir()
        elif not self.correction and all(f.fermee for f in self.pages[self.courante].feuilles()):
            self.aller(self.courante + 1)

    def _fausse(self, feuille):
        """Close sur une mauvaise réponse, dont la correction doit s'afficher."""
        return self.correction and feuille.fermee and feuille.corriger(feuille.saisie)[0] not in (1, None)

    def _libre(self, unite):
        """Une question (ou un écran) dont une feuille visible n'est ni validée ni soumise."""
        return any(not (f.fermee or f.repondue) and not f.cachee for f in unite.feuilles())

    def _voisine(self, sens):
        """Rang de la prochaine (``sens`` = 1) ou de la précédente (-1) question « non traitée », ou ``None``."""
        fin = len(self.unites) if sens > 0 else -1
        return next((n for n in range(self.courante + sens, fin, sens) if self._libre(self.unites[n])), None)

    def sauter(self, sens):
        """Va à la question voisine « non traitée » : à son écran, ou en la faisant défiler dans la vue."""
        n = self._voisine(sens)
        if n is None:
            return
        if self.affichage == "question":
            self.aller(n)
        else:
            self.courante = n
            self._defiler(n)
            self.rafraichir()

    def _devant(self):
        """La question ouverte où est l'élève : ici la première de l'écran ; le widget y ajoute la souris et ce que
        montre la vue."""
        return next((f for q in self._page() for f in q.feuilles() if f.actif and not (f.fermee or f.cachee)), None)

    def ecouler(self):
        """Une seconde de plus, appelée par le chronomètre du lecteur : le délai des indices ne court que sur la question
        où est l'élève (``_devant``), pas sur toutes les questions posées (demande de l'utilisateur, 27/09/2026) ; celle
        qu'il vient de quitter devient « traitée » si sa réponse est entière (``Question.quitter``)."""
        f = self._devant()
        if f is not self.ici:
            if self.ici is not None:
                self.ici.quitter()
            self.ici = f
        if f is not None and f.indice_delai():
            f.presence += 1
            f.mettre_a_jour()

    def retenir(self, oui):
        """Un TP (``tp``) : tant que ``oui``, aucune question ne se soumet, ni une à une, ni toutes, ni en rendant la copie —
        l'élève n'a aucune bonne réponse à donner à son voisin au fil du TP (demande de l'utilisateur, 28/09/2026). Le
        chronomètre du lecteur lève la retenue aux 3/4 du temps."""
        if oui == self.retenue:
            return
        self.retenue = oui
        for f in self.feuilles:
            f.retenue = oui
            f.mettre_a_jour()
        self.rafraichir()

    def rafraichir(self):
        """Ce qui est visible (rien avant ce qu'il révèle, dans un groupe rien avant la précédente en mode « question »),
        ce qui commence à courir (délai des indices), et où en est l'avancement."""
        for q in self.questions():
            for f in (q, *q.sous_questions):
                cachee = any(not all(c.fermee for c in self.cibles.get(r, [])) for r in f.revele) and self.fin is None
                if self.affichage == "question" and f in q.sous_questions and self.fin is None:
                    avant = q.sous_questions[:q.sous_questions.index(f)]
                    cachee = cachee or not all(a.fermee for a in avant)
                f.montrer(not cachee)
                if not cachee and self.demarre and f in [x for p in self._page() for x in p.feuilles()]:
                    f.demarrer()
        self._rafraichir_vue()

    def resultat(self):
        """(points gagnés, points corrigés par la machine, points laissés au professeur) : sur ``total``."""
        obtenus = sum(f.obtenu or 0 for f in self.feuilles)
        attente = sum((f.points if f.obtenu is None else 0) + (f.justification.points if f.justification else 0)
                      for f in self.feuilles if f.fermee)
        return obtenus, self.total - attente, attente

    def rejouable(self):
        """Une seconde chance existe quelque part dans ce sujet : soumettre sans terminer a alors un sens (l'élève
        peut reprendre une réponse fausse) ; sinon « Corriger mes réponses » ne ferait que « Rendre ma copie » sans
        la note, et le bouton n'est pas montré."""
        return any(f.chance() for f in self.feuilles)

    def soumettre_tout(self, confirmer=True):
        """Le bouton « Corriger mes réponses » : chaque question encore ouverte est soumise comme si l'élève
        l'avait validée lui-même — donc une réponse fausse ouvre sa seconde chance, tant qu'il reste du temps. Seule
        la fin du temps (``terminer``) soumet définitivement. ``fige`` empêche la navigation automatique de s'emballer
        sur les dizaines de ``changee`` émis au passage ; le bouton se rallume s'il reste des secondes chances."""
        if confirmer and not self._confirmer():
            return
        self.fige = True
        for f in self.feuilles:
            if not f.fermee:
                f.demarrer()
                f.soumettre()
        self.fige = False
        self.rafraichir()

    def terminer(self):
        """Fin de l'épreuve : toute question encore ouverte est figée telle quelle, sans seconde chance — le temps
        écoulé ne laisse pas de rattrapage —, puis la note et la correction s'affichent. Le chronomètre appelle ceci."""
        self.fige = True
        for f in self.feuilles:
            f.geler()
        self.fige = False
        self.fin = self.fin or time.time()
        self._montrer_fin()

    def _montrer_fin(self):
        """L'épreuve finie : tout est figé et visible, avec la correction si ``correction``."""
        for f in self.feuilles:
            f.figer()
        for q in self.questions():
            for f in (q, *q.sous_questions):
                f.montrer(True)
        if self.correction:
            for q in self.questions():
                q.montrer_correction("#c0392b")
