"""Le noyau du modèle objet de QCM/, sans Qt : les données et la logique des banques, questions, sujets et paquets.

``modele.py`` en dérive ses widgets (``class ChoixUnique(noyau.ChoixUnique, Choix)``) ; le lecteur web l'importe
seul, sous Pyodide. Tout ce qui s'affiche passe par des crochets sans effet ici, que les widgets redéfinissent :
``_dire`` (le retour sous la question), ``_montrer_enonce``, ``_montrer_indice``, ``afficher_contexte``, ``montrer``,
``mettre_a_jour`` ; pour un paquet, ``_afficher_page``, ``_defiler``, ``_rafraichir_vue``,
``_confirmer``, ``_montrer_fin`` et ``_devant``. Ce que les crochets reçoivent est aussi gardé en attributs (``dit``,
``contextes_affiches``, ``cachee``, ``numero``), qu'une interface sans widget lit directement.

La saisie de l'élève est rangée dans ``_valeur`` par ``_lire``/``_ecrire`` ; un widget les redéfinit pour la lire
dans ses champs. Voir la docstring de ``modele.py`` pour le format des fichiers.
"""

import ast
import functools
import html
import inspect
import json
import math
import random
import re
import sys
import time
import traceback
import unicodedata
from pathlib import Path

import horloge

try:
    import serializejson
except ModuleNotFoundError:
    serializejson = None
    if sys.platform != "emscripten":  # le python3 du système : ni serializejson ni qtpy6 (voir ../CLAUDE.md)
        sys.exit("serializejson introuvable : lancer avec /DATA/Python/SmartPython/CachyOS/versions/SmartPython/bin/python")

ID = re.compile(r"^[a-z0-9_]+(->[a-z0-9_]+)*$")
ACCOLADES = re.compile(r"\{([^{}\n]+)\}")
BAREMES = ("tout_ou_rien", "proportionnel", "penalite", "par_case")
DESTINATIONS = ("papier", "electronique", "tp", "projet")
RANGEMENTS = ("TP", "Révisions", "Mini-Interrogations", "DS", "Projets")  # sous-dossier d'un cours où vont les exports d'un sujet
VERT = "#00b050"  # ce qui est juste : le vert vif des cours (``VERT_REPONSE`` de texte_md ; l'utilisateur, 26/09/2026)
POLICE_MAIN = "Kalam"  # ce que la correction écrit en rouge ou en vert, à la main comme un professeur (27/09/2026)
CLASSES = {}  # nom -> classe, pour un chargeur sans serializejson ; les widgets de modele.py remplacent leur noyau
@functools.cache
def niveaux_bloom():
    """Les niveaux de ``referentiels/niveaux_bloom.json``, lus au premier bilan (le lecteur web l'embarque, ``construire.py``)."""
    return json.loads((Path(__file__).resolve().parent / "referentiels/niveaux_bloom.json").read_text(encoding="utf-8"))["niveaux"]


def niveau_bloom(verbe):
    """(rang, libellé) du niveau de Bloom que signale le verbe de la consigne, None s'il n'est dans aucun."""
    for rang, niveau in enumerate(niveaux_bloom().values()):
        if verbe in niveau["verbes"]:
            return rang, niveau["libelle"]
    return None


def rangement(tag):
    """Un tag qui range la question sans dire ce qu'elle travaille : année, source, section, forme ou TP (relevé sur les
    banques, 02/10/2026). Le bilan de l'élève ne le montre pas comme un sous-thème : « 2025 : 30 % » ne lui dit rien."""
    return (tag.isdigit() or re.fullmatch(r"tp\d*(_.*)?", tag) is not None
            or tag.lower() in {"bac", "qcm", "bonus", "parsons", "vrai-faux", "cases à cocher", "texte à trous", "cours à trous",
                               "code libre", "code à trous", "code à compléter", "code à corriger", "code à modifier"})


# Les axes du bilan d'une copie (``Paquet.statistiques``, demande de l'utilisateur, 02/10/2026) : ce qu'une question
# relève de chacun, {clé: poids}. Le poids d'une compétence du livret est le sien, les autres comptent 1 ; d'une capacité
# du programme (« thème -> capacité »), seule la capacité est montrée, le thème étant son propre axe.
AXES = [
    ("Thèmes", lambda q: {q.programme: 1} if q.programme else {}),
    ("Sous-thèmes", lambda q: dict.fromkeys([t for t in q.tags if not rangement(t)], 1)),
    ("Compétences", lambda q: dict(q.competences_livret)),
    ("Capacités du programme", lambda q: {c.split("->")[-1].strip(): 1 for c in q.capacites_programme}),
    ("Niveaux de Bloom", lambda q: {n: 1 for n in [niveau_bloom(q.verbe_action)] if n}),
    ("Pensée informatique", lambda q: dict.fromkeys(q.pensee_informatique, 1)),
]
SEUIL_FORT, SEUIL_FAIBLE = 0.75, 0.5  # trois quarts des points au moins : un point fort ; moins de la moitié : à travailler


class Evenement:
    """Les abonnés d'un ``SignalPur`` pour un objet donné, avec l'interface d'un signal Qt."""

    def __init__(self):
        self.abonnes = []

    def connect(self, fonction):
        self.abonnes.append(fonction)

    def emit(self, *args):
        for fonction in list(self.abonnes):
            fonction(*args)


class SignalPur:
    """Un signal Qt sans Qt : ``objet.changee.connect(f)``, ``objet.changee.emit()``."""

    def __set_name__(self, classe, nom):
        self.nom = "_signal_" + nom

    def __get__(self, objet, classe=None):
        if objet is None:
            return self
        if self.nom not in objet.__dict__:
            objet.__dict__[self.nom] = Evenement()
        return objet.__dict__[self.nom]


@functools.cache
def parametres(classe):
    """{nom: défaut} des paramètres d'``__init__`` de la classe et de ses ancêtres (``empty`` : obligatoire)."""
    resultat = {}
    for c in reversed(classe.__mro__):
        if "__init__" in c.__dict__:
            resultat.update({n: p.default for n, p in inspect.signature(c.__init__).parameters.items()
                             if p.kind is p.POSITIONAL_OR_KEYWORD and n != "self"})
    return resultat


def _defaut(valeur, defaut):
    return (valeur == defaut or (defaut is None and not valeur and valeur != 0)
            or (isinstance(defaut, tuple) and valeur == list(defaut)))


class Objet:
    """Base de toutes les classes : sérialisation plate, valeurs par défaut omises, ``__init__`` rappelé au chargement."""

    def __init_subclass__(cls, **kw):
        super().__init_subclass__(**kw)
        CLASSES[cls.__name__] = cls
        if serializejson:
            serializejson.constructors[cls.__name__] = cls

    def _ordre(self, etat):
        return etat

    def __serializejson__(self):
        """Les attributs qui sont des paramètres d'``__init__``, puis les paramètres qui sont des properties (la
        ``saisie`` d'une question, lue dans ses widgets) : ni l'un ni l'autre à sa valeur par défaut."""
        defauts = parametres(type(self))
        etat = {nom: valeur for nom, valeur in vars(self).items() if nom in defauts and not _defaut(valeur, defauts[nom])}
        for nom, defaut in defauts.items():
            if nom not in etat and isinstance(getattr(type(self), nom, None), property):
                valeur = getattr(self, nom)
                if not _defaut(valeur, defaut):
                    etat[nom] = valeur
        return type(self).__name__, None, self._ordre(etat)

    def __getattr__(self, nom):
        """Un objet lu sans aucun champ (tout à sa valeur par défaut) n'a pas reçu d'état : serializejson n'appelle
        alors pas ``__setstate__``. Le premier accès à un attribut l'initialise."""
        if nom.startswith("__") or vars(self) or inspect.Parameter.empty in parametres(type(self)).values():
            raise AttributeError(nom)  # des paramètres obligatoires : ce n'est pas un objet sans champ
        self.__init__()
        return getattr(self, nom)

    def __setstate__(self, etat):
        try:
            self.__init__(**etat)
        except TypeError as exc:
            raise TypeError(f"{type(self).__name__} {etat.get('id', etat.get('texte', ''))} : {exc}".replace("  ", " ")) from None


def copier(valeur, remplacer=lambda texte: texte, sauf=(), imposes=None):
    """Copie profonde d'un arbre d'objets, sans jamais partager de sous-objet (serializejson écrirait un ``$ref``) ;
    ``remplacer`` transforme chaque chaîne au passage, les champs nommés dans ``sauf`` ne sont pas copiés et ceux de
    ``imposes`` (pour la racine seulement) remplacent les copies. Un objet est reconstruit par son ``__init__`` (un
    widget ne peut pas l'être autrement) à partir de l'état que serializejson écrirait."""
    if isinstance(valeur, str):
        return remplacer(valeur)
    if isinstance(valeur, list):
        return [copier(v, remplacer, sauf) for v in valeur]
    if isinstance(valeur, dict):
        return {k: copier(v, remplacer, sauf) for k, v in valeur.items()}
    if isinstance(valeur, Objet):
        etat = {k: copier(v, remplacer, sauf) for k, v in valeur.__serializejson__()[2].items() if k not in sauf}
        return type(valeur)(**{**etat, **(imposes or {})})
    return valeur


LOGO = "logo du thème"  # le visuel du thème dans les médias ; sans extension, hors de portée des médias d'une banque
MEDIAS = {}  # nom -> octets : alimenté par Banque et Paquet (leurs questions sont construites avant eux)


def normaliser(valeur):
    """Casse, accents et espaces multiples ignorés."""
    texte = unicodedata.normalize("NFD", str(valeur).strip().lower())
    return " ".join("".join(c for c in texte if not unicodedata.combining(c)).split())


def nombre(valeur):
    """La valeur d'un texte numérique, ``None`` sinon. Virgule décimale, et un « ≈ », « ~ » ou « environ » devant,
    qu'un élève recopie du corrigé ou d'une consigne, ne changent pas le nombre."""
    try:
        return float(re.sub(r"^(≈|~|environ)\s*", "", str(valeur).strip().replace(",", ".")))
    except ValueError:
        return None


def comparable(valeur):
    """``normaliser``, plus ce qu'un élève tape sans y penser et qui ne change pas sa réponse : apostrophe
    typographique, œ, virgule décimale (« 3,5 »), espaces des milliers (« 1 024 »), ponctuation finale. C'est la
    forme sous laquelle une saisie se compare à une réponse attendue ou à une erreur listée — pas celle d'un nom
    d'élève (``normaliser`` reste la clé des graines et des codes)."""
    texte = normaliser(valeur)
    for a, b in (("’", "'"), ("‘", "'"), ("´", "'"), ("œ", "oe"), ("æ", "ae")):
        texte = texte.replace(a, b)
    if re.fullmatch(r"\d+,\d+", texte):
        texte = texte.replace(",", ".")
    if re.fullmatch(r"\d{1,3}( \d{3})+", texte):
        texte = texte.replace(" ", "")
    return texte.rstrip(" .;:") or texte


def distance(a, b):
    """Distance de Damerau-Levenshtein (alignement optimal) : lettre changée, ajoutée, retirée ou deux voisines
    échangées comptent un."""
    d = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(len(a) + 1):
        d[i][0] = i
    for j in range(len(b) + 1):
        d[0][j] = j
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] != b[j - 1]))
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[-1][-1]


def marge(reponse):
    """Fautes de frappe tolérées sur cette réponse attendue : UNE pour un mot ou une phrase d'au moins cinq
    lettres, sans chiffre ni symbole ni sigle ; AUCUNE sinon. Une valeur, du code, « HTTP » pour « HTTPS » ou
    « pile » pour « file » ne sont pas des coquilles. Deux fautes ne sont jamais tolérées : « croissant » est à deux
    lettres de « décroissant », « possible » d'« impossible » (mesuré sur les banques, 01/10/2026)."""
    n = comparable(reponse)
    if len(n) < 5 or not re.fullmatch(r"[a-z' -]+", n) or sum(c.isupper() for c in str(reponse)) >= 2:
        return 0
    return 1


def egal(saisie, reponse):
    return comparable(saisie) == comparable(reponse)


def coquille(saisie, reponses, connus=(), exact=False):
    """La saisie est-elle l'une des ``reponses`` à une faute de frappe près (``marge``) ? Jamais si ``exact`` (la
    question l'exige), si la saisie est vide, ni si une chaîne de ``connus`` — erreurs listées, choix proposés,
    réponses des autres trous de la question — est aussi proche : « aucun » pour « aucune » quand l'autre case
    attend « aucun » n'est pas une coquille, c'est l'autre réponse."""
    s = comparable(saisie)
    if exact or not s:
        return False
    acceptees = {comparable(r) for r in reponses}
    for r in reponses:
        m = marge(r)
        if m and distance(s, comparable(r)) <= m:
            return not any(distance(s, comparable(c)) <= m for c in connus if comparable(c) not in acceptees)
    return False


def indice_de(erreurs, saisie):
    """L'indice de l'erreur reconnue à l'exact dans ``saisie``, à défaut celui de « toute autre erreur »."""
    for e in erreurs:
        if e.reponse is not None and egal(e.reponse, saisie):
            return e.indice
    return next((e.indice for e in erreurs if e.reponse is None and not e.description), None)


def points_txt(p):
    return f"{p:g} point" + ("s" if p >= 2 else "")


def en_capitales(titre):
    """Le titre d'un sujet tel qu'il s'affiche en tête : en capitales, sauf les lignes qu'un retour à la ligne place
    avant la dernière, gardées telles qu'écrites (« Mini évaluation : » / « LES RÉSEAUX SOCIAUX » : demande de
    l'utilisateur, 25/09/2026)."""
    *avant, sujet = titre.split("\n")
    return "\n".join([*avant, sujet.upper()])


def melange(elements, graine):
    """Un ordre tiré d'une graine fixe (deux exports se ressemblent), jamais l'ordre d'origine."""
    elements, tires = list(elements), list(elements)
    alea = random.Random(graine)
    while len(elements) > 1 and tires == elements:
        alea.shuffle(tires)
    return tires


# --- sous-objets d'une question -------------------------------------------------------------------------------

class Proposition(Objet):
    def __init__(self, texte, correcte=False, feedback=""):
        self.texte, self.correcte, self.feedback = texte, correcte, feedback


class Test(Objet):
    """Un test de code : ``appel`` est une expression, ``attendu`` le repr() de sa valeur. En SQL, ``appel`` est une
    requête de CONTRÔLE jouée après celle de l'élève, vide pour juger le résultat de la sienne."""

    def __init__(self, appel, attendu, message=""):
        self.appel, self.attendu, self.message = appel, attendu, message


class Rectangle(Objet):
    """Zone rectangulaire d'une image, en pixels."""

    def __init__(self, x, y, largeur, hauteur):
        self.x, self.y, self.largeur, self.hauteur = x, y, largeur, hauteur

    def decrire(self):
        return f"rectangle {self.x}, {self.y}, {self.largeur}, {self.hauteur}"

    def contient(self, x, y):
        return self.x <= x <= self.x + self.largeur and self.y <= y <= self.y + self.hauteur

    def centre(self):
        return [self.x + self.largeur // 2, self.y + self.hauteur // 2]


class Cercle(Objet):
    def __init__(self, x, y, rayon):
        self.x, self.y, self.rayon = x, y, rayon

    def decrire(self):
        return f"cercle {self.x}, {self.y}, {self.rayon}"

    def contient(self, x, y):
        return (x - self.x) ** 2 + (y - self.y) ** 2 <= self.rayon ** 2

    def centre(self):
        return [self.x, self.y]


class Paire(Objet):
    def __init__(self, gauche, droite):
        self.gauche, self.droite = gauche, droite


class Element(Objet):
    """Un élément à classer, avec la catégorie où il va."""

    def __init__(self, texte, categorie):
        self.texte, self.categorie = texte, categorie


class Erreur(Objet):
    """Une erreur attendue et son indice : ``reponse`` reconnue par ``egal`` (et préférée à une coquille), ``description`` rapprochée par un LLM ;
    ni l'une ni l'autre : « toute autre erreur »."""

    def __init__(self, indice, reponse=None, description=""):
        self.indice, self.reponse, self.description = indice, reponse, description


class Indice(Objet):
    def __init__(self, texte, delai=0, malus=0):
        self.texte, self.delai, self.malus = texte, delai, malus


class Justification(Objet):
    def __init__(self, points, consigne="Justifiez votre réponse."):
        self.points, self.consigne = points, consigne


class SecondeChance(Objet):
    """Un second essai après une erreur, avec l'indice lié à l'erreur, moyennant ``malus`` (fraction des points)."""

    def __init__(self, malus=0, actif=True):
        self.malus, self.actif = malus, actif


class Trou(Objet):
    """Un trou de texte : ``reponses`` absent = correction manuelle ; ``choix`` présent = liste déroulante ; ``exact``
    refuse la faute de frappe que ``coquille`` tolère sinon (un mot-clé du langage, une valeur à recopier)."""

    def __init__(self, reponses=None, choix=None, erreurs=None, exact=False):
        self.reponses, self.choix, self.erreurs, self.exact = reponses, choix, erreurs or [], exact


class Rapport(Objet):
    """Deux cases MESURÉES d'un tableau (un temps, un compteur) qu'aucune valeur « vraie » ne peut corriger, mais dont
    le QUOTIENT, lui, est connu : « temps pour n = 2000 » sur « temps pour n = 1000 » vaut 2 pour une boucle simple, 4
    pour deux boucles imbriquées, 1 pour des divisions par 2 (idée de l'utilisateur, 02/10/2026). ``cases`` =
    [numérateur, dénominateur] ; ``attendu`` ± ``tolerance`` (un quart d'``attendu`` à défaut) juge les deux mesures
    ENSEMBLE, en une note ; ``resultat`` = la case où l'élève écrit le rapport, jugée sur SES propres mesures, au nombre
    de décimales qu'il a écrites (« 2 » comme « 2,03 » pour 2,0312…)."""

    def __init__(self, cases, attendu=None, tolerance=None, resultat=None):
        self.cases, self.attendu, self.tolerance, self.resultat = cases, attendu, tolerance, resultat

    def jugees(self):
        """Les cases que ce rapport corrige à la place du professeur."""
        return set(self.cases if self.attendu is not None else []) | ({self.resultat} if self.resultat else set())

    def accepte(self, q):
        """Le quotient ``q`` des deux mesures est-il ``attendu``, à ``tolerance`` près ?"""
        return q is not None and abs(q - self.attendu) <= (self.attendu / 4 if self.tolerance is None else self.tolerance)


class Sommet(Objet):
    """Un sommet d'une question ``dessin``, nommé et placé (en pixels) par le professeur ; l'élève n'y touche pas.
    ``marque`` : ``"initial"`` ou ``"final"``, les deux états particuliers d'un automate."""

    def __init__(self, nom, x, y, marque=""):
        self.nom, self.x, self.y, self.marque = nom, x, y, marque


class Arete(Objet):
    """Une arête attendue : « g »/« d » pour un arbre binaire, une lettre pour un automate, un poids pour un graphe
    pondéré, rien pour un graphe nu."""

    def __init__(self, source, cible, etiquette=""):
        self.source, self.cible, self.etiquette = source, cible, etiquette


class Reference(Objet):
    """Une question d'une section de sujet dont les points remplacent ceux de la banque (sinon : simple chaîne)."""

    def __init__(self, id, points):
        self.id, self.points = id, points


# --- questions ------------------------------------------------------------------------------------------------

DUREE_PAR_DIFFICULTE = {None: 45, 1: 45, 2: 90, 3: 150}  # secondes, faute de ``duree`` mesurée ; calées pour que les
# sujets déjà donnés tiennent dans leur durée (SNT réseaux sociaux : 10 questions, 10 min), à remplacer par les mesures


class Question(Objet):
    """Les champs communs à tous les types ; ``type`` (attribut de classe) est le nom historique du type.

    Chaque type définit ``juste`` (la saisie juste), ``corriger`` (``(fraction des points ou None, indice)``) et
    ``_attendu`` (la correction en Markdown) ; son widget, dans modele.py, ``_corps`` et ``_lire``/``_ecrire``.
    Les champs de session — ``saisie``, ``justifie``, ``ouverte`` (début), ``presence`` (secondes passées dessus, qui font courir le délai des indices), ``debloques``
    (indices découverts), ``aidee`` (aide affichée), ``reformulee`` (énoncé reformulé affiché), ``seconde`` (seconde chance accordée), ``fermee`` (validée, ``obtenu`` = points gagnés, ``None`` si
    elle attend le professeur), ``cochees`` (dans un projet, les actions de l'énoncé cochées, par rang) — sont
    enregistrés avec la question. ``graine`` est posée par ``instancier``."""

    type = ""
    sous_questions = ()  # ne change que pour un Groupe
    classe = ""  # posée par le paquet qui contient la question : elle fixe ce que le programme de l'élève peut employer
    autorises = None  # liste blanche propre à la question, qui remplace celle de la classe (champ de ``Code``)
    projet = False  # posée par le paquet : dans un projet, les actions de l'énoncé se cochent et ses blocs de code se copient
    changee = SignalPur()  # la question a changé d'état (soumise, validée, figée) : à enregistrer
    dit = ("", "")  # le dernier retour affiché sous la question : (Markdown, couleur)
    numero = None
    cachee = False  # masquée par le paquet (``revele``, sous-questions l'une après l'autre)
    retenue = False  # posée par le paquet (``Paquet.retenir``) : ni « Soumettre » ni Entrée, le mode de soumission l'interdit

    def __init__(self, id, enonce, points=1, difficulte=None, tags=None, programme="", fiche="", competences_livret=None,
                 capacites_programme=None, pensee_informatique=None, verbe_action="", contexte="", explication="",
                 explication_fausse="", enonce_simplifie="", aide="", aide_cours="", necessite_ordinateur=False, couleur_obligatoire=False, copiable=False, duree=None, usage="", electronique=None, revele=None, indices=None, variables=None, justification=None,
                 seconde_chance=None, graine=None, saisie=None, justifie="", ouverte=None, presence=0, debloques=0, seconde=False,
                 fermee=False, obtenu=None, repondue=False, reformulee=False, aidee=False, cochees=None, horodatage=None,
                 remarque="", justification_obtenue=None):
        self.id, self.enonce, self.points, self.difficulte = id, enonce, points, difficulte
        self.tags, self.programme, self.fiche = tags or [], programme, fiche
        self.competences_livret, self.capacites_programme = competences_livret or {}, capacites_programme or []
        self.pensee_informatique, self.verbe_action = pensee_informatique or [], verbe_action
        self.contexte, self.explication, self.necessite_ordinateur = contexte, explication, necessite_ordinateur
        self.explication_fausse, self.copiable, self.couleur_obligatoire = explication_fausse, copiable, couleur_obligatoire
        self.duree = duree  # secondes pour y répondre, estimées ; absente : ``DUREE_PAR_DIFFICULTE``
        self.usage = usage  # "formatif", "sommatif", ou "" : les deux
        self.electronique = electronique  # ce que le .qcm en change : voir ``version_electronique``
        self.revele, self.indices, self.variables = revele or [], indices or [], variables or {}
        self.justification, self.seconde_chance, self.graine = justification, seconde_chance, graine
        self.ouverte, self.presence, self.debloques, self.seconde, self.fermee, self.obtenu = ouverte, presence, debloques, seconde, fermee, obtenu
        self.repondue, self.enonce_simplifie, self.reformulee = repondue, enonce_simplifie, reformulee
        self.aide, self.aide_cours, self.aidee, self.cochees = aide, aide_cours, aidee, cochees or []  # aide_cours : la variante quand le cours est sous la main, retenue par un sujet ``acces_cours``
        self._depart, self._justifie_depart = saisie, justifie
        self.actif, self.modifiable = False, True
        self.contextes_affiches = []
        self.contextes_connus = {}  # nom -> markdown de chaque texte partagé cité, affiché ou non (``afficher_contextes``)
        self.horodatage = horodatage or []  # instants (time.time()) où l'élève a validé ou soumis : de quoi mesurer ``duree``
        # posés par la correction différée (``noter``) : le commentaire du correcteur, que l'élève lit sous la correction,
        # et les points de la justification, à part de ``obtenu`` comme ils sont à part de ``points``
        self.remarque, self.justification_obtenue = remarque, justification_obtenue

    def version_electronique(self, sans_ide=False):
        """La question telle que la pose le .qcm, quand elle diffère du papier (un TP où l'élève travaille dans son
        éditeur devient une question ``code`` dans l'éditeur du lecteur) : ``electronique`` vaut ``False`` (question
        absente du .qcm) ou un dict de champs qui remplacent les siens, ``classe`` (« Code », « ReponseOuverte »…)
        changeant le type ; les champs non remplacés sont repris quand la classe les connaît. Un TP qui a deux .qcm,
        « avec IDE » et « sans IDE », range dans ce dict une clé ``sans_ide`` : la variante (dict, ``False`` ou ``None``)
        du second, tout entier dans le lecteur, que prend un sujet à ``sans_ide``."""
        variante = self.electronique
        if sans_ide and isinstance(variante, dict) and "sans_ide" in variante:
            variante = variante["sans_ide"]
        if variante is None:
            return self
        if variante is False:
            return None
        variante = {k: v for k, v in variante.items() if k != "sans_ide"}
        classe = CLASSES[variante.pop("classe", type(self).__name__)]
        champs = parametres(classe)
        etat = {k: v for k, v in self.__serializejson__()[2].items() if k in champs and k != "electronique"}
        return classe(**copier({**etat, **variante}))

    def duree_estimee(self):
        """Secondes pour y répondre : ``duree`` si elle est posée, sinon la somme des sous-questions d'un groupe, sinon
        le forfait de sa difficulté."""
        if self.duree is None and self.sous_questions:
            return sum(sq.duree_estimee() for sq in self.sous_questions)
        return self.duree or DUREE_PAR_DIFFICULTE[self.difficulte]

    # -- affichage (crochets : les widgets de modele.py les redéfinissent)

    def reperer(self, marque):
        """Le repère de la sous-question (« a. ») en tête de son énoncé, sur la MÊME ligne : seul sur sa ligne,
        il s'éloigne de la consigne qu'il numérote. N'écrit pas dans ``enonce``, qui est la donnée enregistrée."""
        self.marque = marque
        self._montrer_enonce()

    marque = ""

    def _montrer_enonce(self):
        """L'énoncé, ou sa reformulation quand l'élève l'a demandée, derrière le repère de sous-question."""

    def reformuler(self):
        """Bascule entre l'énoncé et sa reformulation ; ``reformulee`` est enregistré avec la copie. Offert à toute la
        classe, sans malus : une aide à la lecture, qui ne change pas ce qui est évalué."""
        self.reformulee = not self.reformulee
        self._montrer_enonce()
        self.changee.emit()

    def numeroter(self, numero=None):
        """« Question n°x » au-dessus de l'énoncé."""
        self.numero = numero

    def _construire(self):
        """À la fin du ``__init__`` de chaque type, ses champs posés : la saisie et l'état de session relus."""
        self._valeur = None
        if self.sous_questions:
            return
        if self._depart is not None:
            self._ecrire(self._depart)
        self.justifie = self._justifie_depart
        if self.aidee:
            self._montrer_indice("**Aide** : " + self.aide)
        for i in self.indices[:self.debloques]:
            self._montrer_indice("**Indice** : " + i.texte)
        if self.fermee:
            self._dire("Réponse enregistrée.")
        elif self.seconde:
            self._dire("Seconde chance : " + (self.corriger(self.saisie)[1] or ""))
        self.mettre_a_jour()

    def afficher_contexte(self, markdown):
        """Sous « Question n°x », jamais au-dessus : hors du bloc numéroté, un texte partagé se lit comme la fin de
        la question PRÉCÉDENTE (QCM Algorithmique, questions 99, 126 et 132)."""
        self.contextes_affiches.insert(0, markdown)

    def contextes_cites(self):
        """Les textes partagés que la question ouvre, dans l'ordre de lecture : ``contexte`` est un nom, ou
        plusieurs quand la question ajoute son introduction propre à une figure déjà citée par ses voisines."""
        if not self.contexte:
            return []
        return [self.contexte] if isinstance(self.contexte, str) else list(self.contexte)

    sans_execution = False  # posé par le paquet : voir DefinitionSujet

    _trou_corrige = None  # pour un texte à trous : comment écrire un trou dans la correction

    def _dire(self, markdown, couleur=""):
        self.dit = (markdown, couleur)

    def _montrer_indice(self, markdown, tete=False):
        """Une aide (``tete`` : en premier) ou un indice découvert, sous la question."""

    def mettre_a_jour(self):
        """Ce qui est actif, visible et écrit sur les boutons, selon l'état de la question."""

    def montrer(self, visible):
        self.cachee = not visible

    def feuilles(self):
        """Les questions à noter : elle-même, ou les sous-questions d'un groupe."""
        return [self]

    def total(self):
        """Justification comprise : elle est notée en plus de la réponse, et à la main."""
        return self.points + (self.justification.points if self.justification else 0)

    # -- la saisie de l'élève

    @property
    def saisie(self):
        return None if self.sous_questions else self._lire()

    @saisie.setter
    def saisie(self, valeur):
        if not self.sous_questions:
            self._ecrire(valeur)

    def _lire(self):
        return self._valeur

    def _ecrire(self, valeur):
        self._valeur = valeur

    @property
    def justifie(self):
        return self._justifie if self.justification else ""

    @justifie.setter
    def justifie(self, texte):
        self._justifie = texte

    def chance(self):
        return self.seconde_chance if self.seconde_chance and self.seconde_chance.actif else None

    devinable = False  # la réponse se choisit parmi des options données : le hasard y rapporte
    MALUS_DEVINABLE = 0.5

    def reponse_forcee(self):
        """Après une erreur, il ne reste qu'une réponse possible : une seconde chance la donnerait."""
        return False

    def adapter_chance(self, chance):
        """La seconde chance du SUJET, ajustée au hasard : aucune là où elle donnerait la réponse (Vrai/Faux), au
        moins −50 % là où l'on choisit parmi des options (à −25 %, répondre au hasard y devient rentable), telle quelle là
        où la réponse se saisit. Une ``seconde_chance`` écrite sur la question elle-même n'y passe pas."""
        if not chance or not chance.actif or not self.devinable:
            return chance
        return SecondeChance(actif=False) if self.reponse_forcee() else SecondeChance(max(chance.malus, self.MALUS_DEVINABLE))

    def garder_une_aide(self, acces_cours):
        """Le sujet dit si les élèves ont le cours : une seule aide reste, l'``aide_cours`` s'ils l'ont (à défaut l'aide)."""
        self.aide, self.aide_cours = (self.aide_cours or self.aide) if acces_cours else self.aide, ""

    def indice_delai(self):
        """Secondes avant le prochain indice (0 : déblocable), ou ``None`` s'il n'y en a plus."""
        if self.debloques >= len(self.indices):
            return None
        return max(0, self.indices[self.debloques].delai - self.presence) \
            if self.indices[self.debloques].delai else 0

    def demarrer(self):
        """La question est posée : ses champs deviennent modifiables."""
        if self.sous_questions or self.actif:
            return
        self.actif = True
        if self.ouverte is None:
            self.ouverte = time.time()
        self.mettre_a_jour()

    def figer(self):
        """Plus aucune modification, sans changer l'état de la question."""
        for f in self.feuilles():
            f.actif = False
            f.mettre_a_jour()

    def aider(self):
        """L'aide, gratuite et offerte à tous : une piste pour démarrer (méthode, rappel de cours), jamais la réponse ;
        ``aidee`` est enregistré avec la copie."""
        if self.aide and not self.aidee:
            self.aidee = True
            self._montrer_indice("**Aide** : " + self.aide, tete=True)
            self.mettre_a_jour()
            self.changee.emit()

    def debloquer(self):
        if self.indice_delai() == 0:
            self._montrer_indice("**Indice** : " + self.indices[self.debloques].texte)
            self.debloques += 1
            self.mettre_a_jour()
            self.changee.emit()

    def complete(self):
        """La réponse est entière : quelque chose de saisi, et aucune case laissée vide dans une liste (classement,
        appariement)."""
        saisie = self.saisie
        return saisie is not None and not (isinstance(saisie, list) and None in saisie)

    def quitter(self):
        """L'élève passe à une autre question : celle-ci devient « traitée » si sa réponse est entière (``complete``),
        sans bouton ni correction ; revenue incomplète, elle ne l'est plus. La navigation « Non traitée » la saute alors
        (demande de l'utilisateur, 28/09/2026 : le bouton « Marquer comme traitée » déduit de l'activité de l'élève)."""
        traitee = self.actif and not self.fermee and self.complete()
        if traitee != self.repondue:
            self.repondue = traitee
            self.horodatage.append(round(time.time(), 1))
            self.mettre_a_jour()
            self.changee.emit()

    def soumettre(self):
        """Corrige la réponse : une seconde chance si elle est fausse et permise, sinon la question est close. ``retenue``
        n'y est pas regardée : elle cache « Soumettre » et coupe Entrée, pas « Corriger mes réponses » qui passe par ici."""
        if self.fermee or not self.actif:
            return
        fraction, indice = self.corriger(self.saisie)
        self.horodatage.append(round(time.time(), 1))
        chance = self.chance()
        if chance and not self.seconde and fraction is not None and fraction < 1:
            self.seconde = True
            # les points encore à gagner, pas ceux perdus (demande de l'utilisateur, 28/09/2026)
            prix = f", pour {points_txt(round(self.points * max(0, 1 - self.malus()), 2))}" if self.points else ""
            # en rouge comme une correction, la seconde chance en vert (demandes de l'utilisateur, 26/09/2026)
            self._dire(f"**Ce n'est pas la bonne réponse.** {indice or ''}\n\n"
                       f'<span style="color:{VERT}">Vous pouvez réessayer{prix}.</span>', "#c0392b")
        else:
            self._clore(fraction)
            # sans console, l'élève découvre l'erreur de son programme ici : brute tant qu'il peut réessayer, expliquée ensuite
            self._dire("\n\n".join(filter(None, ["Réponse enregistrée.", self.sans_execution and self._diagnostic()])))
        self.mettre_a_jour()
        self.changee.emit()

    def geler(self):
        """Fige la réponse telle qu'elle est, sans seconde chance (la question est révélée, ou l'épreuve finie)."""
        if not self.fermee:
            self._clore(self.corriger(self.saisie)[0])
            self.mettre_a_jour()
            self.changee.emit()

    def malus(self):
        """La fraction des points retirée par les indices débloqués et la seconde chance jouée."""
        return sum(i.malus for i in self.indices[:self.debloques]) + (self.chance().malus if self.seconde and self.chance() else 0)

    def _clore(self, fraction):
        self.obtenu = None if fraction is None else round(self.points * max(0, fraction - self.malus()), 2)
        self.fermee = True

    def rouvrir(self):
        """Revenir sur une réponse validée (``retour``), sauf si la seconde chance a été jouée."""
        if self.fermee and not self.seconde and self.modifiable:
            self.fermee, self.obtenu = False, None
            self._dire("")
            self.mettre_a_jour()
            self.changee.emit()

    def noter(self, fraction=None, remarque=None, trou=None, justification=False):
        """La fraction retenue par le professeur pour ce que la machine n'a pas su noter (correction différée) : posée
        sur la feuille, qui recalcule ``obtenu`` par sa propre règle (``_clore`` : le malus une seule fois ; un trou
        refait la moyenne de tous les trous). Rejouable : la même fusion redonne le même état."""
        if justification:
            self.justification_obtenue = round(self.justification.points * fraction, 2)
        elif trou is not None:
            self.retenus[str(trou)] = fraction  # les clés de ``trous`` sont des chaînes
            self._clore(self.corriger(self.saisie)[0])
        else:
            self._clore(fraction)
        if remarque:
            ligne = ("Justification : " if justification else f"Trou {trou} : " if trou is not None else "") + remarque
            if ligne not in self.remarque.split("\n"):
                self.remarque = "\n".join(filter(None, [self.remarque, ligne]))

    # -- la correction

    def juste(self):
        """La saisie juste."""
        raise NotImplementedError

    def corriger(self, saisie):
        """``(fraction des points, indice)`` : fraction ``None`` si la réponse n'est pas corrigeable par la machine."""
        raise NotImplementedError

    def _attendu(self):
        return ""

    def montrer_correction(self, couleur=""):
        """La correction (réponse attendue, remarques, explication) sous la question, de la ``couleur`` donnée ; la saisie de l'élève reste."""
        for f in self.feuilles():
            attendu = f._attendu()
            f._dire("\n\n".join(filter(None, [f._diagnostic(), f"**Correction**\n\n{attendu}" if attendu else "", f.explication,
                                                f.explication_fausse,
                                                # un paragraphe par item : un simple \n se lirait en espace
                                                "**Remarque du correcteur**\n\n" + f.remarque.replace("\n", "\n\n")
                                                if f.remarque else ""])), couleur)

    def _diagnostic(self):
        """Dans la correction seulement : ce que la saisie a de faux, au-delà de la réponse attendue."""
        return ""

    def confirmer(self):
        """Bonne réponse : une confirmation en vert, avec l'explication s'il y en a une."""
        self._dire("\n\n".join(filter(None, ["**Bonne réponse !**", self.explication])), VERT)

    def presenter_corrige(self):
        """Comme dans une banque : la bonne réponse saisie, la correction dessous, plus rien de modifiable."""
        self.saisie = self.juste()
        self.montrer_correction("#c0392b")
        self.figer()

    # -- fabrication

    def instancier(self, graine, heritees=None, points=None):
        """La question avec ses ``variables`` tirées de la graine, ses ``{expressions}`` remplacées dans tous ses textes
        (sous-questions comprises, qui héritent des variables du groupe), sa ``graine`` propre pour les mélanges et, si
        ``points`` est donné, ces points (un groupe n'en a pas : c'est la somme de ses sous-questions).
        Une accolade dont le contenu n'est pas une expression citant une variable est laissée telle quelle : ``{.rouge}``
        de Pandoc, dictionnaires du code Python."""
        alea = random.Random(graine)
        espace = {"randint": alea.randint, "randrange": alea.randrange, "uniform": alea.uniform, "choice": alea.choice,
                  "sample": alea.sample, "melange": lambda elements: alea.sample(list(elements), len(elements))}
        valeurs = dict(heritees or {})
        for nom, expression in self.variables.items():
            valeurs[nom] = eval(expression, {**espace, **valeurs})
        espace.update(valeurs)

        def remplacer(m):
            try:
                noms = {n.id for n in ast.walk(ast.parse(m.group(1), mode="eval")) if isinstance(n, ast.Name)}
            except SyntaxError:
                return m.group(0)
            return str(eval(m.group(1), espace)) if noms & valeurs.keys() else m.group(0)

        imposes = {"graine": graine}
        if self.sous_questions:
            imposes["sous_questions"] = [sq.instancier(f"{graine}|{sq.id}", valeurs) for sq in self.sous_questions]
        elif points is not None:
            imposes["points"] = points
        return copier(self, lambda texte: ACCOLADES.sub(remplacer, texte), sauf=("sous_questions", "saisie"), imposes=imposes)

    def problemes(self):
        """[(niveau, message)] : ce que la classe ne peut pas empêcher (niveau « erreur » ou « avert »)."""
        p = []
        for sans_ide in (False, True) if self.electronique not in (None, False) else ():
            try:
                variante = self.version_electronique(sans_ide)
            except (KeyError, TypeError) as exc:
                p.append(("erreur", f"electronique : {exc}"))
            else:
                p += [(niveau, "electronique : " + message) for niveau, message in variante.problemes()] if variante else []
        if not ID.match(self.id):
            p.append(("erreur", f"identifiant « {self.id} » : minuscules, chiffres et _, mots séparés par ->"))
        if not self.enonce:
            p.append(("erreur", "énoncé vide"))
        if (self.aide or self.aide_cours) and self.sous_questions:
            p.append(("erreur", "aide : un groupe n'a pas de bouton « Aide », la mettre sur ses sous-questions"))
        if self.aide_cours and not self.aide:
            p.append(("avert", "aide_cours sans aide : un sujet sans acces_cours n'aura pas d'aide du tout"))
        if self.enonce_simplifie and self.enonce_simplifie.split() == self.enonce.split():
            p.append(("avert", "enonce_simplifie : identique à l'énoncé, le bouton « Reformuler » n'y changerait rien"))
        if not self.points > 0:
            p.append(("erreur", "points : strictement positifs"))
        if self.difficulte not in (None, 1, 2, 3):
            p.append(("erreur", "difficulte : 1, 2 ou 3"))
        if self.duree is not None and not self.duree > 0:
            p.append(("erreur", "duree : secondes, strictement positive"))
        if self.id in self.revele:
            p.append(("erreur", "révèle sa propre réponse"))
        if len(set(self.revele)) != len(self.revele):
            p.append(("erreur", "revele : identifiants en double"))
        if any(a.delai > b.delai for a, b in zip(self.indices, self.indices[1:])):
            p.append(("erreur", "indices : les délais doivent aller croissant"))
        if sum(i.malus for i in self.indices) > 1:
            p.append(("erreur", "indices : la somme des malus dépasse 1 (tous les points)"))
        if self.chance() and self.reponse_forcee():
            p.append(("avert", "seconde_chance : après une erreur il ne reste qu'une réponse, le second essai la donne"))
        if len(self.indices) > 1 or any(i.malus != 0.5 or i.delai < 30 for i in self.indices):  # convention, pas une impossibilité
            p.append(("avert", "indices : la convention est un seul indice, à −50 % (malus 0.5) après au moins 30 secondes "
                               "(delai 30) ; ce qui aide sans donner la réponse va dans aide, gratuite"))
        for ou, reponses, erreurs in [("", getattr(self, "reponses", None), getattr(self, "erreurs", []))] + [
                (f"trou {n}, ", trou.reponses, trou.erreurs) for n, trou in getattr(self, "trous", {}).items()]:
            attendues = {str(r).strip().lower() for r in reponses or []}
            for e in erreurs:
                if e.reponse is not None and str(e.reponse).strip().lower() in attendues:
                    p.append(("erreur", f"{ou}erreur « {e.reponse} » qui est une réponse acceptée"))
                if e.reponse is not None and self.type in ("reponse_ouverte", "code"):
                    p.append(("erreur", f"erreur « {e.reponse} » : pas de réponse exacte pour ce type, utiliser description"))
            if sum(e.reponse is None and not e.description for e in erreurs) > 1:
                p.append(("erreur", f"{ou}plusieurs erreurs sans reponse ni description (une seule « toute autre erreur »)"))
        return p

    def _ordre(self, etat):
        communs = parametres(Question)
        tete = {k: etat[k] for k in ("id", "enonce", "enonce_simplifie") if k in etat}  # la reformulation se relit sous l'énoncé
        return {**tete, **{k: v for k, v in etat.items() if k not in communs}, **{k: v for k, v in etat.items() if k in communs and k not in tete}}


class Alternative(Question):
    type = "alternative"

    devinable = True

    def reponse_forcee(self):
        return True

    def __init__(self, id, enonce, reponse, libelles=("Vrai", "Faux"), **commun):
        super().__init__(id, enonce, **commun)
        self.reponse, self.libelles = reponse, list(libelles)
        self._construire()

    def juste(self):
        return self.reponse

    def corriger(self, saisie):
        return (1 if saisie == self.reponse else 0), None

    def _attendu(self):
        return self.libelles[0 if self.reponse else 1]

    def problemes(self):
        return super().problemes() + ([("erreur", "libelles : exactement deux")] if len(self.libelles) != 2 else [])


class Choix(Question):
    """Base de ChoixUnique et ChoixMultiples : ``saisie`` = indices (de ``propositions``, non mélangées) des cases cochées."""

    devinable = True

    def reponse_forcee(self):
        return self.type == "choix_unique" and len(self.propositions) <= 2

    def __init__(self, id, enonce, propositions, melanger=True, **commun):
        super().__init__(id, enonce, **commun)
        self.propositions, self.melanger = propositions, melanger

    def correctes(self):
        return sum(1 for p in self.propositions if p.correcte)

    def _cochees(self):
        return [i for i, b in enumerate(self.boutons) if b.isChecked()]

    def _feedbacks(self, indices):
        return "\n\n".join(self.propositions[i].feedback for i in indices if self.propositions[i].feedback) or None

    def _attendu(self):
        justes = "\n".join(f"- {p.texte}" for p in self.propositions if p.correcte)
        remarques = "\n".join(f"- {p.texte} : {p.feedback}" for p in self.propositions if p.feedback)
        return justes + ("\n\n" + remarques if remarques else "")

    def problemes(self):
        return super().problemes() + ([("erreur", "au moins deux propositions")] if len(self.propositions) < 2 else [])


class ChoixUnique(Choix):
    type = "choix_unique"

    EXCLUSIF = True

    def __init__(self, id, enonce, propositions, melanger=True, **commun):
        super().__init__(id, enonce, propositions, melanger, **commun)
        self._construire()

    def juste(self):
        return next(i for i, p in enumerate(self.propositions) if p.correcte)

    def corriger(self, saisie):
        if saisie is None:
            return 0, None
        return (1 if self.propositions[saisie].correcte else 0), self._feedbacks([saisie])

    def problemes(self):
        return super().problemes() + ([("erreur", f"choix_unique doit avoir exactement 1 proposition correcte, {self.correctes()} trouvée(s)")]
                                      if self.correctes() != 1 else [])


class ChoixMultiples(Choix):
    type = "choix_multiples"

    EXCLUSIF = False

    def __init__(self, id, enonce, propositions, bareme="tout_ou_rien", melanger=True, **commun):
        super().__init__(id, enonce, propositions, melanger, **commun)
        self.bareme = bareme
        self._construire()

    def juste(self):
        return [i for i, p in enumerate(self.propositions) if p.correcte]

    def corriger(self, saisie):
        """tout_ou_rien : toutes les bonnes cases et aucune autre ; proportionnel : la part des propositions bien traitées
        (cochée à juste titre ou laissée à juste titre) ; penalite : une case fausse retire ce que rapporte une juste ;
        par_case : idem, mais une case correcte laissée vide coûte aussi — une copie blanche gagnerait alors les cases
        justement vides, d'où le 0 imposé quand rien n'est coché."""
        coches, bonnes = set(saisie or []), {i for i, p in enumerate(self.propositions) if p.correcte}
        justes, fausses = len(coches & bonnes), coches - bonnes
        if self.bareme == "proportionnel":
            fraction = (len(self.propositions) - len(coches ^ bonnes)) / len(self.propositions)
        elif self.bareme == "penalite":
            fraction = max(0, justes - len(fausses)) / len(bonnes)
        elif self.bareme == "par_case":
            n = len(self.propositions)
            fraction = max(0, n - 2 * len(coches ^ bonnes)) / n if coches else 0
        else:
            fraction = 1 if coches == bonnes else 0
        return fraction, (self._feedbacks(sorted(fausses)) if fraction < 1 else None)

    def problemes(self):
        return (super().problemes() + ([("erreur", "aucune proposition correcte")] if not self.correctes() else [])
                + ([("erreur", f"bareme « {self.bareme} » : {', '.join(BAREMES)}")] if self.bareme not in BAREMES else []))


COMPARAISONS = ("texte", "valeur", "liste", "ensemble")  # ``ReponseCourte.comparaison``
ILLISIBLE = object()  # ce que rend ``valeur_saisie`` d'un texte qui n'est pas une valeur Python


def valeur_saisie(texte, comparaison):
    """La valeur Python d'une réponse courte (``ast.literal_eval``) ; en ``liste`` et ``ensemble``, la liste de ses
    éléments, crochets facultatifs (« 3, 1, 2 » comme « [3, 1, 2] », « 3 » comme « [3] »). ``ILLISIBLE`` sinon."""
    try:
        v = ast.literal_eval(str(texte).strip())
    except (ValueError, TypeError, SyntaxError, MemoryError, RecursionError):
        return ILLISIBLE
    if comparaison == "valeur":
        return v
    return list(v) if isinstance(v, (list, tuple)) else [v]


def meme_valeur(a, b):
    """``a == b`` sans confondre ``True`` et ``1`` ni une liste et un tuple, à toute profondeur."""
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return type(a) is type(b) and len(a) == len(b) and all(map(meme_valeur, a, b))
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(meme_valeur(a[k], b[k]) for k in a)
    if isinstance(a, bool) or isinstance(b, bool):
        return a is b
    return a == b


def note_ensemble(saisis, attendus):
    """Barème ``penalite`` sur les éléments : un juste rapporte 1/n, un faux en retire autant, plancher 0 ; ordre et
    doublons ignorés."""
    distincts = []
    for x in saisis:
        if not any(meme_valeur(x, y) for y in distincts):
            distincts.append(x)
    justes = sum(any(meme_valeur(x, y) for y in attendus) for x in distincts)
    return max(0, justes - (len(distincts) - justes)) / len(attendus) if attendus else 0


class ReponseCourte(Question):
    type = "reponse_courte"

    def __init__(self, id, enonce, reponses, tolerance=None, erreurs=None, exact=False, comparaison="texte", **commun):
        super().__init__(id, enonce, **commun)
        self.reponses, self.tolerance, self.erreurs, self.exact = reponses, tolerance, erreurs or [], exact
        # « texte » : la comparaison souple de toujours ; sinon saisie et réponses lues comme des valeurs Python
        # (``valeur_saisie``), « ensemble » noté élément par élément
        self.comparaison = comparaison
        self._construire()

    def juste(self):
        return str(self.reponses[0])

    def accepte(self, saisie, reponse):
        a, b = nombre(saisie), nombre(reponse)
        if self.tolerance is not None and a is not None and b is not None:
            return abs(a - b) <= self.tolerance
        return egal(saisie, reponse)

    def corriger(self, saisie):
        """1 pour une réponse acceptée, ou à une coquille près (``coquille`` : jamais si une erreur listée est aussi
        proche, ni si ``exact``) ; sinon 0 et l'indice de l'erreur reconnue."""
        saisie = saisie or ""
        if self.comparaison != "texte":
            v = valeur_saisie(saisie, self.comparaison)
            if v is ILLISIBLE:
                return 0, indice_de(self.erreurs, saisie)
            attendus = [valeur_saisie(r, self.comparaison) for r in self.reponses]
            if self.comparaison == "ensemble":
                note = max(note_ensemble(v, a) for a in attendus)
            else:
                note = int(any(meme_valeur(v, a) for a in attendus))
            return note, None if note == 1 else indice_de(self.erreurs, saisie)
        if any(self.accepte(saisie, r) for r in self.reponses) or coquille(saisie, self.reponses, [e.reponse for e in self.erreurs if e.reponse is not None], self.exact):
            return 1, None
        return 0, indice_de(self.erreurs, saisie)

    def _attendu(self):
        return " ou ".join(f"`{r}`" for r in self.reponses) + (f" (tolérance ± {self.tolerance:g})" if self.tolerance is not None else "")

    def problemes(self):
        p = super().problemes() + ([("erreur", "reponses : au moins une")] if not self.reponses else [])
        if self.comparaison not in COMPARAISONS:
            p.append(("erreur", f"comparaison « {self.comparaison} » : une de {', '.join(COMPARAISONS)}"))
        elif self.comparaison != "texte":
            p += [("erreur", f"comparaison {self.comparaison} : la réponse « {r} » n'est pas une valeur Python")
                  for r in self.reponses if valeur_saisie(r, self.comparaison) is ILLISIBLE]
            if self.tolerance is not None:
                p.append(("erreur", "tolerance : sans effet hors de la comparaison texte"))
        return p


class ReponseOuverte(Question):
    type = "reponse_ouverte"

    def __init__(self, id, enonce, corrige, mots_cles=None, lignes=5, erreurs=None, console=False, **commun):
        super().__init__(id, enonce, **commun)
        self.corrige, self.mots_cles, self.lignes, self.erreurs = corrige, mots_cles or [], lignes, erreurs or []
        self.console = console  # l'interpréteur interactif de Python au-dessus de la réponse (le widget du type code, sans éditeur)
        self._construire()

    def juste(self):
        return self.corrige

    def corriger(self, saisie):
        return None, None  # corrigée à la main

    def _attendu(self):
        return self.corrige + (f"\n\nMots-clés : {', '.join(self.mots_cles)}" if self.mots_cles else "")


def trou_juste(trou, texte, connus=()):
    """Le texte saisi est-il l'une des réponses attendues du trou, ou l'une d'elles à une coquille près (``coquille``,
    qui s'abstient devant un ``connus`` aussi proche) ?"""
    return any(egal(texte, r) for r in trou.reponses) or coquille(texte, trou.reponses, connus, trou.exact)


def connus_du_trou(trous, n, choix=None):
    """Ce qui, écrit dans le trou ``n``, n'est PAS une coquille d'une de ses réponses : ses erreurs listées, les choix
    proposés (les siens ou ceux de la question), et les réponses attendues des autres trous."""
    trou = trous[n]
    return ([e.reponse for e in trou.erreurs if e.reponse is not None] + list(trou.choix or choix or [])
            + [r for m, t in trous.items() if m != n for r in t.reponses or []])


def quotient(numerateur, denominateur):
    a, b = nombre(numerateur), nombre(denominateur)
    return a / b if a is not None and b else None


def arrondi_pareil(texte, valeur):
    """Le texte saisi est-il ``valeur`` arrondie, ou tronquée, au nombre de décimales qu'il porte ? « 2 », « 2,0 » et
    « 2,03 » valent 2,0312 ; « 2,1 » non. À une demi-unité près, inclus : 2,025 s'arrondit à « 2,02 » comme à « 2,03 »,
    selon qu'on calcule ou qu'on lit. Tronqué seulement avec des décimales (« 2,03 » pour 2,036) : « 2 » pour 2,9, non."""
    n = nombre(texte)
    if n is None or valeur is None:
        return False
    decimales = len(str(texte).strip().replace(",", ".").partition(".")[2])
    pas = 10 ** -decimales
    return abs(n - valeur) <= pas / 2 + pas / 1e6 or (decimales > 0 and abs(n - math.floor(valeur / pas) * pas) < pas / 1e6)


def corriger_trous(trous, saisie, distinctes=None, retenus=None, rapports=None, choix=None):
    """La fraction et l'indice d'un ensemble de ``Trou`` remplis : moyenne des trous corrigibles, ``None`` si tous
    sont relevés (``reponses`` absent). Partagée par ``TexteATrous`` et ``Tableau``, dont c'est la même correction.
    ``distinctes`` : des groupes de trous dont les réponses doivent être deux à deux DIFFÉRENTES. « Proposer deux
    adresses » n'est pas deux questions indépendantes — chaque réponse y est juste isolément, c'est leur ÉGALITÉ
    qui est fausse, et une correction trou par trou ne peut pas la voir.
    ``retenus`` : {numéro: fraction} retenues par le professeur (correction différée), qui comptent pour ces trous,
    relevés ou refusés par la comparaison exacte.
    ``rapports`` : des ``Rapport`` entre cases mesurées, qui notent ce qu'aucune valeur attendue ne peut noter.
    ``choix`` : la banque de mots commune de la question, parmi ce que ``coquille`` ne doit pas rapprocher."""
    saisie, retenus = saisie or {}, retenus or {}
    fautifs = set()
    for groupe in distinctes or []:
        memes = {}
        for n in groupe:
            texte = normaliser(saisie.get(n, ""))
            if texte:
                memes.setdefault(texte, []).append(n)
        fautifs |= {n for pareils in memes.values() if len(pareils) > 1 for n in pareils}
    notes, indice = [], None
    for n, trou in trous.items():
        if n in retenus:
            notes.append(retenus[n])
            continue
        if trou.reponses is None:
            continue  # relevé, à corriger à la main
        juste = trou_juste(trou, saisie.get(n, ""), connus_du_trou(trous, n, choix)) and n not in fautifs
        notes.append(juste)
        indice = indice or (None if juste else indice_de(trou.erreurs, saisie.get(n, "")))
    if fautifs and not indice:
        indice = "Deux réponses qui doivent différer sont identiques."
    for rapport in rapports or []:
        q = quotient(*(saisie.get(n, "") for n in rapport.cases))
        if rapport.attendu is not None:
            juste = rapport.accepte(q)
            notes.append(juste)
            indice = indice or (None if juste else "Le rapport entre les deux mesures n'est pas celui qu'on attend.")
        if rapport.resultat and rapport.resultat not in retenus:
            juste = arrondi_pareil(saisie.get(rapport.resultat, ""), q)
            notes.append(juste)
            indice = indice or (None if juste else "Le rapport écrit n'est pas le quotient des deux valeurs mesurées.")
    return (sum(notes) / len(notes) if notes else None), indice


def solution_trous(trous, distinctes=None, rapports=None):
    """La réponse attendue : la première réponse de chaque trou corrigible, les trous relevés omis. Dans un groupe
    de ``distinctes``, les trous acceptent souvent la MÊME liste de réponses (deux adresses prises dans le même
    sous-réseau) : chacun prend alors la première encore libre, sinon la solution proposée serait celle que la
    correction refuse. La case ``resultat`` d'un ``Rapport`` montre le rapport attendu (« ≈ 2 »), ou celui des
    réponses attendues de ses deux cases (compteurs : 1999 / 999) ; ses mesures restent relevées."""
    solution = {n: str(t.reponses[0]) for n, t in trous.items() if t.reponses}
    for rapport in rapports or []:
        attendu = rapport.attendu if rapport.attendu is not None else quotient(*(solution.get(n, "") for n in rapport.cases))
        if rapport.resultat and attendu is not None:
            solution[rapport.resultat] = f"≈ {attendu:.3g}".replace(".", ",")
    for groupe in distinctes or []:
        prises = set()
        for n in groupe:
            trou = trous.get(n)
            libre = next((r for r in (trou.reponses or []) if normaliser(r) not in prises), None) if trou else None
            if libre is not None:
                solution[n] = str(libre)
                prises.add(normaliser(libre))
    return solution


def problemes_trous(trous, choix_communs, quoi="trou", jugees=()):
    """Les contrôles d'un ensemble de ``Trou``, communs au texte à trous et au tableau ; ``jugees`` = les trous sans
    réponse attendue qu'un ``Rapport`` corrige quand même."""
    p = []
    for n, trou in trous.items():
        choix = trou.choix or choix_communs
        if trou.reponses is None and n not in jugees:
            p.append(("avert", f"{quoi} {n} sans réponse attendue, correction manuelle"))
        elif choix and not set(trou.reponses) & set(choix):
            p.append(("erreur", f"{quoi} {n}, aucune réponse ne figure dans la liste de choix"))
    return p


class TexteATrous(Question):
    """``saisie`` = {numéro de trou: texte saisi ou choisi}."""

    type = "texte_a_trous"

    MARQUEUR = re.compile(r"\[\[(\d+)\]\]")

    def __init__(self, id, enonce, texte, trous, choix=None, retenus=None, **commun):
        super().__init__(id, enonce, **commun)
        self.texte, self.trous, self.choix = texte, trous, choix
        self.retenus = retenus or {}  # {numéro: fraction} posées par ``noter`` (correction différée)
        self.devinable = bool(choix) or any(t.choix for t in trous.values())  # listes déroulantes
        self._construire()

    def juste(self):
        return solution_trous(self.trous)

    def corriger(self, saisie):
        return corriger_trous(self.trous, saisie, retenus=self.retenus, choix=self.choix)

    def trou_juste(self, n, texte):
        """Pour ceux qui corrigent un trou à part (correction à l'écran, lot différé) : la même règle que ``corriger``."""
        return trou_juste(self.trous[n], texte, connus_du_trou(self.trous, n, self.choix))

    def complete(self):
        return len(self.saisie or {}) == len(self.trous)

    def _attendu(self):
        return self.texte

    def _trou_corrige(self, n):
        """Le mot attendu à la place du trou : en vert si l'élève l'avait, en rouge sinon (correction)."""
        trou, saisie = self.trous[n], self._lire() or {}
        if trou.reponses is None:
            return f"<b>{html.escape(saisie.get(n, '…'))}</b>"
        juste = self.trou_juste(n, saisie.get(n, ""))
        # 11,7 pt sur ce corps de 10 (a_l_echelle) = 14 pt à l'écran, comme modele.TAILLE_MAIN : Kalam, à corps égal,
        # a des lettres basses (x-height) plus petites que la police du sujet (27/09/2026). « font-size:» sans espace,
        # sinon a_l_echelle ne le reconnaît pas (le trou restait à 10,8 pt jusqu'au 28/09/2026)
        return (f'<span style="color: {VERT if juste else "#c0392b"}; font-family: {POLICE_MAIN}; font-size:11.7pt">'
                f'{html.escape(str(trou.reponses[0]))}</span>')

    def problemes(self):
        p = super().problemes()
        marqueurs, trous = set(self.MARQUEUR.findall(self.texte)), set(self.trous)
        if marqueurs != trous:
            p.append(("erreur", f"marqueurs {sorted(marqueurs)} ≠ trous déclarés {sorted(trous)}"))
        return p + problemes_trous(self.trous, self.choix)


class Tableau(Question):
    """``saisie`` = {"ligne,colonne": texte saisi ou choisi} ; les cases à remplir sont des ``Trou``, comme un texte à trous.

    ``colonnes`` est la ligne d'en-têtes et ``lignes`` la grille telle qu'elle s'affiche (liste de listes de Markdown).
    Une case dont la référence ``"ligne,colonne"`` (numérotées à partir de 0, en-têtes non comptés) figure dans
    ``cellules`` est à remplir : ce qu'en dit ``lignes`` est alors ignoré. Les autres sont données. Un chronogramme
    s'écrit ainsi : une colonne par instant, une ligne par signal, des cellules à ``choix = ["0", "1"]``.

    ``distinctes`` = les groupes de cases dont les réponses doivent être deux à deux DIFFÉRENTES, par exemple
    ``[["0,1", "1,1"]]`` pour « proposer deux adresses IP » : sans cette contrainte, la même adresse écrite deux
    fois serait comptée juste deux fois, chaque case étant corrigée isolément.

    ``rapports`` = les ``Rapport`` entre cases mesurées (temps, compteurs d'une question de complexité) : la case du
    numérateur sur celle du dénominateur doit valoir ``attendu`` à ``tolerance`` près, et la case ``resultat`` où
    l'élève écrit ce rapport doit être le quotient de ses propres mesures. Ce sont les seules cases sans ``reponses``
    que la machine corrige.

    ``lignes_libres`` : l'élève ajoute lui-même ses lignes (« autant de lignes que nécessaire »). ``lignes`` porte la
    grille ATTENDUE ; l'élève en voit les ``minimum`` premières (par défaut, jusqu'à la première ligne qui a une case à
    remplir, incluse) et en fait paraître une de plus à chaque « + ligne », sans savoir combien il en faut. Une ligne
    écrite au-delà de la grille coûte autant qu'une ligne manquante, comme une arête en trop d'un ``dessin`` ; ses
    cases à remplir sont celles de la dernière ligne, et une case donnée y prolonge la numérotation des deux dernières
    (« Étape » 5, 6 → 7, 8), ou reste vide (``donnee``)."""

    type = "tableau"

    REFERENCE = re.compile(r"^(\d+),(\d+)$")

    def __init__(self, id, enonce, colonnes, lignes, cellules, choix=None, distinctes=None, rapports=None,
                 lignes_libres=False, minimum=None, **commun):
        super().__init__(id, enonce, **commun)
        self.colonnes, self.lignes, self.cellules, self.choix = colonnes, lignes, cellules, choix
        self.distinctes, self.rapports = distinctes, rapports
        self.lignes_libres, self.minimum = lignes_libres, minimum
        self._construire()

    def juste(self):
        return solution_trous(self.cellules, self.distinctes, self.rapports)

    def montrees(self):
        """Les lignes affichées d'emblée, avant tout « + ligne »."""
        if not self.lignes_libres:
            return len(self.lignes)
        if self.minimum is not None:
            return self.minimum
        return next((r for r in range(len(self.lignes)) if self.cases_de_ligne(r)), len(self.lignes) - 1) + 1

    def donnee(self, r, c):
        """Le texte donné de la case ``r,c`` ; au-delà de la grille, un nombre entier qui prolonge les deux dernières
        lignes, ou rien."""
        if r < len(self.lignes):
            return self.lignes[r][c]
        entiers = [int(t) for t in (str(l[c]).strip() for l in self.lignes[-2:]) if re.fullmatch(r"-?\d+", t)]
        return str(entiers[1] + (entiers[1] - entiers[0]) * (r - len(self.lignes) + 1)) if len(entiers) == 2 else ""

    def cases_de_ligne(self, r):
        """Les colonnes à remplir de la ligne ``r`` ; au-delà de la grille attendue, celles de sa dernière ligne."""
        r = min(r, len(self.lignes) - 1)
        return [c for c in range(len(self.colonnes)) if f"{r},{c}" in self.cellules]

    def lignes_ecrites(self, saisie):
        """Le nombre de lignes de la saisie : jusqu'à la dernière où quelque chose est écrit, ``montrees`` au moins."""
        ecrites = [int(n.split(",")[0]) for n, t in (saisie or {}).items() if str(t).strip() and self.REFERENCE.match(n)]
        return max([self.montrees(), *(r + 1 for r in ecrites)])

    def corriger(self, saisie):
        fraction, indice = corriger_trous(self.cellules, saisie, self.distinctes, rapports=self.rapports, choix=self.choix)
        if not self.lignes_libres or fraction is None:
            return fraction, indice
        en_trop = sum(len(self.cases_de_ligne(r)) for r in range(len(self.lignes), self.lignes_ecrites(saisie)))
        if not en_trop:
            return fraction, indice
        notes = (sum(t.reponses is not None for t in self.cellules.values())
                 + sum((r.attendu is not None) + bool(r.resultat) for r in self.rapports or []))
        return fraction * notes / (notes + en_trop), indice or "Le tableau a plus de lignes qu'il n'en faut."

    def trou_juste(self, n, texte):
        """Une case corrigée à part, par la même règle que ``corriger``."""
        return trou_juste(self.cellules[n], texte, connus_du_trou(self.cellules, n, self.choix))

    def jugees(self):
        """Les cases sans ``reponses`` qu'un ``Rapport`` corrige quand même."""
        return set().union(*(r.jugees() for r in self.rapports or []))

    def manuelles(self):
        """Les cases qui restent au professeur : relevées, et dans aucun ``Rapport``."""
        return {n for n, t in self.cellules.items() if t.reponses is None} - self.jugees()

    def complete(self):
        if not self.lignes_libres:
            return len(self.saisie or {}) == len(self.cellules)
        saisie = self.saisie or {}  # toutes les cases des lignes que l'élève a ouvertes, et pas une de plus
        return all(saisie.get(f"{r},{c}") for r in range(self.lignes_ecrites(saisie)) for c in self.cases_de_ligne(r))

    def case(self, r, c, corrige=False):
        """Le contenu Markdown d'une case : le texte donné, ou la réponse attendue si ``corrige``, ou un blanc."""
        trou = self.cellules.get(f"{min(r, len(self.lignes) - 1)},{c}")
        if trou is None:
            return self.donnee(r, c)
        if not corrige or r >= len(self.lignes):
            return ""
        return self.juste().get(f"{r},{c}", "(relevé)")

    def _attendu(self):
        entetes = "| " + " | ".join(str(e) for e in self.colonnes) + " |"
        tiret = "|" + "---|" * len(self.colonnes)
        corps = [("| " + " | ".join(self.case(r, c, corrige=True) for c in range(len(self.colonnes))) + " |")
                 for r in range(len(self.lignes))]
        return "\n".join([entetes, tiret, *corps])

    def problemes(self):
        p = super().problemes()
        largeur = len(self.colonnes)
        for r, ligne_ in enumerate(self.lignes):
            if len(ligne_) != largeur:
                p.append(("erreur", f"ligne {r} : {len(ligne_)} cases pour {largeur} colonnes"))
        if not self.cellules:
            p.append(("erreur", "tableau sans aucune case à remplir"))
        if self.lignes_libres:
            if self.minimum is not None and not 1 <= self.minimum <= len(self.lignes):
                p.append(("erreur", f"minimum {self.minimum} : entre 1 et {len(self.lignes)}, les lignes de la grille attendue"))
            for r in range(self.montrees(), len(self.lignes)):
                if not self.cases_de_ligne(r):  # cachée tant que l'élève ne l'ouvre pas : ce qu'elle donne lui manquerait
                    p.append(("erreur", f"lignes_libres : la ligne {r}, cachée d'abord, n'a aucune case à remplir"))
            if not self.cases_de_ligne(len(self.lignes) - 1):
                p.append(("erreur", "lignes_libres : la dernière ligne, modèle des lignes ajoutées, n'a aucune case à remplir"))
        elif self.minimum is not None:
            p.append(("avertissement", "minimum sans lignes_libres : ignoré"))
        for reference in self.cellules:
            m = self.REFERENCE.match(str(reference))
            if not m or not (int(m[1]) < len(self.lignes) and int(m[2]) < largeur):
                p.append(("erreur", f"cellule {reference} : hors de la grille {len(self.lignes)}×{largeur}"))
        for groupe in self.distinctes or []:
            if len(groupe) < 2:
                p.append(("erreur", f"distinctes {groupe} : une contrainte porte sur au moins deux cases"))
            for reference in groupe:
                if reference not in self.cellules:
                    p.append(("erreur", f"distinctes : la case {reference} n'est pas à remplir"))
        for rapport in self.rapports or []:
            if len(rapport.cases) != 2 or (rapport.attendu is None and not rapport.resultat):
                p.append(("erreur", f"rapport {rapport.cases} : deux cases (numérateur, dénominateur), et un attendu ou une case résultat"))
            for reference in [*rapport.cases, *([rapport.resultat] if rapport.resultat else [])]:
                if reference not in self.cellules:
                    p.append(("erreur", f"rapport : la case {reference} n'est pas à remplir"))
            if rapport.resultat in self.cellules and self.cellules[rapport.resultat].reponses is not None:
                p.append(("erreur", f"rapport : la case {rapport.resultat} a déjà ses réponses, elle serait jugée deux fois"))
            if rapport.attendu is not None and all(self.cellules.get(n) and self.cellules[n].reponses for n in rapport.cases):
                q = quotient(*(self.cellules[n].reponses[0] for n in rapport.cases))
                if not rapport.accepte(q):
                    p.append(("erreur", f"rapport {rapport.cases} : les réponses attendues des deux cases donnent {q}, pas {rapport.attendu}"))
        return p + problemes_trous(self.cellules, self.choix, "cellule", self.jugees())


def code_nu(texte):
    """Un élément écrit en Markdown (```` `x = 1` ````) rendu tel qu'il s'exécute, indentation comprise."""
    return texte[1:-1] if len(texte) > 1 and texte.startswith("`") and texte.endswith("`") else texte


class Ordre(Question):
    """``saisie`` = indices des ``elements`` (dans le bon ordre) dans l'ordre où l'élève les a rangés.

    ``langage`` vide : les éléments sont des étiquettes à glisser dans une liste. ``langage = "python"`` : ce sont
    des lignes de code, remises dans l'ordre DANS l'éditeur Python lui-même, où elles arrivent sans indentation
    (sinon les niveaux trahiraient l'ordre) : l'élève les indente aussi, et la saisie devient
    ``{"ordre": [...], "niveaux": [...]}`` (le niveau de chaque ligne, dans l'ordre rangé), jugée sur les deux. Une
    saisie en simple liste (ancienne copie, lecteur qui montre l'indentation) ne juge que l'ordre. Le texte n'est
    pas modifiable ; ``executable`` donne à l'élève la console pour essayer son rangement."""

    type = "ordre"

    devinable = True

    def __init__(self, id, enonce, elements, langage="", executable=False, **commun):
        super().__init__(id, enonce, **commun)
        self.elements, self.langage, self.executable = elements, langage, executable
        self.depart = melange(range(len(self.elements)), self.graine)
        self._construire()

    def juste(self):
        return list(range(len(self.elements)))

    def niveaux_justes(self):
        return [(len(code_nu(e)) - len(code_nu(e).lstrip(" "))) // 4 for e in self.elements]

    def corriger(self, saisie):
        if isinstance(saisie, dict):
            return int(saisie["ordre"] == self.juste() and saisie["niveaux"] == self.niveaux_justes()), None
        return (1 if (self.depart if saisie is None else saisie) == self.juste() else 0), None

    def _attendu(self):
        """Les accents graves n'entourent que du code : sans ``langage``, les éléments sont des étiquettes en
        français, et les accents graves s'y liraient tels quels là où la correction n'est pas rendue en Markdown."""
        return "\n".join(f"{n}. " + (f"`{code_nu(e)}`" if self.langage else e) for n, e in enumerate(self.elements, 1))

    def problemes(self):
        """``executable`` promet un bouton « Exécuter » qui marche : les lignes, remises dans le bon ordre, doivent
        donc former un programme valide — sans quoi l'élève n'obtiendrait qu'une erreur de syntaxe, quoi qu'il range."""
        p = super().problemes()
        if self.executable and self.langage != "python":
            p.append(("erreur", "executable sans langage python : rien à exécuter"))
        elif self.executable:
            try:
                compile("\n".join(code_nu(e) for e in self.elements), self.id, "exec")
            except SyntaxError as exc:
                p.append(("erreur", f"executable, mais les lignes dans le bon ordre ne compilent pas : "
                                    f"{exc.msg} (ligne {exc.lineno})"))
        return p


class Appariement(Question):
    """``saisie`` = pour chaque élément de gauche, l'indice de son élément de droite (``paires`` puis ``distracteurs``), ou ``None``."""

    type = "appariement"

    devinable = True

    def __init__(self, id, enonce, paires, distracteurs=None, **commun):
        super().__init__(id, enonce, **commun)
        self.paires, self.distracteurs = paires, distracteurs or []
        self._construire()

    def juste(self):
        return list(range(len(self.paires)))

    def corriger(self, saisie):
        saisie = saisie or [None] * len(self.paires)
        return sum(saisie[i] == i for i in range(len(self.paires))) / len(self.paires), None

    def _attendu(self):
        return "\n".join(f"- {p.gauche} → {p.droite}" for p in self.paires)

    def problemes(self):
        gauches = [p.gauche for p in self.paires]
        return super().problemes() + ([("erreur", "éléments de gauche en double")] if len(gauches) != len(set(gauches)) else [])


class PointSelection(Question):
    """``saisie`` = [x, y], en pixels de l'image d'origine."""

    type = "point_selection"

    def __init__(self, id, enonce, image, zones, **commun):
        super().__init__(id, enonce, **commun)
        self.image, self.zones = image, zones
        self._construire()

    def juste(self):
        return self.zones[0].centre()

    def corriger(self, saisie):
        return (1 if saisie and any(z.contient(*saisie) for z in self.zones) else 0), None

    def _attendu(self):
        return "Zones attendues, en pixels : " + "; ".join(z.decrire() for z in self.zones)

    def problemes(self):
        return super().problemes() + ([("avert", "seconde_chance sans effet, pas d'indice possible sur une sélection de point")]
                                      if self.seconde_chance and self.seconde_chance.actif else [])


class Dessin(Question):
    """``saisie`` = [[source, cible, étiquette], …] : les arêtes tracées par l'élève entre des sommets que le
    professeur a NOMMÉS ET PLACÉS. C'est ce qui rend la correction possible sans comparer deux graphes à un
    isomorphisme près : les arêtes se comparent en ensembles. Un arbre binaire est le cas où les étiquettes sont
    « g » et « d », un automate celui où les sommets portent une ``marque`` et les arêtes les lettres de l'alphabet,
    un circuit logique celui où les sommets sont des portes nommées.
    ``decor`` : des arêtes DONNÉES, tracées en gris clair et que l'élève ne peut ni créer ni effacer. C'est ce qui
    permet de demander un chemin dans un réseau déjà tracé, ou la suite d'un arbre dont le début est fourni."""

    type = "dessin"

    def __init__(self, id, enonce, sommets, aretes=None, oriente=False, etiquettes=None, image="", decor=None,
                 mode="aretes", chemins=None, parcours=None, **commun):
        super().__init__(id, enonce, **commun)
        self.sommets, self.aretes, self.oriente = sommets, aretes or [], oriente
        self.etiquettes, self.image, self.decor = etiquettes or [], image, decor or []
        # ``mode`` « chemin » : l'élève clique des sommets dans l'ordre, ``saisie`` = [nom, …]. Les ordres acceptés sont
        # ``chemins`` (énumérés), ou ``parcours`` = {type: largeur | profondeur, depart}, vérifié sur le graphe du
        # ``decor`` : tous les ordres valides passent sans qu'on les écrive. Crédit : le plus long début juste.
        self.mode, self.chemins, self.parcours = mode, chemins or [], parcours
        self._construire()

    def juste(self):
        if self.mode == "chemin":
            return [str(n) for n in self.chemins[0]] if self.chemins else self._un_parcours()
        return [[a.source, a.cible, a.etiquette] for a in self.aretes]

    # -- mode « chemin »

    def voisins(self):
        """Le graphe du ``decor`` : nom -> voisins, dans l'ordre du décor ; noms en texte, comme la saisie."""
        graphe = {str(s.nom): [] for s in self.sommets}
        for a in self.decor:
            graphe.setdefault(str(a.source), []).append(str(a.cible))
            if not self.oriente:
                graphe.setdefault(str(a.cible), []).append(str(a.source))
        return graphe

    def _un_parcours(self):
        """Un ordre de ``parcours`` valide, voisins pris dans l'ordre du décor : celui du corrigé et de ``--auto``."""
        graphe, depart = self.voisins(), str((self.parcours or {}).get("depart"))
        if depart not in graphe:
            return []
        if self.parcours.get("type") == "largeur":
            ordre = [depart]
            for u in ordre:
                ordre += [v for v in graphe[u] if v not in ordre]
            return ordre
        ordre = []

        def visiter(u):
            ordre.append(u)
            for v in graphe[u]:
                if v not in ordre:
                    visiter(v)
        visiter(depart)
        return ordre

    def debut_de_parcours(self, saisie):
        """La longueur du plus long début de ``saisie`` qui suit un parcours valide, et celle d'un parcours complet.
        Largeur : les voisins non encore vus du sommet en tête de file arrivent ensemble, dans n'importe quel ordre.
        Profondeur (récursive) : chaque sommet est un voisin non vu du plus profond sommet qui en a encore."""
        graphe, depart = self.voisins(), str(self.parcours.get("depart"))
        attendu = len(self._un_parcours())
        if not saisie or saisie[0] != depart:
            return 0, attendu
        vus, n = [depart], 1
        if self.parcours.get("type") == "largeur":
            for u in vus:
                a_voir = list(dict.fromkeys(v for v in graphe.get(u, []) if v not in vus))
                while a_voir and n < len(saisie) and saisie[n] in a_voir:
                    a_voir.remove(saisie[n])
                    vus.append(saisie[n])
                    n += 1
                if a_voir:
                    break
            return n, attendu
        pile = [depart]
        while n < len(saisie) and pile:
            while pile and not [v for v in graphe.get(pile[-1], []) if v not in vus]:
                pile.pop()
            if not pile or saisie[n] not in graphe.get(pile[-1], []) or saisie[n] in vus:
                break
            vus.append(saisie[n])
            pile.append(saisie[n])
            n += 1
        return n, attendu

    def _corriger_chemin(self, saisie):
        saisie = [str(s) for s in saisie or []]
        if self.parcours:
            n, attendu = self.debut_de_parcours(saisie)
            return n / max(attendu, len(saisie), 1)
        notes = [0]
        for chemin in self.chemins:
            chemin = [str(s) for s in chemin]
            n = next((i for i, (a, b) in enumerate(zip(chemin, saisie)) if a != b), min(len(chemin), len(saisie)))
            notes.append(n / max(len(chemin), len(saisie), 1))
        return max(notes)

    def cle(self, source, cible, etiquette=""):
        """La forme comparable d'une arête : non orientée, les deux bouts sont interchangeables."""
        bouts = (source, cible) if self.oriente else tuple(sorted((str(source), str(cible))))
        return (*bouts, normaliser(etiquette))

    def corriger(self, saisie):
        """Une arête en trop coûte autant qu'une arête manquante : sinon, tout relier vaudrait la note maximale. Un
        chemin trop long est divisé par sa longueur : sinon, poursuivre au hasard après la fin ne coûterait rien."""
        if self.mode == "chemin":
            return self._corriger_chemin(saisie), None
        restantes, justes = [self.cle(a.source, a.cible, a.etiquette) for a in self.aretes], 0
        attendues = len(restantes)
        tracees = [self.cle(*a) for a in (saisie or [])]
        for cle in tracees:
            if cle in restantes:
                restantes.remove(cle)
                justes += 1
        return (max(0, (justes - (len(tracees) - justes)) / attendues) if attendues else None), None

    def _attendu(self):
        if self.mode == "chemin":
            if self.parcours:
                nom = {"largeur": "en largeur", "profondeur": "en profondeur"}.get(self.parcours.get("type"), "")
                return f"Un parcours {nom} depuis {self.parcours.get('depart')}, par exemple : " + " → ".join(map(str, self.juste()))
            return "\n".join("- " + " → ".join(map(str, c)) for c in self.chemins)
        fleche = "→" if self.oriente else "—"
        return "\n".join(f"- {a.source} {fleche} {a.cible}" + (f" ({a.etiquette})" if a.etiquette else "")
                         for a in self.aretes)

    def problemes(self):
        p = super().problemes()
        noms = [s.nom for s in self.sommets]
        if len(set(noms)) != len(noms):
            p.append(("erreur", "deux sommets portent le même nom : les arêtes ne désigneraient rien de sûr"))
        if self.mode not in ("aretes", "chemin"):
            p.append(("erreur", f"mode « {self.mode} » : aretes ou chemin"))
        elif self.mode == "chemin":
            if bool(self.chemins) == bool(self.parcours):
                p.append(("erreur", "mode chemin : chemins OU parcours, l'un des deux"))
            for c in self.chemins:
                p += [("erreur", f"chemin : sommet « {n} » inconnu") for n in c if n not in noms]
            if self.parcours:
                if self.parcours.get("type") not in ("largeur", "profondeur"):
                    p.append(("erreur", "parcours : type largeur ou profondeur"))
                if self.parcours.get("depart") not in noms:
                    p.append(("erreur", f"parcours : départ « {self.parcours.get('depart')} » inconnu"))
                if not self.decor:
                    p.append(("erreur", "parcours : il se vérifie sur le graphe du decor, qui est vide"))
            if self.aretes or self.etiquettes:
                p.append(("avert", "mode chemin : aretes et etiquettes sans effet"))
        elif not self.aretes:
            p.append(("erreur", "aucune arête attendue, la question ne peut pas être corrigée"))
        for a in self.decor:
            if a.source not in noms or a.cible not in noms:
                p.append(("erreur", f"décor {a.source}-{a.cible} : sommet inconnu"))
        for a in self.aretes + self.decor:
            if a.source == a.cible:  # la toile n'en trace pas, l'élève ne peut donc pas la poser (choix du 24/09/2026)
                p.append(("erreur", f"arête {a.source}-{a.cible} : une boucle ne se dessine pas"))
        for a in self.aretes:
            if a.source not in noms or a.cible not in noms:
                p.append(("erreur", f"arête {a.source}-{a.cible} : sommet inconnu"))
            elif self.etiquettes and a.etiquette not in [str(e) for e in self.etiquettes]:
                p.append(("erreur", f"arête {a.source}-{a.cible} : l'étiquette « {a.etiquette} » n'est pas proposée à l'élève"))
        for s in self.sommets:
            if s.marque not in ("", "initial", "final"):
                p.append(("erreur", f"sommet {s.nom} : marque « {s.marque} » inconnue (initial, final ou rien)"))
        if self.seconde_chance and self.seconde_chance.actif:
            p.append(("avert", "seconde_chance sans effet, pas d'indice possible sur un dessin"))
        return p


MARQUE_A_COMPLETER = re.compile(r"^( *)(.*?) *# à compléter *$")  # la même que celle du papier (exporter_pdf.py)


def zones_du_gabarit(fixes, texte):
    """Les intervalles (début, fin) de ``texte`` où l'élève a écrit, si ``texte`` garde dans l'ordre et mot pour mot
    chacune des parties ``fixes`` (``Code.gabarit``) ; ``None`` s'il en a touché une."""
    m = re.fullmatch("(.*?)".join(re.escape(f) for f in fixes), texte, re.DOTALL)
    return [m.span(k) for k in range(1, len(fixes))] if m else None


class Code(Question):
    """``saisie`` = le code écrit ; corrigé par ``verifier.verifier_question`` (un sous-processus par question)."""

    type = "code"

    def __init__(self, id, enonce, solution, langage="python", code_initial="", tests=None, tests_code="", fichier="",
                 lignes=10, erreurs=None, autorises=None, editeur_externe=False, lien="", prelude="", verrouille=False,
                 **commun):
        super().__init__(id, enonce, **commun)
        self.solution, self.langage, self.code_initial, self.tests = solution, langage, code_initial, tests or []
        # le code supposé disponible, que l'élève ne voit pas : exécuté avant le sien, à la correction comme dans la
        # console (« @contexte » : les blocs de code des textes partagés que la question cite) ; en sql, un script rejoué
        # après ``base``. ``verrouille`` : seules les lignes « # à compléter » de ``code_initial`` s'écrivent à l'écran
        self.prelude, self.verrouille = prelude, verrouille
        self.tests_code, self.fichier, self.lignes, self.erreurs = tests_code, fichier, lignes, erreurs or []
        self.autorises = autorises
        # le code s'écrit hors du lecteur (Pyxel Studio…), et l'énoncé le dit : ni éditeur ni console à l'écran
        self.editeur_externe = editeur_externe
        # champ de session : le lien du projet Pyxel Studio, donné à la première de ces questions (``premiere_externe``,
        # posée par le paquet) ; à chaque soumission, son app.py devient la saisie (``modele.Code._rapatrier``)
        self.lien, self.premiere_externe = lien, None
        self._corrections = {}  # (saisie, classe) -> correction : un sous-processus par appel, et on en fait plusieurs
        if self.type == "code":  # mesuré : sans cela, un Sql rouvert en seconde chance corrige sur une base vide,
            self._construire()     # « no such table », car _construire corrige AVANT que Sql n'ait posé self.base

    def juste(self):
        return self.solution

    def prelude_source(self):
        """Le code du prélude tel qu'il s'exécute : « @contexte » devient les blocs ``` de son langage pris dans les
        textes partagés que la question cite, dans l'ordre où elle les cite."""
        if self.prelude.strip() != "@contexte":
            return self.prelude
        blocs = (m.group(1) for texte in self.contextes_connus.values()
                 for m in re.finditer(rf"^```{self.langage}[ \t]*\n(.*?)^```", texte, re.MULTILINE | re.DOTALL))
        return "\n".join(blocs)

    def script_base(self):
        """Le jeu de données sur lequel tourne le code : rien hors SQL (``Sql.script_base``)."""
        return ""

    def gabarit(self):
        """Le code donné d'une question ``verrouille``, découpé en ses parties fixes : l'élève écrit entre deux
        parties consécutives, et nulle part ailleurs. Une ligne « # à compléter » garde fixes son retrait et le début
        de ligne qui précède la marque (« return »), suivi d'une espace ; le reste de la ligne, et toutes les lignes que
        l'élève y ajoute, sont à lui. ``None`` sans aucune marque."""
        fixes, courant = [], []
        for ligne in self.code_initial.split("\n"):
            m = MARQUE_A_COMPLETER.match(ligne)
            if m:
                courant.append(m.group(1) + (m.group(2) + " " if m.group(2) else ""))
                fixes.append("\n".join(courant))
                courant = [""]  # la zone se termine au saut de la ligne suivante, qui commence la partie fixe d'après
            else:
                courant.append(ligne)
        return fixes + ["\n".join(courant)] if fixes else None

    def vierge(self):
        """Le texte que l'éditeur montre avant toute frappe : ``code_initial``, ou, verrouillé, ses zones vides."""
        gabarit = self.gabarit() if self.verrouille else None
        return "".join(gabarit) if gabarit else self.code_initial

    def corriger(self, saisie):
        cle = (saisie, self.classe)
        if cle not in self._corrections:
            self._corrections[cle] = self._verifier(saisie)
        return self._corrections[cle]

    def testee(self):
        """Faux : sans test, la question reste au professeur."""
        return bool(self.tests or self.tests_code)

    def _verifier(self, saisie):
        import tempfile  # noqa: PLC0415 - seulement ici : verifier.py importe modele côté professeur
        from pathlib import Path  # noqa: PLC0415

        from verifier import verifier_question  # noqa: PLC0415
        if not self.testee():
            return None, None
        with tempfile.TemporaryDirectory() as dossier:
            (Path(dossier) / (self.fichier or "tp.py")).write_text(saisie if saisie is not None else self.code_initial, encoding="utf-8")
            r = verifier_question(self, dossier, "tp.py", classe=self.classe)
        return r["obtenus"] / self.points, ("\n\n".join(r["messages"]) or None)

    def _diagnostic(self):
        """Le message d'erreur de Python traduit et expliqué (erreurs_python.py) : jamais avant la soumission, où
        l'élève n'a que le message brut."""
        from erreurs_python import expliquer  # noqa: PLC0415

        source = self.code_initial if self.saisie is None else self.saisie
        if self.langage != "python" or source == self.solution:
            return ""
        return expliquer(self.corriger(self.saisie)[1], source)

    def _attendu(self):
        tests = "\n".join(f"- `{t.appel}` → `{t.attendu}`" for t in self.tests)
        return f"```{self.langage}\n{self.solution.rstrip()}\n```" + (f"\n\n{tests}" if tests else "")

    def problemes(self):
        p = super().problemes()
        if not self.tests and not self.tests_code:
            p.append(("avert", "code sans tests, correction manuelle seulement"))
        if self.code_initial and self.code_initial == self.solution:
            p.append(("erreur", "code_initial identique à la solution"))
        if self.verrouille:
            gabarit = self.gabarit()
            if gabarit is None:
                p.append(("erreur", "verrouille sans aucune ligne « # à compléter » : l'élève n'aurait rien où écrire"))
            elif not zones_du_gabarit(gabarit, self.solution):
                p.append(("erreur", "verrouille : la solution ne reprend pas mot pour mot le code donné hors des lignes "
                                    "« # à compléter » (retrait et début de ligne compris)"))
        if self.prelude.strip() == "@contexte" and not self.prelude_source().strip():
            p.append(("erreur", f"prelude « @contexte » : aucun bloc ```{self.langage} dans les contextes cités"))
        elif self.prelude and self.langage == "python":
            try:
                compile(self.prelude_source(), "<prelude>", "exec")
            except SyntaxError as exc:
                p.append(("erreur", f"prelude, ligne {exc.lineno} : erreur de syntaxe ({exc.msg})"))
        return p


class Sql(Code):
    """``saisie`` = la requête écrite ; corrigée en l'EXÉCUTANT sur ``base``, jamais en comparant son texte.

    ``base`` est le script ``CREATE TABLE … ; INSERT …`` du jeu de données, en TEXTE : la banque reste un JSON
    diffable, et ``medias`` ne transporte de toute façon que des images. Chaque ``Test`` rejoue ce script dans une
    base neuve en mémoire, si bien qu'un test ne subit pas l'état laissé par le précédent : un ``appel`` vide juge
    le résultat de la requête de l'élève, un ``appel`` non vide est une requête de CONTRÔLE jouée après elle, ce qui
    note aussi un INSERT, un UPDATE ou un DELETE. ``attendu`` est le ``repr()`` de la liste de tuples attendue ;
    l'ordre des lignes est indifférent sauf si ``ordonne``, et les colonnes se comparent par position, donc les
    alias sont libres mais un ``SELECT *`` à la place des colonnes demandées est refusé."""

    type = "sql"

    def __init__(self, id, enonce, solution, base, tests=None, ordonne=False, langage="sql", fichier="requete.sql",
                 lignes=6, afficher_base=True, **commun):
        # ``langage`` est redéclaré pour que son défaut soit « sql » ici : sans cela il serait écrit dans le JSON
        # (différent du défaut de Code), puis relu dans ``commun`` — et passé deux fois à Code au rechargement.
        super().__init__(id, enonce, solution, langage=langage, tests=tests, fichier=fichier, lignes=lignes, **commun)
        # ``base`` : le script, ou le nom d'un script des ``bases`` de la banque (``bases_connues``, posées par la banque
        # ou le paquet, ``poser_bases``) ; ``afficher_base`` faux : le papier ne l'imprime pas, l'énoncé montre le schéma
        self.base, self.ordonne, self.afficher_base, self.bases_connues = base, ordonne, afficher_base, {}
        self._construire()

    def script_base(self):
        return self.bases_connues.get(self.base, self.base)

    def _attendu(self):
        tests = "\n".join(f"- {'résultat' if not t.appel.strip() else f'`{t.appel}`'} → `{t.attendu}`" for t in self.tests)
        return f"```{self.langage}\n{self.solution.rstrip()}\n```" + (f"\n\n{tests}" if tests else "")

    def problemes(self):
        import sqlite3  # noqa: PLC0415 - seulement ici, pour éprouver le script de la base

        p = super().problemes()
        if re.fullmatch(r"[\w-]+", self.base.strip()) and self.base not in self.bases_connues:  # un nom, pas un script
            p.append(("erreur", f"base « {self.base} » absente des bases de la banque"))
            return p
        if not self.script_base().strip():
            p.append(("erreur", "sql sans base : la requête n'aurait rien sur quoi tourner"))
            return p
        try:
            sqlite3.connect(":memory:").executescript(self.script_base())
        except sqlite3.Error as exc:
            p.append(("erreur", f"base : {type(exc).__name__} : {exc}"))
        if self.tests_code:
            p.append(("erreur", "sql : tests_code est du Python, sans effet ici ; écrire des tests"))
        return p


class Classement(Question):
    """``saisie`` = pour chaque élément (dans l'ordre de ``elements``), l'indice de la catégorie choisie, ou ``None``."""

    type = "classement"

    devinable = True

    def __init__(self, id, enonce, categories, elements, **commun):
        super().__init__(id, enonce, **commun)
        self.categories, self.elements = categories, elements
        self.depart = melange(range(len(self.elements)), self.graine)
        self._construire()

    def juste(self):
        return [self.categories.index(e.categorie) for e in self.elements]

    def corriger(self, saisie):
        saisie = saisie or [None] * len(self.elements)
        return sum(s == j for s, j in zip(saisie, self.juste())) / len(self.elements), None

    def _attendu(self):
        return "\n".join(f"- **{c}** : " + ", ".join(e.texte for e in self.elements if e.categorie == c) for c in self.categories)

    def problemes(self):
        p, utilisees = super().problemes(), {e.categorie for e in self.elements}
        p += [("erreur", f"catégorie « {c} » absente de categories") for c in sorted(utilisees - set(self.categories))]
        return p + [("avert", f"catégorie « {c} » sans aucun élément") for c in sorted(set(self.categories) - utilisees)]


CHIFFRES = "0123456789ABCDEF"
NOM_BASE = {2: "binaire", 10: "décimal", 16: "hexadécimal"}
INDICE_BASE = {2: "₂", 10: "₁₀", 16: "₁₆"}
EXPOSANT = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")
SUFFIXE_BASE = re.compile(r"(?:[₀-₉]+|_\d+|\(\d+\))$")  # « 199₁₀ », « 199_10 », « 199(10) » : la base écrite derrière
TERME = re.compile(r"([0-9A-F]+)[×X*]([0-9]+)(?:\^|\*\*)([0-9]+)")  # « 1×2⁶ » (exposant ramené à « ^6 »), « 14*16**1 »
METHODES = {"binaire": {(10, 16), (16, 10)}, "ponderation": {(2, 10), (16, 10)}, "polynomial": {(2, 10), (16, 10)}, "soustractions": {(10, 2)}, "divisions": {(10, 2), (10, 16)},
            "paquets": {(2, 16), (16, 2)}}
METHODE_PAR_DEFAUT = {(2, 10): "ponderation", (16, 10): "ponderation", (10, 2): "soustractions", (10, 16): "divisions",
                      (2, 16): "paquets", (16, 2): "paquets"}
NOM_METHODE = {"binaire": "via binaire", "ponderation": "pondération", "polynomial": "développement polynomial", "soustractions": "soustractions successives",
               "divisions": "divisions successives", "paquets": "paquets de 4 bits"}
GAUCHE = -1  # abscisse du bord gauche de la colonne des étiquettes, dans un ``plan`` de conversion
# les couleurs des tableaux du cours (« Conversions de nombres », NSI Première)
BLEU_DONNEE, VERT_RESULTAT, GRIS_ENTETE, NOIR_BANDEAU = "#00b0f0", "#00b050", "#d9d9d9", "#0d0d0d"
VERT_FOIS, BLEU_SOUSTRACTION, VERT_LECTURE = "#92d050", "#41719c", "#66c71f"


def en_base(n, base):
    texte = ""
    while True:
        n, r = divmod(n, base)
        texte = CHIFFRES[r] + texte
        if not n:
            return texte


def chiffres_propres(texte, signes="=+"):
    """Ce que l'élève a écrit, débarrassé de ce qui ne compte pas : espaces, casse, signe de notation (« = 71 », « + 64 »,
    « -128 » d'une soustraction), base écrite derrière (« 199₁₀ »), préfixe Python (« 0b », « 0x »)."""
    texte = SUFFIXE_BASE.sub("", re.sub(r"\s", "", str(texte or "")).upper()).lstrip(signes)
    return texte[2:] if texte[:2] in ("0B", "0X") else texte


def valeur_en_base(texte, base, signes="=+"):
    try:
        return int(chiffres_propres(texte, signes), base)
    except ValueError:
        return None


class Conversion(Question):
    """Une conversion de nombre posée selon une méthode du cours, étape par étape : l'élève remplit les cases du tableau
    de la méthode, et chaque case est corrigée (la fraction des points est la part des cases justes). ``saisie`` =
    {clé de case: texte}. Le corrigé se calcule à partir de ``nombre`` : rien n'est à écrire case par case.

    ``nombre`` est écrit dans la base ``de`` (« 11000111 », « C7 », « 199 ») et converti vers la base ``vers`` ;
    ``methode`` (déduite des deux bases si elle est absente) : ``ponderation`` (2 ou 16 → 10), ``polynomial`` (2 ou
    16 → 10, le polynôme posé terme à terme : « 1×2⁶ », puis sa valeur), ``soustractions``
    (10 → 2), ``divisions`` (10 → 2 ou 16, divisions successives), ``paquets`` (2 ↔ 16, paquets de 4 bits), ``binaire``
    (10 ↔ 16 « via binaire » : les deux tableaux du cours enchaînés en un, soustractions puis paquets, ou paquets puis
    pondération), ou ``choix``
    quand l'énoncé n'en impose aucune : l'élève choisit parmi celles qui valent pour les deux bases (``methodes``), et
    ``saisie["methode"]`` porte son choix ; à défaut, c'est la méthode par défaut (demande de l'utilisateur, 01/10/2026).
    ``chiffres`` : le nombre de colonnes (8 pour un octet), à défaut celui qu'il faut. ``puissances_donnees`` : la ligne
    des puissances en décimales est donnée au lieu d'être à remplir. ``nombre_donne`` (soustractions) : faux, la case du
    nombre décimal est à remplir, quand la question précédente du groupe le fait calculer (2⁸ − |x| du complément à 2) —
    l'afficher donnerait sa réponse (choix de l'utilisateur, 02/10/2026).

    Les flèches du cours (×2 entre les puissances, du reste à la soustraction suivante, sens de lecture des restes) ne se
    dessinent qu'une fois remplie la case qu'elles désignent : elles retracent le chemin de l'élève sans lui souffler
    l'étape suivante (demande de l'utilisateur, 01/10/2026)."""

    type = "conversion"

    def __init__(self, id, enonce, nombre, de, vers, methode="", chiffres=None, puissances_donnees=False, nombre_donne=True,
                 **commun):
        super().__init__(id, enonce, **commun)
        self.nombre, self.de, self.vers, self.methode = str(nombre), de, vers, methode
        self.chiffres, self.puissances_donnees, self.nombre_donne = chiffres, puissances_donnees, nombre_donne
        self._construire()

    def procede(self):
        return self.methode if self.methode not in ("", "choix") else METHODE_PAR_DEFAUT.get((self.de, self.vers), "")

    def methodes(self):
        """Les méthodes que l'élève peut employer : toutes celles des deux bases pour ``choix``, sinon la seule imposée."""
        if self.methode == "choix":
            return [m for m, bases in METHODES.items() if (self.de, self.vers) in bases]
        return [self.procede()]

    def pour(self, saisie):
        """La question posée selon la méthode choisie dans ``saisie`` (la défaut, si rien n'est choisi), ou elle-même
        quand la méthode est imposée."""
        if self.methode != "choix":
            return self
        m = (saisie or {}).get("methode")
        return Conversion(self.id, self.enonce, self.nombre, self.de, self.vers, m if m in self.methodes() else self.procede(),
                          self.chiffres, self.puissances_donnees, self.nombre_donne)  # du noyau : une copie d'un widget du lecteur ne vaudrait rien

    def valeur(self):
        return valeur_en_base(self.nombre, self.de)

    def resultat(self):
        return en_base(self.valeur(), self.vers)

    def colonnes(self):
        """Le nombre de colonnes de chiffres : ``chiffres``, à défaut ce qu'il faut (par paquets de 4 bits entre 2 et 16)."""
        if self.procede() in ("paquets", "binaire"):
            bits = 4 * len(chiffres_propres(self.nombre)) if self.de == 16 else len(en_base(self.valeur(), 2)) \
                if self.de == 10 else len(chiffres_propres(self.nombre))
            return self.chiffres or -(-bits // 4) * 4
        if self.procede() in ("ponderation", "polynomial"):
            return self.chiffres or len(chiffres_propres(self.nombre))
        return self.chiffres or len(en_base(self.valeur(), 2))

    # -- le plan : la grille de la méthode, en unités (une colonne de chiffres, une ligne de texte)

    def plan(self, saisie=None, tout=False):
        """La grille telle que la dessinent le lecteur (``modele.py``) et le PDF (``exporter_pdf.py``) : ``cases``
        (``cle`` d'une case à remplir ou ``None``, ``texte`` donné, ``attendu``, position ``x``/``y``, largeur ``l`` en
        colonnes, ``couleur``, ``aligne`` d/c/g, ``gras``), ``etiquettes`` (la colonne de gauche : ``y``, ``h``,
        ``texte`` sur une ou plusieurs lignes, ``couleur``), ``fonds`` et ``traits`` (``GAUCHE`` : le bord gauche des
        étiquettes), ``fleches`` déjà filtrées sur ``saisie`` (``de`` et ``vers`` : des clés de cases, ``genre`` fois /
        droite / lecture), ``largeur`` et ``hauteur``. ``tout`` : les divisions avec toutes les étapes possibles, au lieu
        de s'arrêter à la dernière que l'élève a ouverte."""
        if self.methode == "choix":
            return self.pour(saisie).plan(saisie, tout)
        saisie = {k: v for k, v in (saisie or {}).items() if str(v).strip()}
        p = {"cases": [], "etiquettes": [], "fonds": [], "traits": [], "fleches": [], "largeur": 0, "hauteur": 0,
             "grille": self.procede() != "divisions"}
        getattr(self, "_plan_" + self.procede())(p, saisie, tout)
        ecrites = saisie.keys() | {c["cle"] for c in p["cases"] if c["cle"] and not c["remplir"]}  # remplies ou données
        p["fleches"] = [f for f in p["fleches"] if f.get("quand", f["vers"]) in ecrites]
        return p

    @staticmethod
    def _case(p, cle, x, y, texte="", attendu="", remplir=True, l=1, couleur="", aligne="d", gras=False, h=1):
        p["cases"].append({"cle": cle, "texte": texte, "attendu": attendu, "remplir": remplir and cle is not None,
                           "x": x, "y": y, "l": l, "h": h, "couleur": couleur, "aligne": aligne, "gras": gras})

    @staticmethod
    def _etiquette(p, y, texte, h=1, couleur=""):
        p["etiquettes"].append({"y": y, "h": h, "texte": texte, "couleur": couleur})

    def _bandeau(self, p, y, n):
        p["fonds"].append((GAUCHE, y, n + 1, 1, NOIR_BANDEAU))
        par = " → (Binaire)" if self.procede() == "binaire" else ""  # l'intitulé du cours : « Décimal ➞ ( Binaire ) ➞ Hexadécimal »
        p["etiquettes"].append({"y": y, "h": 1, "texte": f"{NOM_BASE[self.de].capitalize()}{par} → {NOM_BASE[self.vers].capitalize()}",
                                "couleur": "#ffffff", "gras": True})

    def _puissances(self, p, base, n):
        """L'en-tête gris du cours : les puissances de la base, puis leur valeur en décimales (à remplir sauf
        ``puissances_donnees``), reliées de droite à gauche par les flèches « ×2 »."""
        p["fonds"].append((GAUCHE, 0, n + 1, 2, GRIS_ENTETE))
        self._etiquette(p, 0, f"puissances de {base}")
        self._etiquette(p, 1, f"puissances de {base} en décimales")
        for j in range(n):
            e = n - 1 - j
            self._case(p, None, j, 0, f"{base}{str(e).translate(EXPOSANT)}")
            self._case(p, f"p{j}", j, 1, str(base ** e) if self.puissances_donnees else "", str(base ** e),
                       remplir=not self.puissances_donnees)
        for j in range(n - 1):
            p["fleches"].append({"de": f"p{j + 1}", "vers": f"p{j}", "genre": "fois", "texte": f"×{base}"})

    def _plan_ponderation(self, p, saisie, tout):
        b, n = self.de, self.colonnes()
        chiffres = chiffres_propres(self.nombre).rjust(n, "0")
        self._puissances(p, b, n)
        y = 3.4  # sous les flèches « ×2 »
        self._bandeau(p, y, n)
        self._etiquette(p, y + 1, f"nombre {NOM_BASE[b]}", couleur=BLEU_DONNEE)
        quoi = "nombre binaire" if b == 2 else "chiffre hexadécimal"
        self._etiquette(p, y + 2, f"puissances de {b} pondérées\n(puissances de {b} en décimales ×\n{quoi} à convertir)", 3)
        self._etiquette(p, y + 5, "nombre décimal (total)", couleur=VERT_RESULTAT)
        for j, c in enumerate(chiffres):
            self._case(p, None, j, y + 1, c, couleur=BLEU_DONNEE, gras=True)
            terme = CHIFFRES.index(c) * b ** (n - 1 - j)
            self._case(p, f"w{j}", j, y + 2, attendu=("+ " if j else "") + str(terme), h=3)
        self._case(p, "resultat", 0, y + 5, attendu=str(self.valeur()), l=n, couleur=VERT_RESULTAT, aligne="c", gras=True)
        p["largeur"], p["hauteur"] = n, y + 6

    def _plan_polynomial(self, p, saisie, tout):
        """« Même principe, mais en posant explicitement le polynôme » (le cours) : sous chaque chiffre, son terme
        « chiffre×base^rang », puis la valeur du terme, puis la somme. Le cours n'y trace aucune flèche."""
        b, n = self.de, self.colonnes()
        l = 1 if b == 2 else 2  # « 14×16¹ » ne tient pas dans une colonne de chiffre
        chiffres = chiffres_propres(self.nombre).rjust(n, "0")
        self._bandeau(p, 0, n * l)
        self._etiquette(p, 1, f"nombre {NOM_BASE[b]}", couleur=BLEU_DONNEE)
        self._etiquette(p, 2, f"termes du polynôme\n(chiffre × {b} puissance rang)", 2)
        self._etiquette(p, 4, "valeur de chaque terme")
        self._etiquette(p, 5, "nombre décimal (total)", couleur=VERT_RESULTAT)
        for j, c in enumerate(chiffres):
            e = n - 1 - j
            self._case(p, None, j * l, 1, c, l=l, couleur=BLEU_DONNEE, gras=True, aligne="c")
            self._case(p, f"t{j}", j * l, 2, attendu=f"{CHIFFRES.index(c)}×{b}{str(e).translate(EXPOSANT)}", l=l, h=2,
                       aligne="c")
            self._case(p, f"w{j}", j * l, 4, attendu=str(CHIFFRES.index(c) * b ** e), l=l)
        self._case(p, "resultat", 0, 5, attendu=str(self.valeur()), l=n * l, couleur=VERT_RESULTAT, aligne="c", gras=True)
        p["largeur"], p["hauteur"] = n * l, 6

    def _plan_soustractions(self, p, saisie, tout):
        n, valeur = self.colonnes(), self.valeur()
        self._puissances(p, 2, n)
        y = 3.4
        self._bandeau(p, y, n)
        self._etiquette(p, y + 1, "nombre décimal", couleur=BLEU_DONNEE)
        self._etiquette(p, y + 2, "puissance de 2 en décimales\nsupérieure ou égale au reste", 2)
        self._etiquette(p, y + 4, "reste")
        self._etiquette(p, y + 5, "nombre binaire", couleur=VERT_RESULTAT)
        self._case(p, "nombre", max(0, n / 2 - 1), y + 1, f"{valeur}{INDICE_BASE[10]}" if self.nombre_donne else "",
                   str(valeur), remplir=not self.nombre_donne, l=min(2, n), couleur=BLEU_DONNEE, aligne="c", gras=True)
        reste, bits = valeur, en_base(valeur, 2).rjust(n, "0")
        for j, bit in enumerate(bits):
            puissance = 2 ** (n - 1 - j)
            if bit == "1":
                reste -= puissance
            self._case(p, f"s{j}", j, y + 2, attendu=f"-{puissance}" if bit == "1" else "", h=2)
            self._case(p, f"r{j}", j, y + 4, attendu=f"={reste}" if bit == "1" else "")
            self._case(p, f"b{j}", j, y + 5, attendu=bit, couleur=VERT_RESULTAT, gras=True)
        source = "nombre"  # la flèche part du reste dont l'élève est parti : la dernière case « reste » remplie avant
        for j in range(n):
            if f"s{j}" in saisie:
                p["fleches"].append({"de": source, "vers": f"s{j}", "genre": "droite"})
            if f"r{j}" in saisie:
                source = f"r{j}"
        p["largeur"], p["hauteur"] = n, y + 6

    def _plan_binaire(self, p, saisie, tout):
        """« Méthode via binaire » (le cours) : ses deux tableaux enchaînés en un seul. Décimal → hexadécimal : les
        soustractions successives, puis les bits regroupés par paquets de 4 ; hexadécimal → décimal : chaque chiffre en
        paquet de 4 bits, puis la pondération des bits. L'en-tête des puissances de 2 est celui de la première méthode."""
        n, haut = self.colonnes(), 1.4
        groupe = "chiffre ou lettre associée\npar groupe de 4 bits"
        hexa = (self.resultat() if self.de == 10 else chiffres_propres(self.nombre)).rjust(n // 4, "0")
        bits = en_base(self.valeur(), 2).rjust(n, "0")
        if self.de == 10:
            self._plan_soustractions(p, saisie, tout)  # jusqu'à la ligne « nombre binaire », en y = 8.4
            p["etiquettes"][-1]["couleur"] = ""  # le binaire n'est plus le résultat, seulement une étape
            for c in p["cases"]:
                if c["cle"] and c["cle"][0] == "b":
                    c["couleur"] = ""
            y = 9.4
            self._etiquette(p, y, groupe, haut)
            for i, chiffre in enumerate(hexa):
                self._case(p, f"g{i}", 4 * i, y, attendu=f"={chiffre}", l=4, h=haut)
            self._etiquette(p, y + haut, "nombre hexadécimal", couleur=VERT_RESULTAT)
            self._case(p, "resultat", 0, y + haut, attendu=self.resultat(), l=n, couleur=VERT_RESULTAT, aligne="c", gras=True)
            p["traits"] += [(4 * i, 8.4, 4 * i, y + haut) for i in range(1, n // 4)]
            p["hauteur"] = y + haut + 1
            return
        self._puissances(p, 2, n)
        y = 3.4
        self._bandeau(p, y, n)
        self._etiquette(p, y + 1, "nombre hexadécimal", couleur=BLEU_DONNEE)
        self._case(p, "nombre", 0, y + 1, f"{chiffres_propres(self.nombre)}{INDICE_BASE[16]}", remplir=False, l=n,
                   couleur=BLEU_DONNEE, aligne="c", gras=True)
        self._etiquette(p, y + 2, groupe, haut)
        for i, chiffre in enumerate(hexa):
            self._case(p, None, 4 * i, y + 2, f"{chiffre}{INDICE_BASE[16]}", l=4, h=haut)
        y += 2 + haut
        self._etiquette(p, y, "nombre binaire")
        self._etiquette(p, y + 1, "puissances de 2 pondérées\n(puissances de 2 en décimales ×\nnombre binaire à convertir)", 3)
        self._etiquette(p, y + 4, "nombre décimal (total)", couleur=VERT_RESULTAT)
        for j, bit in enumerate(bits):
            self._case(p, f"b{j}", j, y, attendu=bit, gras=True)
            self._case(p, f"w{j}", j, y + 1, attendu=("+ " if j else "") + str(int(bit) * 2 ** (n - 1 - j)), h=3)
        self._case(p, "resultat", 0, y + 4, attendu=str(self.valeur()), l=n, couleur=VERT_RESULTAT, aligne="c", gras=True)
        p["traits"] += [(4 * i, 5.4, 4 * i, y + 1) for i in range(1, n // 4)]
        p["largeur"], p["hauteur"] = n, y + 5

    def _plan_divisions(self, p, saisie, tout):
        """Les divisions posées comme à l'école primaire, en escalier : à l'étape k, le dividende en (k, k), le diviseur
        à sa droite derrière la potence, le reste sous le dividende, le quotient sous le diviseur — dividende de l'étape
        suivante, qui se pose à partir de lui. Une étape ne paraît qu'une fois le quotient précédent écrit, et différent
        de 0 : rien ne dit d'avance combien il y en aura. Ni grille ni fond (l'utilisateur, 02/10/2026 : « des
        divisions posées comme en primaire, pas un tableau ») ; à l'écran seulement, une case vide est en pointillé
        (``svg``)."""
        b, valeur = self.vers, self.valeur()
        dividendes = [valeur]
        while dividendes[-1]:
            dividendes.append(dividendes[-1] // b)
        if len(dividendes) == 1:
            dividendes.append(0)
        m = len(dividendes) - 1  # le nombre de divisions
        plafond = m + 2  # deux de trop au plus : de quoi se tromper sans que la grille ne s'arrête au bon endroit
        etapes = 1
        while etapes < plafond and (tout or (f"q{etapes}" in saisie and chiffres_propres(saisie[f"q{etapes}"]) != "0")):
            etapes += 1
        x0 = 1  # une colonne libre à gauche, pour la flèche du sens de lecture
        self._etiquette(p, 0, "nombre décimal", couleur=BLEU_DONNEE)
        self._case(p, "nombre", x0, 0, str(valeur), remplir=False, couleur=BLEU_DONNEE, gras=True)
        bas = b == 16  # en base 16, le reste converti en chiffre (« = C₁₆ ») sous le reste
        for k in range(etapes):
            x, juste = x0 + k, k < m
            reste = dividendes[k] % b if juste else None
            self._case(p, None, x + 1, k, str(b), aligne="g")
            p["traits"] += [(x + 1, k, x + 1, k + 2), (x + 1, k + 1, x + 2, k + 1)]  # la potence
            self._case(p, f"r{k}", x, k + 1, attendu=str(reste) if juste else "")
            if bas:
                self._case(p, f"h{k}", x, k + 2, attendu=f"={CHIFFRES[reste]}" if juste else "",
                           couleur=VERT_RESULTAT, aligne="c")
            self._case(p, f"q{k + 1}", x + 1, k + 1, attendu=str(dividendes[k + 1]) if juste else "")
        y = etapes + 1 + bas + 0.4
        self._etiquette(p, y, f"nombre {NOM_BASE[b]}", couleur=VERT_RESULTAT)
        self._case(p, "resultat", x0, y, attendu=self.resultat(), l=etapes + 1, couleur=VERT_RESULTAT, aligne="g", gras=True)
        if etapes > 1:
            p["fleches"].append({"de": f"r{etapes - 1}", "vers": "r0", "genre": "lecture", "quand": "resultat",
                                 "texte": "sens de lecture"})
        p["largeur"], p["hauteur"] = x0 + etapes + 1, y + 1

    def _plan_paquets(self, p, saisie, tout):
        n = self.colonnes()
        self._bandeau(p, 0, n)
        hexa = (self.resultat() if self.de == 2 else chiffres_propres(self.nombre)).rjust(n // 4, "0")
        bits = (chiffres_propres(self.nombre) if self.de == 2 else en_base(self.valeur(), 2)).rjust(n, "0")
        source, cible = ("binaire", "hexadécimal") if self.de == 2 else ("hexadécimal", "binaire")
        self._etiquette(p, 1, f"nombre {source}", couleur=BLEU_DONNEE)
        haut = 1.4  # deux lignes de libellé : sur une seule, la figure dépasse la largeur d'une page A4
        self._etiquette(p, 2, "chiffre ou lettre associée\npar groupe de 4 bits", haut)
        self._etiquette(p, 2 + haut, f"nombre {cible}", couleur=VERT_RESULTAT)
        donne = len(chiffres_propres(self.nombre))
        if self.de == 2:
            for j, bit in enumerate(bits):
                if j >= n - donne:
                    self._case(p, None, j, 1, bit, couleur=BLEU_DONNEE, gras=True)
                else:  # « compléter par des 0 à gauche » (corrigé du professeur) : c'est à l'élève de les écrire
                    self._case(p, f"z{j}", j, 1, attendu="0", couleur=BLEU_DONNEE, gras=True)
            for i, chiffre in enumerate(hexa):
                self._case(p, f"g{i}", 4 * i, 2, attendu=f"={chiffre}", l=4, h=haut)
            self._case(p, "resultat", 0, 2 + haut, attendu=self.resultat(), l=n, couleur=VERT_RESULTAT, aligne="c", gras=True)
        else:
            self._case(p, "nombre", 0, 1, f"{chiffres_propres(self.nombre)}{INDICE_BASE[16]}", remplir=False, l=n,
                       couleur=BLEU_DONNEE, aligne="c", gras=True)
            for i, chiffre in enumerate(hexa):
                self._case(p, None, 4 * i, 2, f"{chiffre}{INDICE_BASE[16]}", l=4, h=haut)
            for j, bit in enumerate(bits):
                self._case(p, f"b{j}", j, 2 + haut, attendu=bit, couleur=VERT_RESULTAT, gras=True)
        debut, fin = (1, 2 + haut) if self.de == 2 else (2, 3 + haut)  # pas sur le nombre écrit d'un seul tenant
        p["traits"] += [(4 * i, debut, 4 * i, fin) for i in range(1, n // 4)]  # la séparation des paquets, en trait épais
        p["largeur"], p["hauteur"] = n, 3 + haut

    # -- le dessin : un SVG, le même à l'écran (sous les champs de saisie) et sur le papier

    COLONNE, LIGNE, CORPS = 34, 20, 10  # en points : une colonne de chiffres, une ligne, le corps du texte (10 pt imprimés)

    def svg(self, plan, valeurs=None, police="Carlito", couleur_valeurs="", police_valeurs="", largeur_max=None, ecrites=None):
        """La figure de ``plan`` en SVG, un point par unité : fonds, bordures, étiquettes, textes donnés, traits, flèches ;
        et ``valeurs`` ({clé: texte}) écrites dans les cases à remplir — le corrigé, ou une copie, sur le papier. À l'écran
        on n'en passe pas : les champs de saisie se posent par-dessus, aux places que donne ``rectangle``. ``largeur_max``
        (en points) réduit la taille déclarée d'une figure plus large, sans toucher au dessin (16 bits sur une page A4).
        ``ecrites`` (à l'écran) : les cases que l'élève a remplies ; sans grille, les autres sont en pointillé, pour qu'il
        voie où écrire. Sur le papier, rien : la copie reste une division posée sur une feuille blanche."""
        g, cases = self.geometrie(plan), {c["cle"]: c for c in plan["cases"] if c["cle"]}
        largeur, hauteur = g["x"](plan["largeur"]) + 1, g["y"](plan["hauteur"]) + 1
        reduction = min(1, largeur_max / largeur) if largeur_max else 1
        s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{largeur * reduction / 72:.3f}in" '
             f'height="{hauteur * reduction / 72:.3f}in" '
             f'viewBox="0 0 {largeur} {hauteur}" font-family="{police}" font-size="{self.CORPS}">']

        def texte(x, y, contenu, ancre="middle", couleur="#000000", gras=False, famille="", corps=None, tourne=0):
            s.append(f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="{ancre}" fill="{couleur or "#000000"}"'
                     + (' font-weight="bold"' if gras else "") + (f' font-family="{famille}"' if famille else "")
                     + (f' font-size="{corps}"' if corps else "")
                     + (f' transform="rotate({tourne:.1f} {x:.1f} {y:.1f})"' if tourne else "")
                     + f">{html.escape(str(contenu))}</text>")

        for x, y, l, h, couleur in plan["fonds"]:
            s.append(f'<rect x="{g["x"](x)}" y="{g["y"](y)}" width="{g["x"](x + l) - g["x"](x)}" height="{h * self.LIGNE}" '
                     f'fill="{couleur}"/>')
        for c in plan["cases"]:
            x, y, l, h = self.rectangle(plan, c)
            if plan["grille"]:
                s.append(f'<rect x="{x}" y="{y}" width="{l}" height="{h}" fill="none" stroke="#7f7f7f" stroke-width="0.75"/>')
            elif ecrites is not None and c["remplir"] and c["cle"] not in ecrites:
                s.append(f'<rect x="{x + 2}" y="{y + 2}" width="{l - 4}" height="{h - 4}" fill="none" stroke="#a6a6a6" '
                         f'stroke-width="0.6" stroke-dasharray="2 2"/>')
        for e in plan["etiquettes"]:
            lignes, y = e["texte"].split("\n"), g["y"](e["y"])
            if plan["grille"] and not e.get("gras"):
                s.append(f'<rect x="0" y="{y}" width="{g["etiquettes"]}" height="{e["h"] * self.LIGNE}" fill="none" '
                         f'stroke="#7f7f7f" stroke-width="0.75"/>')
            haut = y + (e["h"] * self.LIGNE - len(lignes) * self.CORPS * 1.2) / 2
            for i, ligne in enumerate(lignes):
                texte(g["etiquettes"] / 2, haut + (i + 0.82) * self.CORPS * 1.2, ligne, couleur=e["couleur"], gras=e.get("gras"))
        for x1, y1, x2, y2 in plan["traits"]:
            s.append(f'<line x1="{g["x"](x1)}" y1="{g["y"](y1)}" x2="{g["x"](x2)}" y2="{g["y"](y2)}" stroke="#000000" '
                     f'stroke-width="{1.5 if plan["grille"] else 1}"/>')
        for c in plan["cases"]:
            contenu = c["texte"] if not c["remplir"] else (valeurs or {}).get(c["cle"], "")
            if not str(contenu).strip():
                continue
            x, y, l, h = self.rectangle(plan, c)
            ancre, ax = {"d": ("end", x + l - 4), "g": ("start", x + 4)}.get(c["aligne"], ("middle", x + l / 2))
            ecrit = c["remplir"] and couleur_valeurs
            texte(ax, y + h / 2 + self.CORPS * 0.36, contenu, ancre, couleur_valeurs if ecrit else c["couleur"], c["gras"],
                  police_valeurs if c["remplir"] else "")
        for f in plan["fleches"]:
            self._fleche(s, texte, plan, cases[f["de"]], cases[f["vers"]], f)
        s.append("</svg>")
        return "\n".join(s)

    def geometrie(self, plan):
        """Les abscisses et ordonnées en points d'un plan : la colonne des étiquettes à gauche (aussi large que la plus
        longue de leurs lignes, estimée sur la chasse moyenne de Carlito), puis les colonnes de chiffres."""
        lignes = [ligne for e in plan["etiquettes"] for ligne in e["texte"].split("\n")]
        etiquettes = round(max([len(ligne) for ligne in lignes] or [0]) * self.CORPS * 0.5 + 12)
        return {"etiquettes": etiquettes, "x": lambda x: 0 if x == GAUCHE else etiquettes + x * self.COLONNE,
                "y": lambda y: y * self.LIGNE}

    def rectangle(self, plan, case):
        """La place d'une case, en points : (x, y, largeur, hauteur)."""
        g = self.geometrie(plan)
        return g["x"](case["x"]), g["y"](case["y"]), case["l"] * self.COLONNE, case["h"] * self.LIGNE

    def _fleche(self, s, texte, plan, de, vers, f):
        x1, y1, l1, h1 = self.rectangle(plan, de)
        x2, y2, l2, h2 = self.rectangle(plan, vers)

        def pointe(px, py, dx, dy, couleur, taille=6):
            n = (dx * dx + dy * dy) ** 0.5 or 1
            dx, dy = dx / n, dy / n
            gauche = (px - taille * dx - taille * 0.5 * dy, py - taille * dy + taille * 0.5 * dx)
            droite = (px - taille * dx + taille * 0.5 * dy, py - taille * dy - taille * 0.5 * dx)
            s.append(f'<polygon points="{px:.1f},{py:.1f} {gauche[0]:.1f},{gauche[1]:.1f} {droite[0]:.1f},{droite[1]:.1f}" '
                     f'fill="{couleur}"/>')

        if f["genre"] == "fois":  # sous l'en-tête, en arc, de la puissance à celle de sa gauche
            a, b, bas = x1 + l1 / 2, x2 + l2 / 2, y1 + h1
            s.append(f'<path d="M {a - 4:.1f} {bas + 2:.1f} Q {(a + b) / 2:.1f} {bas + 22:.1f} {b + 4:.1f} {bas + 4:.1f}" '
                     f'fill="none" stroke="{VERT_FOIS}" stroke-width="1.5"/>')
            pointe(b + 3, bas + 3, -1, -1.1, VERT_FOIS, 5)
            texte((a + b) / 2, bas + 22, f["texte"], couleur=VERT_FOIS, corps=self.CORPS * 0.8)
        elif f["genre"] == "droite":  # d'un bord de case à l'autre, sur la droite qui joint leurs centres
            (ax, ay), (bx, by) = (x1 + l1 / 2, y1 + h1 / 2), (x2 + l2 / 2, y2 + h2 / 2)
            dx, dy = bx - ax, by - ay

            def bord(l, h):
                return min(l / 2 / abs(dx) if dx else 1e9, h / 2 / abs(dy) if dy else 1e9)
            t1, t2 = bord(l1 - 6, h1 - 4), 1 - bord(l2 - 6, h2 - 4)
            s.append(f'<line x1="{ax + t1 * dx:.1f}" y1="{ay + t1 * dy:.1f}" x2="{ax + t2 * dx:.1f}" y2="{ay + t2 * dy:.1f}" '
                     f'stroke="{BLEU_SOUSTRACTION}" stroke-width="1.5"/>')
            pointe(ax + t2 * dx, ay + t2 * dy, dx, dy, BLEU_SOUSTRACTION)
        else:  # la grosse flèche du sens de lecture, le long des restes, du dernier vers le premier
            # parallèle à la ligne des coins bas-gauche des restes, décalée sous l'escalier
            sous = 8 + (self.LIGNE if self.vers == 16 else 0)  # en base 16, sous la ligne des chiffres convertis
            (ax, ay), (bx, by) = (x1 - 8, y1 + h1 + sous), (x2 - 8, y2 + h2 + sous)
            dx, dy = bx - ax, by - ay
            n = (dx * dx + dy * dy) ** 0.5 or 1
            s.append(f'<line x1="{ax:.1f}" y1="{ay:.1f}" x2="{bx - 9 * dx / n:.1f}" y2="{by - 9 * dy / n:.1f}" '
                     f'stroke="{VERT_LECTURE}" stroke-width="4"/>')
            pointe(bx, by, dx, dy, VERT_LECTURE, 11)
            angle = math.degrees(math.atan2(dy, dx))
            angle = angle + 180 if abs(angle) > 90 else angle  # lisible, jamais tête en bas
            texte((ax + bx) / 2 - 8 * dy / n, (ay + by) / 2 + 8 * dx / n + 4, f["texte"], couleur=VERT_LECTURE,
                  corps=self.CORPS * 0.8, gras=True, tourne=angle)

    # -- la correction

    def base_de(self, cle):
        """La base dans laquelle s'écrit une case : celle du résultat, du chiffre converti, d'un bit, ou décimale."""
        if cle == "resultat":
            return self.vers
        return {"g": 16, "h": 16, "b": 2, "z": 2}.get(cle[0], 10)

    def egal(self, cle, saisi, attendu):
        if cle[0] == "t":  # un terme : même chiffre (« E » ou « 14 »), même base, même rang
            return self._terme(saisi) is not None and self._terme(saisi) == self._terme(attendu)
        signes = "=+-" if cle[0] == "s" else "=+"  # « -128 » ou « 128 » : le signe d'une soustraction est une notation
        v = valeur_en_base(saisi, self.base_de(cle), signes)
        return v is not None and v == valeur_en_base(attendu, self.base_de(cle), signes)

    def _terme(self, texte):
        brut = re.sub("[⁰¹²³⁴⁵⁶⁷⁸⁹]+", lambda m: "^" + m[0].translate(str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")),
                      re.sub(r"\s", "", str(texte or "")).upper().lstrip("+"))
        m = TERME.fullmatch(brut)
        if not m:
            return None
        return (int(m[1]) if m[1].isdigit() else CHIFFRES.index(m[1]) if len(m[1]) == 1 else None), int(m[2]), int(m[3])

    def juste(self):
        if "{" in self.nombre:  # tiré par ``variables`` : la question brute d'une banque n'a pas encore de cases
            return {}
        cases = {c["cle"]: c["attendu"] for c in self.plan(tout=True)["cases"] if c["remplir"] and c["attendu"]}
        return {**cases, "methode": self.procede()} if self.methode == "choix" else cases

    def complete(self):
        return all(str((self.saisie or {}).get(k, "")).strip() for k in self.pour(self.saisie).juste())

    INDICES = {"p": "Une puissance en décimales est fausse : chacune vaut {b} fois celle de sa droite.",
               "w": "Une puissance pondérée est fausse : c'est la puissance multipliée par le chiffre au-dessus.",
               "t": "Un terme du polynôme est faux : c'est le chiffre × {b} puissance son rang (0 tout à droite).",
               "s": "Une soustraction est fausse : on retire la plus grande puissance de 2 que contient le reste.",
               "b": "Un bit est faux.",
               "q": "Une division est fausse : le quotient est la division entière par {b}.",
               "h": "Un reste est mal écrit en chiffre hexadécimal.",
               "g": "Un paquet de 4 bits est mal converti.",
               "z": "Le nombre de bits doit être un multiple de 4 : complète à gauche par des 0.",
               "n": "Le nombre décimal à convertir est faux : c'est le résultat de la question précédente.",
               "resultat": "Le nombre final est faux."}

    def corriger(self, saisie):
        if "{" in self.nombre:  # jamais posée ainsi : le sujet la tire avant (``Sujet.resoudre``, ``Paquet.nommer``)
            return None, None
        if self.methode == "choix":  # selon la méthode choisie ; le choix lui-même ne se corrige pas
            return self.pour(saisie).corriger({k: v for k, v in (saisie or {}).items() if k != "methode"})
        saisie = {k: v for k, v in (saisie or {}).items() if str(v).strip()}
        attendu = self.juste()
        champs = {c["cle"] for c in self.plan(tout=True)["cases"] if c["remplir"]}
        fausses = [k for k, v in attendu.items() if not (k in saisie and self.egal(k, saisie[k], v))]
        en_trop = [k for k in saisie if k in champs and k not in attendu]
        total = len(attendu) + len(en_trop)
        fraction = (len(attendu) - len(fausses)) / total if total else None
        if fausses:
            cle = fausses[0] if fausses[0] == "resultat" else fausses[0][0]
            if cle == "r":  # un reste faux : il vient de la soustraction ou de la division qui l'a produit
                cle = "q" if self.procede() == "divisions" else "s"
            base = self.vers if self.procede() == "divisions" else 2 if self.procede() in ("soustractions", "binaire") else self.de
            indice = self.INDICES.get(cle, "").format(b=base)
        else:
            indice = "Certaines cases devaient rester vides." if en_trop else None
        return fraction, indice

    def _attendu(self):
        if self.methode == "choix":
            return self.pour(self.saisie)._attendu()
        valeur, b = self.valeur(), self.vers
        egalite = f"**{chiffres_propres(self.nombre)}{INDICE_BASE[self.de]} = {self.resultat()}{INDICE_BASE[self.vers]}**"
        procede = self.procede()
        if procede == "polynomial":
            n = self.colonnes()
            chiffres = chiffres_propres(self.nombre).rjust(n, "0")
            termes = [f"{CHIFFRES.index(c)}×{self.de}{str(n - 1 - j).translate(EXPOSANT)}" for j, c in enumerate(chiffres)]
            valeurs = [str(CHIFFRES.index(c) * self.de ** (n - 1 - j)) for j, c in enumerate(chiffres) if c != "0"]
            return f"{egalite} : {' + '.join(termes)} = {' + '.join(valeurs)} = {valeur}"
        if procede == "ponderation":
            n = self.colonnes()
            termes = [f"{CHIFFRES.index(c)}×{self.de ** (n - 1 - j)}"
                      for j, c in enumerate(chiffres_propres(self.nombre).rjust(n, "0"))]
            return f"{egalite} : {' + '.join(termes)} = {valeur}"
        if procede == "soustractions":
            etapes, reste = [], valeur
            for j, bit in enumerate(en_base(valeur, 2).rjust(self.colonnes(), "0")):
                if bit == "1":
                    puissance = 2 ** (self.colonnes() - 1 - j)
                    etapes.append(f"{reste} − {puissance} = {reste - puissance}")
                    reste -= puissance
            return f"{egalite} : {' ; '.join(etapes)}"
        if procede == "binaire":
            bits = en_base(valeur, 2).rjust(self.colonnes(), "0")
            paquets = " ".join(bits[i:i + 4] for i in range(0, len(bits), 4)) + INDICE_BASE[2]
            if self.de == 10:
                etapes, reste = [], valeur
                for j, bit in enumerate(bits):
                    if bit == "1":
                        puissance = 2 ** (len(bits) - 1 - j)
                        etapes.append(f"{reste} − {puissance} = {reste - puissance}")
                        reste -= puissance
                return f"{egalite} : {' ; '.join(etapes)} ⟹ {paquets} ⟹ un chiffre par paquet de 4 bits"
            termes = [str(2 ** (len(bits) - 1 - j)) for j, bit in enumerate(bits) if bit == "1"]
            return f"{egalite} : un paquet de 4 bits par chiffre ⟹ {paquets} ⟹ {' + '.join(termes)} = {valeur}"
        if procede == "divisions":
            etapes, d = [], valeur
            while True:
                etapes.append(f"{d} = {b} × {d // b} + {d % b}")
                d //= b
                if not d:
                    break
            return f"{egalite} : {' ; '.join(etapes)} (restes lus de bas en haut)"
        return f"{egalite} : un chiffre hexadécimal pour chaque paquet de 4 bits, en partant de la droite"

    def problemes(self):
        p = super().problemes()
        if "{" in self.nombre:
            return p  # tiré par ``variables`` : contrôlé une fois instancié
        if self.de not in NOM_BASE or self.vers not in NOM_BASE:
            p.append(("erreur", f"bases {self.de} → {self.vers} : 2, 10 ou 16"))
            return p
        if (self.de, self.vers) not in METHODES.get(self.procede(), ()):
            p.append(("erreur", f"méthode « {self.procede()} » : pas pour {self.de} → {self.vers}"))
            return p
        if self.valeur() is None:
            p.append(("erreur", f"nombre « {self.nombre} » : pas un nombre en base {self.de}"))
            return p
        utiles = len(en_base(self.valeur(), 2 if self.procede() not in ("ponderation", "polynomial") else self.de))
        if self.chiffres and self.chiffres < utiles:
            p.append(("erreur", f"chiffres = {self.chiffres} : il en faut au moins {utiles}"))
        if self.chiffres and self.procede() in ("paquets", "binaire") and self.chiffres % 4:
            p.append(("erreur", f"chiffres = {self.chiffres} : un multiple de 4 pour des paquets de 4 bits"))
        return p


class Personnalise(Question):
    """Une question dont le professeur écrit lui-même le widget, quand aucun type ne convient.

    ``widget`` est du code Python exécuté à la construction, avec pour noms de départ ceux de ce module (les classes
    Qt, ``Texte``, ``hauteur``…). Il y définit des fonctions qui reçoivent la question en premier argument et tiennent
    lieu des méthodes d'un type : ``corps(q, d)`` (les widgets de saisie, ajoutés à la disposition ``d`` et à
    ``q.entrees`` pour être grisés hors épreuve), ``lire(q)`` (la saisie, en JSON), ``ecrire(q, valeur)`` (l'inverse),
    ``corriger(q, saisie)`` (``(fraction, indice)``) et, facultative, ``juste(q)`` (la bonne saisie, que le corrigé
    montre dans le widget). ``papier`` et ``attendu`` sont le repli Markdown des exports imprimés : un widget ne
    s'imprime pas.

    Ce code est celui du professeur, embarqué dans le sujet comme le ``tests_code`` d'une question ``code`` : il
    n'est ni filtré ni confiné. Il est en revanche isolé des pannes — une erreur, à son exécution comme dans l'une
    de ses fonctions, dégrade la question en message rouge et renvoie sa correction au professeur, au lieu
    d'emporter le paquet en pleine épreuve."""

    type = "personnalise"

    def __init__(self, id, enonce, widget, papier="", attendu="", **commun):
        super().__init__(id, enonce, **commun)
        self.widget, self.papier, self.attendu = widget, papier, attendu
        self.fonctions, self.panne = {}, ""
        self._construire()

    def _casser(self, quoi, exc):
        """Panne du code du professeur : la question le dit en rouge, et sa correction lui revient."""
        traceback.print_exc()
        self.panne = f"{quoi} : {exc.__class__.__name__} : {exc}"

    def _appeler(self, nom, defaut, *args):
        """La fonction du professeur, ou ``defaut`` si elle manque, si elle tombe, ou si la question est déjà en panne."""
        if self.panne or nom not in self.fonctions:
            return defaut
        try:
            return self.fonctions[nom](self, *args)
        except Exception as exc:  # noqa: BLE001 - n'importe quelle erreur du code du professeur
            self._casser(f"{nom}()", exc)
            return defaut

    def juste(self):
        return self._appeler("juste", None)

    def corriger(self, saisie):
        return self._appeler("corriger", (None, None), saisie)  # en panne : fraction None, la question attend le professeur

    def _attendu(self):
        return self.attendu

    def problemes(self):
        p = super().problemes()
        if self.panne:
            p.append(("erreur", f"widget : {self.panne}"))
        if not self.attendu:
            p.append(("avert", "sans attendu : le corrigé n'aura rien à montrer"))
        if not self.papier:
            p.append(("avert", "sans papier : le sujet imprimé n'aura que des lignes à remplir"))
        return p


class Groupe(Question):
    type = "groupe"

    def __init__(self, id, enonce, sous_questions, **commun):
        if "points" in commun:
            raise TypeError("un groupe n'a pas de points propres, c'est la somme des sous-questions")
        super().__init__(id, enonce, **commun)
        self.sous_questions = sous_questions
        for lettre, sq in zip("abcdefghijklmnopqrstuvwxyz", sous_questions):
            sq.reperer(f"{lettre}.")
        self._construire()

    def feuilles(self):
        return self.sous_questions

    def total(self):
        return sum(sq.total() for sq in self.sous_questions)

    def montrer_correction(self, couleur=""):
        for sq in self.sous_questions:
            sq.montrer_correction(couleur)

    def presenter_corrige(self):
        for sq in self.sous_questions:
            sq.presenter_corrige()

    def problemes(self):
        p = super().problemes()
        if len(self.sous_questions) < 2:
            p.append(("erreur", "un groupe a au moins deux sous-questions"))
        rangs = {sq.id: n for n, sq in enumerate(self.sous_questions)}
        for n, sq in enumerate(self.sous_questions):
            if isinstance(sq, Groupe):
                p.append(("erreur", f"{sq.id} : groupe dans un groupe, un seul niveau permis"))
            for r in sq.revele:
                if r == self.id or rangs.get(r, -1) > n:
                    p.append(("erreur", f"{sq.id} : révèle {r}, qui ne la précède pas dans le groupe (ordre fixe)"))
        return p


# --- banque, section, sujet, paquet -----------------------------------------------------------------------------

def revelees(q, groupe_de):
    """Les questions dont ``q`` ou l'une de ses sous-questions révèle la réponse (champ ``revele``), une
    sous-question citée étant remplacée par son groupe : ``groupe_de`` = {id de sous-question: id du groupe}."""
    return {groupe_de.get(r, r) for sq in [q, *q.sous_questions] for r in sq.revele} - {q.id}


def ordonner(resolues, groupe_de, melanger=""):
    """Les (question, …) d'une section, mélangées d'abord si ``melanger`` (le titre du sujet : un ordre propre au sujet,
    le même sur papier et pour chaque élève), puis chacune après celles dont elle révèle la réponse, l'ordre reçu conservé
    pour le reste (une boucle de révélations, refusée par le validateur, garde simplement l'ordre reçu)."""
    restant, ordre = list(resolues), []
    if melanger:
        random.Random(melanger + str(len(restant))).shuffle(restant)
    while restant:
        presentes = {q.id for q, *_ in restant}
        ordre.append(restant.pop(next((i for i, (q, *_) in enumerate(restant) if not revelees(q, groupe_de) & presentes), 0)))
    return ordre


def poser_bases(questions, bases):
    """Chaque question SQL dont la ``base`` est un nom des ``bases`` partagées y trouve son script."""
    for q in questions:
        for f in (q, *q.sous_questions):
            if hasattr(f, "bases_connues"):
                f.bases_connues = bases


def afficher_contextes(questions, contextes, repeter=False):
    """Chaque texte partagé s'ouvre au-dessus de la première question qui le cite — au-dessus de CHACUNE si
    ``repeter`` : une question par écran, c'est la seule façon que la figure de l'exercice reste sous les yeux."""
    vus = set()
    for q in questions:
        for f in (q, *q.sous_questions):
            f.contextes_connus = {nom: contextes[nom] for nom in f.contextes_cites() if nom in contextes}
            for nom in reversed(f.contextes_cites()):  # insérés au-dessus les uns des autres, donc du dernier au premier
                if repeter or nom not in vus:
                    vus.add(nom)
                    f.afficher_contexte(contextes[nom])


class Banque(Objet):
    """Un fichier de banque : questions, textes partagés (``contextes``) et fichiers embarqués (``medias`` : nom -> bytes).
    Affichée, elle montre ses questions corrigées."""

    def __init__(self, matiere, questions, niveau="", theme="", contextes=None, medias=None, bases=None):
        self.matiere, self.niveau, self.theme = matiere, niveau, theme
        self.contextes, self.medias, self.questions = contextes or {}, medias or {}, questions
        self.bases = bases or {}  # nom -> script SQL, écrit une fois pour toutes les questions d'un exercice
        MEDIAS.update(self.medias)
        afficher_contextes(questions, self.contextes)
        poser_bases(questions, self.bases)


class Section(Objet):
    """``questions`` : les questions d'un paquet, ou, dans un sujet, des identifiants (ou une ``Reference`` quand les points
    diffèrent de ceux de la banque) qui n'ont rien à afficher. ``bonus`` : ses points s'ajoutent à la note sans compter
    dans le total (questions pour les plus rapides). ``nouvelle_page`` : sur papier, la section commence sur une
    feuille à elle (page impaire, recto-verso), pour être ramassée à part. ``electronique`` : ``titre`` et ``consignes``
    tels que le .qcm les affiche, quand ils y diffèrent du papier (``Question.electronique``)."""

    def __init__(self, questions, titre="", consignes="", bonus=False, nouvelle_page=False, electronique=None):
        self.titre, self.consignes, self.questions, self.bonus = titre, consignes, questions, bonus
        self.nouvelle_page, self.electronique = nouvelle_page, electronique


class DefinitionSujet(Objet):
    """Un fichier de sujet (évaluation papier, QCM électronique, TP ou projet)."""

    def __init__(self, titre, destination, banques, sections, sous_titre="", theme="", matiere="", classe="", date="",
                 duree_minutes=None, consignes="", fichier="tp.py", melanger_questions=False, affichage="sujet",
                 retour=True, graine=None, seconde_chance=None, correction=True, revision="",
                 entrainement=False, acces_cours=False, sans_execution=False, dossier="", sans_ide=False,
                 surveillance=False, cours=None, cours_pages=None):
        self.titre, self.sous_titre, self.theme, self.matiere, self.classe = titre, sous_titre, theme, matiere, classe
        self.date, self.duree_minutes, self.destination, self.consignes = date, duree_minutes, destination, consignes
        self.fichier, self.melanger_questions, self.affichage, self.retour = fichier, melanger_questions, affichage, retour
        self.graine, self.seconde_chance, self.banques, self.sections = graine, seconde_chance, banques, sections
        self.correction, self.revision = correction, revision
        self.entrainement = entrainement  # ni indice ni seconde chance ne coûtent de points : seuls les délais comptent
        self.sans_execution = sans_execution  # comme sur papier : pas de console, le code ne tourne qu'à la soumission
        self.acces_cours = acces_cours  # les élèves ont le cours sous la main : l'``aide_cours`` d'une question remplace son ``aide``
        self.dossier = dossier  # où vont ses exports, relatif au dossier du professeur (``sujet.sortie``) ; vide : Exports/
        self.sans_ide = sans_ide  # le .qcm d'un TP « sans IDE » : ses questions prennent ``electronique["sans_ide"]``
        self.surveillance = surveillance  # le lecteur noircit l'écran une minute à chaque sortie de l'épreuve (``Lecteur.sortir``)
        self.cours = cours or []  # les PDF du cours que le lecteur ouvre à côté des questions, relatifs au dossier du professeur (``PROF``)
        self.cours_pages = cours_pages  # le lecteur n'en montre que les premières pages, celles vues en classe (None : toutes)

    def problemes(self):
        """[(niveau, message)] : ce que la classe ne peut pas empêcher."""
        regles = [(self.destination in DESTINATIONS, f"destination « {self.destination} » : {', '.join(DESTINATIONS)}"),
                  (bool(self.titre), "titre vide"), (bool(self.banques), "aucune banque"),
                  (type(self.graine) is int, f"graine « {self.graine} » : un entier, propre au sujet (tirages et clé du .qcm)"),
                  (all(s.questions for s in self.sections) and bool(self.sections), "sections : au moins une, chacune avec des questions"),
                  (re.fullmatch(r"[A-Za-z0-9_.-]+\.py", self.fichier) is not None, f"fichier « {self.fichier} » : un nom en .py"),
                  (not self.date or re.fullmatch(r"\d{4}-\d\d-\d\d", self.date) is not None, f"date « {self.date} » : AAAA-MM-JJ"),
                  (self.duree_minutes is None or self.duree_minutes > 0, "duree_minutes : strictement positive"),
                  (self.affichage in ("sujet", "question"), f"affichage « {self.affichage} » : sujet ou question"),
                  (not self.cours or self.acces_cours, "cours sans acces_cours : le lecteur ne montre le cours qu'avec acces_cours"),
                  (all(c.lower().endswith(".pdf") for c in self.cours), f"cours {self.cours} : des fichiers .pdf"),
                  (self.cours_pages is None or (type(self.cours_pages) is int and self.cours_pages > 0 and self.cours),
                   f"cours_pages « {self.cours_pages} » : un nombre de pages strictement positif, avec un cours")]
        return [("erreur", message) for ok, message in regles if not ok]


# Les modes de soumission que porte un code de classe (``codes.code_classe``, demande de l'utilisateur, 28/09/2026), dans
# l'ordre où le lecteur les essaie : le numéro retourne les 3 bits de tête de la clé (``codes.variantes``). 0 est le code
# d'avant les modes, 4 le code de TP d'avant (bit de tête seul) : les codes déjà donnés s'ouvrent toujours.
SOUMISSIONS = {
    0: "Par question, à tout moment, avec rattrapage",
    4: "Globale dans le dernier quart du temps, avec rattrapage",
    1: "Par question, à tout moment, sans rattrapage",
    5: "Globale dans le dernier quart du temps, sans rattrapage",
    2: "À la fin seulement, sans correction",
    3: "À la fin seulement, correction après l'échéance",
}
RATTRAPAGE = {0, 4}  # une seconde chance à chaque question : celle du sujet, ou à défaut ``MALUS_RATTRAPAGE``
MALUS_RATTRAPAGE = 0.25
GLOBALES = {4, 5}  # « Corriger mes réponses » et « Rendre ma copie » attendent les 3/4 du temps, aucune question seule
FINALES = {2, 3}  # aucune question seule : rien n'est corrigé avant de rendre la copie
SANS_CORRECTION, DIFFEREE = 2, 3  # la correction jamais montrée, ou seulement après l'échéance (ou la fin de la durée)


class Paquet(Objet):
    """Le fichier que reçoit l'élève, chiffré : le sujet tiré pour lui, questions complètes, et — enregistrée à chaque
    réponse dans le même fichier — sa session (``courante``, ``debut``, ``fin``, et l'état de chaque question).

    ``affichage`` : « sujet » (tout sur un écran défilant) ou « question » (une par écran) ; ``retour`` : revenir sur une
    réponse soumise ; ``correction`` : note et correction en fin d'épreuve. Une question qui en révèle une autre n'apparaît
    qu'une fois celle-ci validée (ou figée par le passage à l'écran suivant). ``eleve`` : « Nom Prénom », saisi à l'ouverture.
    ``graine`` : celle du sujet tant que le paquet reste à préparer : un seul fichier pour la classe, ses questions telles
    que la banque les donne (une seule fois) avec les réglages du sujet (``date`` et ``revision`` de l'export,
    ``melanger_questions``, ``seconde_chance``, ``entrainement``, ``acces_cours``, ceux de ``DefinitionSujet``), que
    ``nommer`` applique pour chaque élève ; vide une fois préparé (la copie). C'est aussi, en clair, la sauvegarde d'un
    export PDF, dont ``sujet.lire`` refait la définition du sujet. ``inscrits`` : ``{classe: [[nom, prénom], …]}``, les
    élèves admis à ouvrir le sujet, reconnus à l'accueil par le code de leur classe (``codes``). ``note`` et ``appreciation`` :
    celles que le professeur écrit sur la copie rendue, dans l'entête ; sans ``note``, c'est celle de la machine qui s'affiche.
    Le paquet à préparer garde chaque question telle que le papier la pose, sa version pour l'écran à côté
    (``Question.electronique``, ``Section.electronique``) : un seul fichier sert au PDF qui l'embarque et au lecteur, qui
    prend la version pour l'écran à l'accueil (``nommer``) ; ``sans_ide`` : celle d'un TP « sans IDE »."""

    def __init__(self, titre, destination, sections, sous_titre="", theme="", matiere="", classe="", date="", consignes="",
                 duree_minutes=None, fichier="tp.py", contextes=None, medias=None, affichage="sujet", retour=True,
                 correction=True, courante=0, debut=None, fin=None, eleve="", graine="", sans_execution=False,
                 inscrits=None, revision="", melanger_questions=False, seconde_chance=None, entrainement=False,
                 acces_cours=False, note=None, appreciation="", empreinte="", heure_locale=False, sans_ide=False,
                 surveillance=False, sorties=None, soumission=None, cours=None, cours_pages=None, dossier="", limite=None, nom="", bases=None):
        self.titre, self.sous_titre, self.theme, self.matiere, self.classe = titre, sous_titre, theme, matiere, classe
        self.sans_ide, self.surveillance = sans_ide, surveillance
        self.dossier = dossier  # celui du sujet (``DefinitionSujet.dossier``) : ses copies vont à côté (``codes.chemin_copie``)
        # le nom du fichier du sujet, celui de son .qcm : il nomme les copies en ligne. Pas le titre, que deux sujets peuvent
        # partager (le projet Pyxel et ses questions bonus : copies confondues, 01/10/2026) ; vide dans un .qcm d'avant
        self.nom = nom
        # les PDF du cours (``DefinitionSujet.cours``), en onglets à côté des questions : pas dans le fichier, un même cours
        # sert à beaucoup de sujets (demande de l'utilisateur, 29/09/2026). Leurs chemins depuis le dossier du .qcm, le même sur
        # le disque du professeur et dans son Dropbox ; ``lire_cours(chemin)`` en rend les octets (None : introuvable), posé
        # par qui ouvre le paquet (``lecteur.Lecteur``, ``pont_qt``)
        self.cours, self.lire_cours = cours or [], lambda chemin: None
        self.cours_pages = cours_pages  # ``DefinitionSujet.cours_pages`` : au-delà, le lecteur ne montre rien
        # les sorties de l'épreuve (``lecteur.Lecteur.sortir``) : [départ, retour] en time.time(), départ None pour une copie
        # rouverte (page fermée ou rechargée), retour None si l'élève n'est pas revenu avant la fin
        self.sorties = sorties or []
        self.note, self.appreciation = note, appreciation
        # la copie d'un élève : l'empreinte de son code personnel (son contrôle lent, ``codes.inscrire`` : le lecteur web n'accepte plus d'autre
        # copie sous ce nom sans ce code), si l'heure de fin a été jugée sur l'horloge de l'ordinateur, faute de réseau, et
        # l'échéance du code de la première ouverture (en time.time()) : la copie rouverte la garde (l'utilisateur, 30/09/2026)
        self.empreinte, self.heure_locale, self.limite = empreinte, heure_locale, limite
        # le mode de soumission du code qui a ouvert le sujet (``SOUMISSIONS``, ``nommer``), None sans code ; ``retenir`` et
        # ``masquer`` le font respecter, au fil du chronomètre du lecteur
        self.soumission, self.retenue, self.masquee = soumission, False, soumission == DIFFEREE
        self.destination, self.consignes, self.duree_minutes, self.fichier = destination, consignes, duree_minutes, fichier
        self.contextes, self.medias, self.sections, self.date, self.revision = contextes or {}, medias or {}, sections, date, revision
        self.affichage, self.retour, self.correction = affichage, retour, correction
        self.courante, self.debut, self.fin, self.demarre, self.fige = courante, debut, fin, False, False
        self.ici = None  # la question où était l'élève à la dernière seconde : ``ecouler`` voit qu'il la quitte
        self.eleve, self.graine, self.sans_execution, self.inscrits = eleve, graine, sans_execution, inscrits or {}
        self.melanger_questions, self.seconde_chance = melanger_questions, seconde_chance
        self.entrainement, self.acces_cours = entrainement, acces_cours
        self.total = sum(q.total() for s in sections if not s.bonus for q in s.questions)
        self.bases = bases or {}
        MEDIAS.update(self.medias)
        afficher_contextes(self.questions(), self.contextes, self.affichage == "question")
        poser_bases(self.questions(), self.bases)
        for n, q in enumerate(self.questions(), 1):
            q.numeroter(n)
        self.feuilles = [f for q in self.questions() for f in q.feuilles()]
        self.cibles = {f.id: [f] for f in self.feuilles} | {q.id: q.feuilles() for q in self.questions()}
        # Les questions bonus avancent à part : finir les autres remplit la barre d'avancement, pas « presque tout ».
        self.feuilles_bonus = [f for s in sections if s.bonus for q in s.questions for f in q.feuilles()]
        self.pages = self.unites = self.questions()  # un écran par question en mode « question »
        premiere_externe = next((f for f in self.feuilles if getattr(f, "editeur_externe", False)), None)
        for f in self.feuilles:
            f.classe, f.projet, f.sans_execution = classe, destination == "projet", sans_execution
            f.premiere_externe = premiere_externe  # lue par les seules questions editeur_externe
            if f.projet:
                f._montrer_enonce()  # ses actions à cocher et ses codes à copier, que la question seule ignorait
            f.modifiable = retour and not self._fausse(f)
            f.changee.connect(self.rafraichir)
            f.changee.connect(functools.partial(self._suite, f))
            f.mettre_a_jour()
        self._construire()

    def __setstate__(self, etat):
        etat.pop("total", None)  # écrit par les exports d'avant le 26/09/2026 : il se calcule
        super().__setstate__(etat)

    def nommer(self, eleve, soumission=None):
        """Le paquet au nom de l'élève, préparé pour lui si ce n'est pas déjà fait (``graine``) : ``variables`` et mélanges
        tirés (graine du sujet, nom, id de la question), questions et sections dans leur version pour l'écran
        (``Question.version_electronique``), une seule aide (``acces_cours``), la seconde chance du sujet donnée
        à chaque question qui n'a pas la sienne (ajustée au hasard, ``Question.adapter_chance``), aucun malus pour un
        ``entrainement`` (la même banque sert à l'évaluation), questions mélangées si le sujet le demande et chacune après
        celles dont elle révèle la réponse. Tout est déterministe : le même élève retrouve le même sujet. Une copie, déjà
        préparée, est rendue telle quelle, sous SON nom : ``eleve`` ne la renomme pas (une copie passée à un camarade reste
        celle de son auteur, et l'élève n'a pas à retaper le sien, l'utilisateur, 30/09/2026).
        ``soumission``, le mode du code (``SOUMISSIONS``), est écrit dans la copie : avec rattrapage, la seconde chance du
        sujet ou à défaut une de ``MALUS_RATTRAPAGE`` ; sans, aucune ; ``SANS_CORRECTION`` retire la correction."""
        if not self.graine:
            self.eleve = self.eleve or eleve
            return self
        rattrapage = soumission is None or soumission in RATTRAPAGE
        chance = self.seconde_chance or (soumission is not None and SecondeChance(MALUS_RATTRAPAGE))
        correction = self.correction and soumission != SANS_CORRECTION
        graine = f"{self.graine}|{normaliser(eleve)}"
        groupe_de = {sq.id: q.id for q in self.questions() for sq in q.sous_questions}
        sections = []
        for s in self.sections:
            questions = [q.instancier(f"{graine}|{q.id}") for q in (q.version_electronique(self.sans_ide) for q in s.questions) if q]
            for f in (f for q in questions for f in q.feuilles()):
                f.garder_une_aide(self.acces_cours)
                f.seconde_chance = (f.seconde_chance or f.adapter_chance(chance)) if correction and rattrapage else SecondeChance(actif=False)
                if self.entrainement:
                    f.seconde_chance = f.seconde_chance and SecondeChance(0, f.seconde_chance.actif)
                    for i in f.indices:
                        i.malus = 0
            ordre = ordonner([(q,) for q in questions], groupe_de, self.melanger_questions and self.titre)
            textes = {"titre": s.titre, "consignes": s.consignes} | (s.electronique or {})
            sections.append(copier(s, sauf=("questions", "electronique"), imposes={"questions": [q for q, in ordre], **textes}))
        return copier(self, sauf=("sections",), imposes={"sections": sections, "graine": "", "eleve": eleve,
                                                          "correction": correction, "soumission": soumission})

    def entete(self):
        """Le texte de l'entête : titre en capitales, sous-titre. Les consignes n'y sont pas : elles ouvrent le sujet, qui
        défile, pour que l'entête ne garde pas leur hauteur une fois l'épreuve commencée."""
        return "\n\n".join(filter(None, [f"# {en_capitales(self.titre).replace(chr(10), '<br>')}", self.sous_titre and f"## {self.sous_titre}"]))

    def _construire(self):
        if self.fin is not None:
            self._montrer_fin()
        else:
            self.rafraichir()

    # -- crochets de l'affichage

    def _afficher_page(self, n):
        """Mode « question » : l'écran ``n``."""

    def _defiler(self, n, recadrer=False):
        """Mode « sujet » : fait défiler la vue jusqu'à la question ``n``. ``recadrer`` : seulement si une autre question
        est visible au-dessus d'elle ; jamais vers le haut, ce qui cacherait la correction au bas d'une longue question."""

    def _rafraichir_vue(self):
        """Barres d'avancement et boutons de navigation."""

    def _confirmer(self):
        """« Soumettre toutes les questions » : l'élève confirme."""
        return True

    def questions(self):
        return [q for s in self.sections for q in s.questions]

    def _page(self):
        return [self.pages[self.courante]] if self.affichage == "question" else self.questions()

    def demarrer(self):
        """L'élève commence : les questions visibles deviennent modifiables."""
        self.demarre = True
        self.debut = self.debut or horloge.secondes()  # l'heure en ligne : début et fin sont des dates de la copie, pas des durées
        self.rafraichir()

    def aller(self, n):
        """Écran ``n`` (mode « question ») : ce que ses questions révèlent est d'abord figé."""
        if not 0 <= n < len(self.pages) or (n < self.courante and not self.retour):
            return
        self.courante = n
        self._afficher_page(n)
        self.fige = True
        for f in (f for q in self._page() for f in q.feuilles()):
            for r in f.revele + self.pages[n].revele:
                for cible in self.cibles.get(r, []):
                    cible.geler()
        self.fige = False
        self.rafraichir()

    def _suite(self, feuille):
        """Après un changement de ``feuille``. Mode « sujet » : soumise, la vue se cale sur la question elle-même,
        pour qu'on relise l'énoncé et la correction (demande de l'utilisateur, 26/09/2026), puis l'élève avance par « Non
        traitée ». Mode « question » : une fois toutes les questions de l'écran closes, on passe au suivant, sauf avec
        ``correction`` (« Suivant »). Une confirmation ou une correction reste affichée sur chaque question soumise
        (demande de l'utilisateur, 26/09/2026 : plus seulement sur la dernière).
        ``geler`` émet aussi ``changee`` : ce qu'il fige (révélation, fin) n'enchaîne pas."""
        if self.fin is not None or self.fige:
            return
        fausse = self._fausse(feuille)
        if fausse:
            feuille.montrer_correction("#c0392b")
            feuille.modifiable = False  # la correction est vue : plus de retour possible
            feuille.mettre_a_jour()
        elif self.correction and feuille.fermee and feuille.corriger(feuille.saisie)[0] == 1:
            feuille.confirmer()
        if self.affichage == "sujet":
            if feuille.fermee:
                self.courante = next(n for n, q in enumerate(self.unites) if feuille in q.feuilles())
                self._defiler(self.courante, recadrer=True)
                self.rafraichir()
        elif not self.correction and all(f.fermee for f in self.pages[self.courante].feuilles()):
            self.aller(self.courante + 1)

    def _fausse(self, feuille):
        """Close sur une mauvaise réponse, dont la correction doit s'afficher."""
        return self.correction and feuille.fermee and feuille.corriger(feuille.saisie)[0] not in (1, None)

    def _libre(self, unite):
        """Une question (ou un écran) dont une feuille visible n'est ni validée ni soumise."""
        return any(not (f.fermee or f.repondue) and not f.cachee for f in unite.feuilles())

    def _voisine(self, sens):
        """Rang de la prochaine (``sens`` = 1) ou de la précédente (-1) question « non traitée », ou ``None``."""
        fin = len(self.unites) if sens > 0 else -1
        return next((n for n in range(self.courante + sens, fin, sens) if self._libre(self.unites[n])), None)

    def sauter(self, sens):
        """Va à la question voisine « non traitée » : à son écran, ou en la faisant défiler dans la vue."""
        n = self._voisine(sens)
        if n is None:
            return
        if self.affichage == "question":
            self.aller(n)
        else:
            self.courante = n
            self._defiler(n)
            self.rafraichir()

    def _devant(self):
        """La question ouverte où est l'élève : ici la première de l'écran ; le widget y ajoute la souris et ce que
        montre la vue."""
        return next((f for q in self._page() for f in q.feuilles() if f.actif and not (f.fermee or f.cachee)), None)

    def ecouler(self):
        """Une seconde de plus, appelée par le chronomètre du lecteur : le délai des indices ne court que sur la question
        où est l'élève (``_devant``), pas sur toutes les questions posées (demande de l'utilisateur, 27/09/2026) ; celle
        qu'il vient de quitter devient « traitée » si sa réponse est entière (``Question.quitter``)."""
        f = self._devant()
        if f is not self.ici:
            if self.ici is not None:
                self.ici.quitter()
            self.ici = f
        if f is not None and f.indice_delai():
            f.presence += 1
            f.mettre_a_jour()

    def retenir(self, oui):
        """Tant que ``oui``, ni « Corriger mes réponses » ni « Rendre ma copie » : la soumission globale attend les 3/4 du
        temps, et l'élève n'a aucune bonne réponse à donner à son voisin d'ici là (demande de l'utilisateur, 28/09/2026 ; le
        chronomètre du lecteur lève la retenue). Une question seule ne se soumet que dans un mode par question."""
        une_a_une = oui or self.soumission in GLOBALES | FINALES
        if oui == self.retenue and all(f.retenue == une_a_une for f in self.feuilles):
            return
        self.retenue = oui
        for f in self.feuilles:
            f.retenue = une_a_une
            f.mettre_a_jour()
        self.rafraichir()

    def masquer(self, oui):
        """Correction différée (``DIFFEREE``) : tant que ``oui``, la copie rendue ne montre ni correction ni note ; le
        chronomètre du lecteur lève le masque à l'échéance, et la fin se remontre avec elles."""
        if oui != self.masquee:
            self.masquee = oui
            if self.fin is not None:
                self._montrer_fin()

    def corrigee(self):
        """La correction et la note se montrent : le sujet le prévoit, et une correction différée a passé l'échéance."""
        return self.correction and not self.masquee

    def rafraichir(self):
        """Ce qui est visible (rien avant ce qu'il révèle, dans un groupe rien avant la précédente en mode « question »),
        ce qui commence à courir (délai des indices), et où en est l'avancement."""
        for q in self.questions():
            for f in (q, *q.sous_questions):
                cachee = any(not all(c.fermee for c in self.cibles.get(r, [])) for r in f.revele) and self.fin is None
                if self.affichage == "question" and f in q.sous_questions and self.fin is None:
                    avant = q.sous_questions[:q.sous_questions.index(f)]
                    cachee = cachee or not all(a.fermee for a in avant)
                f.montrer(not cachee)
                if not cachee and self.demarre and f in [x for p in self._page() for x in p.feuilles()]:
                    f.demarrer()
        self._rafraichir_vue()

    def resultat(self):
        """(points gagnés, points corrigés par la machine, points laissés au professeur) : sur ``total``."""
        obtenus = sum((f.obtenu or 0) + (f.justification_obtenue or 0) for f in self.feuilles)
        attente = sum((f.points if f.obtenu is None else 0)
                      + (f.justification.points if f.justification and f.justification_obtenue is None else 0)
                      for f in self.feuilles if f.fermee)
        return obtenus, self.total - attente, attente

    def bonus(self):
        """(points gagnés, points possibles) des sections ``bonus`` : ``resultat`` les compte dans les points gagnés."""
        return (sum((f.obtenu or 0) + (f.justification_obtenue or 0) for f in self.feuilles_bonus),
                sum(f.total() for f in self.feuilles_bonus))

    def statistiques(self):
        """Le bilan de la copie, axe par axe (``AXES``) : [(axe, [(libellé, points gagnés, points notés), …]), …], sur les
        seules questions déjà notées, bonus compris (elles disent aussi ce que l'élève sait faire). Une sous-question sans
        champ pédagogique prend ceux de son groupe. Les niveaux de Bloom dans l'ordre de la taxonomie, le reste du plus
        réussi au moins réussi ; un axe que le sujet ne renseigne pas est absent."""
        cumuls = {axe: {} for axe, _ in AXES}
        for q in self.questions():
            for f in q.feuilles():
                if f.obtenu is None:
                    continue
                for axe, relever in AXES:
                    for cle, poids in (relever(f) or relever(q)).items():
                        gagne, note = cumuls[axe].get(cle, (0, 0))
                        cumuls[axe][cle] = gagne + poids * f.obtenu, note + poids * f.points
        bilan = []
        for axe, _ in AXES:
            lignes = [(cle, g, n) for cle, (g, n) in cumuls[axe].items() if n]
            if axe == "Niveaux de Bloom":
                lignes = [(cle[1], g, n) for cle, g, n in sorted(lignes)]
            else:
                lignes.sort(key=lambda ligne: (-ligne[1] / ligne[2], ligne[0]))
            if lignes:
                bilan.append((axe, lignes))
        return bilan

    def rejouable(self):
        """Une seconde chance existe quelque part dans ce sujet : soumettre sans terminer a alors un sens (l'élève
        peut reprendre une réponse fausse) ; sinon « Corriger mes réponses » ne ferait que « Rendre ma copie » sans
        la note, et le bouton n'est pas montré."""
        return any(f.chance() for f in self.feuilles)

    def soumettre_tout(self, confirmer=True):
        """Le bouton « Corriger mes réponses » : chaque question encore ouverte est soumise comme si l'élève
        l'avait validée lui-même — donc une réponse fausse ouvre sa seconde chance, tant qu'il reste du temps. Seule
        la fin du temps (``terminer``) soumet définitivement. ``fige`` empêche la navigation automatique de s'emballer
        sur les dizaines de ``changee`` émis au passage ; le bouton se rallume s'il reste des secondes chances."""
        if confirmer and not self._confirmer():
            return
        self.fige = True
        for f in self.feuilles:
            if not f.fermee:
                f.demarrer()
                f.soumettre()
        self.fige = False
        self.rafraichir()

    def terminer(self):
        """Fin de l'épreuve : toute question encore ouverte est figée telle quelle, sans seconde chance — le temps
        écoulé ne laisse pas de rattrapage —, puis la note et la correction s'affichent. Le chronomètre appelle ceci."""
        self.fige = True
        for f in self.feuilles:
            f.geler()
        self.fige = False
        if self.fin is None:  # la date de rendu, dans la copie : une copie de fichiers ne la change pas (l'utilisateur, 30/09/2026)
            self.fin = horloge.secondes()
            self.heure_locale = self.heure_locale or not horloge.en_ligne()
        self._montrer_fin()

    def _montrer_fin(self):
        """L'épreuve finie : tout est figé et visible, avec la correction si ``corrigee``."""
        for f in self.feuilles:
            f.figer()
        for q in self.questions():
            for f in (q, *q.sous_questions):
                f.montrer(True)
        if self.corrigee():
            for q in self.questions():
                q.montrer_correction("#c0392b")
