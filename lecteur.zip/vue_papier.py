"""Le mode papier du lecteur : les pages d'un sujet telles qu'imprimées, peintes à l'écran par le code d'exporter_pdf,
avec des contrôles de réponse posés sur les cases, lignes, trous et cellules du papier (le professeur, 24/11/2026 :
« en fait la référence est toujours le qcm […] le pdf sert juste au rendu dans un lecteur de pdf »).

La géométrie vient de la même mise en page qu'à l'impression (``exporter_pdf.mettre_en_page``,
``positions_imprimees``) et les contrôles de la même table que le formulaire PDF (``formulaire_pdf.champs_du_sujet``) :
une seule source pour l'un et l'autre. Garde : les positions refaites à l'écran doivent être celles archivées dans le
PDF du sujet imprimé (mêmes polices, même code) ; sinon le papier montré ne serait pas celui que l'élève a eu."""
from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable

import exporter_pdf as E
import serializejson
from formulaire_pdf import champs_du_sujet, groupes_de_lignes, sans_coin
from qtpy6.QtCore import QByteArray, QDataStream, QPointF, QRectF, Qt, Signal
from qtpy6.QtGui import QColor, QFont, QImage, QPainter, QPen, QPicture
from qtpy6.QtWidgets import QAbstractButton, QButtonGroup, QLineEdit, QPlainTextEdit, QWidget

ECART = 12  # points : l'espace entre deux pages à l'écran
POLICE_ECRITURE = "Kalam"  # l'écriture de l'élève, comme dans le formulaire PDF
ENCRE = QColor(26, 60, 200)  # le bleu d'un stylo
MARGE_PUCE = 8  # points : autour d'une puce d'appariement, où un clic la désigne
TRANSFERABLES = {"choix_unique", "choix_multiples", "reponse_courte", "reponse_ouverte", "texte_a_trous", "tableau", "code",
                 "appariement", "figure_a_trous"}  # ``VuePapier.relier``
# Le format des pages enregistrées : celui de Qt 6.0, que lit tout Qt 6 ; le Qt du lecteur web (6.10) est plus vieux que
# celui qui écrit le média (6.11 en natif) et refuse un QPicture d'un format plus récent (rejoué vide, W1013, 24/11/2026).
FORMAT_PAGES = QDataStream.Version.Qt_6_0.value
PAGES = "pages_papier.json"  # le média du paquet : pages peintes et positions (``PagesPapier.enregistrer``)


class Coche(QAbstractButton):
    """Une case ou un rond du papier : transparent, il laisse voir la case imprimée et n'y trace, coché, qu'une croix
    à l'encre (un QCheckBox natif dessinerait sa propre case, décalée, par-dessus l'imprimée)."""

    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)

    def paintEvent(self, evenement) -> None:  # noqa: N802 - Qt
        if not self.isChecked():
            return
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.Antialiasing)
        peintre.setPen(QPen(ENCRE, max(1.5, self.width() / 7), Qt.SolidLine, Qt.RoundCap))
        r = QRectF(self.rect()).adjusted(self.width() * .2, self.height() * .2, -self.width() * .2, -self.height() * .2)
        peintre.drawLine(r.topLeft(), r.bottomRight())
        peintre.drawLine(r.topRight(), r.bottomLeft())
        peintre.end()


def champs_par_question(positions: dict[str, Any], questions: dict[str, Any] | None = None,
                        codes: dict[str, tuple[str, list[Any] | None]] | None = None,
                        figures: dict[str, tuple[float, float]] | None = None) -> dict[str, list[dict[str, Any]]]:
    """Les champs de chaque question (``formulaire_pdf.champs_du_sujet``), par identifiant : calculés à la mise en page et
    enregistrés avec elle, le lecteur n'a ni à relire la police Kalam (fontTools) ni à refaire ce calcul. Sans les champs
    d'un appariement (bouton, dessin, cache : les scripts du PDF) : l'écran le trace depuis ses puces (``positions``).
    ``questions`` (par identifiant) : chaque champ d'un trou ou d'une case de tableau reçoit sa ``cle``, celle de la
    saisie de sa feuille (``cles_imprimees``) ; ``codes`` (par identifiant, le code imprimé et ses morceaux à compléter) :
    chaque champ de lignes d'une question de code, de quoi rebâtir le code complet (``cuire_code``) ; ``figures`` (par
    identifiant, la largeur déclarée de l'image et celle d'une case, en points) : les cases d'une figure à trous
    (``cases_de_figure``)."""
    champs = {}
    for q in positions["questions"]:
        champs[q["id"]] = [c for c in champs_du_sujet({**positions, "questions": [q]}, identite=False)
                           if c["sorte"] in ("case", "radio", "texte")]
        question = (questions or {}).get(q["id"])
        if question is None:
            continue
        if question.type == "appariement" and (traits := champ_de_traits(q, question, 72 / positions["ppp"])):
            champs[q["id"]].append(traits)
        if question.type == "figure_a_trous" and q.get("figure") and q["id"] in (figures or {}):
            champs[q["id"]] += cases_de_figure(q, question, 72 / positions["ppp"], *figures[q["id"]])
        cles = cles_imprimees(question)
        if question.type == "code" and (code := (codes or {}).get(q["id"])) is not None:
            cuire_code(champs[q["id"]], q["id"], groupes_de_lignes(q.get("lignes", [])), *code)
        for sorte, prefixe, positionnees in (("trous", "_t", q.get("trous", [])), ("cellules", "_k", q.get("cellules", []))):
            if not positionnees or len(cles[sorte]) != len(positionnees):   # le test du type le voit (cles_imprimees)
                continue
            if sorte == "cellules":   # le coin d'en-tête, retiré des champs comme dans champs_du_sujet
                gardees = {id(c) for c in sans_coin(positionnees)}
                cles[sorte] = [k for k, c in zip(cles[sorte], positionnees) if id(c) in gardees]
            for champ in champs[q["id"]]:
                nom = champ["nom"][len(q["id"]):]
                if nom.startswith(prefixe) and nom[len(prefixe):].isdigit():
                    champ["cle"] = cles[sorte][int(nom[len(prefixe):])]
    return champs


def cases_de_figure(q: dict[str, Any], question: Any, k: float, largeur: float, case: float) -> list[dict[str, Any]]:
    """Les champs des cases d'une figure à trous : chaque case est dessinée dans l'image (``exporter_pdf.figure_a_trous``,
    centrée sur sa place, ``case`` points de large et 16 de haut à la taille déclarée ``largeur``) ; son rect sur la page
    se lit du rect imprimé de l'image (« figure », en px), l'image pouvant être réduite à la mise en page. Clé : le
    numéro du trou, comme ``{numéro: texte}`` d'un texte à trous."""
    page, (x0, y0, x1, y1) = q["figure"]["page"], [v * k for v in q["figure"]["rect"]]
    echelle = (x1 - x0) / largeur
    champs = []
    for i, (n, (fx, fy)) in enumerate(question.places.items()):
        x, y = x0 + fx * (x1 - x0), y0 + fy * (y1 - y0)
        rect = [x - case * echelle / 2, y - 8 * echelle, x + case * echelle / 2, y + 8 * echelle]
        champs.append({"nom": f"{q['id']}_f{i}", "sorte": "texte", "widgets": [(page, rect)], "centre": True,
                       "taille": round(10 * echelle, 1), "cle": n})
    return champs


def champ_de_traits(q: dict[str, Any], question: Any, k: float) -> dict[str, Any] | None:
    """Le champ d'un appariement à l'écran : ses puces (centre en points, côté, rang de la ligne imprimée), un widget par
    page qui les couvre, et ``ordre`` (``exporter_pdf.t_appariement`` : position affichée -> indice dans les droites),
    de quoi écrire la saisie (``Traits``). Les puces viennent ligne par ligne, celle de gauche avant celle de droite, un
    distracteur sans puce de gauche ; un compte qui ne concorde pas : pas de champ (l'onglet Électronique reste)."""
    gauches, droites = len(question.paires), len(question.paires) + len(question.distracteurs)
    if len(q.get("puces", [])) != gauches + droites:
        return None
    cotes = [(c, i) for i in range(droites) for c in ("g", "d") if c == "d" or i < gauches]
    puces = [{"page": p["page"], "x": (p["rect"][0] + p["rect"][2]) / 2 * k, "y": (p["rect"][1] + p["rect"][3]) / 2 * k,
              "cote": c, "rang": i} for p, (c, i) in zip(q["puces"], cotes)]
    widgets = []
    for page in sorted({p["page"] for p in puces}):
        xs, ys = [p["x"] for p in puces if p["page"] == page], [p["y"] for p in puces if p["page"] == page]
        widgets.append((page, [min(xs) - MARGE_PUCE, min(ys) - MARGE_PUCE, max(xs) + MARGE_PUCE, max(ys) + MARGE_PUCE]))
    return {"nom": f"{q['id']}_a", "sorte": "traits", "widgets": widgets, "puces": puces,
            "ordre": list(E.melange(range(droites), question.graine)), "gauches": gauches}


def cuire_code(champs: list[dict[str, Any]], qid: str, groupes: list[Any], initial: str, morceaux: list[Any] | None) -> None:
    """Le code complet d'une question de code se rebâtit de ses lignes écrites comme la correction le relève
    (``transcrire_papier``, « lecture ») : le code imprimé recopié, et à la place de chaque ligne « # à compléter » ce
    qui est écrit sur ses lignes, après son début de ligne imprimé (``exporter_pdf.code_a_completer``). Chaque champ de
    lignes reçoit ``rangs`` (le rang du morceau à compléter de chacune de ses lignes imprimées ; ``cle`` : le premier)
    et ``code`` (le code
    imprimé : ses morceaux, ou tout le code donné suivi des lignes libres). Lignes et morceaux qui ne concordent pas
    (autant de lignes que le code en attend) : pas de clé, le champ reste un texte libre."""
    lignes = [c for c in champs if c["nom"].startswith(qid + "_l")]
    if morceaux is None:
        for c in lignes:
            c["cle"], c["code"] = 0, [initial.rstrip() + "\n" if initial.strip() else "", [0, "", 0, 0, 0]]
        return
    a_ecrire = [m for m in morceaux if not isinstance(m, str)]
    if len(lignes) != len(groupes) or sum(len(g) for _, g in groupes) != sum(m[2] for m in a_ecrire):
        return
    debuts, rang = [], 0
    for m in a_ecrire:
        debuts.append(rang)
        rang += m[2]
    rang = 0
    for c, (_, g) in zip(lignes, groupes):   # un groupe peut couvrir deux marques : le rang de chaque ligne imprimée
        c["rangs"] = [max(i for i, d in enumerate(debuts) if d <= r) for r in range(rang, rang + len(g))]
        c["cle"], c["code"] = c["rangs"][0], [list(m) if not isinstance(m, str) else m for m in morceaux]
        rang += len(g)


def code_rebati(code: list[Any], ecrits: dict[int, list[str]]) -> str | None:
    """Le code complet (``cuire_code``) : les morceaux imprimés tels quels, et chaque morceau à compléter remplacé par
    ses lignes écrites, au retrait de la marque, la première après son début de ligne imprimé. Rien d'écrit : None."""
    if not any(t.strip() for textes in ecrits.values() for t in textes):
        return None
    sortie, rang = [], 0
    for m in code:
        if isinstance(m, str):
            sortie.append(m.rstrip("\n") + "\n" if m.strip() else m)
            continue
        retrait, debut = " " * m[0], m[1]
        texte = "\n".join(ecrits.get(rang, [])).rstrip("\n")
        rang += 1
        lignes = texte.split("\n") if texte.strip() else [""]
        sortie += [(retrait + (debut if i == 0 else "") + l).rstrip() + "\n" for i, l in enumerate(lignes)]
    return "".join(sortie).rstrip("\n") + "\n"


def cles_imprimees(q: Any) -> dict[str, list[str | None]]:
    """La clé de saisie de chaque trou et de chaque case vide d'une question, dans l'ordre où ``exporter_pdf`` les
    imprime et les relève (``positions_imprimees`` : « trous », « cellules »). Trous : le numéro de chaque trou libre
    (un trou à ses propres propositions s'entoure, sans champ) ; cases : « ligne,colonne » de chaque case vide, ligne
    par ligne, deux lignes libres en plus (``t_tableau``), None pour une case vide qui n'est pas à remplir (le coin de
    l'en-tête). Un trou à entourer et une case à pion restent dans l'onglet Électronique."""
    trous, cellules = [], []
    if q.type == "texte_a_trous":
        for n in q.MARQUEUR.findall(q.texte):
            cle = next((k for k in q.trous if str(k) == n), n)
            if not (q.trous.get(cle) and q.trous[cle].choix):
                trous.append(cle)
    elif q.type == "tableau" and not (q.frise and not q._problemes_frise()):
        if q.a_entete():
            cellules += [None for e in q.colonnes if not str(e).strip()]
        for r in range(len(q.lignes) + 2 * bool(q.lignes_libres)):
            m = min(r, len(q.lignes) - 1)
            for c in range(len(q.colonnes)):
                trou = q.cellules.get(f"{m},{c}")
                if q.en_pion(trou) or (trou and trou.choix):
                    continue
                if not str(q.case(r, c) or "").strip():
                    cellules.append(f"{r},{c}" if trou else None)
    return {"trous": trous, "cellules": cellules}


def peindre_ecriture(peintre: QPainter, ecriture: dict[str, Any] | None, largeur: float = E.LARGEUR) -> None:
    """L'écriture de l'élève sur une page (repère du peintre : ``largeur`` unités de large) : une page de
    ``analyse["ecriture"]`` d'une copie papier (``copie_papier.ecriture_de`` : le JPEG des couleurs, le masque PNG de
    l'opacité, la boîte en pixels du scan, large de ``taille[0]``)."""
    if not ecriture or not ecriture.get("boite"):
        return
    peintre.save()
    peintre.scale(largeur / ecriture["taille"][0], largeur / ecriture["taille"][0])   # en pixels du scan
    peintre.setRenderHint(QPainter.SmoothPixmapTransform)
    couleurs = QImage.fromData(ecriture["couleurs"]).convertToFormat(QImage.Format_ARGB32)
    couleurs.setAlphaChannel(QImage.fromData(ecriture["opacite"]).convertToFormat(QImage.Format_Grayscale8))
    x0, y0, x1, y1 = ecriture["boite"]
    peintre.drawImage(QRectF(x0, y0, x1 - x0, y1 - y0), couleurs)
    peintre.restore()


def ecriture(analyse: dict[str, Any]) -> Callable[[QPainter, int], None]:
    """La fonction ``(peintre, i)`` qui peint l'écriture de l'élève sur la page ``i`` (à partir de 0) de sa copie papier :
    le ``sous`` de ``PagesEnregistrees`` (le média ne la porte pas, l'analyse de la copie l'a déjà)."""
    pages = {p["page"]: p for p in analyse.get("ecriture", ())}
    return lambda peintre, i: peindre_ecriture(peintre, pages.get(i + 1))


def contient(refaites: dict[str, Any], archive: dict[str, Any]) -> bool:
    """Les positions refaites sont celles de l'archive, à ceci près qu'une question peut y avoir gagné des lignes de
    réponse que le code de l'impression ne relevait pas encore (la réponse courte, 24/11/2026) : la page est la même."""
    if {k: v for k, v in refaites.items() if k != "questions"} != {k: v for k, v in archive.items() if k != "questions"}:
        return False
    if len(refaites.get("questions", [])) != len(archive.get("questions", [])):
        return False
    for neuve, ancienne in zip(refaites.get("questions", []), archive.get("questions", [])):
        for cle in neuve.keys() | ancienne.keys():
            if neuve.get(cle) != ancienne.get(cle) and not (cle == "lignes" and not ancienne.get(cle)):
                return False
    return True


class PagesPapier:
    """La mise en page élève d'un sujet (sujet .json, .qcm ou PDF qui le joint) et ses positions. ``archive`` : le
    positions.json du sujet imprimé ; s'il est donné, le thème est réduit comme à l'export jusqu'à le retrouver, et
    ``conforme`` dit si on l'a retrouvé."""

    def __init__(self, chemin: Path | str, archive: dict[str, Any] | None = None) -> None:
        sujet = E.Sujet(Path(chemin))
        images = {n: E.charger_image(m) for n, m in sujet.medias.items() if n.rsplit(".", 1)[-1].lower() in E.IMAGES}
        svgs = {n: m for n, m in sujet.medias.items() if n.lower().endswith(".svg")}
        if sujet.definition.destination in ("tp", "projet", "electronique") and sujet.logo:
            images[E.LOGO] = QImage(str(sujet.logo))
        gris = {n: E.sur_blanc(i).convertToFormat(QImage.Format_Grayscale8) for n, i in images.items()}
        self.total = E.points(sujet.total)
        self.identite = (None, None, "")
        tailles = E.TAILLES_THEME_BANDEAU if sujet.definition.destination == "electronique" else E.TAILLES_THEME
        for taille in tailles:  # le thème réduit à l'export contre un recto seul (``exporter``) : celui de l'archive
            rendu = E.Rendu(sujet, images, False, frozenset())
            rendu.taille_theme = taille
            contenu = E.noir_et_blanc(rendu.document())
            self.figures = {n: E.svg_gris(o) for n, o in (svgs | rendu.figures).items()}
            self.mise = E.mettre_en_page(contenu, gris, self.figures, None, False, self.total, rendu.tableaux)
            self.positions = E.positions_imprimees(self.mise.document, rendu.imprimees, self.mise.traits, self.identite,
                                                   self.mise.pages, E.appareil_de_mesure())
            self.conforme = archive is None or contient(self.positions, archive)
            if self.conforme:
                break
        questions = {q.id: q for _, q in rendu.imprimees if q is not None}
        codes = {}   # comme ``Rendu.t_code`` : le code donné tel qu'imprimé, et ses morceaux à compléter
        for q in questions.values():
            if q.type == "code" and not rendu.projet and not q.nom_fichier:
                initial = E.sans_marque_modifier(rendu.sans_reprises(q, q.code_initial))
                codes[q.id] = (initial, E.code_a_completer(initial, rendu.sans_reprises(q, q.solution)))
        figures = {q.id: (E.pouces_de_figure(sujet.medias[q.image]) * 72, E.largeur_case_figure(q))
                   for q in questions.values() if q.type == "figure_a_trous" and q.image in sujet.medias}
        self.champs = champs_par_question(self.positions, questions, codes, figures)
        self.pied = titre = E.titre_complet(sujet.definition, frozenset())
        self.titre = titre

    def peindre(self, peintre: QPainter, i: int) -> None:
        """La page ``i`` (à partir de 0) dans le repère A4 en points."""
        E.peindre_page(peintre, self.mise, i, self.figures, self.pied, self.identite, self.total)

    def enregistrer(self, dessus: Callable[[QPainter, int], None] | None = None,
                    calques: Callable[[int], bytes | None] | None = None) -> bytes:
        """Les pages peintes (QPicture, vectorielles) et leurs positions, pour le média ``PAGES`` du paquet : le lecteur
        les rejoue sans refaire la mise en page (le professeur, 24/11/2026 : « on ne peut pas avoir des choses
        pré-calculées dans les qcm ? » ; 4,7 s refaite, 0,07 s rejouée, sous charge). ``dessus`` peint ensuite sur chaque
        page ce que la copie y ajoute (``correction/calque_qt.dessus`` : les rectangles blancs de sa correction) ;
        ``calques(i)``, une image PNG de la page entière que le lecteur multiplie dessus, ou None (``calque_qt.encre_png`` :
        l'encre de la correction, que le ``QPicture`` garderait brute, 1,2 Mo pour 6 pages)."""
        dessins = []
        for i in range(self.mise.pages):
            dessin = QPicture(FORMAT_PAGES)
            peintre = QPainter(dessin)
            self.peindre(peintre, i)
            if dessus is not None:
                dessus(peintre, i)
            peintre.end()
            dessins.append(bytes(dessin.data()))
        contenu = {"positions": self.positions, "champs": self.champs, "pages": dessins}
        if calques is not None:
            contenu["calques"] = [calques(i) for i in range(self.mise.pages)]
        return serializejson.dumps(contenu).encode()


class PagesEnregistrees:
    """Les pages de ``PagesPapier.enregistrer``, rejouées : ce que ``VuePapier`` en lit, sans mise en page. ``sous`` peint
    sur chaque page, avant son calque, ce que le média ne porte pas (``calque_qt.dessus`` : l'écriture de l'élève, que
    son ``.qcm`` porte déjà)."""

    def __init__(self, octets: bytes, sous: Callable[[QPainter, int], None] | None = None) -> None:
        contenu = serializejson.loads(octets.decode())
        self.positions = contenu["positions"]
        self.champs = contenu.get("champs") or champs_par_question(self.positions)   # un média d'avant le 24/11 au soir
        self.dessins = []
        for donnees in contenu["pages"]:
            dessin = QPicture()
            dessin.setData(QByteArray(donnees))
            self.dessins.append(dessin)
        self.calques = [QImage.fromData(c) if c else None for c in contenu.get("calques") or [None] * len(self.dessins)]
        self.sous = sous
        self.mise = SimpleNamespace(pages=len(self.dessins))

    def peindre(self, peintre: QPainter, i: int) -> None:
        self.dessins[i].play(peintre)
        if self.sous is not None:
            self.sous(peintre, i)
        if self.calques[i] is not None:   # l'encre de la correction, multipliée comme le feutre sur le papier
            calque = self.calques[i]
            peintre.save()
            peintre.setRenderHint(QPainter.SmoothPixmapTransform)
            peintre.setCompositionMode(QPainter.CompositionMode_Multiply)
            peintre.drawImage(QRectF(0, 0, E.LARGEUR, E.LARGEUR * calque.height() / calque.width()), calque)
            peintre.restore()


def pages(sujet: Path | str, medias: dict[str, bytes] | None = None,
          sous: Callable[[QPainter, int], None] | None = None) -> PagesPapier | PagesEnregistrees:
    """Celles du média ``PAGES`` s'il est dans ``medias`` (``sous`` : voir ``PagesEnregistrees``), sinon la mise en
    page refaite."""
    if medias and PAGES in medias:
        return PagesEnregistrees(medias[PAGES], sous)
    return PagesPapier(sujet)


class Traits(QWidget):
    """Les puces d'un appariement sur une page : un clic sur une puce de gauche puis sur une de droite les relie d'un
    trait à l'encre, comme au stylo ; un clic sur une puce déjà reliée défait son trait. Les widgets d'une même question
    (une par page) partagent ses liens (``champ["liens"]`` : rang de gauche -> rang affiché de droite)."""

    change = Signal()

    def __init__(self, parent: QWidget, champ: dict[str, Any], k: int) -> None:
        super().__init__(parent)
        self.champ, (self.page, self.rect) = champ, champ["widgets"][k]
        champ.setdefault("liens", {})
        champ.setdefault("vues", []).append(self)
        self.attente: int | None = None

    @staticmethod
    def lire(champ: dict[str, Any], saisie: list[int | None] | None) -> None:
        """Les liens d'une saisie déjà faite (à l'écran électronique) : chaque indice de droite à sa position affichée."""
        champ["liens"] = {g: champ["ordre"].index(d) for g, d in enumerate(saisie or []) if d in champ["ordre"]}
        for vue in champ.get("vues", []):
            vue.update()

    def saisie(self) -> list[int | None]:
        liens = self.champ["liens"]
        return [self.champ["ordre"][liens[g]] if g in liens else None for g in range(self.champ["gauches"])]

    def _local(self, puce: dict[str, Any]) -> QPointF:
        z = self.parent().zoom
        return QPointF((puce["x"] - self.rect[0]) * z, (puce["y"] - self.rect[1]) * z)

    def mousePressEvent(self, evenement) -> None:  # noqa: N802 - Qt
        if not self.isEnabled():
            return
        z, pos = self.parent().zoom, evenement.position()
        ici = [p for p in self.champ["puces"] if p["page"] == self.page]
        puce = min(ici, key=lambda p: (self._local(p) - pos).manhattanLength(), default=None)
        if puce is None or (self._local(puce) - pos).manhattanLength() > 2 * MARGE_PUCE * z:
            return
        liens, attente = self.champ["liens"], self.champ.get("attente")
        if puce["cote"] == "g":
            liens.pop(puce["rang"], None)
            self.champ["attente"] = puce["rang"]
        elif attente is not None:
            liens[attente] = puce["rang"]
            self.champ["attente"] = None
        else:
            for g in [g for g, d in liens.items() if d == puce["rang"]]:
                del liens[g]
        for vue in self.champ["vues"]:
            vue.update()
        self.change.emit()

    def paintEvent(self, evenement) -> None:  # noqa: N802 - Qt
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.Antialiasing)
        peintre.setPen(QPen(ENCRE, max(1.0, 1.2 * self.parent().zoom)))
        ici = {(p["cote"], p["rang"]): p for p in self.champ["puces"] if p["page"] == self.page}
        for g, d in self.champ["liens"].items():
            if ("g", g) in ici and ("d", d) in ici:
                peintre.drawLine(self._local(ici["g", g]), self._local(ici["d", d]))
        if (attente := self.champ.get("attente")) is not None and ("g", attente) in ici:
            peintre.drawEllipse(self._local(ici["g", attente]), 3 * self.parent().zoom, 3 * self.parent().zoom)
        peintre.end()


class VuePapier(QWidget):
    """Les pages l'une sous l'autre, à ``zoom`` pixels par point, et un contrôle par champ des questions ``ouvertes``
    (toutes si None) : les autres restent telles que peintes."""

    def __init__(self, pages: PagesPapier, ouvertes: set[str] | None = None, zoom: float = 1.5,
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.pages, self.zoom = pages, zoom
        self.champs = [dict(c) for qid, champs in pages.champs.items() if ouvertes is None or qid in ouvertes for c in champs]
        # des copies : l'état d'un appariement (``Traits``) n'entre pas dans les pages enregistrées
        self.controles: list[tuple[QWidget, int, list[float], dict[str, Any]]] = []  # (contrôle, page, rect, champ)
        self.groupes: dict[str, QButtonGroup] = {}
        for champ in self.champs:
            for k, (page, rect) in enumerate(champ["widgets"]):
                controle = self._controle(champ, k)
                if controle is not None:
                    self.controles.append((controle, page, rect, champ))
        self._placer()

    def _controle(self, champ: dict[str, Any], k: int) -> QWidget | None:
        sorte = champ["sorte"]
        if sorte == "case":
            return Coche(self)
        if sorte == "radio":
            bouton = Coche(self)
            groupe = self.groupes.setdefault(champ["nom"], QButtonGroup(self))
            groupe.addButton(bouton, k)
            return bouton
        if sorte == "texte":
            controle = QPlainTextEdit(self) if champ.get("multiligne") else QLineEdit(self)
            if isinstance(controle, QLineEdit):  # l'écriture posée sur le trait, comme au stylo
                controle.setAlignment((Qt.AlignHCenter if champ.get("centre") else Qt.AlignLeft) | Qt.AlignBottom)
            controle.setStyleSheet(f"background: transparent; border: none; padding: 0; margin: 0; color: {ENCRE.name()};")
            if isinstance(controle, QLineEdit):
                controle.setTextMargins(0, 0, 0, 0)
            else:
                controle.document().setDocumentMargin(0)
                controle.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  # le texte en trop défile, sans barre sur le papier
            return controle
        if sorte == "traits":
            return Traits(self, champ, k)
        return None

    def _placer(self) -> None:
        z = self.zoom
        for controle, page, (x0, y0, x1, y1), champ in self.controles:
            haut = (page - 1) * (E.HAUTEUR + ECART)
            controle.setGeometry(round(x0 * z), round((haut + y0) * z), round((x1 - x0) * z), round((y1 - y0) * z))
            if champ["sorte"] == "texte":
                police = QFont(POLICE_ECRITURE)
                taille = champ.get("taille", 12)
                if not champ.get("multiligne"):  # Kalam monte haut : dans un trou, l'écriture tient dans le rect
                    taille = min(taille, (y1 - y0) * .55)
                police.setPixelSize(max(1, round(taille * z)))  # des points du papier en pixels
                controle.setFont(police)
        self.setFixedSize(round(E.LARGEUR * z), round((self.pages.mise.pages * (E.HAUTEUR + ECART) - ECART) * z))

    def regler_zoom(self, zoom: float) -> None:
        self.zoom = zoom
        self._placer()
        self.update()

    def paintEvent(self, evenement) -> None:  # noqa: N802 - Qt
        peintre = QPainter(self)
        peintre.setRenderHint(QPainter.Antialiasing)
        peintre.fillRect(self.rect(), QColor(160, 160, 160))
        for i in range(self.pages.mise.pages):
            haut = i * (E.HAUTEUR + ECART) * self.zoom
            if haut > evenement.rect().bottom() or haut + E.HAUTEUR * self.zoom < evenement.rect().top():
                continue
            peintre.save()
            peintre.translate(0, haut)
            peintre.scale(self.zoom, self.zoom)
            peintre.fillRect(QRectF(0, 0, E.LARGEUR, E.HAUTEUR), Qt.white)
            self.pages.peindre(peintre, i)
            peintre.restore()
        peintre.end()

    def relier(self, feuilles: list[Any]) -> None:
        """Chaque contrôle écrit, à chaque geste, la saisie de sa feuille (``saisie``, le setter du widget, au même
        format : l'indice de la proposition, la liste des indices, le texte) : la copie ``.qcm`` reste la référence, et
        s'enregistre comme depuis l'écran électronique (``changee``). Seuls les types de ``TRANSFERABLES``."""
        self.feuilles = {f.id: f for f in feuilles if f.type in TRANSFERABLES}
        self.par_nom = {champ["nom"]: champ for _, _, _, champ in self.controles}
        for controle, _, _, champ in self.controles:   # un trou ou une case remplis à l'écran électronique s'y lisent
            qid = max((i for i in self.feuilles if champ["nom"].startswith(i + "_")), key=len, default=None)
            if qid and champ["sorte"] == "traits":
                Traits.lire(champ, self.feuilles[qid].saisie)
            elif qid and champ.get("cle") is not None and self.feuilles[qid].type in ("texte_a_trous", "figure_a_trous", "tableau"):
                texte = str((self.feuilles[qid].saisie or {}).get(champ["cle"], ""))
                (controle.setPlainText if isinstance(controle, QPlainTextEdit) else controle.setText)(texte)
        self.actif: Callable[[], bool] = getattr(self, "actif", lambda: True)
        for controle, _, _, _ in self.controles:
            signal = (controle.change if isinstance(controle, Traits) else controle.toggled
                      if isinstance(controle, QAbstractButton) else controle.textChanged)
            signal.connect(self._transferer)

    def _transferer(self, *_: Any) -> None:
        valeurs, saisies, cles, traits = self.valeurs(), {}, {}, {}
        for nom, valeur in valeurs.items():
            qid = max((i for i in self.feuilles if nom == i or nom.startswith(i + "_")), key=len, default=None)
            if qid is None:
                continue
            reste = nom[len(qid):].lstrip("_")
            champ = self.par_nom.get(nom, {})
            if champ.get("sorte") == "traits":
                traits[qid] = valeur
                continue
            if isinstance(valeur, str) and "cle" in champ:   # un trou, une case de tableau, des lignes de code
                cles.setdefault(qid, []).append((champ, valeur))
            elif isinstance(valeur, str) and reste[:1] in ("l", "k", "t") or (isinstance(valeur, str) and not reste
                                                                             and not valeur.startswith("c")):
                saisies.setdefault(qid, []).append(valeur)
            elif valeur is True and reste.startswith("c"):
                saisies.setdefault(qid, []).append(int(reste[1:]))
            elif isinstance(valeur, str) and not reste and valeur.startswith("c"):   # un radio : « c<proposition> »
                saisies.setdefault(qid, []).append(int(valeur[1:]))
        for qid, f in self.feuilles.items():
            if f.fermee or not self.actif():   # rendue, en pause, en lecture seule : l'écran papier ne l'écrit plus
                for controle, _, _, champ in self.controles:
                    if champ["nom"] == qid or champ["nom"].startswith(qid + "_"):
                        controle.setEnabled(False)
                continue
            choix = f.type in ("choix_unique", "choix_multiples")   # une justification écrite à côté n'est pas le choix
            morceaux = [m for m in saisies.get(qid, []) if isinstance(m, int) == choix]
            if f.type == "choix_unique":
                saisie = morceaux[0] if morceaux else None
            elif f.type == "choix_multiples":
                saisie = sorted(morceaux) or None
            elif f.type == "appariement":   # pour chaque élément de gauche, l'indice de son élément de droite
                saisie = traits[qid] if any(v is not None for v in traits.get(qid, [])) else None
            elif f.type == "code" and cles.get(qid):
                ecrits = {}
                for champ, texte in cles[qid]:   # la i-ème ligne écrite à la marque de la i-ème ligne imprimée
                    rangs = champ.get("rangs") or [champ["cle"]]
                    for i, ligne in enumerate(texte.split("\n")):
                        ecrits.setdefault(rangs[min(i, len(rangs) - 1)], []).append(ligne)
                saisie = code_rebati(cles[qid][0][0]["code"], ecrits)
            elif f.type in ("texte_a_trous", "figure_a_trous", "tableau"):   # ``{numéro: texte}``, ``{"ligne,colonne": texte}``
                saisie = dict(f.saisie or {})
                for champ, texte in cles.get(qid, []):
                    if champ["cle"] is not None:
                        if texte.strip():
                            saisie[champ["cle"]] = texte.strip()
                        else:
                            saisie.pop(champ["cle"], None)
                saisie = saisie or None
            else:
                saisie = "\n".join(m for m in morceaux if m.strip()).strip() or None
            if f.saisie != saisie:
                f.saisie = saisie

    def valeurs(self) -> dict[str, Any]:
        """Ce que l'élève a saisi, par nom de champ (``champs_du_sujet``), comme les /V du formulaire PDF : True pour
        une case cochée, la valeur du bouton choisi pour un radio, le texte pour un champ de texte."""
        sortie: dict[str, Any] = {}
        for controle, _, _, champ in self.controles:
            if champ["sorte"] == "case":
                sortie[champ["nom"]] = controle.isChecked()
            elif isinstance(controle, Traits):
                sortie[champ["nom"]] = controle.saisie()
            elif isinstance(controle, (QLineEdit, QPlainTextEdit)):
                sortie[champ["nom"]] = controle.text() if isinstance(controle, QLineEdit) else controle.toPlainText()
        for nom, groupe in self.groupes.items():
            champ = next(c for c in self.champs if c["nom"] == nom)
            sortie[nom] = champ["valeurs"][groupe.checkedId()] if groupe.checkedId() >= 0 else None
        return sortie
