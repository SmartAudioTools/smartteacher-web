"""Tutoyer un sujet : les banques sont écrites à l'infinitif (les consignes : « Convertir… », « Compléter… ») et au
« vous » (tout ce qui s'adresse à l'élève : feedbacks, explications, indices, messages du programme) ; un sujet qui
pose ``adresse: "tu"`` (``DefinitionSujet``) les tutoie à l'export (``sujet.Sujet``) et le lecteur, les messages du
programme avec (``dire``). Décision de l'utilisateur, 04/10/2026 : « l'infinitif et le vous partout par défaut, et la
conversion en tu avec une variable globale au sujet ».

Seul le sens vous → tu est automatique, et seulement quand le sujet le demande : le texte par défaut est celui de la
banque, jamais converti, donc jamais faux. La conversion suit des règles (rôle de « vous » : sujet, complément,
après une préposition ; verbe conjugué ou impératif ; genre du nom après « votre ») et un lexique,
``referentiels/adresse.json`` : les verbes des banques (premier et deuxième groupes réguliers, troisième par modèles
de terminaison, irréguliers en entier) et le genre des noms. Une forme qu'elle ne sait pas traiter est signalée
(``tutoyer(texte, inconnus)``) : ``tests_modele.test_adresse_banques`` les cherche dans toutes les banques, une
banque neuve qui en apporte une la fait échouer, et le lexique s'enrichit. Le code (blocs, code en ligne), les
formules, le HTML et les ``{expressions}`` ne sont jamais touchés."""

import functools
import json
import re
from pathlib import Path

RACINE = Path(__file__).resolve().parent
LEXIQUE = json.loads((RACINE / "referentiels/adresse.json").read_text(encoding="utf-8"))

# Les champs de texte que lit l'élève : les seuls convertis. Le code (``solution``, ``tests``, ``code_initial``), les
# réponses attendues, les identifiants et la ``description`` d'une erreur (lue par le correcteur, à la 3e personne) ne le sont pas.
TEXTES = {"titre", "sous_titre", "consignes", "consigne", "enonce", "enonce_simplifie", "aide", "aide_cours", "explication",
          "feedback", "texte", "indice", "corrige", "contextes", "message"}
# une proposition, un élément à classer, un sommet sont des réponses ou des étiquettes, un texte à trous porte les trous :
# ils restent tels quels
NON_TEXTES_DE = {c: {"texte"} for c in ("Proposition", "Ordre", "Element", "Sommet", "TexteATrous", "FigureATrous")}

PROTEGE = re.compile(r"```.*?```|`[^`\n]*`|\$\$.*?\$\$|\$[^$\n]+\$|<[^>\n]*>|\{[^{}\n]*\}|\]\([^)\n]*\)|https?://\S+", re.S)
LETTRES = "A-Za-zÀ-ÖØ-öø-ÿœŒæÆ"
# Un retour à la ligne est un jeton à lui seul, que ``precedent`` ne saute pas : un début de ligne (après un bloc de code,
# devant une puce) commence une proposition.
JETON = re.compile(rf"\x00\d+\x00|[{LETTRES}]+|\n|[^\S\n]+|.", re.S)
MOT = re.compile(rf"[{LETTRES}]+")
VOYELLE = re.compile(r"[aeiouyéèêëàâîïôûùœh]", re.I)
APOSTROPHES = ("'", "’")
CLITIQUES = {"ne", "n", "le", "la", "les", "l", "en", "y", "lui", "leur", "me", "m", "nous", "vous", "se", "s"}
PREPOSITIONS = {"à", "de", "d", "pour", "chez", "avec", "sans", "par", "sur", "selon", "entre", "vers", "envers", "devant",
                "derrière", "contre", "après", "avant", "comme", "sauf", "malgré", "parmi"}
TOI_DEVANT = {"aussi", "seul", "seule", "seuls", "seules", "même", "mêmes", "tous", "toutes", "non", "oui", "seulement"}
# « que vous » au subjonctif : la forme en -iez y est celle du subjonctif (que tu calcules), sinon de l'imparfait
SUBJONCTIF = re.compile(r"\b(?:faut|faudra|faudrait|pour|afin|avant|bien|sans|veut|voudrait|souhaite|suffit|important|"
                        r"nécessaire|préférable|mieux|attend|attendons)\s+(?:qu[e']\s*|que\s+)$", re.I)
NON_VERBES = set(LEXIQUE["non_verbes"])
INDIRECTES = {"ce", "si", "s", "quel", "quelle", "quels", "quelles", "comment", "pourquoi", "où", "combien", "qu", "d", "à", "lequel",
              "laquelle", "lesquels", "lesquelles", "qui", "quoi"}


# ---- conjugaison : les formes de la deuxième personne d'un verbe du lexique

def _premier_groupe(inf):
    r = inf[:-2]
    fort, futur = r, inf  # le radical devant une terminaison muette (tu calcules, calcule), celui du futur
    if r.endswith("y"):
        fort = r[:-1] + "i"
        futur = fort + "er"
    elif m := re.search(r"é([^aeiouyéèêàâîôû]+)$", r):
        fort = r[:m.start()] + "è" + m.group(1)
    elif re.search(r"[aeiouyéèêàâîôû][^aeiouyéèêàâîôû]*e[^aeiouyéèêàâîôûr]$", r) or re.search(r"^[^aeiouy]*e[^aeiouyéèêàâîôûr]$", r):
        fort = r + r[-1] if inf in LEXIQUE["doublent"] else r[:-2] + "è" + r[-1]
        futur = fort + "er"
    long = r + "e" if r.endswith("g") else r[:-1] + "ç" if r.endswith("c") else r  # mangeais, commençais
    return dict(tu=fort + "es", vous=r + "ez", imp_tu=fort + "e", imp_vous=r + "ez", imparf_tu=long + "ais",
                imparf_vous=r + "iez", futur=futur, subj_tu=fort + "es", subj_vous=r + "iez")


def _deuxieme_groupe(inf):
    r = inf[:-2]
    return dict(tu=r + "is", vous=r + "issez", imp_tu=r + "is", imp_vous=r + "issez", imparf_tu=r + "issais",
                imparf_vous=r + "issiez", futur=inf, subj_tu=r + "isses", subj_vous=r + "issiez")


def _troisieme_groupe(inf, f):
    imparf = f.get("imparfait", f["vous"][:-2])
    subj = f.get("subj", imparf)
    return dict(tu=f["tu"], vous=f["vous"], imp_tu=f.get("imp_tu", f["tu"]), imp_vous=f.get("imp_vous", f["vous"]),
                imparf_tu=imparf + "ais", imparf_vous=imparf + "iez", futur=f["futur"],
                subj_tu=f.get("subj_tu", subj + "es"), subj_vous=f.get("subj_vous", imparf + "iez"))


@functools.cache
def formes(inf):
    """Les formes de la deuxième personne de l'infinitif ``inf`` (un verbe pronominal sans son « se »)."""
    if inf in LEXIQUE["irreguliers"]:
        f = _troisieme_groupe(inf, LEXIQUE["irreguliers"][inf])
    elif inf in LEXIQUE["deuxieme_groupe"]:
        f = _deuxieme_groupe(inf)
    elif inf.endswith("er") and inf != "aller":
        f = _premier_groupe(inf)
    else:
        fin = next((s for s in sorted(LEXIQUE["modeles"], key=len, reverse=True) if inf.endswith(s)), None)
        if fin is None:
            raise KeyError(f"{inf} : ni du premier groupe, ni du deuxième, ni d'un modèle de referentiels/adresse.json")
        base = inf[:-len(fin)]
        f = _troisieme_groupe(inf, {k: base + v for k, v in LEXIQUE["modeles"][fin].items()})
    f["inf"] = inf
    f["futur_tu"], f["futur_vous"] = f["futur"] + "as", f["futur"] + "ez"
    f["cond_tu"], f["cond_vous"] = f["futur"] + "ais", f["futur"] + "iez"
    return f


def verbes():
    return LEXIQUE["premier_groupe"] + LEXIQUE["deuxieme_groupe"] + LEXIQUE["troisieme_groupe"] + list(LEXIQUE["irreguliers"])


@functools.cache
def tables():
    """{nom: {forme: forme}} : ``sujet`` (vous calculez → tu calcules, tous les temps ; le subjonctif à part,
    ``subjonctif``, quand sa forme est celle de l'imparfait), ``imperatif`` (calculez → calcule), ``infinitif``
    (calculez, calcule → calculer) et leurs inverses (``sujet_inv``…), dont se sert ``outils/harmoniser_adresse.py``."""
    t = {n: {} for n in ("sujet", "subjonctif", "imperatif", "infinitif", "sujet_inv", "subjonctif_inv", "imperatif_inv")}
    for inf in verbes():
        f = formes(inf)
        for temps in ("", "imparf_", "futur_", "cond_"):
            t["sujet"].setdefault(f[temps + "vous" if temps else "vous"], f[temps + "tu" if temps else "tu"])
            t["sujet_inv"].setdefault(f[temps + "tu" if temps else "tu"], f[temps + "vous" if temps else "vous"])
        t["subjonctif"].setdefault(f["subj_vous"], f["subj_tu"])
        t["sujet"].setdefault(f["subj_vous"], f["subj_tu"])  # fassiez, ayez : le subjonctif n'a pas d'autre lecture
        t["subjonctif_inv"].setdefault(f["subj_tu"], f["subj_vous"])
        t["sujet_inv"].setdefault(f["subj_tu"], f["subj_vous"])
        if inf not in LEXIQUE["sans_imperatif"]:
            t["imperatif"].setdefault(f["imp_vous"], f["imp_tu"])
            t["imperatif_inv"].setdefault(f["imp_tu"], f["imp_vous"])
            t["infinitif"].setdefault(f["imp_vous"], inf)
            t["infinitif"].setdefault(f["imp_tu"], inf)
    return t


@functools.cache
def genres():
    g = {}
    for genre, mots in (("m", LEXIQUE["noms"]["masculins"]), ("f", LEXIQUE["noms"]["feminins"])):
        g.update(dict.fromkeys(mots, genre))
    return g


# ---- découpage : le texte en jetons, le code et les formules en un seul jeton opaque

def jetons(texte):
    proteges = []

    def mettre_de_cote(m):
        proteges.append(m.group(0))
        return f"\x00{len(proteges) - 1}\x00"
    t = JETON.findall(PROTEGE.sub(mettre_de_cote, texte))
    return [proteges[int(x[1:-1])] if x.startswith("\x00") else x for x in t], {i for i, x in enumerate(t) if x.startswith("\x00")}


class Phrase:
    """Les jetons d'un texte et la navigation de mot en mot ; ``rep`` : les remplacements, par indice de jeton."""

    def __init__(self, texte):
        self.t, self.code = jetons(texte)
        self.rep = {}
        self.colles = set()  # les espaces à retirer derrière une élision posée (t'aide)

    def mot(self, i):
        return i is not None and 0 <= i < len(self.t) and i not in self.code and MOT.fullmatch(self.t[i]) is not None

    def bas(self, i):
        return self.t[i].lower() if self.mot(i) else None

    def suivant(self, i):
        j = i + 1
        while j < len(self.t) and self.t[j].isspace() and self.t[j] != "\n":
            j += 1
        return j if j < len(self.t) else None

    def precedent(self, i):
        j = i - 1
        while j >= 0 and self.t[j].isspace() and self.t[j] != "\n":
            j -= 1
        return j if j >= 0 else None

    def mot_suivant(self, i):
        """Le mot qui suit, par-dessus une apostrophe (n'avez, l'écrire) ; None si autre chose suit."""
        j = self.suivant(i)
        if j is not None and self.t[j] in APOSTROPHES:
            j = self.suivant(j)
        return j if self.mot(j) else None

    def mot_precedent(self, i):
        j = self.precedent(i)
        if j is not None and self.t[j] in APOSTROPHES:
            j = self.precedent(j)
        return j if self.mot(j) else None

    def trait_avant(self, i):
        """Le mot accroché par un trait d'union juste avant (``calculez-vous`` : l'indice de ``calculez``), sinon None."""
        return i - 2 if i >= 2 and self.t[i - 1] == "-" and self.mot(i - 2) else None

    def trait_apres(self, i):
        return i + 2 if i + 2 < len(self.t) and self.t[i + 1] == "-" and self.mot(i + 2) else None

    def debut(self, i):
        """``i`` commence une proposition : début du texte, après une ponctuation, une puce, « et », « puis », « ne »…
        (« Faites attention », pas « les erreurs faites »)."""
        j = self.precedent(i)
        return j is None or self.t[j] in ".!?:;,(-*•\n" or self.bas(j) in ("et", "puis", "ou", "ne", "n", "alors", "donc")

    def phrase_apres(self, i):
        """Le texte de ``i`` à la fin de la phrase."""
        fin = i
        while fin < len(self.t) and self.t[fin] not in ".!?\n":
            fin += 1
        return "".join(self.t[i:fin + 1])

    def avant(self, i, n=60):
        return "".join(self.t[max(0, i - 40):i])[-n:]

    def apostrophe(self):
        return "’" if sum(x == "’" for x in self.t) > sum(x == "'" for x in self.t) else "'"

    def elider(self, i, mot):
        """``mot`` (te, le, se…) à l'indice ``i``, élidé devant une voyelle ou un h : t'aide."""
        j = self.mot_suivant(i)
        if j is not None and j == self.suivant(i) and VOYELLE.match(self.t[j]) and self.bas(j) not in LEXIQUE["h_aspires"]:
            self.rep[i] = mot[:-1] + self.apostrophe()
            self.colles.add(i)
        else:
            self.rep[i] = mot

    def texte(self):
        sortie, colle = [], False
        for i, x in enumerate(self.t):
            if colle and x.isspace():
                colle = False
                continue
            colle = i in self.colles
            sortie.append(self.rep.get(i, x))
        return "".join(sortie)


def casse(modele, mot):
    return mot[:1].upper() + mot[1:] if modele[:1].isupper() else mot


# ---- vous → tu

def tutoyer(texte, inconnus=None):
    """``texte`` (au « vous ») tutoyé. ``inconnus``, une liste : y sont ajoutées les formes que les règles et le
    lexique ne savent pas traiter (laissées telles quelles)."""
    if not isinstance(texte, str) or not re.search(r"\b(?:vous|votre|vos|vôtres?|faites|dites)\b|ez\b", texte, re.I):
        return texte
    p, tb = Phrase(texte), tables()
    signaler = (lambda quoi, i: inconnus.append(f"{quoi} : « …{p.avant(i, 40)}{p.phrase_apres(i)[:40]}… »")) \
        if inconnus is not None else (lambda quoi, i: None)
    convertis = set()  # les verbes déjà conjugués avec leur sujet
    for i, x in enumerate(p.t):
        if p.bas(i) != "vous" or i in p.rep:  # le second « vous » de « vous vous trompez » est déjà traité
            continue
        if (v := p.trait_avant(i)) is not None:  # avez-vous, demandez-vous
            verbe = p.bas(v)
            # une question (avez-vous… ?), sauf devant une interrogative indirecte : « Demandez-vous ce que… ? » reste un ordre
            n = p.mot_suivant(i)
            question = "?" in p.phrase_apres(i) and (n is None or p.bas(n) not in INDIRECTES)
            if verbe in tb["sujet"] and (question or verbe not in tb["imperatif"]):
                p.rep[v], p.rep[i] = casse(p.t[v], tb["sujet"][verbe]), casse(x, "tu")
            elif verbe in tb["imperatif"]:
                p.rep[v], p.rep[i] = casse(p.t[v], tb["imperatif"][verbe]), casse(x, "toi")
            else:
                signaler(f"{verbe}-vous", i)
            convertis.add(v)
            continue
        if (m := p.trait_apres(i)) is not None and p.bas(m) in ("même", "mêmes"):
            p.rep[i], p.rep[m] = casse(x, "toi"), "même"
            continue
        n = p.mot_suivant(i)
        if n is not None and p.bas(n) in ("plaît", "plait"):  # s'il vous plaît
            p.rep[i] = "te"
            continue
        av = p.mot_precedent(i)
        # le verbe dont « vous » serait le sujet, par-dessus ne et les pronoms compléments (vous ne l'avez pas)
        j, pronoms = n, []
        while j is not None and p.bas(j) in CLITIQUES and p.bas(j) != "y" or (j is not None and p.bas(j) == "y"):
            pronoms.append(j)
            j = p.mot_suivant(j)
        verbe = p.bas(j) if j is not None else None
        objet = av is not None and p.bas(av) in ("ne", "n") or (av is not None and p.bas(av) == "vous" and av in p.rep)
        if verbe in tb["sujet"] and not objet:
            subj = SUBJONCTIF.search(p.avant(i)) and verbe in tb["subjonctif"]
            p.rep[i] = casse(x, "tu")
            p.rep[j] = casse(p.t[j], tb["subjonctif" if subj else "sujet"][verbe])
            convertis.add(j)
            for k in pronoms:
                if p.bas(k) == "vous":  # vous vous trompez : tu te trompes
                    p.elider(k, "te")
            continue
        if av is not None and p.bas(av) in PREPOSITIONS:
            infinitif = verbe and re.search(r"(?:er|ir|re|oir)$", verbe) and verbe not in tb["sujet"]
            if infinitif or (n is not None and p.bas(n) in CLITIQUES - {"vous"}):
                p.elider(i, "te")  # de vous aider : de t'aider
            else:
                p.rep[i] = casse(x, "toi")  # chez vous, à vous de jouer
        elif n is None or p.bas(n) in TOI_DEVANT or (p.suivant(i) is not None and p.suivant(i) != n
                                                       and p.t[p.suivant(i)] not in APOSTROPHES):
            p.rep[i] = casse(x, "toi")  # en fin de proposition : c'est à toi
        elif verbe is not None and re.search(r"[eè]z$", verbe) and verbe not in NON_VERBES and verbe not in tb["imperatif"]:
            signaler(f"vous {verbe}", i)
        else:
            p.elider(i, casse(x, "te"))  # cela vous permet : cela te permet
    for i, x in enumerate(p.t):
        b = p.bas(i)
        if b is None or i in convertis or i in p.rep:
            continue
        if b in tb["imperatif"] and b not in NON_VERBES and (b.endswith("ez") or p.debut(i) or p.trait_apres(i) is not None):
            imp = tb["imperatif"][b]
            if (s := p.trait_apres(i)) is not None and p.bas(s) in ("en", "y") and imp[-1] in "ea":
                imp += "s"  # penses-y, vas-y
            p.rep[i] = casse(x, imp)
        elif b == "votre":
            p.rep[i] = casse(x, _possessif(p, i, signaler))
        elif b == "vos":
            p.rep[i] = casse(x, "tes")
        elif b in ("vôtre", "vôtres"):
            art = p.bas(p.mot_precedent(i)) if p.mot_precedent(i) is not None else ""
            p.rep[i] = {"la": "tienne", "les": "tiens"}.get(art, "tien")
        elif re.search(r"(?:ez|iez)$", b) and b not in NON_VERBES and not x[:1].isupper() or b in tb["sujet"] and b.endswith("ez"):
            signaler(b, i)
    return p.texte()


def _possessif(p, i, signaler):
    """ton ou ta, selon le nom (ou l'adjectif) qui suit « votre » ; ton devant une voyelle."""
    j = p.suivant(i)
    while j is not None and p.t[j] in ("*", "_"):  # **votre** dictionnaire
        j = p.suivant(j)
    j = j if p.mot(j) else None
    if j is None:
        signaler("votre", i)
        return "ton"
    if VOYELLE.match(p.t[j]) and p.bas(j) not in LEXIQUE["h_aspires"]:
        return "ton"
    adjectifs = LEXIQUE["adjectifs"]
    while j is not None:
        b = p.bas(j)
        if b in adjectifs["feminins"]:
            return "ta"
        if b in adjectifs["masculins"]:
            return "ton"
        if b in adjectifs["epicenes"]:
            j = p.mot_suivant(j)
            continue
        genre = genres().get(b) or genres().get(b[:-1] if b.endswith("s") else None)
        if genre:
            return "ta" if genre == "f" else "ton"
        break
    signaler(f"votre {p.t[j] if j is not None else ''}", i)
    return "ton"


# ---- les objets : questions, sujets

def tutoyer_objet(valeur, cle=None, classe=None, inconnus=None):
    """Une copie de ``valeur`` (question, section, définition de sujet, dict, liste) dont les champs de texte
    (``TEXTES``) sont tutoyés ; un objet est reconstruit par son ``__init__``, comme ``noyau.copier``. Un champ de
    texte resté à sa valeur par défaut (« Justifier votre réponse. ») l'est aussi."""
    from noyau import Objet, parametres
    if isinstance(valeur, str):
        texte = cle in TEXTES and cle not in NON_TEXTES_DE.get(classe, ())
        return tutoyer(valeur, inconnus) if texte else valeur
    if isinstance(valeur, list):
        return [tutoyer_objet(v, cle, classe, inconnus) for v in valeur]
    if isinstance(valeur, dict):
        return {k: tutoyer_objet(v, k if k in TEXTES or cle != "contextes" else cle, classe, inconnus) for k, v in valeur.items()}
    if isinstance(valeur, Objet):
        nom = type(valeur).__name__
        etat = valeur.__serializejson__()[2]
        defauts = {k: d for k, d in parametres(type(valeur)).items() if k not in etat and isinstance(d, str) and d}
        etat = {k: tutoyer_objet(v, k, nom, inconnus) for k, v in {**defauts, **etat}.items()}
        return type(valeur)(**etat)
    return valeur


# ---- les messages du programme

MODE = "vous"  # celui du sujet ouvert (lecteur) ou exporté (PDF) : ``adresser``


def adresser(adresse):
    global MODE
    MODE = adresse or "vous"


def dire(texte):
    """Un message du programme (écrit au « vous ») à l'adresse du sujet en cours."""
    return tutoyer(texte) if MODE == "tu" else texte
