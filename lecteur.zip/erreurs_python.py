"""Le message d'erreur de Python traduit et expliqué, pour la CORRECTION seulement.

Avant la soumission, l'élève ne voit que le message brut de Python (console, seconde chance) : c'est à lui de le
lire. Une fois la question corrigée, ``expliquer`` dit en français ce que le message signifie et sa cause la plus
probable (demande de l'utilisateur, 26/09/2026 : « pour ne pas qu'il puisse s'auto-corriger avec plus d'indication
que le message d'erreur Python avant la soumission »). Les messages sont ceux de Python 3.13, que ``verifier.py``
met en forme (« ligne 3 : erreur de syntaxe (…) », « ligne 4 : NameError : … »)."""

import builtins
import difflib
import keyword
import re

TYPES = {"str": "un texte (str)", "int": "un entier (int)", "float": "un nombre décimal (float)", "bool": "un booléen (bool)",
         "list": "une liste", "tuple": "un tuple", "dict": "un dictionnaire", "NoneType": "None",
         "function": "une fonction", "builtin_function_or_method": "une fonction"}


def _type(nom):
    return TYPES.get(nom, f"un objet de type {nom}")


def _nom_voisin(nom, source):
    """Le nom écrit dans le programme (ou une fonction de Python) le plus proche de ``nom``, ou ``None``."""
    noms = {n for n in re.findall(r"[A-Za-z_]\w*", source) if not keyword.iskeyword(n)} | set(dir(builtins))
    noms.discard(nom)
    meme = [n for n in noms if n.lower() == nom.lower()]
    return (meme or difflib.get_close_matches(nom, noms, n=1, cutoff=0.7) or [None])[0]


def _non_defini(m, source):
    nom = m["nom"]
    voisin = _nom_voisin(nom, source)
    if voisin:
        cause = f"Tu as sans doute voulu écrire `{voisin}` : Python distingue les majuscules des minuscules, et une seule lettre de différence fait un autre nom."
    else:
        cause = ("Causes fréquentes : une faute de frappe, une variable utilisée AVANT d'avoir reçu sa valeur, ou des "
                 "guillemets oubliés autour d'un texte.")
    return f"Python ne connaît aucune variable ni fonction nommée `{nom}`. {cause}"


# (motif sur le message brut, explication) : la première qui correspond l'emporte ; l'explication est un texte à
# formater par les groupes nommés du motif, ou une fonction (correspondance, source) -> texte.
REGLES = [
    # --- erreurs de syntaxe : le programme n'a pas pu démarrer
    (r"'(?P<o>[(\[{])' was never closed",
     "Une parenthèse (ou un crochet, une accolade) `{o}` ouverte sur cette ligne n'est jamais refermée : compte les "
     "symboles ouvrants et fermants."),
    (r"unmatched '(?P<f>[)\]}])'", "Il y a un `{f}` en trop : il ferme une parenthèse qui n'a jamais été ouverte."),
    (r"closing parenthesis '(?P<f>.)' does not match opening parenthesis '(?P<o>.)'",
     "Un `{o}` est refermé par un `{f}` : chaque symbole ouvrant se referme par le sien, ( par ), [ par ]."),
    (r"expected ':'", "Il manque les deux-points `:` à la fin de la ligne : `if`, `elif`, `else`, `for`, `while` et "
     "`def` se terminent toujours par `:`."),
    (r"expected an indented block after (?P<quoi>.+?) on line (?P<n>\d+)",
     "Après la ligne {n}, qui se termine par `:`, le bloc doit être décalé vers la droite (indenté) : ici la ligne "
     "suivante ne l'est pas."),
    (r"unexpected indent", "Cette ligne est décalée vers la droite alors qu'elle ne commence aucun bloc : aligne-la "
     "sur la ligne précédente."),
    (r"unindent does not match any outer indentation level",
     "Le décalage de cette ligne ne correspond à aucun bloc au-dessus : les lignes d'un même bloc doivent avoir "
     "exactement le même nombre d'espaces."),
    (r"unterminated (?:triple-quoted )?string literal", "Un texte est ouvert par un guillemet mais jamais refermé : "
     "il faut le même guillemet au début et à la fin."),
    (r"Maybe you meant '==' or ':=' instead of '='", "Dans une condition, on compare avec `==` ; un seul `=` sert à "
     "affecter une valeur à une variable."),
    (r"cannot assign to (?P<quoi>.+?)(?: here)?\.", "À gauche d'un `=`, il faut un nom de variable qui reçoit la "
     "valeur. Pour comparer, c'est `==`."),
    (r"Perhaps you forgot a comma", "Deux valeurs se suivent sans rien entre elles : il manque sans doute une "
     "virgule (dans une liste, entre les arguments d'une fonction…)."),
    (r"Missing parentheses in call to 'print'", "`print` est une fonction : ce qu'on affiche se met entre "
     "parenthèses, `print(...)`."),
    (r"invalid decimal literal", "Un nombre est collé à des lettres : un nom de variable ne commence pas par un "
     "chiffre, et une multiplication s'écrit avec `*` (`2 * x`, pas `2x`)."),
    (r"invalid character '(?P<c>.)'", "Le caractère `{c}` n'existe pas en Python : souvent un guillemet ou un tiret "
     "typographique copié d'un traitement de texte. Retape-le au clavier."),
    (r"'return' outside function", "`return` n'a de sens que dans une fonction : cette ligne n'est pas indentée "
     "sous le `def`."),
    (r"erreur de syntaxe \(invalid syntax\)", "Python ne comprend pas cette ligne : un mot-clé mal écrit, un "
     "opérateur ou une parenthèse qui manque… Si rien ne cloche, regarde aussi la fin de la ligne précédente."),
    # --- erreurs à l'exécution : le programme a démarré, puis s'est arrêté sur cette ligne
    (r"NameError : name '(?P<nom>\w+)' is not defined", _non_defini),
    (r"cannot access local variable '(?P<nom>\w+)'",
     "La fonction utilise la variable `{nom}` avant de lui avoir donné une valeur : dès qu'une fonction affecte une "
     "variable, celle-ci est locale, et celle du programme principal n'est plus visible."),
    (r"can't multiply sequence by non-int of type '(?P<t>\w+)'",
     "Un texte (ou une liste) est multiplié par {t_}. Souvent la valeur est un texte alors qu'on la croyait un "
     "nombre (elle vient d'`input()`, ou elle est entre guillemets) : convertis-la avec `float()` ou `int()`."),
    (r'can only concatenate str \(not "(?P<t>\w+)"\) to str',
     "On ajoute à un texte {t_} : `+` entre deux textes les colle, mais ne mélange pas texte et nombre. Convertis le "
     "nombre avec `str()`, ou sépare les valeurs par des virgules dans `print`."),
    (r"TypeError : .*'NoneType'",  # None + 1, 1 + None, None[0], for x in None…
     "Une valeur vaut `None` : c'est souvent le résultat d'une fonction qui ne renvoie rien (un `print` au lieu "
     "d'un `return`)."),
    (r"unsupported operand type\(s\) for (?P<op>\S+): '(?P<a>\w+)' and '(?P<b>\w+)'",
     "L'opération `{op}` ne s'applique pas entre {a_} et {b_}. Vérifie le type de chaque valeur : l'une est "
     "peut-être un texte qu'il faut convertir."),
    (r"'(?P<op>\S+)' not supported between instances of '(?P<a>\w+)' and '(?P<b>\w+)'",
     "On ne peut pas comparer {a_} et {b_} avec `{op}` : une des valeurs n'a pas le type attendu (un texte venu "
     "d'`input()` ?)."),
    (r"(?P<f>\S+)\(\) missing (?P<n>\d+) required positional arguments?",
     "La fonction `{f}` est appelée avec trop peu d'arguments : il en manque {n}. Compare l'appel avec la ligne `def`."),
    (r"(?P<f>\S+)\(\) takes (?P<n>\d+) positional arguments? but (?P<m>\d+) (?:was|were) given",
     "La fonction `{f}` attend {n} argument(s), elle en reçoit {m} : compare l'appel avec la ligne `def`."),
    (r"'(?P<t>\w+)' object is not callable",
     "Des parenthèses suivent {t_}, comme si c'était une fonction : un `*` oublié (`2(x + 1)`), ou une variable qui "
     "porte le nom d'une fonction."),
    (r"'(?P<t>\w+)' object is not subscriptable", "On prend un élément `[…]` d'{t_}, qui n'en a pas : seuls les "
     "textes, listes, tuples et dictionnaires s'indexent."),
    (r"'(?P<t>\w+)' object is not iterable", "`for` parcourt {t_}, qui ne se parcourt pas : pour compter jusqu'à un "
     "nombre, c'est `range(n)`."),
    (r"object of type '(?P<t>\w+)' has no len\(\)", "`len` ne s'applique pas à {t_} : seulement à un texte, une "
     "liste, un tuple, un dictionnaire."),
    (r"indices must be integers or slices, not float", "Un indice est un nombre décimal : il doit être entier. "
     "Utilise `//` (division entière) plutôt que `/`, ou `int()`."),
    (r"'(?P<t>\w+)' object does not support item assignment",
     "On modifie un élément d'{t_}, qui ne se modifie pas : il faut en construire un nouveau."),
    (r"unhashable type: '(?P<t>\w+)'", "{t_} ne peut pas servir de clé de dictionnaire : une clé doit être non "
     "modifiable (texte, nombre, tuple)."),
    (r"IndexError : (?:list|string|tuple) index out of range",
     "L'indice demandé n'existe pas : les indices vont de 0 à `len(...) - 1`. Vérifie la fin de la boucle "
     "(`range(len(t))`, pas `range(len(t) + 1)`) et le cas d'une liste vide."),
    (r"KeyError : (?P<cle>.+)", "La clé {cle} n'est pas dans le dictionnaire : vérifie son orthographe, ou teste "
     "d'abord sa présence avec `in`."),
    (r"ZeroDivisionError", "Une division par zéro : le diviseur vaut 0 (une liste vide dont on divise par la "
     "longueur ?)."),
    (r"invalid literal for int\(\) with base 10: (?P<v>.+)",
     "`int()` ne sait pas convertir le texte {v} en entier : il faut un texte fait de chiffres seulement (pour un "
     "nombre à virgule, `float()`)."),
    (r"could not convert string to float: (?P<v>.+)", "`float()` ne sait pas convertir le texte {v} en nombre : le "
     "séparateur décimal est le point, pas la virgule."),
    (r"ValueError : (?P<v>.+) is not in list", "`index` cherche {v}, qui n'est pas dans la liste : vérifie d'abord sa présence "
     "avec `in`."),
    (r"'(?P<t>\w+)' object has no attribute '(?P<a>\w+)'", "La méthode `{a}` n'existe pas pour {t_} : le nom est "
     "mal écrit, ou la valeur n'a pas le type que tu crois."),
    (r"RecursionError", "La fonction s'appelle elle-même sans jamais s'arrêter : il manque un cas de base, ou "
     "l'appel ne s'en rapproche pas."),
]
REGLES = [(re.compile(motif), texte) for motif, texte in REGLES]


def _expliquer_un(message, source):
    for motif, texte in REGLES:
        m = motif.search(message)
        if m:
            if callable(texte):
                return texte(m, source)
            groupes = m.groupdict()
            return texte.format(**groupes, **{f"{k}_": _type(v) for k, v in groupes.items()})
    return None


def expliquer(message, source=""):
    """Le Markdown de la correction pour ``message`` (ce que rend ``verifier_question``, paragraphes séparés par
    une ligne vide) : chaque erreur de Python reconnue, citée telle quelle puis expliquée ; ``""`` s'il n'y en a pas.
    ``source`` : le programme de l'élève, où chercher le nom qu'il a voulu écrire."""
    vues, blocs = set(), []
    for paragraphe in (message or "").split("\n\n"):
        explication = _expliquer_un(paragraphe, source)
        if explication and explication not in vues:
            vues.add(explication)
            blocs.append(f"`{paragraphe.strip()}`\n\n{explication}")
    return "\n\n".join(["**L'erreur de ton programme**", *blocs]) if blocs else ""
