#!/usr/bin/env python3
"""Exporte un sujet en PDF, en noir et blanc pour la photocopie (en couleur s'il le faut) : le sujet pour l'élève, et
son corrigé avec le barème (voir README.md).

Usage :  python exporter_pdf.py [sujets/exemple_papier.json ...] [-o dossier] [-e eleves.csv] [-c classe] [-a amenagements]
Sans argument : tous les sujets de ``sujets/``. Les PDF vont dans le dossier du cours que nomme le ``dossier`` du sujet,
sinon dans ``Exports/pdf/`` (ou dans le dossier donné),
sous le nom du sujet : ``exemple_papier.pdf`` (élève) et ``exemple_papier - corrigé.pdf`` (corrigé), en noir et blanc
— le corrigé garde sa correction en vert. Un sujet dont une question exige la couleur (``couleur_obligatoire``) sort
en couleur seulement : ``exemple_papier (couleur).pdf`` et ``exemple_papier - corrigé (couleur).pdf``.
Avec ``-e``, une copie par élève du CSV (colonnes Nom, Prénom, Classe facultative), imprimés tout en haut de chaque
page (une copie anonyme y porte des champs à remplir, encadrés et marqués d’un panneau attention),
valeurs aléatoires propres à l'élève : ``Exports/pdf/exemple_papier/NOM_Prenom.pdf`` et `` - corrigé.pdf``.
Chaque PDF, élève comme corrigé, embarque en pièce jointe le ``.qcm`` du sujet, chiffré comme celui des élèves : de quoi
regénérer ces PDF quand la banque aura changé, puisqu'un PDF s'exporte comme un sujet, tout comme un ``.qcm``.
Une seconde pièce jointe, ``plan.json`` (``plan_des_cases``), donne la page et le rectangle de chaque case à remplir
d'une grille de conversion, relevés à la mise en page : la correction papier y retrouve chaque case.
Aménagements (élèves à besoins particuliers, liste dans ``--help``) : ``-a agrandi,indices`` pour toutes les
copies, ou une colonne ``Aménagements`` du CSV par élève ; sans ``-e``, le nom du fichier les porte (``nom_agrandi.pdf``).

Rendu par Qt (qtpy6, PySide6, sans écran) : le sujet est assemblé en HTML, mis en page par QTextDocument,
peint page par page dans un QPdfWriter, numéro « page x / y » en haut à droite. Markdown par le module
``markdown``, coloration du code par ``texte_md.colorer`` (tokenize). Les mélanges (propositions, éléments à ordonner,
questions si ``melanger_questions``) sont tirés d'une graine fixe : deux exports donnent le même PDF.
"""

import argparse
import base64
import csv
import difflib
import html
import itertools
import json
import math
import os
import re
import sys
import tempfile
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from typing import Any

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")  # aucune fenêtre : tout se fait en mémoire
from qtpy6.QtCore import QBuffer, QByteArray, QIODevice, QLineF, QMarginsF, QPointF, QRectF, QSizeF, Qt, QUrl  # noqa: E402
from qtpy6.QtGui import (QAbstractTextDocumentLayout, QColor, QFont, QFontMetricsF, QImage, QPageSize,  # noqa: E402
                        QPainter, QPdfWriter, QPen, QPolygonF, QTextBlockFormat, QTextCharFormat, QTextCursor,
                        QTextDocument, QTextFormat, QTextFrameFormat, QTextLength, QTextTable, QTextTableCellFormat, QTransform)
from qtpy6.QtSvg import QSvgGenerator, QSvgRenderer  # noqa: E402

import codes  # noqa: E402
from exporter_eleve import chiffre, est_paquet, preparer  # noqa: E402
from noyau import CATEGORIES_UNIX, CONSIGNE_BASE_PAPIER, NOM_METHODE, ROND_VIDE, dire, numeros, Permissions, SCHEMA_DEMANDES, Sommet, cite_r, sans_marque_modifier  # noqa: E402
from modele import ECART, LOGO, NOM_SVG, OBJET_SVG, RAYON, TENU, ObjetSvg, application, code_nu, en_capitales, melange, rond_a_la_main, sauver  # noqa: E402
from sujet import Sujet, les_sujets, niveau_bloom, piece_jointe, points, sortie  # noqa: E402
from texte_md import (CADRE_CODE, CADRE_CORRECTION, GRIS, bordure, LARGE, MONO, POLICE, POLICE_MAIN,  # noqa: E402
                      STYLE_MONO, VERT_REPONSE, Markdown, bloc_code, bordure, colorer, encadre, indentation_visible, ligne_code, tableau)

# Page A4 en points (1/72 de pouce). Le QPdfWriter est réglé à 72 ppp : une unité vaut un point,
# et les tailles de police du HTML sont exactes.
LARGEUR, HAUTEUR, MARGE, PIED = 595, 842, 42, 16
LARGEUR_UTILE = LARGEUR - 2 * MARGE
BANDEAU = 16  # sous la marge du haut, la bande où tombe le bas du cadre Nom / Prénom (voir identifier_la_page)
HAUT = MARGE + BANDEAU  # où commence le texte, sur chaque page
HAUTEUR_UTILE = HAUTEUR - HAUT - MARGE - PIED
MARGE_MINI = 28  # 1 cm : la marge la plus étroite que tiennent les imprimantes courantes (souvent 5 mm)
LARGEUR_MAXI = LARGEUR - MARGE - MARGE_MINI  # un bloc de code trop large pour sa colonne mord jusque-là sur la marge
PX = 0.75  # Qt lit les largeurs px du HTML à 96 ppp et les écrit dans un document à 72 : une px vaut 0,75 point
COCHE, CASE, PUCE = "☒", "☐", "•"  # la puce est le bout d’une flèche à tracer, dans un appariement sur papier
ROND_COCHE, ROND = "◉", "⭘"  # une seule réponse attendue : la forme le dit, comme le bouton radio du
# lecteur ; ces deux ronds-là parce qu'ils sortent à la taille du carré ☐, quand le rond ordinaire ○ sort deux
# fois plus petit — aucun n'est dans Carlito, c'est la police de substitution qui les dessine
BAREME_ELEVE = {  # ce que vaut une case fausse, dit à l’élève : la forme ne dit que le nombre de réponses
    "tout_ou_rien": "il faut cocher toutes les bonnes cases et aucune autre : une seule erreur annule la question.",
    "proportionnel": "chaque case compte, cochée comme laissée vide : une erreur ne coûte que sa part.",
    "penalite": "chaque case fausse annule une case juste ; une question ne descend jamais sous 0.",
    "par_case": "chaque case compte, cochée comme laissée vide, et\nune case fausse coûte autant qu’une juste"
                " rapporte ; une question sans aucune case cochée vaut 0, et aucune ne descend sous 0.",
}  # « \n » : en tête du sujet, la suite passe à la ligne en retrait (demande de l'utilisateur, 25/09/2026) ; ailleurs, une espace
LEGENDE_TETE = "Deux types de questions à choix multiples :"  # tête de la légende ; un sujet électronique la recopie dans ses consignes
RISQUES = ("penalite", "par_case")  # les barèmes où cocher au hasard coûte : le conseil qui va avec tient en tête de
RAISON = "une case fausse coûte autant qu’une juste rapporte"  # dite quand les barèmes diffèrent d'une question à l'autre
FOND_CONSIGNES = "#f2f2f2"  # derrière les consignes et la légende des cases, en tête du sujet
CADRE_CONSIGNES = "#bfbfbf"  # léger cadre autour de ce fond (l'utilisateur, 05/11/2026)
TAILLES_THEME = (50, 36, 28)  # le thème en tête d'un TP, en points : la normale, puis les replis contre un recto seul en fin de PDF
TAILLES_THEME_BANDEAU = (36, 28, 20)  # sujet électronique : le visuel s'ajoute sous le sous-titre, le thème part plus petit
PLANCHER = "(sans pour autant pouvoir faire passer en dessous de 0)"  # la suite de RAISON, pour le barème penalite
CONSEIL = "➡ Ne cochez que les réponses dont vous êtes sûr à plus d’une chance sur deux !"  # en tête du sujet ; vouvoie,
# comme toutes les consignes imprimées par ce fichier (« entourez », « reliez »)
TRAIT_ECRITURE = "#d0d0d0"  # gris de tout trait où l’élève écrit : lisible sur le papier, mais assez pâle pour tomber
# sous le seuil de binarisation d’une copie scannée — l’OCR ne voit alors que l’écriture, pas le trait qui la porte.
# Au-dessus de ``encre.GRIS_ENCRE`` (200), sous ``imprimer_correction.TRAIT_VIERGE`` (220) : éclairci le 05/11/2026 depuis #bfbfbf
CADRE_NOTE = 40  # sous le cadre Nom, en tête de la copie élève : la note finale et l'appréciation (demande de l'utilisateur, 27/09/2026)
RETRAIT_CELLULE = 4  # le cellpadding d’un appariement, à ajouter à la largeur mesurée de son texte
CASE_CARACTERE = 28  # px : la case d’une grille caractère par caractère, carrée (hauteur d’une ligne de tableau) et assez large pour écrire une lettre à la main
TAILLE_ROND = 16  # pt : un rond de réglette (``Tableau.pions``), à noircir au crayon ; au corps du texte, ◌ est un point
GOUTTIERE, PUCE_LARGE = 50, 12  # la colonne vide d’un appariement, où l’élève trace ses flèches, et celles des puces
SANS_BAREME = "\ue003"  # entoure un bloc qui s'étend sur la colonne du barème de sa question (voir numeroter)
MOIS = "janvier février mars avril mai juin juillet août septembre octobre novembre décembre".split()
IMAGES = {"png", "jpg", "jpeg", "gif", "webp"}  # les formats chargés en QImage ; le svg, lui, se dessine en vecteurs (ObjetSvg)
AMENAGEMENTS = {"agrandi": "police 13 pt, interligne 1,5, zones de réponse agrandies",
                "aides": "les aides des questions sont imprimées sous l'énoncé (toujours le cas sur un TP ou un projet)",
                "indices": "les indices des questions sont imprimés sous l'énoncé",
                "simplifie": "l'énoncé simplifié remplace l'énoncé, pour les questions qui en ont un",
                "tiers_temps": "durée majorée d'un tiers dans l'en-tête",
                "temps_limite": "les questions retirees_temps_limite du sujet ôtées, barème ramené au même total",
                "sans_empattement": "police DejaVu Sans, plus large et plus ouverte que Carlito, pour le texte, les "
                                    "formules et les styles à empattement (élève dys), lettres basses aussi hautes"}
ECHELLE_AGRANDI = 1.3


def avec_mention(titre: str, amenagements: frozenset[str] | set[str]) -> str:
    """``titre`` tel qu'imprimé (en tête, pied, Word), suivi de « (version agrandie) » si l'aménagement ``agrandi`` est
    là, avant ses retours à la ligne finaux : jamais « BEP », que lisent les voisins (le professeur, 10/11/2026, W527)."""
    if "agrandi" not in amenagements or not titre.strip():
        return titre
    corps = titre.rstrip("\n")
    return corps + " (version agrandie)" + titre[len(corps):]
POLICE_SANS_EMPATTEMENT = "DejaVu Sans"  # libre, installée avec DejaVu Sans Mono ; jamais téléchargée
# son corps : 9 pt pour 10 en Carlito ; ses lettres basses restent plus hautes (hauteur d'x 5,0 pt contre 4,78) et une
# ligne d'énoncé n'est que 1,12 fois plus longue (1,24 à 10 pt : le tableau des distances du DS de SNT n°1, à 100 % de
# la largeur, coupait « Sach a »). Mesuré par QFontMetricsF sur le périphérique du PDF, W495, 10/11/2026.
CORPS_SANS_EMPATTEMENT = 0.9
# les colonnes fixes s'élargissent d'autant, comme celles du profil agrandi (mesurées en Carlito puis multipliées)
LARGEUR_SANS_EMPATTEMENT = 1.12
COLONNE_FIXE = re.compile(r'(<td width=")(\d+(?:\.\d+)?)(")')
# ce que remplace l'aménagement sans_empattement dans le HTML : le corps, les styles « serif » et les formules
FAMILLE_REMPLACEE = re.compile(r"font-family:\s*'(?:Carlito|Liberation Serif|DejaVu Math TeX Gyre)'")

COULEUR_TEXTE = re.compile(r"(?<![-\w])color:\s*#([0-9a-fA-F]{6})")  # color: seul, pas background-color
TAILLE = re.compile(r'(font-size:|<td width=")(\d+(?:\.\d+)?)(pt|")')  # ce qu'agrandit le profil agrandi (pas les images)
# fonds, bordures, et le texte d'une conversion en tableau, gris comme sa figure (svg_gris) plutôt que noir
COULEUR_FOND = re.compile(r'((?:bgcolor|bordercolor|<font color)="|background-color:)#([0-9a-fA-F]{6})')



# ---------------------------------------------------------------- petits rendus

def date_francaise(iso):
    annee, mois, jour = iso.split("-")
    return f"{int(jour)} {MOIS[int(mois) - 1]} {annee}"


def note(texte):
    return f'<p><i>{dire(texte)}</i></p>'


def mono(texte):
    return ligne_code(html.escape(texte))


ROUGE_CORRECTION = "#c0392b"  # la correction de l'écran (``Feuille.presenter_corrige``), écrite à la main ; au corrigé
# imprimé, elle n'annote plus que les propositions fausses, le reste s'écrit en vert (l'utilisateur, 28/09/2026)
# Kalam à 9 pt : les lettres basses de Carlito à 10 pt (6,2 pt, mesuré par QFontMetricsF), comme l'écran les accorde à
# sa propre police (``modele.TAILLE_MAIN``). Son interligne, resserré dans la police même (``modele.MAIN``, COS-18), ne
# dépasse plus celui de Carlito : la correction ne tient pas plus de place que le texte imprimé, sans « line-height »
# (il était ramené ici à 85 %, ce qui faisait 3 pages au lieu de 5 au corrigé des réseaux sociaux).
MAIN = f"font-family:'{POLICE_MAIN}'; font-size:9pt"


def a_la_main(texte, couleur=VERT_REPONSE, balise="span"):
    """Ce que le corrigé écrit à la main, comme la correction à l'écran : Kalam, en vert (en rouge à côté d'une proposition fausse)."""
    return f'<{balise} style="color:{couleur}; {MAIN}">{texte}</{balise}>'


def reponse(texte):
    """Une réponse attendue, dans le corrigé : écrite à la main, en vert, comme la bonne proposition imprimée."""
    return a_la_main(texte)


def juste(texte):
    """Une proposition IMPRIMÉE qui est la bonne (choix, mot à entourer) : en vert, comme le rond que l'écran trace autour."""
    return f'<span style="color:{VERT_REPONSE}"><b>{texte}</b></span>'


def gris(texte):
    return f'<span style="color:{GRIS}">{texte}</span>'


def barree(texte):
    """Une proposition écartée, dans le corrigé d'un trou à choix : barrée comme l'élève devait la barrer."""
    return gris(f"<s>{texte}</s>")


def a_entourer(texte):
    """Une proposition imprimée à la place du trou, à entourer ou à barrer : en italique gras, alors que le corps du
    texte n'est ni l'un ni l'autre — c'est ce qui la fait sortir de l'énoncé sans recourir à la couleur, donc aussi
    bien sur les variantes en noir et blanc."""
    return f'<span style="font-style:italic; font-weight:bold">{texte}</span>'


MARQUE_GROUPE = "#ffffff"  # un fond blanc, invisible sur la page : il ne sert qu'à retrouver les groupes après coup
MARQUE_ENTOURE = "#fefefe"  # de même pour une case d'un ``tableau`` à ``a_entourer``, que le corrigé entoure de vert


def groupe_a_entourer(mots):
    """Le groupe de propositions d'un trou, tenu par des « / » en gras et par un cadre gris tracé après la mise en
    page (``cadres_des_groupes``) : Qt ignore une bordure posée sur un ``span``, et un tableau, qui en accepte une,
    passerait le groupe à la ligne. Les espaces insécables de tête et de queue sont ce qui écarte le cadre du texte.
    Pas de parenthèses : dans un énoncé qui parle de code, elles se liraient comme celles d'un appel de fonction."""
    return f'<span style="background-color:{MARQUE_GROUPE}">&nbsp;{"&nbsp;<b>/</b>&nbsp;".join(mots)}&nbsp;</span>'


AJOUT, SUPPRESSION = "#dff5d0", "#fbdada"  # fonds des lignes d'un corrigé de projet qui ne montre que les changements
BLOC_ENGLOBANT = re.compile(r"^(?:def|class) .*")


def differences(avant, apres, langage):
    """Le code ``apres`` réduit à ce qui change depuis ``avant`` : ajouts surlignés, suppressions barrées, une ligne de contexte
    autour, et devant chaque morceau la fonction qui le contient (pas de numéro de ligne : chaque élève a les siens). None si rien ne change."""
    lignes_avant, lignes_apres = avant.rstrip().split("\n"), apres.rstrip().split("\n")
    couleur_avant = colorer("\n".join(lignes_avant), langage).split("\n")
    couleur_apres = colorer("\n".join(lignes_apres), langage).split("\n")
    morceaux = []
    for groupe in difflib.SequenceMatcher(None, lignes_avant, lignes_apres, autojunk=False).get_grouped_opcodes(1):
        debut = groupe[0][3]
        englobant = next((l for l in reversed(lignes_apres[:debut + 1]) if BLOC_ENGLOBANT.match(l)), "")
        repere = "…" + (f" dans {html.escape(englobant.rstrip(':'))}" if englobant else "")
        h = [f'<span style="color:{GRIS}; font-style:italic">{repere}</span>']
        for operation, a1, a2, b1, b2 in groupe:
            if operation == "equal":
                h += couleur_apres[b1:b2]
            if operation in ("delete", "replace"):
                h += [f'<span style="background-color:{SUPPRESSION}; text-decoration:line-through">{l or " "}</span>' for l in couleur_avant[a1:a2]]
            if operation in ("insert", "replace"):
                h += [f'<span style="background-color:{AJOUT}">{l or " "}</span>' for l in couleur_apres[b1:b2]]
        morceaux.append("\n".join(h))
    return bloc_code("\n\n".join(morceaux), CADRE_CORRECTION) if morceaux else None





TAILLE_PARTIE = 19  # le plus grand entier qui garde « Partie 2 : Étude de cas, l'affaire Cambridge Analytica (10 points) » sur une ligne


def taille_des_parties(document: QTextDocument) -> None:
    """Les titres de niveau 1 à ``TAILLE_PARTIE`` : Qt ne lit que l'ajustement de taille d'un titre, qu'il faut donc retirer."""
    bloc = document.begin()
    while bloc.isValid():
        if bloc.blockFormat().headingLevel() == 1:
            curseur = QTextCursor(bloc)
            curseur.movePosition(QTextCursor.EndOfBlock, QTextCursor.KeepAnchor)
            format_titre = curseur.charFormat()
            format_titre.clearProperty(QTextFormat.FontSizeAdjustment)
            format_titre.setFontPointSize(TAILLE_PARTIE)
            curseur.setCharFormat(format_titre)
        bloc = bloc.next()


def sous_titre(texte, grand=False):
    # Qt fixe la taille d'un titre par son niveau et ignore font-size, même dans une <span> : h2 à 15 pt ; h1, à 20 pt,
    # est ramené à TAILLE_PARTIE par ``taille_des_parties`` (titre de partie plus grand que section, l'utilisateur, 05/11/2026)
    niveau = 1 if grand else 2
    return f'<h{niveau}>{html.escape(texte)}</h{niveau}>'


def trait(contenu):
    """Un trait à écrire dessus, gris comme les lignes réglées : ce qui est imprimé dedans (le numéro d’un trou) l’est
    aussi, sans quoi il resterait dans l’image scannée au milieu de la réponse."""
    return f'<u style="color:{TRAIT_ECRITURE}">{contenu}</u>'


PAS_INDENTATION = 38  # px, soit 1 cm (Qt compte la largeur d’une case en px à 96 ppp) : quatre caractères écrits à la main


def lignes_reponse(n, niveaux=0, retrait=0, debut="", largeur=None, debut_texte=""):
    """n lignes à écrire, réglées comme un cahier. ``niveaux`` : pour du code, autant de pointillés verticaux, un par
    niveau d'indentation ; l'élève y aligne ses blocs, et le correcteur (ou la lecture automatique de l'écriture) n'a
    plus à deviner si une ligne est dans le bloc du dessus. ``retrait`` (en caractères de code) : les lignes commencent
    sous l'indentation du code donné ; ``debut`` (du HTML, « return », dont ``debut_texte`` est le texte seul) est
    imprimé devant, hors du trait, qui ne commence qu'après lui ; ``largeur`` (en caractères de code, depuis le retrait) : la longueur des traits, toute
    la largeur sans elle."""
    case = f'<td{{}} style="border-bottom:1px solid {TRAIT_ECRITURE}{{}}"><p style="font-size:14pt">&nbsp;</p></td>'
    # le repère d'un niveau ne porte pas la rangée de 14 pt : sa ligne de réponse est celle du trait, une seule fois
    repere = f'<td width="{PAS_INDENTATION}" style="border-bottom:1px solid {TRAIT_ECRITURE}; border-right:1px dotted {TRAIT_ECRITURE}"></td>'
    marge = f'<td width="{round(retrait * CHASSE_CODE)}"></td>' if retrait else ""
    tete = f'<td width="{round((len(debut_texte) + 0.5) * CHASSE_CODE)}" style="vertical-align:bottom">{debut}</td>' if debut else ""
    trait_ = case.format("" if largeur is None else f' width="{round(largeur * CHASSE_CODE) - niveaux * PAS_INDENTATION}"', "")
    reste = "" if largeur is None else "<td></td>"  # le trait s'arrête là : la fin de la ligne reste vide
    lignes = "".join(f"<tr>{marge}{tete}{repere * niveaux}{trait_}{reste}</tr>" for _ in range(n))
    return f'<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">{lignes}</table>'


REPONSE_BLANCHE = "Réponse :"  # en blanc sur la ligne d'une réponse courte, l'ancre de imprimer_correction : la rangée reste une ligne de réponse
CHASSE_CODE = 0.6 * 9 * 96 / 72  # px : la chasse d'un caractère du code (0,6 em à 9 pt), pour aligner les lignes sur son indentation
A_COMPLETER = re.compile(r"^( *)(.*?)( *)# à compléter *$")  # la même que noyau.MARQUE_A_COMPLETER


def code_a_completer(initial, solution):
    """Le code donné découpé autour de ses lignes « # à compléter » : des morceaux de code (str) et, pour chaque ligne
    marquée, (retrait, début de ligne donné, nombre de lignes à écrire, niveaux d'indentation à y ajouter, longueur en
    caractères depuis le retrait). Tout se lit sur les lignes que la solution met à sa place (difflib) : autant de
    lignes, des pointillés seulement si elles s'indentent plus que la marque, un trait aussi long que la plus longue
    (demandes de l'utilisateur, 28/09/2026 : « il n'y a qu'un assert à ajouter, donc une seule ligne »).
    Sans ligne marquée, None."""
    donne, attendu = initial.rstrip().splitlines(), solution.rstrip().splitlines()
    if not any(A_COMPLETER.match(l) for l in donne):
        return None
    place = {}
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, donne, attendu, autojunk=False).get_opcodes():
        marquees = [i for i in range(i1, i2) if A_COMPLETER.match(donne[i])]
        for k, i in enumerate(marquees):
            if op == "equal":
                place[i] = []
            elif i2 - i1 == j2 - j1:  # autant de lignes de part et d'autre : chaque marque a la sienne
                place[i] = [l for l in attendu[j1 + i - i1:j1 + i - i1 + 1] if l.strip()]
            else:  # des marques consécutives se partagent les lignes : une chacune, le reste à la dernière
                ecrites = [l for l in attendu[j1:j2] if l.strip()]
                place[i] = ecrites[k:k + 1] if k < len(marquees) - 1 else ecrites[k:]
    morceaux, courant = [], []
    for i, ligne in enumerate(donne):
        m = A_COMPLETER.match(ligne)
        if not m:
            courant.append(ligne)
            continue
        if courant:
            morceaux.append("\n".join(courant))
            courant = []
        retrait, ecrites = len(m.group(1)), place[i]
        n = 1 if m.group(2) else max(1, len(ecrites))  # après « return », une ligne suffit
        niveaux = max([(len(l) - len(l.lstrip()) - retrait) // 4 for l in ecrites] + [0])
        longueur = max([len(l) - retrait for l in ecrites] + [20])
        morceaux.append((retrait, m.group(2) + " " * bool(m.group(3)), n, niveaux, longueur))
    if courant:
        morceaux.append("\n".join(courant))
    return morceaux


COLONNE_POINTS = 64  # largeur px de la colonne des points ; celle du numéro dépend de l'étiquette
A_NOTER = trait("&nbsp;" * 8) + "&nbsp;/&nbsp;"  # devant le barème, sur la copie élève : la place de la note du correcteur
COLONNE_NOTE = 36  # ce qu'il ajoute à la colonne des points


def colonne_numero(etiquette):
    return 8 + 7 * len(etiquette)


def numeroter(etiquette, contenu, pts, a_noter=False):
    """Le numéro dans une colonne à part (les lignes suivantes de l'énoncé et la zone de réponse restent alignées),
    les points (sauf ``None``) dans une colonne à droite, entre parenthèses pour une sous-question (« a. ») : le détail
    du total de sa question, pas des points en plus (demande de l'utilisateur, 25/09/2026). ``a_noter`` (copie élève)
    fait précéder le barème d'un blanc où le correcteur écrit la note, sur un trait gris : « ____ / 2 points ». Un bloc de code marqué
    trop large (texte_md.LARGE) sort du tableau et garde sa marque : il remonte ainsi de niveau en niveau jusqu'au
    document, le seul endroit où Qt le laisse déborder sur la marge — une cellule, elle, le rogne à sa largeur."""
    def rangee(interieur, premiere):
        bareme = "" if pts is None else (A_NOTER if a_noter else "") + points(pts).replace(" ", "&nbsp;")
        bareme = f"({bareme})" if etiquette[:1].isalpha() else bareme
        largeur = COLONNE_POINTS + (COLONNE_NOTE if a_noter else 0)
        def colonne_points(montrer):
            return "" if pts is None else (f'<td width="{largeur}" align="right" style="vertical-align:top">'
                                           f'{"<i>" + bareme + "</i>" if montrer else ""}</td>')
        # un bloc SANS_BAREME (les colonnes d'un appariement) garde la colonne du numéro mais s'étend sur celle du
        # barème, vide à sa hauteur ; dans la même table, pour que la question reste d'un seul tenant à la pagination
        parts = interieur.split(SANS_BAREME)
        lignes = "".join(f'<tr><td></td><td colspan="{1 if pts is None else 2}" style="vertical-align:top">{p}</td></tr>' if k % 2 else
                         f'<tr><td width="{colonne_numero(etiquette)}" style="vertical-align:top">'
                         f'{f"<b>{etiquette}</b>" if premiere and not k else ""}</td>'
                         f'<td style="vertical-align:top">{p}</td>{colonne_points(premiere and not k)}</tr>'
                         for k, p in enumerate(parts) if k % 2 or p.strip() or not k)
        return f'<table width="100%" cellpadding="0" cellspacing="0" style="margin-top:{8 if premiere else 0}px">{lignes}</table>'
    morceaux = contenu.split(LARGE)  # pairs : le texte de la question ; impairs : les blocs élargis
    return "".join(f"{LARGE}{m}{LARGE}" if i % 2 else rangee(m, not i)
                   for i, m in enumerate(morceaux) if i % 2 or m.strip() or not i)


# ---------------------------------------------------------------- le sujet

FIN_DE_PHRASE, DEUX_POINTS = "\ue004", "\ue005"  # l'espace après un « . », après un « : » d'un énoncé : ``Rendu.aerer`` en fait un retour à la ligne ou une espace
NON_PARAGRAPHE = re.compile(r"\s|[|#>!]|[-*+] |\d+[.)] ")  # tableau, titre, citation, image, liste, code indenté


def marquer_fins_de_phrase(enonce: str) -> str:
    """L'énoncé, ``FIN_DE_PHRASE`` ou ``DEUX_POINTS`` à la place de l'espace qui suit un « . » ou un « : » où une ligne peut s'arrêter. Seulement
    dans un paragraphe de pur texte, d'une seule ligne de source : un retour voulu par l'auteur reste seul maître du sien. Ni
    dans du code, une formule ou un lien, ni entre parenthèses ou guillemets, ni après une initiale, ni devant une minuscule
    après un point."""
    def marquer(paragraphe: str) -> str:
        masque = re.sub(r"`[^`]*`|\$[^$]*\$|\[[^\]]*\]\([^)]*\)", lambda m: "x" * len(m.group()), paragraphe)
        resultat = list(paragraphe)
        for m in re.finditer(r"([.:])\*{0,2}( +)(?=\S)", masque):
            avant = masque[:m.start()]
            if avant.count("(") > avant.count(")") or avant.count("«") > avant.count("»"):
                continue
            if m.group(1) == "." and (masque[m.end()].islower() or re.search(r"(?:^|[\s(])(?:\w|etc)$", avant)):
                continue
            resultat[m.start(2):m.end(2)] = [FIN_DE_PHRASE if m.group(1) == "." else DEUX_POINTS] + [""] * (len(m.group(2)) - 1)
        return "".join(resultat)
    morceaux = re.split(r"(\n\n+|```.*?```)", enonce, flags=re.S)  # impairs : les séparations et le code
    return "".join(m if i % 2 or "\n" in m or not m or NON_PARAGRAPHE.match(m) else marquer(m) for i, m in enumerate(morceaux))


class Rendu:
    """Un sujet -> le HTML d'une version : élève (corrige=False) ou corrigé."""

    def __init__(self, sujet, images, corrige, amenagements=frozenset()):
        self.sujet, self.corrige, self.amenagements = sujet, corrige, amenagements
        self.projet = sujet.definition.destination == "projet"  # ni barème ni lignes de réponse sous le code
        echelle = ECHELLE_AGRANDI if "agrandi" in amenagements else 1  # le profil agrandi rétrécit d'autant la place du code
        # sans_empattement élargit les colonnes du numéro et du barème, pas le code (chasse fixe inchangée)
        large = echelle * (LARGEUR_SANS_EMPATTEMENT if "sans_empattement" in amenagements else 1)
        self.a_noter = not corrige and not self.projet
        colonne_points = COLONNE_POINTS + (COLONNE_NOTE if self.a_noter else 0)
        pris = colonne_numero("147.") + colonne_points  # l'étiquette la plus longue : le cas le plus étroit
        self.colonnes_sous_question = colonnes_de_code(  # une sous-question paie les colonnes des deux niveaux
            LARGEUR_UTILE - (pris + colonne_numero("a.") + colonne_points) * large * PX, echelle)
        self.images = images
        self.md = Markdown(images, LARGEUR_UTILE,
                           (colonnes_de_code(LARGEUR_UTILE - pris * large * PX, echelle), round(LARGEUR_MAXI / PX),
                            colonnes_de_code(LARGEUR_MAXI, echelle)))
        self.md.insecables = getattr(sujet.definition, "insecables", True)  # ``"insecables": false`` du sujet (``texte_md.Markdown``)
        self.mesure = QPdfWriter(os.devnull)  # le périphérique sur lequel ``aerer`` mesure une question
        self.mesure.setResolution(72)
        self.contextes_vus = set()
        self.bases_vues = set()  # les bases nommées déjà imprimées dans la section (``t_sql``)
        self.figures = {}  # nom -> SVG : les figures dessinées pour le sujet (``t_conversion``), à ajouter aux médias
        self.tableaux = {}  # nom -> ``Conversion.tableau`` : les grilles ``en_tableau``, que ``ecrire_pdf`` règle et borde
        self.cases_des_figures = {}  # nom -> les cases à remplir d'une figure de conversion (``reperer_les_cases``)
        self.solution_precedente = None  # projet : chaque corrigé de code ne montre que ce qui change depuis le précédent
        self.bareme = []  # (étiquette, question, points), sous-questions comprises
        self.posees = {}  # id -> (numéro, question) des questions déjà imprimées : ce qu'un code ``reprend``
        self.bareme_legende = None  # le barème des choix multiples s'il est le même partout : annoncé une fois, en tête
        self.taille_theme = TAILLES_THEME[0]  # réduite par ``exporter`` quand elle épargne un recto seul en fin de PDF

    # ---- document

    def document(self):
        s = self.sujet.definition
        h = self.page_de_garde() if self.projet else self.en_tete()
        # consignes et légende des cases sur un même fond gris très clair, qui les détache des questions (demandes de
        # l'utilisateur, 25/09/2026 pour la légende, 28/09/2026 pour toutes les instructions de tête)
        legende = self.legende()  # appelée même quand on la tait : elle fixe bareme_legende
        if LEGENDE_TETE in s.consignes:  # un sujet électronique l'écrit dans ses consignes (l'écran n'a pas la sienne)
            legende = []
        # une durée écrite dans le cadre gris (DS SNT de Seconde, 04/11/2026) suit le tiers-temps, comme celle de l'en-tête
        consignes = s.consignes.replace(f"Durée : {s.duree_minutes} min", (self.duree(s.duree_minutes) or "").capitalize())
        # interlignes resserrés dans le cadre gris : il prend de la place à toutes les copies (DS SNT de Seconde, 04/11/2026)
        tete = ([self.md.html(consignes).replace("<p>", '<p style="margin-top:3px; margin-bottom:3px">')] if consignes else []) + legende
        if tete:
            h.append(f'<table width="100%" {bordure(CADRE_CONSIGNES, 6).replace('style="', 'style="margin-top:10px; ')}><tr><td bgcolor="{FOND_CONSIGNES}">{"".join(tete)}</td></tr></table>')
        par_section = s.numerotation_par_section
        self.imprimees = []  # (étiquette, question) dans l'ordre d'impression : le fichier POSITIONS
        etiquettes = numeros([[q for q, _ in r] for _, r in self.sujet.sections], par_section)  # « 9.a », « 9.b »
        for rang, (section, resolues) in enumerate(self.sujet.sections, 1):
            self.bases_vues = set()
            if section.nouvelle_page:  # ramassée à part : saut de page (le nom est repris en haut de chaque page)
                h.append('<p style="page-break-before:always"></p>')
            if section.partie:
                h.append(sous_titre(section.partie, grand=True))
            if section.titre:
                h.append(sous_titre(section.titre))
            if section.consignes:
                # un document à lire dans son cadre (::: {.document}, DS SNT de Seconde, 05/11/2026) : l'italique et l'inline ne le rendraient pas
                h.append(self.md.html(section.consignes) if ":::" in section.consignes
                         else f"<p><i>{self.md.inline(section.consignes)}</i></p>")
            for (q, pts), numero in zip(resolues, etiquettes[rang - 1]):
                self.imprimees.append((f"{numero}.", None if q.type == "groupe" else q))  # layout_retrouve.attendues
                if q.type == "groupe":
                    self.imprimees += [(f"{numero}{chr(97 + i)}", sq) for i, sq in enumerate(q.sous_questions)]
                h.append(self.question(q, f"{numero}.", pts, f"{rang}.{numero}" if par_section else str(numero)))
        if self.corrige and not self.projet:
            h.append(self.tableau_bareme())
        return "".join(h)

    def legende(self):
        """Ce que les formes des cases annoncent, en tête du sujet : rond = une seule réponse, carré = zéro, une ou
        plusieurs. Le barème des carrés n'y tient que s'il est le même partout ; sinon chaque question porte le sien."""
        unique, baremes = False, set()
        for _, resolues in self.sujet.sections:
            for question, _ in resolues:
                for q in question.feuilles():
                    if q.type == "choix_multiples":
                        baremes.add(q.bareme)
                    elif q.type in ("choix_unique", "alternative"):
                        unique = True
        if len(baremes) == 1:
            self.bareme_legende = next(iter(baremes))
        if not (unique or baremes) or self.corrige:  # le corrigé porte le barème de chaque question, et son tableau récapitulatif
            return []
        lignes = ([(ROND, "une seule bonne réponse")] if unique else []) + ([(CASE, "une ou plusieurs bonne(s) réponse(s)")] if baremes else [])
        sous = []  # sous la ligne des carrés, en retrait : ce que coûte une case fausse, puis le conseil qui en découle
        if self.bareme_legende and self.bareme_legende != "penalite":
            premiere, *suite = BAREME_ELEVE[self.bareme_legende].split("\n")
            sous += [premiere] + [f'<p style="margin-left:16px">{x}</p>' for x in suite]  # un retrait tenu sur toutes les lignes
        elif baremes.intersection(RISQUES):  # la pénalité dite en clair, ou, si les barèmes diffèrent, la raison du conseil seule
            sous += [RAISON, PLANCHER] if self.bareme_legende == "penalite" else [RAISON]
        if baremes.intersection(RISQUES):
            sous.append(dire(CONSEIL))
        # un tableau, pour que les lignes du dessous s'alignent sur le texte après « ☐ : » (demande de l'utilisateur, 25/09/2026)
        cellule = lambda x: f"<td><i>{x}</i></td>"
        rangs = [cellule(f"{forme} :&nbsp;") + cellule(texte) for forme, texte in lignes] + [cellule("") + cellule(s) for s in sous]
        tete = note(LEGENDE_TETE) if unique and baremes else ""
        legende = '<table cellpadding="0" cellspacing="0">' + "".join(f"<tr>{r}</tr>" for r in rangs) + "</table>"
        return [tete + legende]

    def page_de_garde(self):
        """Projet : titre (en majuscules, seul sur sa ligne), sous-titre, niveau et couverture du thème seuls sur la première page, comme les originaux ; ni barème ni nom."""
        s = self.sujet.definition
        niveau = " ".join(filter(None, [s.classe, s.matiere]))
        couverture = f'<img src="{LOGO}" width="326">' if LOGO in self.md.images else "&nbsp;"  # 11,5 cm
        titre = avec_mention(en_capitales(s.titre), self.amenagements) + (" – CORRIGÉ" if self.corrige else "")
        return [f'<p align="center" style="margin-top:150px"><span style="font-size:40pt; font-weight:bold">{html.escape(titre).replace(chr(10), "<br>")}</span></p>',
                *([f'<p align="center"><span style="font-size:26pt">{html.escape(s.sous_titre)}</span></p>'] if s.sous_titre else []),
                f'<p align="center"><span style="font-size:18pt">(niveau {html.escape(niveau)})</span></p>',
                f'<p align="center" style="margin-top:40px; page-break-after:always">{couverture}</p>']

    def en_tete(self):
        """Thème (TP) en très gros au-dessus du titre, sinon le titre en majuscules et en gros ; le sous-titre sur sa
        propre ligne dessous (« DS NSI Terminale N°1 » / « Le langage Python » : demande de l'utilisateur, 25/09/2026)."""
        s = self.sujet.definition
        # en-tête de TP (thème) centré comme les originaux ; des paragraphes, car un <h1> ignore font-size
        logo = self.md.images.get(LOGO)  # la surface du logo Python des originaux (2,77 cm de côté), quelle que soit la forme
        bandeau = logo and s.destination == "electronique"  # sous le sous-titre, à la largeur du texte, comme dans le lecteur
        cote = 78 / (logo.width() / logo.height()) ** 0.5 if logo else 0
        h = [f'<p align="center"><img src="{LOGO}" height="{cote:.0f}" width="{78 * 78 / cote:.0f}"></p>'] if logo and not bandeau else []
        h += [f'<p align="center"><span style="font-size:{self.taille_theme}pt; font-weight:bold">{html.escape(s.theme.upper())}</span></p>'] if s.theme else []
        titre = en_capitales(s.titre) if not (h or bandeau) else "" if s.theme and s.titre.casefold() == s.theme.casefold() else s.titre
        titre = "Corrigé" + (" : " + titre if titre else "") if self.corrige else titre
        if s.theme and not titre:  # le titre qui répète le thème s'omet : la mention suit le thème
            theme = html.escape(s.theme.upper())  # le texte de la balise, jamais son style (thème chiffré)
            h[-1] = h[-1].replace(f">{theme}</span>", f">{html.escape(avec_mention(s.theme.upper(), self.amenagements))}</span>", 1)
        titre = avec_mention(titre, self.amenagements)
        if titre:  # un titre qui répète le thème ne s'imprime pas deux fois (« Les réseaux sociaux », TP1 et TP2)
            # écarts égaux entre cartouche, titre, sous-titre et cadre gris (l'utilisateur, 05/11/2026)
            marge = ' style="margin-bottom:6px"' if s.sous_titre else ""
            h.append(f'<p align="center"{marge}><span style="font-size:29pt; font-weight:bold">{html.escape(titre).replace(chr(10), "<br>")}</span></p>')
        if s.sous_titre:
            h.append(f'<p align="center" style="margin-top:6px"><span style="font-size:20pt; font-weight:bold">{html.escape(s.sous_titre).replace(chr(10), "<br>")}</span></p>')
        if bandeau:  # pdf d'un sujet électronique : le visuel que le lecteur montre sous le sous-titre (l'utilisateur, 06/10/2026)
            largeur = LARGEUR_UTILE * self.taille_theme / TAILLES_THEME_BANDEAU[0]  # réduit avec le thème contre un recto seul
            h.append(f'<p align="center"><img src="{LOGO}" width="{largeur:.0f}" height="{largeur * logo.height() / logo.width():.0f}"></p>')
        # ni matière ni classe (elles sont au pied de page), ni total (il est dans le cadre de la note) : l'utilisateur, 28/09/2026
        infos = [date_francaise(s.date) if s.date else None, None if f"Durée : {s.duree_minutes} min" in s.consignes else self.duree(s.duree_minutes)]
        if any(infos):
            h.append("<p>" + " – ".join(filter(None, infos)) + "</p>")
        return h  # nom et prénom : tout en haut de chaque page, par identifier_la_page

    def duree(self, minutes):
        if not minutes:
            return None
        if "tiers_temps" in self.amenagements:
            return f"durée : {round(minutes * 4 / 3)} min (tiers-temps)"
        return f"durée : {minutes} min"

    def hauteur_du_html(self, contenu: str) -> float:
        """La hauteur de ce HTML en pleine largeur, mis en page par Qt sur le périphérique du PDF."""
        document = QTextDocument()
        document.documentLayout().setPaintDevice(self.mesure)
        document.setDefaultFont(police_du_corps(round(10 * ECHELLE_AGRANDI) if "agrandi" in self.amenagements else 10,
                                                self.amenagements))
        document.setDocumentMargin(0)
        document.setTextWidth(LARGEUR_UTILE)
        document.setHtml(contenu.replace(LARGE, ""))
        return document.size().height()

    def aerer(self, question: str) -> str:
        """Le HTML d'une question entière, chaque ``FIN_DE_PHRASE`` puis chaque ``DEUX_POINTS`` de ses énoncés devenu un retour à
        la ligne si la question n'en grandit pas, une espace sinon : les phrases se lisent mieux une par ligne, mais la place sur
        la page prime, et les points passent avant les deux-points (l'utilisateur, 05/11/2026). Mesuré sur la question entière et non d'après une largeur calculée : Qt répartit les
        colonnes de ses tableaux selon leur contenu, et la colonne d'un énoncé n'a donc pas une largeur connue d'avance."""
        morceaux = re.split(f"({FIN_DE_PHRASE}|{DEUX_POINTS})", question)  # impairs : les marques
        if len(morceaux) == 1:
            return question
        marques = morceaux[1::2]
        morceaux[1::2] = [" "] * len(marques)
        base = self.hauteur_du_html("".join(morceaux))
        for marque in (FIN_DE_PHRASE, DEUX_POINTS):
            for i, autre in enumerate(marques):
                if autre == marque:
                    morceaux[2 * i + 1] = "<br/>"
                    if self.hauteur_du_html("".join(morceaux)) > base:
                        morceaux[2 * i + 1] = " "
        return "".join(morceaux)

    def question(self, q, etiquette, pts, numero):
        colonnes = self.colonnes_sous_question if etiquette[:1].isalpha() else None
        corps = []  # DANS le bloc numéroté : au-dessus de lui, un texte partagé se lisait comme la fin de la question
        for nom in q.contextes_cites():  # PRÉCÉDENTE (QCM Algorithmique, questions 99, 126 et 132)
            if nom not in self.contextes_vus:  # le document ouvre la première question qui le cite
                self.contextes_vus.add(nom)
                corps.append(self.md.html(self.sujet.contextes[nom], colonnes=colonnes))
        enonce = q.enonce_simplifie if "simplifie" in self.amenagements and q.enonce_simplifie else q.enonce
        corps.append(self.md.html(marquer_fins_de_phrase(enonce), colonnes=colonnes))
        if q.aide and (self.sujet.definition.destination in ("tp", "projet") or "aides" in self.amenagements):
            corps.append(note("Aide : " + self.md.inline(q.aide)))  # sur un TP, pour tous ; sur un DS, seulement en aménagement
        if "indices" in self.amenagements:
            corps += [note(f"Indice {i} : " + self.md.inline(indice.texte)) for i, indice in enumerate(q.indices, 1)]
        if q.type == "groupe":
            self.alignes = getattr(self, "alignes", {}) | {id(t): lot for lot in q.tableaux_alignes() for t in lot}
            corps += [self.question(sq, f"{chr(97 + i)}.", sq.points, f"{numero}{chr(97 + i)}") for i, sq in enumerate(q.sous_questions)]
        else:
            self.bareme.append((numero, q, pts))
            self.posees[q.id] = numero, q
            corps.append(self.selon(q) or getattr(self, "t_" + q.type)(q))
        if q.justification:
            j = q.justification
            corps.append(f"<p>{self.md.inline(j.consigne)}</p>" if j.consigne_seule else
                         f"<p><b>Justification</b> (<i>{points(j.points)}</i>) : {self.md.inline(j.consigne)}</p>")
            if not self.corrige:
                corps.append(lignes_reponse(3))
        if self.corrige and q.explication:  # sans cadre, à la main sous la question, comme à l'écran
            corps.append(a_la_main(self.md.html(q.explication, manuscrit=True), balise="div"))
        rendu = numeroter(etiquette, "".join(corps), None if self.projet else pts, self.a_noter)
        return rendu if etiquette[:1].isalpha() else self.aerer(rendu)  # une sous-question se mesure dans sa question

    def selon(self, q):
        """Le corrigé d'une question dont la réponse dépend d'une autre (``selon``) : une correction par cas, sous la
        réponse de la source qui le choisit ; la correction écrite si un cas n'a pas de ``libelle`` ou cite la saisie."""
        cas = q.selon["cas"] if self.corrige and q.selon and q.selon.get("question") in self.posees else []
        remplaces = [{k: v for k, v in c.items() if k not in ("si", "libelle")} for c in cas]
        if not cas or any(not c.get("libelle") or cite_r(r) for c, r in zip(cas, remplaces)):
            return ""
        numero = self.posees[q.selon["question"]][0]
        return "".join(f"<p>Si la réponse à la question {numero} est : {self.md.inline(c['libelle'])}</p>"
                       + getattr(self, "t_" + q.type)(q._avec(r)) for c, r in zip(cas, remplaces))

    def tableau_bareme(self):
        lignes = []
        for numero, q, pts in self.bareme:
            competences = ", ".join(f"{c} ({p})" if len(q.competences_livret) > 1 else c for c, p in q.competences_livret.items())
            verbe = q.verbe_action
            niveau = f" ({niveau_bloom(q)})" if niveau_bloom(q) else ""
            lignes.append(f'<tr><td>{numero}</td><td align="right">{points(pts)}</td><td>{html.escape(competences)}</td>'
                          f'<td>{html.escape(verbe)}{niveau}</td><td>{q.id}</td></tr>')
        return sous_titre("Barème et compétences") + tableau(
            '<table width="100%" style="font-size:8pt">'
            "<tr><th>n°</th><th>points</th><th>compétences du livret (poids)</th><th>verbe (niveau de Bloom)</th><th>identifiant</th></tr>"
            + "".join(lignes) + "</table>")

    # ---- un rendu par type : la zone de réponse (élève) ou la correction (corrigé)

    def t_alternative(self, q):
        choix = []
        for i, libelle in enumerate(q.libelles):
            bonne = self.corrige and (i == 0) == q.reponse
            choix.append(juste(f"{ROND_COCHE} {html.escape(libelle)}") if bonne else f"{ROND} {html.escape(libelle)}")
        return "<p>" + " &nbsp;&nbsp;&nbsp; ".join(choix) + "</p>"

    def choix(self, q, multiples):
        propositions = melange(q.propositions, q.graine) if q.melanger else q.propositions
        vide, cochee = (CASE, COCHE) if multiples else (ROND, ROND_COCHE)
        lignes = []
        for p in propositions:
            texte, case = self.md.inline(p.texte), vide
            if self.corrige:
                if p.correcte:
                    case, texte = juste(cochee), juste(texte)
                if p.feedback:  # à droite de sa proposition, à la main : vert pour la bonne, rouge pour une fausse, comme à l'écran
                    texte += " " + a_la_main(self.md.inline(p.feedback, manuscrit=True), VERT_REPONSE if p.correcte else ROUGE_CORRECTION)
            milieu = ' style="vertical-align:middle"' if "<pre" in texte else ""  # le rond à mi-hauteur d'un affichage encadré
            lignes.append(f'<tr><td width="18"{milieu}>{case}</td><td>{texte}</td></tr>')
        avis = ""
        if multiples and self.corrige:
            avis = note("barème " + q.bareme.replace("_", " "))
        elif multiples and q.bareme != self.bareme_legende:  # le barème commun au sujet est déjà annoncé en tête
            avis = note(f"Barème : {BAREME_ELEVE[q.bareme].replace(chr(10), ' ')}")
        # sans largeur, le tableau se réduit au plus petit contenu, et un bloc de code s'y coupe (« S\t5\nM\t|6 »)
        largeur = ' width="100%"' if "<pre" in "".join(lignes) else ""
        return avis + f'<table{largeur} cellpadding="2" cellspacing="0">{"".join(lignes)}</table>'

    def t_choix_unique(self, q):
        return self.choix(q, False)

    def t_choix_multiples(self, q):
        return self.choix(q, True)

    def t_reponse_courte(self, q):
        if q.etapes:  # le calcul justifié : une ligne par étape, à remplir ou, au corrigé, remplie à la main
            juste = q.juste()
            lignes = [("Formule", "formule"), ("Application numérique", "application"), ("Résultat", "resultat")]
            if not self.corrige:
                return "".join(f"<p>{libelle} : {trait('&nbsp;' * 60)}</p>" for libelle, _ in lignes)
            tolerance = f" (tolérance ± {q.tolerance:g})" if q.tolerance is not None else ""
            return "".join(f"<p>{libelle} : {reponse(html.escape(juste[etape]))}{tolerance if etape == 'resultat' else ''}</p>"
                           for libelle, etape in lignes)
        if not self.corrige:
            # la même ligne réglée qu'une réponse ouverte (l'utilisateur, 05/11/2026) ; ``imprimer_correction.ligne_reponse``
            # s'ancre sur ce mot pour placer l'attendu d'une réponse vide : il reste dans le texte du PDF, en blanc, sur la ligne
            return lignes_reponse(1).replace("&nbsp;", f'<span style="color:white">{REPONSE_BLANCHE}</span>', 1)
        reponses = " ou ".join(reponse(html.escape(str(r))) for r in q.reponses)
        tolerance = f" (tolérance ± {q.tolerance:g})" if q.tolerance is not None else ""
        tolerance += {"liste": " (crochets facultatifs)",
                      "ensemble": " (dans n'importe quel ordre ; un élément juste rapporte, un faux retire autant)",
                      }.get(q.comparaison, "")
        return f"<p>Réponse : {reponses}{tolerance}</p>"

    def t_reponse_ouverte(self, q):
        if not self.corrige:
            return lignes_reponse(q.lignes)
        h = a_la_main(self.md.html(q.texte_corrige(), manuscrit=True), balise="div") if q.corrige else note("correction manuelle")
        if q.mots_cles:
            h += note("mots-clés : " + ", ".join(html.escape(m) for m in q.mots_cles))
        return h

    def propositions_a_entourer(self, choix, graine, reponses):
        """Les propositions d'un trou, une par une, prêtes à être entourées par l'élève ; au corrigé, le geste est
        déjà fait (attendue en vert, écartées barrées). Même mélange qu'à l'écran, donc même ordre que sur sa copie.
        L'appelant les assemble : en ligne dans une phrase, l'une sous l'autre dans une case de tableau."""
        mots = []
        attendues = [str(r) for r in reponses or []]
        for c in melange(choix, graine):
            mot = self.md.inline(str(c))
            if self.corrige and attendues:
                mot = juste(mot) if str(c) in attendues else barree(mot)
            mots.append(a_entourer(mot))
        return mots

    def t_texte_a_trous(self, q):
        trous = q.trous

        def champ(n):
            trou = trous.get(n)
            if trou and trou.choix:  # ses propositions s'impriment à sa place, à entourer
                return groupe_a_entourer(self.propositions_a_entourer(trou.choix, f"{q.graine}|{n}", trou.reponses))
            if not self.corrige:  # un trou sans propres propositions : un simple champ, sans numéro à relier à rien
                return trait("&nbsp;" * 15)
            reponses = trou.reponses if trou else None
            return reponse(f"<u>{html.escape(str(reponses[0]))}</u>") if reponses else "<u>(relevé)</u>"

        h = []
        if not self.corrige:
            if q.choix:
                h.append(note("mots à placer : " + " – ".join(html.escape(c) for c in melange(q.choix, q.graine))))
            if any(trou.choix for trou in trous.values()):
                h.append(note("entourez la bonne proposition et barrez les autres"))
        h.append(self.md.html(q.texte, trou=champ))
        if self.corrige and any(trou.reponses is None for trou in trous.values()):
            h.append(note("trou sans réponse attendue : relevé, correction manuelle"))
        return "".join(h)

    def t_figure_a_trous(self, q):
        """La figure, avec une case blanche à chaque place (``figure_a_trous``) ; au sujet, les étiquettes à y écrire,
        mélangées, au-dessus ; au corrigé, la réponse écrite à la main dans la case."""
        nom = f"figure {q.id.replace('>', '')}{' corrige' if self.corrige else ''}.svg"
        self.figures[nom] = figure_a_trous(q, self.sujet.medias[q.image], self.corrige).encode()
        h = ""
        if not self.corrige:
            etiquettes = dict.fromkeys([*(q.choix or []), *(c for t in q.trous.values() for c in t.choix or [])])
            if etiquettes:
                h = note("à écrire dans les cases : " + " – ".join(html.escape(str(c)) for c in melange(list(etiquettes), q.graine)))
        return h + f'<p><img src="{html.escape(nom)}"></p>'

    def element(self, q, e):
        """Un élément à ranger. Si la question déclare un langage, c'est une ligne de code — l'élève la range dans
        l'éditeur Python lui-même, à l'écran — donc elle s'imprime comme du code, que la banque l'ait entourée
        d'accents graves ou non. La passer au Markdown faisait dépendre son rendu de son indentation : quatre espaces
        de retrait en faisaient un bloc de code (bleu, à chasse fixe, retrait mangé), un « def » en début de ligne
        restait du texte courant — la même fonction s'imprimait donc en deux polices et deux couleurs."""
        return ligne_code(colorer(code_nu(e), q.langage)) if q.langage else self.md.inline(e)

    def t_ordre(self, q):
        if self.corrige:  # les intrus barrés sous la suite, et chaque autre ordre accepté en numéros
            autres = "".join(f"<p>{reponse('ou dans cet ordre : ' + ', '.join(str(q.elements.index(e) + 1) for e in v))}</p>"
                             for v in q.variantes)
            return ("<ol>" + "".join(f"<li>{reponse(self.element(q, e))}</li>" for e in q.elements) + "</ol>" + autres
                    + "".join(f'<p><span style="text-decoration:line-through">{self.element(q, code_nu(e).lstrip() if q.langage else e)}'
                              f'</span>{reponse(" : n’en fait pas partie")}</p>' for e in q.intrus))  # sans son retrait, hors du code
        # assez large pour barrer un numéro écrit au stylo et réécrire le bon à côté
        etapes = q.elements + q.intrus
        ordre = [etapes[i] for i in q.depart] if q.intrus else melange(q.elements, q.graine)
        lignes = "".join(f'<tr><td width="56">&nbsp;</td><td>{self.element(q, e)}</td></tr>' for e in ordre)
        consigne = ("numérotez dans l'ordre les étapes de la suite et barrez celles qui n'en font pas partie" if q.intrus
                    else "numérotez les éléments dans l'ordre")
        return (note(consigne + ", d'abord au crayon à papier puis au stylo ; pour corriger un numéro "
                     "écrit au stylo, barrez-le et écrivez le bon à côté") + f'<table {bordure(CADRE_CODE[1])}>{lignes}</table>')

    def t_appariement(self, q):
        gauches = [p.gauche for p in q.paires]
        droites = [p.droite for p in q.paires] + q.distracteurs
        ordre = melange(range(len(droites)), q.graine)  # position affichée -> indice dans droites
        # le bloc de gauche part de la marge et s'aligne à droite sur ses puces : sa colonne vaut sa plus longue
        # proposition, pas une fraction de la page. Laisser Qt serrer les colonnes tout seul coupait le code au
        # milieu d'un identifiant, la mesure lui épargne ce choix. Plafond : la moitié de ce que laissent la gouttière
        # et les puces (en px, comme la mesure), l'autre moitié revient à l'énoncé de droite.
        # Si la droite est courte, sa place libre revient à la gauche : les puces se décalent plutôt que de couper la
        # phrase de gauche (DS SNT de Seconde, 04/11/2026, « décaller les points pour éviter le retour à la ligne »).
        place = round(LARGEUR_UTILE / PX - GOUTTIERE - 2 * PUCE_LARGE)
        droite_max = round(max(largeur_naturelle(self.md.inline(d)) for d in droites)) + 2 * RETRAIT_CELLULE
        plafond = max(place // 2, place - droite_max)
        colonne = min(round(max(largeur_naturelle(self.md.inline(g)) for g in gauches)) + 2 * RETRAIT_CELLULE, plafond)
        lignes = []
        for i in range(len(droites)):
            # ni numéros ni lettres : ils ne servaient qu'à écrire « 1 → A » en dessous, ce que la flèche remplace
            gauche = self.md.inline(gauches[i]) if i < len(gauches) else ""
            puce = PUCE if i < len(gauches) else "&nbsp;"  # un distracteur n'a pas de départ, seulement une arrivée
            # toutes les colonnes sont fixées sauf la dernière : sinon Qt répartit le reste de la page entre
            # elles, et ce sont les colonnes des puces qui s'étirent, loin de la gouttière.
            lignes.append(f'<tr><td width="{colonne}" align="right">{gauche}</td><td width="{PUCE_LARGE}">{puce}</td>'
                          f'<td width="{GOUTTIERE}">&nbsp;</td><td width="{PUCE_LARGE}">{PUCE}</td>'
                          f'<td>{self.md.inline(droites[ordre[i]])}</td></tr>')
        # le tableau prend aussi la colonne du barème, vide à sa hauteur : autant de retours à la ligne en moins
        tableau = f'{SANS_BAREME}<table width="100%" cellpadding="{RETRAIT_CELLULE}" cellspacing="0">{"".join(lignes)}</table>{SANS_BAREME}'
        if self.corrige:
            reponses = " ; ".join(f"{self.md.inline(p.gauche)} → {reponse(self.md.inline(p.droite))}" for p in q.paires)
            return tableau + f"<p>Réponses : {reponses}</p>"
        # sur papier on relie : la colonne vide du milieu est la place où tracer, les puces en sont les deux bouts.
        # Recopier les lettres dans une phrase en dessous coûtait un aller-retour de l’œil par appariement.
        if "flèche" in q.enonce:  # l'énoncé le dit déjà
            return tableau
        return note("reliez par une flèche chaque élément de gauche à celui de droite") + tableau

    def t_point_selection(self, q):
        h = self.md.html(f"![]({q.image})")
        if not self.corrige:
            return h + note("question interactive : cliquer sur l'image")
        zones = "; ".join(z.decrire() for z in q.zones)
        return h + note("zones attendues, en pixels : " + zones)

    def sans_reprises(self, q, code):
        """``code`` où la solution d'une question que ``q`` reprend devient une ligne qui la renvoie à cette question :
        sur le papier, tout se lit d'un coup, la copie ne donne pas la réponse d'une autre question."""
        for r in q.reprend:
            if r in self.posees:
                numero, repris = self.posees[r]
                reference = q.reference(repris)
                retrait = reference[:len(reference) - len(reference.lstrip(" "))]
                code = code.replace(reference, f"{retrait}# le code de la question {numero}, supposé écrit", 1)
        return code

    def t_code(self, q):
        langage = q.langage
        if not self.corrige:
            initial, solution = sans_marque_modifier(self.sans_reprises(q, q.code_initial)), self.sans_reprises(q, q.solution)
            morceaux = None if self.projet else code_a_completer(initial, solution)
            if morceaux:  # du code à compléter : des lignes à écrire à la place de chaque « # à compléter », rien à recopier
                def code(m):  # Pygments retire les lignes vides de tête, et <pre> ignore son premier saut de ligne
                    vides = "\n" * (1 + len(m) - len(m.lstrip("\n")))
                    return f'<pre style="{STYLE_MONO}; white-space:pre-wrap">{vides}{indentation_visible(colorer(m, langage))}</pre>'
                parties = [code(m) if isinstance(m, str) else
                           lignes_reponse(m[2], m[3], m[0], m[1] and f'<span style="{STYLE_MONO}; white-space:pre">{html.escape(m[1])}</span>',
                                          m[4] - len(m[1]), m[1])
                           for m in morceaux]
                largeur = None  # comme Markdown.code : un code trop large pour la question mord sur la marge
                if self.md.code_large and max(map(len, initial.splitlines())) > self.md.code_large[0]:
                    largeur = self.md.code_large[1]
                return (encadre("".join(parties), CADRE_CODE) if largeur is None
                        else f"{LARGE}{encadre(''.join(parties), CADRE_CODE, largeur=largeur)}{LARGE}")
            depart = self.md.html(f"```{langage}\n{initial.rstrip()}\n```") if initial else ""
            if q.nom_fichier:  # ``FichierRendu`` : programmé dans l'éditeur de l'élève, rendu dans la copie électronique
                return depart + note(dire("programme à enregistrer sous le nom ") + mono(q.nom_fichier))
            return depart + ("" if self.projet else lignes_reponse(q.lignes, niveaux=5))  # un projet se code dans l'éditeur
        precedente, self.solution_precedente = self.solution_precedente, (langage, q.solution)
        if self.projet and precedente and precedente[0] == langage:
            changements = differences(precedente[1], q.solution, langage)
            h = [f"<p>{reponse('<b>Correction</b>')} : <i>changements depuis l’exercice précédent, ajouts surlignés, suppressions barrées</i></p>",
                 changements] if changements else [f"<p>{reponse('<b>Correction</b>')} : <i>code inchangé depuis l’exercice précédent</i></p>"]
        else:
            h = [f"<p>{reponse('<b>Correction</b>')}</p>", self.md.code(q.solution.rstrip(), langage, CADRE_CORRECTION)]
        if q.tests:
            # un appel vide n'existe qu'en SQL : c'est le résultat de la requête même, le dire comme le fait _attendu()
            lignes = "".join(f"<tr><td>{mono(t.appel) if t.appel.strip() else '<i>résultat</i>'}</td>"
                             f"<td>{mono(t.attendu)}</td></tr>" for t in q.tests)
            h.append(tableau(f"<table><tr><th>appel</th><th>attendu</th></tr>{lignes}</table>"))
        if q.tests_code:
            h.append(note("tests complémentaires :") + self.md.html(f"```{langage}\n{q.tests_code.rstrip()}\n```"))
        for m in q.mutants:  # le correcteur du papier juge les assert de l'élève comme le lecteur : contre ces versions
            h.append(note("version fausse que les tests doivent détecter :")
                     + self.md.html(f"```{langage}\n{m.code.rstrip()}\n```"))
        if prelude := re.sub(r"(?m)^# @solution (\S+)$", lambda m: f"# le code de la question {self.posees[m[1]][0]}, supposé écrit"
                             if m[1] in self.posees else m[0], q.prelude_source()).strip():  # le sujet ne l'imprime pas :
            h.append(note("code supposé disponible, exécuté avant celui de l’élève :")  # l'énoncé le dit « supposé disponible »
                     + self.md.html(f"```{langage}\n{prelude}\n```"))
        if q.effet:
            h.append(note("jugé par son effet : toute instruction qui affiche la même chose"
                          + (f" et laisse {', '.join(mono(e) for e in q.observe)} dans le même état" if q.observe else "")
                          + " est juste"))
        if not q.testee() and not self.projet:
            h.append(note("pas de tests : correction manuelle"))
        return "".join(h)

    def t_sql(self, q):
        """Le jeu de données précède la requête : sans lui elle se répond à l'aveugle au sujet, et ne se juge pas au
        corrigé, où c'est lui qui dit si une requête écrite autrement reste juste. Le reste est celui du code. Une base
        nommée (``bases`` de la banque) ne s'imprime qu'à la première question de la section qui s'en sert ; aucune si
        ``afficher_base`` est faux (l'énoncé en montre le schéma)."""
        if not q.afficher_base or q.base in self.bases_vues:
            return self.t_code(q)
        if q.base in self.sujet.bases:
            self.bases_vues.add(q.base)
        script = self.sujet.bases.get(q.base, q.base)
        base = self.md.html(f"```sql\n{script.rstrip()}\n```") if script else ""
        return base + self.t_code(q)

    def t_classement(self, q):
        categories = q.categories
        entete = "".join(f"<th>{html.escape(c)}</th>" for c in categories)
        if self.corrige:
            colonnes = [[e.texte for e in q.elements if e.categorie == c] for c in categories]
            hauteur = max(len(c) for c in colonnes)
            cellule = lambda c, i: reponse(self.md.inline(colonnes[c][i])) if i < len(colonnes[c]) else "&nbsp;"  # noqa: E731
        else:
            hauteur = -(-len(q.elements) // len(categories)) + 1  # de la place pour se tromper
            cellule = lambda c, i: "&nbsp;"  # noqa: E731
        lignes = "".join("<tr>" + "".join(f"<td>{cellule(c, i)}</td>" for c in range(len(categories))) + "</tr>" for i in range(hauteur))
        grille = tableau(f'<table width="100%"><tr>{entete}</tr>{lignes}</table>')
        if self.corrige:
            return grille
        elements = melange([e.texte for e in q.elements], q.graine)
        return "<p>Éléments : " + " – ".join(self.md.inline(e) for e in elements) + "</p>" + grille

    def t_tableau(self, q):
        """La grille telle qu'elle s'affiche : les cases données en noir, les cases à remplir vides au sujet, vertes au
        corrigé — sauf celles qui portent leurs propres choix, qui impriment leurs propositions à entourer, comme un trou.
        Lignes libres : le sujet imprime deux lignes vides de plus que la grille attendue, pour ne pas souffler combien
        il en faut ; le corrigé, la grille attendue. Une grille caractère par caractère (``caracteres``) a des cases carrées
        et centrées, à sa largeur et non à celle de la page. Une case donnée dans une colonne qui a des cases à remplir est
        centrée comme les réponses qu'on y écrit (le professeur, 05/11/2026, DS Secondes 1 à 5, Q13 : « pourquoi les
        coordonées imprimées du sujet ne sont pas centrées ? »)."""
        if q.frise and not q._problemes_frise():
            return self.t_frise(q)
        carre = f' width="{CASE_CARACTERE}" align="center"' if q.caracteres else ""
        a_remplir = {int(cle.split(",")[1]) for cle in q.cellules}
        largeurs = self.largeurs_alignees(q)  # posées sur la première ligne imprimée : l'en-tête, sinon la première de la grille
        entete = "".join(f"<th{largeurs[c]}>{self.md.inline(str(e))}</th>" for c, e in enumerate(q.colonnes))
        if q.a_entete():
            largeurs = [""] * len(q.colonnes)
        entourer = any(trou.choix and not q.en_pion(trou) for trou in q.cellules.values())
        pions = any(map(q.en_pion, q.cellules.values()))  # une réglette (1.47) : des ronds à noircir, comme la figure du sujet
        libres = q.lignes_libres and not self.corrige
        lignes = []
        for r in range(len(q.lignes) + 2 * libres):
            m = min(r, len(q.lignes) - 1)  # au-delà de la grille, les cases à remplir de sa dernière ligne
            cellules = []
            for c in range(len(q.colonnes)):
                trou = q.cellules.get(f"{m},{c}")
                if q.en_pion(trou) and not self.corrige:
                    texte = ROND_VIDE
                elif trou and trou.choix and not q.en_pion(trou):  # une par ligne : la case est étroite, une proposition coupée ne s'entoure pas
                    texte = "<br>".join(self.propositions_a_entourer(trou.choix, f"{q.graine}|{m},{c}", trou.reponses))
                else:
                    texte = self.md.inline(q.case(r, c, self.corrige)) or "&nbsp;"
                    if trou and self.corrige:
                        texte = reponse(texte)
                    elif self.corrige and f"{r},{c}" in (q.a_entourer or ()):
                        texte = f'<span style="background-color:{MARQUE_ENTOURE}">{texte}</span>'  # rond tracé après la mise en page
                if q.en_pion(trou):  # le rond au milieu de la case, à la taille de ceux de la figure du sujet
                    cellules.append(f'<td align="center" valign="middle"><span style="font-size:{TAILLE_ROND}pt">{texte}</span></td>')
                else:
                    cellules.append(f"<td{largeurs[c]}{carre or ' align=\"center\"' * (c in a_remplir and not trou)}>{texte}</td>")
            lignes.append("<tr>" + "".join(cellules) + "</tr>")
            largeurs = [""] * len(q.colonnes)
        grille = tableau(f'<table{"" if q.caracteres else ' width="100%"'}>{f"<tr>{entete}</tr>" if q.a_entete() else ""}{"".join(lignes)}</table>')
        if self.corrige:  # une ``simulation`` (1.47) : la grille n'est qu'une solution parmi d'autres
            return (note(q.consigne_simulation()) if q.simulation else "") + grille
        banque = ("<p>À choisir parmi&nbsp;: " + " – ".join(self.md.inline(str(c)) for c in melange(q.choix, q.graine))
                  + "</p>" if q.choix else "")
        return (banque + (note("entourez la bonne proposition et barrez les autres") if entourer else "")
                + (note("entourez sur le tableau les cases de la réponse") if q.a_entourer else "")
                + (note("noircissez le rond des cases qui portent un pion") if pions else "")
                + (note("remplissez autant de lignes qu'il en faut, pas forcément toutes") if libres else "")
                + (note(CONSIGNE_BASE_PAPIER.format(quoi="chaque nombre")) if any(t.base for t in q.cellules.values()) else "")
                + grille)

    def largeurs_alignees(self, q) -> list[str]:
        """Les attributs ``width`` des colonnes d'un tableau dont les frères d'un groupe partagent les largeurs
        (``noyau.Groupe.tableaux_alignes``), vides sinon : chaque colonne prend la plus large de ses homologues du lot,
        mesurée au corrigé (réponses comprises) pour que sujet et corrigé aient la même grille, et le tout se répartit
        en pourcentages de la largeur de la page, la même pour tous."""
        lot = getattr(self, "alignes", {}).get(id(q))
        if not lot:
            return [""] * len(q.colonnes)
        mesures = [0.0] * len(q.colonnes)
        for t in lot:
            for c, titre in enumerate(t.colonnes):
                mesures[c] = max(mesures[c], largeur_naturelle(f"<b>{self.md.inline(str(titre))}</b>") if t.a_entete() else 0,
                                 *(largeur_naturelle(self.md.inline(t.case(r, c, True))) for r in range(len(t.lignes))))
        mesures = [m + 2 * RETRAIT_CELLULE for m in mesures]
        return [f' width="{100 * m / sum(mesures):.1f}%"' for m in mesures]

    def t_frise(self, q):
        """Le chronogramme d'un ``tableau`` à ``frise`` (1.13), comme à l'écran (``FriseGantt``) : une ligne par
        processus, une colonne par instant ; dans une colonne donnée, la case du processus exécuté est grisée ; au
        corrigé, les cases attendues sont en vert, la couleur des corrections qui reste sur la photocopie."""
        lignes = [f"<tr><th></th>{''.join(f'<th style="font-size:7pt">{html.escape(str(libelle))}</th>' for libelle, _ in q.instants())}</tr>"]  # 18 instants : « 10–11 » tient sans se couper au tiret
        for p in q.processus():
            cellules = []
            for _, case in q.instants():
                donnee = case not in q.cellules
                if donnee or self.corrige:
                    execute = q.execute(case, None if donnee else q.juste())
                    fond = (' bgcolor="#d9d9d9"' if donnee else f' bgcolor="{AJOUT}"') if execute == p else ""
                else:
                    fond = ""
                cellules.append(f"<td{fond}>&nbsp;</td>")
            lignes.append(f"<tr><th>{html.escape(str(p))}</th>{''.join(cellules)}</tr>")
        grille = tableau(f'<table width="100%">{"".join(lignes)}</table>')
        return grille if self.corrige else note("pour chaque instant, coloriez la case du processus exécuté") + grille

    def t_dessin(self, q):
        """La figure de la toile, en vecteurs (``figure_dessin``) : fond, arêtes données, sommets à relier, sur
        laquelle l'élève trace ; au corrigé, ce qui est attendu en vert. Un chemin s'écrit en plus sur une ligne."""
        place = (LARGEUR_UTILE - colonne_numero("147.") * PX) / 72
        nom = f"dessin {q.id.replace('>', '')}{' corrige' if self.corrige else ''}.svg"
        fond = self.images.get(q.image) if q.image else None
        h = ""
        if q.image and not (fond is not None and q.image.rsplit(".", 1)[-1].lower() in IMAGES):  # un fond SVG ne s'emboîte pas
            h, fond = self.md.html(f"![]({q.image})"), None
        self.figures[nom] = figure_dessin(q, fond, self.corrige, place).encode()
        h += f'<p><img src="{html.escape(nom)}"></p>'
        if q.mode == "chemin":
            if not self.corrige:
                return h + f"<p>Ordre de visite : {trait('&nbsp;' * 90)}</p>"
            ordre = reponse(html.escape(" → ".join(map(str, q.juste()))))
            autre = (f" (ou tout autre parcours en {q.parcours.get('type')} depuis {html.escape(str(q.parcours.get('depart')))})"
                     if q.parcours else "")
            return h + f"<p>Ordre de visite : {ordre}{autre}</p>"
        if q.grille:
            return h if self.corrige else h + note("rayer sur la grille chaque mur supprimé")
        if q.propriete == "partition":  # sur papier, on entoure les groupes ; le corrigé les numérote
            return h + (f"<p>{reponse('un groupe par numéro, les numéros eux-mêmes sont indifférents')}</p>" if self.corrige
                        else note("entourer sur la figure chaque groupe d’équipements"))
        if q.mode == "coloration":
            return h + (f"<p>{reponse('ou toute autre coloration où deux sommets reliés ont des couleurs différentes')}</p>" if self.corrige
                        else note(f"écrire à côté de chaque sommet sa couleur, de 0 à {q.couleurs - 1}"))
        if q.mode == "sommets":
            return h + (f"<p>Sommets : {reponse(html.escape(', '.join(q.juste())))}</p>" if self.corrige
                        else note("entourer sur la figure les sommets de la réponse"))
        if q.mode == "arbre" and not self.corrige:
            libres = Counter(s.libelle() for s in q.sommets if not any(
                str(s.nom) in (str(a.source), str(a.cible)) for a in q.decor))  # les valeurs répétées, une fois avec leur nombre
            valeurs = " – ".join(self.md.inline(v) + (f" (×{n})" if n > 1 else "") for v, n in libres.items())
            consigne = "dessiner l'arbre" + (" en complétant celui donné" if q.decor else "") + " sur la figure"
            return f"<p>Valeurs à placer&nbsp;: {valeurs}</p>" + h + note(consigne)
        return h if self.corrige else h + note("tracer les arêtes sur la figure")

    def t_pas_a_pas(self, q):
        """La méthode du cours, ligne à ligne, puis le graphe en grand (``figure_pas_a_pas``), rempli au crayon ; au corrigé,
        l'état final en vert, le plus court chemin et sa longueur, et ce qui ferait deux bons déroulés."""
        place = (LARGEUR_UTILE - colonne_numero("147.") * PX) / 72
        nom = f"pas a pas {q.id.replace('>', '')}{' corrige' if self.corrige else ''}.svg"
        etapes, egalites = q._derouler()
        fin = etapes[-1]["etat"] if self.corrige else None
        self.figures[nom] = figure_pas_a_pas(q, fin, place).encode()
        lignes = []  # [puce, texte] ; la ligne « b » (« • barrer », seconde puce de ⓐ dans le cours) rejoint le texte de ⓐ
        for repere, texte in q.lignes(papier=True):
            puce, texte = texte.split(" ", 1)
            if repere == "b" and lignes:
                lignes[-1][2] += f"<br>{texte}"
            else:
                lignes.append([repere in ("a", "b", "c"), puce, texte])
        rangs = []  # ①, ②, ③ dans une colonne : a) et b) s'alignent sur le texte de ②, quelle que soit la police
        for boucle, puce, texte in lignes:
            if boucle:  # le corps de la boucle, en retrait, « a) » en saillie de son bloc de texte
                texte = (f'<table cellpadding="0" cellspacing="0"><tr><td style="padding-left:18px">{puce}&nbsp;</td>'
                         f'<td style="white-space:nowrap">{texte}</td></tr></table>')  # en HTML, aux couleurs du cours
                # sans retour automatique : seulement ceux du cours (l'utilisateur, 06/11/2026), qui tiennent sur un A4
                puce = ""
            rangs.append(f'<tr><td style="padding-bottom:6px">{puce}&nbsp;</td><td style="padding-bottom:6px">{texte}</td></tr>')
        # 9 pt : à la taille du texte, les retours à la ligne du cours débordaient de la colonne d’un A4
        h = f'<table width="100%" cellpadding="0" cellspacing="0" style="font-size:9pt">{"".join(rangs)}</table>'
        h += f'<p><img src="{html.escape(nom)}"></p>'
        A, F = html.escape(str(q.depart)), html.escape(str(q.arrivee))
        if not self.corrige:
            return h + f"<p>Plus court chemin de {A} à {F} : {trait('&nbsp;' * 60)} longueur : {trait('&nbsp;' * 15)}</p>"
        if fin["chemin"]:
            h += (f"<p>Plus court chemin de {A} à {F} : {reponse(html.escape(' → '.join(reversed(fin['chemin']))))}, "
                  f"longueur : {reponse(str(q.gardees(fin)[str(q.arrivee)][0]))}</p>")
        return h + "".join(note(e) for e in egalites)

    def t_conversion(self, q):
        """La figure de la méthode, en vecteurs (``Conversion.svg``) : vierge au sujet, sans aucune flèche — elles
        viennent avec ce que l'élève écrit — et, pour des divisions, juste le bon nombre (le professeur, DS Première q4 :
        « il y a trop de division par deux ») ; au corrigé, les cases remplies à la main, flèches comprises. Le SVG est
        rangé dans ``figures`` sous un nom propre à la question, et ``ecrire_pdf`` le dessine comme un média."""
        place = LARGEUR_UTILE - colonne_numero("147.") * PX  # la colonne du numéro de question est prise à gauche
        q = q.papier()  # un polynôme aux cases qui paraissent à l'écran : une ligne d'écriture par étape
        if self.corrige:  # méthode au choix : le corrigé la remplit avec celle par défaut
            nom = f"conversion {q.id.replace('>', '')} corrige.svg"
            plan = q.plan(q.juste())
            if q.en_tableau and plan["grille"]:
                return self.conversion_en_tableau(q, plan, nom, q.juste())
            svg = q.svg(plan, q.juste(), couleur_valeurs=VERT_REPONSE, police_valeurs=POLICE_MAIN, largeur_max=place)
            self.figures[nom] = svg.encode()
            return f'<p><img src="{html.escape(nom)}"></p>'
        h = note(CONSIGNE_BASE_PAPIER.format(quoi="le résultat")) if q.demande_base() else ""
        methodes = q.methodes()
        if len(methodes) > 1:  # au choix : une grille par méthode, l'élève en remplit une
            h += "<p>Méthode au choix : remplir une seule des grilles.</p>"
        for g, m in enumerate(methodes, 1):
            nom = f"conversion {q.id.replace('>', '')} {m}.svg"
            plan = q.plan({"methode": m}, tout="imprime")
            if len(methodes) > 1:
                h += f"<p><b>Méthode : {NOM_METHODE[m]}</b></p>"
            if q.en_tableau and plan["grille"]:
                h += self.conversion_en_tableau(q, plan, nom, prefixe=f"G{g}." if len(methodes) > 1 else "")
                continue
            self.figures[nom] = q.svg(plan, largeur_max=place).encode()
            self.reperer_les_cases(q, plan, nom, f"G{g}." if len(methodes) > 1 else "")
            h += f'<p><img src="{html.escape(nom)}"></p>'
        return h

    def reperer_les_cases(self, q, plan, nom, prefixe):
        """Pour le plan joint au PDF (``plan_des_cases``) : les cases à remplir de la figure ``nom``, en unités de son
        ``viewBox`` (``Conversion.rectangle``), et la largeur de celui-ci, qui donne l'échelle où la figure est dessinée."""
        g = q.geometrie(plan)
        self.cases_des_figures[nom] = {"question": q.id, "prefixe": prefixe, "largeur": g["x"](plan["largeur"]) + 1,
                                       "cases": {c["cle"]: q.rectangle(plan, c, g) for c in plan["cases"]
                                                 if c["remplir"] and c["cle"]}}

    def conversion_en_tableau(self, q, plan, nom, valeurs=None, prefixe=""):
        """Une grille ``en_tableau`` en vrai tableau (``Conversion.tableau``), comme à l'écran : une cellule par case et
        par étiquette, fusions comprises, les fonds, les textes donnés, et au corrigé les ``valeurs`` à la main. Le HTML ne
        sait pas tout dire : la première cellule porte l'ancre ``conversion:<nom>``, par laquelle ``ecrire_pdf`` retrouve
        le tableau, fixe ses largeurs, ses hauteurs et la ligne de base de chaque texte (``regler_les_conversions``), puis
        trace après la mise en page les bords, les traits épais et les flèches (``calque`` de ``svg``, rangé dans
        ``figures`` sous ``nom``). La grille garde la question et le ``prefixe`` de ses clés (« G1. » d'une méthode au
        choix, comme ``transcrire_papier.cases_de_conversion``) : le plan des cases joint au PDF les nomme ainsi."""
        t = {**q.tableau(plan), "question": q.id, "prefixe": prefixe}
        self.figures[nom], self.tableaux[nom] = q.svg(plan, calque=True).encode(), t
        rangs = [[] for _ in t["lignes"]]
        for c in sorted(t["cellules"], key=lambda c: (c["ligne"], c["colonne"])):
            quoi = c["case"] or c["etiquette"] or {}
            ecrit = c["case"] and c["case"]["remplir"]
            contenu = str((valeurs or {}).get(quoi["cle"], "") if ecrit else quoi.get("texte", ""))
            texte = "<br>".join(html.escape(ligne) for ligne in contenu.split("\n")) if contenu.strip() else ""
            if texte and ecrit:
                texte = reponse(f"<b>{texte}</b>" if quoi.get("gras") else texte)
            elif texte:
                texte = f'<font color="{quoi.get("couleur") or "#000000"}">{texte}</font>'
                texte = f"<b>{texte}</b>" if quoi.get("gras") else texte
            if not any(rangs):
                texte = f'<a name="conversion:{html.escape(nom)}">{texte or "&nbsp;"}</a>'
            alignement = {"d": "right", "g": "left"}.get(c["case"]["aligne"] if c["case"] else "", "center")
            rangs[c["ligne"]].append(f'<td align="{alignement}"' + (f' rowspan="{c["hauteur"]}"' if c["hauteur"] > 1 else "")
                                     + (f' colspan="{c["largeur"]}"' if c["largeur"] > 1 else "")
                                     + (f' bgcolor="{c["fond"]}"' if c["fond"] else "") + f">{texte or '&nbsp;'}</td>")
        return (f'{SANS_BAREME}<table cellspacing="0" cellpadding="0" border="0">'
                + "".join(f"<tr>{''.join(r)}</tr>" for r in rangs) + f"</table>{SANS_BAREME}")

    def t_schema(self, q):
        """Chaque relation dans la notation du bac : au sujet, ce que la question donne (les attributs, et ce qu'elle ne
        demande pas : clés soulignées, # des clés étrangères, domaines), des traits pour une relation à écrire ; au
        corrigé, le schéma attendu, à la main."""
        domaines = "domaines" in q.demande
        if self.corrige:
            return a_la_main(self.md.html(q.schema_attendu(), manuscrit=True), balise="div")
        consignes = {"attributs": "écrivez ses attributs", "cles": "soulignez la clé primaire",
                     "etrangeres": "faites précéder chaque clé étrangère d'un # et indiquez la clé primaire qu'elle référence",
                     "domaines": "donnez le domaine de chaque attribut"}
        h = note("Pour chaque relation, " + ", ".join(consignes[c] for c in SCHEMA_DEMANDES if c in q.demande) + ".")
        for r in q.relations:
            if r.fixe or "attributs" not in q.demande:
                lignes = [{**q.ligne_juste(a), **({} if r.fixe else {c: v for c, v, demande in (
                    ("cle", False, "cles"), ("reference", "", "etrangeres"), ("domaine", "", "domaines")) if demande in q.demande})}
                    for a in r.attributs]
                h += self.md.html(q.notation(r.nom, lignes, domaines and (r.fixe or "domaines" not in q.demande), cibles=False))
            else:
                h += f"<p>{html.escape(r.nom)} ( {trait('&nbsp;' * 120)} )</p>"
            if not r.fixe and {"etrangeres", "domaines"} & set(q.demande):
                h += lignes_reponse(2)
        return h

    def t_permissions(self, q):
        """Commande : l'invite du terminal et un trait, la commande attendue à la main au corrigé. Grille : les neuf
        droits à cocher, vides au sujet (l'élève y écrit l'état final, pas ce qui change), cochés en vert au corrigé."""
        if q.commande:
            if self.corrige:
                return a_la_main(self.md.html(Permissions._attendu(q), manuscrit=True), balise="div")  # celui du noyau : le widget n'en écrit pas
            return f"<p>{mono(f'{q.utilisateur or 'eleve'}@nsi:~$')} {trait('&nbsp;' * 80)}</p>"
        entete = f"<th>Droits de {mono(q.fichier)}</th>" + "".join(f"<th>{t}</th>" for t in ("lecture (r)", "écriture (w)", "exécution (x)"))
        lignes = "".join(f"<tr><td>{c}</td>" + "".join(
            f'<td align="center">{reponse(COCHE) if self.corrige and q.droits[3 * i + j] != "-" else CASE}</td>' for j in range(3))
            + "</tr>" for i, c in enumerate(CATEGORIES_UNIX))
        return tableau(f'<table width="100%"><tr>{entete}</tr>{lignes}</table>')

    def t_axe(self, q):
        """L'axe gradué en vecteurs (``Axe.svg``, le même dessin qu'à l'écran) : les objets donnés seuls au sujet, l'élève
        dessine les siens au-dessus ; au corrigé, les positions attendues à la main en vert, avec leur portée."""
        nom = f"axe {q.id.replace('>', '')}{' corrige' if self.corrige else ''}.svg"
        place = LARGEUR_UTILE - colonne_numero("147.") * PX
        self.figures[nom] = q.svg(q.juste() if self.corrige else None, couleur=VERT_REPONSE, portees=self.corrige, largeur_max=place).encode()
        return f'<p><img src="{html.escape(nom)}"></p>'

    def t_liste_chainee(self, q):
        """Les maillons en vecteurs (``ListeChainee.svg``, le même dessin qu'à l'écran) : au sujet, les cases et les pointeurs
        donnés seuls, l'élève trace ses flèches au stylo (ou écrit None dans la case) ; au corrigé, les pointeurs attendus
        en vert."""
        nom = f"chaine {q.id.replace('>', '')}{' corrige' if self.corrige else ''}.svg"
        place = LARGEUR_UTILE - colonne_numero("147.") * PX
        self.figures[nom] = q.svg(q.juste() if self.corrige else None, couleur=VERT_REPONSE, largeur_max=place).encode()
        return f'<p><img src="{html.escape(nom)}"></p>'

    def t_deroulement(self, q):
        """Le déroulement en vecteurs (``Deroulement.svg``) : au sujet, l'espace blanc où l'élève construit l'arbre sur
        sa copie, comme au bac ; au corrigé, l'arbre attendu, la liste de départ en noir, le reste à la main en vert."""
        nom = f"deroulement {q.id.replace('>', '')}{' corrige' if self.corrige else ''}.svg"
        largeur = min(q.LARGEUR, LARGEUR_UTILE - colonne_numero("147.") * PX)
        self.figures[nom] = q.svg(q.juste() if self.corrige else None, couleur=VERT_REPONSE, largeur=largeur, main=True).encode()
        return f'<p><img src="{html.escape(nom)}"></p>'

    def t_personnalise(self, q):
        """Un widget ne s'imprime pas : le sujet et le corrigé s'en tiennent au repli Markdown de la question."""
        if self.corrige:
            return self.md.html(q.attendu) if q.attendu else note("correction manuelle")
        if q.papier:
            return self.md.html(q.papier)
        return note("question interactive : elle n'a pas de forme papier") + lignes_reponse(3)


def largeur_case_figure(q) -> float:
    """La largeur en points, à la taille déclarée de la figure, de chaque case d'une ``figure_a_trous`` : la plus longue
    étiquette en 10 pt, 60 au moins, et une marge (16 points de haut) ; ``vue_papier`` y pose ses champs."""
    mots = [str(m) for t in q.trous.values() for m in (t.choix or []) + (t.reponses or [])] + [str(m) for m in q.choix or []]
    police = QFont("Carlito")
    police.setPixelSize(10)  # en points : la figure est imprimée à 72 ppp
    metrique = QFontMetricsF(police)
    return max([metrique.horizontalAdvance(m) for m in mots] + [60]) + 8


def pouces_de_figure(source: bytes) -> float:
    """La largeur déclarée d'une image de ``figure_a_trous``, en pouces (``width`` d'un SVG, ``pHYs`` d'une image)."""
    if source.lstrip().startswith(b"<"):
        return float(ET.fromstring(source.decode()).get("width").removesuffix("in"))
    image = QImage.fromData(source)
    return image.width() / (image.dotsPerMeterX() * 0.0254 or 96)


def figure_a_trous(q, source, corrige):
    """L'image d'une ``figure_a_trous`` en SVG, à sa taille déclarée, avec une case blanche centrée à chaque place, assez
    large pour la plus longue étiquette en 10 pt ; au corrigé, la réponse dedans, à la main, en vert. Une image de pixels
    s'embarque dans un SVG à sa taille d'impression (``pHYs``)."""
    if source.lstrip().startswith(b"<"):
        texte = source.decode()
        racine = ET.fromstring(texte)
        largeur, hauteur = (float(v) for v in racine.get("viewBox").split()[2:])
        pouces = float(racine.get("width").removesuffix("in"))
    else:
        image = QImage.fromData(source)
        largeur, hauteur = image.width(), image.height()
        pouces = largeur / (image.dotsPerMeterX() * 0.0254 or 96)
        texte = (f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{pouces:.3f}in" '
                 f'height="{pouces * hauteur / largeur:.3f}in" viewBox="0 0 {largeur} {hauteur}"><image x="0" y="0" '
                 f'width="{largeur}" height="{hauteur}" xlink:href="data:image/png;base64,{base64.b64encode(source).decode()}"/></svg>')
    point = largeur / (pouces * 72)  # unités de la figure par point imprimé
    l = largeur_case_figure(q)
    cases = []
    for n, (x, y) in q.places.items():
        x, y = x * largeur, y * hauteur
        cases.append(f'<rect x="{x - l * point / 2:.1f}" y="{y - 8 * point:.1f}" width="{l * point:.1f}" height="{16 * point:.1f}" '
                     f'fill="white" stroke="black" stroke-width="{0.75 * point:.1f}"/>')
        reponses = q.trous[n].reponses
        if corrige and reponses:
            cases.append(f'<text x="{x:.1f}" y="{y + 3.5 * point:.1f}" font-family="{POLICE_MAIN}" font-size="{9 * point:.1f}" '
                         f'fill="{VERT_REPONSE}" text-anchor="middle">{html.escape(str(reponses[0]))}</text>')
    return texte.replace("</svg>", "".join(cases) + "</svg>")


def figure_grille(q, corrige, largeur_max):
    """Un ``dessin`` à ``grille`` (1.66) : la grille aux mêmes pas que ``modele.ToileLabyrinthe``, numéros de ligne et de
    colonne compris ; au sujet tous les murs, l'élève raye ceux qu'il supprime ; au corrigé le labyrinthe attendu, ses
    murs restants en noir (``Dessin.murs``, le tracé de l'écran) et ses passages en vert, d'un centre de cellule à l'autre."""
    haut, long = q.grille
    m, pas = 24, 50
    largeur, hauteur = m + pas * long + 4, m + pas * haut + 4
    reduction = min(1, largeur_max * 96 / largeur)
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{largeur * reduction / 96:.3f}in" '
         f'height="{hauteur * reduction / 96:.3f}in" viewBox="0 0 {largeur} {hauteur}">']
    o += [f'<text x="{m + pas * (c + 0.5)}" y="{m - 7}" font-size="14" text-anchor="middle" fill="#78909c">{c}</text>' for c in range(long)]
    o += [f'<text x="{m / 2}" y="{m + pas * (l + 0.5) + 5}" font-size="14" text-anchor="middle" fill="#78909c">{l}</text>' for l in range(haut)]
    centre = {f"{l},{c}": (m + pas * (c + 0.5), m + pas * (l + 0.5)) for l in range(haut) for c in range(long)}
    if corrige:
        for a, b, _ in q._attendues():
            (x1, y1), (x2, y2) = centre[str(a)], centre[str(b)]
            o.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{VERT_REPONSE}" stroke-width="3" stroke-linecap="round"/>')
    for (x1, y1), (x2, y2) in q.murs(q._attendues() if corrige else []):
        o.append(f'<line x1="{m + pas * x1}" y1="{m + pas * y1}" x2="{m + pas * x2}" y2="{m + pas * y2}" stroke="#37474f" '
                 f'stroke-width="3" stroke-linecap="round"/>')
    o.append(f'<rect x="{m}" y="{m}" width="{pas * long}" height="{pas * haut}" fill="none" stroke="#37474f" stroke-width="3"/>')
    return "\n".join(o + ["</svg>"])


def dixieme(v):
    return f"{v:.1f}"


def entete_svg(largeur, hauteur, largeur_max):
    """L'en-tête d'une figure dessinée en pixels de l'écran (1/96 de pouce), réduite à ``largeur_max`` pouces si besoin."""
    reduction = min(1, largeur_max * 96 / largeur)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
            f'width="{largeur * reduction / 96:.3f}in" height="{hauteur * reduction / 96:.3f}in" viewBox="0 0 {largeur} {hauteur}">')


def pointe(x1, y1, x2, y2, couleur):
    """QtSvg ne connaît pas ``marker`` : la pointe de la toile, en triangle."""
    angle = math.atan2(y2 - y1, x2 - x1)
    coins = [(x2, y2)] + [(x2 - 12 * math.cos(angle + c), y2 - 12 * math.sin(angle + c)) for c in (0.4, -0.4)]
    return f'<polygon points="{" ".join(f"{dixieme(a)},{dixieme(b)}" for a, b in coins)}" fill="{couleur}"/>'


def trait_entre(a, b, couleur, epaisseur, oriente=False):
    """Une arête de la toile entre deux sommets (``Sommet``, ou ``None`` : rien), arrêtée au bord des cercles ; orientée,
    décalée de côté et fléchée, comme ``ToileGraphe``."""
    if not a or not b:
        return ""
    dx, dy = b.x - a.x, b.y - a.y
    n = math.hypot(dx, dy) or 1
    ux, uy, e = dx / n, dy / n, ECART if oriente else 0
    p = (a.x + ux * RAYON - uy * e, a.y + uy * RAYON + ux * e, b.x - ux * RAYON - uy * e, b.y - uy * RAYON + ux * e)
    return (f'<line x1="{dixieme(p[0])}" y1="{dixieme(p[1])}" x2="{dixieme(p[2])}" y2="{dixieme(p[3])}" stroke="{couleur}" '
            f'stroke-width="{epaisseur}"/>' + (pointe(*p, couleur) if oriente else ""))


def etiquette_entre(a, b, texte, couleur):
    """L'étiquette d'une arête (sa longueur, son poids), en cartouche blanc au milieu."""
    if not texte or not a or not b:
        return ""
    mx, my, w = (a.x + b.x) / 2, (a.y + b.y) / 2, 8 * len(str(texte)) + 10
    return (f'<rect x="{dixieme(mx - w / 2)}" y="{dixieme(my - 10)}" width="{w}" height="20" fill="#ffffff" stroke="{couleur}"/>'
            f'<text x="{dixieme(mx)}" y="{dixieme(my + 5)}" font-size="14" text-anchor="middle" fill="{couleur}">'
            f'{html.escape(str(texte))}</text>')


def rond_sommet(s):
    return f'<circle cx="{s.x}" cy="{s.y}" r="{RAYON}" fill="#ffffff" stroke="#37474f" stroke-width="2"/>'


def pastille(s, texte):
    """Un numéro du corrigé (rang dans un chemin, couleur, ordre où une ville est entourée), en haut à droite du sommet."""
    w = max(18, 8 * len(texte) + 8)
    return (f'<rect x="{dixieme(s.x + RAYON * 0.7 - w / 2)}" y="{dixieme(s.y - RAYON * 0.7 - 9)}" width="{w}" height="18" '
            f'rx="9" fill="{VERT_REPONSE}"/><text x="{dixieme(s.x + RAYON * 0.7)}" y="{dixieme(s.y - RAYON * 0.7 + 4)}" '
            f'font-size="12" text-anchor="middle" fill="#ffffff">{texte}</text>')


def figure_dessin(q, fond, corrige, largeur_max):
    """La toile d'une question ``dessin`` (``modele.ToileGraphe``) en SVG, aux mêmes coordonnées : un pixel de l'écran y
    vaut 1/96 de pouce, réduit à ``largeur_max`` pouces. Au corrigé, les arêtes attendues ou le chemin numéroté en vert."""
    if q.grille:
        return figure_grille(q, corrige, largeur_max)
    liste = cadre = q.disposes(RAYON + 4)
    if q.mode == "arbre":  # les sommets n'ont pas de place : celle de l'arbre, disposé comme sur la toile (``agencement``)
        donne = [[a.source, a.cible, a.etiquette] for a in q.decor]
        def placer(triples):
            return [Sommet(n, px + RAYON + 4, py + RAYON + 4, texte=q.libelles().get(n, ""))
                    for n, (px, py) in q.agencement(triples, vides=False)[0].items()] if triples else []
        cadre = placer(q._attendues() + donne)  # au sujet, la place de dessiner l'arbre entier
        liste = cadre if corrige else placer(donne)
    marge = (RAYON + 4, RAYON + 4) if q.mode == "arbre" else (2 * RAYON + 40, 2 * RAYON + 16)
    largeur = max([s.x for s in cadre] or [0]) + marge[0]
    hauteur = max([s.y + marge[1] for s in cadre]  # un nom trop long, écrit sous le cercle (plus bas), y tient aussi
                  + [s.y + RAYON + 21 for s in liste if 8 * len(s.libelle()) > TENU] or [marge[1]])
    if fond is not None:  # une QImage, celle des autres images du sujet (``charger_image``), posée sur le blanc du papier
        tampon = QBuffer()
        tampon.open(QIODevice.OpenModeFlag.WriteOnly)
        sur_blanc(fond).save(tampon, "PNG")
        largeur, hauteur = max(largeur, fond.width()), max(hauteur, fond.height())
    o = [entete_svg(largeur, hauteur, largeur_max)]
    if fond is not None:
        o.append(f'<image x="0" y="0" width="{fond.width()}" height="{fond.height()}" '
                 f'xlink:href="data:image/png;base64,{base64.b64encode(bytes(tampon.data())).decode()}"/>')
    sommets = {str(s.nom): s for s in liste}
    cotes_muets = liste is not q.sommets and q.cotes() == ["g", "d"]  # arbre disposé : g et d se voient à la place du fils

    def trait_arete(source, cible, couleur, epaisseur):
        return trait_entre(sommets.get(str(source)), sommets.get(str(cible)), couleur, epaisseur, q.oriente)

    def etiquette(source, cible, texte, couleur):
        return "" if cotes_muets else etiquette_entre(sommets.get(str(source)), sommets.get(str(cible)), texte, couleur)

    for a in q.decor:
        o.append(trait_arete(a.source, a.cible, "#90a4ae", 2))
    for a in q.decor:
        o.append(etiquette(a.source, a.cible, a.etiquette, "#607d8b"))
    if corrige and q.mode != "chemin":
        o += [trait_arete(a.source, a.cible, VERT_REPONSE, 3) for a in q.aretes]
        o += [etiquette(a.source, a.cible, a.etiquette, VERT_REPONSE) for a in q.aretes]
    chemin = [n for n in q.juste() if n in sommets] if corrige and q.mode == "chemin" else []
    for a, b in zip(chemin, chemin[1:]) if q.parcours is None else ():  # un parcours : les numéros seuls (ToileGraphe)
        o.append(f'<line x1="{sommets[a].x}" y1="{sommets[a].y}" x2="{sommets[b].x}" y2="{sommets[b].y}" '
                 f'stroke="{VERT_REPONSE}" stroke-width="3"/>')
    designes = set(q.juste()) if corrige and q.mode == "sommets" else set()
    for s in liste:
        o.append(rond_sommet(s))
        if str(s.nom) in designes:  # le sommet attendu, entouré comme l'élève le fait sur sa copie
            o.append(f'<circle cx="{s.x}" cy="{s.y}" r="{RAYON + 5}" fill="none" stroke="{VERT_REPONSE}" stroke-width="3"/>')
        if s.marque == "final":
            o.append(f'<circle cx="{s.x}" cy="{s.y}" r="{RAYON - 4}" fill="none" stroke="#37474f" stroke-width="2"/>')
        if s.marque == "initial":
            o.append(f'<line x1="{s.x - 2 * RAYON}" y1="{s.y}" x2="{s.x - RAYON}" y2="{s.y}" stroke="#37474f" '
                     f'stroke-width="2"/>' + pointe(s.x - 2 * RAYON, s.y, s.x - RAYON, s.y, "#37474f"))
        dessous = 8 * len(s.libelle()) > TENU  # comme la toile : un nom trop long pour son cercle s'écrit dessous
        if dessous:  # sur un fond blanc : les arêtes qui partent du nœud passent dessous
            w = 8 * len(s.libelle()) + 6
            o.append(f'<rect x="{dixieme(s.x - w / 2)}" y="{s.y + RAYON + 2}" width="{w}" height="17" fill="#ffffff"/>')
        o.append(f'<text x="{s.x}" y="{s.y + (RAYON + 15 if dessous else 5)}" font-size="14" text-anchor="middle" '
                 f'fill="#000000">{html.escape(s.libelle())}</text>')
    teintes = q.juste() if corrige and q.mode == "coloration" else {}
    for s in liste:
        rangs = ",".join(str(i + 1) for i, n in enumerate(chemin) if n == str(s.nom)) or str(teintes.get(str(s.nom), ""))
        if rangs:
            o.append(pastille(s, rangs))
    return "\n".join(o + ["</svg>"])


def figure_pas_a_pas(q, etat, largeur_max):
    """Le graphe d'une question ``pas_a_pas`` en grand, pour le crayon : les routes et leurs longueurs, sous chaque ville
    des lignes « ___ km de A, en venant de ___ » comme à l'écran, autant que la ville la plus servie du déroulé en
    reçoit, où ⓐ ajoute et ⓑ barre (une seule « ___ km de A » sous le départ, dans un cadre étroit). ``etat`` (au corrigé, le dernier de
    ``q.etapes()``) : villes entourées et numérotées dans l'ordre, lignes écrites (barrées comme à l'écran), plus court
    chemin, en vert."""
    A = html.escape(str(q.depart))
    pas = 19  # une ligne d'écriture
    rangs = max([2] + [len(ls) for ls in q._lignes(q._derouler()[0][-1]["etat"]).values()])  # le même nombre partout
    cadre_l, cadre_h, sous = 170, 4 + rangs * pas, RAYON + 6  # le cadre, et l'écart entre le centre d'une ville et son haut
    xs, ys = [s.x for s in q.sommets] or [0], [s.y for s in q.sommets] or [0]
    k = max(1, (largeur_max * 96 - cadre_l) / ((max(xs) - min(xs)) or 1))  # étiré à la largeur utile, cadres compris
    kv = 2 * k  # et deux fois plus en hauteur : les cadres sous les villes y prennent leur place sans couvrir les routes
    villes = {str(s.nom): Sommet(s.nom, cadre_l / 2 + (s.x - min(xs)) * k, RAYON + 8 + (s.y - min(ys)) * kv) for s in q.sommets}
    largeur = cadre_l + (max(xs) - min(xs)) * k
    hauteur = RAYON + 8 + (max(ys) - min(ys)) * kv + sous + cadre_h + 2
    o = [entete_svg(largeur, hauteur, largeur_max)]
    etat = etat or {}
    chemin = etat.get("chemin", [])
    pris = {frozenset(c) for c in zip(chemin, chemin[1:])}
    for a, b, longueur in q.routes():
        vert = frozenset((a, b)) in pris
        o.append(trait_entre(villes.get(a), villes.get(b), VERT_REPONSE if vert else "#90a4ae", 3 if vert else 2))
    entourees = etat.get("entourees", [])
    for nom, s in villes.items():
        o.append(rond_sommet(s))
        if nom in entourees:
            o.append(f'<circle cx="{dixieme(s.x)}" cy="{dixieme(s.y)}" r="{RAYON + 5}" fill="none" stroke="{VERT_REPONSE}" stroke-width="3"/>')
            o.append(pastille(s, str(entourees.index(nom) + 1)))
        o.append(f'<text x="{dixieme(s.x)}" y="{dixieme(s.y + 5)}" font-size="14" text-anchor="middle" fill="#000000">'
                 f'{html.escape(nom)}</text>')
        depart = nom == str(q.depart)  # le départ ne vient de nulle part : une ligne, sans « en venant de »
        l_cadre = 37 + 6.5 * len(f"km de {q.depart}") if depart else cadre_l  # et un cadre à sa mesure (l'utilisateur, 16/10/2026)
        x0, y0 = s.x - l_cadre / 2, s.y + sous
        ecrites = q._lignes(etat).get(nom, [])
        o.append(f'<rect x="{dixieme(x0)}" y="{dixieme(y0)}" width="{dixieme(l_cadre)}" height="{4 + pas if depart else cadre_h}" '
                 f'fill="#ffffff" stroke="#37474f" stroke-width="1"/>')
        for rang in range(1 if depart else rangs):
            y = y0 + 16 + pas * rang
            distance, venant_de, barree = (ecrites[rang] if rang < len(ecrites) else ("", "", False))
            # les traits à remplir restent pâles (#90a4ae, 0,75) : l'OCR de la copie les distingue de l'écriture (l'utilisateur, 16/10/2026)
            o.append(f'<line x1="{dixieme(x0 + 4)}" y1="{dixieme(y + 3)}" x2="{dixieme(x0 + 26)}" y2="{dixieme(y + 3)}" '
                     f'stroke="#90a4ae" stroke-width="0.75"/>')
            o.append(f'<text x="{dixieme(x0 + 29)}" y="{dixieme(y)}" font-size="11" fill="#000000">'
                     f'km de {A}{"" if depart else ", en venant de"}</text>')
            if not depart:
                o.append(f'<line x1="{dixieme(x0 + 144)}" y1="{dixieme(y + 3)}" x2="{dixieme(x0 + 166)}" y2="{dixieme(y + 3)}" '
                         f'stroke="#90a4ae" stroke-width="0.75"/>')
            for x, valeur in ((x0 + 15, distance), (x0 + 155, venant_de)):
                if valeur not in ("", None):
                    o.append(f'<text x="{dixieme(x)}" y="{dixieme(y)}" font-family="{POLICE_MAIN}" font-size="15" '
                             f'text-anchor="middle" fill="{VERT_REPONSE}">{html.escape(str(valeur))}</text>')
            if barree:  # ⓑ : la ligne barrée d'un trait, comme l'élève le fait au crayon
                o.append(f'<line x1="{dixieme(x0 + 4)}" y1="{dixieme(y - 4)}" x2="{dixieme(x0 + l_cadre - 4)}" '
                         f'y2="{dixieme(y - 4)}" stroke="{VERT_REPONSE}" stroke-width="1.5"/>')
    for a, b, longueur in q.routes():  # par-dessus les cadres, qu'une longueur ne s'y cache jamais
        o.append(etiquette_entre(villes.get(a), villes.get(b), longueur, "#607d8b"))
    return "\n".join(o + ["</svg>"])


# ---------------------------------------------------------------- PDF

COULEURS_DE_CORRECTION = {c[1:].lower() for c in (VERT_REPONSE, AJOUT, ROUGE_CORRECTION)}  # restent, même sur la photocopie


def noir_et_blanc(contenu):
    """Le HTML, écrit avec la palette du cours, rendu pour la photocopie : texte coloré en noir (il est déjà en gras), fonds, bordures (et texte d'une conversion en tableau) en
    gris de même luminance. Les commentaires du code, déjà gris, le restent, et le vert et le rouge de la correction aussi."""
    def texte(m):
        couleur = m.group(1).lower()
        return m.group(0) if couleur in COULEURS_DE_CORRECTION or len({couleur[i:i + 2] for i in (0, 2, 4)}) == 1 else "color:#000000"

    def fond(m):
        return m.group(0) if m.group(2).lower() in COULEURS_DE_CORRECTION else m.group(1) + gris_de(m.group(2))

    return COULEUR_FOND.sub(fond, COULEUR_TEXTE.sub(texte, contenu))


def gris_de(hexa):
    """``"rrggbb"`` -> ``"#gggggg"``, le gris de même luminance."""
    r, v, b = (int(hexa[i:i + 2], 16) for i in (0, 2, 4))
    return "#" + f"{round(0.299 * r + 0.587 * v + 0.114 * b):02x}" * 3


def svg_gris(octets):
    """Un SVG pour la photocopie : chaque couleur ``#rrggbb`` (potrace n'en écrit pas d'autre forme) au gris de même luminance,
    sauf celles de la correction, comme ``noir_et_blanc`` (le corrigé d'une figure de conversion). Une image PNG qu'il
    embarque (le fond d'un ``dessin``, ``figure_dessin``) passe en gris comme les autres images du sujet."""
    def png_gris(m):
        tampon = QBuffer()
        tampon.open(QIODevice.OpenModeFlag.WriteOnly)
        sur_blanc(QImage.fromData(base64.b64decode(m.group(1)))).convertToFormat(QImage.Format_Grayscale8).save(tampon, "PNG")
        return "data:image/png;base64," + base64.b64encode(bytes(tampon.data())).decode()
    texte = re.sub(r"data:image/png;base64,([A-Za-z0-9+/=]+)", png_gris, octets.decode())
    return re.sub(r"#([0-9a-fA-F]{6})\b", lambda m: m.group(0) if m.group(1).lower() in COULEURS_DE_CORRECTION
                  else gris_de(m.group(1)), texte).encode()


def agrandir(contenu):
    """Le HTML avec ses tailles de police et ses colonnes fixes multipliées par ECHELLE_AGRANDI."""
    return TAILLE.sub(lambda m: f"{m.group(1)}{float(m.group(2)) * ECHELLE_AGRANDI:g}{m.group(3)}", contenu)


COULEURS = r"(?:rouge|verte?|bleue?|jaune|orange|violette?|rose|marron)s?"
MOT_COULEUR = re.compile(rf"\b{COULEURS}\b", re.I)
# une chose désignée par sa couleur : « en rouge », « la courbe verte », « les cases bleues », « de couleur orange »
DESIGNE_PAR_COULEUR = re.compile(rf"\b(?:en|couleur|(?:l[ea]|les|du|des|aux?|une?)\s+\w+)\s+{COULEURS}\b", re.I)
STYLES_COULEUR = {"rouge", "vert", "bleu", "orange", "violet", "gris"}  # styles_texte.json : couleur sans autre marque
STYLE_DE_MOT = re.compile(r"\]\{\.([a-z][a-z0-9_-]*)\}")
# ce que voit le corrigé, ou ce qui n'est pas du texte : hors du contrôle
HORS_CONTROLE = {"id", "source", "usage", "explication", "explication_fausse", "aide_cours", "masque_cours",
                 "zone_cours", "sections_cours", "justification", "selon", "revele", "electronique", "difficulte",
                 "feedback", "groupe_parent"}   # groupe_parent : le Groupe, ses sœurs ne sont pas cette question


def repose_sur_la_couleur(q) -> str | None:
    """Pourquoi la question ``q`` semble ne se distinguer que par la couleur (TODO Aménagements, « Tolérance sur les
    couleurs »), ou None. Heuristique d'AVERTISSEMENT, jamais de refus ; ``couleur_obligatoire`` la fait taire. Trois
    signes, sur l'énoncé, l'énoncé simplifié, l'aide, les indices et les propositions (pas le corrigé) :
    deux propositions identiques au mot de couleur près (« le fil rouge » / « le fil vert ») ; deux styles de couleur
    différents ([a]{.rouge} et [b]{.vert} : tous deux en gras, le noir et blanc les confond ; un seul se distingue par
    son gras) ; une chose désignée par sa couleur (« la courbe rouge », « en vert ») dans une question qui a une image.
    Attrape À TORT : une image dont les zones colorées portent aussi un libellé ; la couleur comme sujet d'étude
    (codage RVB, « le rouge vaut 255 ») avec une image. Ne voit pas : une couleur portée par l'image seule, sans mot."""
    if getattr(q, "couleur_obligatoire", False):
        return None
    textes, listes, image, vus = [], [], False, {id(q)}

    def parcourir(valeur, cle=""):
        nonlocal image
        if cle in HORS_CONTROLE or (not isinstance(valeur, str) and id(valeur) in vus):
            return
        if not isinstance(valeur, str):
            vus.add(id(valeur))  # une référence circulaire (parent, graphe, liste) ne se parcourt qu'une fois
        if isinstance(valeur, str):
            textes.append(valeur)
            image |= "![" in valeur or (cle == "image" and bool(valeur))
        elif isinstance(valeur, (list, tuple)):
            listes.append([t for v in valeur if isinstance(t := getattr(v, "texte", v), str)])  # Proposition : son texte
            for v in valeur:
                parcourir(v)
        elif isinstance(valeur, dict):
            for k, v in valeur.items():
                parcourir(v, str(k))
        elif hasattr(valeur, "__dict__") and not isinstance(valeur, type):
            image |= cle == "image" and valeur is not None
            for k, v in vars(valeur).items():
                if not k.startswith("_"):
                    parcourir(v, k)

    for k, v in vars(q).items():
        if not k.startswith("_") and k not in ("sous_questions", "questions"):  # les feuilles sont vues une à une
            parcourir(v, k)
    for liste in listes:
        vues = {}
        for texte in liste:
            if MOT_COULEUR.search(texte):
                sans = " ".join(MOT_COULEUR.sub("", texte).split()).lower()
                if re.sub(r"\W+", "", sans) and sans in vues and vues[sans] != texte:  # « rouge », `"bleu"` seuls : des mots lisibles
                    return f"« {vues[sans]} » et « {texte} » ne diffèrent que par la couleur"
                vues[sans] = texte
    styles = {m for t in textes for m in STYLE_DE_MOT.findall(t)} & STYLES_COULEUR
    if len(styles) > 1:
        return "styles " + ", ".join(sorted(styles)) + " côte à côte"
    if image and (m := next((m for t in textes if (m := DESIGNE_PAR_COULEUR.search(t))), None)):
        return f"« {m.group(0)} » avec une image"
    return None


def sans_empattement(contenu: str) -> str:
    """Le HTML de l'aménagement sans_empattement : corps, styles à empattement et formules en POLICE_SANS_EMPATTEMENT
    (le code garde sa chasse fixe, l'écriture manuscrite du corrigé sa police), colonnes fixes élargies de
    LARGEUR_SANS_EMPATTEMENT (barème, grilles à largeur imposée). Un tableau à 100 % de la largeur, déjà plein en
    Carlito, coupe encore ses en-têtes en milieu de mot, comme en agrandi (TODO Aménagements)."""
    contenu = COLONNE_FIXE.sub(lambda m: f"{m.group(1)}{float(m.group(2)) * LARGEUR_SANS_EMPATTEMENT:g}{m.group(3)}",
                               contenu)
    return FAMILLE_REMPLACEE.sub(f"font-family:'{POLICE_SANS_EMPATTEMENT}'", contenu)


def eviter_les_coupures(document):
    """Une question (table de premier niveau) qui tient sur une page n'est pas coupée, et un titre de section ne reste
    pas seul en bas de page, séparé de sa première question : saut de page avant la question, ou avant le titre
    (avec les consignes qui le suivent) s'il la précède."""
    disposition = document.documentLayout()
    debut = 0  # fin de la question précédente : un titre placé après introduit celle-ci
    for cadre in document.rootFrame().childFrames():
        rect = disposition.frameBoundingRect(cadre)
        page = rect.top() // HAUTEUR_UTILE
        coupee = rect.height() <= HAUTEUR_UTILE and page != (rect.bottom() - 1) // HAUTEUR_UTILE
        bloc, titre = document.findBlock(debut), None
        while bloc.isValid() and bloc.position() < cadre.firstPosition() and not titre:
            titre = bloc if bloc.blockFormat().headingLevel() else None
            bloc = bloc.next()
        debut = cadre.lastPosition() + 1
        if titre and (coupee or disposition.blockBoundingRect(titre).top() // HAUTEUR_UTILE != page):
            format_bloc = titre.blockFormat()
            format_bloc.setPageBreakPolicy(QTextFormat.PageBreak_AlwaysBefore)
            QTextCursor(titre).setBlockFormat(format_bloc)
        elif coupee:
            format_cadre = cadre.format()
            format_cadre.setPageBreakPolicy(QTextFormat.PageBreak_AlwaysBefore)
            cadre.setFormat(format_cadre)


def commencer_sur_une_feuille(document, titres):
    """Les sections ``nouvelle_page`` (``titres`` : leurs blocs, qui portent le saut de page) commencent sur une page
    impaire : imprimées en recto-verso, elles sont sur une feuille à elles et se ramassent à part. Tombée sur une page
    paire, la section est repoussée d'une page, laissée blanche."""
    for titre in titres:
        if document.documentLayout().blockBoundingRect(titre).top() // HAUTEUR_UTILE % 2:
            QTextCursor(titre).insertBlock()  # ``titre`` reste le bloc de tête, vidé : c'est lui qui ouvre la page blanche
            blanche = QTextBlockFormat()
            blanche.setPageBreakPolicy(QTextFormat.PageBreak_AlwaysBefore)
            QTextCursor(titre).setBlockFormat(blanche)


def sauts_de_page(document):
    """Les blocs qui portent un saut de page demandé par le HTML (Qt le reporte sur le bloc qui suit le paragraphe vide)."""
    bloc, sauts = document.begin(), []
    while bloc.isValid():
        if bloc.blockFormat().pageBreakPolicy() & QTextFormat.PageBreak_AlwaysBefore:
            sauts.append(bloc)
        bloc = bloc.next()
    return sauts


def police_du_corps(taille: float = 10, amenagements: frozenset[str] = frozenset()) -> QFont:
    """La police du texte ; POLICE_SANS_EMPATTEMENT, au corps réduit de CORPS_SANS_EMPATTEMENT, avec l'aménagement
    sans_empattement."""
    police = (QFont(POLICE_SANS_EMPATTEMENT, round(taille * CORPS_SANS_EMPATTEMENT)) if "sans_empattement" in amenagements
              else QFont(POLICE, taille))
    police.setFeature(QFont.Tag("liga"), 0)  # « ti », « fi »… : une ligature se copie mal (« fonc on » pour « fonction »)
    return police


def colonnes_de_code(largeur, echelle=1):
    """Combien de caractères de code tiennent dans un cadre de cette largeur, en points. Mesuré par Qt sur le
    périphérique du PDF : compté à la taille de police, on se tromperait de 96/72, et d'autant plus si la police
    à chasse fixe du style de cours manque et que Qt en substitue une autre."""
    pdf = QPdfWriter(os.devnull)
    pdf.setResolution(72)
    police = QFont(MONO)
    police.setPointSizeF(9 * echelle)  # la taille de STYLE_MONO, qu'agrandit le profil agrandi
    return int((largeur - 2 * 6 * PX - 2) / QFontMetricsF(police, pdf).horizontalAdvance("x"))  # rembourrage, bordures


def largeur_naturelle(fragment):
    """La largeur qu’un fragment HTML en ligne occupe sans revenir à la ligne, mesurée par Qt lui-même :
    l’estimer au nombre de caractères se tromperait sur le code, en chasse fixe et plus large que le corps."""
    document = QTextDocument()
    document.setDefaultFont(police_du_corps())
    document.setHtml(fragment)
    return document.idealWidth()


def bordures_au_point(cadre):
    """Les côtés des cases d'un tableau bordé à 1 pt. Chaque case trace ses quatre côtés, deux voisines tracent donc leur
    séparation chacune ; à 1 px (0,75 pt sur ce périphérique à 72 ppp), Qt les place dans un intervalle d'un point entier,
    l'une calée à gauche, l'autre à droite : un trait de 1 pt entre les cases contre 0,75 au bord. À 1 pt pile, les deux
    se superposent exactement — mesuré sur le flux du PDF, question 2 de l'évaluation des réseaux sociaux. Mais 1 pt est
    épais : Qt les peint transparents, et ``traits_des_tableaux`` trace à leur place un trait de ``TRAIT_TABLEAU``."""
    for enfant in cadre.childFrames():
        if isinstance(enfant, QTextTable) and enfant.format().borderCollapse() and enfant.format().border():
            invisible = QColor(enfant.format().borderBrush().color())
            invisible.setAlpha(0)  # Qt garde la place, ``traits_des_tableaux`` retrouve la couleur et trace le trait fin
            for r in range(enfant.rows()):
                for c in range(enfant.columns()):
                    case = enfant.cellAt(r, c)
                    if (case.row(), case.column()) == (r, c):  # une case fusionnée, une fois
                        f = case.format().toTableCellFormat()
                        for cote in ("Left", "Right", "Top", "Bottom"):
                            getattr(f, f"set{cote}BorderStyle")(QTextFrameFormat.BorderStyle.BorderStyle_Solid)
                            getattr(f, f"set{cote}Border")(1 / PX)
                            getattr(f, f"set{cote}BorderBrush")(invisible)
                        case.setFormat(f)
        elif isinstance(enfant, QTextTable) and enfant.format().borderCollapse():  # les traits où l'élève écrit, même remède
            for r in range(enfant.rows()):  # 0,75 ou 1 pt selon la ligne sinon (l'utilisateur, 05/11/2026) ; ils gardent leur 1 px,
                for c in range(enfant.columns()):  # donc leur place : passer à 1 pt allongerait chaque ligne de réponse
                    case = enfant.cellAt(r, c)
                    f = case.format().toTableCellFormat()
                    if f.bottomBorder() and f.bottomBorderBrush().color() == QColor(TRAIT_ECRITURE):
                        invisible = QColor(TRAIT_ECRITURE)
                        invisible.setAlpha(0)
                        f.setBottomBorderBrush(invisible)
                        case.setFormat(f)
        bordures_au_point(enfant)


TRAIT_TABLEAU = 0.75  # l'épaisseur des traits d'un tableau bordé, centrés dans l'intervalle d'un point que Qt leur réserve


def traits_des_tableaux(document):
    """Les traits fins des tableaux bordés, {couleur: [QLineF]} : où Qt a posé les bordures transparentes de
    ``bordures_au_point``, relevé en peignant le document dans un SVG — les rectangles d'un point d'épaisseur et
    d'opacité nulle. Ces intervalles tombent sur des points entiers et se touchent aux croisements : chacun est découpé
    en carrés d'un point, et chaque suite de carrés alignés devient un trait passant par leurs centres. Terminé en
    bout carré, il déborde d'une demi-épaisseur et rejoint exactement le bord du trait qu'il croise."""
    tampon = QBuffer()
    tampon.open(QIODevice.WriteOnly)
    svg = QSvgGenerator()
    svg.setOutputDevice(tampon)
    svg.setResolution(72)
    peintre = QPainter(svg)
    document.documentLayout().draw(peintre, QAbstractTextDocumentLayout.PaintContext())
    peintre.end()
    carres = {}  # couleur -> {(x, y)}
    for groupe in ET.fromstring(bytes(tampon.data())).iter("{http://www.w3.org/2000/svg}g"):
        if groupe.get("fill-opacity") != "0":
            continue
        dx, dy = (float(v) for v in groupe.get("transform", "matrix(1,0,0,1,0,0)")[7:-1].split(",")[4:])
        for r in groupe.iter("{http://www.w3.org/2000/svg}rect"):
            x, y, l, h = (round(float(r.get(k)) + d) for k, d in (("x", dx), ("y", dy), ("width", 0), ("height", 0)))
            if 1 in (l, h):
                carres.setdefault(groupe.get("fill"), set()).update((x + i, y + j) for i in range(l) for j in range(h))
    traits = {}
    for couleur, ensemble in carres.items():
        for x, y in ensemble:
            for pas in ((1, 0), (0, 1)):  # une suite commence là où le carré précédent manque et le suivant est là
                if (x - pas[0], y - pas[1]) not in ensemble and (x + pas[0], y + pas[1]) in ensemble:
                    n = 1
                    while (x + n * pas[0], y + n * pas[1]) in ensemble:
                        n += 1
                    traits.setdefault(couleur, []).append(QLineF(x + 0.5, y + 0.5, x + 0.5 + (n - 1) * pas[0], y + 0.5 + (n - 1) * pas[1]))
    return traits


def tables_de(cadre):
    for enfant in cadre.childFrames():
        if isinstance(enfant, QTextTable):
            yield enfant
        yield from tables_de(enfant)


PLANCHER_MOTS_ENTIERS = 0.7  # un tableau ne descend pas sous 70 % de son corps pour garder ses mots entiers
COUPURES_PERMISES = "-‑/­–—￼"  # après un trait d'union, une barre, un tiret, une image : pas un mot coupé


def mot_coupe(table: QTextTable) -> tuple[str, int, QFont] | None:
    """Le premier mot qu'une case du tableau coupe en fin de ligne (« Sac|ha »), avec sa colonne et sa police, None s'il
    n'y en a pas : Qt coupe un mot plus large que sa colonne n'importe où (``WrapAtWordBoundaryOrAnywhere``). Le
    document doit être mis en page."""
    for r in range(table.rows()):
        for c in range(table.columns()):
            cellule = table.cellAt(r, c)
            if cellule.row() != r or cellule.column() != c:  # case fusionnée : vue à sa première position
                continue
            bloc, fin = cellule.firstCursorPosition().block(), cellule.lastCursorPosition().position()
            while bloc.isValid() and bloc.position() <= fin:
                texte, couche = bloc.text(), bloc.layout()
                for i in range(couche.lineCount() - 1):
                    bout = couche.lineAt(i).textStart() + couche.lineAt(i).textLength()
                    if 0 < bout < len(texte) and not texte[bout - 1].isspace() and texte[bout - 1] not in COUPURES_PERMISES \
                            and not texte[bout].isspace() and texte[bout] != "￼":
                        debut = len(texte[:bout]) - len(texte[:bout].split()[-1])
                        curseur = QTextCursor(bloc)
                        curseur.setPosition(bloc.position() + debut + 1)
                        return texte[debut:].split()[0], c, curseur.charFormat().font()
                bloc = bloc.next()
    return None


def mot_le_plus_large(document: QTextDocument, table: QTextTable, colonne: int) -> float:
    """La largeur, en points du périphérique, du mot le plus large des cases de ``colonne``, chacun dans sa police."""
    peripherique, plus_large = document.documentLayout().paintDevice(), 0.0
    for r in range(table.rows()):
        cellule = table.cellAt(r, colonne)
        if cellule.column() != colonne or cellule.columnSpan() > 1:
            continue
        bloc, fin = cellule.firstCursorPosition().block(), cellule.lastCursorPosition().position()
        while bloc.isValid() and bloc.position() <= fin:
            for mot in re.finditer(r"\S+", bloc.text()):
                curseur = QTextCursor(bloc)
                curseur.setPosition(bloc.position() + mot.start() + 1)
                police = curseur.charFormat().font()
                plus_large = max(plus_large, QFontMetricsF(police, peripherique).horizontalAdvance(mot.group()))
            bloc = bloc.next()
    return plus_large


def elargir_colonne(document: QTextDocument, table: QTextTable, colonne: int, largeur: float) -> bool:
    """Donne à ``colonne`` la place d'un mot de ``largeur`` points, prise aux autres colonnes ; False si le tableau
    déborderait alors de la page, et rien n'est changé. Une grille en pourcentages (tableaux alignés d'un groupe,
    ``largeurs_alignees``) reçoit sa nouvelle part, et ses sœurs aux mêmes parts la même, pour rester alignées."""
    format_table, mise_en_page = table.format(), document.documentLayout()
    largeur += 2 * (format_table.cellPadding() + format_table.border())
    contraintes = list(format_table.columnWidthConstraints()) or [QTextLength()] * table.columns()
    if any(c.type() == QTextLength.PercentageLength for c in contraintes):
        if any(c.type() != QTextLength.PercentageLength for c in contraintes):
            return False  # grille mixte (parts et largeurs) : on réduira le corps plutôt que d'en deviner les parts
        # chaque colonne reçoit au moins son mot le plus large, pris dans toutes les sœurs : élargir la seule colonne du
        # mot coupé prendrait la place d'un autre (« Excentricité » entier coupait « Sach|a », W770)
        avant = [(c.type(), c.rawValue()) for c in contraintes]
        largeur_table = mise_en_page.frameBoundingRect(table).width()
        soeurs = [t for t in tables_de(document.rootFrame()) if not t.childFrames()  # mêmes parts, même largeur
                  and [(c.type(), c.rawValue()) for c in t.format().columnWidthConstraints()] == avant
                  and abs(mise_en_page.frameBoundingRect(t).width() - largeur_table) < 1]
        base = mise_en_page.frameBoundingRect(table).width() - 2 * format_table.border() \
            - (table.columns() + 1) * format_table.cellSpacing()  # Qt répartit les parts sur ce qui reste
        marge = 2 * (format_table.cellPadding() + format_table.border())
        parts = [c.rawValue() for c in contraintes]
        minima = [100 * (max(mot_le_plus_large(document, t, c) for t in soeurs) + 2 + marge) / base
                  for c in range(table.columns())]
        if sum(minima) >= 100:  # estimation large (marges comptées pleines) : les parts au prorata des mots, et la
            minima = [100 * m / sum(minima) for m in minima]  # mise en page dira si les mots tiennent
            parts = minima
        manque = sum(max(m - p, 0) for m, p in zip(minima, parts))
        aisance = sum(max(p - m, 0) for m, p in zip(minima, parts))
        nouvelles = [QTextLength(QTextLength.PercentageLength,
                                 m if m >= p else p - (p - m) * manque / aisance) for m, p in zip(minima, parts)]
        for soeur in soeurs:
            format_soeur = soeur.format()
            format_soeur.setColumnWidthConstraints(nouvelles)
            soeur.setFormat(format_soeur)
        mise_en_page.documentSize()
        return True
    ancien = table.format()
    contraintes[colonne] = QTextLength(QTextLength.FixedLength, largeur)
    format_table.setColumnWidthConstraints(contraintes)
    table.setFormat(format_table)
    mise_en_page.documentSize()
    page = (document.textWidth() if document.textWidth() > 0 else document.pageSize().width()) \
        - document.rootFrame().frameFormat().rightMargin()  # le cadre racine s'élargit avec le tableau
    if mise_en_page.frameBoundingRect(table).right() <= min(page, mise_en_page.frameBoundingRect(table.parentFrame()).right()) + 0.5:
        return True
    table.setFormat(ancien)  # le tableau déborderait de la page : on réduira le corps à la place
    mise_en_page.documentSize()
    return False


def mots_entiers_dans_les_tableaux(document: QTextDocument) -> list[str]:
    """Réduit le corps d'un tableau qui coupe un mot (en-têtes « Sac ha », « Excentri cité » du tableau des distances,
    DS de SNT n°1, en agrandi), par crans de 10 %, jusqu'à ce qu'aucun mot ne soit coupé, sans descendre sous
    ``PLANCHER_MOTS_ENTIERS`` : jamais un mot coupé pour un élève dys (TODO Aménagements, W770). Renvoie les mots encore
    coupés au plancher, pour l'avertissement à l'export."""
    restes = []
    corps = document.defaultFont().pointSizeF()
    for table in list(tables_de(document.rootFrame())):
        if table.childFrames():  # un tableau de mise en page (question, barème) : seuls ses tableaux feuilles comptent
            continue
        document.documentLayout().documentSize()  # met en page ce qui a changé
        echelle, elargies = 1.0, set()
        while (coupe := mot_coupe(table)) and echelle > PLANCHER_MOTS_ENTIERS + 1e-9:
            mot, colonne, police = coupe
            if colonne not in elargies and table.columns() > 1:  # d'abord la colonne à la largeur du mot, corps intact
                elargies.add(colonne)
                metrique = QFontMetricsF(police, document.documentLayout().paintDevice())
                if elargir_colonne(document, table, colonne, metrique.horizontalAdvance(mot) + 2):
                    continue
            facteur, elargies = max(echelle * 0.9, PLANCHER_MOTS_ENTIERS) / echelle, set()  # au corps réduit, la grille peut tenir élargie
            echelle *= facteur
            morceaux = []  # relevés d'abord : changer un format refait les fragments sous l'itérateur
            bloc, fin = table.firstCursorPosition().block(), table.lastCursorPosition().position()
            while bloc.isValid() and bloc.position() <= fin:
                fragments = bloc.begin()
                while not fragments.atEnd():
                    fragment, format_lu = fragments.fragment(), fragments.fragment().charFormat()
                    if format_lu.fontPointSize() or not (format_lu.hasProperty(QTextFormat.FontPixelSize)
                                                         or format_lu.hasProperty(QTextFormat.FontSizeAdjustment)):
                        morceaux.append((fragment.position(), fragment.length(), format_lu.fontPointSize() or corps))
                    fragments += 1  # une taille en pixels ou relative (titre) n'est pas convertie en points
                bloc = bloc.next()
            curseur = QTextCursor(document)
            for position, longueur, taille in morceaux:
                format_car = QTextCharFormat()
                format_car.setFontPointSize(taille * facteur)
                curseur.setPosition(position)
                curseur.setPosition(position + longueur, QTextCursor.KeepAnchor)
                curseur.mergeCharFormat(format_car)
            document.documentLayout().documentSize()
        if coupe:
            restes.append(coupe[0])
    return restes


def conversions_en_tableau(document, tableaux):
    """[(QTextTable, grille, nom)] : les tableaux de ``Rendu.conversion_en_tableau``, retrouvés par l'ancre de leur première cellule."""
    trouves = []
    for table in tables_de(document.rootFrame()):
        it = table.cellAt(0, 0).firstCursorPosition().block().begin()
        while not it.atEnd():
            noms = [n[len("conversion:"):] for n in it.fragment().charFormat().anchorNames() if n.startswith("conversion:")]
            if noms and noms[0] in tableaux:
                trouves.append((table, tableaux[noms[0]], noms[0]))
                break
            it += 1
    return trouves


def regler_les_conversions(document, tableaux, echelle=1):
    """Les tableaux des conversions ``en_tableau`` à la géométrie de leur figure (``noyau.Conversion.svg``), ce que le HTML
    ne sait pas dire : largeurs de colonnes fixes, et dans chaque cellule, un interligne fixe et des marges intérieures qui
    posent chaque ligne de texte à la ligne de base de la figure, et donnent à la cellule la hauteur exacte de ses lignes
    du tableau (Qt ne fixe pas la hauteur d'une ligne de tableau : elle naît de ses cellules). Deux passes : la première
    mesure où Qt pose la ligne de base (son ascendant, selon la police de la cellule), la seconde en déduit les marges.
    Le texte aligné à droite finit à ``MARGE`` du bord, la queue (exposant, base) débordant dans la marge."""
    from noyau import Conversion, queue_suscrite
    CORPS, LIGNE, MARGE_CASE = (v * echelle for v in (Conversion.CORPS, Conversion.LIGNE, Conversion.MARGE))
    trouves = conversions_en_tableau(document, tableaux)
    # Qt lit les longueurs d'un format en pixels à 96 ppp et les ramène au périphérique (72 ppp pour le PDF : × 0,75) ;
    # la géométrie, elle, est en points du périphérique, comme ce que la mise en page mesure : on écrit donc × 96 / ppp.
    appareil = document.documentLayout().paintDevice()
    k = 96 / appareil.logicalDpiY() if appareil else 1
    # la place : Qt ignore la largeur fixe d'un tableau imbriqué et lui donne toute sa cellule (celle de l'énoncé et du
    # barème, SANS_BAREME : la grille y déborde comme sa figure) ; des colonnes fixes compteraient dans la largeur minimale
    # de la question et l'élargiraient. On mesure donc cette place, colonnes variables, puis on la partage en pourcentages :
    # les colonnes de la grille à leur largeur exacte, une colonne vide ajoutée à droite prend le reste ; une grille plus
    # large que la place (une sous-question) est réduite d'autant, comme sa figure par ``largeur_max``
    for table, t, _ in trouves:
        table.appendColumns(1)
        for i in range(table.rows()):  # vide, sans fond ni hauteur : elle prendrait ceux de sa voisine et d'une ligne de texte
            cellule = table.cellAt(i, table.columns() - 1)
            cellule.setFormat(QTextTableCellFormat())
            bloc = QTextBlockFormat()
            bloc.setLineHeight(0, QTextBlockFormat.FixedHeight.value)
            QTextCursor(cellule.firstCursorPosition()).setBlockFormat(bloc)
        f = table.format()
        f.setColumnWidthConstraints([])
        f.setWidth(QTextLength(QTextLength.FixedLength, 1))
        for regle in (f.setBorder, f.setCellPadding, f.setCellSpacing, f.setMargin, f.setPadding):
            regle(0)
        table.setFormat(f)
    document.documentLayout().documentSize()
    places = [document.documentLayout().frameBoundingRect(table).width() for table, _, _ in trouves]
    trouves = [(table, t, nom, echelle * min(1, place / (sum(t["colonnes"]) * echelle)))
               for (table, t, nom), place in zip(trouves, places)]
    reglages = []
    for (table, t, _, reduit), place in zip(trouves, places):
        f = table.format()
        pourcents = [100 * l * reduit / place for l in t["colonnes"]]
        f.setColumnWidthConstraints([QTextLength(QTextLength.PercentageLength, p) for p in pourcents + [100 - sum(pourcents)]])
        table.setFormat(f)
        lignes = [l * reduit for l in t["lignes"]]
        for c in t["cellules"]:
            cellule = table.cellAt(c["ligne"], c["colonne"])
            h = sum(lignes[c["ligne"]:c["ligne"] + c["hauteur"]])
            quoi = c["case"] or c["etiquette"]
            texte = cellule.firstCursorPosition().block().text().replace("\u00a0", " ")
            n = len(texte.split("\u2028"))
            if c["etiquette"]:  # centrée, une ligne tous les 1,2 corps
                pas = CORPS * 1.2
                base = (h - n * pas) / 2 + 0.82 * pas
            elif quoi and n > 1:  # une case de plusieurs lignes : une par ligne du plan
                pas = LIGNE * reduit / echelle
                base = pas / 2 + CORPS * 0.36
            else:  # une ligne, centrée ; vide, toute la hauteur (la ligne des « ×2 » est plus basse qu'une ligne de texte)
                pas, base = h, h / 2 + CORPS * 0.36
            fixe = n > 1 or not texte.strip()  # une ligne de texte garde son interligne naturel : un fixe la déplacerait
            reglages.append((cellule, c, h, n, pas, base if texte.strip() else None))
            bloc = QTextBlockFormat()
            if fixe:
                bloc.setLineHeight(pas * k, QTextBlockFormat.FixedHeight.value)
            bloc.setTopMargin(0)
            bloc.setBottomMargin(0)
            curseur = cellule.firstCursorPosition()
            curseur.setPosition(cellule.lastCursorPosition().position(), QTextCursor.KeepAnchor)
            curseur.mergeBlockFormat(bloc)
    document.documentLayout().documentSize()  # la mise en page de la première passe
    for cellule, c, h, n, pas, base in reglages:
        f = cellule.format().toTableCellFormat()
        haut = droite = gauche = 0
        if base is not None:
            ligne = cellule.firstCursorPosition().block().layout().lineAt(0)
            haut = max(0, base - ligne.y() - ligne.ascent())
            pas = pas if n > 1 else ligne.height()  # cf. fixe
            if c["case"] and c["case"]["aligne"] == "d":
                bloc = cellule.firstCursorPosition().block()
                fin = len(bloc.text().split("\u2028")[0].rstrip())
                queue = len(queue_suscrite(bloc.text()[:fin])[1])
                droite = MARGE_CASE - (ligne.cursorToX(fin)[0] - ligne.cursorToX(fin - queue)[0])
            elif c["case"] and c["case"]["aligne"] == "g":
                gauche = MARGE_CASE
            if haut + n * pas > h:  # la dernière ligne déborderait : l'interligne cède, pas la hauteur de la cellule
                bloc = QTextBlockFormat()
                bloc.setLineHeight((h - haut) / n * k, QTextBlockFormat.FixedHeight.value)
                QTextCursor(cellule.firstCursorPosition()).mergeBlockFormat(bloc)
                pas = (h - haut) / n
        f.setTopPadding(haut * k)
        f.setBottomPadding((h - haut - n * pas) * k)
        f.setRightPadding(droite * k)
        f.setLeftPadding(gauche * k)
        cellule.setFormat(f)
    return trouves


def bornes_des_conversions(document, trouves):
    """Pour chaque tableau de ``regler_les_conversions`` : (grille, nom, réduction, origine, xs, ys), l'origine et les
    bornes des colonnes et des lignes de la grille dans le repère du document, une fois mis en page."""
    for table, t, nom, reduit in trouves:
        # le haut du tableau : celui du texte de sa première cellule moins sa marge intérieure (frameBoundingRect
        # rend le haut du texte, pas celui de la cellule) ; la marge est en pixels à 96 ppp (regler_les_conversions)
        appareil = document.documentLayout().paintDevice()
        k = 96 / appareil.logicalDpiY() if appareil else 1
        premiere = table.cellAt(0, 0)
        haut = document.documentLayout().blockBoundingRect(premiere.firstCursorPosition().block()).top()
        origine = QPointF(document.documentLayout().frameBoundingRect(table).left(),
                          haut - premiere.format().toTableCellFormat().topPadding() / k)
        # les bornes des colonnes, là où Qt les a posées (ses pourcentages s'arrondissent au point, la colonne vide ajoutée
        # à droite donne la dernière) ; celles des lignes, calculées : regler_les_conversions en a fixé la hauteur
        xs = [min(document.documentLayout().blockBoundingRect(cellule.firstCursorPosition().block()).x()
                  - cellule.format().toTableCellFormat().leftPadding() / k
                  for cellule in (table.cellAt(i, j) for i in range(table.rows())) if cellule.column() == j)
              for j in range(len(t["colonnes"]) + 1)]
        ys = [origine.y() + v * reduit for v in itertools.accumulate(t["lignes"], initial=0)]
        yield t, nom, reduit, origine, xs, ys


def peindre_les_conversions(peintre, document, trouves, svgs, echelle=1):
    """Ce que le tableau d'une conversion ``en_tableau`` ne trace pas, peint après la mise en page comme à l'écran
    (``modele.TableConversion``) : le cadre gris de chaque case, le trait épais des paquets de 4 bits, puis les flèches
    (le ``calque`` de ``noyau.Conversion.svg``), aux bornes de la grille posées à l'origine du tableau."""
    for t, nom, reduit, origine, xs, ys in bornes_des_conversions(document, trouves):
        for c in t["cellules"]:
            x0, y0 = xs[c["colonne"]], ys[c["ligne"]]
            x1, y1 = xs[c["colonne"] + c["largeur"]], ys[c["ligne"] + c["hauteur"]]
            if c["bord"]:
                peintre.setPen(QPen(QColor("#7f7f7f"), 0.75 * echelle))
                peintre.drawRect(QRectF(x0, y0, x1 - x0, y1 - y0))
            if c["epais"]:
                peintre.setPen(QPen(QColor("#000000"), 1.5 * echelle))
                peintre.drawLine(QPointF(x0, y0), QPointF(x0, y1))
        rendu = QSvgRenderer(QByteArray(svgs[nom]))
        boite = rendu.viewBoxF()
        rendu.render(peintre, QRectF(origine, QSizeF(boite.width() * reduit, boite.height() * reduit)))


PLAN = "plan.json"  # la seconde pièce jointe de chaque PDF : où sont imprimées les cases à remplir


class ObjetSvgReleve(ObjetSvg):
    """``ObjetSvg`` qui retient où il a dessiné chaque figure (nom -> QRectF, repère du document) : la place réelle,
    celle que Qt a donnée à la figure en la peignant, pour le plan des cases."""

    def __init__(self, *args):
        super().__init__(*args)
        self.places = {}

    def drawObject(self, peintre, rect, document, position, format_):
        self.places[format_.property(NOM_SVG)] = QRectF(rect)
        super().drawObject(peintre, rect, document, position, format_)


def plan_des_cases(document, trouves, figures=None, places=None):
    """Le plan des cases à remplir des conversions, tel que la page les porte : par case, sa question, sa clé (celle du
    relevé, ``transcrire_papier.cases_de_conversion``), sa page (1 pour la première) et son rectangle [x0, y0, x1, y1] en
    points depuis le coin haut gauche de la feuille A4 — le repère de ``layout_retrouve``, à 72 ppp. Les grilles
    ``en_tableau`` (``trouves``) par les bornes de leur tableau ; les figures (``Rendu.cases_des_figures``) par la place
    où ``ObjetSvgReleve`` les a peintes (``places``), à l'échelle de leur ``viewBox``. Joint au PDF (``PLAN``) : la
    correction papier retrouve chaque case sans la chercher dans l'image."""
    rects = []  # (question, clé, x0, y0, x1, y1) dans le repère du document
    for t, _, _, _, xs, ys in bornes_des_conversions(document, trouves):
        for c in t["cellules"]:
            if c["case"] and c["case"]["remplir"] and c["case"]["cle"]:
                rects.append((t["question"], t["prefixe"] + c["case"]["cle"], xs[c["colonne"]], ys[c["ligne"]],
                              xs[c["colonne"] + c["largeur"]], ys[c["ligne"] + c["hauteur"]]))
    for nom, f in (figures or {}).items():
        if nom not in (places or {}):
            continue
        place = places[nom]
        k = place.width() / f["largeur"]
        for cle, (x, y, l, h) in f["cases"].items():
            rects.append((f["question"], f["prefixe"] + cle, place.x() + x * k, place.y() + y * k,
                          place.x() + (x + l) * k, place.y() + (y + h) * k))
    cases = []
    for question, cle, x0, y0, x1, y1 in rects:
        page = int(y0 // HAUTEUR_UTILE)
        decale = HAUT - page * HAUTEUR_UTILE
        cases.append({"question": question, "cle": cle, "page": page + 1,
                      "rect": [round(v, 2) for v in (x0 + MARGE, y0 + decale, x1 + MARGE, y1 + decale)]})
    return {"version": 1, "unite": "point", "page": [LARGEUR, HAUTEUR], "cases": cases}


POSITIONS = "positions.json"  # la troisième pièce jointe : où sont imprimés étiquettes, cases, trous, lignes, cadre du nom


def sur_la_page(x: float, y: float) -> tuple[int, float, float]:
    """Un point du document mis en page (repère de ``documentLayout``) sur sa feuille : (page, x, y), page 1 pour la
    première, x et y en points depuis le coin haut gauche de l'A4, comme ``ecrire_pdf`` peint chaque page."""
    page = int(y // HAUTEUR_UTILE)
    return page + 1, x + MARGE, y + HAUT - page * HAUTEUR_UTILE


def boites(document, bloc, debut: int, n: int) -> tuple[QRectF, QRectF]:
    """Les ``n`` caractères du ``bloc`` à partir de ``debut``, dans le repère du document : (boîte du texte, celle que
    ``pdftotext -bbox`` en donne, de l'ascendante à la descendante de la police ; boîte de l'encre, les contours des
    glyphes eux-mêmes)."""
    origine = document.documentLayout().blockBoundingRect(bloc).topLeft()
    texte, encre = QRectF(), QRectF()
    for run in bloc.layout().glyphRuns(debut, n):
        police = run.rawFont()
        for glyphe, place in zip(run.glyphIndexes(), run.positions()):
            base = origine + place
            avance = police.advancesForGlyphIndexes([glyphe])[0].x()
            texte |= QRectF(base.x(), base.y() - police.ascent(), avance, police.ascent() + police.descent())
            encre |= police.pathForGlyph(glyphe).boundingRect().translated(base)
    return texte, encre


def positions_imprimees(document, imprimees, traits, identite, pages, appareil) -> dict[str, Any]:
    """Où ``ecrire_pdf`` a imprimé ce que la correction papier relit, tel que Qt l'a mis en page (le professeur,
    16/11/2026 : « le code de conversion json -> pdf devrait écrire le layout ») : le cadre du nom et, par question, son
    étiquette, ses cases (``choix_unique``, ``choix_multiples``, ``alternative``), ses trous, ses lignes de réponse
    imprimées et ses zones. En pixels à ``layout_retrouve.PPP``, dans le repère et avec les définitions de
    ``layout_retrouve.retrouver`` (``layout.json``), qui ne sert plus qu'aux archives d'avant ce fichier et d'oracle à
    l'export. ``imprimees`` : (étiquette, question) dans l'ordre d'impression (``layout_retrouve.attendues``), None
    pour l'énoncé commun d'un groupe ; ``traits`` : ``traits_des_tableaux`` ; ``appareil`` : le QPdfWriter (72 ppp)."""
    lr = layout_retrouve()
    etiquettes, titres, visibles = [], [], {}  # titres : (rang de l'étiquette qui les suit, page, y)
    cases, trous, lignes, cellules, puces, figures = [], [], [], [], [], []  # (rang de l'étiquette d'avant, page, rect en points, ...)
    verticaux = [l for ls in traits.values() for l in ls if l.x1() == l.x2()]
    horizontaux = [l for ls in traits.values() for l in ls if l.y1() == l.y2()]
    ecriture = sorted((l.y1(), min(l.x1(), l.x2()), max(l.x1(), l.x2()))
                      for l in traits.get(TRAIT_ECRITURE, []) if l.y1() == l.y2())
    bloc = document.begin()
    while bloc.isValid():
        texte, couche = bloc.text(), bloc.layout()
        rang = len(etiquettes) - 1
        for i in range(couche.lineCount()):
            ligne = couche.lineAt(i)
            morceau = texte[ligne.textStart():ligne.textStart() + ligne.textLength()]
            if morceau.strip(" ￼  "):
                boite, _ = boites(document, bloc, ligne.textStart(), ligne.textLength())
                page, _, y = sur_la_page(0, boite.top())
                visibles.setdefault(page, []).append(y)
        if (lr.NUMERO.fullmatch(texte) or lr.SOUS_NUMERO.fullmatch(texte)) and couche.lineCount():
            page, r = rect_sur_la_page(boites(document, bloc, 0, len(texte))[0])
            if r[0] < lr.COLONNE:
                etiquettes.append((texte, page, r[1], r))
                bloc = bloc.next()
                continue
        if bloc.blockFormat().headingLevel() and couche.lineCount() and texte.strip():
            boite, _ = boites(document, bloc, 0, len(texte))
            titres.append((rang + 1, *sur_la_page(0, boite.top())[::2]))
        for i, c in enumerate(texte):
            if c in lr.CASES:
                cases.append((rang, *rect_sur_la_page(boites(document, bloc, i, 1)[1]), c))
            elif c == PUCE:  # un bout de flèche d'un appariement : le formulaire y pose ses boutons
                puces.append((rang, *rect_sur_la_page(boites(document, bloc, i, 1)[1])))
        if texte in (" ", REPONSE_BLANCHE) and bloc.begin().fragment().charFormat().fontPointSize() == 14 and ecriture:  # une rangée de lignes_reponse
            bas = document.documentLayout().blockBoundingRect(bloc).bottom()
            y = min((y for y, _, _ in ecriture if y >= bas - 1), default=None, key=lambda y: y - bas)
            if y is not None and y - bas < 4:
                xs = [(a, b) for yy, a, b in ecriture if yy == y]
                lignes.append((rang, *rect_sur_la_page(QRectF(QPointF(min(a for a, _ in xs), y),
                                                               QPointF(max(b for _, b in xs), y)))))
        table = QTextCursor(bloc).currentTable()
        if (table is not None and table.format().border() > 0 and not texte.strip(" \u00a0")
                and table.cellAt(bloc.position()).firstPosition() == bloc.position() and not cellule_ecrite(document, table, bloc)
                and (cadre := cellule_bordee(document.documentLayout().blockBoundingRect(bloc), verticaux, horizontaux))):
            cellules.append((rang, *rect_sur_la_page(cadre)))  # une case vide d'un tableau bordé : où l'élève écrit
        it = bloc.begin()
        while not it.atEnd():
            fragment = it.fragment()
            it += 1
            f = fragment.charFormat()
            if f.fontUnderline() and f.foreground().color().name() == TRAIT_ECRITURE and not fragment.text().strip(" "):
                debut = fragment.position() - bloc.position()
                boite, _ = boites(document, bloc, debut, fragment.length())
                # A_NOTER, suivi de « / » et du barème : la place de la note du correcteur, pas un trou de l'élève
                note = texte[debut + fragment.length():].startswith("\u00a0/")
                trous.append((rang, *rect_sur_la_page(boite), note))
            elif f.objectType() == OBJET_SVG and str(f.property(NOM_SVG)).startswith("figure "):  # l'image d'une figure_a_trous
                debut = fragment.position() - bloc.position()
                ligne = couche.lineForTextPosition(debut)  # une image en ligne pose son bas sur la ligne de base
                origine = document.documentLayout().blockBoundingRect(bloc).topLeft()  # le repère de boites
                taille = document.documentLayout().handlerForObject(OBJET_SVG).intrinsicSize(document, fragment.position(), f)
                bas = QPointF(ligne.cursorToX(debut)[0], ligne.y() + ligne.ascent()) + origine
                figures.append((rang, *rect_sur_la_page(QRectF(bas - QPointF(0, taille.height()), taille))))
        bloc = bloc.next()
    return assembler_positions(lr, etiquettes, titres, visibles, cases, trous, lignes, cellules, imprimees, identite, pages,
                               appareil, puces, figures)


def cellule_ecrite(document, table, bloc) -> bool:
    """La case de ``table`` qui commence au ``bloc`` porte-t-elle du texte, sur l'un de ses blocs ? Un cadre (celui d'un
    code à compléter, ``encadre``) dont le premier bloc est vide n'est pas une case où l'élève écrit."""
    case = table.cellAt(bloc.position())
    curseur = QTextCursor(document)
    curseur.setPosition(case.firstPosition())
    curseur.setPosition(case.lastPosition(), QTextCursor.KeepAnchor)
    return bool(curseur.selectedText().strip(" \u00a0\u2029\ufffc"))


def cellule_bordee(r: QRectF, verticaux: list[QLineF], horizontaux: list[QLineF]) -> QRectF | None:
    """La case d'un tableau qui contient le bloc ``r``, entre les traits de ``traits_des_tableaux`` les plus proches
    de chaque côté (repère du document) ; None hors d'un tableau bordé de ses quatre côtés."""
    c = r.center()
    gauche = max((l.x1() for l in verticaux if l.x1() <= r.left() + 1 and min(l.y1(), l.y2()) <= c.y() <= max(l.y1(), l.y2())), default=None)
    droite = min((l.x1() for l in verticaux if l.x1() >= r.right() - 1 and min(l.y1(), l.y2()) <= c.y() <= max(l.y1(), l.y2())), default=None)
    haut = max((l.y1() for l in horizontaux if l.y1() <= r.top() + 1 and min(l.x1(), l.x2()) <= c.x() <= max(l.x1(), l.x2())), default=None)
    bas = min((l.y1() for l in horizontaux if l.y1() >= r.bottom() - 1 and min(l.x1(), l.x2()) <= c.x() <= max(l.x1(), l.x2())), default=None)
    return None if None in (gauche, droite, haut, bas) else QRectF(QPointF(gauche, haut), QPointF(droite, bas))


def rect_sur_la_page(r: QRectF) -> tuple[int, list[float]]:
    page, x0, y0 = sur_la_page(r.left(), r.top())
    return page, [x0, y0, x0 + r.width(), y0 + r.height()]


def assembler_positions(lr, etiquettes, titres, visibles, cases, trous, lignes, cellules, imprimees, identite, pages,
                        appareil, puces=(), figures=()) -> dict[str, Any]:
    """La suite de ``positions_imprimees`` : chaque élément relevé rendu à la question de l'étiquette qui le précède,
    les zones tracées comme ``layout_retrouve.retrouver`` les trace (de l'étiquette à la suivante, la suite d'une
    question coupée jusqu'au titre de la section suivante), le cadre du nom comme ``layout_retrouve.cadre_du_nom``."""
    bas = HAUTEUR - MARGE - PIED
    sortie = {"version": 1, "unite": "pixel", "ppp": lr.PPP, "page": lr.px(0, 0, LARGEUR, HAUTEUR)[2:], "pages": pages,
              "etiquettes": [e for e, _ in imprimees], "nom": [], "cadre_nom": [], "questions": []}
    if [e for e, *_ in etiquettes] != [e if e.endswith(".") else e[-1] + "." for e, _ in imprimees]:
        sortie["ecart"] = f"étiquettes mises en page {[e for e, *_ in etiquettes]} ≠ attendues {sortie['etiquettes']}"
        return sortie
    for k, ((etiquette, q), (_, page, y, boite)) in enumerate(zip(imprimees, etiquettes)):
        if q is None:
            continue
        fin = etiquettes[k + 1][1:3] if k + 1 < len(etiquettes) else (pages, bas + lr.AU_DESSUS)
        zones = [{"page": page, "rect": lr.px(MARGE, y - lr.AU_DESSUS, LARGEUR - MARGE,
                                              (fin[1] if fin[0] == page else bas) - lr.AU_DESSUS)}]
        for p in range(page + 1, fin[0] + 1):  # la suite d'une question coupée : layout_retrouve.suite
            arret = min([fin[1] if p == fin[0] else bas] + [t for r, pt, t in titres if r == k + 1 and pt == p])
            if not any(lr.MARGE <= v < bas and v < arret - lr.AU_DESSUS for v in visibles.get(p, [])):
                break
            zones.append({"page": p, "rect": lr.px(MARGE, HAUT - lr.AU_DESSUS, LARGEUR - MARGE, arret - lr.AU_DESSUS)})
            if arret < bas:
                break
        entree = {"etiquette": etiquette, "id": q.id, "type": q.type, "zones": zones,
                  "etiquette_rect": {"page": page, "rect": lr.px(*boite)}}
        a_elle = lambda liste: [e[1:] for e in liste if e[0] == k]  # noqa: E731
        if (props := lr.libelles(q)) is not None:
            origine = lr.ordre(q)
            entree["cases"] = [{"page": p, "rect": lr.px(*r), "proposition": origine[i] if i < len(origine) else None,
                                "texte": props[i] if i < len(props) else None, "forme": "rond" if c in "⭘◉" else "carre"}
                               for i, (p, r, c) in enumerate(a_elle(cases))]
        entree["trous"] = [{"page": p, "rect": lr.px(*r)} for p, r, note in a_elle(trous) if not note]
        entree["note"] = next(({"page": p, "rect": lr.px(*r)} for p, r, note in a_elle(trous) if note), None)
        entree["lignes"] = [{"page": p, "rect": lr.px(*r)} for p, r in a_elle(lignes)]
        entree["cellules"] = [{"page": p, "rect": lr.px(*r)} for p, r in a_elle(cellules)]
        if q.type == "appariement":  # l'encre de chaque puce, ligne par ligne, celle de gauche avant celle de droite
            entree["puces"] = [{"page": p, "rect": lr.px(*r)} for p, r in a_elle(puces)]
        if q.type == "figure_a_trous":  # l'image où le formulaire pose les champs, depuis q.places
            entree["figure"] = next(({"page": p, "rect": lr.px(*r)} for p, r in a_elle(figures)), None)
        sortie["questions"].append(entree)
    if identite is not None and identite is not False:
        sortie["nom"], sortie["cadre_nom"], sortie["identite"] = cadre_du_nom_imprime(lr, pages, appareil)
    return sortie


def cadre_du_nom_imprime(lr, pages: int, appareil) -> tuple[list[dict], list[dict], list[dict]]:
    """Sur chaque page, ce que ``identifier_la_page`` y peint : la boîte de ``layout_retrouve.cadre_du_nom`` (du mot
    « Nom » jusqu'avant « page i / n »), le cadre arrondi lui-même, et la place où écrire chaque champ (« Nom »,
    « Prénom », « Classe » : du trait jusqu'au haut du cadre, celle d'un champ du formulaire)."""
    metrique = QFontMetricsF(QFont(POLICE, 10), appareil)
    cadre = QRectF(MARGE, 18, LARGEUR_UTILE, HAUT - 8 - 18)
    base = cadre.bottom() - 7 - metrique.descent()  # remplir : « Nom : » aligné en bas sur la ligne
    x = X_DU_NOM
    places = places_du_nom(metrique, x, cadre, [(etiquette, None, longueur) for etiquette, longueur in CHAMPS_DU_NOM])
    nom, cadres, champs = [], [], []
    for p in range(1, pages + 1):
        fin = cadre.right() - 8 - metrique.horizontalAdvance(f"page {p} / {pages}")
        nom.append({"page": p, "rect": lr.px(x - 4, base - metrique.ascent() - 10, fin - 6, base + metrique.descent() + 6)})
        cadres.append({"page": p, "rect": lr.px(cadre.left(), cadre.top(), cadre.right(), cadre.bottom())})
        champs += [{"page": p, "champ": etiquette.strip(" :"),
                    "rect": lr.px(debut, cadre.top() + 3, debut + longueur, cadre.bottom() - 7)}
                   for etiquette, _, _, debut, longueur in places]
    return nom, cadres, champs


CADRE_GROUPE, RAYON_GROUPE = "#bfbfbf", 3  # un gris léger, le même que le cadre des blocs de code


def plages_marquees(bloc, marque=MARQUE_GROUPE):
    """Les plages de texte que ``groupe_a_entourer`` (ou ``marque``) a marquées, fragments contigus fusionnés : un groupe en est une
    seule, alors que Qt le découpe en autant de fragments que de propositions et de séparateurs."""
    debut = fin = None
    it = bloc.begin()
    while not it.atEnd():
        fragment = it.fragment()
        it += 1
        if fragment.charFormat().background().color().name() != marque:
            continue
        depart = fragment.position() - bloc.position()
        if depart == fin:
            fin += fragment.length()
        else:
            if debut is not None:
                yield debut, fin
            debut, fin = depart, depart + fragment.length()
    if debut is not None:
        yield debut, fin


def cadres_des_groupes(document, marque=MARQUE_GROUPE):
    """Où chaque groupe de propositions a atterri, une fois le document mis en page : Qt n'encadre pas un fragment en
    ligne, mais le PDF est peint par nous, donc le cadre se trace au pinceau sur la mise en page qu'il a calculée.
    Un groupe coupé en fin de ligne rend un rectangle par ligne — deux demi-cadres, comme un mot coupé."""
    bloc = document.begin()
    while bloc.isValid():
        layout, origine = bloc.layout(), document.documentLayout().blockBoundingRect(bloc).topLeft()
        for debut, fin in plages_marquees(bloc, marque):
            for i in range(layout.lineCount()):
                ligne = layout.lineAt(i)
                d, f = max(debut, ligne.textStart()), min(fin, ligne.textStart() + ligne.textLength())
                if d < f:
                    x, largeur = ligne.cursorToX(d)[0], ligne.cursorToX(f)[0] - ligne.cursorToX(d)[0]
                    yield QRectF(origine.x() + x, origine.y() + ligne.y() + 1, largeur, ligne.height() - 2)
        bloc = bloc.next()


CHAMPS_DU_NOM = (("Nom : ", 0), ("   Prénom : ", 0), ("   Classe : ", 45))  # étiquette, longueur du trait (0 : le reste)
X_DU_NOM = MARGE + 8 + 20 + 8  # après le panneau attention (``identifier_la_page``)


def identifier_la_page(peintre, identite, numero):
    """Tout en haut de chaque page, la première comprise : nom, prénom et classe, pour qu'une feuille séparée des autres
    reste à son élève, et à droite, dans le cadre, le ``numero`` (« page 2 / 3 »). ``identite`` : (nom, prénom, classe),
    chacun imprimé s'il est connu, un trait à remplir sinon ; le tout dans un cadre marqué d'un panneau attention qui ne
    se laisse pas oublier, le même sur une copie au nom imprimé (le professeur, 10/11/2026). False pour rien (corrigé, projet) ; le cadre (1 cm de haut)
    descend de la marge dans le BANDEAU. None : ni cadre ni numéro, le corps partagé des copies d'un même profil, que
    ``cadres_nominatifs`` complète élève par élève."""
    if identite is None:
        return
    peintre.setFont(QFont(POLICE, 10))
    cadre = QRectF(MARGE, 18, LARGEUR_UTILE, HAUT - 8 - 18)
    peintre.drawText(cadre.adjusted(0, 0, -8, 0), Qt.AlignRight | Qt.AlignVCenter, numero)
    if identite is False:
        return
    ligne = cadre.bottom() - 7
    # cadre et panneau aussi quand le nom est imprimé (copie personnalisée) : « je souhaite garder la meme mise en page de
    # la cartouche, que pour les copies normales » (le professeur, 10/11/2026)
    peintre.setPen(QPen(QColor("black"), 1))
    peintre.drawRoundedRect(cadre, 4, 4)
    cote, bas = 20, cadre.center().y() + 8  # le panneau attention : triangle noir plein, point d'exclamation blanc
    peintre.setBrush(QColor("black"))
    peintre.drawPolygon(QPolygonF([QPointF(MARGE + 8, bas), QPointF(MARGE + 8 + cote, bas),
                                   QPointF(MARGE + 8 + cote / 2, bas - cote * 0.87)]))
    peintre.setBrush(Qt.NoBrush)
    # dessiné et non écrit : le gras de la police donne un trait trop fin (l'utilisateur, 05/11/2026)
    milieu = MARGE + 8 + cote / 2
    peintre.setPen(QPen(QColor("white"), 2.4, Qt.SolidLine, Qt.RoundCap))
    peintre.drawLine(QPointF(milieu, bas - 12), QPointF(milieu, bas - 7.5))
    peintre.drawPoint(QPointF(milieu, bas - 2.8))
    peintre.setPen(QColor("black"))
    remplir(peintre, X_DU_NOM, ligne, cadre, tuple((etiquette, valeur, longueur)
                                                  for (etiquette, longueur), valeur in zip(CHAMPS_DU_NOM, identite)))


def noter_la_copie(peintre, total):
    """Sous le cadre Nom de la première page, celui du correcteur : « Note : ____ / total » à gauche, deux lignes
    d'appréciation à droite, au même trait arrondi que le cadre Nom. ``ecrire_pdf`` lui a réservé la place."""
    cadre = QRectF(MARGE, HAUT, LARGEUR_UTILE, CADRE_NOTE)
    peintre.setPen(QPen(QColor("black"), 1))
    peintre.drawRoundedRect(cadre, 4, 4)
    lignes = (cadre.top() + 16, cadre.top() + 33)
    peintre.setFont(QFont(POLICE, 12, QFont.Bold))
    hauteur = lignes[1] - cadre.top()
    x = MARGE + 8 + QFontMetricsF(peintre.font()).horizontalAdvance("Note : ")
    peintre.drawText(QRectF(MARGE + 8, cadre.top(), 150, hauteur), Qt.AlignLeft | Qt.AlignBottom, "Note :")
    peintre.drawText(QRectF(x + 44, cadre.top(), 150, hauteur), Qt.AlignLeft | Qt.AlignBottom, f"/ {total}")
    peintre.setFont(QFont(POLICE, 10))
    gauche = MARGE + 170  # l'appréciation
    peintre.drawText(QRectF(gauche, cadre.top(), 100, lignes[0] - cadre.top()), Qt.AlignLeft | Qt.AlignBottom, "Appréciation :")
    debut = gauche + QFontMetricsF(peintre.font()).horizontalAdvance("Appréciation : ")
    peintre.setPen(QPen(QColor(TRAIT_ECRITURE), 0.7))  # les traits où écrire
    peintre.drawLine(QPointF(x, lignes[1]), QPointF(x + 40, lignes[1]))
    peintre.drawLine(QPointF(debut, lignes[0]), QPointF(cadre.right() - 8, lignes[0]))
    peintre.drawLine(QPointF(gauche, lignes[1]), QPointF(cadre.right() - 8, lignes[1]))
    peintre.setPen(QColor("black"))


def places_du_nom(metrique: QFontMetricsF, x: float, cadre: QRectF,
                  champs) -> list[tuple[str, Any, float, float, float]]:
    """Où ``remplir`` pose les ``champs`` (étiquette, valeur, longueur) : (étiquette, valeur, x de l'étiquette, x du
    trait, longueur du trait) ; un trait de longueur 0 prend ce qui reste jusqu'au numéro de page, partagé entre eux.
    La source unique de leur place, pour la peinture et pour les champs du formulaire (``cadre_du_nom_imprime``)."""
    fin = cadre.right() - metrique.horizontalAdvance("page 00 / 00") - 20  # le numéro de page, à droite
    # un trait de longueur fixe s'allonge seulement si la valeur, écrite en Kalam gras 11 pt, le dépasse
    metrique_main = QFontMetricsF(QFont(POLICE_MAIN, 11, QFont.Weight.Bold))
    champs = [(etiquette, valeur, longueur and max(longueur, metrique_main.horizontalAdvance(valeur or "") + 4))
              for etiquette, valeur, longueur in champs]
    pris = sum(metrique.horizontalAdvance(etiquette) + longueur for etiquette, _, longueur in champs)
    extensibles = sum(1 for _, _, longueur in champs if not longueur)
    reste = max(fin - x - pris, 0) / max(extensibles, 1)
    places = []
    for etiquette, valeur, longueur in champs:
        largeur = metrique.horizontalAdvance(etiquette)
        places.append((etiquette, valeur, x, x + largeur, longueur or reste))
        x += largeur + (longueur or reste)
    return places


def remplir(peintre, x, ligne, cadre, champs):
    """Écrit les ``champs`` (étiquette, valeur, longueur) côte à côte sur la ``ligne`` du cadre, aux places de
    ``places_du_nom`` : la valeur si elle est connue, sinon un trait où écrire."""
    # la valeur connue s'écrit SUR le trait, aux places de la copie à remplir (le professeur, 10/11/2026 : « exactement la
    # meme forme que pour les copies normales ») ;
    # écrite à la main, en gras (« en ecriture manuscrite grasse (kamal ? ) », 10/11/2026) : Kalam, la main du corrigé ;
    # la graisse est synthétisée par Qt, Kalam Bold n'étant pas installé
    imprime, main = peintre.font(), QFont(POLICE_MAIN, 11, QFont.Weight.Bold)
    for etiquette, valeur, x_etiquette, x, longueur in places_du_nom(QFontMetricsF(imprime), x, cadre, champs):
        peintre.setPen(QColor("black"))
        peintre.drawText(QRectF(x_etiquette, cadre.top(), x - x_etiquette, ligne - cadre.top()), Qt.AlignLeft | Qt.AlignBottom, etiquette)
        peintre.setPen(QPen(QColor(TRAIT_ECRITURE), 0.7))
        peintre.drawLine(QPointF(x, ligne), QPointF(x + longueur, ligne))
        if valeur:
            peintre.setPen(QColor("black"))
            peintre.setFont(main)
            peintre.drawText(QRectF(x + 2, cadre.top() - 4, longueur, ligne - cadre.top() + 6), Qt.AlignLeft | Qt.AlignBottom, valeur)
            peintre.setFont(imprime)
    peintre.setPen(QColor("black"))


def ecrire_pdf(contenu, images, svgs, chemin, pied, agrandi=False, identite=False, pieces=None, total=None, tableaux=None,
               cases_des_figures=None, sans_empattement=False, imprimees=None):
    """Met en page le HTML et le peint page par page ; renvoie le nombre de pages. ``images`` : nom -> QImage, ``svgs`` :
    nom -> octets, dessinés en vecteurs. ``agrandi`` : police et interligne du profil agrandi (le HTML est déjà passé
    par ``agrandir``). ``identite`` : ce que ``identifier_la_page`` reporte en haut de chaque page, à côté du numéro de
    page, False pour rien (corrigé, projet). ``pieces`` : nom -> octets, les fichiers à joindre, invisibles à l'affichage et à l'impression.
    ``total`` : les points du sujet, pour le cadre de la note (``noter_la_copie``) ; None pour pas de cadre (corrigé, projet).
    ``tableaux`` : nom -> grille, les conversions ``en_tableau`` (``Rendu.tableaux``), leurs flèches dans ``svgs``.
    ``cases_des_figures`` : les cases des figures de conversion (``Rendu.cases_des_figures``), pour le plan joint.
    ``sans_empattement`` : police du corps de l'aménagement de ce nom (le HTML est déjà passé par ``sans_empattement``).
    ``imprimees`` : (étiquette, question) dans l'ordre d'impression (``Rendu.imprimees``), pour joindre ``POSITIONS`` ;
    None pour ne pas le joindre (corrigé, projet)."""
    pdf = QPdfWriter(str(chemin))
    for nom, octets in (pieces or {}).items():
        pdf.addFileAttachment(nom, octets, "application/octet-stream")
    pdf.setTitle(pied)
    mise = mettre_en_page(contenu, images, svgs, pdf, agrandi, total, tableaux, sans_empattement, Path(chemin).name)
    peintre = QPainter(pdf)
    for i in range(mise.pages):
        if i:
            pdf.newPage()
        peindre_page(peintre, mise, i, svgs, pied, identite, total)
    # après le dessin, avant ``end`` : la pièce jointe s'écrit encore, et le plan est celui de la mise en page peinte
    pdf.addFileAttachment(PLAN, json.dumps(plan_des_cases(mise.document, mise.conversions, cases_des_figures, mise.svg.places),
                                                ensure_ascii=False).encode(),
                          "application/json")
    if imprimees is not None:
        positions = positions_imprimees(mise.document, imprimees, mise.traits, identite, mise.pages, pdf)
        positions["formes"] = formes_imprimees(mise, svgs, pied, identite, total)
        pdf.addFileAttachment(POSITIONS, json.dumps(positions, ensure_ascii=False).encode(), "application/json")
    peintre.end()
    return mise.pages


class MiseEnPage:
    """Le sujet mis en page par ``mettre_en_page`` : ce que ``peindre_page`` peint, sur un PDF (``ecrire_pdf``) comme
    à l'écran (le mode papier du lecteur), et d'où ``positions_imprimees`` relève les zones de réponse."""

    def __init__(self, document, svg, echelle, conversions, cadres, ronds, traits):
        self.document, self.svg, self.echelle, self.conversions = document, svg, echelle, conversions
        self.cadres, self.ronds, self.traits = cadres, ronds, traits
        self.pages = document.pageCount()
        self.appareil = None  # gardé en vie : le documentLayout le mesure encore après ``mettre_en_page``


def appareil_de_mesure(appareil=None):
    """La page A4 à 72 points par pouce, sans marge, sur laquelle le sujet se met en page : le ``QPdfWriter`` du PDF
    écrit, ou, pour une mise en page sans fichier (le mode papier du lecteur), un ``QPdfWriter`` sur ``os.devnull``,
    pour que la géométrie soit celle de l'impression au point près."""
    appareil = appareil or QPdfWriter(os.devnull)
    appareil.setPageSize(QPageSize(QPageSize.A4))
    appareil.setResolution(72)
    appareil.setPageMargins(QMarginsF(0, 0, 0, 0))
    return appareil


def mettre_en_page(contenu, images, svgs, appareil=None, agrandi=False, total=None, tableaux=None,
                   sans_empattement=False, nom="") -> MiseEnPage:
    """Met en page le HTML d'un ``Rendu`` sur ``appareil`` (``appareil_de_mesure``) ; les paramètres sont ceux de
    ``ecrire_pdf``, ``nom`` celui que nomme l'avertissement d'un tableau qui coupe un mot."""
    appareil = appareil_de_mesure(appareil)
    document = QTextDocument()
    document.documentLayout().setPaintDevice(appareil)
    document.setDefaultFont(police_du_corps(round(10 * ECHELLE_AGRANDI) if agrandi else 10,
                                            frozenset({"sans_empattement"}) if sans_empattement else frozenset()))
    document.setDocumentMargin(0)
    for cle, image in images.items():
        document.addResource(QTextDocument.ImageResource, QUrl(cle), image)
    svg = ObjetSvgReleve(document, svgs, 72, LARGEUR_UTILE)  # 72 points par pouce : la résolution du QPdfWriter
    document.setHtml(contenu.replace(LARGE, ""))  # les blocs élargis sont arrivés au premier niveau : la marque a servi
    bordures_au_point(document.rootFrame())
    taille_des_parties(document)
    svg.poser()
    if total is not None:  # la place du cadre de la note, en tête de la première page : un bloc vide de sa hauteur
        curseur = QTextCursor(document)  # (Qt ignore la marge haute du premier bloc d'un cadre)
        curseur.insertBlock(curseur.blockFormat(), curseur.charFormat())
        curseur.movePosition(QTextCursor.Start)
        format_bloc = QTextBlockFormat()
        format_bloc.setLineHeight(CADRE_NOTE + 9, QTextBlockFormat.FixedHeight.value)
        curseur.setBlockFormat(format_bloc)
    if agrandi:
        curseur = QTextCursor(document)
        curseur.select(QTextCursor.Document)
        format_bloc = QTextBlockFormat()
        format_bloc.setLineHeight(150, QTextBlockFormat.ProportionalHeight.value)
        curseur.mergeBlockFormat(format_bloc)
    document.setPageSize(QSizeF(LARGEUR_UTILE, HAUTEUR_UTILE))
    echelle = ECHELLE_AGRANDI if agrandi else 1
    conversions = regler_les_conversions(document, tableaux or {}, echelle)
    if coupes := mots_entiers_dans_les_tableaux(document):  # un garde-fou : il signale, le tableau est à revoir
        print(f"{nom} : AVERTISSEMENT, tableau(x) qui coupent encore un mot à "
              f"{PLANCHER_MOTS_ENTIERS:.0%} de leur corps : {', '.join(coupes)}")
    titres = sauts_de_page(document)  # avant que ``eviter_les_coupures`` n'en ajoute
    eviter_les_coupures(document)
    commencer_sur_une_feuille(document, titres)
    mise = MiseEnPage(document, svg, echelle, conversions, list(cadres_des_groupes(document)),
                      list(cadres_des_groupes(document, MARQUE_ENTOURE)), traits_des_tableaux(document))
    mise.appareil = appareil
    return mise


def peindre_page(peintre, mise: MiseEnPage, i: int, svgs, pied, identite=False, total=None):
    """Peint la page ``i`` (à partir de 0) de ``mise`` dans le repère d'une page A4 en points, origine en haut à gauche :
    le ``QPainter`` d'un ``QPdfWriter`` tel quel, celui d'un widget mis à l'échelle. ``svgs``, ``pied``, ``identite`` et
    ``total`` : ceux de ``ecrire_pdf``."""
    document = mise.document
    peintre.save()
    peintre.setClipRect(QRectF(MARGE, HAUT, LARGEUR_MAXI, HAUTEUR_UTILE))  # de quoi laisser passer un bloc élargi
    peintre.translate(MARGE, HAUT - i * HAUTEUR_UTILE)
    contexte = QAbstractTextDocumentLayout.PaintContext()
    contexte.clip = QRectF(0, i * HAUTEUR_UTILE, LARGEUR_MAXI, HAUTEUR_UTILE)
    document.documentLayout().draw(peintre, contexte)
    peintre.setPen(QPen(QColor(CADRE_GROUPE), 0.7))
    for cadre in mise.cadres:
        peintre.drawRoundedRect(cadre, RAYON_GROUPE, RAYON_GROUPE)
    peintre.setPen(QPen(QColor(VERT_REPONSE), 1.2, Qt.SolidLine, Qt.RoundCap))
    for rond in mise.ronds:  # les cases à entourer d'un corrigé, comme le correcteur les entoure à l'écran
        rond_a_la_main(peintre, rond, (4, 1))
    for couleur, lignes in mise.traits.items():
        peintre.setPen(QPen(QColor(couleur), TRAIT_TABLEAU, Qt.SolidLine, Qt.SquareCap))
        peintre.drawLines(lignes)
    peindre_les_conversions(peintre, document, mise.conversions, svgs, mise.echelle)
    peintre.restore()
    identifier_la_page(peintre, identite, f"page {i + 1} / {mise.pages}")
    if total is not None and not i:
        noter_la_copie(peintre, total)
    peintre.setFont(QFont(POLICE, 8))
    zone = QRectF(MARGE, HAUTEUR - MARGE - PIED + 4, LARGEUR_UTILE, PIED)
    peintre.drawText(zone, Qt.AlignLeft | Qt.AlignVCenter, pied)


def formes_imprimees(mise: MiseEnPage, svgs, pied, identite=False, total=None) -> dict[str, dict[str, list[list[int]]]]:
    """Tout ce que ``peindre_page`` imprime, en rectangles pour le placement vectoriel de la correction papier ([POE-7],
    le professeur, 24/11/2026 : « on ne peut pas passer tout le placement en vectoriel ? ») : {page: {nature: [[x0, y0,
    x1, y1], ...]}}, en pixels à ``layout_retrouve.PPP``, repère de ``positions_imprimees``. Natures : « texte », un
    mot, boîte de l'encre de ses glyphes (``boites``, pas celle de ``pdftotext`` qui monte à l'ascendante) ; « case »,
    un ⭘ ou ☐ ; et, relevés en peignant la page dans un SVG comme ``traits_des_tableaux`` : « trait », chaque segment
    tracé (épaisseur du stylo comprise), « ligne » ceux de ``TRAIT_ECRITURE`` où l'élève écrit, « cadre » ceux d'un
    contour fermé, « aplat » une surface remplie, « image » une image ; un texte peint hors du document (en-tête, note,
    pied) y est mesuré par ``QFontMetricsF``."""
    lr = layout_retrouve()
    formes: dict[str, dict[str, list[list[int]]]] = {}

    def poser(page: int, nature: str, r: QRectF) -> None:
        formes.setdefault(str(page), {}).setdefault(nature, []).append(lr.px(r.left(), r.top(), r.right(), r.bottom()))

    cases = "".join(lr.CASES)
    document, mots = mise.document, {}  # mots : page -> [QRectF] des mots du document, pour ignorer leur <text> du SVG
    bloc = document.begin()
    while bloc.isValid():
        texte = list(bloc.text())  # un caractère qui ne marque pas le papier (« $ » transparents de l'indentation,
        morceau = bloc.begin()      # « Réponse : » en blanc) compte pour une espace
        while not morceau.atEnd():
            f = morceau.fragment()
            couleur = f.charFormat().foreground().color()
            if couleur.alpha() == 0 or couleur.lightness() == 255:
                debut = f.position() - bloc.position()
                texte[debut:debut + f.length()] = " " * f.length()
            morceau += 1
        texte = "".join(texte)
        for m in re.finditer(f"[{cases}]|[^\\s{cases}\ufffc]+", texte):
            encre = boites(document, bloc, m.start(), len(m.group()))[1]
            if not encre.isEmpty():
                page, r = rect_sur_la_page(encre)
                rect = QRectF(QPointF(*r[:2]), QPointF(*r[2:]))
                poser(page, "case" if m.group() in lr.CASES else "texte", rect)
                mots.setdefault(page, []).append(rect.adjusted(-1, -1, 1, 1))
        bloc = bloc.next()
    mesure = appareil_de_mesure()
    for i in range(mise.pages):
        tampon = QBuffer()
        tampon.open(QIODevice.WriteOnly)
        svg = QSvgGenerator()
        svg.setOutputDevice(tampon)
        svg.setResolution(72)
        peintre = QPainter(svg)
        peindre_page(peintre, mise, i, svgs, pied, identite, total)
        peintre.end()
        page = QRectF(0, 0, LARGEUR, HAUTEUR)
        zone = QRectF(MARGE, HAUT, LARGEUR_MAXI, HAUTEUR_UTILE)  # le clip de ``peindre_page`` pour le document
        document_ici = QTransform.fromTranslate(MARGE, HAUT - i * HAUTEUR_UTILE)  # la couche du document (``peindre_page``)
        for nature, r, du_document in formes_du_svg(ET.fromstring(bytes(tampon.data())), mesure, document_ici):
            if nature == "texte?":  # un <text> : peint hors du document s'il n'est sur aucun de ses mots
                if any(m.contains(r.center()) for m in mots.get(i + 1, [])):
                    continue
                nature = "texte"
            # le SVG ne garde pas le clip de ``peindre_page`` : ce que la couche du document peint des pages voisines
            r = r & (zone if du_document else page)
            if r.width() > 0 or r.height() > 0:
                poser(i + 1, nature, r)
    return formes


def formes_du_svg(racine, mesure, document: QTransform) -> list[tuple[str, QRectF, bool]]:
    """(nature, rectangle en points de la page, peint par la couche du document ?) de chaque élément visible d'un SVG
    de ``QSvgGenerator`` : style et ``matrix`` hérités des groupes ; « texte? » pour un mot d'un <text>. La couche du
    document est le groupe dont la matrice vaut ``document``, et ce qu'il contient."""
    out = []

    def visible(style: dict, cle: str) -> bool:
        return (style.get(cle, "none").lower() not in ("none", "#ffffff")  # le blanc ne marque pas le papier
                and float(style.get(f"{cle}-opacity", 1)) > 0)

    def parcourir(noeud, matrice: QTransform, style: dict, dedans: bool) -> None:
        style = style | {k: v for k, v in noeud.attrib.items() if k.startswith(("fill", "stroke", "font"))}
        if (m := noeud.get("transform", "")).startswith("matrix("):
            a, b, c, d, e, f = (float(v) for v in m[7:-1].split(","))
            matrice = QTransform(a, b, c, d, e, f) * matrice
            dedans = dedans or matrice == document
        balise = noeud.tag.rsplit("}", 1)[-1]
        epaisseur = float(style.get("stroke-width", 1)) * math.hypot(matrice.m11(), matrice.m12())
        couleur = style.get("stroke", "").lower()
        trait = "ligne" if couleur == TRAIT_ECRITURE else "trait"
        if balise == "text" and visible(style, "fill"):
            police = QFont(style.get("font-family", POLICE).strip("'\""))
            police.setPointSizeF(float(style.get("font-size", "10").rstrip("ptx")))
            poids = style.get("font-weight", "400")
            police.setBold(poids == "bold" or (poids.isdigit() and int(poids) >= 600))
            police.setItalic(style.get("font-style") == "italic")
            metrique = QFontMetricsF(police, mesure)
            texte = "".join(noeud.itertext())
            x, y = float(noeud.get("x", 0)), float(noeud.get("y", 0))
            for m in re.finditer(r"\S+", texte):
                r = metrique.tightBoundingRect(m.group()).translated(x + metrique.horizontalAdvance(texte[:m.start()]), y)
                out.append(("texte?", matrice.mapRect(r), dedans))
        elif balise == "image":
            out.append(("image", matrice.mapRect(QRectF(*(float(noeud.get(k, 0)) for k in ("x", "y", "width", "height")))), dedans))
        elif balise in ("rect", "path", "polyline", "polygon", "line", "ellipse", "circle"):
            for ferme, points in contours(balise, noeud):
                points = [matrice.map(p) for p in points]
                if visible(style, "fill") and len(points) > 2:
                    xs, ys = [p.x() for p in points], [p.y() for p in points]
                    out.append(("aplat", QRectF(QPointF(min(xs), min(ys)), QPointF(max(xs), max(ys))), dedans))
                if visible(style, "stroke"):
                    for p, q in zip(points, points[1:] + points[:1] if ferme else points[1:]):
                        r = QRectF(p, q).normalized().adjusted(-epaisseur / 2, -epaisseur / 2, epaisseur / 2, epaisseur / 2)
                        out.append(("cadre" if ferme and trait == "trait" else trait, r, dedans))
        for enfant in noeud:
            parcourir(enfant, matrice, style, dedans)

    parcourir(racine, QTransform(), {}, False)
    return out


def contours(balise: str, noeud) -> list[tuple[bool, list[QPointF]]]:
    """Les sous-chemins d'une forme SVG en points (fermé ?, sommets) ; une courbe vaut ses points de contrôle, qui
    l'englobent ; une ellipse, son rectangle."""
    f = lambda k: float(noeud.get(k, 0))  # noqa: E731
    if balise == "rect":
        x, y, l, h = f("x"), f("y"), f("width"), f("height")
        return [(True, [QPointF(x, y), QPointF(x + l, y), QPointF(x + l, y + h), QPointF(x, y + h)])]
    if balise in ("ellipse", "circle"):
        rx, ry = (f("r"), f("r")) if balise == "circle" else (f("rx"), f("ry"))
        cx, cy = f("cx"), f("cy")
        return [(True, [QPointF(cx - rx, cy - ry), QPointF(cx + rx, cy - ry), QPointF(cx + rx, cy + ry), QPointF(cx - rx, cy + ry)])]
    if balise == "line":
        return [(False, [QPointF(f("x1"), f("y1")), QPointF(f("x2"), f("y2"))])]
    if balise in ("polyline", "polygon"):
        v = [float(t) for t in re.findall(r"-?[\d.]+(?:e-?\d+)?", noeud.get("points", ""))]
        return [(balise == "polygon", [QPointF(a, b) for a, b in zip(v[::2], v[1::2])])]
    out, courant, ferme = [], [], False
    for commande, nombres in re.findall(r"([MLCZmlcz])([^MLCZmlcz]*)", noeud.get("d", "")):
        v = [float(t) for t in re.findall(r"-?[\d.]+(?:e-?\d+)?", nombres)]
        if commande in "Mm" and courant:
            out.append((ferme, courant))
            courant, ferme = [], False
        if commande in "Zz":
            ferme = True
        courant += [QPointF(a, b) for a, b in zip(v[::2], v[1::2])]
    if courant:
        out.append((ferme or (len(courant) > 2 and courant[0] == courant[-1]), courant))
    return out


def lire_eleves(chemin):
    """Un CSV (séparateur détecté) avec une colonne Nom, une colonne Prénom et, au choix, une colonne Classe et une
    colonne Aménagements (valeurs de AMENAGEMENTS séparées par des espaces ou des virgules) ; sans en-tête, les deux
    premières colonnes."""
    lignes = chemin.read_text(encoding="utf-8-sig").splitlines()
    lignes = [l for l in csv.reader(lignes, csv.Sniffer().sniff(lignes[0], ",;\t")) if any(c.strip() for c in l)]
    entete = [c.strip().lower() for c in lignes[0]]
    nom = next((i for i, c in enumerate(entete) if c.startswith("nom")), None)
    prenom = next((i for i, c in enumerate(entete) if c.startswith("pr")), None)
    amenagements = next((i for i, c in enumerate(entete) if c.startswith("am")), None)
    classe = next((i for i, c in enumerate(entete) if c.startswith("cl")), None)
    if nom is None or prenom is None:
        nom, prenom = 0, 1
    else:
        lignes = lignes[1:]
    return [{"nom": l[nom].strip(), "prenom": l[prenom].strip(),
             "classe": l[classe].strip() if classe is not None and len(l) > classe else "",
             "amenagements": lire_amenagements(l[amenagements]) if amenagements is not None and len(l) > amenagements else frozenset()}
            for l in lignes]


def lire_amenagements(texte):
    """« agrandi, indices » -> {"agrandi", "indices"} ; une valeur inconnue arrête tout."""
    valeurs = frozenset(v.lower().replace("-", "_") for v in re.split(r"[\s,+]+", texte) if v)
    for inconnu in valeurs - AMENAGEMENTS.keys():
        sys.exit(f"aménagement inconnu : {inconnu} (connus : {', '.join(AMENAGEMENTS)})")
    return valeurs


def titre_complet(donnees: Any, amenagements: frozenset[str] = frozenset()) -> str:
    """Le pied de page : matière – niveau – thème – titre – sous-titre (l'utilisateur, 28/09/2026). Le titre qui répète le
    thème s'omet, comme la matière ou la classe que le titre dit déjà (« DS NSI Terminale N°1 »). Mention ``avec_mention``
    en fin de titre, ou du thème quand le titre s'omet."""
    titre = donnees.titre.replace("\n", " ").strip()
    deja = titre.casefold()
    omis = titre.casefold() == (donnees.theme or "").casefold()
    return " – ".join(filter(None, [*(x for x in (donnees.matiere, donnees.classe) if x and x.casefold() not in deja),
                                    avec_mention(donnees.theme or "", amenagements) if omis else donnees.theme,
                                    None if omis else avec_mention(titre, amenagements), donnees.sous_titre]))


def charger_image(octets):
    """Une image qui ne dit pas sa résolution est prise à 96 ppp (un pixel d'écran), et non au défaut de Qt."""
    image = QImage.fromData(octets)
    if b"pHYs" not in octets:
        image.setDotsPerMeterX(3780)
    return image


def sur_blanc(image):
    """Une image à fond transparent posée sur du blanc, le papier : la conversion en gris ignore la transparence et
    ferait du fond un aplat noir."""
    if not image.hasAlphaChannel():
        return image
    plat = QImage(image.size(), QImage.Format_RGB32)
    plat.fill(Qt.white)
    peintre = QPainter(plat)
    peintre.drawImage(0, 0, image)
    peintre.end()
    plat.setDotsPerMeterX(image.dotsPerMeterX())
    plat.setDotsPerMeterY(image.dotsPerMeterY())
    return plat


def cadres_nominatifs(chemin: Path, copies: list[tuple[tuple[str, str, str] | None, int]]) -> Path:
    """Le calque des copies nominatives d'un profil (``pdf_qcm.copies_nominatives``) : pour chaque (identité, pages),
    autant de pages qui ne portent que le cadre Nom et le numéro (``identifier_la_page``), ou de pages vides pour une
    identité None ; posé par ``qpdf --overlay`` sur le corps partagé, mis en page une seule fois (``exporter``,
    ``cadre=False``)."""
    pdf = QPdfWriter(str(chemin))
    pdf.setPageSize(QPageSize(QPageSize.A4))
    pdf.setResolution(72)
    pdf.setPageMargins(QMarginsF(0, 0, 0, 0))
    peintre = QPainter(pdf)
    # sur un peintre neuf, le crayon noir de 1 pt d'``identifier_la_page`` égale celui par défaut : Qt ne l'émet pas et
    # le cadre de la première page sort pâle (mesuré : 1547 pixels à 100 ppp) ; un crayon autre d'abord le fait émettre
    peintre.setPen(Qt.NoPen)
    peintre.setPen(QColor("black"))  # le numéro s'écrit au crayon courant, noir comme après le corps peint
    premiere = True
    for identite, pages in copies:
        for i in range(pages):
            if not premiere:
                pdf.newPage()
            premiere = False
            if identite is not None:
                identifier_la_page(peintre, identite, f"page {i + 1} / {pages}")
    peintre.end()
    return chemin


def exporter(chemin_sujet: Path | str, dossier: Path | None = None, eleve: dict[str, Any] | None = None,
             amenagements: frozenset[str] = frozenset(), classe: str = "", corriges: tuple[bool, ...] = (False, True),
             cadre: bool = True) -> list[Path]:
    """``corriges`` : les PDF à faire, (False,) pour le sujet seul, (True,) pour le corrigé seul. Rend leurs chemins.
    ``cadre=False`` : ni cadre Nom ni numéro de page, que ``cadres_nominatifs`` pose ensuite, élève par élève."""
    if eleve:
        amenagements = amenagements | eleve["amenagements"]
    sujet = Sujet(chemin_sujet, eleve, temps_limite="temps_limite" in amenagements)
    nom = codes.nom_de_fichier(sujet.chemin.stem)  # sans « : », refusé par Windows et Dropbox
    dossiers = {corrige: (dossier or sortie(sujet.definition, "corrigé" if corrige else "pdf")) / (nom if eleve else "")
                for corrige in corriges}  # -o : sujet et corrigé côte à côte ; copies nominatives à part
    impression = {cle: valeur for cle, valeur in (("eleve", eleve and {"nom": eleve["nom"], "prenom": eleve["prenom"]}),
                                                  ("classe", (eleve or {}).get("classe") or classe),
                                                  ("amenagements", sorted(amenagements))) if valeur}
    pieces = {f"{nom}.qcm": paquet_chiffre(chemin_sujet, impression or None)}
    images = {nom: charger_image(media)
              for nom, media in sujet.medias.items() if nom.rsplit(".", 1)[-1].lower() in IMAGES}
    svgs = {nom: media for nom, media in sujet.medias.items() if nom.lower().endswith(".svg")}
    if sujet.definition.destination in ("tp", "projet", "electronique") and sujet.logo:  # TP, projets, et le pdf d'un sujet électronique, qui montre le visuel du lecteur
        images[LOGO] = QImage(str(sujet.logo))
    gris = {nom: sur_blanc(image).convertToFormat(QImage.Format_Grayscale8) for nom, image in images.items()}
    svgs_gris = {nom: svg_gris(octets) for nom, octets in svgs.items()}
    base = re.sub(r"[\s/]+", "_", f"{eleve['nom']}_{eleve['prenom']}") if eleve else "_".join([nom, *sorted(amenagements)])
    for d in dossiers.values():
        d.mkdir(parents=True, exist_ok=True)
    agrandi = "agrandi" in amenagements
    couleur = [q.id for _, resolues in sujet.sections for question, _ in resolues
               for q in (question, *question.feuilles()) if q.couleur_obligatoire]
    if couleur:  # une version noir et blanc serait fausse, pas seulement moins jolie : elle ne doit pas exister
        print(f"{sujet.chemin.name} : impression en couleur obligatoire ({', '.join(dict.fromkeys(couleur))})")
    elif douteuses := {q.id: raison for _, resolues in sujet.sections for question, _ in resolues
                       for q in (question, *question.feuilles()) if (raison := repose_sur_la_couleur(q))}:
        print(f"{sujet.chemin.name} : AVERTISSEMENT, question(s) qui semblent reposer sur la seule couleur (élève "
              f"daltonien, impression en noir et blanc) : " + " ; ".join(f"{i} ({r})" for i, r in douteuses.items()))
    chemins = []
    for corrige in corriges:
        pied = ("Corrigé : " if corrige else "") + titre_complet(sujet.definition, amenagements)
        if eleve:  # nom imprimé s'il est connu, champs à remplir sauf au corrigé et au projet (page de garde)
            identite = (eleve["nom"], eleve["prenom"], eleve["classe"] or classe)  # la classe du CSV avant celle de -c
        else:
            identite = (None, None, classe) if not corrige and sujet.definition.destination != "projet" else False
        if not cadre:
            identite = None
        chemin = dossiers[corrige] / (base +(" - corrigé" if corrige else "") + (" (couleur)" if couleur else "") + ".pdf")

        def ecrire(taille):
            rendu = Rendu(sujet, images, corrige, amenagements)
            rendu.taille_theme = taille
            contenu = rendu.document()
            contenu = agrandir(contenu) if agrandi else contenu
            contenu = sans_empattement(contenu) if "sans_empattement" in amenagements else contenu
            figures = svgs | rendu.figures if couleur else svgs_gris | {n: svg_gris(o) for n, o in rendu.figures.items()}
            return ecrire_pdf(contenu if couleur else noir_et_blanc(contenu), images if couleur else gris, figures,
                              chemin, pied, agrandi, identite, pieces,
                              None if corrige else points(sujet.total), rendu.tableaux, rendu.cases_des_figures,
                              "sans_empattement" in amenagements,
                              None if corrige or sujet.definition.destination == "projet" else rendu.imprimees)
        tailles = TAILLES_THEME_BANDEAU if sujet.definition.destination == "electronique" else TAILLES_THEME
        pages = ecrire(tailles[0])
        # impression recto verso (l'utilisateur, 06/10/2026) : une dernière page seule au recto, peu remplie, se rattrape
        # en réduisant le thème en tête ; on garde la première taille qui l'épargne, sinon on revient à la taille normale
        if pages % 2 and pages > 1 and sujet.definition.theme and sujet.definition.destination != "projet":
            for taille in tailles[1:]:
                if (moins := ecrire(taille)) < pages:
                    pages = moins
                    break
            else:
                ecrire(tailles[0])
        if not corrige and sujet.definition.destination != "projet":
            ECARTS_POSITIONS.extend(verifier_positions(chemin, sujet))
            from formulaire_pdf import ajouter_formulaire  # composer à l'écran le même sujet (AS-11, 21/11/2026)
            ajouter_formulaire(chemin, identite=not eleve)
        print(f"{chemin} : {pages} page{'s' if pages > 1 else ''}")
        chemins.append(chemin)
    return chemins


ECARTS_POSITIONS: list[str] = []  # ceux de chaque export du processus : ``main`` sort en erreur s'il y en a


def layout_retrouve():
    """``correction/layout_retrouve.py``, importable que ``correction/`` soit ou non dans ``sys.path`` (un appel depuis
    ``QCM/`` seul, comme ``exporter_eleve`` ou les tests, ne l'y a pas)."""
    dossier = str(Path(__file__).resolve().parent / "correction")
    if dossier not in sys.path:
        sys.path.insert(0, dossier)
    import layout_retrouve as lr
    return lr


def verifier_positions(pdf: Path, sujet) -> list[str]:
    """L'oracle du fichier ``POSITIONS`` joint à ``pdf`` : le layout relu du PDF lui-même (``pdftotext -bbox`` et
    rendu, ``layout_retrouve.retrouver_pdf``, le seul chemin avant lui) doit donner les mêmes étiquettes, zones, cases
    et cadres du nom à ``layout_retrouve.TOLERANCE`` pixels près. Chaque écart est écrit sur stderr et rendu, jamais
    tu : la correction papier d'un sujet en écart ne croirait pas sa pièce jointe (``layout_retrouve.positions``)."""
    lr = layout_retrouve()
    ecrit = json.loads(piece_jointe(pdf, POSITIONS))
    lu, ecarts = lr.retrouver_pdf(Path(pdf), sujet, sujet.chemin.name)
    ecarts = [f"relecture du PDF : {e}" for e in ecarts] + lr.comparer(ecrit, lu)  # comparer rend aussi un « ecart » écrit
    for e in ecarts:
        print(f"{Path(pdf).name} : POSITIONS en écart : {e}", file=sys.stderr)
    return ecarts


def paquet_chiffre(chemin_sujet, impression=None):
    """Les octets du ``.qcm`` que joint chaque PDF : celui dont on part, s'il en est un (un paquet ``.json`` en clair, chiffré ; ou un PDF qui en porte un), sinon
    le paquet qu'``exporter_eleve.py`` ferait du sujet (``preparer`` : classes de son niveau comprises, que « Déployer » propose), avec la même graine (pas celui d'un élève : son tirage s'en
    redéduit), chiffré par une clé tirée du mot de passe professeur (``exporter_eleve.cle_neuve``). C'est lui qui permet de regénérer plus tard la page vierge exacte d'une
    copie à corriger — les questions du dépôt, elles, auront changé. ``impression`` : l'élève, la classe et les aménagements
    d'une copie imprimée pour lui (``Paquet.impression``) ; le paquet est alors refait, même d'un paquet ou d'un PDF."""
    chemin_sujet = Path(chemin_sujet)
    if impression is None and (chemin_sujet.suffix == ".qcm" or est_paquet(chemin_sujet)):  # sans clé de correction, comme le paquet d'un sujet
        return chiffre(chemin_sujet, cle_api=False)
    if impression is None and chemin_sujet.suffix == ".pdf":
        return piece_jointe(chemin_sujet)
    contenu, cle = preparer(Sujet(chemin_sujet))
    contenu.impression = impression
    with tempfile.TemporaryDirectory() as dossier:
        chemin = Path(dossier) / "sujet.qcm"
        sauver(contenu, chemin, cle)
        return chemin.read_bytes()


def main():
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujets", nargs="*", type=Path, help="sujets à exporter (défaut : tous ceux de sujets/)")
    analyseur.add_argument("-o", "--dossier", type=Path, help="dossier de sortie (défaut : celui du champ dossier du sujet, sinon Exports/pdf/)")
    analyseur.add_argument("-e", "--eleves", type=Path, help="CSV des élèves (Nom, Prénom, Classe facultative) : une copie par élève, dans un sous-dossier au nom du sujet")
    analyseur.add_argument("-c", "--classe", default="", help="classe imprimée en haut de chaque page (« 2nde 5 ») ; sans elle, un trait à remplir")
    analyseur.add_argument("-a", "--amenagements", default="", type=lire_amenagements,
                           help="aménagements de toutes les copies : " + " ; ".join(f"{k} = {v}" for k, v in AMENAGEMENTS.items()))
    arguments = analyseur.parse_args()
    application()
    eleves = lire_eleves(arguments.eleves) if arguments.eleves else [None]
    for chemin in arguments.sujets or les_sujets():
        for eleve in eleves:
            exporter(chemin, arguments.dossier, eleve, arguments.amenagements, arguments.classe)
    if ECARTS_POSITIONS:
        sys.exit(f"{len(ECARTS_POSITIONS)} écart(s) entre les positions écrites et le PDF relu (détail ci-dessus)")


if __name__ == "__main__":
    main()
