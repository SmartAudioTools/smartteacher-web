"""Ed25519 (RFC 8032) en Python pur : signer et vérifier, sur le bureau comme dans le navigateur (Pyodide), sans bibliothèque
à embarquer ni CDN. Sert à la signature d'``echeances.csv`` (``echeances.signer``, ``echeances.verifie``) : le jeton Dropbox
de la page permet à qui le lit de réécrire ce fichier, la page n'en garde qu'une version signée par le professeur.
Lent (quelques millisecondes par opération), sans protection contre les canaux auxiliaires : il ne signe que sur la machine
ou dans la page du professeur, et vérifie un fichier par visite. Accord avec ``cryptography`` vérifié par
``tests_modele.test_echeances_signees``."""

from __future__ import annotations

import hashlib

P = 2**255 - 19
Q = 2**252 + 27742317777372353535851937790883648493  # l'ordre du groupe
D = -121665 * pow(121666, P - 2, P) % P
RACINE_MOINS_UN = pow(2, (P - 1) // 4, P)
Point = tuple[int, int, int, int]  # coordonnées étendues (X, Y, Z, T)
NEUTRE: Point = (0, 1, 1, 0)


def _ajouter(a: Point, b: Point) -> Point:
    x1, y1, z1, t1 = a
    x2, y2, z2, t2 = b
    pa, pb = (y1 - x1) * (y2 - x2) % P, (y1 + x1) * (y2 + x2) % P
    pc, pd = 2 * t1 * t2 * D % P, 2 * z1 * z2 % P
    e, f, g, h = pb - pa, pd - pc, pd + pc, pb + pa
    return e * f % P, g * h % P, f * g % P, e * h % P


def _multiplier(n: int, point: Point) -> Point:
    resultat = NEUTRE
    while n:
        if n & 1:
            resultat = _ajouter(resultat, point)
        point = _ajouter(point, point)
        n >>= 1
    return resultat


def _egaux(a: Point, b: Point) -> bool:
    return (a[0] * b[2] - b[0] * a[2]) % P == 0 and (a[1] * b[2] - b[1] * a[2]) % P == 0


def _x(y: int, signe: int) -> int | None:
    if y >= P:
        return None
    x2 = (y * y - 1) * pow(D * y * y + 1, P - 2, P) % P
    if x2 == 0:
        return None if signe else 0
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P:
        x = x * RACINE_MOINS_UN % P
    if (x * x - x2) % P:
        return None
    return P - x if (x & 1) != signe else x


_GY = 4 * pow(5, P - 2, P) % P
_GX = _x(_GY, 0)
G: Point = (_GX, _GY, 1, _GX * _GY % P)


def _compresser(point: Point) -> bytes:
    inverse = pow(point[2], P - 2, P)
    x, y = point[0] * inverse % P, point[1] * inverse % P
    return (y | (x & 1) << 255).to_bytes(32, "little")


def _decompresser(octets: bytes) -> Point | None:
    if len(octets) != 32:
        return None
    y = int.from_bytes(octets, "little")
    signe, y = y >> 255, y & (1 << 255) - 1
    x = _x(y, signe)
    return None if x is None else (x, y, 1, x * y % P)


def _hache(octets: bytes) -> int:
    return int.from_bytes(hashlib.sha512(octets).digest(), "little") % Q


def _developper(graine: bytes) -> tuple[int, bytes]:
    h = hashlib.sha512(graine).digest()
    a = int.from_bytes(h[:32], "little") & (1 << 254) - 8 | 1 << 254
    return a, h[32:]


def publique(graine: bytes) -> bytes:
    """La clé publique (32 octets) de la clé secrète ``graine`` (32 octets)."""
    return _compresser(_multiplier(_developper(graine)[0], G))


def signer(graine: bytes, message: bytes) -> bytes:
    """La signature (64 octets) de ``message`` par ``graine``."""
    a, prefixe = _developper(graine)
    cle = _compresser(_multiplier(a, G))
    r = _hache(prefixe + message)
    point_r = _compresser(_multiplier(r, G))
    s = (r + _hache(point_r + cle + message) * a) % Q
    return point_r + s.to_bytes(32, "little")


def verifier(cle: bytes, message: bytes, signature: bytes) -> bool:
    """Vrai si ``signature`` est celle de ``message`` par la clé publique ``cle`` ; faux pour toute entrée mal formée."""
    if len(cle) != 32 or len(signature) != 64:
        return False
    point_a, point_r = _decompresser(cle), _decompresser(signature[:32])
    s = int.from_bytes(signature[32:], "little")
    if point_a is None or point_r is None or s >= Q:
        return False
    h = _hache(signature[:32] + cle + message)
    return _egaux(_multiplier(s, G), _ajouter(point_r, _multiplier(h, point_a)))
