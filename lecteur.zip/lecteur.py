#!/usr/bin/env python3
"""Lit un sujet et y répond : l'application de l'élève.

    python lecteur.py SUJET.qcm|SUJET.pdf [--mot-de-passe MOT] [--eleve "Nom Prénom"] [--auto] [--capture IMAGE.png]

L'élève commence par la boîte d'accueil (``Accueil``) : son nom, son prénom et, si le sujet en demande un, le code de
déverrouillage ; la même boîte, dans le canevas, ouvre l'épreuve dans le navigateur (web/pyqt6/pont_qt.py). ``--eleve`` la
saute quand le sujet s'ouvre sans code (la sonde fait de même par ``?eleve=``), tout comme l'identité que SmartOS exporte
dans la session (``UTILISATEUR_NOM``/``UTILISATEUR_PRENOM``) quand elle est complète. Le paquet (exporter_eleve.py) est réécrit, chiffré avec le même mot de passe, à chaque réponse validée : fermé puis rouvert, il
reprend là où il en était (réponses, indices débloqués, question courante, fin de l'épreuve). Ce fichier est aussi celui que
l'élève rend. La note affichée à la fin n'est pas la note officielle : le professeur recorrige les rendus (verifier.py).
Un PDF d'``exporter_pdf.py`` s'ouvre aussi, par le ``.qcm`` qu'il embarque : la copie s'écrit alors à côté de lui, sous
« <PDF> [Nom Prénom].qcm » (``copie_du_pdf``), et c'est ce fichier que l'élève rend.
``--auto`` répond juste à toutes les questions, termine, enregistre et sort, sans fenêtre (vérification) ; ``--capture``
écrit l'image de la fenêtre puis sort.
"""

import argparse
import os
import sys
import tempfile
import time

from pathlib import Path

from qtpy6.QtCore import QByteArray, Qt, QTimer, Signal
from qtpy6.QtGui import QIcon, QPainter, QPixmap
from qtpy6.QtSvg import QSvgRenderer
from qtpy6.QtWidgets import QDialog, QFormLayout, QLabel, QLineEdit, QMainWindow

import codes
import horloge
from modele import GardeCopie, application, charger, colorer, sauver
from qtpy6.web import tactile
from voir import MotDePasseRequis, essayer, ouvrir, raison

DEMI_VIE = 10  # minutes : la barre d'un sujet sans durée annoncée est à moitié pleine au bout de ce temps


def duree(secondes, avec_secondes=True):
    """« 1 h 05 min 12 s » au-delà d'une heure, « 12 min 34 s » en deçà ; sans secondes pour un total, toujours en minutes rondes."""
    h, m, s = int(secondes) // 3600, int(secondes) // 60 % 60, int(secondes) % 60
    if avec_secondes:
        return f"{h} h {m:02d} min {s:02d} s" if h else f"{m} min {s:02d} s"
    if h:
        return f"{h} h {m:02d} min" if m else f"{h} h"
    return f"{m} min"


class Lecteur(QMainWindow):
    enregistree = Signal()  # la copie vient d'être réécrite : la page du navigateur (web/pyqt6) la range à son tour

    def __init__(self, chemin, paquet, mot_de_passe):
        super().__init__()
        self.chemin, self.paquet, self.mot_de_passe = chemin, paquet, mot_de_passe
        self.setWindowTitle(paquet.titre.replace("\n", " "))
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "associations" / "qcm.svg")))
        self.setCentralWidget(paquet)
        self.resize(paquet.size())
        for f in paquet.feuilles:
            f.changee.connect(self.enregistrer)
        paquet.finie.connect(self.enregistrer)  # « Rendre ma copie » confirmé : la fin est enregistrée même si tout était déjà fermé
        paquet.annotee.connect(self.enregistrer)
        paquet.noter(codes.professeur() is not None)  # la machine du professeur : il écrit la note et l'appréciation
        boutons = [paquet.prec_libre, paquet.suiv_libre] + ([paquet.precedent, paquet.suivant] if paquet.affichage == "question" else [])
        for b in boutons:  # après la connexion du paquet lui-même : la session enregistrée est celle d'après le clic
            b.clicked.connect(self.enregistrer)
        if paquet.fin is None:
            paquet.demarrer()
            self.minuteur = QTimer(self)
            self.minuteur.timeout.connect(self.chronometre)
            self.minuteur.start(1000)
            self.chronometre()

    def enregistrer(self):
        sauver(self.paquet, self.chemin, self.mot_de_passe)
        self.enregistree.emit()

    def closeEvent(self, evenement):
        """Un changement de réponse sans soumission ni validation n'est enregistré qu'ici ou en changeant d'écran."""
        self.enregistrer()
        super().closeEvent(evenement)

    def chronometre(self):
        """La barre de temps, et le délai des indices de la question où est l'élève ; seule une durée annoncée par le sujet
        met fin à l'épreuve, ou la date limite du code (``paquet.limite``), jugée à l'heure en ligne (``horloge``) : la copie
        est alors rendue d'office. Sans réseau, l'heure de l'ordinateur la remplace, et la copie le retient (``heure_locale``)."""
        ecoule = time.time() - self.paquet.debut
        total = 60 * (self.paquet.duree_minutes or 0)
        limite = self.paquet.limite  # posée par l'accueil, pas enregistrée : chaque ouverture redonne le code
        if limite is not None:
            avant_limite = limite.timestamp() - horloge.secondes()
            if not horloge.en_ligne():
                self.paquet.heure_locale = True
            if not total or avant_limite < total - ecoule:  # la limite tombe avant la fin de la durée : c'est elle qui compte
                total = ecoule + max(avant_limite, 0)
        reste = max(int(total - ecoule), 0)
        if self.paquet.tp:
            self.paquet.retenir(bool(total) and ecoule < 0.75 * total)
        if self.paquet.fin is not None:
            self.minuteur.stop()
        elif total and not reste:
            self.paquet.terminer()  # enregistré par ``finie``
        else:
            self.paquet.ecouler()
        barre = self.paquet.barre_temps
        if total:
            barre.setValue(round(100 * (total - reste) / total))
            colorer(barre, "rouge" if reste <= total / 5 else "bleu")
            titre = f"{duree(reste)} / {duree(total, False)}"
        else:  # rien ne s'arrête faute de durée annoncée : une échelle qui approche 100 % sans l'atteindre, plutôt qu'une
            barre.setValue(min(99, round(100 * (1 - 0.5 ** (ecoule / (60 * DEMI_VIE))))))  # barre pleine annonçant une fin
            colorer(barre, "bleu")
            titre = f"temps écoulé : {duree(ecoule)}"
        barre.setFormat(titre)
        self.setWindowTitle(f"{self.paquet.titre.replace(chr(10), ' ')} — {titre}")


class CodeRefuse(MotDePasseRequis):
    """Un code de classe qui n'ouvre pas le sujet, et pourquoi : faux, ou hors de ses dates."""

    def __init__(self, pourquoi):
        super().__init__(pourquoi)
        self.pourquoi = pourquoi


# l'œil d'un champ masqué, ouvert (montrer) ou barré (masquer) : dessiné ici, le navigateur n'a pas le thème d'icônes
OEIL = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" '
        'stroke-linecap="round"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>{}</svg>')


def icone_oeil(barre):
    pixmap = QPixmap(48, 48)
    pixmap.fill(Qt.GlobalColor.transparent)
    peintre = QPainter(pixmap)
    QSvgRenderer(QByteArray(OEIL.format('<path d="M3 3l18 18"/>' if barre else "").encode())).render(peintre)
    peintre.end()
    return QIcon(pixmap)


def champ_masque():
    """Un champ de code, masqué, avec l'œil qui le montre le temps qu'on le relise."""
    champ = QLineEdit()
    champ.setEchoMode(QLineEdit.EchoMode.Password)
    oeil = champ.addAction(icone_oeil(False), QLineEdit.ActionPosition.TrailingPosition)
    oeil.setToolTip("Afficher")

    def basculer():
        masque = champ.echoMode() == QLineEdit.EchoMode.Password
        champ.setEchoMode(QLineEdit.EchoMode.Normal if masque else QLineEdit.EchoMode.Password)
        oeil.setIcon(icone_oeil(masque))
        oeil.setToolTip("Masquer" if masque else "Afficher")
    oeil.triggered.connect(basculer)
    return champ


class Accueil(QDialog):
    """Le premier écran de l'élève, en natif comme dans le navigateur : son nom, son prénom et, si le sujet en demande un, le
    code de déverrouillage. Le sujet s'ouvre dès la construction (sans code, ou avec celui des sujets d'entraînement), pour
    porter son titre et ne montrer le champ du code que s'il en faut un ; un code refusé le redemande, une autre erreur
    (fichier absent, illisible, corrompu : ``voir.raison``) est dite et n'a pas de code qui la débloque. Pas de bouton : Entrée
    passe au champ vide suivant et, tout rempli, commence ; un code de classe (``codes``) commence dès qu'il est complet. Un
    sujet exporté avec ses listes de classes ne s'ouvre que par le code d'une classe, dans ses dates, et pour un élève de
    cette classe, reconnu malgré ses fautes de frappe et nommé comme sur la liste ; son code personnel, facultatif, doit
    alors être le sien (``empreinte`` : la copie la garde, et le lecteur web n'en accepte plus d'autre sous ce nom). Un code
    sans classe (``codes.SANS_CLASSE``) laisse entrer tout nom, sans liste ; un code ne sert ni avant son départ ni après
    son échéance, qu'il confie au lecteur (``paquet.limite``), qui rend la copie à l'heure dite, et sa durée remplace celle
    du sujet. La boîte ne bloque
    pas (``open``, pas ``exec`` : dans le navigateur, Qt n'a pas de boucle d'événements imbriquée) : ``accepted`` livre
    ``paquet`` (avec son ``eleve``, « Nom Prénom ») et ``mot`` (le mot de passe qui l'a ouvert, celui de la copie)."""

    def __init__(self, chemin, mot_de_passe=None, eleve=""):
        super().__init__()
        self.chemin, self.paquet, self.mot = chemin, None, None
        self.classe = self.inscrits = None  # la classe du code qui a ouvert le sujet, et sa liste (aucune : code sans classe)
        self.limite = None  # l'échéance de ce code (UTC), que le lecteur fait respecter
        self.duree = None  # la durée de l'épreuve que ce code donne (minutes), à la place de celle du sujet
        self.tp = False  # un code de TP : rien ne se soumet avant les 3/4 du temps (``Paquet.retenir``)
        self.bloque = False  # une erreur qu'aucun code ne corrige
        self.empreinte = ""  # celle du code personnel donné (codes.empreinte), ou rien
        self.setWindowTitle("SmartTeacher")
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "associations" / "qcm.svg")))
        # ni bouton de fermeture ni d'agrandissement : dans le navigateur, Qt dessine lui-même la barre de titre, et fermer
        # l'accueil laisserait un canevas vide
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.CustomizeWindowHint | Qt.WindowType.WindowTitleHint)
        self.setProperty("copiable", True)  # GardeCopie laisse le menu contextuel : le code se colle
        self.nom, self.prenom, self.personnel, self.code = QLineEdit(), QLineEdit(), champ_masque(), champ_masque()
        # sans eleve, l'identité que SmartOS exporte dans la session (identite-eleve.sh : sur le compte élève, lue dans son
        # coffre) : ici seulement incomplète, l'accueillir() d'une identité complète saute la boîte ; l'élève complète le reste
        nom, prenom = (eleve.split(" ", 1) + [""])[:2] if eleve else (os.environ.get("UTILISATEUR_NOM", ""),
                                                                       os.environ.get("UTILISATEUR_PRENOM", ""))
        self.nom.setText(nom)
        self.prenom.setText(prenom)
        self.code.setText(mot_de_passe or "")  # le code d'un lien (``?code=`` du lecteur web) : refuser() le réessaie
        self.code.textChanged.connect(lambda texte: codes.lire_code(texte) and self.commencer())
        self.message = QLabel()
        self.message.setWordWrap(True)
        self.formulaire = QFormLayout(self)
        self.formulaire.addRow("Nom", self.nom)
        self.formulaire.addRow("Prénom", self.prenom)
        self.formulaire.addRow("Code personnel (facultatif)", self.personnel)
        self.formulaire.addRow("Code de déverrouillage", self.code)
        self.formulaire.addRow(self.message)
        self.setMinimumWidth(360)
        self.ouvrir(mot_de_passe)

    def ouvrir(self, mot_de_passe):
        """Un essai d'ouverture du sujet ; le champ du code n'est là que tant qu'il n'est pas ouvert. Seul un code de classe
        l'ouvre (``deverrouiller``), sauf sur la machine du professeur, où son mot de passe l'ouvre sans code ni liste."""
        try:
            if mot_de_passe:
                self.deverrouiller(mot_de_passe)
            else:  # un fichier en clair, ou la machine du professeur : son mot de passe l'ouvre, sans liste
                self.paquet, self.mot = essayer(self.chemin)
        except MotDePasseRequis as erreur:
            self.paquet = None
            self.dire(erreur.pourquoi if isinstance(erreur, CodeRefuse) else "Ce sujet demande un code de déverrouillage.")
        except Exception as erreur:  # noqa: BLE001 - rien d'autre que le code ne se corrige ici : on le dit
            self.dire(raison(self.chemin, erreur))
            self.bloque = True
        else:
            self.setWindowTitle(self.paquet.titre.replace("\n", " "))
            self.dire("")
        self.formulaire.setRowVisible(self.code, self.paquet is None)
        self.formulaire.setRowVisible(self.personnel, self.paquet is None or self.inscrits is not None)
        self.adjustSize()
        self.focaliser()

    def deverrouiller(self, texte):
        """Ouvre le sujet par le code de classe ``texte``, écrit juste ou à quelques lettres près (``codes.corrections`` :
        plusieurs lectures possibles s'essaient toutes sur le fichier, 0,3 s chacune), ou lève ``CodeRefuse``. Le fichier
        juge d'abord le code (sans contrôle, toute phrase des listes se lit), ses dates ensuite : un refus pour la date ne
        vient ainsi que d'un vrai code."""
        horloge.demarrer()  # l'heure en ligne, avant de juger une date
        exact = codes.lire_code(texte)
        pourquoi = "Code incorrect."
        lus = [exact] if exact else filter(None, map(codes.lire_code, codes.corrections(texte)))
        for code in (c for lu in lus for c in (lu, codes.en_tp(lu))):
            try:
                paquet, mot = essayer(self.chemin, code.cle)
            except MotDePasseRequis:
                continue
            classes = sorted(paquet.inscrits)
            if code.classe != codes.SANS_CLASSE and code.classe >= len(classes):  # une classe que le sujet n'a pas
                continue
            if codes.refus(code):
                pourquoi = codes.refus(code)
                break
            self.paquet, self.mot = paquet, mot
            self.limite, self.duree, self.tp = code.echeance, code.duree, code.tp
            self.classe = None if code.classe == codes.SANS_CLASSE else classes[code.classe]
            self.inscrits = self.classe and paquet.inscrits[self.classe]
            return
        raise CodeRefuse(pourquoi)

    def focaliser(self):
        """Le curseur dans le champ à remplir : le code s'il en faut un, sinon le premier vide de nom et prénom."""
        vide = next((c for c in (self.nom, self.prenom) if not c.text().strip()), self.nom)
        (self.code if self.paquet is None else vide).setFocus()

    def showEvent(self, evenement):
        """Le focus reposé à l'affichage : dans le navigateur, celui posé à la construction est perdu et Qt le donne au
        dernier champ."""
        super().showEvent(evenement)
        self.focaliser()

    def keyPressEvent(self, evenement):
        """Entrée passe au champ suivant encore vide (dans l'ordre du formulaire, en revenant au début) ; quand tous sont
        remplis, elle commence."""
        if evenement.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            champs = [self.nom, self.prenom] + ([self.code] if self.paquet is None else [])
            ici = champs.index(self.focusWidget()) + 1 if self.focusWidget() in champs else 0
            vide = next((c for c in champs[ici:] + champs[:ici] if not c.text().strip()), None)
            if vide is not None:
                vide.setFocus()
            else:
                self.commencer()
            return
        super().keyPressEvent(evenement)

    def dire(self, texte):
        """Le message sous les champs ; sa ligne disparaît quand il n'y a rien à dire."""
        self.message.setText(texte)
        self.formulaire.setRowVisible(self.message, bool(texte))

    def commencer(self):
        if self.bloque:
            return
        if self.paquet is None:
            self.ouvrir(self.code.text())
            if self.paquet is None:
                return
        nom, prenom = self.nom.text().strip(), self.prenom.text().strip()
        if not (nom and prenom):
            self.dire("Écrivez votre nom et votre prénom.")
            return
        if self.inscrits is not None:
            inscrit = codes.reconnaitre(nom, prenom, self.inscrits)
            if inscrit is None:
                self.dire(f"« {nom} {prenom} » n'est pas sur la liste de la classe {self.classe} : vérifiez l'orthographe, et le code.")
                return
            nom, prenom = inscrit[:2]
        personnel = self.personnel.text().strip()
        if personnel and self.inscrits is None:
            self.dire("Ce sujet n'a pas de code personnel : laissez ce champ vide.")
            return
        if personnel and not codes.verifier_personnel(self.mot, inscrit, personnel):
            self.dire(f"Ce code personnel n'est pas celui de {nom} {prenom}.")
            return
        self.empreinte = codes.empreinte(personnel) if personnel else ""
        self.paquet = self.paquet.nommer(f"{nom} {prenom}")
        self.paquet.empreinte, self.paquet.limite, self.paquet.tp = self.empreinte, self.limite, self.tp
        if self.duree:
            self.paquet.duree_minutes = self.duree
        self.accept()

    def refuser(self, texte):
        """La boîte rouverte sur le sujet, avec la raison : le professeur refuse ce nom (lecteur web, ``pont_qt``)."""
        self.ouvrir(self.code.text() or None)
        self.dire(texte)
        self.open()


def accueillir(chemin, apres, mot_de_passe=None, eleve=""):
    """L'accueil de l'élève, puis ``apres(paquet, mot)`` : tout de suite si l'élève est déjà nommé (``--eleve``,
    ``?eleve=``, ou l'identité que SmartOS exporte dans la session) et que le sujet s'ouvre sans lui demander de code ni
    le chercher sur une liste (un code de classe, même venu d'un lien), sinon quand il a rempli la boîte. Rend la boîte, à
    garder tant qu'elle est ouverte (``None`` si elle a été sautée)."""
    if not eleve:
        nom, prenom = os.environ.get("UTILISATEUR_NOM", "").strip(), os.environ.get("UTILISATEUR_PRENOM", "").strip()
        if nom and prenom:
            eleve = f"{nom} {prenom}"
    accueil = Accueil(chemin, mot_de_passe, eleve)
    if eleve and accueil.paquet is not None and accueil.inscrits is None:  # un nom à vérifier sur la liste passe par la boîte
        apres(accueil.paquet.nommer(eleve), accueil.mot)
        return None
    accueil.accepted.connect(lambda: apres(accueil.paquet, accueil.mot))
    accueil.open()
    return accueil


def sujet_du_pdf(pdf, dossier):
    """Le ``.qcm`` qu'embarque un PDF d'``exporter_pdf.py`` (``sujet.piece_jointe``), écrit dans ``dossier`` : l'accueil
    ouvre un fichier, et le relit à chaque code essayé."""
    from sujet import piece_jointe  # noqa: PLC0415 - ici seulement : le lecteur web n'embarque pas sujet.py
    chemin = Path(dossier) / "sujet.qcm"
    chemin.write_bytes(piece_jointe(pdf))
    return chemin


def copie_du_pdf(pdf, paquet, mot):
    """``(chemin, paquet)`` de la copie d'un sujet ouvert depuis un PDF : à côté de lui, « <PDF> [Nom Prénom].qcm » (demande
    de l'utilisateur, 28/09/2026, le même nom que sur Dropbox, ``codes.chemin_copie``), et reprise si l'élève l'a déjà
    commencée : rouvrir le PDF ne la remet pas à zéro. Ce que l'accueil pose sans l'enregistrer (limite, TP) passe à la reprise."""
    copie = pdf.with_name(codes.nom_de_fichier(f"{pdf.stem} [{paquet.eleve}]") + ".qcm")
    if copie.exists():
        reprise = charger(copie, mot)
        reprise.limite, reprise.tp = paquet.limite, paquet.tp
        paquet = reprise
    return copie, paquet


def lancer(chemin, mot_de_passe=None, eleve="", pdf=None):
    """Sans accueil : le lecteur d'un sujet qui s'ouvre sans rien demander (``--auto``, ``--capture``), ou ``SystemExit``."""
    paquet, mot = ouvrir(chemin, mot_de_passe, interactif=False)
    return Lecteur(*copie_du_pdf(pdf, paquet.nommer(eleve), mot) if pdf else (chemin, paquet.nommer(eleve)), mot)


def main():
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujet")
    analyseur.add_argument("--mot-de-passe")
    analyseur.add_argument("--eleve", default="", help="« Nom Prénom » : l'accueil est sauté si le sujet s'ouvre sans code")
    analyseur.add_argument("--auto", action="store_true", help="répond juste, enregistre et sort, sans fenêtre")
    analyseur.add_argument("--capture", help="écrit l'image de la fenêtre dans ce fichier, puis sort")
    mode = analyseur.add_mutually_exclusive_group()
    mode.add_argument("--tactile", action="store_true", help="les cibles d'un écran au doigt, même sans écran tactile détecté")
    mode.add_argument("--souris", action="store_true", help="les cibles de la souris, même sur un écran tactile (pour comparer)")
    a = analyseur.parse_args()
    app = application()
    if a.tactile or (not a.souris and tactile.detecte()):
        tactile.activer(app)
    GardeCopie(app)  # vit autant que l'application (son parent)
    pdf = Path(a.sujet) if a.sujet.lower().endswith(".pdf") else None
    extrait = tempfile.TemporaryDirectory()  # le sujet tiré du PDF, effacé à la sortie
    sujet = sujet_du_pdf(pdf, extrait.name) if pdf else a.sujet
    if a.auto:
        lecteur = lancer(sujet, a.mot_de_passe, a.eleve, pdf)
        paquet = lecteur.paquet
        for f in paquet.feuilles:
            f.demarrer()
            f.saisie = f.juste()
            f.soumettre()
        paquet.terminer()
        lecteur.enregistrer()
        obtenus, corriges, attente = paquet.resultat()
        print(f"{obtenus:g} / {corriges:g}" + (f" (+ {attente:g} à corriger)" if attente else ""))
        return 0
    if a.capture:
        lecteur = lancer(sujet, a.mot_de_passe, a.eleve, pdf)
        lecteur.show()
        for _ in range(3):
            app.processEvents()
        lecteur.grab().save(a.capture)
        return 0
    vivants = []  # l'accueil puis le lecteur : des références, sans quoi Python les détruirait avant ``exec``

    def montrer(paquet, mot):
        vivants.append(Lecteur(*copie_du_pdf(pdf, paquet, mot) if pdf else (sujet, paquet), mot))
        vivants[-1].show()

    vivants.append(accueillir(sujet, montrer, a.mot_de_passe, a.eleve))
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
