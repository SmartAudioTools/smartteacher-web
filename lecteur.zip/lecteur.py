#!/usr/bin/env python3
"""Lit un sujet et y répond : l'application de l'élève.

    python lecteur.py SUJET.qcm [--mot-de-passe MOT] [--eleve "Nom Prénom"] [--auto] [--capture IMAGE.png]

L'élève commence par la boîte d'accueil (``Accueil``) : son nom, son prénom et, si le sujet en demande un, le code de
déverrouillage ; la même boîte, dans le canevas, ouvre l'épreuve dans le navigateur (web/pyqt6/pont_qt.py). ``--eleve`` la
saute quand le sujet s'ouvre sans code (la sonde fait de même par ``?eleve=``). Le paquet (exporter_eleve.py) est réécrit, chiffré avec le même mot de passe, à chaque réponse validée : fermé puis rouvert, il
reprend là où il en était (réponses, indices débloqués, question courante, fin de l'épreuve). Ce fichier est aussi celui que
l'élève rend. La note affichée à la fin n'est pas la note officielle : le professeur recorrige les rendus (verifier.py).
``--auto`` répond juste à toutes les questions, termine, enregistre et sort, sans fenêtre (vérification) ; ``--capture``
écrit l'image de la fenêtre puis sort.
"""

import argparse
import os
import sys
import time

from pathlib import Path

from qtpy6.QtCore import Qt, QTimer, Signal
from qtpy6.QtGui import QIcon
from qtpy6.QtWidgets import QDialog, QFormLayout, QLabel, QLineEdit, QMainWindow

import codes
from modele import GardeCopie, application, colorer, sauver
from qtpy6web import tactile
from voir import MotDePasseRequis, essayer, ouvrir, raison

DEMI_VIE = 10  # minutes : la barre d'un sujet sans durée annoncée est à moitié pleine au bout de ce temps


def duree(secondes, avec_secondes=True):
    """« 1 h 05 min 12 s » au-delà d'une heure, « 12 min 34 s » en deçà ; sans secondes pour un total, toujours en minutes rondes."""
    h, m, s = int(secondes) // 3600, int(secondes) // 60 % 60, int(secondes) % 60
    if avec_secondes:
        return f"{h} h {m:02d} min {s:02d} s" if h else f"{m} min {s:02d} s"
    if h:
        return f"{h} h {m:02d} min" if m else f"{h} h"
    return f"{m} min"


class Lecteur(QMainWindow):
    enregistree = Signal()  # la copie vient d'être réécrite : la page du navigateur (web/pyqt6) la range à son tour

    def __init__(self, chemin, paquet, mot_de_passe):
        super().__init__()
        self.chemin, self.paquet, self.mot_de_passe = chemin, paquet, mot_de_passe
        self.setWindowTitle(paquet.titre.replace("\n", " "))
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "associations" / "qcm.svg")))
        self.setCentralWidget(paquet)
        self.resize(paquet.size())
        for f in paquet.feuilles:
            f.changee.connect(self.enregistrer)
        paquet.finie.connect(self.enregistrer)  # « Rendre ma copie » confirmé : la fin est enregistrée même si tout était déjà fermé
        boutons = [paquet.prec_libre, paquet.suiv_libre] + ([paquet.precedent, paquet.suivant] if paquet.affichage == "question" else [])
        for b in boutons:  # après la connexion du paquet lui-même : la session enregistrée est celle d'après le clic
            b.clicked.connect(self.enregistrer)
        if paquet.fin is None:
            paquet.demarrer()
            self.minuteur = QTimer(self)
            self.minuteur.timeout.connect(self.chronometre)
            self.minuteur.start(1000)
            self.chronometre()

    def enregistrer(self):
        sauver(self.paquet, self.chemin, self.mot_de_passe)
        self.enregistree.emit()

    def closeEvent(self, evenement):
        """Un changement de réponse sans soumission ni validation n'est enregistré qu'ici ou en changeant d'écran."""
        self.enregistrer()
        super().closeEvent(evenement)

    def chronometre(self):
        """La barre de temps ; seule une durée annoncée par le sujet met fin à l'épreuve."""
        ecoule = time.time() - self.paquet.debut
        total = 60 * (self.paquet.duree_minutes or 0)
        reste = max(int(total - ecoule), 0)
        if self.paquet.fin is not None:
            self.minuteur.stop()
        elif total and not reste:
            self.paquet.terminer()  # enregistré par ``finie``
        barre = self.paquet.barre_temps
        if total:
            barre.setValue(round(100 * (total - reste) / total))
            colorer(barre, "rouge" if reste <= total / 5 else "bleu")
            titre = f"{duree(reste)} / {duree(total, False)}"
        else:  # rien ne s'arrête faute de durée annoncée : une échelle qui approche 100 % sans l'atteindre, plutôt qu'une
            barre.setValue(min(99, round(100 * (1 - 0.5 ** (ecoule / (60 * DEMI_VIE))))))  # barre pleine annonçant une fin
            colorer(barre, "bleu")
            titre = f"temps écoulé : {duree(ecoule)}"
        barre.setFormat(titre)
        self.setWindowTitle(f"{self.paquet.titre.replace(chr(10), ' ')} — {titre}")


class Accueil(QDialog):
    """Le premier écran de l'élève, en natif comme dans le navigateur : son nom, son prénom et, si le sujet en demande un, le
    code de déverrouillage. Le sujet s'ouvre dès la construction (sans code, ou avec celui des sujets d'entraînement), pour
    porter son titre et ne montrer le champ du code que s'il en faut un ; un code refusé le redemande, une autre erreur
    (fichier absent, illisible, corrompu : ``voir.raison``) est dite et n'a pas de code qui la débloque. Pas de bouton : Entrée
    passe au champ vide suivant et, tout rempli, commence ; un code de classe (``codes``) commence dès qu'il est complet. Un
    sujet exporté avec ses listes de classes ne s'ouvre que par le code d'une classe, dans ses dates, et pour un élève de
    cette classe, reconnu malgré ses fautes de frappe et nommé comme sur la liste ; son code personnel, facultatif, doit
    alors être le sien (``empreinte`` : ce que le lecteur web envoie au professeur avec la copie). La boîte ne bloque
    pas (``open``, pas ``exec`` : dans le navigateur, Qt n'a pas de boucle d'événements imbriquée) : ``accepted`` livre
    ``paquet`` (avec son ``eleve``, « Nom Prénom ») et ``mot`` (le mot de passe qui l'a ouvert, celui de la copie)."""

    def __init__(self, chemin, mot_de_passe=None, eleve=""):
        super().__init__()
        self.chemin, self.paquet, self.mot = chemin, None, None
        self.classe = self.inscrits = None  # la classe du code qui a ouvert le sujet, et sa liste
        self.bloque = False  # une erreur qu'aucun code ne corrige
        self.empreinte = ""  # celle du code personnel donné (codes.empreinte), ou rien
        self.setWindowTitle("SmartTeacher")
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "associations" / "qcm.svg")))
        # ni bouton de fermeture ni d'agrandissement : dans le navigateur, Qt dessine lui-même la barre de titre, et fermer
        # l'accueil laisserait un canevas vide
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.CustomizeWindowHint | Qt.WindowType.WindowTitleHint)
        self.nom, self.prenom, self.personnel, self.code = QLineEdit(), QLineEdit(), QLineEdit(), QLineEdit()
        # sans --eleve, l'identité que SmartOS exporte dans la session (identite-eleve.sh : sur le compte élève, lue dans son
        # coffre) ; l'élève la voit et peut la corriger
        nom, prenom = (eleve.split(" ", 1) + [""])[:2] if eleve else (os.environ.get("UTILISATEUR_NOM", ""),
                                                                       os.environ.get("UTILISATEUR_PRENOM", ""))
        self.nom.setText(nom)
        self.prenom.setText(prenom)
        self.code.setEchoMode(QLineEdit.EchoMode.Password)
        self.personnel.setEchoMode(QLineEdit.EchoMode.Password)
        self.code.textChanged.connect(lambda texte: codes.lire_code(texte) and self.commencer())
        self.message = QLabel()
        self.message.setWordWrap(True)
        self.formulaire = QFormLayout(self)
        self.formulaire.addRow("Nom", self.nom)
        self.formulaire.addRow("Prénom", self.prenom)
        self.formulaire.addRow("Code personnel (facultatif)", self.personnel)
        self.formulaire.addRow("Code de déverrouillage", self.code)
        self.formulaire.addRow(self.message)
        self.setMinimumWidth(360)
        self.ouvrir(mot_de_passe)

    def ouvrir(self, mot_de_passe):
        """Un essai d'ouverture du sujet ; le champ du code n'est là que tant qu'il n'est pas ouvert. Un code de classe hors
        de ses dates est refusé avant tout déchiffrement ; la clé d'un sujet à listes, tapée telle quelle, n'ouvre rien (sur
        la machine du professeur, le mot de passe professeur l'ouvre sans code, et sans liste)."""
        code = codes.lire_code(mot_de_passe) if mot_de_passe else None
        pourquoi = code and codes.refus(code)
        try:
            if pourquoi:
                raise MotDePasseRequis
            self.paquet, self.mot = essayer(self.chemin, code.cle if code else mot_de_passe)
            classes = sorted(self.paquet.inscrits)
            if code:
                self.classe, self.inscrits = classes[code.classe], self.paquet.inscrits[classes[code.classe]]
            elif classes and mot_de_passe:
                raise MotDePasseRequis
        except (MotDePasseRequis, IndexError):  # IndexError : le rang d'une classe que le sujet n'a pas
            self.paquet = None
            self.dire(pourquoi or ("Code incorrect." if mot_de_passe else "Ce sujet demande un code de déverrouillage."))
        except Exception as erreur:  # noqa: BLE001 - rien d'autre que le code ne se corrige ici : on le dit
            self.dire(raison(self.chemin, erreur))
            self.bloque = True
        else:
            self.setWindowTitle(self.paquet.titre.replace("\n", " "))
            self.dire("")
        self.formulaire.setRowVisible(self.code, self.paquet is None)
        self.formulaire.setRowVisible(self.personnel, self.paquet is None or self.inscrits is not None)
        self.adjustSize()
        vide = next((c for c in (self.nom, self.prenom) if not c.text().strip()), self.nom)
        (self.code if self.paquet is None else vide).setFocus()

    def keyPressEvent(self, evenement):
        """Entrée passe au champ suivant encore vide (dans l'ordre du formulaire, en revenant au début) ; quand tous sont
        remplis, elle commence."""
        if evenement.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            champs = [self.nom, self.prenom] + ([self.code] if self.paquet is None else [])
            ici = champs.index(self.focusWidget()) + 1 if self.focusWidget() in champs else 0
            vide = next((c for c in champs[ici:] + champs[:ici] if not c.text().strip()), None)
            if vide is not None:
                vide.setFocus()
            else:
                self.commencer()
            return
        super().keyPressEvent(evenement)

    def dire(self, texte):
        """Le message sous les champs ; sa ligne disparaît quand il n'y a rien à dire."""
        self.message.setText(texte)
        self.formulaire.setRowVisible(self.message, bool(texte))

    def commencer(self):
        if self.bloque:
            return
        if self.paquet is None:
            self.ouvrir(self.code.text())
            if self.paquet is None:
                return
        nom, prenom = self.nom.text().strip(), self.prenom.text().strip()
        if not (nom and prenom):
            self.dire("Écrivez votre nom et votre prénom.")
            return
        if self.inscrits is not None:
            inscrit = codes.reconnaitre(nom, prenom, self.inscrits)
            if inscrit is None:
                self.dire(f"« {nom} {prenom} » n'est pas sur la liste de la classe {self.classe} : vérifiez l'orthographe, et le code.")
                return
            nom, prenom = inscrit[:2]
        personnel = self.personnel.text().strip()
        if personnel and self.inscrits is None:
            self.dire("Ce sujet n'a pas de code personnel : laissez ce champ vide.")
            return
        if personnel and not codes.verifier_personnel(self.mot, inscrit, personnel):
            self.dire(f"Ce code personnel n'est pas celui de {nom} {prenom}.")
            return
        self.empreinte = codes.empreinte(personnel) if personnel else ""
        self.paquet = self.paquet.nommer(f"{nom} {prenom}")
        self.accept()

    def refuser(self, texte):
        """La boîte rouverte sur le sujet, avec la raison : le professeur refuse ce nom (lecteur web, ``pont_qt``)."""
        self.ouvrir(self.code.text() or None)
        self.dire(texte)
        self.open()


def accueillir(chemin, apres, mot_de_passe=None, eleve=""):
    """L'accueil de l'élève, puis ``apres(paquet, mot)`` : tout de suite si l'élève est déjà nommé (``--eleve``,
    ``?eleve=``) et que le sujet s'ouvre sans lui demander de code, sinon quand il a rempli la boîte. Rend la boîte, à garder
    tant qu'elle est ouverte (``None`` si elle a été sautée)."""
    accueil = Accueil(chemin, mot_de_passe, eleve)
    if eleve and accueil.paquet is not None:
        apres(accueil.paquet.nommer(eleve), accueil.mot)
        return None
    accueil.accepted.connect(lambda: apres(accueil.paquet, accueil.mot))
    accueil.open()
    return accueil


def lancer(chemin, mot_de_passe=None, eleve=""):
    """Sans accueil : le lecteur d'un sujet qui s'ouvre sans rien demander (``--auto``, ``--capture``), ou ``SystemExit``."""
    paquet, mot = ouvrir(chemin, mot_de_passe, interactif=False)
    return Lecteur(chemin, paquet.nommer(eleve), mot)


def main():
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujet")
    analyseur.add_argument("--mot-de-passe")
    analyseur.add_argument("--eleve", default="", help="« Nom Prénom » : l'accueil est sauté si le sujet s'ouvre sans code")
    analyseur.add_argument("--auto", action="store_true", help="répond juste, enregistre et sort, sans fenêtre")
    analyseur.add_argument("--capture", help="écrit l'image de la fenêtre dans ce fichier, puis sort")
    analyseur.add_argument("--tactile", action="store_true", help="les cibles d'un écran au doigt (ce que le navigateur détecte seul)")
    a = analyseur.parse_args()
    app = application()
    if a.tactile:
        tactile.activer(app)
    GardeCopie(app)  # vit autant que l'application (son parent)
    if a.auto:
        lecteur = lancer(a.sujet, a.mot_de_passe, a.eleve)
        paquet = lecteur.paquet
        for f in paquet.feuilles:
            f.demarrer()
            f.saisie = f.juste()
            f.soumettre()
        paquet.terminer()
        lecteur.enregistrer()
        obtenus, corriges, attente = paquet.resultat()
        print(f"{obtenus:g} / {corriges:g}" + (f" (+ {attente:g} à corriger)" if attente else ""))
        return 0
    if a.capture:
        lecteur = lancer(a.sujet, a.mot_de_passe, a.eleve)
        lecteur.show()
        for _ in range(3):
            app.processEvents()
        lecteur.grab().save(a.capture)
        return 0
    vivants = []  # l'accueil puis le lecteur : des références, sans quoi Python les détruirait avant ``exec``

    def montrer(paquet, mot):
        vivants.append(Lecteur(a.sujet, paquet, mot))
        vivants[-1].show()

    vivants.append(accueillir(a.sujet, montrer, a.mot_de_passe, a.eleve))
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
