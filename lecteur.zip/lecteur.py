#!/usr/bin/env python3
"""Lit un sujet et y répond : l'application de l'élève.

    python lecteur.py SUJET.qcm|SUJET.pdf|SUJET.json|BILAN.report [--mot-de-passe MOT] [--eleve "Nom Prénom"] [--auto] [--capture IMAGE.png]

L'élève commence par la boîte d'accueil (``Accueil``) : son nom, son prénom et, si le sujet en demande un, le code de
déverrouillage ; la même boîte, dans le canevas, ouvre l'épreuve dans le navigateur (web/pyqt6/pont_qt.py). ``--eleve`` la
saute quand le sujet s'ouvre sans code (la sonde fait de même par ``?eleve=``), tout comme l'identité que SmartOS exporte
dans la session (``UTILISATEUR_NOM``/``UTILISATEUR_PRENOM``) quand elle est complète. Le paquet (exporter_eleve.py) est réécrit, chiffré avec le même mot de passe, à chaque réponse validée : fermé puis rouvert, il
reprend là où il en était (réponses, indices débloqués, question courante, fin de l'épreuve). Ce fichier est aussi celui que
l'élève rend. La note affichée à la fin n'est pas la note officielle : le professeur recorrige les rendus (verifier.py).
Chez l'élève, le sujet devient ainsi sa copie : il ne peut pas refaire l'épreuve plus tard (l'utilisateur, 30/09/2026). Sur la
machine du professeur, qui lit ou essaie le sujet, rien ne s'écrit (``copie`` ; même jour, après un TP01 changé en copie par
un simple double clic). Un PDF d'``exporter_pdf.py`` s'ouvre par le ``.qcm`` qu'il embarque, sa copie à côté de lui sous
« <sujet> [Nom Prénom].qcm ». Un sujet ``.json`` (``sujets/``) s'ouvre par un ``.qcm`` exporté dans un dossier temporaire
(``exporter_eleve.qcm_de``), sur la machine du professeur. En ligne, le sujet déposé dans Dropbox ne change pas non plus : la page n'écrit que des
copies, « <sujet> [<élève>]….qcm » (``codes.est_copie``, ``web/pyqt6/dropbox.js``).
``--auto`` répond juste à toutes les questions, termine, enregistre et sort, sans fenêtre (vérification) ; ``--capture``
écrit l'image de la fenêtre puis sort.
"""

import argparse
import base64
import json
import math
import os
import re
import sys
import tempfile
import time

from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from qtpy6.QtCore import QByteArray, QStandardPaths, Qt, QTimer, Signal
from qtpy6.QtGui import QIcon, QPainter, QPixmap
from qtpy6.QtSvg import QSvgRenderer
from qtpy6.QtWidgets import (QDialog, QFormLayout, QLabel, QLineEdit, QMainWindow, QPushButton, QVBoxLayout,
                             QWidget)

import amenagements_lecteur
import bilans_widget
import codes
import echeances
import horloge
import noyau
import serializejson
from modele import GardeCopie, SaisieConversion, application, charger, colorer, differee, sauver
from qtpy6 import erreurs, loupe, voix
from qtpy6.web import tactile
from voir import MotDePasseRequis, ouvrir, raison
from voir import essayer as essayer_ecran

DEMI_VIE = 10  # minutes : la barre d'un sujet sans durée annoncée est à moitié pleine au bout de ce temps
SANCTION = 60  # secondes d'écran noir après le retour de l'élève, dans une épreuve sous ``anti_triche``
RECHARGE = 60  # s : la page rechargée par le zoom (``zoomer``), le temps que l'élève revalide l'accueil, n'est pas une sortie
GRACE = 5000  # ms : une sortie plus brève ne compte pas, ni une copie rouverte dans ce délai (la page rechargée ; l'utilisateur, 12/10/2026)
DIFFERE = 250  # ms : les demandes d'enregistrement plus rapprochées n'en font qu'un (``Lecteur.differe``)
ESSAI_NOMME = re.compile(r" \(\d+ème essai\)$")  # la fin du nom d'une copie d'essai suivant (``codes.essai``)
RIDEAU = ("Vous avez quitté l'épreuve : autre onglet, autre application, ou page fermée.\n\n{}\n\n"
          "Le temps de l'épreuve continue de s'écouler.")
PLEIN_ECRAN = "Cette épreuve se passe en plein écran."
RETOUR = (f"Vous avez quitté l'épreuve.\n\nRevenez-y en plein écran dans les {GRACE // 1000} secondes : au-delà, l'écran "
          f"restera noir {SANCTION} s.")  # la sortie encore sans sanction (``Lecteur.sortir``)
# secondes : le fichier d'échéances du professeur est relu pendant l'épreuve à cette période, et toujours à l'échéance, avant
# de rendre la copie (``Lecteur.relire``) ; cette relecture d'avant la clôture attend sa réponse au plus ATTENTE_RELECTURE
RELECTURE, ATTENTE_RELECTURE = 60, 10
DELAI_AVANCEE = 120  # secondes : une échéance avancée à une heure passée, ou trop proche, laisse encore ce temps pour rendre
SANS_LIEN = "Ouvrez ce sujet depuis le tableau de bord de votre classe, ou par le lien donné par le professeur."
APPROCHE = 30  # minutes : un code dont le départ est si proche ouvre l'accueil, « Commencer » grisé jusqu'à l'heure dite


def duree(secondes, avec_secondes=True):
    """« 1 h 05 min 12 s » au-delà d'une heure, « 12 min 34 s » en deçà ; sans secondes pour un total, toujours en minutes rondes."""
    h, m, s = int(secondes) // 3600, int(secondes) // 60 % 60, int(secondes) % 60
    if avec_secondes:
        return f"{h} h {m:02d} min {s:02d} s" if h else f"{m} min {s:02d} s"
    if h:
        return f"{h} h {m:02d} min" if m else f"{h} h"
    return f"{m} min"


def emplacements_du_cours(chemin, profondeur):
    """Où chercher un PDF du cours (``Paquet.cours``), depuis le dossier du .qcm : à ``chemin``, comme le professeur les range
    sur son disque et dans son Dropbox, sinon sous son seul nom dans ce dossier puis dans chacun de ses ``profondeur`` parents
    (un sujet copié ailleurs, le cours rangé plus haut)."""
    nom = Path(chemin).name
    return [chemin] + ["../" * k + nom for k in range(profondeur + 1)]


def cours_a_cote(qcm, chemin):
    """Les octets d'un PDF du cours au premier de ses ``emplacements_du_cours``, None s'il n'est nulle part."""
    dossier = Path(qcm).resolve().parent
    for c in emplacements_du_cours(chemin, len(dossier.parents)):
        if (pdf := dossier / c).is_file():
            return pdf.read_bytes()
    return None


def bilan_a_cote(qcm, eleve: str) -> Path | None:
    """Le bilan de l'année de ``eleve`` (``bilans.py fichiers``) dans le « Bilans » du plus proche dossier parent de la copie :
    celui de son niveau dans le Dropbox du professeur (« Seconde/Bilans »), où sont aussi les copies ; None s'il n'y en a pas."""
    if not eleve:
        return None
    nom = bilans_widget.nom_du_fichier(eleve)
    return next((b for d in Path(qcm).resolve().parents if (b := d / "Bilans" / nom).is_file()), None)


def depart_du_bilan(chemin, cle: str | None, maintenant: float | None = None
                    ) -> tuple[dict[tuple[str, ...], dict[str, Any]], float | None]:
    """D'où composer le questionnaire « Réviser » d'un élève : l'état de ses notions dans son bilan ``chemin``
    (``bilan_a_cote``, ou lu chez le professeur par le lecteur web), en clair ou ouvert par ``cle`` (``Bilan.etats`` à
    ``maintenant``), et l'instant de son calcul (``notions_le``), que les réponses d'après s'y ajoutent
    (``Paquet.nouvel_essai_suivant``) ; ``({}, None)`` sans bilan lisible : rien n'est vu."""
    bilan = chemin and bilans_widget.ouvrir_bilan(str(chemin), cle)
    if not bilan:
        return {}, None
    depart = bilan.etats(maintenant), bilan.notions_le
    bilan.deleteLater()
    return depart


def relire_depart(paquet, chemin, cle: str | None) -> None:
    """Une copie « Réviser » rouverte (du disque, page rechargée) n'a plus l'état des notions d'où elle a été composée
    (``_depart``, non enregistré) : relu dans le bilan ``chemin`` (``depart_du_bilan``), son essai suivant part encore du
    bilan (``Paquet.nouvel_essai_suivant``) et non de cette copie seule. Rien sur une copie qui l'a déjà."""
    if paquet.reviser and getattr(paquet, "_depart", None) is None:
        paquet._depart = depart_du_bilan(chemin, cle)


class Lecteur(QMainWindow):
    enregistree = Signal()  # la copie vient d'être réécrite : la page du navigateur (web/pyqt6) la range à son tour

    def __init__(self, chemin, paquet, mot_de_passe, source=None, maitre=False, lire_echeances=None):
        """``chemin`` : où écrire la copie, ``None`` pour n'écrire nulle part (le professeur essaie le sujet) ; ``source`` : le
        fichier ouvert, près duquel chercher le cours (``chemin`` par défaut). Un paquet en données (l'accueil,
        ``noyau.en_donnees``) reçoit ici son écran, construit une seule fois. ``maitre`` : le professeur entré par son mot de
        passe dans le navigateur, où ``codes.professeur`` ne le connaît pas ; sans anti-triche pour lui (``surveillee``).
        ``lire_echeances(rappel)`` : relit le fichier d'échéances (``relire``), ``rappel(texte)``, ``None`` s'il n'a pas pu le
        lire ; par défaut, sur le disque du professeur (``echeances.du_disque``). Le navigateur le lit dans Dropbox (``pont_qt``),
        et le donne ici : une copie rouverte après son échéance le relit dès sa construction."""
        super().__init__()
        # la clé du bilan de l'année, tirée du mot de passe tapé à l'accueil (``Accueil.commencer``) : en mémoire, jamais dans
        # la copie, et lue avant ``ecran``, qui ne recopie que ce qui s'enregistre
        cle_bilan = vars(paquet).pop("cle_bilan", None)
        # (sujets, classe) : de quoi retrouver la ligne de cette copie dans le fichier d'échéances (``Accueil.nommer``)
        self.suivi_echeances = vars(paquet).pop("suivi_echeances", None)
        # les aménagements de l'élève (``Accueil.nommer``) : le recul de son échéance (secondes)
        self.bonus_echeance = vars(paquet).pop("bonus_echeance", 0)
        agrandi = vars(paquet).pop("agrandi", False)  # et son zoom de départ
        oralise = vars(paquet).pop("oralise", False)  # et le bouton « Écouter »
        with GardeCopie.suspendue(), differee():
            paquet = noyau.ecran(paquet)
        self.chemin, self.paquet, self.mot_de_passe, self.source = chemin, paquet, mot_de_passe, source
        self.setWindowTitle(paquet.titre.replace("\n", " "))
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "associations" / "teacher.svg")))
        self.setCentralWidget(paquet)
        self.resize(paquet.size())
        paquet.lire_cours = lambda cours: cours_a_cote(source or chemin, cours)
        if (source or chemin) and (bilan := bilan_a_cote(source or chemin, paquet.eleve)):
            paquet.poser_bilan(str(bilan), cle_bilan)
            relire_depart(paquet, bilan, cle_bilan)
        # Une réponse, une navigation, une touche de l'appréciation : l'enregistrement est DIFFÉRÉ de DIFFERE ms, et les
        # demandes qui arrivent d'ici là n'en font qu'un (le paquet entier sérialisé, chiffré, rangé : 6 à 20 ms par geste,
        # 4,4 s pour les 219 feuilles que « terminer » ferme une à une, mesuré le 02/10/2026). La fin, la fermeture et les
        # sorties de la surveillance enregistrent tout de suite, et la page du navigateur vide l'attente quand elle se cache.
        self.differe = QTimer(self, singleShot=True, interval=DIFFERE)
        self.differe.timeout.connect(self.enregistrer)
        for f in paquet.feuilles:
            f.changee.connect(self.differe.start)
        paquet.finie.connect(self.enregistrer)  # « Rendre ma copie » confirmé : la fin est enregistrée même si tout était déjà fermé
        paquet.finie.connect(lambda: self.reduire())  # et le plein écran quitté (l'utilisateur, 09/10/2026) ; lu à l'appel (``pont_qt``)
        paquet.finie.connect(lambda: QTimer.singleShot(0, self.montrer_rapport))  # après la note, que ``finie`` précède, et sa mise en page
        paquet.annotee.connect(self.differe.start)
        paquet.recommencee.connect(lambda: self.recommencer())  # lu au clic : le navigateur le remplace (``pont_qt``)
        # le zoom de toute l'interface (``qtpy6.loupe``) ; l'élève « agrandi » (``Accueil.nommer``) part à 130 %, tant
        # qu'aucun zoom n'a été choisi sur ce poste
        self.en_zoom, self.marge_vu = False, 0
        paquet.bouton_zoom.setText(f"Zoom {round(loupe.facteur() * 100)} %")
        paquet.bouton_zoom.show()
        paquet.zoomee.connect(lambda: self.zoomer(loupe.suivant()))
        if agrandi and not loupe.choisi():
            QTimer.singleShot(0, lambda: self.zoomer(amenagements_lecteur.ZOOM_AGRANDI))
        # l'élève aux consignes oralisées : « Écouter » lit la question en cours (``Paquet.ecouter``, ``qtpy6.voix``), là
        # où une voix existe ; la lecture s'arrête à la copie rendue
        paquet.bouton_ecouter.setVisible(oralise and voix.disponible())
        paquet.finie.connect(voix.taire)
        self.suivant = None  # la fenêtre de l'essai suivant : une référence, sans quoi Python la détruirait
        self.professeur, self.maitre = codes.professeur() is not None, maitre
        paquet.noter(self.professeur)  # la machine du professeur : il écrit la note et l'appréciation
        boutons = [paquet.prec_libre, paquet.suiv_libre] + ([paquet.precedent, paquet.suivant] if paquet.affichage == "question" else [])
        for b in boutons:  # après la connexion du paquet lui-même : la session enregistrée est celle d'après le clic
            b.clicked.connect(self.differe.start)
        # la surveillance (``sortir``) : l'écran noir, et la sortie qui n'y mène qu'après GRACE
        self.leve, self.sanction = None, SANCTION  # leve : time.time() où il se lève, math.inf tant que l'élève est dehors
        self.depart = None  # time.time() de la sortie en cours
        # l'épreuve se passe en plein écran, et y revenir se fait par un clic (le navigateur n'accepte que ça) ; dans le
        # navigateur, c'est la page qui les fournit (pont_qt.surveiller), et qui dit quand l'élève sort
        self.agrandir, self.present = self.showFullScreen, lambda: self.isFullScreen() and self.isActiveWindow()
        self.reduire = lambda: self.isFullScreen() and self.showMaximized()
        self.rideau = QWidget(self)
        self.rideau.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.rideau.setStyleSheet("background: black; color: white; font-size: 20pt;")
        self.consigne, self.plein = QLabel(), QPushButton("Passer en plein écran")
        self.consigne.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.consigne.setWordWrap(True)
        self.plein.setStyleSheet("background: white; color: black; padding: 10px 30px;")
        self.plein.clicked.connect(self._agrandir)
        disposition = QVBoxLayout(self.rideau)
        disposition.setContentsMargins(40, 40, 40, 40)
        disposition.addStretch()
        disposition.addWidget(self.consigne)
        disposition.addWidget(self.plein, alignment=Qt.AlignmentFlag.AlignHCenter)
        disposition.addStretch()
        self.rideau.hide()
        self.dehors = QTimer(self, singleShot=True, interval=GRACE)
        self.dehors.timeout.connect(self.baisser)
        self.lire_echeances = lire_echeances or (lambda rappel: rappel(echeances.du_disque()))  # relu pendant l'épreuve
        self.relue = time.monotonic()  # la dernière relecture : l'accueil vient de lire le fichier
        self.en_relecture = None  # monotonic() de la relecture qui attend sa réponse
        # la fin de la séance en classe (secondes UTC, colonne ``fin_creneau``) et l'ouverture de la copie, d'où sa barre part ;
        # lue dès l'ouverture (plus bas), sans compter pour la relecture régulière, puis à chaque relecture (``seance_lue``)
        self.fin_seance, self.ouverture = None, horloge.secondes()
        self.cloture = None  # l'échéance (``paquet.limite``) dont la relecture d'avant la clôture est faite : elle fige la copie
        # une correction différée attend l'échéance, la copie déjà rendue ; une copie figée (en pause), un nouveau code, ou
        # l'échéance repoussée dans le fichier qu'elle relit (``lever_pause``)
        if paquet.fin is None and (not paquet.suspendue or self.suivi_echeances) or paquet.fin is not None and paquet.masquee:
            repris = paquet.debut is not None
            if paquet.fin is None:
                paquet.demarrer()
            self.minuteur = QTimer(self)
            self.minuteur.timeout.connect(self.chronometre)
            self.minuteur.start(1000)
            self.chronometre()
            if self.suivi_echeances and self.en_relecture is None:  # sans relecture d'échéance en cours, qui la lira
                self.lire_echeances(self.seance_lue)
            if repris and not paquet.suspendue and self.surveillee() and time.time() - (paquet.vu or 0) > GRACE / 1000:  # la copie rouverte (page
                self.baisser()  # rechargée, fermée) : on en était sorti, sauf à l'instant
                self.revenir()
        elif paquet.fin is None:  # figée, rien qui la rouvre : sans minuteur, mais « Corriger mes réponses » actif (``demarre``)
            paquet.demarrer()
        # la copie telle qu'elle est sur le disque : la regarder sans rien y changer ne la réécrit pas (``enregistrer``) ; un
        # sujet distribué ouvert là, ou le sujet que le navigateur pose dans ``chemin``, n'est pas la copie : il diffère
        self.ecrite = self.sur_disque()

    def _agrandir(self):  # ``agrandir`` lu au clic : le navigateur le remplace (``pont_qt``)
        self.agrandir()

    def surveiller(self):
        """Une épreuve sous ``anti_triche`` commence en plein écran (``agrandir``, dans le navigateur possible seulement juste
        après un clic, celui de l'accueil) ; sinon l'écran noir le demande, sans sanction."""
        if self.surveillee():
            self.agrandir()
            if self.leve is None and not self.present():
                self.baisser(0)

    def juger(self, *_):
        """Chaque changement d'état (fenêtre active, plein écran, onglet visible) : l'élève est là, ou il est sorti."""
        if self.present():
            self.revenir()
        else:
            self.sortir()

    def changeEvent(self, evenement):
        super().changeEvent(evenement)
        if evenement.type() in (evenement.Type.WindowStateChange, evenement.Type.ActivationChange) and sys.platform != "emscripten":
            self.juger()

    def montrer_rapport(self) -> None:
        """La copie rendue et corrigée : retour en haut, où sont la note et le rapport (``Paquet._cadre_note``). L'élève
        rend depuis le bas de la copie, et il n'en voyait rien (TP3 de géolocalisation, l'utilisateur, 03/11/2026)."""
        paquet = self.paquet
        if not paquet.corrigee():
            return
        if paquet.affichage == "question":  # ``aller`` refuserait de revenir en arrière sans ``retour``
            paquet.courante = 0
            paquet._afficher_page(0)
            zone = paquet.ecrans[0]
        else:
            paquet.attente.stop()  # une descente vers la question suivante, demandée par la dernière soumission
            paquet.descente.stop()
            zone = paquet.defilement
        zone.verticalScrollBar().setValue(0)

    def enregistrer(self):
        self.differe.stop()
        if self.chemin is None:
            return
        # Hors épreuve surveillée, une copie dont rien n'a changé depuis son ouverture ou sa dernière écriture, hormis ``vu``,
        # n'est pas réécrite : ouverte puis fermée par le professeur, elle était rechiffrée et datée du jour, et Dropbox la
        # resynchronisait (l'utilisateur, 06/11/2026 : « pourquoi quand j'ouvre une copie d'élève […] sa date de modification
        # est mise à jour ? »). Pendant l'épreuve, ``vu`` doit s'écrire : une copie rouverte le compare (``__init__``).
        contenu = None if self.surveillee() else self.contenu()
        if contenu is not None and contenu == getattr(self, "ecrite", None):
            retenir_cle(self.chemin, self.mot_de_passe)
            return
        if self.leve is None:  # l'élève est là, ou sorti depuis moins de GRACE : ce qu'une copie rouverte compare (``vu``)
            self.paquet.vu = (self.depart if self.dehors.isActive() else time.time()) + self.marge_vu
        sauver(self.paquet, self.chemin, self.mot_de_passe)
        retenir_cle(self.chemin, self.mot_de_passe)
        self.ecrite = contenu
        self.enregistree.emit()

    def sur_disque(self) -> str | None:
        """``chemin`` relu et sérialisé sans ``vu``, comme ``contenu`` ; ``None`` s'il n'existe pas ou ne se relit pas."""
        if self.chemin is None or not Path(self.chemin).exists():
            return None
        medias = dict(noyau.MEDIAS)  # relire un Paquet remplit MEDIAS : les images du sujet ouvert restent les siennes
        try:
            with noyau.en_donnees():
                lu = charger(self.chemin, self.mot_de_passe)
            lu.vu = None
            return serializejson.dumps(lu)
        except Exception:  # noqa: BLE001 : illisible ici, la copie s'écrit comme avant
            return None
        finally:
            noyau.MEDIAS.clear()
            noyau.MEDIAS.update(medias)

    def contenu(self) -> str:
        """La copie sérialisée sans ``vu`` (l'heure du dernier enregistrement) : ce qui dit si elle a changé."""
        vu, self.paquet.vu = self.paquet.vu, None
        try:
            return serializejson.dumps(self.paquet)
        finally:
            self.paquet.vu = vu

    def zoomer(self, facteur: float) -> None:
        """Toute l'interface à ``facteur`` (``qtpy6.loupe``). La copie est enregistrée avant : dans le navigateur, la page se
        recharge et la reprend (``pont_qt.ranger``, ``reprendre_puis_afficher``), l'élève revalidant l'accueil prérempli ;
        ce qu'il en coûte de temps (``RECHARGE``) n'est pas compté comme une sortie à la réouverture (``vu``). En natif, la
        fenêtre se recrée : la surveillance ignore ce qu'elle voit pendant une seconde."""
        self.en_zoom, self.marge_vu = True, RECHARGE
        self.enregistrer()
        loupe.zoomer(facteur)
        if abs(loupe.facteur() - facteur) > 1e-6:  # le navigateur : la page part et reviendra au nouveau facteur
            return
        self.marge_vu = 0
        for grille in list(SaisieConversion.GRILLES):  # leur plancher suit le facteur (``actualiser``)
            grille.actualiser()
        self.paquet.bouton_zoom.setText(f"Zoom {round(facteur * 100)} %")
        QTimer.singleShot(1000, self._zoom_fini)

    def _zoom_fini(self) -> None:
        self.en_zoom = False
        if self.surveillee():
            self.juger()

    def recommencer(self):
        """« Nouvel essai » : la copie de l'essai suivant, à côté de celle-ci, « … (2ème essai).qcm » (``chemin_essai``), dans
        une nouvelle fenêtre ; reprise telle quelle si l'élève l'a déjà commencée."""
        self.enregistrer()
        with noyau.en_donnees():
            paquet = self.paquet.nouvel_essai_suivant()
            chemin = self.chemin and chemin_essai(self.chemin, paquet.essai)
            if chemin and chemin.exists():
                paquet = charger(chemin, self.mot_de_passe)
        paquet.suivi_echeances = self.suivi_echeances
        self.suivant = Lecteur(chemin, paquet, self.mot_de_passe, self.source or self.chemin, self.maitre, self.lire_echeances)
        self.suivant.enregistrer()  # tout de suite : la nouvelle copie existe, et « Nouvel essai » la reprendra
        self.suivant.showFullScreen() if self.isFullScreen() else self.suivant.show()
        self.suivant.surveiller()
        self.close()

    def closeEvent(self, evenement):
        """Un changement de réponse sans soumission ni validation n'est enregistré qu'ici ou en changeant d'écran ; et ce qui
        attend encore son enregistrement différé l'est ici."""
        self.enregistrer()
        super().closeEvent(evenement)

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.rideau.setGeometry(self.rect())

    def surveillee(self):
        """Le sujet le demande, l'épreuve dure, et ce n'est pas la machine du professeur."""
        return self.paquet.anti_triche and self.paquet.fin is None and not (self.professeur or self.maitre)

    def sortir(self):
        """L'élève quitte l'épreuve (autre onglet, autre application, plein écran quitté) : le rideau tombe s'il n'est pas
        revenu dans GRACE. D'ici là, le rideau montre déjà « Passer en plein écran », sans sanction : dans le navigateur, le
        plein écran ne se reprend que par un clic, et sans ce bouton une sortie par Échap, même d'une seconde, valait toujours
        la minute (l'utilisateur, 06/11/2026 : « il ne faut pas mettre une minute de pénalité si on quitte le plein écran
        moins de 5 secondes »)."""
        if self.surveillee() and not self.en_zoom and not self.dehors.isActive() and self.leve != math.inf:
            self.depart = time.time()
            self.dehors.start()
            if self.leve is None:
                self.consigne.setText(noyau.dire(RETOUR))
                self.plein.show()
                self.paquet.setEnabled(False)
                self.rideau.raise_()
                self.rideau.show()

    def baisser(self, sanction=SANCTION):
        """L'écran noir, qui cache le sujet et en bloque la saisie, jusqu'au retour de l'élève, puis ``sanction`` secondes ;
        une sortie sanctionnée est inscrite dans la copie (``paquet.sorties``), avec l'heure du départ (``None`` : la copie
        rouverte)."""
        self.dehors.stop()  # le plein écran demandé au début : une sortie encore en attente n'en est pas une
        self.leve, self.sanction = math.inf, sanction
        if sanction:
            self.paquet.sorties.append([self.depart, None])
            self.enregistrer()
        self.paquet.setEnabled(False)
        self.rideau.raise_()
        self.rideau.show()
        self.decompter()

    def revenir(self):
        """L'élève est revenu : le rideau se lève SANCTION secondes plus tard ; une nouvelle sortie d'ici là le relance."""
        self.dehors.stop()
        if self.leve is None and not self.rideau.isHidden():  # revenu dans GRACE : le rideau d'attente se lève, sans sanction
            self.lever()
        if self.leve == math.inf:
            self.leve = time.time() + self.sanction
            if self.sanction:
                self.paquet.sorties[-1][1] = time.time()
                self.enregistrer()
            self.decompter()

    def decompter(self):
        """Le décompte du rideau, à chaque seconde (``chronometre``) ; levé à son terme si l'élève est là (en plein écran), ou si
        l'épreuve se termine."""
        if self.leve is None:
            return
        reste = self.leve - time.time()
        if self.paquet.fin is not None or reste <= 0 and self.present():
            self.leve = None
            self.lever()
            return
        if reste <= 0:  # la sanction purgée hors du plein écran (la copie rouverte) : y revenir, sans nouvelle sanction
            self.leve, self.sanction, reste = math.inf, 0, math.inf
        self.plein.setVisible(reste == math.inf or not self.present())  # hors du plein écran, le chemin du retour reste montré
        self.consigne.setText(PLEIN_ECRAN if not self.sanction else noyau.dire(RIDEAU.format(
            "Revenez sur cette page, en plein écran." if reste == math.inf else f"Reprise dans {math.ceil(reste)} s.")))

    def lever(self):
        """Le rideau levé : l'épreuve de nouveau visible et modifiable."""
        self.rideau.hide()
        self.paquet.setEnabled(True)

    def chronometre(self):
        """La barre de temps, et le délai des indices de la question où est l'élève ; seule une durée annoncée par le sujet
        met fin à l'épreuve, ou la date limite du code (``paquet.limite``), jugée à l'heure en ligne (``horloge``) : la copie
        est alors figée (``Paquet.suspendre``), jamais rendue d'office (10/11/2026). Sans réseau, l'heure de l'ordinateur la remplace, et la copie le retient (``heure_locale``).
        Le mode de soumission du code (``paquet.soumission``) se juge sur le même temps : la soumission globale attend les 3/4
        (``retenir``), une correction différée la fin, copie rendue ou non (``masquer``)."""
        # le ``temps`` du sujet ou du code (l'utilisateur, 08/10/2026) : passé devant la copie, pas depuis sa première ouverture,
        # ou à l'heure, fermée comprise (fermer n'arrête pas une épreuve surveillée) ; à l'heure aussi une fois rendue
        # (l'échéance d'une correction différée est celle de la classe)
        ecoule = self.paquet.ecoule()
        # prolongée (``Paquet.reprendre_code``) : la durée du nouveau code court depuis la reprise
        total = 60 * self.paquet.duree_minutes + self.paquet.reprise if self.paquet.duree_minutes else 0
        limite = self.paquet.limite  # celle du code de la première ouverture, enregistrée dans la copie
        echue = False  # la limite passée : ``total`` peut alors valoir 0, une copie ouverte sans une seconde devant elle
        attend = False  # la relecture d'avant la clôture n'a pas répondu
        if limite is not None:
            avant_limite = limite - horloge.secondes()
            if not horloge.en_ligne():
                self.paquet.heure_locale = True
            if not total or avant_limite < total - ecoule:  # la limite tombe avant la fin de la durée : c'est elle qui compte
                total, echue = ecoule + max(avant_limite, 0), avant_limite <= 0
        if self.suivi_echeances and self.en_relecture is None and time.monotonic() - self.relue >= RELECTURE:
            self.relire()
        if echue and self.paquet.fin is None and self.suivi_echeances and self.cloture != limite:
            # l'échéance atteinte : le fichier relu d'abord, une prolongation de dernière seconde vaut (l'utilisateur, 26/10/2026)
            if self.en_relecture is None:
                self.relire()
            if self.en_relecture is not None and time.monotonic() - self.en_relecture < ATTENTE_RELECTURE:
                echue, attend = False, True  # la copie attend la réponse, la barre à zéro (figée, elle le reste)
            else:
                self.cloture = limite  # sans réponse : figée à l'échéance connue
        reste = max(int(total - ecoule), 0)
        echue = echue or bool(total) and not reste
        if self.paquet.soumission is not None:
            self.paquet.retenir(self.paquet.soumission in noyau.GLOBALES and bool(total) and ecoule < 0.75 * total)
            self.paquet.masquer(self.paquet.soumission == noyau.DIFFEREE and bool(reste) or self.paquet.soumission in noyau.PAUSES)
        if self.paquet.fin is not None:
            if not self.paquet.masquee:
                self.minuteur.stop()
        elif echue:
            # figée, pas rendue ni corrigée, quel que soit le mode : « Rendre ma copie » seul la corrige (le professeur,
            # 10/11/2026) ; un nouveau code PAUSES ou l'échéance repoussée dans le fichier la rouvre
            if not self.paquet.suspendue:
                self.paquet.suspendre()
                self.enregistrer()
            if not self.suivi_echeances:  # rien ne la rouvrira tant qu'elle est ouverte
                self.minuteur.stop()
        else:
            if not attend:
                self.paquet.lever_pause()  # l'échéance repoussée (``relue_echeance``) : du temps rendu, sans correction vue
            self.paquet.ecouler()
        barre = self.paquet.barre_temps
        if total:
            barre.setValue(round(100 * (total - reste) / total))
            colorer(barre, "rouge" if reste <= total / 5 else "bleu")
            titre = f"{duree(reste)} / {duree(total, False)}"
        else:  # rien ne s'arrête faute de durée annoncée : une échelle qui approche 100 % sans l'atteindre, plutôt qu'une
            barre.setValue(min(99, round(100 * (1 - 0.5 ** (ecoule / (60 * DEMI_VIE))))))  # barre pleine annonçant une fin
            colorer(barre, "bleu")
            titre = f"temps écoulé : {duree(ecoule)}"
        if self.seance(limite) and total:  # deux barres : celle-ci mène à la séance suivante (l'échéance)
            titre = f"séance suivante : {titre}"
        barre.setFormat(titre)
        self.setWindowTitle(f"{self.paquet.titre.replace(chr(10), ' ')} — {titre}")
        self.decompter()


    def relire(self):
        """Le fichier d'échéances relu (``lire_echeances``), et la nouvelle échéance de cette copie appliquée à sa réponse
        (``relue_echeance``) : demandé toutes les RELECTURE secondes, et à l'échéance avant de rendre la copie."""
        self.en_relecture = time.monotonic()
        self.lire_echeances(self.relue_echeance)

    def relue_echeance(self, texte):
        """La réponse de ``relire`` : ``texte`` du fichier, ``None`` s'il n'a pas pu être lu (réseau). Une échéance repoussée
        vaut aussitôt ; une échéance avancée aussi, mais pas en deçà de DELAI_AVANCEE à partir de maintenant : la copie n'est
        pas fermée sous les yeux de l'élève, il a le temps de la rendre. Un fichier illisible, une ligne absente ou une case
        vide gardent l'échéance connue, sans rien dire à l'élève. Une relecture d'avant la clôture qui ne repousse pas
        l'échéance rend la copie au tic suivant."""
        limite = self.paquet.limite
        self.en_relecture, self.relue = None, time.monotonic()
        ligne = self.seance_lue(texte)
        # une copie OUVERTE au troisième temps le garde ; jamais par sa limite, qu'une avancée met après l'échéance
        echeance = echeances.echeance_pour(ligne, datetime.fromtimestamp(self.ouverture, timezone.utc),
                                           echeances.validations(self.paquet))
        nouvelle = echeance and echeance.timestamp() + self.bonus_echeance  # le tiers-temps de l'élève (``Accueil.nommer``)
        if nouvelle and nouvelle != limite and self.paquet.fin is None:
            if limite is None or nouvelle < limite:  # avancée : pas avant DELAI_AVANCEE, ni après l'ancienne
                nouvelle = max(nouvelle, horloge.secondes() + DELAI_AVANCEE)
                nouvelle = nouvelle if limite is None else min(nouvelle, limite)
            if nouvelle != limite:
                self.paquet.limite = nouvelle
                self.differe.start()
        if self.paquet.limite == limite and limite is not None and limite <= horloge.secondes():
            self.cloture = limite  # rien de plus au fichier : figée
        QTimer.singleShot(0, self.chronometre)  # pas dans ``chronometre`` : la lecture du disque répond sur-le-champ

    def seance_lue(self, texte: str | None) -> echeances.Ligne:
        """La ligne de cette copie dans le fichier d'échéances ``texte`` (``None`` : pas lu), et la fin de séance qu'elle
        porte retenue (``fin_seance``) ; un fichier illisible garde celle qu'on connaît."""
        if texte is None:
            return echeances.Ligne()
        sujets, classe = self.suivi_echeances
        ligne = echeances.lire(echeances.trouver(texte, sujets, classe))
        self.fin_seance = ligne.fin_creneau and ligne.fin_creneau.timestamp() + echeances.MARGE_FIN_SEANCE  # le temps de rendre
        return ligne

    def seance(self, limite: float | None) -> bool:
        """La barre de la séance en classe (``paquet.barre_seance``) : montrée tant qu'elle dure et qu'elle finit avant
        l'échéance ``limite`` (sinon une seule barre dit tout), pleine à sa fin, partie de l'ouverture de la copie (le début
        de la séance n'est pas dans le fichier). Rend vrai si elle est montrée."""
        barre, fin = self.paquet.barre_seance, self.fin_seance
        reste = fin - horloge.secondes() if fin else 0
        montree = reste > 0 and self.paquet.fin is None and (limite is None or fin < limite)
        barre.setVisible(montree)
        if montree:
            total = max(fin - self.ouverture, reste, 1)
            barre.setValue(round(100 * (total - reste) / total))
            colorer(barre, "rouge" if reste <= total / 5 else "bleu")
            barre.setFormat(f"fin de séance : {duree(int(reste))}")
        return montree


class CodeRefuse(MotDePasseRequis):
    """Un code de classe qui n'ouvre pas le sujet, et pourquoi : faux, ou hors de ses dates."""

    def __init__(self, pourquoi):
        super().__init__(pourquoi)
        self.pourquoi = pourquoi


# l'œil d'un champ masqué, ouvert (montrer) ou barré (masquer) : dessiné ici, le navigateur n'a pas le thème d'icônes
OEIL = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" '
        'stroke-linecap="round"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>{}</svg>')


def icone_oeil(barre):
    pixmap = QPixmap(48, 48)
    pixmap.fill(Qt.GlobalColor.transparent)
    peintre = QPainter(pixmap)
    QSvgRenderer(QByteArray(OEIL.format('<path d="M3 3l18 18"/>' if barre else "").encode())).render(peintre)
    peintre.end()
    return QIcon(pixmap)


class ChampMasque(QLineEdit):
    """Un champ de code, masqué, avec l'œil qui le montre le temps qu'on le relise."""

    def __init__(self):
        super().__init__()
        self.setEchoMode(QLineEdit.EchoMode.Password)
        self.oeil = self.addAction(icone_oeil(False), QLineEdit.ActionPosition.TrailingPosition)
        self.oeil.setToolTip("Afficher")
        self.oeil.triggered.connect(self.basculer)

    def basculer(self):
        self.montrer(self.echoMode() == QLineEdit.EchoMode.Password)

    def montrer(self, visible: bool) -> None:
        self.setEchoMode(QLineEdit.EchoMode.Normal if visible else QLineEdit.EchoMode.Password)
        self.oeil.setIcon(icone_oeil(visible))
        self.oeil.setToolTip("Masquer" if visible else "Afficher")


class Accueil(QDialog):
    """Le premier écran de l'élève, en natif comme dans le navigateur : son nom, son prénom et, si le sujet en demande un, le
    code de déverrouillage. Le sujet s'ouvre dès la construction (sans code, ou avec celui des sujets d'entraînement), pour
    porter son titre et ne montrer le champ du code que s'il en faut un ; un code refusé le redemande, une autre erreur
    (fichier absent, illisible, corrompu : ``voir.raison``) est dite et n'a pas de code qui la débloque. Pas de bouton : Entrée
    passe au champ vide suivant et, tout rempli, commence ; un code de classe (``codes``) commence dès qu'il est complet. Un
    sujet exporté avec ses listes de classes ne s'ouvre que par le code d'une classe, dans ses dates, et pour un élève de
    cette classe, reconnu malgré ses fautes de frappe et nommé comme sur la liste ; son mot de passe doit
    alors être le sien (``empreinte``, sa publique : la copie la garde, et le lecteur web n'en accepte plus d'autre sous ce nom). Un code
    sans classe (``codes.SANS_CLASSE``) laisse entrer tout nom, sans liste ; un code ne sert ni avant son départ ni après
    son échéance, qu'il confie au lecteur (``paquet.limite``), qui rend la copie à l'heure dite, et sa durée remplace celle
    du sujet. La boîte ne bloque
    pas (``open``, pas ``exec`` : dans le navigateur, Qt n'a pas de boucle d'événements imbriquée) : ``accepted`` livre
    ``paquet`` (avec son ``eleve``, « Nom Prénom ») et ``mot`` (le mot de passe qui l'a ouvert, celui de la copie).
    ``echeances`` : le texte du fichier d'échéances du professeur, que le lecteur web a lu dans Dropbox ; sans lui, celui du
    disque s'il y est (``echeances.du_disque`` : la machine du professeur), sinon le code vaut seul. ``origine`` : le chemin
    du sujet qui y donne son nom, quand ``chemin`` ne le porte pas (le lecteur web l'écrit sous ``/sujet.qcm``)."""

    def __init__(self, chemin: str | Path, mot_de_passe: str | None = None, eleve: str = "",
                 echeances_texte: str | None = None, origine: str | Path | None = None,
                 identites: dict[str, Any] | None = None, amenagements_texte: str | None = None) -> None:
        super().__init__()
        # la table des aménagements que le lecteur applique (``amenagements_lecteur``) : celle que le lecteur web a lue dans
        # Dropbox ; sans elle, celle du disque (natif), à côté du fichier d'empreintes
        self.amenagements = amenagements_lecteur.du_disque(chemin) if amenagements_texte is None \
            else amenagements_lecteur.lire(amenagements_texte)
        self.chemin, self.paquet, self.mot = chemin, None, None
        self.origine = Path(origine or chemin)  # dont les noms (fichier, dossier, dossier du dessus) cherchent la ligne d'échéances
        # le fichier d'empreintes (``codes.IDENTITES``) : celui que le lecteur web a lu dans Dropbox ; sans lui (natif), celui du
        # dossier partagé de l'élève, sur le disque, et l'identité gardée sur ce compte (``identite_gardee``)
        self.disque = identites is None
        self.identites, self.fichier_identites = identites_du_disque(chemin) if self.disque else (identites, None)
        self.garde = identite_gardee() if self.disque else None  # (nom, prénom, secret) : entrer sans retaper le mot de passe
        self.oublier = oublier_identite  # identité gardée périmée : le lecteur web y oublie la sienne (``pont_qt.preremplir``)
        self.secret = self.depot = None  # la clé tirée du mot de passe (``codes.secret_eleve``), l'empreinte à déposer
        self.premiere = False  # l'élève nommé en est à sa première visite : son mot de passe s'affiche (``voir_premiere_visite``)
        self.classe = self.inscrits = None  # la classe du code qui a ouvert le sujet, et sa liste (aucune : code sans classe)
        self.limite = None  # l'échéance de ce code (UTC), que le lecteur fait respecter
        self.depart = None  # le départ de ce code (UTC), s'il n'est pas encore passé : « Commencer » attend jusque-là
        self.duree = None  # la durée de l'épreuve que ce code donne (minutes), à la place de celle du sujet
        self.soumission = None  # le mode de soumission de ce code (``noyau.SOUMISSIONS``), écrit dans la copie par ``nommer``
        self.anti_triche = self.temps = None  # l'anti-triche et le temps de ce code, qui remplacent ceux du sujet (``nommer``)
        # le texte du fichier d'échéances du professeur, s'il a pu être lu : il gagne sur le code (``echeances``)
        self.echeances = echeances.du_disque() if echeances_texte is None else echeances_texte
        self.bloque = False  # une erreur qu'aucun code ne corrige
        self.maitre = False  # ouvert par le mot de passe professeur (tapé, ou son fichier) : seul à entrer sous son nom
        self.empreinte = ""  # la publique de l'élève entré par son mot de passe (``codes.publique``), ou rien
        self.mot_professeur = ""  # le mot de passe professeur tapé (``professeur``), que le lecteur web retient
        self.setWindowTitle("SmartTeacher")
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "associations" / "teacher.svg")))
        # ni bouton de fermeture ni d'agrandissement : dans le navigateur, Qt dessine lui-même la barre de titre, et fermer
        # l'accueil laisserait un canevas vide
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.CustomizeWindowHint | Qt.WindowType.WindowTitleHint)
        self.setProperty("copiable", True)  # GardeCopie laisse le menu contextuel : le mot de passe se colle
        self.nom, self.prenom, self.personnel = QLineEdit(), QLineEdit(), ChampMasque()
        # sans eleve, l'identité que SmartOS exporte dans la session (identite-eleve.sh : sur le compte élève, lue dans son
        # coffre) : ici seulement incomplète, l'accueillir() d'une identité complète saute la boîte ; l'élève complète le reste
        nom, prenom = (eleve.split(" ", 1) + [""])[:2] if eleve else (os.environ.get("UTILISATEUR_NOM", ""),
                                                                       os.environ.get("UTILISATEUR_PRENOM", ""))
        self.nom.setText(nom)
        self.prenom.setText(prenom)
        # le code du lien (``?code=`` du lecteur web, ou du tableau de bord de la classe) : refuser() le réessaie. Jamais de
        # champ où le taper (l'utilisateur, 04/11/2026 : « je ne veux pas que les élèves aient à rentrer un code de sujet »)
        self.code = mot_de_passe or ""
        self.nom.editingFinished.connect(self.voir_premiere_visite)
        self.prenom.editingFinished.connect(self.voir_premiere_visite)
        self.message = QLabel()
        self.message.setWordWrap(True)
        self.formulaire = QFormLayout(self)
        self.formulaire.addRow("Prénom", self.prenom)  # le prénom d'abord : c'est l'ordre dans lequel l'élève se nomme
        self.formulaire.addRow("Nom", self.nom)
        # le mot de passe que l'élève choisit à sa première visite (``identifier``) ; le mot de passe professeur s'y tape aussi
        self.formulaire.addRow("Mot de passe", self.personnel)
        # chaque libellé à la hauteur de son champ, texte centré : en tactile (``tactile.activer``) le champ monte à 44 px,
        # et QFormLayout laisse le libellé en haut de ligne, plus en face de ce qu'on y tape
        for champ in (self.prenom, self.nom, self.personnel):
            libelle = self.formulaire.labelForField(champ)
            libelle.setMinimumHeight(champ.sizeHint().height())
            libelle.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.formulaire.addRow(self.message)
        self.bouton = QPushButton("Commencer")  # le clic qui, dans le navigateur, autorise le plein écran (``Lecteur.surveiller``)
        self.bouton.setAutoDefault(False)  # Entrée reste à keyPressEvent
        self.bouton.clicked.connect(self.commencer)
        self.formulaire.addRow(self.bouton)
        self.attente = QTimer(self, interval=1000)
        self.attente.timeout.connect(self.patienter)
        self.setMinimumWidth(360)
        self.ouvrir(mot_de_passe)
        self.garder(self.garde)
        self.voir_premiere_visite()  # le nom gardé vient d'être écrit : son mot de passe a pu être réinitialisé

    def garder(self, garde: tuple[str, str, bytes] | None) -> None:
        """L'identité gardée sur ce poste (``garde``) : son nom dans les champs encore vides, le mot de passe inutile tant
        que c'est elle qui entre (chaque élève a sa session Windows : le poste n'est jamais partagé)."""
        self.garde = garde
        if garde:
            for champ, texte in ((self.nom, garde[0]), (self.prenom, garde[1])):
                if not champ.text().strip():
                    champ.setText(texte)

    def voir_premiere_visite(self) -> None:
        """À sa première visite, l'élève ne tape son mot de passe qu'une fois : le champ l'affiche et le message le dit ;
        sinon il est masqué. Hors liste (professeur compris, sujet encore fermé), toujours masqué."""
        premiere = self.inscrits is not None and codes.premiere_visite(
            self.identites, self.inscrits, self.nom.text().strip(), self.prenom.text().strip(), self.garde)
        if premiere != self.premiere:
            self.premiere = premiere
            self.personnel.montrer(premiere)
            self.dire(codes.PREMIERE_VISITE if premiere else "")

    def ouvrir(self, mot_de_passe):
        """Un essai d'ouverture du sujet. Seul un code de classe l'ouvre (``deverrouiller``), venu d'un lien, jamais tapé, sauf
        sur la machine du professeur, où son mot de passe l'ouvre sans code ni liste."""
        try:
            if mot_de_passe:
                self.deverrouiller(mot_de_passe)
            elif not self.rouvrir():  # un fichier en clair, ou la machine du professeur : son mot de passe l'ouvre, sans liste
                self.paquet, self.mot = essayer(self.chemin)
                self.maitre = self.mot is not None
        except MotDePasseRequis as erreur:
            self.paquet = None
            self.dire(erreur.pourquoi if isinstance(erreur, CodeRefuse) else SANS_LIEN)
        except Exception as erreur:  # noqa: BLE001 - rien d'autre que le code ne se corrige ici : on le dit
            self.dire(raison(self.chemin, erreur))
            self.bloque = True
        else:
            self.setWindowTitle(self.paquet.titre.replace("\n", " "))
            self.dire("")
        self.patienter()
        # le mot de passe, seulement tant que le sujet est fermé (le mot de passe professeur s'y tape) ou ouvert pour une
        # classe : hors liste, l'élève n'en a pas (l'utilisateur, 03/10/2026, qui renonce au mot de passe sur un lien sans classe)
        self.formulaire.setRowVisible(self.personnel, self.paquet is None or self.inscrits is not None)
        self.voir_premiere_visite()
        self.adjustSize()
        self.focaliser()

    def copie_rouverte(self):
        """Ouverte, une copie d'élève (sans graine, mais nommée : pas un sujet libre), et pas par le professeur."""
        return self.paquet is not None and not self.paquet.graine and bool(self.paquet.eleve) and not self.maitre

    def rouvrir(self):
        """Une copie déjà enregistrée sur ce compte se rouvre par la clé retenue alors (``retenir_cle``), sans code (l'utilisateur,
        30/09/2026 : « aucun code ne doit être redemandé »). Pas le sujet distribué, qui a le même sel et la même clé : le
        refaire demande le code, dans ses dates. Rend ``False`` si ce n'est pas une copie de ce compte."""
        cle = cle_retenue(self.chemin)
        try:
            paquet, mot = essayer(self.chemin, cle) if cle else (None, None)
        except MotDePasseRequis:
            return False
        if paquet is None or paquet.graine:
            return False
        self.paquet, self.mot = paquet, mot
        return True

    def deverrouiller(self, texte):
        """Ouvre le sujet par le code de classe ``texte``, écrit juste ou à quelques lettres près (``codes.corrections`` :
        plusieurs lectures possibles s'essaient toutes sur le fichier, 0,3 s chacune), ou lève ``CodeRefuse``. Le fichier
        juge d'abord le code (sans contrôle, toute phrase des listes se lit), ses dates ensuite : un refus pour la date ne
        vient ainsi que d'un vrai code. Ce qui n'est pas un code de classe s'essaie d'abord comme le mot de passe professeur
        (``codes.cle_du_mot``) : il ouvre tout sujet, sans classe ni dates, sous le nom ``codes.PROFESSEUR`` (demande de
        l'utilisateur, 28/09/2026 : essayer ses sujets en ligne à la place d'un élève)."""
        horloge.demarrer()  # l'heure en ligne, avant de juger une date
        exact = codes.lire_code(texte)
        pourquoi = "Code incorrect."
        if not exact and self.professeur(texte.strip()):
            return
        lus = [exact] if exact else filter(None, map(codes.lire_code, codes.corrections(texte)))
        for code in (c for lu in lus for c in codes.variantes(lu)):
            try:
                paquet, mot = essayer(self.chemin, code.cle)
            except MotDePasseRequis:
                continue
            classes = sorted(paquet.inscrits)
            if code.classe != codes.SANS_CLASSE and code.classe >= len(classes):  # une classe que le sujet n'a pas
                continue
            if code.classe != codes.SANS_CLASSE and self.echeances:  # le fichier d'échéances gagne sur ce que le code porte
                ligne = echeances.lire(echeances.trouver(self.echeances, self.sujets(), classes[code.classe]))
                code = echeances.appliquer(code, ligne)
                if paquet.fin is None:  # non rendue, après l'échéance : le troisième temps, à la règle de notation_tp
                    tardive = echeances.echeance_pour(ligne, horloge.maintenant(), echeances.validations(paquet))
                    code = code._replace(echeance=tardive or code.echeance)
            proche = code.depart and code.depart - timedelta(minutes=APPROCHE) <= horloge.maintenant() < code.depart
            if codes.refus(code) and not proche:
                pourquoi = codes.refus(code)
                break
            self.paquet, self.mot, self.depart = paquet, mot, code.depart if proche else None
            self.limite, self.duree, self.soumission = code.echeance, code.duree, code.soumission
            self.anti_triche, self.temps = code.anti_triche, code.temps
            self.classe = None if code.classe == codes.SANS_CLASSE else classes[code.classe]
            self.inscrits = self.classe and paquet.inscrits[self.classe]
            return
        raise CodeRefuse(pourquoi)

    def sujets(self) -> set[str]:
        """Les noms sous lesquels le fichier d'échéances peut citer ce sujet : le fichier, son dossier, celui du dessus."""
        return {self.origine.stem, *(p.name for p in self.origine.parents[:2])}

    def professeur(self, texte):
        """Ouvre le sujet si ``texte`` est le mot de passe professeur (``codes.cle_du_mot``), tapé dans « Mot de passe »
        (l'utilisateur, 28/09/2026) : tout sujet, sans classe ni dates, même déjà ouvert par un code de classe, sous
        le nom ``codes.PROFESSEUR``. Rend ``False`` si ce n'est pas lui."""
        cle = texte and codes.cle_du_mot(texte, Path(self.chemin).read_bytes())
        if not cle:
            return False
        try:
            self.paquet, self.mot = essayer(self.chemin, cle)
        except MotDePasseRequis:
            return False
        self.maitre, self.mot_professeur = True, texte
        self.classe = self.inscrits = self.limite = self.depart = self.duree = self.soumission = self.anti_triche = self.temps = None
        self.nom.setText(codes.PROFESSEUR[0])
        self.prenom.setText(codes.PROFESSEUR[1])
        return True

    def focaliser(self):
        """Le curseur dans le champ à remplir : le premier vide de prénom et nom."""
        next((c for c in (self.prenom, self.nom) if not c.text().strip()), self.prenom).setFocus()

    def showEvent(self, evenement):
        """Le focus reposé à l'affichage : dans le navigateur, celui posé à la construction est perdu et Qt le donne au
        dernier champ."""
        super().showEvent(evenement)
        self.focaliser()

    def keyPressEvent(self, evenement):
        """Entrée passe au champ suivant encore vide (dans l'ordre du formulaire, en revenant au début) ; quand tous sont
        remplis, elle commence."""
        if evenement.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            champs = [self.prenom, self.nom]
            ici = champs.index(self.focusWidget()) + 1 if self.focusWidget() in champs else 0
            vide = next((c for c in champs[ici:] + champs[:ici] if not c.text().strip()), None)
            if vide is not None:
                vide.setFocus()
            else:
                self.commencer()
            return
        super().keyPressEvent(evenement)

    def patienter(self):
        """« Commencer » grisé, avec le temps qui reste, jusqu'au départ du code (``APPROCHE``)."""
        reste = (self.depart - horloge.maintenant()).total_seconds() if self.depart else 0
        self.bouton.setEnabled(reste <= 0)
        self.bouton.setText(f"Commencer dans {duree(math.ceil(reste))}" if reste > 0 else "Commencer")
        if reste > 0:
            self.attente.start()
        else:
            self.attente.stop()

    def dire(self, texte):
        """Le message sous les champs ; sa ligne disparaît quand il n'y a rien à dire."""
        self.message.setText(noyau.dire(texte))
        self.formulaire.setRowVisible(self.message, bool(texte))

    def transmettre(self):
        if self.disque and self.secret is not None:  # natif : l'empreinte dans le dossier partagé, synchronisé par Dropbox
            garder_identite(*self.nomme, self.secret)
            if self.depot:
                deposer_sur_disque(self.fichier_identites, self.depot)
        self.apres(self.paquet, self.mot)

    def commencer(self):
        if self.bloque:
            return
        if not self.maitre and self.professeur(self.personnel.text().strip()):
            self.personnel.clear()  # le sien, pas celui d'un élève à vérifier
            self.dire("")
            self.patienter()
        if self.paquet is None:
            self.ouvrir(self.code)
            if self.paquet is None:
                return
        if self.copie_rouverte():  # par son code (autre compte) :
            self.nommer(self.paquet.eleve)  # son nom, vérifié à la première ouverture ; ni départ ni liste
            self.accept()
            return
        if not self.bouton.isEnabled():  # Entrée avant le départ
            return
        nom, prenom = self.nom.text().strip(), self.prenom.text().strip()
        if not (nom and prenom):
            self.dire("Écrivez votre nom et votre prénom.")
            return
        if self.inscrits is not None:
            inscrit = codes.reconnaitre(nom, prenom, self.inscrits)
            if inscrit is None:
                self.dire(f"« {nom} {prenom} » n'est pas sur la liste de la classe {self.classe} : vérifiez l'orthographe, et le code.")
                return
            nom, prenom = inscrit[:2]
        if not self.maitre and codes.reconnaitre(nom, prenom, [codes.PROFESSEUR]):
            self.dire("Ce nom est celui du professeur : il n'entre que par son mot de passe.")
            return
        personnel = self.personnel.text().strip()
        if personnel and self.inscrits is None:
            self.dire("Ce sujet ne demande pas de mot de passe : laissez ce champ vide.")
            return
        self.empreinte, self.secret, self.depot = "", None, None
        if self.inscrits is not None:
            if not self.identifier(nom, prenom, personnel):
                return
            self.empreinte = codes.publique(self.secret)
        # pour le bilan de l'année (``Lecteur``), hors de la copie
        self.nommer(f"{nom} {prenom}").cle_bilan = bilans_widget.cle_du_secret(self.secret)
        self.accept()

    def identifier(self, nom: str, prenom: str, tape: str) -> bool:
        """L'élève reconnu par son mot de passe ``tape`` ou, sans lui, par l'identité gardée sur ce poste
        (``codes.reconnaitre_mot_de_passe``, la même entrée qu'au tableau de bord). Pose ``secret`` (dont l'empreinte garde ses
        copies, ``identite_copie``) et ``depot`` (l'empreinte d'une première visite) ; sinon dit pourquoi, rend faux."""
        cle = codes.nom_identite(nom, prenom)
        garde = self.garde[2] if self.garde and codes.nom_identite(*self.garde[:2]) == cle else None
        reconnu = codes.reconnaitre_mot_de_passe(self.identites, nom, prenom, tape, garde)
        if isinstance(reconnu, str):
            if reconnu == codes.GARDE_PERIMEE:  # gardée d'avant une réinscription : le mot de passe d'aujourd'hui la remplacera
                self.oublier()
                self.garder(None)
                self.voir_premiere_visite()
                reconnu = codes.PREMIERE_VISITE if self.premiere else reconnu  # réinitialisé : il en choisit un autre
            self.dire(reconnu)
            return False
        self.nomme = (nom, prenom)
        self.secret, self.depot = reconnu
        return True

    def identite_copie(self) -> dict[str, str] | None:
        """Ce que la copie porte pour dire qui l'a écrite (``Paquet.identite``) : la publique de l'élève (son
        empreinte), ``None`` sans mot de passe. Plus de preuve depuis le 05/11/2026 ; celle d'une copie ancienne est ignorée."""
        return None if self.secret is None else {"publique": codes.publique(self.secret)}

    def nommer(self, eleve, depart=None):
        """Le paquet au nom de ``eleve``, avec ce que le code y met, écrit dans la copie : son mode de soumission, son
        échéance (``limite``), sa durée, son anti-triche, et l'empreinte de son mot de passe. Une copie rouverte garde les siens
        et son nom, ceux de sa première ouverture (l'utilisateur, 30/09/2026). ``distribue`` (non enregistré) dit s'il sort du
        sujet distribué ou d'une copie rouverte : ``copie`` en décide où écrire. Un sujet « Réviser » distribué se compose sur
        l'état des notions de l'élève (``depart``, sinon celui du bilan à côté du sujet, ``depart_du_bilan``), gardé
        dans le paquet pour l'essai suivant (``_depart``, non enregistré) ; le lecteur web, qui n'a pas le bilan sur son
        disque, le lit chez le professeur puis le renomme (``pont_qt.reprendre_puis_afficher``)."""
        distribue = bool(self.paquet.graine)
        amenagements = amenagements_lecteur.de(self.amenagements, eleve)
        if distribue and self.paquet.reviser and depart is None:
            depart = depart_du_bilan(bilan_a_cote(self.origine, eleve), bilans_widget.cle_du_secret(self.secret))
        with noyau.en_donnees():
            self.paquet = self.paquet.nommer(eleve, self.soumission, etats=depart and depart[0])
        self.paquet.distribue = distribue
        if depart is not None:
            self.paquet._depart = depart
        if self.classe:  # de quoi relire son échéance dans le fichier pendant l'épreuve (``Lecteur.relire``), hors de la copie
            self.paquet.suivi_echeances = (self.sujets(), self.classe)
        # les aménagements de l'élève (``amenagements_lecteur``) : le tiers-temps ajoute un tiers à la durée et autant à l'échéance (``bonus``), que la relecture du fichier d'échéances
        # garde (``Lecteur.relue_echeance``, non enregistré)
        # la durée de base : celle du code, sinon celle du sujet (d'une copie rouverte : déjà allongée d'un tiers)
        base = self.duree or (self.paquet.duree_minutes if distribue or "tiers_temps" not in amenagements
                              else round((self.paquet.duree_minutes or 0) / amenagements_lecteur.TIERS_TEMPS))
        bonus = amenagements_lecteur.bonus(amenagements, base)
        self.paquet.bonus_echeance = 60 * bonus
        self.paquet.agrandi = "agrandi" in amenagements  # le zoom de départ (``Lecteur``), non enregistré
        self.paquet.oralise = "oralise" in amenagements  # le bouton « Écouter » (``Lecteur``), non enregistré
        # une faute de plus par mot dans une réponse courte (``noyau.FAUTES_EN_PLUS``), remise à zéro pour l'élève suivant ;
        # enregistrée dans la copie (``Paquet.fautes_en_plus``) : une recorrection hors du lecteur la retrouve ; une copie
        # rouverte garde la sienne, même ouverte là où la table des aménagements manque
        if distribue:
            self.paquet.fautes_en_plus = 1 if "orthographe" in amenagements else 0
        noyau.FAUTES_EN_PLUS = self.paquet.fautes_en_plus
        limite = self.limite and (self.limite + timedelta(minutes=bonus)).timestamp()
        duree = self.duree and self.duree + bonus
        if not distribue:  # sauf la copie d'un code en pause, qu'un nouveau code prolonge ou rend (``Paquet.reprendre_code``)
            self.paquet.reprendre_code(limite, duree, self.soumission)
            return self.paquet
        if self.anti_triche is not None:
            self.paquet.anti_triche, self.paquet.temps = self.anti_triche, self.temps
        self.paquet.empreinte, self.paquet.limite = self.empreinte, limite
        self.paquet.identite = self.identite_copie()
        if duree or self.paquet.duree_minutes:
            self.paquet.duree_minutes = duree or self.paquet.duree_minutes + bonus
        if "simplifie" in amenagements:
            amenagements_lecteur.simplifier(self.paquet)
        return self.paquet

    def refuser(self, texte):
        """La boîte rouverte sur le sujet, avec la raison : le professeur refuse ce nom (lecteur web, ``pont_qt``)."""
        self.ouvrir(self.code or None)
        self.dire(texte)
        self.open()


def essayer(chemin, mot_de_passe=None):
    """``voir.essayer``, en données (``noyau.en_donnees``) : l'accueil ne montre du sujet que son titre et ses listes, et
    ``Lecteur`` en construit l'écran, sur la copie de l'élève."""
    with noyau.en_donnees():
        return essayer_ecran(chemin, mot_de_passe)


def accueillir(chemin: str | Path, apres: Callable, mot_de_passe: str | None = None, eleve: str = "",
               echeances_texte: str | None = None, origine: str | Path | None = None,
               identites: dict[str, Any] | None = None, amenagements_texte: str | None = None) -> Accueil | None:
    """L'accueil de l'élève, puis ``apres(paquet, mot)`` : tout de suite si l'élève est déjà nommé (``--eleve``,
    ``?eleve=``, ou l'identité que SmartOS exporte dans la session) et que le sujet s'ouvre sans lui demander de code ni
    le chercher sur une liste (un code de classe, même venu d'un lien), sinon quand il a rempli la boîte. Rend la boîte, à
    garder tant qu'elle est ouverte (``None`` si elle a été sautée). ``echeances_texte``, ``origine``, ``identites``,
    ``amenagements_texte`` : ceux de ``Accueil``."""
    if not eleve:
        nom, prenom = os.environ.get("UTILISATEUR_NOM", "").strip(), os.environ.get("UTILISATEUR_PRENOM", "").strip()
        if nom and prenom:
            eleve = f"{nom} {prenom}"
    accueil = Accueil(chemin, mot_de_passe, eleve, echeances_texte, origine, identites, amenagements_texte)
    if accueil.copie_rouverte():
        eleve = accueil.paquet.eleve  # son nom, sans boîte
    # un nom à vérifier, sur la liste ou comme celui du professeur (``Accueil.maitre``), passe par la boîte
    if eleve and accueil.paquet is not None and accueil.inscrits is None and (
            accueil.maitre or not codes.reconnaitre(eleve, "", [codes.PROFESSEUR])):
        paquet = accueil.nommer(eleve)
        # l'accueil sauté suit le paquet qu'il a nommé (non enregistré) : le lecteur web, qui n'a pas le bilan sur son
        # disque, en renomme le sujet « Réviser » sur celui du professeur (``pont_qt.composer_sur_le_bilan``)
        paquet._accueil = accueil
        apres(paquet, accueil.mot)
        return None
    accueil.apres = apres
    accueil.accepted.connect(accueil.transmettre)
    accueil.open()
    return accueil


def copie(source, paquet, mot):
    """``(chemin, paquet)`` : où écrire la copie de ``paquet``, ouvert depuis ``source`` (un ``.qcm`` ou un PDF), et le paquet à
    montrer. Sur la machine du professeur, qui lit ou essaie un sujet distribué, nulle part (``None``) ; chez l'élève, en place :
    le sujet devient sa copie, qu'il ne pourra pas recommencer. Sauf un PDF (ou un ``.json``), qu'on ne réécrit pas : sa copie va à côté de lui,
    « <sujet> [Nom Prénom].qcm » (le même nom que sur Dropbox, ``codes.chemin_copie``), reprise s'il l'a déjà commencée."""
    if paquet.distribue and codes.professeur() is not None:
        return None, paquet
    if source.suffix == ".qcm":
        return source, paquet
    chemin = dernier_essai(source.with_name(codes.nom_de_fichier(f"{source.stem} [{paquet.eleve}]") + ".qcm"))
    return chemin, charger(chemin, mot) if chemin.exists() else paquet


def chemin_essai(chemin, numero):
    """La copie du ``numero``-ième essai, à côté de ``chemin`` (celle d'un autre essai) : « <nom> (2ème essai).qcm »."""
    chemin = Path(chemin)
    return chemin.with_name(ESSAI_NOMME.sub("", chemin.stem) + codes.essai(numero) + chemin.suffix)


def dernier_essai(chemin: str | Path) -> Path:
    """À l'ouverture d'une copie de base (sans « (Nème essai) ») : celle de l'essai le plus récent, à côté d'elle
    (``chemin_essai``), ou elle-même s'il n'y en a pas. Une copie d'essai nommée s'ouvre telle quelle : un essai plus ancien
    s'ouvre par son propre fichier (décision du professeur, 07/11/2026)."""
    chemin = Path(chemin)
    if ESSAI_NOMME.search(chemin.stem):
        return chemin
    numero = 1
    while chemin_essai(chemin, numero + 1).is_file():
        numero += 1
    return chemin_essai(chemin, numero)


def copie_du_pdf(pdf):
    """La copie commencée à côté du PDF (``copie``) et enregistrée sur ce compte (``cle_retenue``), à rouvrir sans code à la
    place du sujet qu'il embarque ; ``None`` s'il n'y en a pas, ou plusieurs (un compte partagé : l'accueil demande le code)."""
    trouvees = [c for c in pdf.parent.glob("*.qcm") if c.name.startswith(f"{pdf.stem} [") and cle_retenue(c)
                and not ESSAI_NOMME.search(c.stem)]
    return dernier_essai(trouvees[0]) if len(trouvees) == 1 else None


def fichier_des_cles():
    """Les clés des copies enregistrées sur ce compte, ``{sel de l'en-tête age : clé}`` : le sel est celui du sujet, le
    même pour toutes ses copies, où qu'elles soient déplacées. La clé est celle que le code donne : ce fichier n'en dit pas
    plus que le code à qui lit le compte de l'élève, et une copie passée sur un autre compte (clé USB) redemande le code."""
    dossier = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.GenericDataLocation)
    return Path(dossier) / "SmartTeacher" / "cles_des_copies.json"


def identites_du_disque(chemin: str | Path) -> tuple[dict[str, Any], Path]:
    """Le fichier d'empreintes du natif (``codes.IDENTITES``) et son chemin : le premier trouvé dans le dossier du sujet ou un
    dossier au-dessus (la racine du dossier Dropbox que l'élève partage avec le professeur), sinon un fichier vide à côté
    du sujet. Lu sur place, sans réseau : la séance n'attend pas Internet."""
    dossier = Path(chemin).resolve().parent
    trouve = next((d / codes.IDENTITES for d in (dossier, *dossier.parents) if (d / codes.IDENTITES).is_file()), None)
    if trouve is None:
        return {}, dossier / codes.IDENTITES
    try:
        return codes.identites_lire(trouve.read_text(encoding="utf-8")), trouve
    except OSError:
        return {}, trouve


def fichier_identite() -> Path:
    """L'identité gardée sur ce compte (``garder_identite``), à côté des clés retenues des copies."""
    return fichier_des_cles().with_name("identite.json")


def identite_gardee() -> tuple[str, str, bytes] | None:
    """``(nom, prénom, secret)`` du dernier élève entré sur ce compte par son mot de passe, ou ``None``."""
    try:
        nom, prenom, secret = json.loads(fichier_identite().read_text())
        return nom, prenom, base64.b64decode(secret)
    except (OSError, ValueError, TypeError):
        return None


def garder_identite(nom: str, prenom: str, secret: bytes) -> None:
    """Garde l'identité de l'élève sur ce compte : il n'y retape pas son mot de passe (``Accueil.garder``). Le secret ne
    rouvre aucune copie : il ne fait que prouver qui les écrit, comme le mot de passe."""
    fichier_identite().parent.mkdir(parents=True, exist_ok=True)
    fichier_identite().write_text(json.dumps([nom, prenom, base64.b64encode(secret).decode()]))


def oublier_identite() -> None:
    """L'identité gardée sur ce compte oubliée (gardée d'avant une réinscription, ``codes.GARDE_PERIMEE``)."""
    fichier_identite().unlink(missing_ok=True)


def deposer_sur_disque(fichier: Path, entree: dict[str, str]) -> None:
    """L'empreinte d'une première visite ajoutée au fichier d'empreintes du natif, relu juste avant (un autre poste a pu y
    déposer depuis) ; une autre publique déjà sous ce nom n'est jamais réécrite d'ici."""
    try:
        identites = codes.identites_lire(fichier.read_text(encoding="utf-8")) if fichier.is_file() else {}
    except OSError:
        return
    if codes.ajouter_depot(identites, entree):
        fichier.write_text(json.dumps(identites, ensure_ascii=False, indent=1), encoding="utf-8")


def nettoyer_au_lancement(chemin: str | Path) -> bool:
    """À l'ouverture du lecteur du professeur : le fichier d'empreintes de ``chemin`` (``identites_du_disque``) perd ce qu'y
    laissaient les versions d'avant : codes personnels, publique du professeur (``codes.nettoyer_identites``). Vrai s'il est
    réécrit."""
    _, fichier = identites_du_disque(chemin)
    if not fichier.is_file():
        return False
    identites = codes.identites_lire(fichier.read_text(encoding="utf-8"))
    if not codes.nettoyer_identites(identites):
        return False
    fichier.write_text(json.dumps(identites, ensure_ascii=False, indent=1), encoding="utf-8")
    return True


def cle_retenue(chemin):
    """La clé retenue pour le fichier ``chemin`` (``retenir_cle``), ou ``None`` (dans le navigateur : jamais)."""
    if sys.platform == "emscripten" or not fichier_des_cles().exists():
        return None
    sel = sel_de(chemin)
    return sel and json.loads(fichier_des_cles().read_text()).get(sel)


def sel_de(chemin):
    """Le sel de l'en-tête age du fichier ``chemin`` (``codes.sel_du_fichier``) : l'index des clés retenues."""
    with open(chemin, "rb") as fichier:
        return codes.sel_du_fichier(fichier.read(200))


def retenir_cle(chemin, mot):
    """Retient la clé ``mot`` de la copie ``chemin``, pour la rouvrir sans code (``Accueil.rouvrir``)."""
    if sys.platform == "emscripten" or not mot:
        return
    cles = json.loads(fichier_des_cles().read_text()) if fichier_des_cles().exists() else {}
    sel = sel_de(chemin)
    if sel and cles.get(sel) != mot:
        try:  # un compte sans dossier de données écrivable : la copie redemandera son code, elle s'enregistre quand même
            fichier_des_cles().parent.mkdir(parents=True, exist_ok=True)
            fichier_des_cles().write_text(json.dumps(cles | {sel: mot}, indent=0))
        except OSError:
            pass


def lancer(chemin, mot_de_passe=None, eleve="", source=None):
    """Sans accueil : le lecteur d'un sujet qui s'ouvre sans rien demander (``--auto``, ``--capture``), ou ``SystemExit``.
    ``source`` : le fichier ouvert, quand ``chemin`` est le ``.qcm`` qu'en a tiré ``exporter_eleve.qcm_de``."""
    with noyau.en_donnees():  # l'écran, une fois, par ``Lecteur``
        paquet, mot = ouvrir(chemin, mot_de_passe, interactif=False)
        distribue = bool(paquet.graine)
        paquet = paquet.nommer(eleve)
    paquet.distribue = distribue
    source = Path(source or chemin)
    return Lecteur(*copie(source, paquet, mot), mot, source)


def bilan(app: Any, a: argparse.Namespace) -> int:
    """Le bilan ``a.sujet`` : en clair, ou par le secret gardé sur ce compte, sans rien demander ; sinon par le mot de passe de
    ``--mot-de-passe``, celui de l'élève ou du professeur (``--capture`` : son image, puis la sortie), ou par celui que
    l'on tape (``bilans_widget.montrer``)."""
    vivants = []  # la boîte puis la fenêtre du bilan, gardées tant qu'elles sont ouvertes
    identites, _ = identites_du_disque(a.sujet)
    eleve = bilans_widget.eleve_du_fichier(Path(a.sujet).as_posix(), identites)
    if a.mot_de_passe:
        ouvert = bilans_widget.ouvrir_bilan(a.sujet) or bilans_widget.ouvrir_par_mot_de_passe(a.sujet, eleve, a.mot_de_passe, identites)
        if ouvert is None:
            raise SystemExit(f"{a.sujet} : ce mot de passe ne l'ouvre pas")
        vivants.append(bilans_widget.fenetre(ouvert))
        if a.capture:
            app.processEvents()
            vivants[-1].grab().save(a.capture)
            return 0
    else:
        garde = identite_gardee()
        vivants.append(bilans_widget.montrer(a.sujet, vivants.append, eleve, identites, garde and garde[2]))
    return app.exec()


def main():
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujet")
    analyseur.add_argument("--mot-de-passe")
    analyseur.add_argument("--eleve", default="", help="« Nom Prénom » : l'accueil est sauté si le sujet s'ouvre sans code")
    analyseur.add_argument("--auto", action="store_true", help="répond juste, enregistre et sort, sans fenêtre")
    analyseur.add_argument("--capture", help="écrit l'image de la fenêtre dans ce fichier, puis sort")
    mode = analyseur.add_mutually_exclusive_group()
    mode.add_argument("--tactile", action="store_true", help="les cibles d'un écran au doigt, même sans écran tactile détecté")
    mode.add_argument("--souris", action="store_true", help="les cibles de la souris, même sur un écran tactile (pour comparer)")
    a = analyseur.parse_args()
    app = application()
    if not (a.auto or a.capture):
        erreurs.installer()  # sans personne devant l'écran, une boîte bloquerait
    if a.tactile or (not a.souris and tactile.detecte()):
        tactile.activer(app)
    GardeCopie(app)  # vit autant que l'application (son parent)
    source = Path(a.sujet)
    if source.suffix == bilans_widget.EXTENSION:  # le bilan d'un élève (``bilans.py fichiers``)
        return bilan(app, a)
    if source.suffix == ".qcm":  # la copie de base d'une révision à essais : l'essai le plus récent, à côté
        a.sujet = str(dernier_essai(source))
    extrait = tempfile.TemporaryDirectory()  # le .qcm tiré d'un PDF ou d'un .json, effacé à la sortie
    sujet = a.sujet
    if source.suffix in (".pdf", ".json"):
        from exporter_eleve import qcm_de  # noqa: PLC0415 - ici seulement : le lecteur web n'embarque pas exporter_eleve.py
        sujet = source.suffix == ".pdf" and copie_du_pdf(source) or qcm_de(source, Path(extrait.name))
    if a.auto:
        lecteur = lancer(sujet, a.mot_de_passe, a.eleve, a.sujet)
        paquet = lecteur.paquet
        for f in paquet.feuilles:
            f.demarrer()
            f.saisie = f.juste()
            f.soumettre()
        paquet.terminer()
        lecteur.enregistrer()
        obtenus, corriges, attente = paquet.resultat()
        print(f"{obtenus:g} / {corriges:g}" + (f" (+ {attente:g} à corriger)" if attente else ""))
        return 0
    if a.capture:
        lecteur = lancer(sujet, a.mot_de_passe, a.eleve, a.sujet)
        lecteur.show()
        # jusqu'à une mise en page stable : une colonne de classement fixe sa hauteur à son premier redimensionnement,
        # et la question ne grandit qu'une passe plus tard ; trois passes la capturaient débordant sur ses boutons
        avant = None
        for _ in range(50):
            app.processEvents()
            apres = [w.geometry().getRect() for w in lecteur.findChildren(QWidget)]
            if apres == avant:
                break
            avant = apres
        lecteur.grab().save(a.capture)
        return 0
    if codes.professeur():
        try:
            nettoyer_au_lancement(source)
        except OSError as erreur:  # le ménage n'empêche jamais d'ouvrir un sujet
            print(f"fichier d'empreintes non nettoyé : {erreur}", file=sys.stderr)
    vivants = []  # l'accueil puis le lecteur : des références, sans quoi Python les détruirait avant ``exec``

    def montrer(paquet, mot):
        vivants.append(Lecteur(*copie(Path(a.sujet), paquet, mot), mot, Path(a.sujet)))
        vivants[-1].show()
        vivants[-1].surveiller()

    vivants.append(accueillir(sujet, montrer, a.mot_de_passe, a.eleve))
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
