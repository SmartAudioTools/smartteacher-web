#!/usr/bin/env python3
"""Lit un sujet et y répond : l'application de l'élève.

    python lecteur.py SUJET.qcm|SUJET.pdf|SUJET.json [--mot-de-passe MOT] [--eleve "Nom Prénom"] [--auto] [--capture IMAGE.png]

L'élève commence par la boîte d'accueil (``Accueil``) : son nom, son prénom et, si le sujet en demande un, le code de
déverrouillage ; la même boîte, dans le canevas, ouvre l'épreuve dans le navigateur (web/pyqt6/pont_qt.py). ``--eleve`` la
saute quand le sujet s'ouvre sans code (la sonde fait de même par ``?eleve=``), tout comme l'identité que SmartOS exporte
dans la session (``UTILISATEUR_NOM``/``UTILISATEUR_PRENOM``) quand elle est complète. Le paquet (exporter_eleve.py) est réécrit, chiffré avec le même mot de passe, à chaque réponse validée : fermé puis rouvert, il
reprend là où il en était (réponses, indices débloqués, question courante, fin de l'épreuve). Ce fichier est aussi celui que
l'élève rend. La note affichée à la fin n'est pas la note officielle : le professeur recorrige les rendus (verifier.py).
Chez l'élève, le sujet devient ainsi sa copie : il ne peut pas refaire l'épreuve plus tard (l'utilisateur, 30/09/2026). Sur la
machine du professeur, qui lit ou essaie le sujet, rien ne s'écrit (``copie`` ; même jour, après un TP01 changé en copie par
un simple double clic). Un PDF d'``exporter_pdf.py`` s'ouvre par le ``.qcm`` qu'il embarque, sa copie à côté de lui sous
« <sujet> [Nom Prénom].qcm ». Un sujet ``.json`` (``sujets/``) s'ouvre par un ``.qcm`` exporté dans un dossier temporaire
(``exporter_eleve.qcm_de``), sur la machine du professeur. En ligne, le sujet déposé dans Dropbox ne change pas non plus : la page n'écrit que sous
``Copies/`` (``web/pyqt6/dropbox.js``).
``--auto`` répond juste à toutes les questions, termine, enregistre et sort, sans fenêtre (vérification) ; ``--capture``
écrit l'image de la fenêtre puis sort.
"""

import argparse
import json
import math
import os
import re
import sys
import tempfile
import time

from datetime import timedelta
from pathlib import Path

from qtpy6.QtCore import QByteArray, QStandardPaths, Qt, QTimer, Signal
from qtpy6.QtGui import QIcon, QPainter, QPixmap
from qtpy6.QtSvg import QSvgRenderer
from qtpy6.QtWidgets import (QDialog, QFormLayout, QLabel, QLineEdit, QMainWindow, QPushButton, QVBoxLayout,
                             QWidget)

import codes
import horloge
import noyau
from modele import GardeCopie, application, charger, colorer, differee, sauver
from qtpy6 import erreurs
from qtpy6.web import tactile
from voir import MotDePasseRequis, ouvrir, raison
from voir import essayer as essayer_ecran

DEMI_VIE = 10  # minutes : la barre d'un sujet sans durée annoncée est à moitié pleine au bout de ce temps
SANCTION = 60  # secondes d'écran noir après le retour de l'élève, dans une épreuve sous ``surveillance``
GRACE = 1000  # ms : une sortie plus brève ne compte pas (la fenêtre inactive un instant entre l'accueil et l'épreuve)
DIFFERE = 250  # ms : les demandes d'enregistrement plus rapprochées n'en font qu'un (``Lecteur.differe``)
RIDEAU = ("Vous avez quitté l'épreuve : autre onglet, autre application, ou page fermée.\n\n{}\n\n"
          "Le temps de l'épreuve continue de s'écouler.")
PLEIN_ECRAN = "Cette épreuve se passe en plein écran."
APPROCHE = 30  # minutes : un code dont le départ est si proche ouvre l'accueil, « Commencer » grisé jusqu'à l'heure dite


def duree(secondes, avec_secondes=True):
    """« 1 h 05 min 12 s » au-delà d'une heure, « 12 min 34 s » en deçà ; sans secondes pour un total, toujours en minutes rondes."""
    h, m, s = int(secondes) // 3600, int(secondes) // 60 % 60, int(secondes) % 60
    if avec_secondes:
        return f"{h} h {m:02d} min {s:02d} s" if h else f"{m} min {s:02d} s"
    if h:
        return f"{h} h {m:02d} min" if m else f"{h} h"
    return f"{m} min"


def emplacements_du_cours(chemin, profondeur):
    """Où chercher un PDF du cours (``Paquet.cours``), depuis le dossier du .qcm : à ``chemin``, comme le professeur les range
    sur son disque et dans son Dropbox, sinon sous son seul nom dans ce dossier puis dans chacun de ses ``profondeur`` parents
    (un sujet copié ailleurs, le cours rangé plus haut)."""
    nom = Path(chemin).name
    return [chemin] + ["../" * k + nom for k in range(profondeur + 1)]


def cours_a_cote(qcm, chemin):
    """Les octets d'un PDF du cours au premier de ses ``emplacements_du_cours``, None s'il n'est nulle part."""
    dossier = Path(qcm).resolve().parent
    for c in emplacements_du_cours(chemin, len(dossier.parents)):
        if (pdf := dossier / c).is_file():
            return pdf.read_bytes()
    return None


class Lecteur(QMainWindow):
    enregistree = Signal()  # la copie vient d'être réécrite : la page du navigateur (web/pyqt6) la range à son tour

    def __init__(self, chemin, paquet, mot_de_passe, source=None, maitre=False):
        """``chemin`` : où écrire la copie, ``None`` pour n'écrire nulle part (le professeur essaie le sujet) ; ``source`` : le
        fichier ouvert, près duquel chercher le cours (``chemin`` par défaut). Un paquet en données (l'accueil,
        ``noyau.en_donnees``) reçoit ici son écran, construit une seule fois. ``maitre`` : le professeur entré par son mot de
        passe dans le navigateur, où ``codes.professeur`` ne le connaît pas ; sans anti-triche pour lui (``surveillee``)."""
        super().__init__()
        with GardeCopie.suspendue(), differee():
            paquet = noyau.ecran(paquet)
        self.chemin, self.paquet, self.mot_de_passe, self.source = chemin, paquet, mot_de_passe, source
        self.setWindowTitle(paquet.titre.replace("\n", " "))
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "associations" / "teacher.svg")))
        self.setCentralWidget(paquet)
        self.resize(paquet.size())
        paquet.lire_cours = lambda cours: cours_a_cote(source or chemin, cours)
        # Une réponse, une navigation, une touche de l'appréciation : l'enregistrement est DIFFÉRÉ de DIFFERE ms, et les
        # demandes qui arrivent d'ici là n'en font qu'un (le paquet entier sérialisé, chiffré, rangé : 6 à 20 ms par geste,
        # 4,4 s pour les 219 feuilles que « terminer » ferme une à une, mesuré le 02/10/2026). La fin, la fermeture et les
        # sorties de la surveillance enregistrent tout de suite, et la page du navigateur vide l'attente quand elle se cache.
        self.differe = QTimer(self, singleShot=True, interval=DIFFERE)
        self.differe.timeout.connect(self.enregistrer)
        for f in paquet.feuilles:
            f.changee.connect(self.differe.start)
        paquet.finie.connect(self.enregistrer)  # « Rendre ma copie » confirmé : la fin est enregistrée même si tout était déjà fermé
        paquet.annotee.connect(self.differe.start)
        paquet.recommencee.connect(lambda: self.recommencer())  # lu au clic : le navigateur le remplace (``pont_qt``)
        self.suivant = None  # la fenêtre de l'essai suivant : une référence, sans quoi Python la détruirait
        self.professeur, self.maitre = codes.professeur() is not None, maitre
        paquet.noter(self.professeur)  # la machine du professeur : il écrit la note et l'appréciation
        boutons = [paquet.prec_libre, paquet.suiv_libre] + ([paquet.precedent, paquet.suivant] if paquet.affichage == "question" else [])
        for b in boutons:  # après la connexion du paquet lui-même : la session enregistrée est celle d'après le clic
            b.clicked.connect(self.differe.start)
        # la surveillance (``sortir``) : l'écran noir, et la sortie qui n'y mène qu'après GRACE
        self.leve, self.sanction = None, SANCTION  # leve : time.time() où il se lève, math.inf tant que l'élève est dehors
        self.depart = None  # time.time() de la sortie en cours
        # l'épreuve se passe en plein écran, et y revenir se fait par un clic (le navigateur n'accepte que ça) ; dans le
        # navigateur, c'est la page qui les fournit (pont_qt.surveiller), et qui dit quand l'élève sort
        self.agrandir, self.present = self.showFullScreen, lambda: self.isFullScreen() and self.isActiveWindow()
        self.rideau = QWidget(self)
        self.rideau.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)
        self.rideau.setStyleSheet("background: black; color: white; font-size: 20pt;")
        self.consigne, self.plein = QLabel(), QPushButton("Passer en plein écran")
        self.consigne.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.consigne.setWordWrap(True)
        self.plein.setStyleSheet("background: white; color: black; padding: 10px 30px;")
        self.plein.clicked.connect(self._agrandir)
        disposition = QVBoxLayout(self.rideau)
        disposition.setContentsMargins(40, 40, 40, 40)
        disposition.addStretch()
        disposition.addWidget(self.consigne)
        disposition.addWidget(self.plein, alignment=Qt.AlignmentFlag.AlignHCenter)
        disposition.addStretch()
        self.rideau.hide()
        self.dehors = QTimer(self, singleShot=True, interval=GRACE)
        self.dehors.timeout.connect(self.baisser)
        if paquet.fin is None or paquet.masquee:  # une correction différée attend l'échéance, la copie déjà rendue
            repris = paquet.debut is not None
            if paquet.fin is None:
                paquet.demarrer()
            self.minuteur = QTimer(self)
            self.minuteur.timeout.connect(self.chronometre)
            self.minuteur.start(1000)
            self.chronometre()
            if repris and self.surveillee():  # la copie rouverte (page rechargée, fermée) : on en était sorti
                self.baisser()
                self.revenir()

    def _agrandir(self):  # ``agrandir`` lu au clic : le navigateur le remplace (``pont_qt``)
        self.agrandir()

    def surveiller(self):
        """Une épreuve sous ``surveillance`` commence en plein écran (``agrandir``, dans le navigateur possible seulement juste
        après un clic, celui de l'accueil) ; sinon l'écran noir le demande, sans sanction."""
        if self.surveillee():
            self.agrandir()
            if self.leve is None and not self.present():
                self.baisser(0)

    def juger(self, *_):
        """Chaque changement d'état (fenêtre active, plein écran, onglet visible) : l'élève est là, ou il est sorti."""
        if self.present():
            self.revenir()
        else:
            self.sortir()

    def changeEvent(self, evenement):
        super().changeEvent(evenement)
        if evenement.type() in (evenement.Type.WindowStateChange, evenement.Type.ActivationChange) and sys.platform != "emscripten":
            self.juger()

    def enregistrer(self):
        self.differe.stop()
        if self.chemin is None:
            return
        sauver(self.paquet, self.chemin, self.mot_de_passe)
        retenir_cle(self.chemin, self.mot_de_passe)
        self.enregistree.emit()

    def recommencer(self):
        """« Nouvel essai » : la copie de l'essai suivant, à côté de celle-ci, « … (2ème essai).qcm » (``chemin_essai``), dans
        une nouvelle fenêtre ; reprise telle quelle si l'élève l'a déjà commencée."""
        self.enregistrer()
        with noyau.en_donnees():
            paquet = self.paquet.nouvel_essai_suivant()
            chemin = self.chemin and chemin_essai(self.chemin, paquet.essai)
            if chemin and chemin.exists():
                paquet = charger(chemin, self.mot_de_passe)
        self.suivant = Lecteur(chemin, paquet, self.mot_de_passe, self.source or self.chemin, self.maitre)
        self.suivant.enregistrer()  # tout de suite : la nouvelle copie existe, et « Nouvel essai » la reprendra
        self.suivant.showFullScreen() if self.isFullScreen() else self.suivant.show()
        self.suivant.surveiller()
        self.close()

    def closeEvent(self, evenement):
        """Un changement de réponse sans soumission ni validation n'est enregistré qu'ici ou en changeant d'écran ; et ce qui
        attend encore son enregistrement différé l'est ici."""
        self.enregistrer()
        super().closeEvent(evenement)

    def resizeEvent(self, evenement):
        super().resizeEvent(evenement)
        self.rideau.setGeometry(self.rect())

    def surveillee(self):
        """Le sujet le demande, l'épreuve dure, et ce n'est pas la machine du professeur."""
        return self.paquet.surveillance and self.paquet.fin is None and not (self.professeur or self.maitre)

    def sortir(self):
        """L'élève quitte l'épreuve (autre onglet, autre application) : le rideau tombe s'il n'est pas revenu dans GRACE."""
        if self.surveillee() and not self.dehors.isActive() and self.leve != math.inf:
            self.depart = time.time()
            self.dehors.start()

    def baisser(self, sanction=SANCTION):
        """L'écran noir, qui cache le sujet et en bloque la saisie, jusqu'au retour de l'élève, puis ``sanction`` secondes ;
        une sortie sanctionnée est inscrite dans la copie (``paquet.sorties``), avec l'heure du départ (``None`` : la copie
        rouverte)."""
        self.dehors.stop()  # le plein écran demandé au début : une sortie encore en attente n'en est pas une
        self.leve, self.sanction = math.inf, sanction
        if sanction:
            self.paquet.sorties.append([self.depart, None])
            self.enregistrer()
        self.paquet.setEnabled(False)
        self.rideau.raise_()
        self.rideau.show()
        self.decompter()

    def revenir(self):
        """L'élève est revenu : le rideau se lève SANCTION secondes plus tard ; une nouvelle sortie d'ici là le relance."""
        self.dehors.stop()
        if self.leve == math.inf:
            self.leve = time.time() + self.sanction
            if self.sanction:
                self.paquet.sorties[-1][1] = time.time()
                self.enregistrer()
            self.decompter()

    def decompter(self):
        """Le décompte du rideau, à chaque seconde (``chronometre``) ; levé à son terme si l'élève est là (en plein écran), ou si
        l'épreuve se termine."""
        if self.leve is None:
            return
        reste = self.leve - time.time()
        if self.paquet.fin is not None or reste <= 0 and self.present():
            self.leve = None
            self.rideau.hide()
            self.paquet.setEnabled(True)
            return
        if reste <= 0:  # la sanction purgée hors du plein écran (la copie rouverte) : y revenir, sans nouvelle sanction
            self.leve, self.sanction, reste = math.inf, 0, math.inf
        self.plein.setVisible(reste == math.inf)
        self.consigne.setText(PLEIN_ECRAN if not self.sanction else RIDEAU.format(
            "Revenez sur cette page, en plein écran." if reste == math.inf else f"Reprise dans {math.ceil(reste)} s."))

    def chronometre(self):
        """La barre de temps, et le délai des indices de la question où est l'élève ; seule une durée annoncée par le sujet
        met fin à l'épreuve, ou la date limite du code (``paquet.limite``), jugée à l'heure en ligne (``horloge``) : la copie
        est alors rendue d'office. Sans réseau, l'heure de l'ordinateur la remplace, et la copie le retient (``heure_locale``).
        Le mode de soumission du code (``paquet.soumission``) se juge sur le même temps : la soumission globale attend les 3/4
        (``retenir``), une correction différée la fin, copie rendue ou non (``masquer``)."""
        ecoule = horloge.secondes() - self.paquet.debut
        total = 60 * (self.paquet.duree_minutes or 0)
        limite = self.paquet.limite  # celle du code de la première ouverture, enregistrée dans la copie
        if limite is not None:
            avant_limite = limite - horloge.secondes()
            if not horloge.en_ligne():
                self.paquet.heure_locale = True
            if not total or avant_limite < total - ecoule:  # la limite tombe avant la fin de la durée : c'est elle qui compte
                total = ecoule + max(avant_limite, 0)
        reste = max(int(total - ecoule), 0)
        if self.paquet.soumission is not None:
            self.paquet.retenir(self.paquet.soumission in noyau.GLOBALES and bool(total) and ecoule < 0.75 * total)
            self.paquet.masquer(self.paquet.soumission == noyau.DIFFEREE and bool(reste))
        if self.paquet.fin is not None:
            if not self.paquet.masquee:
                self.minuteur.stop()
        elif total and not reste:
            self.paquet.terminer()  # enregistré par ``finie``
        else:
            self.paquet.ecouler()
        barre = self.paquet.barre_temps
        if total:
            barre.setValue(round(100 * (total - reste) / total))
            colorer(barre, "rouge" if reste <= total / 5 else "bleu")
            titre = f"{duree(reste)} / {duree(total, False)}"
        else:  # rien ne s'arrête faute de durée annoncée : une échelle qui approche 100 % sans l'atteindre, plutôt qu'une
            barre.setValue(min(99, round(100 * (1 - 0.5 ** (ecoule / (60 * DEMI_VIE))))))  # barre pleine annonçant une fin
            colorer(barre, "bleu")
            titre = f"temps écoulé : {duree(ecoule)}"
        barre.setFormat(titre)
        self.setWindowTitle(f"{self.paquet.titre.replace(chr(10), ' ')} — {titre}")
        self.decompter()


class CodeRefuse(MotDePasseRequis):
    """Un code de classe qui n'ouvre pas le sujet, et pourquoi : faux, ou hors de ses dates."""

    def __init__(self, pourquoi):
        super().__init__(pourquoi)
        self.pourquoi = pourquoi


# l'œil d'un champ masqué, ouvert (montrer) ou barré (masquer) : dessiné ici, le navigateur n'a pas le thème d'icônes
OEIL = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" '
        'stroke-linecap="round"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>{}</svg>')


def icone_oeil(barre):
    pixmap = QPixmap(48, 48)
    pixmap.fill(Qt.GlobalColor.transparent)
    peintre = QPainter(pixmap)
    QSvgRenderer(QByteArray(OEIL.format('<path d="M3 3l18 18"/>' if barre else "").encode())).render(peintre)
    peintre.end()
    return QIcon(pixmap)


class ChampMasque(QLineEdit):
    """Un champ de code, masqué, avec l'œil qui le montre le temps qu'on le relise."""

    def __init__(self):
        super().__init__()
        self.setEchoMode(QLineEdit.EchoMode.Password)
        self.oeil = self.addAction(icone_oeil(False), QLineEdit.ActionPosition.TrailingPosition)
        self.oeil.setToolTip("Afficher")
        self.oeil.triggered.connect(self.basculer)

    def basculer(self):
        masque = self.echoMode() == QLineEdit.EchoMode.Password
        self.setEchoMode(QLineEdit.EchoMode.Normal if masque else QLineEdit.EchoMode.Password)
        self.oeil.setIcon(icone_oeil(masque))
        self.oeil.setToolTip("Masquer" if masque else "Afficher")


class Accueil(QDialog):
    """Le premier écran de l'élève, en natif comme dans le navigateur : son nom, son prénom et, si le sujet en demande un, le
    code de déverrouillage. Le sujet s'ouvre dès la construction (sans code, ou avec celui des sujets d'entraînement), pour
    porter son titre et ne montrer le champ du code que s'il en faut un ; un code refusé le redemande, une autre erreur
    (fichier absent, illisible, corrompu : ``voir.raison``) est dite et n'a pas de code qui la débloque. Pas de bouton : Entrée
    passe au champ vide suivant et, tout rempli, commence ; un code de classe (``codes``) commence dès qu'il est complet. Un
    sujet exporté avec ses listes de classes ne s'ouvre que par le code d'une classe, dans ses dates, et pour un élève de
    cette classe, reconnu malgré ses fautes de frappe et nommé comme sur la liste ; son code personnel, facultatif, doit
    alors être le sien (``empreinte`` : la copie la garde, et le lecteur web n'en accepte plus d'autre sous ce nom). Un code
    sans classe (``codes.SANS_CLASSE``) laisse entrer tout nom, sans liste ; un code ne sert ni avant son départ ni après
    son échéance, qu'il confie au lecteur (``paquet.limite``), qui rend la copie à l'heure dite, et sa durée remplace celle
    du sujet. La boîte ne bloque
    pas (``open``, pas ``exec`` : dans le navigateur, Qt n'a pas de boucle d'événements imbriquée) : ``accepted`` livre
    ``paquet`` (avec son ``eleve``, « Nom Prénom ») et ``mot`` (le mot de passe qui l'a ouvert, celui de la copie)."""

    def __init__(self, chemin, mot_de_passe=None, eleve=""):
        super().__init__()
        self.chemin, self.paquet, self.mot = chemin, None, None
        self.classe = self.inscrits = None  # la classe du code qui a ouvert le sujet, et sa liste (aucune : code sans classe)
        self.limite = None  # l'échéance de ce code (UTC), que le lecteur fait respecter
        self.depart = None  # le départ de ce code (UTC), s'il n'est pas encore passé : « Commencer » attend jusque-là
        self.duree = None  # la durée de l'épreuve que ce code donne (minutes), à la place de celle du sujet
        self.soumission = None  # le mode de soumission de ce code (``noyau.SOUMISSIONS``), écrit dans la copie par ``nommer``
        self.surveillance = None  # l'anti-triche de ce code, qui remplace celui du sujet (``nommer``)
        self.bloque = False  # une erreur qu'aucun code ne corrige
        self.maitre = False  # ouvert par le mot de passe professeur (tapé, ou son fichier) : seul à entrer sous son nom
        self.empreinte = ""  # le contrôle du code personnel donné (celui du sujet, ``codes.inscrire``), ou rien
        self.mot_professeur = ""  # le mot de passe professeur tapé (``professeur``), que le lecteur web retient
        self.setWindowTitle("SmartTeacher")
        self.setWindowIcon(QIcon(str(Path(__file__).parent / "associations" / "teacher.svg")))
        # ni bouton de fermeture ni d'agrandissement : dans le navigateur, Qt dessine lui-même la barre de titre, et fermer
        # l'accueil laisserait un canevas vide
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.CustomizeWindowHint | Qt.WindowType.WindowTitleHint)
        self.setProperty("copiable", True)  # GardeCopie laisse le menu contextuel : le code se colle
        self.nom, self.prenom, self.personnel, self.code = QLineEdit(), QLineEdit(), ChampMasque(), ChampMasque()
        # sans eleve, l'identité que SmartOS exporte dans la session (identite-eleve.sh : sur le compte élève, lue dans son
        # coffre) : ici seulement incomplète, l'accueillir() d'une identité complète saute la boîte ; l'élève complète le reste
        nom, prenom = (eleve.split(" ", 1) + [""])[:2] if eleve else (os.environ.get("UTILISATEUR_NOM", ""),
                                                                       os.environ.get("UTILISATEUR_PRENOM", ""))
        self.nom.setText(nom)
        self.prenom.setText(prenom)
        self.code.setText(mot_de_passe or "")  # le code d'un lien (``?code=`` du lecteur web) : refuser() le réessaie
        self.lien = bool(mot_de_passe)  # venu du lien, le code n'a pas de ligne : rien à taper, rien à dévoiler par l'œil
        self.code.textChanged.connect(self._code_tape)
        self.message = QLabel()
        self.message.setWordWrap(True)
        self.formulaire = QFormLayout(self)
        self.formulaire.addRow("Prénom", self.prenom)  # le prénom d'abord : c'est l'ordre dans lequel l'élève se nomme
        self.formulaire.addRow("Nom", self.nom)
        self.formulaire.addRow("Code personnel", self.personnel)
        self.formulaire.addRow("Code du sujet", self.code)
        # chaque libellé à la hauteur de son champ, texte centré : en tactile (``tactile.activer``) le champ monte à 44 px,
        # et QFormLayout laisse le libellé en haut de ligne, plus en face de ce qu'on y tape
        for champ in (self.prenom, self.nom, self.personnel, self.code):
            libelle = self.formulaire.labelForField(champ)
            libelle.setMinimumHeight(champ.sizeHint().height())
            libelle.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.formulaire.addRow(self.message)
        self.bouton = QPushButton("Commencer")  # le clic qui, dans le navigateur, autorise le plein écran (``Lecteur.surveiller``)
        self.bouton.setAutoDefault(False)  # Entrée reste à keyPressEvent
        self.bouton.clicked.connect(self.commencer)
        self.formulaire.addRow(self.bouton)
        self.attente = QTimer(self, interval=1000)
        self.attente.timeout.connect(self.patienter)
        self.setMinimumWidth(360)
        self.ouvrir(mot_de_passe)

    def ouvrir(self, mot_de_passe):
        """Un essai d'ouverture du sujet ; le champ du code n'est là que tant qu'il n'est pas ouvert. Seul un code de classe
        l'ouvre (``deverrouiller``), sauf sur la machine du professeur, où son mot de passe l'ouvre sans code ni liste."""
        try:
            if mot_de_passe:
                self.deverrouiller(mot_de_passe)
            elif not self.rouvrir():  # un fichier en clair, ou la machine du professeur : son mot de passe l'ouvre, sans liste
                self.paquet, self.mot = essayer(self.chemin)
                self.maitre = self.mot is not None
        except MotDePasseRequis as erreur:
            self.paquet = None
            self.dire(erreur.pourquoi if isinstance(erreur, CodeRefuse) else "Ce sujet demande un code de déverrouillage.")
        except Exception as erreur:  # noqa: BLE001 - rien d'autre que le code ne se corrige ici : on le dit
            self.dire(raison(self.chemin, erreur))
            self.bloque = True
        else:
            self.setWindowTitle(self.paquet.titre.replace("\n", " "))
            self.dire("")
        self.patienter()
        self.formulaire.setRowVisible(self.code, self.paquet is None and not self.lien)
        # le code personnel, seulement tant que le sujet est fermé (le mot de passe professeur s'y tape) ou ouvert pour une
        # classe : hors liste, l'élève n'en a pas (l'utilisateur, 03/10/2026, qui renonce au mot de passe sur un lien sans classe)
        self.formulaire.setRowVisible(self.personnel, self.paquet is None or self.inscrits is not None)
        self.adjustSize()
        self.focaliser()

    def copie_rouverte(self):
        """Ouverte, une copie d'élève (sans graine, mais nommée : pas un sujet libre), et pas par le professeur."""
        return self.paquet is not None and not self.paquet.graine and bool(self.paquet.eleve) and not self.maitre

    def rouvrir(self):
        """Une copie déjà enregistrée sur ce compte se rouvre par la clé retenue alors (``retenir_cle``), sans code (l'utilisateur,
        30/09/2026 : « aucun code ne doit être redemandé »). Pas le sujet distribué, qui a le même sel et la même clé : le
        refaire demande le code, dans ses dates. Rend ``False`` si ce n'est pas une copie de ce compte."""
        cle = cle_retenue(self.chemin)
        try:
            paquet, mot = essayer(self.chemin, cle) if cle else (None, None)
        except MotDePasseRequis:
            return False
        if paquet is None or paquet.graine:
            return False
        self.paquet, self.mot = paquet, mot
        return True

    def deverrouiller(self, texte):
        """Ouvre le sujet par le code de classe ``texte``, écrit juste ou à quelques lettres près (``codes.corrections`` :
        plusieurs lectures possibles s'essaient toutes sur le fichier, 0,3 s chacune), ou lève ``CodeRefuse``. Le fichier
        juge d'abord le code (sans contrôle, toute phrase des listes se lit), ses dates ensuite : un refus pour la date ne
        vient ainsi que d'un vrai code. Ce qui n'est pas un code de classe s'essaie d'abord comme le mot de passe professeur
        (``codes.cle_du_mot``) : il ouvre tout sujet, sans classe ni dates, sous le nom ``codes.PROFESSEUR`` (demande de
        l'utilisateur, 28/09/2026 : essayer ses sujets en ligne à la place d'un élève)."""
        horloge.demarrer()  # l'heure en ligne, avant de juger une date
        exact = codes.lire_code(texte)
        pourquoi = "Code incorrect."
        if not exact and self.professeur(texte.strip()):
            return
        lus = [exact] if exact else filter(None, map(codes.lire_code, codes.corrections(texte)))
        for code in (c for lu in lus for c in codes.variantes(lu)):
            try:
                paquet, mot = essayer(self.chemin, code.cle)
            except MotDePasseRequis:
                continue
            classes = sorted(paquet.inscrits)
            if code.classe != codes.SANS_CLASSE and code.classe >= len(classes):  # une classe que le sujet n'a pas
                continue
            proche = code.depart and code.depart - timedelta(minutes=APPROCHE) <= horloge.maintenant() < code.depart
            if codes.refus(code) and not proche:
                pourquoi = codes.refus(code)
                break
            self.paquet, self.mot, self.depart = paquet, mot, code.depart if proche else None
            self.limite, self.duree, self.soumission, self.surveillance = code.echeance, code.duree, code.soumission, code.surveillance
            self.classe = None if code.classe == codes.SANS_CLASSE else classes[code.classe]
            self.inscrits = self.classe and paquet.inscrits[self.classe]
            return
        raise CodeRefuse(pourquoi)

    def professeur(self, texte):
        """Ouvre le sujet si ``texte`` est le mot de passe professeur (``codes.cle_du_mot``), tapé dans l'un ou l'autre champ
        de code (l'utilisateur, 28/09/2026) : tout sujet, sans classe ni dates, même déjà ouvert par un code de classe, sous
        le nom ``codes.PROFESSEUR``. Rend ``False`` si ce n'est pas lui."""
        cle = texte and codes.cle_du_mot(texte, Path(self.chemin).read_bytes())
        if not cle:
            return False
        try:
            self.paquet, self.mot = essayer(self.chemin, cle)
        except MotDePasseRequis:
            return False
        self.maitre, self.mot_professeur = True, texte
        self.classe = self.inscrits = self.limite = self.depart = self.duree = self.soumission = self.surveillance = None
        self.nom.setText(codes.PROFESSEUR[0])
        self.prenom.setText(codes.PROFESSEUR[1])
        return True

    def focaliser(self):
        """Le curseur dans le champ à remplir : le code s'il en faut un, sinon le premier vide de prénom et nom."""
        vide = next((c for c in (self.prenom, self.nom) if not c.text().strip()), self.prenom)
        (self.code if self.paquet is None and not self.lien else vide).setFocus()

    def showEvent(self, evenement):
        """Le focus reposé à l'affichage : dans le navigateur, celui posé à la construction est perdu et Qt le donne au
        dernier champ."""
        super().showEvent(evenement)
        self.focaliser()

    def keyPressEvent(self, evenement):
        """Entrée passe au champ suivant encore vide (dans l'ordre du formulaire, en revenant au début) ; quand tous sont
        remplis, elle commence."""
        if evenement.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            champs = [self.prenom, self.nom] + ([self.code] if self.paquet is None and not self.lien else [])
            ici = champs.index(self.focusWidget()) + 1 if self.focusWidget() in champs else 0
            vide = next((c for c in champs[ici:] + champs[:ici] if not c.text().strip()), None)
            if vide is not None:
                vide.setFocus()
            else:
                self.commencer()
            return
        super().keyPressEvent(evenement)

    def patienter(self):
        """« Commencer » grisé, avec le temps qui reste, jusqu'au départ du code (``APPROCHE``)."""
        reste = (self.depart - horloge.maintenant()).total_seconds() if self.depart else 0
        self.bouton.setEnabled(reste <= 0)
        self.bouton.setText(f"Commencer dans {duree(math.ceil(reste))}" if reste > 0 else "Commencer")
        if reste > 0:
            self.attente.start()
        else:
            self.attente.stop()

    def dire(self, texte):
        """Le message sous les champs ; sa ligne disparaît quand il n'y a rien à dire."""
        self.message.setText(texte)
        self.formulaire.setRowVisible(self.message, bool(texte))

    def _code_tape(self, texte):
        if codes.lire_code(texte):
            self.commencer()

    def transmettre(self):
        self.apres(self.paquet, self.mot)

    def commencer(self):
        if self.bloque:
            return
        if not self.maitre and self.professeur(self.personnel.text().strip()):
            self.personnel.clear()  # un mot de passe, pas un code personnel à vérifier ni à garder dans la copie
            self.formulaire.setRowVisible(self.code, False)
            self.dire("")
            self.patienter()
        if self.paquet is None:
            self.ouvrir(self.code.text())
            if self.paquet is None:
                return
        if self.copie_rouverte():  # par son code (autre compte) :
            self.nommer(self.paquet.eleve)  # son nom, vérifié à la première ouverture ; ni départ ni liste
            self.accept()
            return
        if not self.bouton.isEnabled():  # Entrée, ou le code tapé, avant le départ
            return
        nom, prenom = self.nom.text().strip(), self.prenom.text().strip()
        if not (nom and prenom):
            self.dire("Écrivez votre nom et votre prénom.")
            return
        if self.inscrits is not None:
            inscrit = codes.reconnaitre(nom, prenom, self.inscrits)
            if inscrit is None:
                self.dire(f"« {nom} {prenom} » n'est pas sur la liste de la classe {self.classe} : vérifiez l'orthographe, et le code.")
                return
            nom, prenom = inscrit[:2]
        if not self.maitre and codes.reconnaitre(nom, prenom, [codes.PROFESSEUR]):
            self.dire("Ce nom est celui du professeur : il n'entre que par son mot de passe.")
            return
        personnel = self.personnel.text().strip()
        if personnel and self.inscrits is None:
            self.dire("Ce sujet n'a pas de code personnel : laissez ce champ vide.")
            return
        if personnel and not codes.verifier_personnel(self.mot, inscrit, personnel):
            self.dire(f"Ce code personnel n'est pas celui de {nom} {prenom}.")
            return
        self.empreinte = inscrit[2] if personnel else ""  # vérifié ci-dessus : la copie n'en révèle pas plus que le sujet
        self.nommer(f"{nom} {prenom}")
        self.accept()

    def nommer(self, eleve):
        """Le paquet au nom de ``eleve``, avec ce que le code y met, écrit dans la copie : son mode de soumission, son
        échéance (``limite``), sa durée, son anti-triche, et l'empreinte du code personnel. Une copie rouverte garde les siens
        et son nom, ceux de sa première ouverture (l'utilisateur, 30/09/2026). ``distribue`` (non enregistré) dit s'il sort du
        sujet distribué ou d'une copie rouverte : ``copie`` en décide où écrire."""
        distribue = bool(self.paquet.graine)
        with noyau.en_donnees():
            self.paquet = self.paquet.nommer(eleve, self.soumission)
        self.paquet.distribue = distribue
        if not distribue:
            return self.paquet
        if self.surveillance is not None:
            self.paquet.surveillance = self.surveillance
        self.paquet.empreinte, self.paquet.limite = self.empreinte, self.limite and self.limite.timestamp()
        if self.duree:
            self.paquet.duree_minutes = self.duree
        return self.paquet

    def refuser(self, texte):
        """La boîte rouverte sur le sujet, avec la raison : le professeur refuse ce nom (lecteur web, ``pont_qt``)."""
        self.ouvrir(self.code.text() or None)
        self.dire(texte)
        self.open()


def essayer(chemin, mot_de_passe=None):
    """``voir.essayer``, en données (``noyau.en_donnees``) : l'accueil ne montre du sujet que son titre et ses listes, et
    ``Lecteur`` en construit l'écran, sur la copie de l'élève."""
    with noyau.en_donnees():
        return essayer_ecran(chemin, mot_de_passe)


def accueillir(chemin, apres, mot_de_passe=None, eleve=""):
    """L'accueil de l'élève, puis ``apres(paquet, mot)`` : tout de suite si l'élève est déjà nommé (``--eleve``,
    ``?eleve=``, ou l'identité que SmartOS exporte dans la session) et que le sujet s'ouvre sans lui demander de code ni
    le chercher sur une liste (un code de classe, même venu d'un lien), sinon quand il a rempli la boîte. Rend la boîte, à
    garder tant qu'elle est ouverte (``None`` si elle a été sautée)."""
    if not eleve:
        nom, prenom = os.environ.get("UTILISATEUR_NOM", "").strip(), os.environ.get("UTILISATEUR_PRENOM", "").strip()
        if nom and prenom:
            eleve = f"{nom} {prenom}"
    accueil = Accueil(chemin, mot_de_passe, eleve)
    if accueil.copie_rouverte():
        eleve = accueil.paquet.eleve  # son nom, sans boîte
    # un nom à vérifier, sur la liste ou comme celui du professeur (``Accueil.maitre``), passe par la boîte
    if eleve and accueil.paquet is not None and accueil.inscrits is None and (
            accueil.maitre or not codes.reconnaitre(eleve, "", [codes.PROFESSEUR])):
        apres(accueil.nommer(eleve), accueil.mot)
        return None
    accueil.apres = apres
    accueil.accepted.connect(accueil.transmettre)
    accueil.open()
    return accueil


def copie(source, paquet, mot):
    """``(chemin, paquet)`` : où écrire la copie de ``paquet``, ouvert depuis ``source`` (un ``.qcm`` ou un PDF), et le paquet à
    montrer. Sur la machine du professeur, qui lit ou essaie un sujet distribué, nulle part (``None``) ; chez l'élève, en place :
    le sujet devient sa copie, qu'il ne pourra pas recommencer. Sauf un PDF (ou un ``.json``), qu'on ne réécrit pas : sa copie va à côté de lui,
    « <sujet> [Nom Prénom].qcm » (le même nom que sur Dropbox, ``codes.chemin_copie``), reprise s'il l'a déjà commencée."""
    if paquet.distribue and codes.professeur() is not None:
        return None, paquet
    if source.suffix == ".qcm":
        return source, paquet
    chemin = source.with_name(codes.nom_de_fichier(f"{source.stem} [{paquet.eleve}]") + ".qcm")
    return chemin, charger(chemin, mot) if chemin.exists() else paquet


def chemin_essai(chemin, numero):
    """La copie du ``numero``-ième essai, à côté de ``chemin`` (celle d'un autre essai) : « <nom> (2ème essai).qcm »."""
    chemin = Path(chemin)
    return chemin.with_name(re.sub(r" \(\d+ème essai\)$", "", chemin.stem) + codes.essai(numero) + chemin.suffix)


def copie_du_pdf(pdf):
    """La copie commencée à côté du PDF (``copie``) et enregistrée sur ce compte (``cle_retenue``), à rouvrir sans code à la
    place du sujet qu'il embarque ; ``None`` s'il n'y en a pas, ou plusieurs (un compte partagé : l'accueil demande le code)."""
    trouvees = [c for c in pdf.parent.glob("*.qcm") if c.name.startswith(f"{pdf.stem} [") and cle_retenue(c)]
    return trouvees[0] if len(trouvees) == 1 else None


def fichier_des_cles():
    """Les clés des copies enregistrées sur ce compte, ``{sel de l'en-tête age : clé}`` : le sel est celui du sujet, le
    même pour toutes ses copies, où qu'elles soient déplacées. La clé est celle que le code donne : ce fichier n'en dit pas
    plus que le code à qui lit le compte de l'élève, et une copie passée sur un autre compte (clé USB) redemande le code."""
    dossier = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.GenericDataLocation)
    return Path(dossier) / "SmartTeacher" / "cles_des_copies.json"


def cle_retenue(chemin):
    """La clé retenue pour le fichier ``chemin`` (``retenir_cle``), ou ``None`` (dans le navigateur : jamais)."""
    if sys.platform == "emscripten" or not fichier_des_cles().exists():
        return None
    sel = sel_de(chemin)
    return sel and json.loads(fichier_des_cles().read_text()).get(sel)


def sel_de(chemin):
    """Le sel de l'en-tête age du fichier ``chemin`` (``codes.sel_du_fichier``) : l'index des clés retenues."""
    with open(chemin, "rb") as fichier:
        return codes.sel_du_fichier(fichier.read(200))


def retenir_cle(chemin, mot):
    """Retient la clé ``mot`` de la copie ``chemin``, pour la rouvrir sans code (``Accueil.rouvrir``)."""
    if sys.platform == "emscripten" or not mot:
        return
    cles = json.loads(fichier_des_cles().read_text()) if fichier_des_cles().exists() else {}
    sel = sel_de(chemin)
    if sel and cles.get(sel) != mot:
        try:  # un compte sans dossier de données écrivable : la copie redemandera son code, elle s'enregistre quand même
            fichier_des_cles().parent.mkdir(parents=True, exist_ok=True)
            fichier_des_cles().write_text(json.dumps(cles | {sel: mot}, indent=0))
        except OSError:
            pass


def lancer(chemin, mot_de_passe=None, eleve="", source=None):
    """Sans accueil : le lecteur d'un sujet qui s'ouvre sans rien demander (``--auto``, ``--capture``), ou ``SystemExit``.
    ``source`` : le fichier ouvert, quand ``chemin`` est le ``.qcm`` qu'en a tiré ``exporter_eleve.qcm_de``."""
    with noyau.en_donnees():  # l'écran, une fois, par ``Lecteur``
        paquet, mot = ouvrir(chemin, mot_de_passe, interactif=False)
        distribue = bool(paquet.graine)
        paquet = paquet.nommer(eleve)
    paquet.distribue = distribue
    source = Path(source or chemin)
    return Lecteur(*copie(source, paquet, mot), mot, source)


def main():
    analyseur = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    analyseur.add_argument("sujet")
    analyseur.add_argument("--mot-de-passe")
    analyseur.add_argument("--eleve", default="", help="« Nom Prénom » : l'accueil est sauté si le sujet s'ouvre sans code")
    analyseur.add_argument("--auto", action="store_true", help="répond juste, enregistre et sort, sans fenêtre")
    analyseur.add_argument("--capture", help="écrit l'image de la fenêtre dans ce fichier, puis sort")
    mode = analyseur.add_mutually_exclusive_group()
    mode.add_argument("--tactile", action="store_true", help="les cibles d'un écran au doigt, même sans écran tactile détecté")
    mode.add_argument("--souris", action="store_true", help="les cibles de la souris, même sur un écran tactile (pour comparer)")
    a = analyseur.parse_args()
    app = application()
    if not (a.auto or a.capture):
        erreurs.installer()  # sans personne devant l'écran, une boîte bloquerait
    if a.tactile or (not a.souris and tactile.detecte()):
        tactile.activer(app)
    GardeCopie(app)  # vit autant que l'application (son parent)
    source = Path(a.sujet)
    extrait = tempfile.TemporaryDirectory()  # le .qcm tiré d'un PDF ou d'un .json, effacé à la sortie
    sujet = a.sujet
    if source.suffix in (".pdf", ".json"):
        from exporter_eleve import qcm_de  # noqa: PLC0415 - ici seulement : le lecteur web n'embarque pas exporter_eleve.py
        sujet = source.suffix == ".pdf" and copie_du_pdf(source) or qcm_de(source, Path(extrait.name))
    if a.auto:
        lecteur = lancer(sujet, a.mot_de_passe, a.eleve, a.sujet)
        paquet = lecteur.paquet
        for f in paquet.feuilles:
            f.demarrer()
            f.saisie = f.juste()
            f.soumettre()
        paquet.terminer()
        lecteur.enregistrer()
        obtenus, corriges, attente = paquet.resultat()
        print(f"{obtenus:g} / {corriges:g}" + (f" (+ {attente:g} à corriger)" if attente else ""))
        return 0
    if a.capture:
        lecteur = lancer(sujet, a.mot_de_passe, a.eleve, a.sujet)
        lecteur.show()
        for _ in range(3):
            app.processEvents()
        lecteur.grab().save(a.capture)
        return 0
    vivants = []  # l'accueil puis le lecteur : des références, sans quoi Python les détruirait avant ``exec``

    def montrer(paquet, mot):
        vivants.append(Lecteur(*copie(Path(a.sujet), paquet, mot), mot, Path(a.sujet)))
        vivants[-1].show()
        vivants[-1].surveiller()

    vivants.append(accueillir(sujet, montrer, a.mot_de_passe, a.eleve))
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
